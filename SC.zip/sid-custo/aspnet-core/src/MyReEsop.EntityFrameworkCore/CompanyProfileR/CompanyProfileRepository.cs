﻿using Abp.Application.Services.Dto;
using Abp.Data;
using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MyReEsop.Authorization.Users;
using MyReEsop.Authorization.Users.Dtos;
using MyReEsop.CompanyProfile;
using MyReEsop.CompanyProfile.Dto;
using MyReEsop.EntityFrameworkCore;
using MyReEsop.EntityFrameworkCore.Repositories;
using MyReEsop.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;


namespace MyReEsop.CompanyProfileR
{
    public class CompanyProfileRepository : MyReEsopRepositoryBase<User, long>, ICompanyRepo
    {
            private readonly IActiveTransactionProvider _transactionProvider;

            public CompanyProfileRepository(IDbContextProvider<MyReEsopDbContext> dbContextProvider, IActiveTransactionProvider transactionProvider)
                : base(dbContextProvider)
            {
                _transactionProvider = transactionProvider;
            } 

      

        public async Task<CompanyMaster> GetUserNames()
        {
            EnsureConnectionOpen();

            using (var command = CreateCommand("PROC_GET_COMPANY_INFO", CommandType.StoredProcedure))
            {
                using (var dataReader = await command.ExecuteReaderAsync())
                {
                    CompanyMaster companyDetails = new CompanyMaster();
                    while (dataReader.Read())
                    {
                        
                        companyDetails.CompanyName = Convert.ToString(dataReader["CompanyName"]);
                        companyDetails.CompanyAddress = Convert.ToString(dataReader["CompanyAddress"]);
                        companyDetails.CompanyEmailId = Convert.ToString(dataReader["CompanyEmailID"]);
                        companyDetails.AdminEmailId = Convert.ToString(dataReader["AdminEmailID"]);
                        companyDetails.CompanyUrl = Convert.ToString(dataReader["CompanyURL"]);
                        companyDetails.AdminUserId = Convert.ToString(dataReader["AdminUserID"]);
                        companyDetails.MaxLoginAttempts = Convert.ToInt32(dataReader["MaxLoginAttempts"]);
                        
                    }

                    return companyDetails;
                }
            }
        }

        public async Task<UpdateCompanyProfile> UpdateCompanyInfoAsync()
        {
            EnsureConnectionOpen();

            using (var command = CreateCommand("PROC_GET_COMPANY_INFO", CommandType.StoredProcedure))
            {
                using (var dataReader = await command.ExecuteReaderAsync())
                {
                    UpdateCompanyProfile update = new UpdateCompanyProfile();
                    while (dataReader.Read())
                    {
                        update.CompanyAddress = Convert.ToString(dataReader["CompanyAddress"]);
                    }
                    return update;
                }
            }
        }

       

        private DbCommand CreateCommand(string commandText, CommandType commandType, params SqlParameter[] parameters)
            {
                var command = Context.Database.GetDbConnection().CreateCommand();

                command.CommandText = commandText;
                command.CommandType = commandType;
                command.Transaction = GetActiveTransaction();

                foreach (var parameter in parameters)
                {
                    command.Parameters.Add(parameter);
                }

                return command;
            }

            private void EnsureConnectionOpen()
            {
                var connection = Context.Database.GetDbConnection();

                if (connection.State != ConnectionState.Open)
                {
                    connection.Open();
                }
            }

            private DbTransaction GetActiveTransaction()
            {
                return (DbTransaction)_transactionProvider.GetActiveTransaction(new ActiveTransactionProviderArgs
            {
                {"ContextType", typeof(MyReEsopDbContext) },
                {"MultiTenancySide", MultiTenancySide }
            });
            }


        
    }
}


