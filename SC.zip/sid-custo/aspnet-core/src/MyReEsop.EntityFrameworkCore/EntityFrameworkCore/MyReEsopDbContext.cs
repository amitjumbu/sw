﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using MyReEsop.Authorization.Roles;
using MyReEsop.Authorization.Users;
using MyReEsop.MultiTenancy;
using MyReEsop.Models;


namespace MyReEsop.EntityFrameworkCore
{
    public class MyReEsopDbContext : AbpZeroDbContext<Tenant, Role, User, MyReEsopDbContext>
    {
        public DbSet<CompanyMaster> CompanyM { get; set; }
        public DbSet<CurrencyMaster> CURRENCY_MASTER { get; set; }

        public MyReEsopDbContext(DbContextOptions<MyReEsopDbContext> options)
            : base(options)
        {
            
        }
        
    }
}
