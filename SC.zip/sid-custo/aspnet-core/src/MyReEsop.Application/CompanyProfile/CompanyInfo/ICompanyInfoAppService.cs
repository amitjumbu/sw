﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using MyReEsop.Authorization.Users.Dtos;
using MyReEsop.CompanyProfile.CompanyInfo.Dto;
using MyReEsop.Models;
using MyReEsop.Roles.Dto;
using MyReEsop.Users.Dto;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CreateUserDto = MyReEsop.Users.Dto.CreateUserDto;

namespace MyReEsop.CompanyProfile.CompanyInfo
{
    public interface ICompanyInfoAppService : IApplicationService
    {
        Task<CompanyMaster> GetUserNamesAsync();
        void UpdateCompanyInfo(CreateUpdateCompanyProDTO input);
    }
}
