﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using Abp.Domain.Entities;
using System;
using MyReEsop.Models;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.CompanyProfile.CompanyInfo.Dto
{
    [AutoMapFrom(typeof(CompanyMaster))]
    public class CompanyDTO : AuditedEntityDto<Guid>
    {

        public string CompanyName { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyUrl { get; set; }
        public string CompanyEmailId { get; set; }
        public string AdminEmailId { get; set; }
        public string AdminUserId { get; set; }

    }

}
