﻿using Abp.AutoMapper;
using MyReEsop.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.CompanyProfile.CompanyInfo.Dto
{
    [AutoMapTo(typeof(CompanyMaster))]
    public class CreateUpdateCompanyProDTO
    {
        public string CompanyAddress { get; set; }
    }
}
