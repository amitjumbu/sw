﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.CompanyProfile.CompanyInfo.Dto
{
    public class Company
    {
        public string CompanyName { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyUrl { get; set; }
        public string CompanyEmailId { get; set; }
        public string AdminEmailId { get; set; }
        public string AdminUserId { get; set; }
    }
}
