﻿using Abp.Authorization;
using MyReEsop.Authorization;
using MyReEsop.CompanyProfile.CompanyInfo.Dto;
using MyReEsop.Models;
using System;
using System.Threading.Tasks;

namespace MyReEsop.CompanyProfile.CompanyInfo
{
    [AbpAuthorize(PermissionNames.Pages_Users)]
    public class CompanyInfoAppService : ICompanyInfoAppService
    {                        

        private readonly ICompanyRepo _userRepository;    
        public CompanyInfoAppService(ICompanyRepo userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<CompanyMaster> GetUserNamesAsync()
        {
            return await _userRepository.GetUserNames();
        }

        public void UpdateCompanyInfo(CreateUpdateCompanyProDTO input)
        {
            throw new NotImplementedException();
        }

        
    }
}
