﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using MyReEsop.CompanyProfile.PaymentMode.Dto;
using MyReEsop.Models;
using MyReEsop.Roles.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MyReEsop.CompanyProfile.PaymentMode
{
    public class CurrencyMasterAppService: AsyncCrudAppService<
        CurrencyMaster,
        CurrencyMasterDto,
        int,
        PagedCompanyMasterResultRequestDto,
        CreateCurrencyMInput,
        CurrencyMasterDto>,ICurrencyMasterAppService
    {
        public CurrencyMasterAppService(IRepository<CurrencyMaster, int> repository)
            : base(repository)
        {

        }

        

        public async Task<UpdateCurrencyMDto> GetPaymentModeForEdit(EntityDto input)
        {
            
            return new UpdateCurrencyMDto
            {
              CurrencyName="Esop",
              CureencyAlias="Rupees",
              CureencySymbol="Rs"

            };
        }

        public Task<ListResultDto<PermissionDto>> GetAllPermissions()
        {
            var permissions = PermissionManager.GetAllPermissions();

            return Task.FromResult(new ListResultDto<PermissionDto>(
                ObjectMapper.Map<List<PermissionDto>>(permissions)
            ));
        }
    }
    
}
