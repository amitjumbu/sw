﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using MyReEsop.CompanyProfile.PaymentMode.Dto;
using MyReEsop.Models;
using MyReEsop.Roles.Dto;
using System;
using System.Threading.Tasks;

namespace MyReEsop.CompanyProfile.PaymentMode
{
    public interface ICurrencyMasterAppService : IAsyncCrudAppService<
        CurrencyMasterDto,
        int,
        PagedCompanyMasterResultRequestDto,
        CreateCurrencyMInput,
        CurrencyMasterDto>
    {
        Task<UpdateCurrencyMDto> GetPaymentModeForEdit(EntityDto input);
        Task<ListResultDto<PermissionDto>> GetAllPermissions();
    }
}
