﻿using Abp.Application.Services.Dto;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.CompanyProfile.PaymentMode.Dto
{
    public class GetAllTasksInput : PagedAndSortedResultRequestDto
    {
        public string CurrencyName{ get; set; }
    }
}
