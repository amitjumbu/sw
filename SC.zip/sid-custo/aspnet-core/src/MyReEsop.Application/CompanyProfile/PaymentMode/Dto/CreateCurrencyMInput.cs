﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using MyReEsop.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.CompanyProfile.PaymentMode.Dto
{
    [AutoMapTo(typeof(CurrencyMaster))]
    public class CreateCurrencyMInput: EntityDto<Guid>
    {
        public string CurrencyName { get; set; }
        public string CureencySymbol { get; set; }
        public string CureencyAlias { get; set; }
    }
}
