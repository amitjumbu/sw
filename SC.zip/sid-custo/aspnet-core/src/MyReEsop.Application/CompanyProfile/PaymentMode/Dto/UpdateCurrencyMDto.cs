﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using MyReEsop.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.CompanyProfile.PaymentMode.Dto
{
   
    public class UpdateCurrencyMDto : EntityDto<int>
    { 
        public string CurrencyName { get; set; }
        public string CureencySymbol { get; set; }
        public string CureencyAlias { get; set; }
    }
}
