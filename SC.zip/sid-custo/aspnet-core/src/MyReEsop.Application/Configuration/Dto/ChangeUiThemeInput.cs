﻿using System.ComponentModel.DataAnnotations;

namespace MyReEsop.Configuration.Dto
{
    public class ChangeUiThemeInput
    {
        [Required]
        [StringLength(32)]
        public string Theme { get; set; }
    }
}
