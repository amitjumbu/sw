﻿using System.Threading.Tasks;
using MyReEsop.Configuration.Dto;

namespace MyReEsop.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
