using Abp.Application.Services;
using Abp.Application.Services.Dto;
using MyReEsop.Authorization.Users.Dtos;
using MyReEsop.Roles.Dto;
using MyReEsop.Users.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyReEsop.Users
{
    public interface IUserAppService : IAsyncCrudAppService<UserDto, long, PagedResultRequestDto, CreateUserDto, UserDto>
    {
        Task<ListResultDto<RoleDto>> GetRoles();

        Task<List<string>> GetUsers();

        Task<List<string>> GetAdminUsernames();

        Task DeleteUser(EntityDto input);

        Task UpdateEmailAsync(UpdateEmailDto input);

        Task<GetUserByIdOutput> GetUserById(EntityDto input);
       

    }
}
