﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using MyReEsop.MultiTenancy.Dto;

namespace MyReEsop.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<
        TenantDto, int, 
        PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

