﻿namespace MyReEsop
{
    public class MyReEsopConsts
    {
        public const string LocalizationSourceName = "MyReEsop";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
