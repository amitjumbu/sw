﻿using Abp.Domain.Entities;
using Abp.Domain.Entities.Auditing;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace MyReEsop.Models
{
    [Table("CompanytMaster")]
    public class CompanyMaster: FullAuditedEntity
    {        
        public string CompanyName { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyUrl { get; set; }
        public string CompanyEmailId { get; set; }
        public string AdminEmailId { get; set; }
        public string AdminUserId { get; set; }
        public int MaxLoginAttempts { get; set; }
    }
}
