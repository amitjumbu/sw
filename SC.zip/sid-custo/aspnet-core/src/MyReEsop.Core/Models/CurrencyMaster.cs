﻿using Abp.Domain.Entities;
using Abp.Domain.Entities.Auditing;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace MyReEsop.Models
{
    [Table("CURRENCY_MASTER")]
    public class CurrencyMaster : Entity<int>
    {
            public string CurrencyName { get; set; }
            public string CureencySymbol { get; set; }
              public string CureencyAlias { get; set; }

    }
}
