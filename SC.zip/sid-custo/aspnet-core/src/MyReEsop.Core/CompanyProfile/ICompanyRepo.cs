﻿using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using MyReEsop.Authorization.Users;
using MyReEsop.Authorization.Users.Dtos;
using MyReEsop.CompanyProfile.Dto;
using MyReEsop.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyReEsop.CompanyProfile
{
    public interface ICompanyRepo : IRepository<User, long>
    {        
        Task<CompanyMaster> GetUserNames();
        Task<UpdateCompanyProfile> UpdateCompanyInfoAsync();
    }
}
