﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.CompanyProfile.Dto
{
    public class UpdateCompanyProfile
    {
        public string CompanyAddress { get; set; }
    }
}
