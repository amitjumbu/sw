﻿using Abp.Application.Features;
using Abp.Domain.Repositories;
using MyReEsop.Editions;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.PaymentMode
{
    public class PaymentModeManager
    {
        public PaymentModeManager(
            IRepository<Tenant> tenantRepository,
            IRepository<TenantFeatureSetting, long> tenantFeatureRepository,
            EditionManager editionManager,
            IAbpZeroFeatureValueStore featureValueStore)
            : base(
                tenantRepository,
                tenantFeatureRepository,
                editionManager,
                featureValueStore)
        {
        }
    }
}
