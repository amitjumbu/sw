namespace MyReEsop.Authorization.Users.Dtos
{
    public class GetUserByIdOutput
    {
        public string Username { get; set; }
    }
}