﻿using Abp.Application.Services.Dto;

namespace MyReEsop.Authorization.Users.Dtos
{
    public class UpdateEmailDto:EntityDto
    {
        public string EmailAddress { get; set; }
    }
}