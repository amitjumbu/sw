
import { Component, OnInit } from '@angular/core';
import { Field } from 'ng2-jsgrid';

@Component({
    selector: 'app-company-settings',
    templateUrl: './company-settings.component.html',
    styleUrls: ['./company-settings.component.css']
})
export class CompanySettingsComponent  implements OnInit {
    fields: Field[];
    api = async (filter) => {
      // Call from API with current filter
      // Some samples:
      // const result = await this._someService.getDate(filter).toPromise();
   
      console.log(filter);
   
      const promise = new Promise((res) => {
        setTimeout(() => {
          res({
            itemsCount: 12,
            data: [
              { name: 'John', age: 30 },
              { name: 'Smith', age: 46 },
            ]
          });
        }, 3000);
      });
   
      const result = await promise;
      return result;
    }
    ngOnInit(): void {
      this.fields = [
        { name: 'name', title: 'Name' },
        { name: 'age', title: 'Age' }
      ];
    }
}
