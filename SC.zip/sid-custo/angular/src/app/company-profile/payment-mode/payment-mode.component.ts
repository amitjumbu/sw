import { Component, Injector } from '@angular/core';
import { MatDialog } from '@angular/material';
import { finalize } from 'rxjs/operators';

import {
    PagedListingComponentBase,
    PagedRequestDto
} from 'shared/paged-listing-component-base';
import {  
    PaymentModeDto,
    PaymentModeServiceProxy,
    PagedResultDtoOfPaymentModeDto } from '@shared/service-proxies/service-proxies';
    

import { UpdateModeComponent } from './update-mode/update-mode.component';
import { CreateModeComponent } from './create-mode/create-mode.component';
import { Observable } from 'rxjs';

class PagedPaymentModeRequestDto extends PagedRequestDto {
  keyword: string;
  isActive: boolean | null;
}


@Component({
  selector: 'app-payment-mode',
  templateUrl: './payment-mode.component.html',
  styleUrls: ['./payment-mode.component.css']
})
export class PaymentModeComponent extends PagedListingComponentBase<PaymentModeDto> {
  PaymentMode:  PaymentModeDto[] = [];
  PM : Observable<PaymentModeDto>;
  keyword = '';
  isActive: boolean | null;
  PMode:any;

  constructor(
      injector: Injector,
      private _PaymentModeService: PaymentModeServiceProxy,
      private _dialog: MatDialog
  ) {
      super(injector);
  }

  loadAll() {  
    this.PM =this._PaymentModeService.GetPaymentModeForEdit();
  }

  

  list(
      request: PagedPaymentModeRequestDto,
      pageNumber: number,
      finishedCallback: Function
  ): void {

      request.keyword = this.keyword;
      request.isActive = this.isActive;

      this._PaymentModeService
           .getAll(request.keyword, request.isActive, request.skipCount, request.maxResultCount)
          //.GetPaymentModeForEdit()
          .pipe(
              finalize(() => {
                  finishedCallback();
              })
          )
          .subscribe((result: PagedResultDtoOfPaymentModeDto) => {
              this.PaymentMode = result.items;
              this.showPaging(result, pageNumber);
          });
  }

  delete(PaymentMode: PaymentModeDto): void {
      abp.message.confirm(
          this.l('TenantDeleteWarningMessage', PaymentMode.CurrencyName),
          (result: boolean) => {
              if (result) {
                  this._PaymentModeService
                      .delete(PaymentMode.CureencyId)
                      .pipe(
                          finalize(() => {
                              abp.notify.success(this.l('SuccessfullyDeleted'));
                              this.refresh();
                          })
                      )
                      .subscribe(() => { });
              }
          }
      );
  }

  createPaymentMode(): void {
      this.showCreateOrEditPaymentModeDialog();
  }

  editPaymentMode(Pm: PaymentModeDto): void {
      this.showCreateOrEditPaymentModeDialog(Pm.CureencyId);
  }

  showCreateOrEditPaymentModeDialog(id?: number): void {
      let CreateMode;
      if (id === undefined || id <= 0) {
        CreateMode = this._dialog.open(CreateModeComponent);
      } else {
        CreateMode = this._dialog.open(UpdateModeComponent, {
              data: id
          });
      }

      CreateMode.afterClosed().subscribe(result => {
          if (result) {
              this.refresh();
          }
      });
  }
}
