import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-mode',
  templateUrl: './create-mode.component.html',
  styleUrls: ['./create-mode.component.css']
})
export class CreateModeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
