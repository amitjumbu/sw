export class  CurrencyMaster{  
    CurrencyName:string;  
    CureencySymbol:string ;  
    CureencyAlias:string;  
    CureencyId:number;  

 }  