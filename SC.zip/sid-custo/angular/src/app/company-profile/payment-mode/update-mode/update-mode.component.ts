import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-mode',
  templateUrl: './update-mode.component.html',
  styleUrls: ['./update-mode.component.css']
})
export class UpdateModeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
