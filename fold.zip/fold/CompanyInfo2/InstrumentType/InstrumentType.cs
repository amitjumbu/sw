﻿using Abp.Domain.Entities;
using System.ComponentModel.DataAnnotations;

namespace MyReEsop.CompanyInfo.InstrumentType
{
    public class InstrumentType:Entity<int>
    {
       
        public string INSTRUMENTNAME { get; set; }        

        public string M { get; set; }

        public string CurrencySymbol { get; set; }

        public string CurrencyAlias { get; set; }

        public string SEMVALRPT { get; set; }

        public bool ISENABLED { get; set; }

        public InstrumentType()
        {

        }
        //public InstrumentType(string Name)
        //{
        //    INSTRUMENT_NAME = Name;
        //}
    }
}
