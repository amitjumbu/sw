﻿using Abp.Application.Services.Dto;

namespace MyReEsop.CompanyInfo.InstrumentType.Dtos
{
    public class UpdateIntrumentTypeDto : EntityDto
    {
        
        public string MSEid { get; set; }

        public int SEMVALRPTID { get; set; }

        public bool ISENABLED { get; set; }

        public string UPDATED_BY { get; set; }

        public int CIMid { get; set; }

        public int Curencyid { get; set; }
        
    }
}
