﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// Code behind page for Home.aspx
    /// </summary>
    public partial class Home : BasePage
    {
        /// <summary>
        /// Page load method for Home.aspx
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            if (Session["IsLoginSucceed"] == null)
            {
                Response.Redirect("~/View/Login.aspx", false);
            }
        }
    }
}