﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// Class is used to perform CURD company creation
    /// </summary>
    public partial class CompanyCreation : BasePage
    {
        int n_index = 0, n_ID = 0, n_MMID = 0, n_SMID = 0, n_CMID = 0, n_IsActive = 0, n_CompCreatedOn = 0, n_ModuleAssociastion = 0, n_Remark = 0, n_Action = 0;

        /// <summary>
        /// Perform page load event.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                    {
                        // Method is used to bind UI
                        companyCreationModel.BindPageUI(this);

                        // Method is used to bind all controls i.e. grid and drop down list ect.
                        companyCreationModel.BindControls(this);

                        // Method is used to get and store the list of all the associated modules into a datatable.
                        companyCreationModel.GetModuleAssociationList(this);

                        // Binds calculation method dropdown and status method dropdown.
                        companyCreationModel.Bind_CMthd_dropdowns(this);

                        // Encrypts query string which has to be passed on to report page.
                        companyCreationModel.EncryptData(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Perform page load event.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.GvRowDatabaBind(sender, e, this, ref n_index, ref n_ID, ref n_CompCreatedOn, ref n_ModuleAssociastion, ref n_Remark, ref n_Action);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to perform filter operation on search gird.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void btnCCSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.ApplyFilterToGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used for remove filters from the search grid.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.ClearFilterFromGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to perform CUD operation.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void btnCURDCreate_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.CompanyCreation(this);
                    companyCreationModel.GetModuleAssociationList(this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to reset parameter on the page.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void btnCURDCancel_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.ClearCRUDDetails(this, true);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to perform page indexing of the grid.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.GvPageIndexChanging(sender, e, this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to perform CUD operation for add data to grid view.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void btnCRUDAddToGrid_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.AddModuleDetailToGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to perform operation on dropdown change.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void ddlCRUDModuleId_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.BindSubModule(this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to perform operation on while data bind to the grid.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void gvModuleAssociation_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.GvModuleAssociationRowDatabaBind(sender, e, this, ref n_index, ref n_MMID, ref n_SMID, ref n_CMID, ref n_IsActive);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to perform page indexing of the module association grid.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void gvModuleAssociation_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.GvModuleAssociationPageIndexChanging(sender, e, this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to perform operation on dropdown change.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void ddlCRUDCompanyType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.ddlCURDTypeSelectedIndexChanged(sender, e, this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to reset page and open company creation popoup
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void btnCCCreate_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.btnCCCreate_Click(sender, e, this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to perform operation on dropdown change.
        /// </summary>
        /// <param name="sender">Paramter as Sender</param>
        /// <param name="e">Parameter as Event Args e</param>
        protected void ddlCRUDListingStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.ddlCRUDListingStatus_SelectedIndexChanged(sender, e, this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to select only the required company modules from the list of all modules
        /// </summary>
        /// <param name="s_CompanyDbName">Company Database Name</param>
        /// <param name="s_BtnId">s_BtnId</param>
        /// <returns>returns list type having module details</returns>
        [WebMethod]
        public static ModuleList[] Get_Filtered_AssociationList(string s_CompanyDbName, string s_BtnId)
        {
            List<ModuleList> Detail = new List<ModuleList>();
            DataTable dt_FilteredModuleList = new DataTable();

            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    dt_FilteredModuleList = companyCreationModel.Filter_ModuleAssociationList(s_CompanyDbName);
                    foreach (DataRow dtRow in dt_FilteredModuleList.Rows)
                    {
                        if (s_BtnId.Equals("View"))
                        {
                            ModuleList DataObj = new ModuleList();
                            DataObj.ModuleName = dtRow["Module Name"].ToString();
                            DataObj.SubmoduleName = dtRow["Submodule Name"].ToString();
                            DataObj.CalculationMethod = dtRow["Calculation Method"].ToString() == "" ? "-" : dtRow["Calculation Method"].ToString();
                            DataObj.CompanyName = dtRow["Company_Name"].ToString();
                            DataObj.Status = dtRow["Status"].ToString();
                            Detail.Add(DataObj);
                        }
                        else
                        {
                            ModuleList DataObj = new ModuleList();
                            DataObj.Mmid = dtRow["MMID"].ToString();
                            DataObj.Smid = dtRow["SMID"].ToString();
                            DataObj.Cmid = dtRow["CMID"].ToString() == "" ? "0" : dtRow["CMID"].ToString();
                            DataObj.CompanyId = dtRow["COMPANY_ID"].ToString();
                            DataObj.ModuleName = dtRow["Module Name"].ToString();
                            DataObj.SubmoduleName = dtRow["Submodule Name"].ToString();
                            DataObj.CalculationMethod = dtRow["Calculation Method"].ToString() == "" ? "-" : dtRow["Calculation Method"].ToString();
                            DataObj.CompanyName = dtRow["Company_Name"].ToString();
                            DataObj.DataBase_Name = dtRow["Database_Name"].ToString();
                            DataObj.Status = dtRow["Status"].ToString();
                            Detail.Add(DataObj);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
            return Detail.ToArray();
        }

        /// <summary>
        /// Class for binding data
        /// </summary>		
        public class ModuleList
        {
            /// <summary>
            /// 
            /// </summary>
            public string Mmid { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string ModuleName { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string Smid { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string SubmoduleName { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string Cmid { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string CalculationMethod { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string CompanyId { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string CompanyName { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string DataBase_Name { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string Status { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string DisplayMessage { get; set; }


        }

        /// <summary>
        /// This is Edit Module functionality's submodule select event
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">event arguement</param>
        protected void ddAMMMName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (!hdnindex.Value.Equals("2") && ddAMMMName.SelectedIndex > 0)
                    using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                    {
                        companyCreationModel.Bind_EditSubModule(this);
                    }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is click event of save buton .
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">event arguement e</param>
        protected void btnAMSubmit_Click(object sender, EventArgs e)
        {
            using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
            {
                companyCreationModel.PerformCUD(this, "", hdnEditMmId.Value);
                companyCreationModel.BindControls(this);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_editModule_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
            {
                companyCreationModel.gv_EditModule_RowDatabound(sender, e, this, ref n_index, ref n_MMID, ref n_SMID, ref n_CMID, ref n_IsActive);
            }
        }

        /// <summary>
        /// This method toggles the Is_Active status of selected module.
        /// </summary>
        /// <param name="s_CompanyName">s_CompanyName</param>
        /// <param name="CompanyId">CompanyId</param>
        /// <param name="Mmid">Mmid</param>
        /// <param name="Smid">Smid</param>
        /// <param name="Cmid">Cmid</param>
        /// <param name="s_Status">s_Status</param>
        /// <returns>returns string </returns>
        [WebMethod]
        public static ModuleList[] AlterModuleStatus(string s_CompanyName, int CompanyId, int Mmid, int Smid, string Cmid, string s_Status)
        {
            List<ModuleList> Detail = new List<ModuleList>();
            DataTable dt_FilteredModuleList = new DataTable();
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    string s_DisplayMessage = companyCreationModel.AlterModuleStatus(s_CompanyName, CompanyId, Mmid, Smid, Cmid, s_Status);
                    dt_FilteredModuleList = companyCreationModel.Filter_ModuleAssociationList(s_CompanyName);
                    foreach (DataRow dtRow in dt_FilteredModuleList.Rows)
                    {
                        ModuleList DataObj = new ModuleList();
                        DataObj.Mmid = dtRow["MMID"].ToString();
                        DataObj.Smid = dtRow["SMID"].ToString();
                        DataObj.Cmid = dtRow["CMID"].ToString() == "" ? "0" : dtRow["CMID"].ToString();
                        DataObj.CompanyId = dtRow["COMPANY_ID"].ToString();
                        DataObj.ModuleName = dtRow["Module Name"].ToString();
                        DataObj.SubmoduleName = dtRow["Submodule Name"].ToString();
                        DataObj.CalculationMethod = dtRow["Calculation Method"].ToString() == "" ? "-" : dtRow["Calculation Method"].ToString();
                        DataObj.CompanyName = dtRow["Company_Name"].ToString();
                        DataObj.DataBase_Name = dtRow["Company_Name"].ToString();
                        DataObj.Status = dtRow["Status"].ToString();
                        DataObj.DisplayMessage = s_DisplayMessage;
                        Detail.Add(DataObj);
                    }

                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
            return Detail.ToArray();
        }

        /// <summary>
        /// Button click event of Cancel button.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">event arguement e</param>
        protected void btnCC_AddCancel_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.BacktoSearch(this, true);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Click event of btnSearchPanel envoked when user clicks search accordian instead of cancel button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearchPanelClick_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    companyCreationModel.BacktoSearch(this, false);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyCreationModel companyCreationModel = new CompanyCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}