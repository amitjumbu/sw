﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Web.UI.WebControls;
using System.Net;
using System.Web;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// This is code behind class for ManageStockExchange page
    /// </summary>
    public partial class ManageStockExchange : BasePage
    {
        #region Declaration

        int n_ID = 0, n_index = 0, n_Action = 0, n_Delete = 0;

        #endregion

        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                    {
                        manageStockExchangeModel.PopulateAllControls(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageStockExchangeModel.userSessionInfo.ACC_CompanyName).Replace("*", manageStockExchangeModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events

        /// <summary>
        /// Button click event to save Stock Exchange details
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    manageStockExchangeModel.SaveStockExchangeDetails(this, string.IsNullOrEmpty(hdnID.Value) ? "C" : "U");
                    manageStockExchangeModel.BindSearchFilters(this);
                    manageStockExchangeModel.BindGridview(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageStockExchangeModel.userSessionInfo.ACC_CompanyName).Replace("*", manageStockExchangeModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to filter Stock Exchange Details
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnApplyFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    manageStockExchangeModel.BindGridview(this);
                    manageStockExchangeModel.ClearMessage(this);
                    manageStockExchangeModel.HideAddEditSection(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageStockExchangeModel.userSessionInfo.ACC_CompanyName).Replace("*", manageStockExchangeModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to Clear input fields
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    manageStockExchangeModel.ResetAllControls(this);
                    manageStockExchangeModel.ClearMessage(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageStockExchangeModel.userSessionInfo.ACC_CompanyName).Replace("*", manageStockExchangeModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to delete record
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnSEDeleteAll_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    manageStockExchangeModel.SaveStockExchangeDetails(this, "D");
                    manageStockExchangeModel.BindSearchFilters(this);
                    manageStockExchangeModel.BindGridview(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageStockExchangeModel.userSessionInfo.ACC_CompanyName).Replace("*", manageStockExchangeModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    manageStockExchangeModel.RowDataBindForGV(e, ref n_index, ref n_ID, ref n_Action, ref n_Delete);
                }
            }
            catch (Exception Ex)
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageStockExchangeModel.userSessionInfo.ACC_CompanyName).Replace("*", manageStockExchangeModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    manageStockExchangeModel.PageIndexChanging(e.NewPageIndex, this);
                    manageStockExchangeModel.ClearMessage(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageStockExchangeModel.userSessionInfo.ACC_CompanyName).Replace("*", manageStockExchangeModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// update link button click 
        /// </summary>
        public void lnkYes_Click()
        {
            try
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    manageStockExchangeModel.SaveStockExchangeDetails(this, "U");
                    manageStockExchangeModel.BindSearchFilters(this);
                    manageStockExchangeModel.BindGridview(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageStockExchangeModel manageStockExchangeModel = new ManageStockExchangeModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageStockExchangeModel.userSessionInfo.ACC_CompanyName).Replace("*", manageStockExchangeModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}