﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// This is code behind class for ManageCurrencies page.
    /// </summary>
    public partial class ManageCurrencies : BasePage
    {
        int n_index = 0, n_ID = 0, n_Delete = 0, n_Action = 0, n_DefCurrency = 0;

        /// <summary>
        /// This is page load event for ManageCurrencies.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">EventArgs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.Cache.SetNoStore();
                if (!Page.IsPostBack)
                {
                    using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                    {
                        currencyMasterModel.BindCurrencyDetailsGrid(this);
                        currencyMasterModel.BindCurrencyName(this);
                        currencyMasterModel.BindCurrencyAlias(this);
                        currencyMasterModel.ReadL10N_UI(this);
                        ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    }
                }
            }
            catch (Exception Ex)
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", currencyMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", currencyMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row bound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    currencyMasterModel.BindRows(e, ref n_index, ref n_ID, ref n_Delete, ref n_Action, ref n_DefCurrency);
                }
            }
            catch (Exception Ex)
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", currencyMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", currencyMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Apply Filters
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApplyFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    currencyMasterModel.BindCurrencyDetailsGrid(this);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", currencyMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", currencyMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Save records
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    currencyMasterModel.CUDCurrencyDetails(this);
                    currencyMasterModel.ResetGrid(this);
                    currencyMasterModel.BindCurrencyName(this);
                    currencyMasterModel.BindCurrencyAlias(this);
                    btnCRMClearFilter.Visible = false;
                }
            }
            catch (Exception Ex)
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", currencyMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", currencyMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Delete records
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    if (!string.IsNullOrEmpty(hdnDeletedRecords.Value))
                    {
                        currencyMasterModel.CUDCurrencyDetails(this);
                        currencyMasterModel.ResetGrid(this);
                        currencyMasterModel.BindCurrencyName(this);
                        currencyMasterModel.BindCurrencyAlias(this);
                        btnCRMClearFilter.Visible = false;
                    }
                    else
                    {
                        using (SuperAdminServiceClient obj_SuperAdminServiceClient = new SuperAdminServiceClient())
                        {
                            ctrSuccessErrorMessage.s_MessageText = obj_SuperAdminServiceClient.LoadL10N("lblCRMSelectRecords");
                            currencyMasterModel.BindCurrencyDetailsGrid(this);
                            currencyMasterModel.BindCurrencyName(this);
                            currencyMasterModel.BindCurrencyAlias(this);
                            ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", currencyMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", currencyMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Index change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    currencyMasterModel.PageIndexChanging(sender, e, gv, hdnDeletedRecords.Value);
                }
            }
            catch (Exception Ex)
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", currencyMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", currencyMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Reset Filters
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCMClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    currencyMasterModel.ResetGrid(this);
                    currencyMasterModel.BindCurrencyName(this);
                    currencyMasterModel.BindCurrencyAlias(this);
                    currencyMasterModel.ReadL10N_UI(this);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    btnCRMClearFilter.Visible = false;
                }
            }
            catch (Exception Ex)
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", currencyMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", currencyMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Reactive Currency Name
        /// </summary>
        public void lnkYes_Click()
        {
            try
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    currencyMasterModel.ReactivateCurrencyDetails(this);
                    currencyMasterModel.ResetGrid(this);
                    currencyMasterModel.BindCurrencyName(this);
                    currencyMasterModel.BindCurrencyAlias(this);
                    btnCRMClearFilter.Visible = false;
                }
            }
            catch (Exception Ex)
            {
                using (CurrencyMasterModel currencyMasterModel = new CurrencyMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", currencyMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", currencyMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}