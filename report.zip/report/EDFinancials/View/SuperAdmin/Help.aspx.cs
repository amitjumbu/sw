﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// partial class Help
    /// </summary>
    public partial class Help : BasePage
    {
        int n_isDeleted = 0, n_oisDeleted = 0, n_oIndex = 0, n_oFileName = 0, n_oAction = 0;

        /// <summary>
        /// The Page Load Event
        /// </summary>
        /// <param name="sender">Help Page</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (HelpModel helpModel = new HelpModel())
                    {
                        helpModel.BindUI(this);

                        helpModel.BindPageDropDown(this);

                        helpModel.GetPageNames(this);

                        helpModel.BindPageWiseGrid(this);

                        helpModel.BindOthersGrid(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Upload of All Files
        /// </summary>
        /// <param name="sender">Button(s) btnPageWiseUpload and btnFileOthersUpload</param>
        /// <param name="e">e</param>
        protected void btnFileOthersUpload_Click(object sender, EventArgs e)
        {
            try
            {
                switch (Convert.ToString(((Button)sender).ID))
                {
                    case "btnPageWiseUpload":
                        if (n_isDeleted == 0 && hdnErrorUpload.Value.Equals("0"))
                        {
                            string s_MainFolderPath = Server.MapPath("../../HelpDocs/");

                            using (HelpModel helpModel = new HelpModel())
                            {
                                helpModel.FileUploadPageWise_UploadedComplete(this, s_MainFolderPath);
                            }
                        }
                        hdnErrorUpload.Value = "0";
                        break;

                    case "btnFileOthersUpload":
                        if (n_oisDeleted == 0 && o_hdnErrorUpload.Value.Equals("0"))
                        {
                            string s_MainFolderPath = Server.MapPath("../../HelpDocs/");

                            using (HelpModel helpModel = new HelpModel())
                            {
                                helpModel.FileUploadOthers_UploadedComplete(this, s_MainFolderPath);
                            }
                        }
                        o_hdnErrorUpload.Value = "0";
                        break;
                }

            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Remove File After Upload 
        /// </summary>
        /// <param name="sender">Remove LinkButton</param>
        /// <param name="e">e</param>
        protected void lnkbtnFileRemove_Click(object sender, EventArgs e)
        {
            try
            {
                string s_MainFolderPath = Server.MapPath("..//..//HelpDocs//");

                using (HelpModel helpModel = new HelpModel())
                {
                    n_isDeleted = helpModel.lnkbtnFileRemove_Click(this, s_MainFolderPath);
                }
            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  The GridView gvPageWise RowBound Event
        /// </summary>
        /// <param name="sender">GridView gvPageWise</param>
        /// <param name="e">e</param>
        protected void gvPageWise_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    helpModel.gvPageWise_RowDataBound(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The GridView gvPageWise Delete Event
        /// </summary>
        /// <param name="sender">GridView gvPageWise</param>
        /// <param name="e">e</param>
        protected void gvPageWise_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                string s_MainFolderPath = Server.MapPath("..//..//HelpDocs//");

                using (HelpModel helpModel = new HelpModel())
                {
                    helpModel.gvPageWise_RowDeleting(this, e, s_MainFolderPath);
                }
            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The GridView gv RowBound Event
        /// </summary>
        /// <param name="sender">GridView gv</param>
        /// <param name="e">e</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    helpModel.gv_RowDataBound(e, ref n_oIndex, ref n_oFileName, ref n_oAction);
                }
            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The GridView gv Delete Event
        /// </summary>
        /// <param name="sender">GridView gv</param>
        /// <param name="e">e</param>
        protected void gv_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                string s_MainFolderPath = Server.MapPath("..//..//HelpDocs//");

                using (HelpModel helpModel = new HelpModel())
                {
                    helpModel.gv_RowDeleting(this, e, s_MainFolderPath);
                }
            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This will Save File(s) to database
        /// </summary>
        /// <param name="sender">Save Button</param>
        /// <param name="e">e</param>
        protected void btnHelpSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    helpModel.btnHelpSave_Click(this);

                    helpModel.ClearAllTable(this);

                    helpModel.BindPageDropDown(this);

                    helpModel.BindPageWiseGrid(this);

                    helpModel.BindOthersGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Dropdown ddlHelpSelectPage Index change event
        /// </summary>
        /// <param name="sender">Dropdown ddlHelpSelectPage</param>
        /// <param name="e">e</param>
        protected void ddlHelpSelectPage_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    helpModel.ddlHelpSelectPage_SelectedIndexChanged(this);
                }
            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Page index change event of gvPageWise GridView
        /// </summary>
        /// <param name="sender">gvPageWise GridView</param>
        /// <param name="e">e</param>
        protected void gvPageWise_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    helpModel.gvPageWise_PageIndexChanging(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Page index change event of gv GridView
        /// </summary>
        /// <param name="sender">gv GridView</param>
        /// <param name="e">e</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    helpModel.gv_PageIndexChanging(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (HelpModel helpModel = new HelpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpModel.userSessionInfo.ACC_CompanyName).Replace("*", helpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}