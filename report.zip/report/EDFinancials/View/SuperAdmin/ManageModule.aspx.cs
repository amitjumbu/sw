﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// Code behind page for Manage Module.aspx
    /// </summary>
    public partial class Manage_Module : BasePage
    {
        int n_index = 0, n_ID = 0, n_Delete = 0, n_Action = 0;

        /// <summary>
        /// Page load method for Manage Module page
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                    {
                        manageModuleModel.BindPageUI(this);
                        loadIsActiveDropDown();
                        loadMasterGrid();
                    }

                }
                catch (Exception Ex)
                {
                    using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>

        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl)
        {
            using (ImageButton img = new ImageButton())
            {
                img.ImageUrl = s_strUrl;
                img.ToolTip = s_strToolTip;
                img.Style.Add("cursor", "pointer");
                return img;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">Sender's Id</param>
        /// <param name="e">Gridview Row Id</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {

                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    manageModuleModel.BindRows(e, ref n_index, ref n_ID, ref n_Delete, ref n_Action);

                }
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD  IS USED  FOR CHANGING GRIDVIEW PAGE NUMBER.
        /// </summary>
        /// <param name="sender">Sender's Id</param>
        /// <param name="e">Gridview Event Argument</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    manageModuleModel.PageIndexChanging(sender, e, gv, hdnDeletedRecords.Value);
                    updGridView.Update();
                }
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD LOADS IS CONTENTS OF ISACTIVE DROPDOWNLIST 
        /// </summary>
        public void loadIsActiveDropDown()
        {
            try
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    manageModuleModel.Load_ddIsactive(ddIsActive, "S");
                    manageModuleModel.Load_ddIsactive(ddCreatenew_IsActive, "SE");
                }
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD LOADS GRID VIEW DATA
        /// </summary>
        public void loadMasterGrid()
        {
            try
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    manageModuleModel.LoadGridData(this, "R");
                    manageModuleModel.loadModuleNameDropdown(ddModuleName);
                }
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// FILTERS DATA FROM GRID VIEW ACCORDING TO FILTER MODULE NAME AND ITS STATUS.
        /// </summary>
        /// <param name="sender">seder's Id</param>
        /// <param name="e">Event Argument</param>
        protected void BtnGridfilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    manageModuleModel.FilterGridData(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD PERFORMS DELETE OPERATION for particular records in dataabse. 
        /// </summary>
        public void DeletegridviewRow()
        {
            try
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    manageModuleModel.CRUDManageModuleDetails(this, hdnDeletedRecords.Value.TrimStart(','), "D");
                    loadMasterGrid();
                }
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to Delete records on from Manage Module PAge.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event</param>
        protected void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (hdnDeletedRecords.Value != "")
                    DeletegridviewRow();
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to insert new records to database
        /// </summary>
        /// <param name="sender">sender's Id</param>
        /// <param name="e">Event</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                switch (Convert.ToInt32(hdnBtnID.Value))
                {
                    case 0:
                        CUD("C");
                        break;
                    case 1:
                        CUD("U");
                        break;
                }
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD PERFORMS CREATE / UPDATE OPERATIONS IN DATABASE.
        /// </summary>
        /// <param name="s_Action">This parameters defines the action to be performed: "C- Create , U- Update, D-Delete"</param>
        public void CUD(string s_Action)
        {
            try
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    manageModuleModel.CRUDManageModuleDetails(this, hdnEditMmId.Value.TrimStart(','), s_Action);
                    loadMasterGrid();
                }
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to clear filter on gridview.
        /// </summary>
        /// <param name="sender">Button's sender Id</param>
        /// <param name="e">Event</param>
        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    manageModuleModel.LoadGridData(this, "R");
                    btnClearFilter.Visible = false;
                    ddModuleName.SelectedIndex = -1;
                    ddIsActive.SelectedIndex = 0;
                }
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method updates the deleted status of module to zero whose id will be passed, when clicked on the lnkyes button.
        /// </summary>
        public void lnkYes_Click()
        {
            try
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    manageModuleModel.ReverseDeletedRecord(this);
                    loadMasterGrid();
                }
            }
            catch (Exception Ex)
            {
                using (ManageModuleModel manageModuleModel = new ManageModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}