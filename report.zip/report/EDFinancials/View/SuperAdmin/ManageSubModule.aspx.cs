﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// Code Behind Page for ManageSubModule.aspx
    /// </summary>
    public partial class ManageSubmodule : BasePage
    {
        int n_index = 0, n_ID = 0, n_Delete = 0, n_Action = 0;

        /// <summary>
        /// Page Load event for Manage sub Module Page .
        /// </summary>
        /// <param name="sender">sender Id</param>
        /// <param name="e">Event</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                    {
                        manageSubModuleModel.BindPageUI(this);
                        loadIsActiveDropDown();
                        loadMasterGrid();

                    }
                }
                catch (Exception Ex)
                {
                    using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }
        }

        /// <summary>
        /// this method is used to perform gridview row vise action
        /// </summary>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    manageSubModuleModel.BindRows(e, ref n_index, ref n_ID, ref n_Delete, ref n_Action);
                }
            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD  IS USED  FOR CHANGING GRIDVIEW PAGE NUMBER
        /// </summary>
        /// <param name="sender">Sender Id</param>
        /// <param name="e">Event</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    manageSubModuleModel.PageIndexChanging(sender, e, gv, hdnDeletedRecords.Value);
                    updGridView.Update();
                }
            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD LOADS IS CONTENTS OF ISACTIVE DROPDOWNLIST 
        /// </summary>
        public void loadIsActiveDropDown()
        {
            try
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    manageSubModuleModel.Load_ddIsactive(ddIsActive, "S");
                    manageSubModuleModel.Load_ddIsactive(ddCreatenewIsActive, "SE");
                }
            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD LOADS GRID VIEW DATA
        /// </summary>
        public void loadMasterGrid()
        {
            try
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    manageSubModuleModel.LoadGridData(this, "R");
                    manageSubModuleModel.loadModuleNameDropdown(ddSModuleName);
                }
            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD FILTERS DATA FROM GRID VIEW ACCORDING TO FILTER MODULE NAME AND ITS STATUS.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event</param>
        protected void BtnGridfilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    manageSubModuleModel.FilterGridData(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD PERFORMS DELETE OPERATION IN DATABASE
        /// </summary>
        public void DeletegridviewRow()
        {
            try
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    manageSubModuleModel.PerformCUD(this, hdnDeletedRecords.Value.TrimStart(','), "D");
                    loadMasterGrid();
                }
            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to Delete records from page.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event</param>
        protected void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(hdnDeletedRecords.Value))
                    DeletegridviewRow();
            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to Insert records.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                switch (Convert.ToInt32(hdnBtnID.Value))
                {
                    case 0:
                        CUD("C");
                        break;
                    case 1:
                        CUD("U");
                        break;
                }
            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD PERFORMS CREATE / UPDATE OPERATIONS IN DATABASE.
        /// </summary>
        /// <param name="s_Action"></param>
        public void CUD(string s_Action)
        {
            try
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    manageSubModuleModel.PerformCUD(this, hdnEditMmId.Value.TrimStart(','), s_Action);
                    loadMasterGrid();
                }

            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to Clear filter on Gridview.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event</param>
        protected void btnSMClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    manageSubModuleModel.LoadGridData(this, "R");
                    btnSMClearFilter.Visible = false;
                    ddSModuleName.SelectedIndex = -1;
                    ddIsActive.SelectedIndex = 0;
                }
            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This updates/reverts back the delete status of particular submodule whose id is given further.
        /// </summary>
        public void lnkYes_Click()
        {
            try
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    manageSubModuleModel.ReverseDeletedRecord(this);
                    loadMasterGrid();
                }
            }
            catch (Exception Ex)
            {
                using (ManageSubModuleModel manageSubModuleModel = new ManageSubModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageSubModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", manageSubModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}