﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Collections.Generic;
using System.Web.Services;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// This is code bend class for Status Report page.
    /// </summary>
    public partial class StatusReport : BasePage
    {
        /// <summary>
        /// 
        /// </summary>
        int n_index = 0, n_CompanyName = 0, n_GroupNumber = 0, n_Status_of_Report = 0, n_Pending_Stage = 0, n_Associated_Users = 0, n_Associated_Modules = 0;

        #region PageLoad
        /// <summary>
        /// Page load event for Status Report page.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">EventArgs</param>        
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (StatusReportModel statusReportModel = new StatusReportModel())
                    {
                        statusReportModel.BindUI(this);

                        statusReportModel.BindStatus(this);

                        statusReportModel.GetValStatusReportList(this);

                        statusReportModel.GetValuesFromDatabase(this);

                        statusReportModel.GetAccStatusReportList(this);

                        statusReportModel.EncryptData(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Search/ Apply Fiter and Clear Filter
        /// <summary>
        /// This method is used for search status
        /// </summary>
        /// <param name="sender">Search/Apply Filter Button</param>
        /// <param name="e">e</param>         
        protected void btnSearchStatus_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.GV_Filter(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear fields
        /// </summary>
        /// <param name="sender">Clear Filter Button</param>
        /// <param name="e">e</param>
        protected void btnResetStatus_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.DisplayContents(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }

            }
        }

        /// <summary>
        /// Check All checkBoxes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chckchanged(object sender, EventArgs e)
        {
            using (StatusReportModel statusReportModel = new StatusReportModel())
            {
                statusReportModel.ChkedChkBox(this);
            }
        }

        /// <summary>
        /// Check All checkBoxes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chckAccchanged(object sender, EventArgs e)
        {
            using (StatusReportModel statusReportModel = new StatusReportModel())
            {
                statusReportModel.ChkedAccChkBox(this);
            }
        }
        #endregion

        #region Valuation Search/ Apply Fiter and Clear Filter
        /// <summary>
        /// This method is used for search status
        /// </summary>
        /// <param name="sender">Search/Apply Filter Button</param>
        /// <param name="e">e</param>         
        protected void btnSearchValStatus_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.GV_Valuation_Filter(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear fields
        /// </summary>
        /// <param name="sender">Clear Filter Button</param>
        /// <param name="e">e</param>
        protected void btnResetValStatus_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.DisplayContents(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }

            }
        }
        #endregion

        #region Accounting Search/ Apply Fiter and Clear Filter
        /// <summary>
        /// This method is used for search status
        /// </summary>
        /// <param name="sender">Search/Apply Filter Button</param>
        /// <param name="e">e</param>         
        protected void btnSearchAccStatus_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.GV_Accounting_Filter(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear fields
        /// </summary>
        /// <param name="sender">Clear Filter Button</param>
        /// <param name="e">e</param>
        protected void btnResetAccStatus_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.DisplayContents(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }

            }
        }
        #endregion

        #region Bind Company List
        /// <summary>
        /// Bind Compnay List
        /// </summary>
        /// <param name="company">company</param>
        /// <returns></returns>
        [WebMethod]
        public static List<string> BindCompnyList(object company)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    return statusReportModel.BindSRCompnyList(Convert.ToString(company));
                }
            }
            catch (Exception)
            {
                return new List<string>();
            }
        }
        #endregion

        #region Bind Valuation Company List
        /// <summary>
        /// Bind Valuation Compnay List
        /// </summary>
        /// <param name="company">company</param>
        /// <returns></returns>
        [WebMethod]
        public static List<string> BindValCompnyList(object company)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    return statusReportModel.BindValCompnyList(Convert.ToString(company));
                }
            }
            catch (Exception)
            {
                return new List<string>();
            }
        }
        #endregion

        #region Bind Accounting Company List
        /// <summary>
        /// Bind Valuation Compnay List
        /// </summary>
        /// <param name="company">company</param>
        /// <returns></returns>
        [WebMethod]
        public static List<string> BindAccCompnyList(object company)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    return statusReportModel.BindAccCompnyList(Convert.ToString(company));
                }
            }
            catch (Exception)
            {
                return new List<string>();
            }
        }
        #endregion

        #region Data Row is Bound
        /// <summary>
        /// This method is used to bind data to the grid at pageload
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void grd_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.grd_RowDataBound(sender, this, e);
                }
            }

            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region RowDataBound Of Status Valuation Report GridView
        /// <summary>
        /// This method is used to bind data to the grid at pageload
        /// </summary>
        /// <param name="sender">Status Valuation Report Grid</param>
        /// <param name="e">e</param>
        protected void GV_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.GVVal_RowDataBound(sender, e, ref n_index, ref n_CompanyName, ref n_GroupNumber, ref n_Status_of_Report, ref n_Pending_Stage, ref n_Associated_Users, ref n_Associated_Modules);
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region RowDataBound Of Status Accounting Report GridView
        /// <summary>
        /// This method is used to bind data to the grid at pageload
        /// </summary>
        /// <param name="sender">Status Accounting Report Grid</param>
        /// <param name="e">e</param>
        protected void GVAcc_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.GVAcc_RowDataBound(sender, e, ref n_index, ref n_CompanyName, ref n_Status_of_Report, ref n_Pending_Stage, ref n_Associated_Users, ref n_Associated_Modules);
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Status Report Gridview Page Index Change Event
        /// <summary>
        /// The Row DataBound Event of gvViewDocument GridView
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void lnkPage_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    string pageIndex = (sender as LinkButton).CommandArgument;

                    statusReportModel.Page_IndexChangeing(this, pageIndex);
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString(Ex.Message + "\n" + Ex.StackTrace));
            }
        }

        /// <summary>
        /// The Row DataBound Event of gvViewDocument GridView
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void lnkValPage_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    string pageIndex = (sender as LinkButton).CommandArgument;

                    statusReportModel.PageVal_IndexChangeing(this, pageIndex);
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString(Ex.Message + "\n" + Ex.StackTrace));
            }
        }

        /// <summary>
        /// The Row DataBound Event of gvViewDocument GridView
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void lnkAccPage_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    string pageIndex = (sender as LinkButton).CommandArgument;

                    statusReportModel.PageAcc_IndexChangeing(this, pageIndex);
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString(Ex.Message + "\n" + Ex.StackTrace));
            }
        }

        /// <summary>
        ///  LinkButton Fillter For Valuation and Accounting
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void lnkVal_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                using (StatusReportModel statusreportmodel = new StatusReportModel())
                {
                    statusreportmodel.lnkVal_RowCommand(this, e);
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region Back Button of Valuation
        /// <summary>
        /// Back Button event of Valuation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnValBack_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.Btn_ValBack(this);
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }


        /// <summary>
        /// Back Button event of Accounting
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAccBack_Click(object sender, EventArgs e)
        {
            try
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    statusReportModel.Btn_AccBack(this);
                }
            }
            catch (Exception Ex)
            {
                using (StatusReportModel statusReportModel = new StatusReportModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", statusReportModel.userSessionInfo.ACC_CompanyName).Replace("*", statusReportModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Send Mails
        /// <summary>
        /// Send  Mails to users
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="s_TemplateName"></param>
        protected void SendValMailToUser(object sender, object s_TemplateName)
        {
            using (StatusReportModel statusReportModel = new StatusReportModel())
            {
                statusReportModel.SendMail(this, sender);
            }
        }

        /// <summary>
        /// Send  Mails to users
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="s_TemplateName"></param>
        protected void SendAccMailToUser(object sender, object s_TemplateName)
        {
            using (StatusReportModel statusReportModel = new StatusReportModel())
            {
                statusReportModel.SendMail(this, sender);
            }
        }
        #endregion   
    }
}