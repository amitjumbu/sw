﻿using EDFinancials.Model;
using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Configuration;
using System.IO;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// This is code bend class for ManageAdminUsers page.
    /// </summary>
    public partial class ManageAdminUsers : BasePage
    {
        int n_Action = 0, n_index = 0, n_EmailID = 0, n_UMID = 0, n_CompanyName = 0, n_IsActive = 0, n_Loginid = 0, n_dbName = 0, n_isDeleted = 0;
        EDFinancialsException Ex = null;

        #region Page Load
        /// <summary>
        /// Page load event for ManageAdminUsers page.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">EventArgs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                    {
                        manageAdminUsersModel.BindUI(this);

                        manageAdminUsersModel.BindCompanyList(this);

                        manageAdminUsersModel.GetAdminUsersList(this);

                        manageAdminUsersModel.DisplayContents(this, "", Ex);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageAdminUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageAdminUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Search/ Apply Fiter and Clear Filter
        /// <summary>
        /// This method is used for apply filter 
        /// </summary>
        /// <param name="sender">Search/Apply Filter Button</param>
        /// <param name="e">e</param>
        protected void btnMAUApplyFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.GetAdminUsersList(this);

                    manageAdminUsersModel.DisplayContents(this, "btnMAUApplyFilter", Ex);
                }
            }
            catch (Exception Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageAdminUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageAdminUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear fields
        /// </summary>
        /// <param name="sender">Clear Filter Button</param>
        /// <param name="e">e</param>
        protected void btnMAUClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.BindCompanyList(this);

                    manageAdminUsersModel.GetAdminUsersList(this);

                    manageAdminUsersModel.DisplayContents(this, "", Ex);
                }
            }
            catch (Exception Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageAdminUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageAdminUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Save and Update Admin Mail
        /// <summary>
        /// This method is used to save and update admin e-mail ID
        /// </summary>
        /// <param name="sender">Save Admin Mail Button</param>
        /// <param name="e">e</param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.UpdateAdminMail(this, "U", hdnCompanyName.Value);

                    manageAdminUsersModel.BindCompanyList(this);

                    manageAdminUsersModel.DisplayContents(this, "", Ex);
                }
            }
            catch (Exception Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageAdminUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageAdminUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
            finally
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.BindCompanyList(this);

                    manageAdminUsersModel.GetAdminUsersList(this);
                }
            }
        }
        #endregion

        #region Save and Reset Admin Password
        /// <summary>
        /// This method is used to Save and Reset Admin  Password
        /// </summary>
        /// <param name="sender">Save Password Button</param>
        /// <param name="e">e</param>
        protected void btnSavepwd_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.ResetAdminPassword(hdnCompanyName.Value, txtMAUConfirmPassword.Text, "", "", "", "");

                    manageAdminUsersModel.BindCompanyList(this);

                    manageAdminUsersModel.DisplayContents(this, "", Ex);
                }
            }
            catch (EDFinancialsException Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.BindCompanyList(this);

                    manageAdminUsersModel.GetAdminUsersList(this);

                    manageAdminUsersModel.DisplayContents(this, "btnSavepwdException", Ex);
                }
            }
        }
        #endregion

        #region Save and Reset Admin APssword and Send Mail
        /// <summary>
        /// This Method is used to Save and Send the  Mail of Changed Password 
        /// </summary>
        /// <param name="sender">Save Password and Send Mail Button</param>
        /// <param name="e">e</param>
        protected void btnMAUSaveSendMail_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.ResetAdminPassword(hdnCompanyName.Value, txtMAUConfirmPassword.Text, File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"Mails\ResetPassword.html"), hdnUserName.Value, hdnEmailID.Value, hdnLoginID.Value);

                    manageAdminUsersModel.BindCompanyList(this);

                    manageAdminUsersModel.DisplayContents(this, "", Ex);
                }
            }
            catch (EDFinancialsException Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.BindCompanyList(this);

                    manageAdminUsersModel.GetAdminUsersList(this);

                    manageAdminUsersModel.DisplayContents(this, "btnSavepwdException", Ex);
                }
            }
        }
        #endregion

        #region RowDataBound Of Manage Admin Users GridView
        /// <summary>
        /// This method is used to bind data to the grid at pageload
        /// </summary>
        /// <param name="sender">Manage Admin Users Grid</param>
        /// <param name="e">e</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ManageAdminUsersModel manageadminusers = new ManageAdminUsersModel())
                {
                    manageadminusers.RowDataBound(sender, e, ref n_Action, ref n_EmailID, ref n_index, ref n_UMID, ref n_CompanyName, ref n_IsActive, ref n_Loginid, ref n_dbName, ref n_isDeleted);
                }
            }
            catch (Exception Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageAdminUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageAdminUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Page Index Change Event Of Manage Admin Users GridView
        /// <summary>
        /// This is page index changing method resposible to change pages in gridview.
        /// </summary>
        /// <param name="sender">GridView gv</param>
        /// <param name="e">e</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.gv_PageIndexChanging(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageAdminUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageAdminUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region View History
        /// <summary>
        /// This Method is used to View History Of Mail In PopUp Div
        /// </summary>
        /// <param name="sender">btnMAUViewHistory</param>
        /// <param name="e">e</param>
        protected void btnMAUViewHistory_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.btnMAUViewHistory_Click(this);

                    manageAdminUsersModel.GetAdminUsersList(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageAdminUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageAdminUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region RowDataBound Of gvViewHistory GridView
        /// <summary>
        /// The Row Bound Event Of gvViewHistory GridView
        /// </summary>
        /// <param name="sender">gvViewHistory GridView</param>
        /// <param name="e">e</param>
        protected void gvViewHistory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.gvViewHistory_RowDataBound(e);
                }
            }
            catch (Exception Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageAdminUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageAdminUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Page Index Change Event Of gvViewHistory GridView
        /// <summary>
        /// Page index change event of gvViewHistory GridView
        /// </summary>
        /// <param name="sender">gvViewHistory GridView</param>
        /// <param name="e">e</param>
        protected void gvViewHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    manageAdminUsersModel.gvViewHistory_PageIndexChanging(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (ManageAdminUsersModel manageAdminUsersModel = new ManageAdminUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageAdminUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageAdminUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}