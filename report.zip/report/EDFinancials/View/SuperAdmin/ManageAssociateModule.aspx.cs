﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// Code behind file for AssociateModule Page
    /// </summary>
    public partial class AssociateModule : BasePage
    {

        int n_index = 0, n_ID = 0, n_Delete = 0, n_Action = 0;

        /// <summary>
        /// Page load method for AssociateModule
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                    {
                        associateModuleModel.BindPageUI(this);
                        loadIsAllDropDown();
                        loadMasterGrid();
                    }

                }
                catch (Exception Ex)
                {
                    using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }
        }


        /// <summary>
        /// This method calls the method that is resposible to bind the gridview row and columns
        /// </summary>
        /// <param name="sender">Sender's Id</param>
        /// <param name="e">Gridview Row Id</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    associateModuleModel.BindRows(e, ref n_index, ref n_ID, ref n_Delete, ref n_Action);
                }
            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD  IS USED  FOR CHANGING GRIDVIEW PAGE NUMBER.
        /// </summary>
        /// <param name="sender">Sender's Id</param>
        /// <param name="e">Gridview Event Argument</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    associateModuleModel.PageIndexChanging(sender, e, gv, hdnDeletedRecords.Value);
                    updGridView.Update();
                }
            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD calls the method of model that Loads  contentsof all the dropdownlist one by one
        /// </summary>
        public void loadIsAllDropDown()
        {
            try
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    associateModuleModel.LoadDropdownLists(ddIsActive, "S", "DATA", "VALUE");
                    associateModuleModel.LoadDropdownLists(ddIsActiveEdit, "SE", "DATA", "VALUE");
                    associateModuleModel.LoadDropdownLists(ddAMMMName, "EML", "MODULE_NAME", "MMID");
                    associateModuleModel.LoadDropdownLists(ddAMSName, "SSL", "SUB_MODULE_NAME", "SMID");
                    associateModuleModel.LoadDropdownLists(ddAMSMName, "ESL", "SUB_MODULE_NAME", "SMID");
                }
            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD LOADS GRID VIEW DATA
        /// </summary>
        public void loadMasterGrid()
        {
            try
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    associateModuleModel.LoadGridData(this, "MAL");
                    associateModuleModel.loadModuleNameDropdown(ddModuleName);
                }
            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// FILTERS DATA FROM GRID VIEW ACCORDING TO FILTER MODULE NAME AND ITS STATUS.
        /// </summary>
        /// <param name="sender">seder's Id</param>
        /// <param name="e">Event Argument</param>
        protected void BtnGridfilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    associateModuleModel.filterGridData(this);
                }

            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD PERFORMS DELETE OPERATION for particular records in dataabse. 
        /// </summary>
        public void DeletegridviewRow()
        {
            try
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    associateModuleModel.PerformCUD(this, hdnDeletedRecords.Value.TrimStart(','), "D");
                    loadMasterGrid();
                }
            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to Delete records.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event</param>
        protected void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (hdnDeletedRecords.Value != "")
                    DeletegridviewRow();
            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to insert new records to database
        /// </summary>
        /// <param name="sender">sender's Id</param>
        /// <param name="e">Event</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                switch (Convert.ToInt32(hdnBtnID.Value))
                {
                    case 0:
                        CUD("C");
                        break;
                    case 1:
                        CUD("U");
                        break;
                }
            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD PERFORMS CREATE / UPDATE OPERATIONS IN DATABASE.
        /// </summary>
        /// <param name="s_Action">This parameters defines the action to be performed: "C- Create , U- Update, D-Delete"</param>
        public void CUD(string s_Action)
        {
            try
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    associateModuleModel.PerformCUD(this, hdnEditMmId.Value.TrimStart(','), s_Action);
                    loadMasterGrid();
                }
            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to clear filter on gridview.
        /// </summary>
        /// <param name="sender">Button's sender Id</param>
        /// <param name="e">Event</param>
        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    associateModuleModel.ClearGridFilter(this);
                }
            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method updates the deleted status of module to zero whose id will be passed, when clicked on the lnkyes button.
        /// </summary>
        public void lnkYes_Click()
        {
            try
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    associateModuleModel.ReverseDeletedRecord(this);
                    loadMasterGrid();
                }
            }
            catch (Exception Ex)
            {
                using (AssociateModuleModel associateModuleModel = new AssociateModuleModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", associateModuleModel.userSessionInfo.ACC_CompanyName).Replace("*", associateModuleModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}