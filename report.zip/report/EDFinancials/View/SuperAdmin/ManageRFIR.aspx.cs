﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Net;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// This is code behind class for ManageRFIR page
    /// </summary>
    public partial class ManageRFIR : BasePage
    {
        #region Declaration

        int n_ID = 0, n_index = 0, n_Action = 0, n_Delete = 0;

        #endregion

        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                    {
                        manageRFIRModel.PopulateAllControls(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRFIRModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRFIRModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        #endregion

        #region Control Events

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    manageRFIRModel.RowDataBindForGV(e, ref n_index, ref n_ID, ref n_Action, ref n_Delete, ddlRFIRCountryList.SelectedItem.Value.ToUpper().Equals("INDIA"));
                }
            }
            catch (Exception Ex)
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRFIRModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRFIRModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Download button click event to download RFIR file from server drive
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnRFIRDownload_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    manageRFIRModel.DownloadFile(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRFIRModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRFIRModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to delete RFIR details from table ACC_RFIR_DETAILS
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnRFIRDeleteAll_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    manageRFIRModel.SaveRFIRDetails(this, "D");
                    manageRFIRModel.BindGridview(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRFIRModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRFIRModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// button apply filter click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnRFIRApplyFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    manageRFIRModel.BindGridview(this);
                    manageRFIRModel.ClearMessage(this);
                    manageRFIRModel.HideAddEditSection(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRFIRModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRFIRModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    manageRFIRModel.PageIndexChanging(e.NewPageIndex, this);
                    manageRFIRModel.ClearMessage(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRFIRModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRFIRModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to clear input filters
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnRFIRClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    manageRFIRModel.ResetAllControls(this);
                    manageRFIRModel.ClearMessage(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRFIRModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRFIRModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Country dropdown selected index changed event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void ddlRFIRCountryList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    manageRFIRModel.ShowHideSections(this);
                    manageRFIRModel.ClearMessage(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRFIRModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRFIRModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to save RFIR details
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnRFIRSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    manageRFIRModel.SaveRFIRDetails(this, string.IsNullOrEmpty(hdnID.Value) ? "C" : "U");
                    manageRFIRModel.BindGridview(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRFIRModel manageRFIRModel = new ManageRFIRModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRFIRModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRFIRModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}