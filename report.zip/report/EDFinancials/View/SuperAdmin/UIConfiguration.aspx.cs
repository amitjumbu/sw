﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.SuperAdmin
{
    /// <summary>
    /// This is code bend class for UIConfiguration page.
    /// </summary>
    public partial class UIConfiguration : BasePage
    {
        int n_index = 0, n_ID = 0, n_Delete = 0, n_Action = 0, n_ControlType = 0, n_LabelName = 0, n_LabelToolTip = 0, n_ErrorText = 0, n_ErrorText2 = 0;
        /// <summary>
        /// Page load event for UIConfiguration page.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">EventArgs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                    {
                        configureUIModel.BindL10N_UI(this);
                        configureUIModel.BindNullGrid(this);
                        configureUIModel.BindFileNameDropdown(this);
                        configureUIModel.BindPageNameDropdown(this);
                        configureUIModel.BindControlUITypeDropdown(this);
                        ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", configureUIModel.userSessionInfo.ACC_CompanyName).Replace("*", configureUIModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Bind file names by using stored procedure 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlCUIFileName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    configureUIModel.BindPageNameDropdown(this);
                    configureUIModel.BindNullGrid(this);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", configureUIModel.userSessionInfo.ACC_CompanyName).Replace("*", configureUIModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Bind Page names by using stored procedure
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlCUIPageName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    configureUIModel.BindControlUITypeDropdown(this);
                    configureUIModel.BindNullGrid(this);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", configureUIModel.userSessionInfo.ACC_CompanyName).Replace("*", configureUIModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Bind gridview according to selected page name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApplyFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    configureUIModel.BindGrid(this);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", configureUIModel.userSessionInfo.ACC_CompanyName).Replace("*", configureUIModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Clear applied filters
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCUIClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    configureUIModel.BindL10N_UI(this);
                    configureUIModel.BindNullGrid(this);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    configureUIModel.BindNullPageNameDDL(this);
                    configureUIModel.BindFileNameDropdown(this);
                    configureUIModel.BindPageNameDropdown(this);
                    configureUIModel.BindControlUITypeDropdown(this);
                }
            }
            catch (Exception Ex)
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", configureUIModel.userSessionInfo.ACC_CompanyName).Replace("*", configureUIModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Update record
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCUISave_Click(object sender, EventArgs e)
        {
            try
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    configureUIModel.RenameLabelNames(this);
                    configureUIModel.BindGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", configureUIModel.userSessionInfo.ACC_CompanyName).Replace("*", configureUIModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Bind Rows
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">GridViewRowEventArgs</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    configureUIModel.BindRows(e, ref n_index, ref n_ID, ref n_Delete, ref n_Action, ref n_ControlType, ref n_LabelName, ref n_LabelToolTip, ref n_ErrorText, ref n_ErrorText2);
                }
            }
            catch (Exception Ex)
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", configureUIModel.userSessionInfo.ACC_CompanyName).Replace("*", configureUIModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Index change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    configureUIModel.PageIndexChanging(sender, e, gv);
                }
            }
            catch (Exception Ex)
            {
                using (ConfigureUIModel configureUIModel = new ConfigureUIModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", configureUIModel.userSessionInfo.ACC_CompanyName).Replace("*", configureUIModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}