﻿function pageLoad() {
    LoadScript();

    $('html').bind('keypress', function (e) {
        if (e.keyCode == 13) {
            return false;
        }
    });

    if ($("#hdnGDPageName").val() == 'AccountingReport') {
        $(".header").hide();
        $(".menuRow").hide();
        $(".lftMenu").hide();
        $(".footerMsg").hide();
        $(".container").removeAttr("style");
        $(".trGDHeader").hide();
        $(".container").attr("style", "width:100%;");
        $("#h4SearchPanel").hide();
        $("#btnAddGrantSaveContinue").hide();
        $("#hdnAccordionIndex").val("1");
        $("#hdnTabActiveIndex").val("0");
        $($("#tabs").find("li")[1]).hide()
        $($("#tabs").find("li")[2]).hide()
        $($("#tabs").find("li")[3]).hide()
        $("#btnGDReset").hide();
        $("#ctl00_MainContent_EmployeeAssociationUC_hlRedirectEmpMaster").hide();
        $("#ctl00_MainContent_EmployeeAssociationUC_hlRefreash").hide();
        $("#btnAddGrantPopulateVestDetails").hide();
        $("#btnAddGrantCancel").hide();
    }

    $("#closebtnOD").click(function () {
        $("#PopupMainContentDivOD").hide('500', "swing", function () { $("#PopupBackgroundDivOD").fadeOut("300"); });
    });

    jQuery('#accordion').css('display', 'block');

    if ($(this).is(":checked")) {
        document.getElementById("regExpExercisePeriod").validationGroup = "Populate1";
        document.getElementById("reqFldExercisePeriod").validationGroup = "Populate1";
        document.getElementById("reqFldExPrcFirst").validationGroup = "Populate";
        document.getElementById("regExpExPrcFirst").validationGroup = "Populate";
        document.getElementById("regExpExPrcSecond").validationGroup = "Populate";
        document.getElementById("reqFldExPrcSecond").validationGroup = "Populate";
    }
    else {
        document.getElementById("regExpExercisePeriod").validationGroup = "Populate";
        document.getElementById("reqFldExercisePeriod").validationGroup = "Populate";
        document.getElementById("reqFldExPrcFirst").validationGroup = "Populate1";
        document.getElementById("regExpExPrcFirst").validationGroup = "Populate1";
        document.getElementById("regExpExPrcSecond").validationGroup = "Populate1";
        document.getElementById("reqFldExPrcSecond").validationGroup = "Populate1";
    }

    if ($('#chkAddGrantExPrcLnkMultDates').is(":checked")) {
        $("#trdivVestExercisePopulateOne").hide();
        $("#divExPrcLnkMultDatesFirst").slideDown();
        $("#btnAddGrantPopulateVestDetails").hide();
        $("#hdnbtnAddGrantPopulateVestDetails").show();
        document.getElementById("regExpExercisePeriod").validationGroup = "Populate1";
        document.getElementById("reqFldExercisePeriod").validationGroup = "Populate1";
        document.getElementById("reqFldExPrcFirst").validationGroup = "Populate";
        document.getElementById("regExpExPrcFirst").validationGroup = "Populate";
        document.getElementById("regExpExPrcSecond").validationGroup = "Populate";
        document.getElementById("reqFldExPrcSecond").validationGroup = "Populate";
    }

    $("tr.gvChildGrid").hide();
    $("tr.gvChildGridOp").hide();

    var tabActiveIndex = $("#hdnTabActiveIndex").val();
    var activeIndex = parseInt($("#hdnAccordionIndex").val());

    $("#accordion").accordion({
        collapsible: false,
        heightStyle: "content",
        active: activeIndex,
        activate: function (event, ui) {
            var index = $(this).children('h4').index(ui.newHeader);
            $("#hdnAccordionIndex").val(index);
        }
    });

    var dateToday = new Date();
    $(".datepickerGrantDate").datepicker({
        showOn: "both",
        maxDate: dateToday,
        buttonImage: "../../App_Themes/images/datepicker.png",
        buttonImageOnly: true,
        buttonText: "Calendar",
        dateFormat: "dd/M/yy",
        changeMonth: true,
        changeYear: true,
        onClose: function (dateText, inst) {
            $(this).blur();
        },
    });

    $(".datepickerDateOfListing").datepicker({
        showOn: "both",
        buttonImage: "../../App_Themes/images/datepicker.png",
        buttonImageOnly: true,
        buttonText: "Calendar",
        dateFormat: "dd/M/yy",
        changeMonth: true,
        changeYear: true,
        onClose: function (dateText, inst) {
        },
    });

    if ($("#txtAddGrantGrantID").val() == "")
        $("#btnAddGrantFileUpload").attr('disabled', true);
    else
        $("#btnAddGrantFileUpload").attr('disabled', false);

    $("#txtAddGrantGrantID").blur(function () {
        if ($("#txtAddGrantGrantID").val() == "")
            $("#btnAddGrantFileUpload").attr('disabled', true);
        else
            $("#btnAddGrantFileUpload").attr('disabled', false);
    });

    $(".datepickerDateOfListing").Watermark('dd/mmm/yyyy');
    $(".datepickerGrantDate").Watermark('dd/mmm/yyyy');

    var hideTabs;
    switch ($("#hdnhideTabs").val()) {
        case "1":
            hideTabs = [1, 2]
            break;
        case "2":
            hideTabs = []
            break;
        case "3":
            hideTabs = [1, 2, 3, 4]
            break;
    }
    
    $("#tabs").tabs({
        activate: function () {
            var newIdx = $('#tabs').tabs('option', 'active');
            $("#hdnTabActiveIndex").val(newIdx);
            if ($("#hdnTabActiveIndex").val() == 0) {
                return false;
            }
        },
        heightStyle: "content",
        active: tabActiveIndex,
        disabled: hideTabs
    });

    $("#h4SearchPanel").click(function () {
        var current = $("#accordion").accordion("option", "active");
        var prev = current - 1 < 0 ? 0 : current - 1;
        $("#accordion").accordion("option", "active", prev);
        $(".h3AddEdit").hide();

        HideMessageDiv();

        /* Clear All Search Panel Filters */
        $("#ddlGDGrantID").prop('selectedIndex', 0);
        $("#ddlGDSchemeName").prop('selectedIndex', 0);
        $("#calGDFromDate").val('dd/mmm/yyyy');
        $("#calGDToDate").val('dd/mmm/yyyy');
        $("#ddlGDCurrency").prop('selectedIndex', 0);
        $("#ddlGDReportStatus").prop('selectedIndex', 0);
        $("#txtGDExercisePriceFrom").val('');
        $("#txtGDExercisePriceTo").val('');
        /* ------------------------------ */
        $("#hdnDropDownChange").val('');
        return false;
    });

    $("h4ViewAddEditGV").click(function () {
        HideMessageDiv();
        var current = $("#accordion").accordion("option", "active");
        var next = current - 1 < 0 ? count + 1 : current - 1;
        $("#accordion").accordion("option", "active", next);
    });

    $("#chkGDGrantID_0").click(function () {
        if ($(this).is(":checked"))
            $("[id*=chkGDGrantID] input").attr("checked", "checked");
        else
            $("[id*=chkGDGrantID] input").removeAttr("checked");
    });

    $("#chkGDGrantID").click(function () {
        var v_SelectedGrantID = [];

        var v_ItemsCount = parseInt($("#chkGDGrantID input:checked").size()) + parseInt($("#chkGDGrantID input:not(:checked)").size());
        var v_ChekedItemCnt = parseInt($("#chkGDGrantID input:checked").size());

        if (v_ItemsCount != v_ChekedItemCnt)
            $("#chkGDGrantID_0").attr("checked", false);

        $("[id*= chkGDGrantID] input:checked").each(function () {
            if ($(this).is(":checked")) {
                if ($(this).val() == "--- Select All ---")
                    v_SelectedGrantID.pop($(this).val());
                else {
                    v_SelectedGrantID.push($(this).val());
                }
            }
        });

        if (v_SelectedGrantID.length > 0) {
            $("#txtGDGrantID").val(v_SelectedGrantID);
        }
        else {
            $("#txtGDGrantID").val('--- Please Select ---');
        }
    });

    $("#chkGDSchemeName_0").click(function () {
        if ($(this).is(":checked"))
            $("[id*=chkGDSchemeName] input").attr("checked", "checked");
        else
            $("[id*=chkGDSchemeName] input").removeAttr("checked");
    });

    $("#chkGDSchemeName").click(function () {
        var v_SelectedSchemeName = [];

        var v_ItemsCount = parseInt($("#chkGDSchemeName input:checked").size()) + parseInt($("#chkGDSchemeName input:not(:checked)").size());
        var v_ChekedItemCnt = parseInt($("#chkGDSchemeName input:checked").size());

        if (v_ItemsCount != v_ChekedItemCnt)
            $("#chkGDSchemeName_0").attr("checked", false);

        $("[id*= chkGDSchemeName] input:checked").each(function () {
            if ($(this).is(":checked")) {
                if ($(this).val() == "--- Select All ---")
                    v_SelectedSchemeName.pop($(this).val());
                else
                    v_SelectedSchemeName.push($(this).val());
            }
        });

        if (v_SelectedSchemeName.length > 0) {
            $("#txtGDSchemeName").val(v_SelectedSchemeName);
        }
        else {
            $("#txtGDSchemeName").val('--- Please Select ---');
        }
    });

    $("#chkGDCurrency_0").click(function () {
        if ($(this).is(":checked"))
            $("[id*=chkGDCurrency] input").attr("checked", "checked");
        else
            $("[id*=chkGDCurrency] input").removeAttr("checked");
    });

    $("#chkGDCurrency").click(function () {
        var v_SelectedCurrency = [];

        var v_ItemsCount = parseInt($("#chkGDCurrency input:checked").size()) + parseInt($("#chkGDCurrency input:not(:checked)").size());
        var v_ChekedItemCnt = parseInt($("#chkGDCurrency input:checked").size());

        if (v_ItemsCount != v_ChekedItemCnt)
            $("#chkGDCurrency_0").attr("checked", false);

        $("[id*= chkGDCurrency] input:checked").each(function () {
            if ($(this).is(":checked")) {
                if ($(this).val() == "--- Select All ---")
                    v_SelectedCurrency.pop($(this).val());
                else
                    v_SelectedCurrency.push($(this).val());
            }
        });

        if (v_SelectedCurrency.length > 0) {
            $("#txtGDCurrency").val(v_SelectedCurrency);
        }
        else {
            $("#txtGDCurrency").val('--- Please Select ---');
        }
    });

    $("#chkGDReportStatus_0").click(function () {
        if ($(this).is(":checked"))
            $("[id*=chkGDReportStatus] input").attr("checked", "checked");
        else
            $("[id*=chkGDReportStatus] input").removeAttr("checked");
    });

    $("#chkGDReportStatus").click(function () {
        var v_SelectedStatus = [];

        var v_ItemsCount = parseInt($("#chkGDReportStatus input:checked").size()) + parseInt($("#chkGDReportStatus input:not(:checked)").size());
        var v_ChekedItemCnt = parseInt($("#chkGDReportStatus input:checked").size());

        if (v_ItemsCount != v_ChekedItemCnt)
            $("#chkGDReportStatus_0").attr("checked", false);

        $("[id*= chkGDReportStatus] input:checked").each(function () {
            if ($(this).is(":checked")) {
                if ($(this).val() == "--- Select All ---")
                    v_SelectedStatus.pop($(this).val());
                else
                    v_SelectedStatus.push($(this).val());
            }
        });

        if (v_SelectedStatus.length > 0) {
            $("#txtGDReportStatus").val(v_SelectedStatus);
        }
        else {
            $("#txtGDReportStatus").val('--- Please Select ---');
        }
    });

    $("#chkGrantCreatedOn_0").click(function () {
        if ($(this).is(":checked"))
            $("[id*=chkGrantCreatedOn] input").attr("checked", "checked");
        else
            $("[id*=chkGrantCreatedOn] input").removeAttr("checked");
    });

    $("#chkGrantCreatedOn").click(function () {
        var v_SelectedStatus = [];

        var v_ItemsCount = parseInt($("#chkGrantCreatedOn input:checked").size()) + parseInt($("#chkGrantCreatedOn input:not(:checked)").size());
        var v_ChekedItemCnt = parseInt($("#chkGrantCreatedOn input:checked").size());

        if (v_ItemsCount != v_ChekedItemCnt)
            $("#chkGrantCreatedOn_0").attr("checked", false);

        $("[id*= chkGrantCreatedOn] input:checked").each(function () {
            if ($(this).is(":checked")) {
                if ($(this).val() == "--- Select All ---")
                    v_SelectedStatus.pop($(this).val());
                else
                    v_SelectedStatus.push($(this).val());
            }
        });

        if (v_SelectedStatus.length > 0) {
            $("#txtGrantCreatedOn").val(v_SelectedStatus);
        }
        else {
            $("#txtGrantCreatedOn").val('--- Please Select ---');
        }
    });


    $("#btnGDAddGrant").click(function () {
        $("#hdnAccordionIndex").val(1);
        $("#hdnAction").val("A");
        $('#tabs').tabs('option', 'active', 0);
        $("#ddlAddGrantSchemeName").prop("disabled", false);
        $("#txtAddGrantGrantID").attr("disabled", false);

        /* Clear All Controls Fields*/
        $("#ddlAddGrantSchemeName").prop('selectedIndex', 0);
        $("#txtEnterSchemeName").val('');
        $("#txtAddGrantGrantID").val('');
        $("#txtAddGrantGrantDate").val('dd/mmm/yyyy');
        $("#txtAddGrantExercisePrice").val('');
        $("#txtAddGrantPricingFormula").val('');
        $("#ddlAddGrantCurrency").prop('selectedIndex', 0);
        $("#txtAddGrantNumberOfVest").val('');
        $("#txtAddGrantVestingFrequency").val('');
        $('#rdbtnVestingFreqYearly :radio[value="Y"]').prop('checked', true);
        $('#chkFirstVestAftrOneYr').prop('checked', false);
        $("#divExPrcLnkMultDatesFirst").hide();
        $("#ddlAddGrantVestingParams").prop('selectedIndex', 0);
        $("#txtAddGrantExercisePeriod").val('');
        $('#rdbtnExerPeriodYears :radio[value="Y"]').prop('checked', true);
        $('#rdbtnExerPeriodFromDOG :radio[value="V"]').prop('checked', true);
        $('#chkAddGrantExPrcLnkMultDates').prop('checked', false);
        $('#rdbtnExPrcLnkMultDatesEarlier :radio[value="E"]').prop('checked', true);
        $("#txtAddGrantExPrcFirst").val('');
        $("#txtAddGrantExPrcSecond").val('');
        $('#rdbtnExPrcLnkMultDatesYearsOne :radio[value="Y"]').prop('checked', true);
        $('#rdbtnExPrcLnkMultDatesYearsTwo :radio[value="Y"]').prop('checked', true);
        $('#rdbtnExPrcLnkMultDatesGDOne :radio[value="V"]').prop('checked', true);
        $('#rdbtnExPrcLnkMultDatesGDTwo :radio[value="V"]').prop('checked', true);
        $('#rdbtnEquitySettled').prop('checked', true);
        $('#rdbtnCashSettled').prop('checked', false);
        $("#txtAddGrantRatioOpt").val('1');
        $("#txtAddGrantRatioShares").val('1');
        $("#chkAddGrantTrstRouteNo").prop('checked', true);
        $("#chkAddGrantTrstRouteYes").prop('checked', false);
        $("#txtAddGrantCommentBox").val('');
        $('#rdbtnUpdateParams :radio[value="N"]').prop('checked', true);
        $('#btnAddGrantAddMoreGrants').hide();
        $('#btnAddGrantSaveContinue').hide();
        /* ----------------------- */
        $(".h3AddEdit").show();
        $("#hdnDropDownChange").val("1");
        $("#divMessegebox").hide();

        HideMessageDiv();

        $("#trdivVestExercisePopulateOne").show();
        $('#divVestExercisePopulateOne').show();
        $('#hdnSearchUC').val("1");
        $("#hdnAction").val('');
        $("#hdnARMID_ToEdit").val('');
        $("#gvVestExercisePopulate").hide();
        $("#gvUpdateFairParams").hide();
        $("#hdnAccordionIndex").val(1);

        ClearAllHiddenFlagFields();

        $("#pageloaddiv").fadeIn();
        return true;
    });

    $("#btnAddOptionDetails").click(function () {
        $("#hdnAccordionIndex").val(1);
        $("#hdnAction").val("A");
        $('#tabs').tabs('option', 'active', 3);
        $("#ddlAddGrantSchemeName").prop("disabled", false);
        $("#txtAddGrantGrantID").attr("disabled", false);

        /* Clear All Controls Fields*/
        $("#ddlAddGrantSchemeName").prop('selectedIndex', 0);
        $("#txtEnterSchemeName").val('');
        $("#txtAddGrantGrantID").val('');
        $("#txtAddGrantGrantDate").val('dd/mmm/yyyy');
        $("#txtAddGrantExercisePrice").val('');
        $("#txtAddGrantPricingFormula").val('');
        $("#ddlAddGrantCurrency").prop('selectedIndex', 0);
        $("#txtAddGrantNumberOfVest").val('');
        $("#txtAddGrantVestingFrequency").val('');
        $('#rdbtnVestingFreqYearly :radio[value="Y"]').prop('checked', true);
        $('#chkFirstVestAftrOneYr').prop('checked', false);
        $("#divExPrcLnkMultDatesFirst").hide();
        $("#ddlAddGrantVestingParams").prop('selectedIndex', 0);
        $("#txtAddGrantExercisePeriod").val('');
        $('#rdbtnExerPeriodYears :radio[value="Y"]').prop('checked', true);
        $('#rdbtnExerPeriodFromDOG :radio[value="V"]').prop('checked', true);
        $('#chkAddGrantExPrcLnkMultDates').prop('checked', false);
        $('#rdbtnExPrcLnkMultDatesEarlier :radio[value="E"]').prop('checked', true);
        $("#txtAddGrantExPrcFirst").val('');
        $("#txtAddGrantExPrcSecond").val('');
        $('#rdbtnExPrcLnkMultDatesYearsOne :radio[value="Y"]').prop('checked', true);
        $('#rdbtnExPrcLnkMultDatesYearsTwo :radio[value="Y"]').prop('checked', true);
        $('#rdbtnExPrcLnkMultDatesGDOne :radio[value="V"]').prop('checked', true);
        $('#rdbtnExPrcLnkMultDatesGDTwo :radio[value="V"]').prop('checked', true);
        $('#rdbtnEquitySettled').prop('checked', true);
        $('#rdbtnCashSettled').prop('checked', false);
        $("#txtAddGrantRatioOpt").val('1');
        $("#txtAddGrantRatioShares").val('1');
        $("#chkAddGrantTrstRouteNo").prop('checked', true);
        $("#chkAddGrantTrstRouteYes").prop('checked', false);
        $("#txtAddGrantCommentBox").val('');
        $('#rdbtnUpdateParams :radio[value="N"]').prop('checked', true);
        $('#btnAddGrantAddMoreGrants').hide();
        $('#btnAddGrantSaveContinue').hide();
        /* ----------------------- */
        $(".h3AddEdit").show();
        $("#hdnDropDownChange").val("1");
        $("#divMessegebox").hide();

        HideMessageDiv();

        $("#trdivVestExercisePopulateOne").show();
        $('#divVestExercisePopulateOne').show();
        $('#hdnSearchUC').val("1");
        $("#hdnAction").val('');
        $("#hdnARMID_ToEdit").val('');
        $("#gvVestExercisePopulate").hide();
        $("#gvUpdateFairParams").hide();
        $("#hdnAccordionIndex").val(1);

        ClearAllHiddenFlagFields();

        return true;
    });

    $("#ddlAddGrantSchemeName").change(function () {
        $("hdnddlAddGrantSchemeName").val("DrChange");
        $("#ddlAddGrantSchemeName").prop('disabled', false);
        $("#txtAddGrantGrantID").prop('disabled', false);
    });

    $("#ddlGVPGrantList").change(function () {
        $("#hdnAction").val("U");
    });

    $('#chkAddGrantExPrcLnkMultDates').on('click', function () {
        if ($("#hdnAction").val() != "U") {
            $("#txtAddGrantExercisePeriod").val('');
            $("#txtAddGrantExPrcFirst").val('');
            $("#txtAddGrantExPrcSecond").val('');
        }
        $("#gvVestExercisePopulate").hide();
        $("#MainContent_divVestExercisePopulate").hide('slow');
        $("#btnAddGrantAddMoreGrants").hide();
        $("#btnAddGrantSaveContinue").hide();

        if ($(this).is(":checked")) {
            document.getElementById("regExpExercisePeriod").validationGroup = "Populate1";
            document.getElementById("reqFldExercisePeriod").validationGroup = "Populate1";
            document.getElementById("reqFldExPrcFirst").validationGroup = "Populate";
            document.getElementById("regExpExPrcFirst").validationGroup = "Populate";
            document.getElementById("regExpExPrcSecond").validationGroup = "Populate";
            document.getElementById("reqFldExPrcSecond").validationGroup = "Populate";
            HideMessageDiv();
            $('#trdivVestExercisePopulateOne').hide();
            $('#divExPrcLnkMultDatesFirst').slideDown();
            $("#trExPrcLnkMultDatesFirst").show();
            $("#hdnbtnAddGrantPopulateVestDetails").show();
            $("#btnAddGrantPopulateVestDetails").hide();
            $("#MainContent_trbtnAddGrantPopulateVestDetails").show();
            $("#MainContent_trdivgvVestExercisePopulateEdit").hide();
        }
        else {
            $("#hdnbtnAddGrantPopulateVestDetails").hide();
            $("#btnAddGrantPopulateVestDetails").show();
            document.getElementById("regExpExercisePeriod").validationGroup = "Populate";
            document.getElementById("reqFldExercisePeriod").validationGroup = "Populate";
            document.getElementById("reqFldExPrcFirst").validationGroup = "Populate1";
            document.getElementById("regExpExPrcFirst").validationGroup = "Populate1";
            document.getElementById("regExpExPrcSecond").validationGroup = "Populate1";
            document.getElementById("reqFldExPrcSecond").validationGroup = "Populate1";
            HideMessageDiv();
            $("#trdivVestExercisePopulateOne").show();
            $("#divVestExercisePopulateOne").show();
            $('#divExPrcLnkMultDatesFirst').slideUp();
        }
        for (var i in Page_Validators) {
            if (Page_Validators[i].validationGroup == "Populate1") {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                control.className = "cTextBox";
                Page_Validators[i].style.display = "none";
                Page_Validators[i].isvalid = true;
            }
        }
    });

    $("#hdnbtnAddGrantPopulateVestDetails").click(function () {
        $("#btnAddGrantPopulateVestDetails").hide();

        ShowHideContent();

        if ($('#chkAddGrantExPrcLnkMultDates').is(":checked")) {
            $("#trdivVestExercisePopulateOne").hide();
            $("#divExPrcLnkMultDatesFirst").slideDown();
            $("#btnAddGrantPopulateVestDetails").hide();
            $("#hdnbtnAddGrantPopulateVestDetails").show();
            document.getElementById("regExpExercisePeriod").validationGroup = "Populate1";
            document.getElementById("reqFldExercisePeriod").validationGroup = "Populate1";
            document.getElementById("reqFldExPrcFirst").validationGroup = "Populate";
            document.getElementById("regExpExPrcFirst").validationGroup = "Populate";
            document.getElementById("regExpExPrcSecond").validationGroup = "Populate";
            document.getElementById("reqFldExPrcSecond").validationGroup = "Populate";
        }

        if ($("#hdnAction").val() != "U") {
            $("#gvVestExercisePopulate").hide();
            $("#btnAddGrantAddMoreGrants").hide();
            $("#btnAddGrantSaveContinue").hide();
        }

        if ($("#ddlAddGrantSchemeName").val() == "--- Please Select ---") {
            var control = document.getElementById("ddlAddGrantSchemeName");
            control.className = "form-control-Error";
            var control = document.getElementById("lblddlAddGrantSchemeName");
            control.className = "noImg";
            return false;
        }
        else
            return true;
    });

    $("#btnGDReset").click(function () {
        if (confirm("Do you really want to reset?") == true)
            return true;
        else
            return false;
    });

    $("#btnAddGrantCancel").click(function () {
        if (confirm("Do you really want to cancel?") == true) {
            var current = $("#accordion").accordion("option", "active");
            var prev = current - 1 < 0 ? 0 : current - 1;
            $("#accordion").accordion("option", "active", prev);
            $(".h3AddEdit").hide();

            HideMessageDiv();

            $("#hdnDropDownChange").val('');
            $("#divMessegebox").hide();
            $("#txtEnterSchemeName").val("");
            $(".PopupBackgroundDiv").hide();
            $("#txtAddGrantExercisePeriod").val('');
            /* Clear All Search Panel Filters */
            $("#ddlGDGrantID").prop('selectedIndex', 0);
            $("#ddlGDSchemeName").prop('selectedIndex', 0);
            $("#calGDFromDate").val('dd/mmm/yyyy');
            $("#calGDToDate").val('dd/mmm/yyyy');
            $("#ddlGDCurrency").prop('selectedIndex', 0);
            $("#ddlGDReportStatus").prop('selectedIndex', 0);
            $("#txtGDExercisePriceFrom").val('');
            $("#txtGDExercisePriceTo").val('');
            /* ------------------------------ */

            return false;
        }
        else
            return false;

    });

    if ($("#hdnShowGrid").val() == "1") {
        OpenPopupDiv();
    }

    if ($("#hdnShowGridOne").val() == "1") {
        if (document.getElementById('VDbkgEL').style.display == 'none') {
            document.getElementById('VDbkgEL').style.display = '';
            $("#VDbkgEL").hide();
        }
        if (document.getElementById('VDdlgEL').style.display == 'none') {
            document.getElementById('VDdlgEL').style.display = '';
            $("#VDdlgEL").hide();
        }
        $("#VDbkgEL").fadeIn(300, "linear", function () { $("#VDdlgEL").show(500, "swing"); });

        $("#hdnShowGridOne").val('');
    }

    $("#VDclosebtnEL").click(function () {
        $("#VDdlgEL").hide('500', "swing", function () { $("#VDbkgEL").fadeOut("300"); });
        $("#PopupMainContentDiv").hide('500', "swing", function () { $("#PopupBackgroundDiv").fadeOut("300"); });
        $("#hdnShowGrid").val('');
        $("#hdnShowGridOne").val('');
        $("#hdnGrantID").val('');
        $(".h3AddEdit").hide();
        $(".Message_div").hide();
    });

    $("#closebtnEL").click(function () {
        ClosePopupDiv();
        $("#hdnShowGrid").val('');
        $("#hdnShowGridOne").val('');
        $("#hdnGrantID").val('');
        $(".h3AddEdit").hide();
        $(".Message_div").hide();
    });

    $("#btnGDDocDownload").click(function () {
        return true;
    });

    $("#btnAddGrantPopulateVestDetails").click(function () {

        ShowHideContent();

        if ($("#hdnAction").val() != "U") {
            $("#gvVestExercisePopulate").hide();
            $("#btnAddGrantAddMoreGrants").hide();
            $("#btnAddGrantSaveContinue").hide();
        }

        if ($("#ddlAddGrantSchemeName").val() == "--- Please Select ---") {
            var control = document.getElementById("ddlAddGrantSchemeName");
            control.className = "form-control-Error";
            var control = document.getElementById("lblddlAddGrantSchemeName");
            control.className = "noImg";
            return false;
        }
        else
        {
            return true;
        }
    });

    $("#btnMsgclosebtn").click(function () {
        $(".Message_div").hide('slow');
        $("#btnAddGrantPopulateVestDetails").show();
        if ($('#chkAddGrantExPrcLnkMultDates').is(":checked")) {
            $("#txtAddGrantExercisePeriod").val('');
            $("#btnAddGrantPopulateVestDetails").hide();
            $("#hdnbtnAddGrantPopulateVestDetails").show();
        }
        else {
            $("#btnAddGrantPopulateVestDetails").show();
            $("#hdnbtnAddGrantPopulateVestDetails").hide();
        }
    });

    $("#btnAddGrantAddMoreGrants").click(function () {
        $("#hdnDropDownChange").val("0");
        var o_isValidd = 0;

        ClearAllHiddenFlagFields();

        o_isValidd = ValidateDates();

        if (o_isValidd != 1) {
            o_isValidd = ValidateValuParamGrid("PageLoad");

            var checkedRadio = $("#rdbtnUpdateParams input[type=radio]:checked");

            if (o_isValidd != 1) {
                if (checkedRadio.val() == "N") {

                    if ($('#chkAddGrantExPrcLnkMultDates').is(":checked")) {
                        document.getElementById("regExpExercisePeriod").validationGroup = "Populate1";
                        document.getElementById("reqFldExercisePeriod").validationGroup = "Populate1";
                        document.getElementById("reqFldExPrcFirst").validationGroup = "Populate";
                        document.getElementById("regExpExPrcFirst").validationGroup = "Populate";
                        document.getElementById("regExpExPrcSecond").validationGroup = "Populate";
                        document.getElementById("reqFldExPrcSecond").validationGroup = "Populate";

                        Page_ClientValidate("Populate");
                        if (Page_IsValid) {
                            if (confirm("Are you sure to add grant(s)?") == true)
                                return true;
                            else
                                return false;
                        }
                    }

                    else {
                        document.getElementById("regExpExercisePeriod").validationGroup = "Populate";
                        document.getElementById("reqFldExercisePeriod").validationGroup = "Populate";
                        document.getElementById("reqFldExPrcFirst").validationGroup = "Populate1";
                        document.getElementById("regExpExPrcFirst").validationGroup = "Populate1";
                        document.getElementById("regExpExPrcSecond").validationGroup = "Populate1";
                        document.getElementById("reqFldExPrcSecond").validationGroup = "Populate1";
                        Page_ClientValidate("Populate");

                        if (Page_IsValid) {
                            if (confirm("Are you sure to add grant(s)?") == true)
                                return true;
                            else
                                return false;
                        }
                    }
                }
                else {
                    Page_ClientValidate("ValdParams");
                    if (Page_IsValid) {
                        if (checkedRadio.val() == "P" || checkedRadio.val() == "F") {
                            if ($("#txt_0_1").val() != "" || $("#txt_1_1").val() != "" || $("#txt_2_1").val() != "" || $("#txt_3_1").val() != "" || $("#txt_4_1").val() != "" || $("#txt_5_1").val() != "" || $("#txt_6_1").val() != "" || $("#txt_7_1").val() != "") {
                                if (checkedRadio.val() == "F" && $("#txt_6_1").val() == "") {
                                    alert("Please Enter Fair Values For All Vests or Select 'None' to proceed");
                                    return false;
                                }
                                if (checkedRadio.val() == "P" && $("#txt_3_1").val() != "" && ($("#txt_4_1").val() != "" || $("#txt_5_1").val() != "")) {
                                    alert("Please Enter Either 'Dividend Yield' Or 'Dividend Yeild-Divd' and 'Dividend Yield-Market Price'");
                                    return false;
                                }
                                if ((checkedRadio.val() == "P" && $("#txt_4_1").val() != "" && $("#txt_5_1").val() == "")) {
                                    alert("Please Enter 'Dividend Yield-Market Price' For All Vests");
                                    return false;
                                }
                                if ((checkedRadio.val() == "P" && $("#txt_5_1").val() != "" && $("#txt_4_1").val() == "")) {
                                    alert("Please Enter 'Dividend Yeild-Divd' For All Vests");
                                    return false;
                                }
                            }
                            else {
                                alert("Please select 'None' to proceed");
                                return false;
                            }
                        }

                        if ($('#chkAddGrantExPrcLnkMultDates').is(":checked")) {
                            Page_ClientValidate("Populate");
                            if (Page_IsValid) {
                                if (confirm("Are you sure to add grant(s)?") == true)
                                    return true;
                                else
                                    return false;
                            }
                        }
                        else {
                            Page_ClientValidate("Populate");
                            if (Page_IsValid) {
                                if (confirm("Are you sure to add grant(s)?") == true)
                                    return true;
                                else
                                    return false;
                            }
                        }
                    }
                    else
                        return false;
                }
            }
            else {
                $("#btnAddGrantSaveContinue").blur();
            }
        }
        else {
            for (var i in Page_Validators) {
                if (Page_Validators[i].validationGroup == "ValdateDate") {
                    var control = document.getElementById(Page_Validators[i].controltovalidate);
                    control.className = "cTextBox form-control-Error";
                    Page_Validators[i].isvalid = true;
                }
            }
            return false;
        }
    });

    $(".txtEditCode").change(function () {
        ValidateValuParamGrid("");
        $("#btnAddGrantSaveContinue").blur();
        return false;
    });

    $("#txtAddGrantExercisePeriod").blur(function () {
        if ($("#txtAddGrantExercisePeriod").val() == '') {
            $("#btnAddGrantAddMoreGrants").hide();
            $("#btnAddGrantSaveContinue").hide();
        }
    });

    $("#txtAddGrantExPrcFirst").blur(function () {
        if ($("#txtAddGrantExPrcFirst").val() == '') {
            $("#btnAddGrantAddMoreGrants").hide();
            $("#btnAddGrantSaveContinue").hide();
        }
    });

    $("#txtAddGrantExPrcSecond ").blur(function () {
        if ($("#txtAddGrantExPrcSecond").val() == '') {
            $("#btnAddGrantAddMoreGrants").hide();
            $("#btnAddGrantSaveContinue").hide();
        }
    });

    $("#rdbtnUpdateParams").change(function () {

        ClearAllHiddenFlagFields();

        Page_ClientValidate("ValdParams");
        if (Page_IsValid) {
            $("#pageloaddiv").fadeIn();
            $("#btnGDShowValParamGrid").trigger('click');
            return false;
        }
    });

    $("#btnAddGrantSaveContinue").click(function () {
        var o_isValidd = 0;

        ClearAllHiddenFlagFields();

        o_isValidd = ValidateDates();

        if (o_isValidd != 1) {
            o_isValidd = ValidateValuParamGrid("PageLoad");

            var checkedRadio = $("#rdbtnUpdateParams input[type=radio]:checked");

            if (o_isValidd != 1) {
                if (checkedRadio.val() == "N") {

                    if ($('#chkAddGrantExPrcLnkMultDates').is(":checked")) {
                        document.getElementById("regExpExercisePeriod").validationGroup = "Populate1";
                        document.getElementById("reqFldExercisePeriod").validationGroup = "Populate1";
                        document.getElementById("reqFldExPrcFirst").validationGroup = "Populate";
                        document.getElementById("regExpExPrcFirst").validationGroup = "Populate";

                        if ($("#hdnAction").val() != "U") {
                            document.getElementById("regExpExPrcSecond").validationGroup = "Populate";
                            document.getElementById("reqFldExPrcSecond").validationGroup = "Populate";
                        }
                        else {
                            document.getElementById("regExpExPrcSecond").validationGroup = "Populate1";
                            document.getElementById("reqFldExPrcSecond").validationGroup = "Populate1";
                        }

                        Page_ClientValidate("Populate");
                        if (Page_IsValid) {
                            if (confirm("Are you sure to save and continue?") == true) {
                                $("#pageloaddiv").fadeIn();
                                return true;
                            }
                            else
                                return false;
                        }
                    }

                    else {
                        document.getElementById("regExpExercisePeriod").validationGroup = "Populate";
                        document.getElementById("reqFldExercisePeriod").validationGroup = "Populate";
                        document.getElementById("reqFldExPrcFirst").validationGroup = "Populate1";
                        document.getElementById("regExpExPrcFirst").validationGroup = "Populate1";
                        document.getElementById("regExpExPrcSecond").validationGroup = "Populate1";
                        document.getElementById("reqFldExPrcSecond").validationGroup = "Populate1";
                        Page_ClientValidate("Populate");

                        if (Page_IsValid) {

                            if (confirm("Are you sure to save and continue?") == true) {
                                $("#pageloaddiv").fadeIn();
                                return true;
                            }
                            else
                                return false;
                        }
                    }
                }
                else {
                    Page_ClientValidate("ValdParams");
                    if (Page_IsValid) {
                        if (checkedRadio.val() == "P" || checkedRadio.val() == "F") {
                            if ($("#txt_0_1").val() != "" || $("#txt_1_1").val() != "" || $("#txt_2_1").val() != "" || $("#txt_3_1").val() != "" || $("#txt_4_1").val() != "" || $("#txt_5_1").val() != "" || $("#txt_6_1").val() != "" || $("#txt_7_1").val() != "") {
                                if (checkedRadio.val() == "F" && $("#txt_6_1").val() == "") {
                                    alert("Please Enter Fair Values For All Vests or Select 'None' to proceed");
                                    return false;
                                }
                                if (checkedRadio.val() == "P" && $("#txt_3_1").val() != "" && ($("#txt_4_1").val() != "" || $("#txt_5_1").val() != "")) {
                                    alert("Please Enter Either 'Dividend Yield' Or 'Dividend Yeild-Divd' and 'Dividend Yield-Market Price'");
                                    return false;
                                }
                            }
                            else {
                                alert("Please select 'None' to proceed");
                                return false;
                            }
                        }

                        if ($('#chkAddGrantExPrcLnkMultDates').is(":checked")) {
                            Page_ClientValidate("Populate");
                            if (Page_IsValid) {
                                if (confirm("Are you sure to save and continue?") == true) {
                                    $("#pageloaddiv").fadeIn();
                                    return true;
                                }
                                else
                                    return false;
                            }
                        }
                        else {
                            Page_ClientValidate("Populate");
                            if (Page_IsValid) {
                                if (confirm("Are you sure to save and continue?") == true) {
                                    $("#pageloaddiv").fadeIn();
                                    return true;
                                }
                                else
                                    return false;
                            }
                        }
                    }
                    else
                        return false;
                }
            }
            else {
                $("#btnAddGrantSaveContinue").blur();
            }
        }

        else {
            for (var i in Page_Validators) {
                if (Page_Validators[i].validationGroup == "ValdateDate") {
                    var control = document.getElementById(Page_Validators[i].controltovalidate);
                    control.className = "cTextBox form-control-Error";
                    Page_Validators[i].isvalid = true;
                }
            }
            return false;
        }
    });

    $(".Validators").on("keypress keyup", function (event) {
        var value = $(this).val().replace(/[^0-9\.]/g, '');
        $(this).val(value);
        if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    });

    $('#lnkRFIR').click(function () {
        window.location = "RiskFreeInterestRate.aspx";
        return false;
    });

    document.getElementById("regxcalGDFromDate").validationGroup = "Search1";
    document.getElementById("regxcalGDToDate").validationGroup = "Search1";

    $("#btnGDSearch").click(function () {

        HideMessageDiv();

        $("#divMessegebox").hide();

        if ($("#calGDFromDate").val() == "dd/mmm/yyyy") {
            document.getElementById("regxcalGDFromDate").validationGroup = "Search1";
        }
        else {
            document.getElementById("regxcalGDFromDate").validationGroup = "Search";
        }

        if ($("#calGDToDate").val() == "dd/mmm/yyyy") {
            document.getElementById("regxcalGDToDate").validationGroup = "Search1";
        }
        else {
            document.getElementById("regxcalGDToDate").validationGroup = "Search";
        }

        Page_ClientValidate("Search");
        if (Page_IsValid) {
            $("#pageloaddiv").fadeIn();
            return true;
        }
        else
            return false;
    });

    $("#btnGDClearFilter").click(function () {
        $("#hdnReset").val("1");
        $(".Message_div").hide("slow");

        var v_ChkBoxListControl = document.getElementById("chkGDGrantID");

        ClearChkBoxListItemsselection(v_ChkBoxListControl);

        v_ChkBoxListControl = document.getElementById("chkGDSchemeName");

        ClearChkBoxListItemsselection(v_ChkBoxListControl);

        v_ChkBoxListControl = document.getElementById("chkGDCurrency");

        ClearChkBoxListItemsselection(v_ChkBoxListControl);

        v_ChkBoxListControl = document.getElementById("chkGDReportStatus");

        ClearChkBoxListItemsselection(v_ChkBoxListControl);


        HideMessageDiv();

        $("#divMessegebox").hide();
        $("#pageloaddiv").fadeIn();
        return true;
    });

    $('#txtAddGrantNumberOfVest').keyup(function () {
        var ele = $("#txtAddGrantNumberOfVest").val();
        var i = ele.indexOf('0');
        if (i == 0) {
            alert("The Number of Vests should not be zero");
            $('#txtAddGrantNumberOfVest').val('');
        }
    });

    $("#btnAddGrantFileUpload").click(function () {
        var filename = $("#FileUploadControlOne").val();
        if (filename != '') {
            filename = filename.substring(filename.lastIndexOf('.'));
            var fileExtension = ['doc', 'docx', 'pdf', 'xlsx', 'xls'];
            if ($.inArray(filename.split('.').pop().toLowerCase(), fileExtension) == -1) {
                $("#imgFileUploadError").show();
                return false;
            }
            else {
                $("#imgFileUploadError").hide();
                return true;
            }
        }
        else
            return false;
    });

    $('#txtAddGrantGrantID').bind('keypress', function (e) {
        if ($('#txtAddGrantGrantID').val().length == 0) {
            var valid = (e.which >= 48 && e.which <= 57) || (e.which >= 65 && e.which <= 90) || (e.which >= 97 && e.which <= 122);
            if (!valid) {
                e.preventDefault();
            }
        } else {
            var valid = (e.which >= 48 && e.which <= 57) || (e.which >= 65 && e.which <= 90) || (e.which >= 97 && e.which <= 122 || e.which == 95 || e.which == 8);
            if (!valid) {
                e.preventDefault();
            }
        }
    });
};


function ValidateDates() {
    Page_ClientValidate("ValdiateDate");
    if (Page_IsValid) {
        return 0;
    }
    else
        return 1;
};

function ClearChkBoxListItemsselection(v_ChkBoxListControl) {

    var v_ChkBoxListItemsCount = v_ChkBoxListControl.getElementsByTagName("input");

    for (var i = 0; i < v_ChkBoxListItemsCount.length ; i++) {
        v_ChkBoxListItemsCount[i].checked = false;
    }

};

function ShowDetailsOpt(o_this) {
    if ($(o_this).attr('src') == "../../App_Themes/images/plus.png") {
        $(o_this).attr('src', "../../App_Themes/images/minus.png");
    }
    else {
        $(o_this).attr('src', "../../App_Themes/images/plus.png");
    }
    $(o_this).closest('tr').next('tr.gvChildGridOp').toggle(500, "swing");
    return false;
};


function ValidateValuParamGrid(o_Type) {
    var iColIndex, iRowIndex;
    $("#gvUpdateFairParams tr td").each(function (e) {
        iColIndex = $(this).closest("tr td").prevAll("tr td").length;
        iRowIndex = $(this).closest("tr").prevAll("tr").length;
    });

    var checkedRadio = $("#rdbtnUpdateParams input[type=radio]:checked");
    if (checkedRadio.val() == "P" || checkedRadio.val() == "F") {
        if ($("#txt_0_1").attr("noofcolumns") != undefined) {
            var o_NoOfColumns = $("#txt_0_1").attr("noofcolumns");

            if ($("#txt_0_1").val() != "") {
                Page_ClientValidate("ValdParams_0");
                if (Page_IsValid) {
                    if (o_Type == "PageLoad") {
                        var s_Val = '';
                        for (var i_loop = 1; i_loop < o_NoOfColumns; i_loop++) {
                            s_Val += "~" + $("#" + "txt_0_" + i_loop).val();
                        }
                        $("#hdnMarketPricePerVest").val(s_Val);
                        $("#hdnMPFlag").val("set");
                    }
                }
                else
                    return 1;
            }
            else if ($("#txt_0_1").val() == "") {
                var iColValCnt0 = 0;
                for (var i = 1 ; i <= iColIndex ; i++) {
                    if ($("#txt_0_" + i).val() == "") {
                        iColValCnt0 = parseInt(iColValCnt0) + 1;
                    }
                }

                if (iColValCnt0 <= iColIndex && iColValCnt0 != 0) {
                    Page_ClientValidate("ValdParams_0");
                    if (Page_IsValid || iColValCnt0 == iColIndex) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_0") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else
                        return 1;
                }

                else if (iColValCnt0 == 0) {
                    Page_ClientValidate("ValdParams_0");
                    if (Page_IsValid) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_0") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else if (iColValCnt0 == iColIndex)
                        return 1;
                }
            }

            if ($("#txt_1_1").val() != "") {
                Page_ClientValidate("ValdParams_1");
                if (Page_IsValid) {
                    if (o_Type == "PageLoad") {
                        var s_Val = '';
                        for (var i_loop = 1; i_loop < o_NoOfColumns; i_loop++) {
                            s_Val += "~" + $("#" + "txt_1_" + i_loop).val();
                        }
                        $("#hdnMarketPriceIV").val(s_Val);
                        $("#hdnMPIVFlag").val("set");
                    }
                }
                else return 1;
            }
            else if ($("#txt_1_1").val() == "") {
                var iColValCnt1 = 0;
                for (var i = 1 ; i <= iColIndex ; i++) {
                    if ($("#txt_1_" + i).val() == "") {
                        iColValCnt1 = parseInt(iColValCnt1) + 1;
                    }
                }

                if (iColValCnt1 <= iColIndex && iColValCnt1 != 0) {
                    Page_ClientValidate("ValdParams_1");
                    if (Page_IsValid || iColValCnt1 == iColIndex) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_1") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else
                        return 1;
                }

                else if (iColValCnt1 == 0) {
                    Page_ClientValidate("ValdParams_1");
                    if (Page_IsValid) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_1") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else if (iColValCnt1 == iColIndex)
                            ;
                    else
                        return 1;
                }
            }

            if ($("#txt_2_1").val() != "") {
                Page_ClientValidate("ValdParams_2");
                if (Page_IsValid) {
                    if (o_Type == "PageLoad") {
                        var s_Val = '';
                        for (var i_loop = 1; i_loop < o_NoOfColumns; i_loop++) {
                            s_Val += "~" + $("#" + "txt_2_" + i_loop).val();
                        }
                        $("#hdnExpectedLife").val(s_Val);
                        $("#hdnEXLFlag").val("set");
                    }
                }
                else return 1;
            }
            else if ($("#txt_2_1").val() == "") {
                var iColValCnt2 = 0;
                for (var i = 1 ; i <= iColIndex ; i++) {
                    if ($("#txt_2_" + i).val() == "") {
                        iColValCnt2 = parseInt(iColValCnt2) + 1;
                    }
                }

                if (iColValCnt2 <= iColIndex && iColValCnt2 != 0) {
                    Page_ClientValidate("ValdParams_2");
                    if (Page_IsValid || iColValCnt2 == iColIndex) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_2") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else
                        return 1;
                }

                else if (iColValCnt2 == 0) {
                    Page_ClientValidate("ValdParams_2");
                    if (Page_IsValid) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_2") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else if (iColValCnt2 == iColIndex)
                            ;
                    else
                        return 1;
                }
            }

            if ($("#txt_3_1").val() != "") {
                Page_ClientValidate("ValdParams_3");
                if (Page_IsValid) {
                    if (o_Type == "PageLoad") {
                        var s_Val = '';
                        for (var i_loop = 1; i_loop < o_NoOfColumns; i_loop++) {
                            s_Val += "~" + $("#" + "txt_3_" + i_loop).val();
                        }
                        $("#hdnDividend").val(s_Val);
                        $("#hdnDIVDFlag").val("set");
                    }
                }
                else
                    return 1;
            }
            else if ($("#txt_3_1").val() == "") {
                var iColValCnt3 = 0;
                for (var i = 1 ; i <= iColIndex ; i++) {
                    if ($("#txt_3_" + i).val() == "") {
                        iColValCnt3 = parseInt(iColValCnt3) + 1;
                    }
                }

                if (iColValCnt3 <= iColIndex && iColValCnt3 != 0) {
                    Page_ClientValidate("ValdParams_3");
                    if (Page_IsValid || iColValCnt3 == iColIndex) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_3") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else
                        return 1;
                }

                else if (iColValCnt3 == 0) {
                    Page_ClientValidate("ValdParams_3");
                    if (Page_IsValid) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_3") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else if (iColValCnt3 == iColIndex)
                            ;
                    else
                        return 1;
                }
            }

            if ($("#txt_4_1").val() != "") {
                Page_ClientValidate("ValdParams_4");
                if (Page_IsValid) {
                    if (o_Type == "PageLoad") {
                        var s_Val = '';
                        for (var i_loop = 1; i_loop < o_NoOfColumns; i_loop++) {
                            if ($("#" + "txt_4_" + i_loop).val() != "")
                                s_Val += "~" + $("#" + "txt_4_" + i_loop).val();
                            else
                                s_Val = '0';
                        }

                        if (checkedRadio.val() == "P" && s_Val != '0') {
                            $("#hdnDividendDIVD").val(s_Val);
                            $("#hdnDIVDDivdFlag").val("set");
                        }
                        else if (checkedRadio.val() == "F" && s_Val != '0') {
                            $("#hdnVolatility").val(s_Val);
                            $("#hdnVOLFlag").val("set");
                        }
                    }
                }
                else
                    return 1;
            }
            else if ($("#txt_4_1").val() == "") {
                var iColValCnt4 = 0;
                for (var i = 1 ; i <= iColIndex ; i++) {
                    if ($("#txt_4_" + i).val() == "") {
                        iColValCnt4 = parseInt(iColValCnt4) + 1;
                    }
                }

                if (iColValCnt4 <= iColIndex && iColValCnt4 != 0) {
                    Page_ClientValidate("ValdParams_4");
                    if (Page_IsValid || iColValCnt4 == iColIndex) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_4") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else
                        return 1;
                }

                else if (iColValCnt4 == 0) {
                    Page_ClientValidate("ValdParams_4");
                    if (Page_IsValid) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_4") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else if (iColValCnt4 == iColIndex)
                            ;
                    else
                        return 1;
                }
            }

            if ($("#txt_5_1").val() != "") {
                Page_ClientValidate("ValdParams_5");
                if (Page_IsValid) {
                    if (o_Type == "PageLoad") {
                        var s_Val = '';
                        for (var i_loop = 1; i_loop < o_NoOfColumns; i_loop++) {
                            if ($("#" + "txt_5_" + i_loop).val() != "")
                                s_Val += "~" + $("#" + "txt_5_" + i_loop).val();
                            else
                                s_Val = '0';
                        }

                        if (checkedRadio.val() == "P" && s_Val != '0') {
                            $("#hdnDividendMP").val(s_Val);
                            $("#hdnDividendMPFlag").val("set");
                        }
                        else if (checkedRadio.val() == "F" && s_Val != '0') {
                            $("#hdnRFIR").val(s_Val);
                            $("#hdnRFIRFlag").val("set");
                        }
                    }
                }
                else return 1;
            }
            else if ($("#txt_5_1").val() == "") {
                var iColValCnt5 = 0;
                for (var i = 1 ; i <= iColIndex ; i++) {
                    if ($("#txt_5_" + i).val() == "") {
                        iColValCnt5 = parseInt(iColValCnt5) + 1;
                    }
                }

                if (iColValCnt5 <= iColIndex && iColValCnt5 != 0) {
                    Page_ClientValidate("ValdParams_5");
                    if (Page_IsValid || iColValCnt5 == iColIndex) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_5") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else
                        return 1;
                }

                else if (iColValCnt5 == 0) {
                    Page_ClientValidate("ValdParams_5");
                    if (Page_IsValid) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_5") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else if (iColValCnt5 == iColIndex)
                            ;
                    else
                        return 1;
                }
            }


            if ($("#txt_6_1").val() != "") {
                Page_ClientValidate("ValdParams_6");

                if (Page_IsValid) {
                    if (o_Type == "PageLoad") {
                        var s_Val = '';
                        for (var i_loop = 1; i_loop < o_NoOfColumns; i_loop++) {
                            if ($("#" + "txt_6_" + i_loop).val() != "")
                                s_Val += "~" + $("#" + "txt_6_" + i_loop).val();
                            else
                                s_Val = '0';
                        }

                        if (checkedRadio.val() == "P" && s_Val != '0') {
                            $("#hdnVolatility").val(s_Val);
                            $("#hdnVOLFlag").val("set");
                        }
                        else if (checkedRadio.val() == "F" && s_Val != '0') {
                            $("#hdnFairVal").val(s_Val);
                            $("#hdnFVFlag").val("set");
                        }
                    }
                }
                else return 1;
            }
            else if ($("#txt_6_1").val() == "") {
                var iColValCnt6 = 0;
                for (var i = 1 ; i <= iColIndex ; i++) {
                    if ($("#txt_6_" + i).val() == "") {
                        iColValCnt6 = parseInt(iColValCnt6) + 1;
                    }
                }

                if (iColValCnt6 <= iColIndex && iColValCnt6 != 0) {
                    Page_ClientValidate("ValdParams_6");
                    if (Page_IsValid || iColValCnt6 == iColIndex) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_6") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else
                        return 1;
                }

                else if (iColValCnt6 == 0) {
                    Page_ClientValidate("ValdParams_6");
                    if (Page_IsValid) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_6") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else if (iColValCnt6 == iColIndex)
                            ;
                    else
                        return 1;
                }
            }

            if ($("#txt_7_1").val() != "") {
                Page_ClientValidate("ValdParams_7");
                if (Page_IsValid) {
                    if (o_Type == "PageLoad") {
                        var s_Val = '';

                        for (var i_loop = 1; i_loop < o_NoOfColumns; i_loop++) {
                            if ($("#" + "txt_7_" + i_loop).val() != "")
                                s_Val += "~" + $("#" + "txt_7_" + i_loop).val();
                            else
                                s_Val = '0';
                        }

                        if (checkedRadio.val() == "P" && s_Val != '0') {
                            $("#hdnRFIR").val(s_Val);
                            $("#hdnRFIRFlag").val("set");
                        }

                        else if (checkedRadio.val() == "F" && s_Val != '0') {
                            $("#hdnIntriVal").val(s_Val);
                            $("#hdnIVFlag").val("set");
                        }
                    }
                }
                else return 1;
            }
            else if ($("#txt_7_1").val() == "") {
                var iColValCnt7 = 0;
                for (var i = 1 ; i <= iColIndex ; i++) {
                    if ($("#txt_7_" + i).val() == "") {
                        iColValCnt7 = parseInt(iColValCnt7) + 1;
                    }
                }

                if (iColValCnt7 <= iColIndex && iColValCnt7 != 0) {
                    Page_ClientValidate("ValdParams_7");
                    if (Page_IsValid || iColValCnt7 == iColIndex) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_7") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else
                        return 1;
                }

                else if (iColValCnt7 == 0) {
                    Page_ClientValidate("ValdParams_7");
                    if (Page_IsValid) {
                        for (var i in Page_Validators) {
                            if (Page_Validators[i].validationGroup == "ValdParams_7") {
                                var control = document.getElementById(Page_Validators[i].controltovalidate);
                                control.className = "cTextBox UpdateParamGrid";
                                Page_Validators[i].isvalid = true;
                            }
                        }
                    }
                    else if (iColValCnt7 == iColIndex)
                            ;
                    else
                        return 1;
                }
            }
        }
    }
    return 2;
};

function ClearAllHiddenFlagFields() {
    $("#hdnMarketPricePerVest").val('0');
    $("#hdnMPFlag").val('');
    $("#hdnMarketPriceIV").val('0');
    $("#hdnMPIVFlag").val('');
    $("#hdnExpectedLife").val('0');
    $("#hdnEXLFlag").val('');
    $("#hdnDividend").val('0');
    $("#hdnDIVDFlag").val('');
    $("#hdnDividendDIVD").val('0');
    $("#hdnDIVDDivdFlag").val('');
    $("#hdnDividendMP").val('0');
    $("#hdnDividendMPFlag").val('');
    $("#hdnVolatility").val('0');
    $("#hdnVOLFlag").val('');
    $("#hdnRFIR").val('0');
    $("#hdnRFIRFlag").val('');
    $("#hdnFairVal").val('0');
    $("#hdnFVFlag").val('');
    $("#hdnIntriVal").val('0');
    $("#hdnIVFlag").val('');
}

function HideReversePopualteDiv() {
    HideMessageDiv();
    $("#MainContent_trdivgvVestExercisePopulateEdit").hide();
    $("#MainContent_trbtnAddGrantPopulateVestDetails").show();
};

function ShowHideContent() {
    Page_ClientValidate("Populate");
    if (Page_IsValid) {
        if ($("#hdntxtSchemeVal").val() != "0") {
            HideMessageDiv();
            var current = $("#accordion").accordion("option", "active");
            var next = current < 0 ? count + 1 : current;
            $("#accordion").accordion("option", "active", next);
            $("#divVestExercisePopulate").show();
            $("#gvVestExercisePopulate").show();
            return true;
        }
        else {
            var control = document.getElementById("reqFldEnterSchemeName");
            if (control != null)
                control.className = "form-control-Error";
        }
    }
    else {
        if ($("#hdntxtSchemeVal").val() == "hdn") {
            $("#hdntxtSchemeVal").val("0");
        }
        for (var i in Page_Validators) {
            if (Page_Validators[i].validationGroup == "Populate") {
                if (i.length < 0) {
                    var control = document.getElementById(Page_Validators[i].controltovalidate);
                    control.className = "form-control-Error";
                }
                else {
                    var control = document.getElementById(Page_Validators[i].controltovalidate);
                    if (control != null)
                        control.className = "cTextBox";
                }
            }
        }
        return true;
    }
};

function VaildateFile() {
    var filename = $("#FileUploadControlOne").val();
    if (filename != '') {
        filename = filename.substring(filename.lastIndexOf('.'));
        var fileExtension = ['doc', 'docx', 'pdf', 'xlsx'];
        if ($.inArray(filename.split('.').pop().toLowerCase(), fileExtension) == -1) {
            $("#FileUploadControlOne").val('');
            $("#imgFileUploadError").hide();
            return 1;
        }
        else {
            return 2;
        }
    }
};

function DocDownload(s_FileName, s_FilePath) {
    $("#hdnFileName").val(s_FileName);
    $("#hdnFileServerPath").val(s_FilePath + s_FileName);
    $("#hdnShowGridOne").val('');
    $("#VDdlgEL").hide('500', "swing", function () { $("#VDbkgEL").fadeOut("300"); });
    $("#PopupMainContentDiv").hide('500', "swing", function () { $("#PopupBackgroundDiv").fadeOut("300"); });
    $("#btnDocumentDownload").trigger("click");
    $(".h3AddEdit").hide();
    return false;
};
