﻿var $Modaldialog;
function pageLoad() {
    LoadScript();
    $("#txtVPSRFIRFileName").autocomplete({
        source: function (request, response) {
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: "ValuationParameters.aspx/VPSRFIRFileName",
                data: "{'fileName':'" + $("#txtVPSRFIRFileName").val() + "'}",
                dataType: "json",
                success: function (data) {
                    response(data.d);
                },
                failure: function (data) {
                    alert('failure');
                },
                error: function (data) {
                    alert('error');
                }
            });
        }
    });
    var activeIndex = parseInt($("#hdnVPSRFIRAccordionIndex").val());
    $("#accordion").accordion({
        heightStyle: "content",
        collapsible: false,
        heightStyle: "content",
        active: activeIndex,
        activate: function (event, ui) {
            var index = $(this).children('h4').index(ui.newHeader);
            $("#hdnVPSRFIRAccordionIndex").val(index);
        }
    });
    var tabActiveIndex = parseInt($("#hdnTabActiveIndex").val());
    $("#tabs").tabs({
        activate: function (event, ui) {
            var index = $("#tabs").tabs("option", "active");
            $("#hdnTabActiveIndex").val(index);
        },
        heightStyle: "content"
    });
    $("#tabs").tabs({ active: tabActiveIndex });
    $(".datepickerControl").Watermark('dd/mmm/yyyy');
    $(".datepickerControl").datepicker({
        showOn: "both",
        buttonImage: "../../App_Themes/images/datepicker.png",
        buttonImageOnly: true,
        buttonText: "Calendar",
        dateFormat: "dd/M/yy",
        changeMonth: true,
        changeYear: true,
        onClose: function (dateText, inst) {
            $(this).blur();
            switch ($(this)[0].id) {
                case "txtIVApplFromDate":
                    if ($("#hdnVPSAppFromDate_IV").val() != "" && $(this)[0].value == $("#hdnVPSAppFromDate_IV").val())
                        $("#btnVPSSaveIV").val(s_BtnVPSUpdateIVText).attr('title', s_BtnVPSUpdateIVTooltip);
                    else $("#btnVPSSaveIV").val(s_BtnVPSSaveIVText).attr('title', s_BtnVPSSaveIVToolTip);
                    break;
                case "txtFVApplFromDate":
                    if ($("#hdnVPSAppFromDate_FV").val() != "" && $(this)[0].value == $("#hdnVPSAppFromDate_FV").val())
                        $("#btnVPSSaveFV").val(s_BtnVPSUpdateFVText).attr('title', s_BtnVPSUpdateFVTooltip);
                    else $("#btnVPSSaveFV").val(s_BtnVPSSaveFVText).attr('title', s_BtnVPSSaveFVToolTip);
                    break;
                case "txtVPSApplicableValFromDate":
                    if ($("#hdnVPSAppFromDate_ELC").val() != "" && $(this)[0].value == $("#hdnVPSAppFromDate_ELC").val())
                        $("#btnVPSExpectedLifeSave").val(s_BtnVPSExpectedLifeUpdateText).attr('title', s_BtnVPSExpectedLifeUpdateTooltip);
                    else $("#btnVPSExpectedLifeSave").val(s_BtnVPSExpectedLifeSaveText).attr('title', s_BtnVPSExpectedLifeSaveToolTip);
                    break;
                case "txtVolatilityApplFromDate":
                    if ($("#hdnVPSAppFromDate_VC").val() != "" && $(this)[0].value == $("#hdnVPSAppFromDate_VC").val())
                        $("#btnVPSVolatilitySave").val(s_BtnVPSVolatilityUpdateText).attr('title', s_BtnVPSVolatilityUpdateTooltip);
                    else $("#btnVPSVolatilitySave").val(s_BtnVPSVolatilitySaveText).attr('title', s_BtnVPSVolatilitySaveToolTip);
                    break;
                case "txtDividendApplFromDate":
                    if ($("#hdnVPSAppFromDate_DC").val() != "" && $(this)[0].value == $("#hdnVPSAppFromDate_DC").val())
                        $("#btnDividendSave").val(s_BtnVPSDividendUpdateText).attr('title', s_BtnVPSDividendUpdateTooltip);
                    else $("#btnDividendSave").val(s_BtnVPSDividendSaveText).attr('title', s_BtnVPSDividendSaveToolTip);
                    break;
            }
        }
    });
    $("#txtVPSELEstDateOfListing").datepicker("disable");
    $("#btnRFIRDeleteAll").click(function () {
        if ($("#hdnVPSRFIRID").val() == "") {
            ShowMessageDiv("Please select record(s) to delete.", "");
            return false;
        }
        else {
            var r = confirm("Are you sure you want to delete?");
            if (r == true) {
                return true;
            } else {
                return false;
            }
        }
    });

    $("#btnRFIRCreateNew").click(function () {
        $("#divRFIRSearch").hide();
        $("#accordion").show("slide", { direction: "down" });
        $("#txtRFIREditFromDate").val('dd/mmm/yyyy').attr("style", "width: 100px; color: rgb(170, 170, 170);").datepicker("enable");
        $("#txtRFIREditSlot1to3Yrs").val('');
        $("#txtRFIREditSlot3to5Yrs").val('');
        $("#txtRFIREditSlot5to10Yrs").val('');
        $("#txtRFIREditSlot10PlusYrs").val('');
        HideMessageDiv();
        $("#hdnVPSRFIRID").val('');
        $("#btnRFIRSave").val(s_BtnRFIRSaveText).attr('title', s_BtnRFIRSaveTooltip);
        return false;
    });
    $("#btnRFIRCancel").click(function () {
        $("#accordion").hide();
        $("#divRFIRSearch").show("slide", { direction: "up" });
        HideMessageDiv();
        $("#hdnVPSRFIRID").val('');
        $("#hdnAccordionIndex").val(0);
        $("#gvVPSRFIR tr").each(function (e) {
            var checkBox = $(this).find("input[type='checkbox']");
            if (checkBox.is(':checked')) {
                checkBox[0].checked = false;
            }
        });
        for (var i in Page_Validators) {
            if (Page_Validators[i].validationGroup == "Save" || Page_Validators[i].validationGroup == "RFIRCurrency") {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                if (Page_Validators[i].controltovalidate == "txtRFIREditFromDate")
                    control.className = "cTextBox datepickerControl hasDatepicker";
                else control.className = "cTextBox";
                Page_Validators[i].style.display = "none";
                Page_Validators[i].isvalid = true;
            }
        }
        return false;
    });

    $("#btnRFIRSave").click(function () {
        Page_ClientValidate("Save");
        if (Page_IsValid) {
            Page_ClientValidate("RFIRCurrency");
            if (Page_IsValid) {
                if ($("#btnRFIRSave").val() == s_BtnRFIRUpdateText) {
                    if (confirm('Are you sure, you want to make the specific changes?')) {
                        $("#pageloaddiv").fadeIn();
                        return true;
                    }
                    else return false;
                }
                $("#pageloaddiv").fadeIn();
                return true;
            } else return false;
        } else return false;
    });
    $("#closebtnEL").click(function () {
        ClosePopupDiv();
    });
    $("#btnVPSSaveFV").click(function () {
        HideMessageDiv();
        if ($("#hdnVPSIsListed").val() == "1") {
            if ($("#lblFVSE01").is(":checked") || $("#lblFVSE02").is(":checked"))
            { }
            else {
                ShowMessageDiv(s_SelectSEMsg, "");
                return false;
            }
        }
        if ($("#lblFVDMP01").is(":checked") || $("#lblFVDMP02").is(":checked"))
        { }
        else {
            ShowMessageDiv(s_SelectDateOfMPMsg, "");
            return false;
        }
        Page_ClientValidate("FVBoth");
        if (Page_IsValid) {
            Page_ClientValidate("FVDateFormat");
            if (Page_IsValid) {
                if (parseInt($("#hdnVPS_IsApproved_FV").val()) != 1) {
                    ShowMessageDiv(s_CanNotEditSettingsMsg, "");
                    return false;
                }
                if ($("#btnVPSSaveFV").val() == s_BtnVPSUpdateFVText) {
                    if (confirm("Are You Sure you want to update the settings?") == true) {
                        $("#pageloaddiv").fadeIn();
                        return true;
                    }
                    else return false;
                } else {
                    $("#pageloaddiv").fadeIn();
                    return true;
                }
            } else return false;
        } else return false;

    });
    $("#btnVPSSaveIV").click(function () {
        HideMessageDiv();
        if ($("#hdnVPSIsListed").val() == "1") {
            if ($("#lblIVSE01").is(":checked") || $("#lblIVSE02").is(":checked"))
            { }
            else {
                ShowMessageDiv(s_SelectSEMsg, "");
                return false;
            }
        }
        if ($("#lblIVDMP01").is(":checked") || $("#lblIVDMP02").is(":checked"))
        { }
        else {
            ShowMessageDiv(s_SelectDateOfMPMsg, "");
            return false;
        }
        Page_ClientValidate("IVBoth");
        if (Page_IsValid) {
            Page_ClientValidate("IVDateFormat");
            if (Page_IsValid) {
                if (parseInt($("#hdnVPS_IsApproved_IV").val()) != 1) {
                    ShowMessageDiv(s_CanNotEditSettingsMsg, "");
                    return false;
                }
                if ($("#btnVPSSaveIV").val() == s_BtnVPSUpdateIVText) {
                    if (confirm("Are You Sure you want to update the settings?") == true) {
                        $("#pageloaddiv").fadeIn();
                        return true;
                    }
                    else return false;
                } else {
                    $("#pageloaddiv").fadeIn();
                    return true;
                }
            } else return false;
        } else return false;
    });
    $("#btnVPSExpectedLifeSave").click(function () {
        HideMessageDiv();
        if ($("#lblMCEL01").is(":checked") || $("#lblMCEL02").is(":checked") || $("#lblMCEL03").is(":checked") || $("#lblMCEL04").is(":checked")) {
            if ($("#lblMCEL02").is(":checked")) {
                if ($("#rdoELPastExerBehaviorYrs").is(":checked") || $("#rdoELPastExerBehaviorMnts").is(":checked") || $("#rdoELPastExerBehaviorDays").is(":checked")) {
                    if ($("#rdoELPastExerBehaviorYrs").is(":checked") && $.trim($("#txtELPastExerBehaviorYrs").val()) == "") {
                        ShowMessageDiv(s_EnterYearsMsg, "");
                        $("#txtELPastExerBehaviorYrs").focus();
                        return false;
                    }
                    else if ($("#rdoELPastExerBehaviorMnts").is(":checked") && $.trim($("#txtELPastExerBehaviorMnts").val()) == "") {
                        ShowMessageDiv(s_EnterMonthsMsg, "");
                        $("#txtELPastExerBehaviorMnts").focus();
                        return false;
                    }
                    else if ($("#rdoELPastExerBehaviorDays").is(":checked") && $.trim($("#txtELPastExerBehaviorDays").val()) == "") {
                        ShowMessageDiv(s_EnterDaysMsg, "");
                        $("#txtELPastExerBehaviorDays").focus();
                        return false;
                    }
                }
                else {
                    ShowMessageDiv(s_SelectOptionForPastExerMsg, "");
                    return false;
                }
            }
            if ($("#lblMCEL03").is(":checked")) {
                if ($("#rdoExpLifeYears").is(":checked") || $("#rdoExpLifeMonths").is(":checked") || $("#rdoExpLifeDays").is(":checked")) {
                    if ($("#rdoExpLifeYears").is(":checked") && $.trim($("#txtExpLifeYears").val()) == "") {
                        ShowMessageDiv(s_EnterYearsMsg, "");
                        $("#txtExpLifeYears").focus();
                        return false;
                    }
                    else if ($("#rdoExpLifeMonths").is(":checked") && $.trim($("#txtExpLifeMonths").val()) == "") {
                        ShowMessageDiv(s_EnterMonthsMsg, "");
                        $("#txtExpLifeMonths").focus();
                        return false;
                    }
                    else if ($("#rdoExpLifeDays").is(":checked") && $.trim($("#txtExpLifeDays").val()) == "") {
                        ShowMessageDiv(s_EnterDaysMsg, "");
                        $("#txtExpLifeDays").focus();
                        return false;
                    }
                }
                else {
                    ShowMessageDiv(s_SelectOptionForSpPrdMsg, "");
                    return false;
                }
            }
            else if ($("#lblMCEL04").is(":checked") && ($("#hdnVPSELEstDateOfListing").val() == "")) {
                ShowMessageDiv(s_EstDateMandatoryMsg, "");
                return false;
            }
        }
        else {
            ShowMessageDiv(s_SelectMthdForCalcELMsg, "");
            return false;
        }
        Page_ClientValidate("ExpectedLife");
        if (Page_IsValid) {
            Page_ClientValidate("ELCDateFormat");
            if (Page_IsValid) {
                if (parseInt($("#hdnVPS_IsApproved_ELC").val()) != 1) {
                    ShowMessageDiv(s_CanNotEditSettingsMsg, "");
                    return false;
                }
                if ($("#btnVPSExpectedLifeSave").val() == s_BtnVPSExpectedLifeUpdateText) {
                    if (confirm("Are You Sure you want to update the settings?") == true) {
                        $("#pageloaddiv").fadeIn();
                        return true;
                    }
                    else return false;
                } else {
                    $("#pageloaddiv").fadeIn();
                    return true;
                }
            } else return false;
        } else return false;
    });
    $("#btnVPSVolatilitySave").click(function () {
        HideMessageDiv();
        if ($("#lblVOL01").is(":checked") || $("#lblVOL02").is(":checked") || $("#lblVOL03").is(":checked")) {
        }
        else {
            ShowMessageDiv("Please select option for 'Volatility of'.", "");
            return false;
        }
        if ($("#hdnVPSIsListed").val() == "1" || $("#lblVOL02").is(":checked")) {
            if ($("#lblMPTCV01").is(":checked")) {
                if ($("#lblMPTCV01").is(":checked")) {
                    if ($("#lblTDD01").is(":checked") || $("#lblTDD02").is(":checked") || $("#lblTDD03").is(":checked")) {
                        if ($("#lblTDD03").is(":checked") && $.trim($("#txtVPSSpecifyDaysDaily").val()) == "") {
                            ShowMessageDiv(s_EnterDaysMsg, "");
                            return false;
                        }
                    }
                    else {
                        ShowMessageDiv(s_SelectTradingDaysMsg, "");
                        return false;
                    }
                }
                /*else if ($("#lblMPTCV02").is(":checked")) {
                    if ($("#lblTDW01").is(":checked") || $("#lblTDW02").is(":checked")) {
                        if ($("#lblTDW02").is(":checked") && $.trim($("#txtVPSSpecifyDaysWeekly").val()) == "") {
                            ShowMessageDiv(s_EnterDaysMsg,"");
                            return false;
                        }
                    }
                    else {
                        ShowMessageDiv(s_SelectTradingDaysMsg,"");
                        return false;
                    }
                }
                else if ($("#lblMPTCV03").is(":checked")) {
                    if ($("#lblTDA01").is(":checked") || $("#lblTDA02").is(":checked")) {
                        if ($("#lblTDW02").is(":checked") && $.trim($("#txtVPSSpecifyDaysAnnual").val()) == "") {
                            ShowMessageDiv(s_EnterDaysMsg,"");
                            return false;
                        }
                    }
                    else {
                        ShowMessageDiv(s_SelectTradingDaysMsg,"");
                        return false;
                    }
               }*/
            }
            else {
                ShowMessageDiv(s_SelectoptionForVolmsg, "");
                return false;
            }
            if ($("#lblPTCV01").is(":checked") || $("#lblPTCV02").is(":checked") || $("#lblPTCV03").is(":checked")) {
                if ($("#lblPTCV03").is(":checked")) {
                    if ($("#rdoVolatilityYears").is(":checked") || $("#rdoVolatilityMonths").is(":checked") || $("#rdoVolatilityDays").is(":checked")) {
                        if ($("#rdoVolatilityYears").is(":checked") && $.trim($("#txtVolatilityYears").val()) == "") {
                            ShowMessageDiv(s_EnterYearsMsg, "");
                            return false;
                        }
                        else if ($("#rdoVolatilityMonths").is(":checked") && $.trim($("#txtVolatilityMonths").val()) == "") {
                            ShowMessageDiv(s_EnterMonthsMsg, "");
                            return false;
                        }
                        else if ($("#rdoVolatilityDays").is(":checked") && $.trim($("#txtVolatilityDays").val()) == "") {
                            ShowMessageDiv(s_EnterDaysMsg, "");
                            return false;
                        }
                    }
                    else {
                        ShowMessageDiv(s_SpecifyPrdMsg, "");
                        return false;
                    }
                }
            }
            else {
                ShowMessageDiv(s_SelectOpForPrdToCalcVolMsg, "");
                return false;
            }
        }
        Page_ClientValidate("Volatility");
        if (Page_IsValid) {
            Page_ClientValidate("VCDateFormat");
            if (Page_IsValid) {
                if (parseInt($("#hdnVPS_IsApproved_VC").val()) != 1) {
                    ShowMessageDiv(s_CanNotEditSettingsMsg, "");
                    return false;
                }
                if ($("#btnVPSVolatilitySave").val() == s_BtnVPSVolatilityUpdateText) {
                    if (confirm("Are You Sure you want to update the settings?") == true) {
                        $("#pageloaddiv").fadeIn();
                        return true;
                    }
                    else return false;
                } else {
                    $("#pageloaddiv").fadeIn();
                    return true;
                }
            } else return false;
        } else return false;
    });
    $("#btnDividendSave").click(function () {
        HideMessageDiv();
        if ($("#lblDIV01").is(":checked") || $("#lblDIV02").is(":checked") || $("#lblDIV03").is(":checked") || $("#lblDIV04").is(":checked")) {
        }
        else {
            ShowMessageDiv("Please select option for 'Dividend'.", "");
            return false;
        }
        if ($("#lblMPTCD01").is(":checked") || $("#lblMPTCD02").is(":checked")) {
        }
        else {
            ShowMessageDiv(s_SelectOpForMPTOCalcVolMsg, "");
            return false;
        }
        Page_ClientValidate("Dividend");
        if (Page_IsValid) {
            Page_ClientValidate("DCDateFormat");
            if (Page_IsValid) {
                if (parseInt($("#hdnVPS_IsApproved_DC").val()) != 1) {
                    ShowMessageDiv(s_CanNotEditSettingsMsg, "");
                    return false;
                }
                if ($("#btnDividendSave").val() == s_BtnVPSDividendUpdateText) {
                    if (confirm("Are You Sure you want to update the settings?") == true) {
                        $("#pageloaddiv").fadeIn();
                        return true;
                    }
                    else return false;
                } else {
                    $("#pageloaddiv").fadeIn();
                    return true;
                }
            } else return false;
        } else return false;
    });
    $(".VPSVolatilityOfClass").click(function () {
        ShowHideVolatilityContent("clickEvent");
    });
    $("#btnVPSExcludeVolAdd").click(function () {
        Page_ClientValidate("ExcludeVolAdd");
        if (Page_IsValid) {
            Page_ClientValidate("VCSExcludeDateFormat");
            if (Page_IsValid) {
                var o_FromDate = $('#txtVPSExcludeFromDate').datepicker("getDate");
                var o_ToDate = $('#txtVPSExcludeToDate').datepicker("getDate");
                var curDate = new Date();
                if (o_FromDate > o_ToDate) {
                    ShowMessageDiv(s_FromToDateErrorMsg, "");
                    return false;
                } else {
                    $("#pageloaddiv").fadeIn();
                    return true;
                }
            } else return false;
        } else return false;
    });
    $(".rdoVPSDividend").click(function () {
        ShowHideVPSEncDivForGrants();
    });
    $(".divExclVolHideShow").click(function () {
        ShowHideExcludeVolSection("Click");
    });
    $(".VPSELSpecPrdFromVD").click(function () {
        ShowHideExpectedLifeControls("");
    });
    $(".VPSPrdsToCalcVolatility").click(function () {
        ShowHideCalcVolSection();
    });
    $(".MPToCalcVolClass").click(function () {
        ShowHideMPToCalcVolSection();
    });
    $(".VPSELExpcLifeSpecPrd").click(function () {
        ShowHideELExpcLifeSpecPrd();
    });
    $(".PrdToCalcVolatilityClass").click(function () {
        ShowHidePrdToCalcVolatility();
    });
    $(".TradingDaysDailyClass").click(function () {
        ShowHideTradingDaysDaily();
    });
    $(".TradingDaysWeeklyClass").click(function () {
        ShowHideTradingDaysWeekly();
    });
    $(".TradingDaysAnnualClass").click(function () {
        ShowHideTradingDaysAnnual();
    });
    $(".VPSELPastExerBehavior").click(function () {
        ShowHidePastExerBehavior("");
    });
    $("#btnVPSResetFV").click(function (event) {
        document.forms[0].reset();
        for (var i in Page_Validators) {
            if (Page_Validators[i].validationGroup == "FVBoth" || Page_Validators[i].validationGroup == "FVDateFormat") {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                if (Page_Validators[i].controltovalidate == "txtFVApplFromDate")
                    control.className = "cTextBox datepickerControl hasDatepicker";
                else control.className = "cTextBox";
                Page_Validators[i].style.display = "none";
                Page_Validators[i].isvalid = true;
            }
        }
        HideMessageDiv();
        ShowHideControlsOnPageLoad("");
        if ($("#txtFVApplFromDate").val() != "" && $("#txtFVApplFromDate").val() == $("#hdnVPSAppFromDate_FV").val())
            $("#btnVPSSaveFV").val(s_BtnVPSUpdateFVText).attr('title', s_BtnVPSUpdateFVTooltip);
        else $("#btnVPSSaveFV").val(s_BtnVPSSaveFVText).attr('title', s_BtnVPSSaveFVToolTip);
        $(".datepickerControl").Watermark('dd/mmm/yyyy');
        if ($("#txtFVApplFromDate").val() != 'dd/mmm/yyyy')
            $("#txtFVApplFromDate").attr('style', 'width: 100px !important;');
        event.preventDefault();
        return false;
    });
    $("#btnVPSResetIV").click(function (event) {
        document.forms[0].reset();
        for (var i in Page_Validators) {
            if (Page_Validators[i].validationGroup == "IVBoth" || Page_Validators[i].validationGroup == "IVDateFormat") {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                if (Page_Validators[i].controltovalidate == "txtIVApplFromDate")
                    control.className = "cTextBox datepickerControl hasDatepicker";
                else control.className = "cTextBox";
                Page_Validators[i].style.display = "none";
                Page_Validators[i].isvalid = true;
            }
        }
        HideMessageDiv();
        ShowHideControlsOnPageLoad("");
        if ($("#txtIVApplFromDate").val() != "" && $("#txtIVApplFromDate").val() == $("#hdnVPSAppFromDate_IV").val())
            $("#btnVPSSaveIV").val(s_BtnVPSUpdateIVText).attr('title', s_BtnVPSUpdateIVTooltip);
        else $("#btnVPSSaveIV").val(s_BtnVPSSaveIVText).attr('title', s_BtnVPSSaveIVToolTip);
        $(".datepickerControl").Watermark('dd/mmm/yyyy');
        if ($("#txtIVApplFromDate").val() != 'dd/mmm/yyyy')
            $("#txtIVApplFromDate").attr('style', 'width: 100px !important;');
        event.preventDefault();
        return false;
    });
    $("#btnVPSExpectedLifeReset").click(function (event) {
        document.forms[0].reset();
        for (var i in Page_Validators) {
            if (Page_Validators[i].validationGroup == "ExpectedLife" || Page_Validators[i].validationGroup == "ELCDateFormat") {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                if (Page_Validators[i].controltovalidate == "txtVPSApplicableValFromDate")
                    control.className = "cTextBox datepickerControl hasDatepicker";
                else control.className = "cTextBox";
                Page_Validators[i].style.display = "none";
                Page_Validators[i].isvalid = true;
            }
        }
        HideMessageDiv();
        ShowHideControlsOnPageLoad("");
        if ($("#txtVPSApplicableValFromDate").val() != "" && $("#txtVPSApplicableValFromDate").val() == $("#hdnVPSAppFromDate_ELC").val())
            $("#btnVPSExpectedLifeSave").val(s_BtnVPSExpectedLifeUpdateText).attr('title', s_BtnVPSExpectedLifeUpdateTooltip);
        else $("#btnVPSExpectedLifeSave").val(s_BtnVPSExpectedLifeSaveText).attr('title', s_BtnVPSExpectedLifeSaveToolTip);
        $(".datepickerControl").Watermark('dd/mmm/yyyy');
        if ($("#txtVPSApplicableValFromDate").val() != 'dd/mmm/yyyy')
            $("#txtVPSApplicableValFromDate").attr('style', 'width: 100px !important;');
        event.preventDefault();
        return false;
    });
    $("#btnVPSVolatilityReset").click(function (event) {
        document.forms[0].reset();
        for (var i in Page_Validators) {
            if (Page_Validators[i].validationGroup == "Volatility" || Page_Validators[i].validationGroup == "VCDateFormat") {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                if (Page_Validators[i].controltovalidate == "txtVolatilityApplFromDate")
                    control.className = "cTextBox datepickerControl hasDatepicker";
                else control.className = "cTextBox";
                Page_Validators[i].style.display = "none";
                Page_Validators[i].isvalid = true;
            }
        }
        HideMessageDiv();
        ShowHideControlsOnPageLoad("");
        if ($("#txtVolatilityApplFromDate").val() != "" && $("#txtVolatilityApplFromDate").val() == $("#hdnVPSAppFromDate_VC").val())
            $("#btnVPSVolatilitySave").val(s_BtnVPSVolatilityUpdateText).attr('title', s_BtnVPSVolatilityUpdateTooltip);
        else $("#btnVPSVolatilitySave").val(s_BtnVPSVolatilitySaveText).attr('title', s_BtnVPSVolatilitySaveToolTip);
        $(".datepickerControl").Watermark('dd/mmm/yyyy');
        if ($("#txtVolatilityApplFromDate").val() != 'dd/mmm/yyyy')
            $("#txtVolatilityApplFromDate").attr('style', 'width: 100px !important;');
        event.preventDefault();
        return false;
    });
    $("#btnVPSDividendReset").click(function (event) {
        document.forms[0].reset();
        for (var i in Page_Validators) {
            if (Page_Validators[i].validationGroup == "Dividend" || Page_Validators[i].validationGroup == "DCDateFormat") {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                if (Page_Validators[i].controltovalidate == "txtDividendApplFromDate")
                    control.className = "cTextBox datepickerControl hasDatepicker";
                else control.className = "cTextBox";
                Page_Validators[i].style.display = "none";
                Page_Validators[i].isvalid = true;
            }
        }
        HideMessageDiv();
        ShowHideControlsOnPageLoad("");
        if ($("#txtDividendApplFromDate").val() != "" && $("#txtDividendApplFromDate").val() == $("#hdnVPSAppFromDate_DC").val())
            $("#btnDividendSave").val(s_BtnVPSDividendUpdateText).attr('title', s_BtnVPSDividendUpdateTooltip);
        else $("#btnDividendSave").val(s_BtnVPSDividendSaveText).attr('title', s_BtnVPSDividendSaveToolTip);
        $(".datepickerControl").Watermark('dd/mmm/yyyy');
        if ($("#txtDividendApplFromDate").val() != 'dd/mmm/yyyy')
            $("#txtDividendApplFromDate").attr('style', 'width: 100px !important;');
        event.preventDefault();
        return false;
    });
    $("#btnVolatilitySave_Text").click(function () {
        HideMessageDiv();
        if ($("#lblVOL01").is(":checked") || $("#lblVOL02").is(":checked") || $("#lblVOL03").is(":checked")) {
        }
        else {
            ShowMessageDiv("Please select option for 'Volatility of'.", "");
            return false;
        }
        if ($("#hdnVPSIsListed").val() == "1") {
            if ($("#lblMPTCV01").is(":checked")) {
                if ($("#lblMPTCV01").is(":checked")) {
                    if ($("#lblTDD01").is(":checked") || $("#lblTDD02").is(":checked") || $("#lblTDD03").is(":checked")) {
                        if ($("#lblTDD03").is(":checked") && $.trim($("#txtVPSSpecifyDaysDaily").val()) == "") {
                            ShowMessageDiv(s_EnterDaysMsg, "");
                            return false;
                        }
                    }
                    else {
                        ShowMessageDiv(s_SelectTradingDaysMsg, "");
                        return false;
                    }
                }
                /*else if ($("#lblMPTCV02").is(":checked")) {
                    if ($("#lblTDW01").is(":checked") || $("#lblTDW02").is(":checked")) {
                        if ($("#lblTDW02").is(":checked") && $.trim($("#txtVPSSpecifyDaysWeekly").val()) == "") {
                            ShowMessageDiv(s_EnterDaysMsg,"");
                            return false;
                        }
                    }
                    else {
                        ShowMessageDiv(s_SelectTradingDaysMsg,"");
                        return false;
                    }
                }
                else if ($("#lblMPTCV03").is(":checked")) {
                    if ($("#lblTDA01").is(":checked") || $("#lblTDA02").is(":checked")) {
                        if ($("#lblTDW02").is(":checked") && $.trim($("#txtVPSSpecifyDaysAnnual").val()) == "") {
                           ShowMessageDiv(s_EnterDaysMsg,"");
                            return false;
                       }
                    }
                    else {
                        ShowMessageDiv(s_SelectTradingDaysMsg,"");
                        return false;
                   }
                }*/
            }
            else {
                ShowMessageDiv(s_SelectoptionForVolmsg, "");
                return false;
            }
            if ($("#lblPTCV01").is(":checked") || $("#lblPTCV02").is(":checked") || $("#lblPTCV03").is(":checked")) {
                if ($("#lblPTCV03").is(":checked")) {
                    if ($("#rdoVolatilityYears").is(":checked") || $("#rdoVolatilityMonths").is(":checked") || $("#rdoVolatilityDays").is(":checked")) {
                        if ($("#rdoVolatilityYears").is(":checked") && $.trim($("#txtVolatilityYears").val()) == "") {
                            ShowMessageDiv(s_EnterYearsMsg, "");
                            return false;
                        }
                        else if ($("#rdoVolatilityMonths").is(":checked") && $.trim($("#txtVolatilityMonths").val()) == "") {
                            ShowMessageDiv(s_EnterMonthsMsg, "");
                            return false;
                        }
                        else if ($("#rdoVolatilityDays").is(":checked") && $.trim($("#txtVolatilityDays").val()) == "") {
                            ShowMessageDiv(s_EnterDaysMsg, "");
                            return false;
                        }
                    }
                    else {
                        ShowMessageDiv(s_SpecifyPrdMsg, "");
                        return false;
                    }
                }
            }
            else {
                ShowMessageDiv(s_SelectOpForPrdToCalcVolMsg, "");
                return false;
            }
        }
        Page_ClientValidate("Volatility");
        if (Page_IsValid) {
            Page_ClientValidate("VCDateFormat");
            if (Page_IsValid) {
                if (parseInt($("#hdnVPS_IsApproved_VC").val()) != 1) {
                    ShowMessageDiv(s_CanNotEditSettingsMsg, "");
                    return false;
                }
                if ($("#btnVPSVolatilitySave").val() == s_BtnVPSVolatilityUpdateText) {
                    if (confirm("Are You Sure you want to update the settings?") == true) {
                        $("#pageloaddiv").fadeIn();
                        return true;
                    }
                    else return false;
                } else {
                    $("#pageloaddiv").fadeIn();
                    return true;
                }
            } else return false;
        } else return false;
    });
    $("#btnMPIVPreview").click(function () {
        if ($("#hdn_IsCompanyListed").val() == "1") {
            var a = Number($("#ddIVStockExtext_Rank option:selected").text());
            var b = Number($("#ddIVMarketPriceDate_Rank option:selected").text());
            if ((a + b) == 3)
                return true;
            else {
                ShowMessageDiv(s_incorrectseqOfRankMsg, "");
                HidePreviewDiv();
                return false;
            }
        }
        else
            return true;

    });
    $("#btnMPFVPreview").click(function () {
        if ($("#hdn_IsCompanyListed").val() == "1") {
            var a = Number($("#ddFVStockExtext_Rank option:selected").text());
            var b = Number($("#ddFVMarketPriceDate_Rank option:selected").text());
            if ((a + b) == 3)
                return true;
            else {
                ShowMessageDiv(s_incorrectseqOfRankMsg, "");
                HidePreviewDiv();
                return false;
            }
        }
        else
            return true;

    });
    $("#btnVolatilityPreview").click(function () {
        var Ischecked = $("#lblVOL03").prop("checked");
        if (Ischecked == false) {
            var a = Number($("#ddVolatilityOf_Rank option:selected").text());
            var b = Number($("#ddMPToCalcVol_Rank option:selected").text());
            var c = Number($("#ddPrdsToCalVol_Rank option:selected").text());
            var d = Number($("#ddExcludeVol_rank option:selected").text());
            if ((a + b + c + d) == 10)
                return true;
            else {
                ShowMessageDiv(s_incorrectseqOfRankWithCondnMsg, "");
                HidePreviewDiv();
                return false;
            }
        }
        else if (Ischecked = true) {
            var a = Number($("#ddVolatilityOf_Rank option:selected").text());
            var d = Number($("#ddExcludeVol_rank option:selected").text());
            if ((a + d) == 3)
                return true;
            else {
                ShowMessageDiv(s_incorrectseqOfRankWithCondnMsg, "");
                HidePreviewDiv();
                return false;
            }
        }
        else {
            ShowMessageDiv(s_SelectOpForVolOfMsg, "");
            HidePreviewDiv();
            return false;
        }

    });
    $("#btnDividendPreview").click(function () {
        var a = Number($("#ddDivToBeConsidered_Rank option:selected").text());
        var b = Number($("#ddSpecialDiv_Rank option:selected").text());
        var c = Number($("#ddMPDivCal_Rank option:selected").text());
        if ((a + b + c) == 6)
            return true;
        else {
            ShowMessageDiv(s_incorrectseqOfRankMsg, "");
            HidePreviewDiv();
            return false;
        }

    });
    $(".divIVHideShow").click(function () {
        SHowHideVPSIVSection("Click");
    });
    $(".divFVHideShow").click(function () {
        SHowHideVPSFVSection("Click");
    });
    $Modaldialog = $('<div id="ModalDiv"></div>').dialog({
        heightStyle: "content",
        autoOpen: false,
        resizable: false,
        draggable: false,
        height: 460,
        width: 750,
        modal: true,
        closeOnEscape: true,
        close: function () {
            CloseModalPopup(0);
        },
    });
    $("#btnVPSELEstimatedDateOfLstg").click(function () {
        OpenPopupWindow(5, "Listing Details");
        return true;
    });
    ShowHideControlsOnPageLoad("PageLoad");
    EnableDisableTabs();

    $("#btnVPSIncorpDividend").click(function () {
        HideMessageDiv();
        Page_ClientValidate("IncorpDividend");
        if (Page_IsValid) {
            var dte_FromDate = $('#txtVPSDivFromDate').datepicker("getDate");
            var dte_ToDate = $('#txtVPSDivToDate').datepicker("getDate");
            if (dte_FromDate != null && dte_ToDate != null) {
                if (dte_FromDate > dte_ToDate) {
                    ShowMessageDiv(s_FromToDateErrorMsg, "");
                    return false;
                }
            }
            return true;
        }
    });
};

function OpenPopupWindow(n_Type, modalTitle) {
    var page = "EstimatedDateDetailsPopup.aspx";
    $Modaldialog.dialog({ title: modalTitle });
    $Modaldialog.html('<iframe id="ValuationModalIframe" frameborder="0" border="0" style="border:0;" src="' + page + '" width="100%" height="100%"></iframe>');
    $Modaldialog.dialog('open');
};

function CloseModalPopup(o_Div) {
    $('#ModalDiv').dialog("close");
    $(".ui-button").click();
    $("#btnVPSClosePopup").click();
};

function EnableDisableTabs() {
    if ($("#hdnVPSEnabledTab").val() == "Market")
        $("#tabs").tabs("option", "disabled", [1, 2, 3, 4]);
    else if ($("#hdnVPSEnabledTab").val() == "Expected")
        $("#tabs").tabs("option", "disabled", [0, 2, 3, 4]);
    else if ($("#hdnVPSEnabledTab").val() == "Volatility") {
        $("#tabs").tabs("option", "disabled", [0, 1, 3, 4]);
        $("#divVPSExclVolatility").hide();
    }
    else if ($("#hdnVPSEnabledTab").val() == "Dividend")
        $("#tabs").tabs("option", "disabled", [0, 1, 2, 3]);
};

function DeleteSelectedRecords(s_SEID, o_this) {
    HideMessageDiv();
    var str1 = $("#hdnVPSRFIRID").val();
    var str2 = s_SEID;
    if (o_this.checked) {
        if (str1 == "")
            $("#hdnVPSRFIRID").val(str2 + str1);
        else $("#hdnVPSRFIRID").val(str1 + ',' + str2);
    }
    else {
        var tmp = $("#hdnVPSRFIRID").val().toString().split(",");
        var index = $.inArray(s_SEID, tmp);
        if (index !== -1) {
            tmp.splice(index, 1);
        }
        tmp = tmp.join(",")
        $("#hdnVPSRFIRID").val(tmp);
        $("#chk")[0].checked = false;
    }
};
function IsOneDecimalPoint(evt, val) {
    var character = String.fromCharCode(evt.keyCode)
    var newValue = val.value + character;
    if (isNaN(newValue) || hasDecimalPlace(newValue, 3)) {
        return false;
    }
};
function hasDecimalPlace(value, x) {
    var pointIndex = value.indexOf('.');
    return pointIndex >= 0 && pointIndex < value.length - x;
}
function SelectAllCheckBoxes(o_this) {
    HideMessageDiv();
    if (o_this.checked) {
        $("#gvVPSRFIR tr").each(function (e) {
            var checkBox = $(this).find("input[type='checkbox']");
            if (checkBox.is(':checked')) {
            }
            else {
                if (checkBox.val() != undefined) {
                    var str1 = $("#hdnVPSRFIRID").val();
                    var str2 = checkBox.val();
                    checkBox[0].checked = true;
                    if (str1 == "")
                        $("#hdnVPSRFIRID").val(str2 + str1);
                    else $("#hdnVPSRFIRID").val(str1 + ',' + str2);
                }
            }
        });
    }
    else {
        var tmp = $("#hdnVPSRFIRID").val().toString().split(",");
        $("#gvVPSRFIR tr").each(function (e) {
            var checkBox = $(this).find("input[type='checkbox']");
            var index = $.inArray(checkBox.val(), tmp);
            if (index != -1) {
                tmp.splice(index, 1);
            }
            if (checkBox.length > 0)
                checkBox[0].checked = false;
        });
        tmp = tmp.join(",");
        $("#hdnVPSRFIRID").val(tmp);
    }
};

function ShowHideVolatilityContent(o_Event) {
    if ($("#lblVOL02").is(":checked") || $("#lblVOL01").is(":checked") || $("#hdnVPSIsListed").val() == "1") {
        if ($("#lblVOL02").is(":checked"))
            $(".divVPSVCPeerCompaniesGrid").show();
        else $(".divVPSVCPeerCompaniesGrid").hide();
        $(".trVPSMPToCalcVolatility").show();
        $(".trVPSPrdsToCalcVolatility").show();
        if (o_Event == "clickEvent") {
            if (parseInt($("#hdnVPSVolPeerCompCount").val()) <= 0) {
                ShowMessageDiv(s_SelectOwnCompOrSetupPeerMsg, "");
            }
        }
    }
    else {
        $(".divVPSVCPeerCompaniesGrid").hide();
        $(".trVPSMPToCalcVolatility").hide();
        $(".trVPSPrdsToCalcVolatility").hide();
    }
};

function ShowEditPanel(n_ID, s_FromDate, s_Slot1to3, s_Slot3to5, s_Slot5to10, s_Slot10Plus, s_ToDate) {
    $("#divRFIRSearch").hide();
    $("#accordion").show("slide", { direction: "down" });
    $("#txtRFIREditFromDate").val(s_FromDate).attr("style", "width: 100px;");
    $("#txtRFIREditSlot1to3Yrs").val(s_Slot1to3.replace('%', ''));
    $("#txtRFIREditSlot3to5Yrs").val(s_Slot3to5.replace('%', ''));
    $("#txtRFIREditSlot5to10Yrs").val(s_Slot5to10.replace('%', ''));
    $("#txtRFIREditSlot10PlusYrs").val(s_Slot10Plus.replace('%', ''));
    $("#hdnVPSRFIRID").val(n_ID);
    $("#btnRFIRSave").val(s_BtnRFIRUpdateText).attr('title', s_BtnRFIRUpdateToolTip);
    $("#txtRFIREditFromDate").datepicker("disable");
    HideMessageDiv();
    return false;
};

function ShowHidePastExerBehavior() {
    if ($("#rdoELPastExerBehaviorYrs").is(":checked")) {
        $("#txtELPastExerBehaviorMnts").val('');
        $("#txtELPastExerBehaviorDays").val('');
    }
    else if ($("#rdoELPastExerBehaviorMnts").is(":checked")) {
        $("#txtELPastExerBehaviorYrs").val('');
        $("#txtELPastExerBehaviorDays").val('');
    }
    else if ($("#rdoELPastExerBehaviorDays").is(":checked")) {
        $("#txtELPastExerBehaviorYrs").val('');
        $("#txtELPastExerBehaviorMnts").val('');
    }
};

function ShowHideTradingDaysAnnual() {
    if ($("#lblTDA01").is(":checked"))
        $("#txtVPSSpecifyDaysAnnual").val('');
};

function ShowHideTradingDaysWeekly() {
    if ($("#lblTDW01").is(":checked"))
        $("#txtVPSSpecifyDaysWeekly").val('');
};

function ShowHideTradingDaysDaily() {
    if ($("#lblTDD01").is(":checked") || $("#lblTDD02").is(":checked"))
        $("#txtVPSSpecifyDaysDaily").val('');
};

function ShowHidePrdToCalcVolatility() {
    if ($("#rdoVolatilityYears").is(":checked")) {
        $("#txtVolatilityMonths").val('');
        $("#txtVolatilityDays").val('');
    }
    else if ($("#rdoVolatilityMonths").is(":checked")) {
        $("#txtVolatilityDays").val('');
        $("#txtVolatilityYears").val('');
    }
    else if ($("#rdoVolatilityDays").is(":checked")) {
        $("#txtVolatilityMonths").val('');
        $("#txtVolatilityYears").val('');
    }
};

function ShowHideELExpcLifeSpecPrd() {
    if ($("#rdoExpLifeYears").is(":checked")) {
        $("#txtExpLifeMonths").val('');
        $("#txtExpLifeDays").val('');
    }
    else if ($("#rdoExpLifeMonths").is(":checked")) {
        $("#txtExpLifeYears").val('');
        $("#txtExpLifeDays").val('');
    }
    else if ($("#rdoExpLifeDays").is(":checked")) {
        $("#txtExpLifeYears").val('');
        $("#txtExpLifeMonths").val('');
    }
};

function ShowHideControlsOnPageLoad(o_Event) {
    ShowHideVPSEncDivForGrants();
    SHowHideVPSIVSection("PageLoad");
    SHowHideVPSFVSection("PageLoad");
    ShowHidePeerCompGrid();
    ShowHideExcludeVolSection("PageLoad");
    ShowHideExpectedLifeControls();
    ShowHideCalcVolSection();
    ShowHideMPToCalcVolSection();
    ShowHideVolatilityContent("");
};

function SHowHideVPSIVSection(o_Event) {
    if (o_Event != "PageLoad") {
        if ($(".trVPSIntriValue").is(":hidden")) {
            $(".trVPSIntriValue").slideDown("slow");
            $(".imgIVHideShow").attr('src', '../../App_Themes/images/up.png');
            $(".imgIVHideShow").attr('title', 'Click here to collapse');
        } else {
            $(".trVPSIntriValue").slideUp("slow");
            $(".imgIVHideShow").attr('src', '../../App_Themes/images/down.png');
            $(".imgIVHideShow").attr('title', 'Click here to expand');
        }
    }
};

function SHowHideVPSFVSection(o_Event) {
    if (o_Event != "PageLoad") {
        if ($(".trVPSFairValue").is(":hidden")) {
            $(".trVPSFairValue").slideDown("slow");
            $(".imgFVHideShow").attr('src', '../../App_Themes/images/up.png');
            $(".imgFVHideShow").attr('title', 'Click here to collapse');
        } else {
            $(".trVPSFairValue").slideUp("slow");
            $(".imgFVHideShow").attr('src', '../../App_Themes/images/down.png');
            $(".imgFVHideShow").attr('title', 'Click here to expand');
        }
    }
};

function ShowHideVPSEncDivForGrants() {
    if ($("#lblDIV04").is(":checked")) {
        for (var i in Page_Validators) {
            if (Page_Validators[i].validationGroup == "IncorpDividend") {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                if (Page_Validators[i].controltovalidate == "txtVPSDivFromDate" || Page_Validators[i].controltovalidate == "txtVPSDivToDate")
                    control.className = "cTextBox datepickerControl hasDatepicker";
                else control.className = "cTextBox";
                Page_Validators[i].style.display = "none";
                Page_Validators[i].isvalid = true;
            }
        }
        $(".divVPSEncDivForGrants").show();
    }
    else {
        $(".divVPSEncDivForGrants").hide();
        $("#txtVPSDivFromDate").attr("style", "width: 100px; color: rgb(170, 170, 170);").val('dd/mmm/yyyy');
        $("#txtVPSDivToDate").attr("style", "width: 100px; color: rgb(170, 170, 170);").val('dd/mmm/yyyy');
        $("#txtVPSDivDividend").val('');

    }
    if ($("#lblDIV03").is(":checked"))
        $(".divVPSVolAvgDividend").show();
    else $(".divVPSVolAvgDividend").hide();
};

function ShowHidePeerCompGrid() {
    if ($("#lblVOL02").is(":checked") || $("#lblVOL01").is(":checked")) {
        if ($("#lblVOL02").is(":checked"))
            $(".divVPSVCPeerCompaniesGrid").show();
        else $(".divVPSVCPeerCompaniesGrid").hide();
        $(".trVPSMPToCalcVolatility").show();
        $(".trVPSPrdsToCalcVolatility").show();
    }
    else {
        $(".divVPSVCPeerCompaniesGrid").hide();
        $(".trVPSMPToCalcVolatility").hide();
        $(".trVPSPrdsToCalcVolatility").hide();
    }
};

function ShowHideExcludeVolSection(o_Event) {
    if (o_Event != "PageLoad") {
        if ($(".divVPSVolExcludeVol").is(":hidden")) {
            $(".divVPSVolExcludeVol").slideDown("slow");
            $(".chkVPSVolExcludeVol").attr('src', '../../App_Themes/images/up.png');
            $(".chkVPSVolExcludeVol").attr('title', 'Click here to collapse');
            $("#btnVPSExcludeVolAdd").focus();
        } else {
            $(".divVPSVolExcludeVol").slideUp("slow");
            $(".chkVPSVolExcludeVol").attr('src', '../../App_Themes/images/down.png');
            $(".chkVPSVolExcludeVol").attr('title', 'Click here to expand');
            $("#btnVPSVolatilitySave").focus();
            for (var i in Page_Validators) {
                if (Page_Validators[i].validationGroup == "ExcludeVolAdd") {
                    var control = document.getElementById(Page_Validators[i].controltovalidate);
                    if (Page_Validators[i].controltovalidate == "txtVPSExcludeFromDate" || Page_Validators[i].controltovalidate == "txtVPSExcludeToDate")
                        control.className = "cTextBox datepickerControl hasDatepicker";
                    else control.className = "cTextBox";
                    Page_Validators[i].style.display = "none";
                    Page_Validators[i].isvalid = true;
                }
            }
        }
    }
};

function ShowHideExpectedLifeControls() {
    if ($("#lblMCEL03").is(":checked")) {
        $(".divVPSELSpecPrdFromVD").show();
        $("#lblMCEL03").prop('checked', true);
        $("#rdoELPastExerBehaviorYrs").prop('checked', false);
        $("#txtELPastExerBehaviorMnts").val('');
        $("#txtELPastExerBehaviorDays").val('');
        $("#rdoELPastExerBehaviorMnts").prop('checked', false);
        $("#txtELPastExerBehaviorYrs").val('');
        $("#txtELPastExerBehaviorDays").val('');
        $("#rdoELPastExerBehaviorDays").prop('checked', false);
        $("#txtELPastExerBehaviorYrs").val('');
        $("#txtELPastExerBehaviorMnts").val('');
        ShowHideELExpcLifeSpecPrd();
    }
    else $(".divVPSELSpecPrdFromVD").hide();
    if ($("#lblMCEL04").is(":checked")) {
        $(".divVPSELEstDateOfListingTxt").show();
        HideAllControls();
    }
    else $(".divVPSELEstDateOfListingTxt").hide();
    if ($("#lblMCEL02").is(":checked")) {
        $(".divVPSELPastExerBehavior").show();
        $("#lblMCEL02").prop('checked', true);
        $("#rdoExpLifeYears").prop('checked', false);
        $("#txtExpLifeMonths").val('');
        $("#txtExpLifeDays").val('');
        $("#rdoExpLifeMonths").prop('checked', false);
        $("#txtExpLifeYears").val('');
        $("#txtExpLifeDays").val('');
        $("#rdoExpLifeDays").prop('checked', false);
        $("#txtExpLifeYears").val('');
        $("#txtExpLifeMonths").val('');
        ShowHidePastExerBehavior();
    }
    else $(".divVPSELPastExerBehavior").hide();
    if ($("#lblMCEL01").is(":checked"))
        HideAllControls();
};

function HideAllControls() {
    $("#rdoELPastExerBehaviorYrs").prop('checked', false);
    $("#txtELPastExerBehaviorMnts").val('');
    $("#txtELPastExerBehaviorDays").val('');
    $("#rdoELPastExerBehaviorMnts").prop('checked', false);
    $("#txtELPastExerBehaviorYrs").val('');
    $("#txtELPastExerBehaviorDays").val('');
    $("#rdoELPastExerBehaviorDays").prop('checked', false);
    $("#txtELPastExerBehaviorYrs").val('');
    $("#txtELPastExerBehaviorMnts").val('');
    $("#rdoExpLifeYears").prop('checked', false);
    $("#txtExpLifeMonths").val('');
    $("#txtExpLifeDays").val('');
    $("#rdoExpLifeMonths").prop('checked', false);
    $("#txtExpLifeYears").val('');
    $("#txtExpLifeDays").val('');
    $("#rdoExpLifeDays").prop('checked', false);
    $("#txtExpLifeYears").val('');
    $("#txtExpLifeMonths").val('');
}

function ShowHideCalcVolSection() {
    if ($("#lblPTCV03").is(":checked")) {
        $(".divVPSPrdsToCalcVolSpcPrd").show();
        ShowHidePrdToCalcVolatility();
    }
    else {
        $(".divVPSPrdsToCalcVolSpcPrd").hide();
        $("#rdoVolatilityYears").prop('checked', false);
        $("#txtVolatilityMonths").val('');
        $("#txtVolatilityDays").val('');
        $("#rdoVolatilityMonths").prop('checked', false);
        $("#txtVolatilityDays").val('');
        $("#txtVolatilityYears").val('');
        $("#rdoVolatilityDays").prop('checked', false);
        $("#txtVolatilityMonths").val('');
        $("#txtVolatilityYears").val('');
    }
};

function ShowHideMPToCalcVolSection() {
    if ($("#lblMPTCV01").is(":checked"))
        $(".trDailyTradingDays").show();
    else $(".trDailyTradingDays").hide();
    /*if ($("#lblMPTCV02").is(":checked"))
        $(".trWeeklyTradingDays").show();
    else $(".trWeeklyTradingDays").hide();
    if ($("#lblMPTCV03").is(":checked"))
        $(".trAnnualTradingDays").show();
    else $(".trAnnualTradingDays").hide();*/
};

function ViewHistoryData(s_ConfigID, s_FromDate, s_ToDate, s_Type) {
    $.ajax({
        type: "POST",
        url: "ValuationParameters.aspx/BindHistoryGridByID",
        data: "{'s_ConfigID':" + JSON.stringify(s_ConfigID) + ",'s_Type':" + JSON.stringify(s_Type) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        processData: false,
        success: function (data) {
            var v_HTMLStr = "", v_HeaderText = "";
            switch (s_Type) {
                case "MPC_IV":
                    v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" rules=\"all\" border=\"1\" id=\"gvMarketPriceIV\" style=\"border-collapse: collapse; font-size: 75%;\"><tr class=\"gridHeader\">";
                    v_HTMLStr += "<th scope=\"col\">Stock Exchange</th><th scope=\"col\">Date of Market Price</th><th scope=\"col\">Remark</th><th scope=\"col\">Approval Status</th></tr>";
                    for (var i = 0; i < data.d.length; i++) {
                        var s_IsApproved = data.d[i].MPC_IS_APPROVED ? "Approved" : "Pending";
                        v_HTMLStr += "<tr class=\"gridItems\"><td>" + data.d[i].MPC_STOCK_EX_LABEL_ID + "</td>";
                        v_HTMLStr += "<td>" + data.d[i].MPC_MARKET_PRICE_DT_LABEL_ID + "</td>";
                        v_HTMLStr += "<td style=\"text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;\">" + data.d[i].MPC_REMARK + "</td>";
                        v_HTMLStr += "<td align=\"center\">" + s_IsApproved + "</td></tr>";
                        if (v_HeaderText == "") {
                            if (data.d[i].MPC_TO_DATE == "")
                                v_HeaderText = "History ( " + data.d[i].MPC_APPLICABLE_FROM_DATE + " - Present )";
                            else v_HeaderText = "History ( " + data.d[i].MPC_APPLICABLE_FROM_DATE + " - " + data.d[i].MPC_TO_DATE + " )";
                        }
                    };
                    break;
                case "MPC_FV":
                    v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" rules=\"all\" border=\"1\" id=\"gvMarketPriceIV\" style=\"border-collapse: collapse; font-size: 75%;\"><tr class=\"gridHeader\">";
                    v_HTMLStr += "<th scope=\"col\">Stock Exchange</th><th scope=\"col\">Date of Market Price</th><th scope=\"col\">Remark</th><th scope=\"col\">Approval Status</th></tr>";
                    for (var i = 0; i < data.d.length; i++) {
                        var s_IsApproved = data.d[i].MPC_IS_APPROVED ? "Approved" : "Pending";
                        v_HTMLStr += "<tr class=\"gridItems\"><td>" + data.d[i].MPC_STOCK_EX_LABEL_ID + "</td>";
                        v_HTMLStr += "<td>" + data.d[i].MPC_MARKET_PRICE_DT_LABEL_ID + "</td>";
                        v_HTMLStr += "<td style=\"text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;\">" + data.d[i].MPC_REMARK + "</td>";
                        v_HTMLStr += "<td align=\"center\">" + s_IsApproved + "</td></tr>";
                        if (v_HeaderText == "") {
                            if (data.d[i].MPC_TO_DATE == "")
                                v_HeaderText = "History ( " + data.d[i].MPC_APPLICABLE_FROM_DATE + " - Present )";
                            else v_HeaderText = "History ( " + data.d[i].MPC_APPLICABLE_FROM_DATE + " - " + data.d[i].MPC_TO_DATE + " )";
                        }
                    };
                    break;
                case "ELC":
                    v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" rules=\"all\" border=\"1\" id=\"gvMarketPriceIV\" style=\"border-collapse: collapse; font-size: 75%;\"><tr class=\"gridHeader\">";
                    v_HTMLStr += "<th scope=\"col\">Method for Calculating Expected Life</th><th scope=\"col\">File Name</th><th scope=\"col\">Remark</th><th scope=\"col\">Approval Status</th></tr>";
                    for (var i = 0; i < data.d.length; i++) {
                        var s_IsApproved = data.d[i].ELC_IS_APPROVED ? "Approved" : "Pending";
                        v_HTMLStr += "<tr class=\"gridItems\"><td>" + data.d[i].ELC_CAL_METHOD_LABEL_ID + "</td>";
                        v_HTMLStr += "<td><a title=\"Click here to download\" class=\"cHyperLinksp\" onclick=\"return DownloadFileFromServer('" + data.d[i].ELC_FILE_PATH + "','" + data.d[i].ELC_FILE_NAME + "')\">" + data.d[i].ELC_FILE_NAME + "</a></td>";
                        v_HTMLStr += "<td style=\"text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;\">" + data.d[i].ELC_REMARK + "</td>";
                        v_HTMLStr += "<td align=\"center\">" + s_IsApproved + "</td></tr>";
                        if (v_HeaderText == "") {
                            if (data.d[i].ELC_TO_DATE == "")
                                v_HeaderText = "History ( " + data.d[i].ELC_APPLICABLE_FROM_DATE + " - Present )";
                            else v_HeaderText = "History ( " + data.d[i].ELC_APPLICABLE_FROM_DATE + " - " + data.d[i].ELC_TO_DATE + " )";
                        }
                    };
                    break;
                case "VC":
                    v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" rules=\"all\" border=\"1\" id=\"gvMarketPriceIV\" style=\"border-collapse: collapse; font-size: 75%;\"><tr class=\"gridHeader\">";
                    v_HTMLStr += "<th scope=\"col\">Volatility of</th><th scope=\"col\">Market Price to Calculate Volatility</th><th scope=\"col\">Periods to Calculate Volatility</th><th scope=\"col\">Remark</th><th scope=\"col\">Approval Status</th></tr>";
                    for (var i = 0; i < data.d.length; i++) {
                        var s_IsApproved = data.d[i].VC_IS_APPROVED ? "Approved" : "Pending";
                        v_HTMLStr += "<tr class=\"gridItems\"><td>" + data.d[i].VC_VOLATILITY_OF_LABEL_ID + "</td>";
                        v_HTMLStr += "<td>" + data.d[i].VC_MP_CALC_VOLATILITY_LABEL_ID + "</td>";
                        v_HTMLStr += "<td>" + data.d[i].VC_PRD_CALC_VOLATILITY_LABEL_ID + "</td>";
                        v_HTMLStr += "<td style=\"text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;\">" + data.d[i].VC_REMARK + "</td>";
                        v_HTMLStr += "<td align=\"center\">" + s_IsApproved + "</td></tr>";
                        if (v_HeaderText == "") {
                            if (data.d[i].VC_TO_DATE == "")
                                v_HeaderText = "History ( " + data.d[i].VC_APPLICABLE_FROM_DATE + " - Present )";
                            else v_HeaderText = "History ( " + data.d[i].VC_APPLICABLE_FROM_DATE + " - " + data.d[i].VC_TO_DATE + " )";
                        }
                    };
                    break;
                case "DC":
                    v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" rules=\"all\" border=\"1\" id=\"gvMarketPriceIV\" style=\"border-collapse: collapse; font-size: 75%;\"><tr class=\"gridHeader\">";
                    v_HTMLStr += "<th scope=\"col\" width=\"250px\">Dividend</th><th scope=\"col\">Special Dividend</th><th scope=\"col\">Market Price to Calculate Dividend Yield</th><th scope=\"col\">Remark</th><th scope=\"col\">Approval Status</th></tr>";
                    for (var i = 0; i < data.d.length; i++) {
                        var s_IsApproved = data.d[i].DC_IS_APPROVED ? "Approved" : "Pending";
                        v_HTMLStr += "<tr class=\"gridItems\"><td>" + data.d[i].DC_DIVIDEND_LABEL_ID + "</td>";
                        v_HTMLStr += "<td>" + data.d[i].DC_SPECIAL_DIVIDEND + "</td>";
                        v_HTMLStr += "<td>" + data.d[i].DC_MP_TO_CAL_DIVIDEND_LABEL_ID + "</td>";
                        v_HTMLStr += "<td style=\"text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;\">" + data.d[i].DC_REMARK + "</td>";
                        v_HTMLStr += "<td align=\"center\">" + s_IsApproved + "</td></tr>";
                        if (v_HeaderText == "") {
                            if (data.d[i].DC_TO_DATE == "")
                                v_HeaderText = "History ( " + data.d[i].DC_APPLICABLE_FROM_DATE + " - Present )";
                            else v_HeaderText = "History ( " + data.d[i].DC_APPLICABLE_FROM_DATE + " - " + data.d[i].DC_TO_DATE + " )";
                        }
                    };
                    break;
            }
            v_HTMLStr += "</table>";
            $("#divHistoryDetails").html(v_HTMLStr);
            $("#lblCSStatusHistory").text(v_HeaderText);
            OpenPopupDiv();
        },
        failure: function (data) {
            alert('fail');
        },
        error: function (data) {
            alert('error')
        }
    });
};

function SetRFIRFileDownloadHdnFields(s_ServerPath, s_FileName) {
    $("#hdnVPSRFIRFileServerPath").val(s_ServerPath);
    $("#hdnVPSRFIRFileName").val(s_FileName);
    $("#btnRFIRDownload").trigger("click");
    return false;
};

function DownloadFileFromServer(s_FilePath, s_FileName) {
    $("#hdnVPSESFileServerPath").val(s_FilePath);
    $("#hdnVPSELFileName").val(s_FileName);
    $("#btnVPSESFileDownload").trigger("click");
    return false;
};
