﻿function pageLoad() {
    LoadScript();
    $("#closebtnEL").click(function () {
        ClosePopupDiv();
    });

    var optionTarget;
    $(".datepickerControl").Watermark('dd/mmm/yyyy');
    var activeIndex = parseInt($("#hdnAccordionIndex").val());
    $("#accordion").accordion({
        collapsible: false,
        heightStyle: "content",
        active: activeIndex,
        activate: function (event, ui) {
            var index = $(this).children('h3').index(ui.newHeader);
            $("#hdnAccordionIndex").val(index);
        }
    });
    $(".datepickerControl").datepicker({
        showOn: "both",
        buttonImage: "../../App_Themes/images/datepicker.png",
        buttonImageOnly: true,
        buttonText: "Calendar",
        dateFormat: "dd/M/yy",
        changeMonth: true,
        changeYear: true,
        onClose: function (dateText, inst) {
            $(this).blur();
            switch ($(this)[0].id) {

            }
        }
    });

    function ShowDetails(o_this) {
        $(o_this).closest('tr').next('tr.gvChildGrid').toggle(1000);
        return false;
    };

   
    $(".h3AddEdit").click(function () {
        $("#divAddEdit").hide();
        var current = $("#accordion").accordion("option", "active");
        if (current == 1) {
            var next = current - 1 < 0 ? count : current - 1;
            $("#accordion").accordion("option", "active", next);
        }
        else {
            $("#accordion").accordion({
                collapsible: false
            });
        }
        $(".h3AddEdit").hide();
    });
    $("#h3Search").click(function () {
        HideMessageDiv();
        $("#hdnAccordionIndex").val('0');
        for (var i in Page_Validators) {
            try {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                control.className = "cTextBox";
                Page_Validators[i].style.display = "none";
                Page_Validators[i].isvalid = true;
            }
            catch (e)
            { }
        }
        $(".h3AddEdit").hide();
        $("#divAddEdit").hide();
        $("#divSearch").show();
    });


    $("#chkAPams").click(function () {
        if ($(this).is(":checked"))
        {
            $(".divASPToCalacHCost").show();
            $("#btnSNext").val(s_BtnSNext).attr('title', s_BtnSNextTooltip);
        }
        else
            $(".divASPToCalacHCost").hide();
    });

} 