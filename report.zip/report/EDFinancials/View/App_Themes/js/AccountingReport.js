﻿function pageLoad() {
    LoadScript();

    $(".datepickerControl").datepicker({
        showOn: "both",
        buttonImage: "../../App_Themes/images/datepicker.png",
        buttonImageOnly: true,
        buttonText: "Calendar",
        dateFormat: "dd/M/yy",
        changeMonth: true,
        changeYear: true,
        onClose: function (dateText, inst) {
            $(this).blur();
            DateChangeEvent();
        }
    });
    var v_ARAccordionIndex = parseInt($("#hdnARAccordionIndex").val());
    $(".datepickerControl").Watermark('dd/mmm/yyyy');
    $("#divARAccordion").accordion({
        heightStyle: "content",
        collapsible: false,
        heightStyle: "content",
        active: v_ARAccordionIndex,
        activate: function (event, ui) {
            var index = $(this).children('h3').index(ui.newHeader);
            $("#hdnARAccordionIndex").val(index);
        }
    });
    $("#h4ARSearchPanel").click(function (event, ui) {
        $("#hdnARAccordionIndex").val(0);
        $("#btnARCancelReport").click();
    });
    $(".h4ARAddEditPanel").click(function () {
        $(".h4ARViewWorkingsPanel").hide();
    });
    $(".divARAdvanceSearch").click(function () {
        ShowHideAdvanceSearchSection("Click");
    });
    ShowHideAdvanceSearchSection("PageLoad");
    $("#btnARViewReport").click(function () {
        HideMessageDiv();
        Page_ClientValidate("MainReport");
        if (Page_IsValid) {
            Page_ClientValidate("MainReportDateFormat");
            if (Page_IsValid) {
                var dte_FromDate;
                var dte_ToDate;
                if ($('#txtARGrantFromDate').val() != 'dd/mmm/yyyy' && $('#txtARGrantToDate').val() != 'dd/mmm/yyyy' && $('#txtARGrantFromDate').val() != '' && $('#txtARGrantToDate').val() != '') {
                    dte_FromDate = $('#txtARGrantFromDate').datepicker("getDate");
                    dte_ToDate = $('#txtARGrantToDate').datepicker("getDate");
                    if (dte_FromDate > dte_ToDate) {
                        ShowMessageDiv("'Grant To' cannot be earlier than 'Grant From' Date.", "");
                        return false;
                    }
                }
                if ($('#ddlARFinancialYrFrom').val() != '' && $('#ddlARFinancialYrFrom').val() != '0' && $('#ddlARFinancialYrFrom').val() != '--- Please Select'
                    && $('#ddlARFinancialYrTo').val() != '' && $('#ddlARFinancialYrTo').val() != '0' && $('#ddlARFinancialYrTo').val() != '--- Please Select') {
                    dte_FromDate = $('#ddlARFinancialYrFrom').val().split('-');
                    dte_ToDate = $('#ddlARFinancialYrTo').val().split('-');
                    if (dte_FromDate[0] != "" && dte_ToDate[0] != "" && (dte_FromDate[0] > dte_ToDate[0])) {
                        ShowMessageDiv("'Financial Year To' cannot be earlier than 'Financial Year From'.", "");
                        return false;
                    }
                    else if (dte_FromDate[0] != "" && (dte_FromDate[0] > $('#txtARDate').val().split('/')[2])) {
                        ShowMessageDiv("'Financial Year From' cannot be later than 'Reporting Year - " + $('#txtARDate').val().split('/')[2] + "'.", "");
                        return false;
                    }
                    else if (dte_ToDate[1] != "" && (dte_ToDate[1] < $('#txtARDate').val().split('/')[2])) {
                        ShowMessageDiv("'Financial Year To' cannot be earlier than the financial year pertaining to the Accounting Report Date which is in the financial year " + $('#txtARDate').val().split('/')[2] + "-" + parseInt(parseInt($('#txtARDate').val().split('/')[2]) + 1) + "'.", "");
                        return false;
                    }
                }
                else if ($('#ddlARFinancialYrFrom').val() != '' && $('#ddlARFinancialYrFrom').val() != '0' && $('#ddlARFinancialYrFrom').val() != '--- Please Select') {
                    dte_FromDate = $('#ddlARFinancialYrFrom').val().split('-');
                    if (dte_FromDate[0] > $('#txtARDate').val().split('/')[2]) {
                        ShowMessageDiv("'Financial Year From' cannot be later than 'Reporting Year - " + $('#txtARDate').val().split('/')[2] + "'.", "");
                        return false;
                    }
                }
                else if ($('#ddlARFinancialYrTo').val() != '' && $('#ddlARFinancialYrTo').val() != '0' && $('#ddlARFinancialYrTo').val() != '--- Please Select') {
                    dte_ToDate = $('#ddlARFinancialYrTo').val().split('-');
                    if (dte_ToDate[1] < $('#txtARDate').val().split('/')[2]) {
                        ShowMessageDiv("'Financial Year To' cannot be earlier than 'Reporting Year - " + $('#txtARDate').val().split('/')[2] + "'.", "");
                        return false;
                    }
                }
                $("#pageloaddiv").fadeIn();
                return true;
            } else return false;
        } else return false;
    });
    $("#btnARViewWorkings").click(function () {
        var current = $("#divARAccordion").accordion("option", "active");
        var next = current + 1 < 0 ? count : current + 1;
        $("#divARAccordion").accordion("option", "active", next);
        $(".h4ARAddEditPanel").show();
        $(".h4ARViewWorkingsPanel").show();
        return false;
    });
    $("#btnARBackViewWorkings").click(function () {
        var current = $("#divARAccordion").accordion("option", "active");
        var next = current - 1 < 0 ? count : current - 1;
        $("#divARAccordion").accordion("option", "active", next);
        $(".h4ARAddEditPanel").show();
        $(".h4ARViewWorkingsPanel").hide();
        return false;
    });
    $("#btnARCreateReport").click(function () {
        var var_RptDates;
        var OPGLIst = $("#hdnOPList").val();
        var CorpApplied = $("#hdnCAAppliedOnDate").val();
        $("#gvARDetails tr").each(function (e) {
            if ($(this).closest('tr').find('td:eq(0)').text() != '')
                var_RptDates = var_RptDates + "," + $(this).closest('tr').find('td:eq(0)').text();;
        });
        var var_tmp = var_RptDates.split(",");
        var var_index = $.inArray($("#txtARDate").val(), var_tmp)

        if (var_index !== -1)
            ShowMessageDiv($("#hdnARCantCreateRptForSameDate").val(), "red");
        else {
            var b_IsoptionDetailsAdd = false, b_IsCAAdded = false;
            //if (OPGLIst != "") {
            //    if (confirm('Option details for Grant ' + $("#hdnOPList").val() + ' have not been updated as on the date of generation of report. Are you sure you want to continue generating the report?')) {
            //        //  $("#pageloaddiv").fadeIn();
            //        b_IsoptionDetailsAdd = true;
            //    } else return false;
            //}
            if (CorpApplied == "True") {
                if (confirm('Apply the Corporate action prior to Accounting Report Date to create this report.')) {
                    b_IsCAAdded = true;
                } else return false;
            }
            else {
                $(".divARSelectTemplate").show();
                $("#btnARCreateReport").attr("disabled", true);
            }

            if (b_IsCAAdded) {
                $(".divARSelectTemplate").show();
                $("#btnARCreateReport").attr("disabled", true);
            }
        }
        return false;
    });
    $("tr.gvChildGrid").hide();
    $("#btnARWorkingDownload").click(function () {
        debugger;
        $("#pageloaddiv").fadeIn();
        var QueryString = $("#hdnAR_SSRSQueryString").val();
        var CallFor = "btnARWorkingDownload";
        $.ajax({
            type: "POST",
            url: "AccountingReport.aspx/SSRSReportScheduling",
            data: "{'o_GrantRegID':" + JSON.stringify(QueryString) + " ,'o_CallFOR':" + JSON.stringify(CallFor) + "}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processData: false,
            success: function (data) {
                debugger;
                if (data.d == "Success") {
                    $("#lblReportSchSubscription").removeAttr("style");
                    $("#pageloaddiv").fadeOut();
                }
                else if (data.d == "Failure") {
                    debugger;
                    alert("Error occured while report scheduling.");
                    $("#pageloaddiv").fadeOut();
                }
                else if (data.d == "Exists") {
                    alert("Report has been already created for this reporting date. In Case of change in any data click on Re-download report Button.Then click on Refresh button to download report.");
                    $("#pageloaddiv").fadeOut();
                }
            },
            failure: function (data) {
                $("#divRefresh").hide();
                $("#pageloaddiv").fadeOut();
            },
            error: function (data) {
                $("#divRefresh").hide();
                $("#pageloaddiv").fadeOut();
            }
        });
        return false;
    });
    
    $("#btnARWDownloadNew").click(function () {
        $("#pageloaddiv").fadeIn();
        var QueryString = $("#hdnAR_SSRSQueryString").val();
        var CallFor = "btnARWDownloadNew";
        $.ajax({
            type: "POST",
            url: "AccountingReport.aspx/SSRSReportScheduling",
            data: "{'o_GrantRegID':" + JSON.stringify(QueryString) + " ,'o_CallFOR':" + JSON.stringify(CallFor) + "}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processData: false,
            success: function (data) {
                if (data.d == "Success") {
                    $("#lblReportSchSubscription").removeAttr("style");
                    $("#pageloaddiv").fadeOut();
                }
                else if (data.d == "Failure") {
                    alert("Error occured while report scheduling.");
                    $("#pageloaddiv").fadeOut();
                }
                else if (data.d == "Exists") {
                    alert("Report has been already created for this reporting date.Click on Refresh button to download report.");
                    $("#pageloaddiv").fadeOut();
                }
            },
            failure: function (data) {
                $("#divRefresh").hide();
                $("#pageloaddiv").fadeOut();
            },
            error: function (data) {
                $("#divRefresh").hide();
                $("#pageloaddiv").fadeOut();
            }
        });
        return false;
    });

    $("#btnARViewCancellationWorking").click(function () {
        var QueryString = $("#hdnAR_SSRSStrForCancellation").val();
        if (QueryString != "") {
            var newWin = window.open(s_ReportURL + QueryString, "EDReports", "toolbar=0,location=0,menubar=0,status=0,scrollbars=yes,copyhistory=0,height=550,width=800,modal=yes,alwaysRaised=yes,resizable=1");
            if (newWin != null) {
                newWin.focus();
                void (0);
            }
        }
        return false;
    });
    $Modaldialog = $('<div id="ModalDiv"></div>').dialog({
        heightStyle: "content",
        autoOpen: false,
        resizable: false,
        draggable: false,
        height: 600,
        width: 850,
        modal: true,
        closeOnEscape: true,
        close: function () {
        },
    });
    $("#closebtnEL").click(function () {
        ClosePopupDiv();
    });

    $("tr.gvReconChildGridView_ColumnCell_a").hide();
    $("tr.gvReconChildGridView_ColumnCell_b").hide();
    $("tr.gvReconChildGridView_ColumnCell_c").hide();
    $("tr.gvReconChildGridView_ColumnCell_f").hide();

    $("#btnARViewReconciliation").click(function () {
        var var_Page = "AccReportingReconPopUp.aspx?RptDate=" + $("#txtARDate").val() + "&DispCostBefore=" + $("#rdoARDisplayCostBefore input:checked").val() + "&DispCostAfter=" + $("#rdoARDisplayCostAfter input:checked").val();
        $Modaldialog.dialog({ title: 'Reconciliation Workings' });
        $Modaldialog.html('<iframe id="AccReportingReconModalIframe" frameborder="0" border="0" style="border:0;" src="' + var_Page + '" width="100%;" height="100%;"></iframe>');
        $Modaldialog.dialog('option', 'width', 1000);
        $Modaldialog.dialog('open');
        return false;
    });

    $("#btnARViewAccParameters").click(function () {
        var page = "AccountingParameters.aspx?PageName=AccountingReport";
        $Modaldialog.dialog({ title: 'Accounting Parameters' });
        $Modaldialog.html('<iframe id="AccountingModalIframe" frameborder="0" border="0" style="border:0;" src="' + page + '" width="100%" height="100%"></iframe>');
        $Modaldialog.dialog('option', 'width', 850);
        $Modaldialog.dialog('open');
        return false;
    });

    $("#btnARViewForfitParams").click(function () {
        var page = "ForfeitureSetup.aspx?PageName=AccountingReport";
        $Modaldialog.dialog({ title: 'Forfeiture  Parameters' });
        $Modaldialog.html('<iframe id="AccountingModalIframe" frameborder="0" border="0" style="border:0;" src="' + page + '" width="100%" height="100%"></iframe>');
        $Modaldialog.dialog('option', 'width', 850);
        $Modaldialog.dialog('open');
        return false;
    });

    $("#btnARViewSummaryWorking").click(function () {
        var var_Page = "AccSummaryWorkingsReport.aspx?RptDate=" + $("#txtARDate").val();
        $Modaldialog.dialog({ title: 'Summary Workings Report' });
        $Modaldialog.html('<iframe id="AccSUMMARYReportingModalIframe" frameborder="0" border="0" style="border:0;" src="' + var_Page + '" width="100%;" height="100%;"></iframe>');
        $Modaldialog.dialog('option', 'width', 1000);
        $Modaldialog.dialog('open');
        return false;
    });

    $("#btnARTemplateSendForReview").click(function () {
        $("#pageloaddiv").fadeIn();
        return true;
    });
    $("#btnARCreateAccReport").click(function () {
        $("#hdnARACC_RPT_GRP_ID").val("");
        $("#pageloaddiv").fadeIn();
        return true;
    });
    $("#btnARReset").click(function () {
        $("#pageloaddiv").fadeIn();
        return true;
    });
    $("#btnARReviewerApprove").click(function () {
        $("#pageloaddiv").fadeIn();
        return true;
    });
    $("#btnARReviewerDisApprove").click(function () {
        $("#pageloaddiv").fadeIn();
        return true;
    });
    $("#btnARClientApprove").click(function () {
        $("#pageloaddiv").fadeIn();
        return true;
    });
    $("#btnARClientDisApprove").click(function () {
        $("#pageloaddiv").fadeIn();
        return true;
    });
    $("#rdoARDisplayCostFor").change(function (e) {
        HideShowFyncYr("change");
        return false;
    });

    if ($("#dhnARIsIVFVCalcModal").val() == "true") {
        OpenPopupDiv();
        $(".divARIVFVCalculations").show();
        $("#h4ARViewWorkingsPanel").show();
        $("#dhnARIsIVFVCalcModal").val("false");
    }
    else $(".divARIVFVCalculations").hide();
    if (parseInt($("#hdnARACC_RPT_GRP_ID").val()) > 0) {
        $("#txtARDate").datepicker("disable");
    }

    HideShowFyncYr("");
};

function DateChangeEvent() {
    $("#pageloaddiv").fadeIn();
    $("#btnARDateChange").click();
};

function ShowHideAdvanceSearchSection(o_Event) {
    if (o_Event != "PageLoad") {
        if ($(".divARHideShowAdvSearch").is(":hidden")) {
            $(".divARHideShowAdvSearch").slideDown("slow");
            $(".imgARAdvanceSearch").attr('src', '../../App_Themes/images/minus.png');
            $(".imgARAdvanceSearch").attr('title', 'Click here to collapse');
        } else {
            $(".divARHideShowAdvSearch").slideUp("slow");
            $(".imgARAdvanceSearch").attr('src', '../../App_Themes/images/plus.png');
            $(".imgARAdvanceSearch").attr('title', 'Click here to expand');
        }
    }
};

function HideShowFyncYr(o_Event) {
    if ($("#rdoARDisplayCostFor input:checked").val() == "M") {
        $("#ddlARFinancialMonthFrom").show();
        $("#ddlARFinancialMonthTo").show();
        $("#ddlARFinancialQrFrom").hide();
        $("#ddlARFinancialQrTo").hide();
        if (o_Event == "change") {
            $("#ddlARFinancialMonthTo").val("--- Please Select ---");
            $("#ddlARFinancialMonthFrom").val("--- Please Select ---");
        }
    }
    else if ($("#rdoARDisplayCostFor input:checked").val() == "Q") {
        $("#ddlARFinancialMonthFrom").hide();
        $("#ddlARFinancialMonthTo").hide();
        $("#ddlARFinancialQrFrom").show();
        $("#ddlARFinancialQrTo").show();
        if (o_Event == "change") {
            $("#ddlARFinancialQrFrom").val("--- Please Select ---");
            $("#ddlARFinancialQrTo").val("--- Please Select ---");
        }
    }
    else {
        $("#ddlARFinancialQrFrom").hide();
        $("#ddlARFinancialQrTo").hide();
        $("#ddlARFinancialMonthFrom").hide();
        $("#ddlARFinancialMonthTo").hide();
    }
};

function ViewValuationParas(o_GrantRegID) {
    $.ajax({
        type: "POST",
        url: "AccountingReport.aspx/BindValuationParasToCompare",
        data: "{'o_GrantRegID':" + JSON.stringify(o_GrantRegID) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        processData: false,
        success: function (data) {
            var v_HTMLStr = "", v_Note = "", o_COMPANY_LEVEL_PARAMETERS = "", o_CLP_RadioList = "", o_PRESENT_GRANT_PARAMETERS = "", o_PGP_RadioList = "";
            v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"4\" rules=\"all\" border=\"1\" id=\"gvValuationParasToCompare\" style=\"border-collapse: collapse; font-size: 100%;\"><tr class=\"gridHeader\">";
            v_HTMLStr += "<th scope=\"col\">Parameters selected for</th><th scope=\"col\">Company Level</th><th scope=\"col\">Present Grant Parameters</th></tr>";
            for (var i = 0; i < data.d.length; i++) {
                v_HTMLStr += "<tr class=\"gridItems\"><td>" + data.d[i].PARAMETERS_SELECTED_FOR_GRANT + "</td>";
                /* COMPANY LEVEL PARAMETERS - START */
                o_COMPANY_LEVEL_PARAMETERS = data.d[i].COMPANY_LEVEL_PARAMETERS.split(',');
                o_CLP_RadioList = "";
                if (o_COMPANY_LEVEL_PARAMETERS.length > 0) {
                    for (var o_CLP = 0; o_CLP < o_COMPANY_LEVEL_PARAMETERS.length; o_CLP++) {
                        if (o_CLP_RadioList == "")
                            o_CLP_RadioList += "<ul style=\"list-style-type: square;\"><li>" + o_COMPANY_LEVEL_PARAMETERS[o_CLP] + "</li>";
                        else o_CLP_RadioList += "<li>" + o_COMPANY_LEVEL_PARAMETERS[o_CLP] + "</li>";
                    }
                    o_CLP_RadioList += "</ul>";
                }
                v_HTMLStr += "<td>" + o_CLP_RadioList + "</td>";
                /* COMPANY LEVEL PARAMETERS - END */
                /* GRANT LEVEL PARAMETERS - START */
                o_PRESENT_GRANT_PARAMETERS = data.d[i].PRESENT_GRANT_PARAMETERS.split(',');
                o_PGP_RadioList = "";
                if (o_PRESENT_GRANT_PARAMETERS.length > 0) {
                    for (var o_PGP = 0; o_PGP < o_PRESENT_GRANT_PARAMETERS.length; o_PGP++) {
                        if (o_PGP_RadioList == "")
                            o_PGP_RadioList += "<ul style=\"list-style-type: square;\"><li>" + o_PRESENT_GRANT_PARAMETERS[o_PGP] + "</li>";
                        else o_PGP_RadioList += "<li>" + o_PRESENT_GRANT_PARAMETERS[o_PGP] + "</li>";
                    }
                    o_PGP_RadioList += "</ul>";
                }
                if (data.d[i].IS_MANUALY_UPLOADED == "True") {
                    v_HTMLStr += "<td style=\"background-color: #E0F0FF;\">Manually entered data</td></tr>";
                    v_Note = "<b>Parameters marked in blue are manually entered</b>";
                }
                else if (data.d[i].PRESENT_GRANT_PARAMETERS == "") {
                    v_HTMLStr += "<td>Same as company level</td></tr>";
                    v_Note = "<b>Parameters marked in green are different from the company parameters</b>";
                }
                else if (data.d[i].PRESENT_GRANT_PARAMETERS != data.d[i].COMPANY_LEVEL_PARAMETERS) {
                    v_HTMLStr += "<td style=\"background-color: #D6FFD6;\">" + o_PGP_RadioList + "</td></tr>";
                    v_Note = "<b>Parameters marked in green are different from the company parameters</b>";
                }
                else v_HTMLStr += "<td>" + o_PGP_RadioList + "</td></tr>";
                /* GRANT LEVEL PARAMETERS - END */
            };
            if (v_Note != "")
                v_HTMLStr += "<tr><td colspan=\"3\"><b>Note :</b>" + v_Note + "</td><tr>";
            v_HTMLStr += "</table>";
            $("#divARGridData").html(v_HTMLStr);
            $("#lblARPopupHeader").text("Valuation Parameters");
            $(".divARIVFVCalculations").hide();
            OpenPopupDiv();
        },
        failure: function (data) {
            alert('fail');
        },
        error: function (data) {
            alert('error')
        }
    });
    return false;
};

function ReadConfigSettings() {
    var hdnARCompanyName = $("#hdnARCompanyName").val();
    if ($("#ddlARSelectTemplate option:selected").text() == '') {
        alert('Template is not created for company.');
        return false;
    }
    else {
        switch ($("#ddlARSelectTemplate option:selected").text()) {
            case "Default":
                var hyperlinkAddress = "../Accounting/LetterTemplates/Default.pdf";
                var newWin = window.open(hyperlinkAddress, "ViewCurrentTemplate", 'toolbar=0,location=0,menubar=0,status=0,scrollbars=yes,copyhistory=0,height=600,width=900,modal=yes,alwaysRaised=yes,resizable=1');
                if (newWin != null) {
                    newWin.focus();
                    void (0);
                }
                break;

            default:
                var hyperlinkAddress = "../Accounting/LetterTemplates/" + hdnARCompanyName + "/" + "PDFTemplates/" + $("#ddlARSelectTemplate option:selected").text() + ".pdf";
                var newWin = window.open(hyperlinkAddress, "ViewCurrentTemplate", 'toolbar=0,location=0,menubar=0,status=0,scrollbars=yes,copyhistory=0,height=600,width=900,modal=yes,alwaysRaised=yes,resizable=1');
                if (newWin != null) {
                    newWin.focus();
                    void (0);
                }
                break;
        }
        return false;
    }
};

function ViewWorkings(QueryString) {
    if (QueryString != "") {
        var newWin = window.open(s_ReportURL + QueryString, "EDReports", "toolbar=0,location=0,menubar=0,status=0,scrollbars=yes,copyhistory=0,height=550,width=800,modal=yes,alwaysRaised=yes,resizable=1");
        if (newWin != null) {
            newWin.focus();
            void (0);
        }
    }
    return false;
};

function ViewIVFVCalculations(s_GrantRegID, s_MP_Type) {
    $("#hdnARCalcGrantRegID").val(s_GrantRegID);
    $("#hdnARCalcMP_Type").val(s_MP_Type);
    $.ajax({
        type: "POST",
        url: "AccountingReport.aspx/ViewHistory",
        data: "{'s_GrantRegID':'" + s_GrantRegID + "','s_MP_Type': '" + s_MP_Type + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        processData: false,
        success: function (data) {
            var objdata = $.parseJSON(data.d);
            var Price_Details = data.d;
            var s_OP = s_MP_Type == "FV" ? objdata.dt_Price[17] : objdata.dt_Price[5];
            s_MP_Type == "FV" ? objdata.dt_Price.splice(11, 16, s_OP) : objdata.dt_Price.splice(4, 6, s_OP);
            var v_HTMLStr = "", v_HeaderText = "";;
            v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" style='font-size: 100%;' rules=\"all\" border=\"1\" id=\"gv\" style=\"border-collapse: collapse; font-size: 100%;\"><tr class=\"gridHeader\">";
            for (var i = 0; i < objdata.dt_Price.length; i++) {
                if (i == 0) {
                    for (var k = 0; k < objdata.dt_Price[0].split(",").length - 2; k++) {
                        v_HTMLStr += "<th scope=\"col\">" + objdata.dt_Price[0].split(",")[k] + "</th>";
                    }
                    v_HTMLStr += "</tr>";
                    v_HTMLStr += "<tr class=\"gridItems\"><td style='font-weight:bold' colspan = " + (objdata.dt_Price[i].length - 2) + ">Variables</td></tr>";
                }
                else {
                    v_HTMLStr += "<tr class=\"gridItems\">";
                    for (var M = 0 ; M < objdata.dt_Price[i].length - 1; M++) {
                        {
                            if (objdata.dt_Price[i][objdata.dt_Price[i].length - 1] == 1 || objdata.dt_Price[i][objdata.dt_Price[i].length - 1] != null) {

                                v_HTMLStr += ((objdata.dt_Price[i][M] == null || objdata.dt_Price[i][M] == '' ? "<td style='height:13px'>" : "<td style='color:green'>")) + ((objdata.dt_Price[i][M] == null || objdata.dt_Price[i][M] == '' ? ' ' : M == 0 ? objdata.dt_Price[i][M] : parseFloat(objdata.dt_Price[i][M]).toFixed(2))) + "</td>";
                            }
                            else {
                                if (i != (objdata.dt_Price.length - 1)) {
                                    v_HTMLStr += ((objdata.dt_Price[i][M] == null || objdata.dt_Price[i][M] == '' ? "<td style='height:13px'>" : "<td>")) + ((objdata.dt_Price[i][M] == null || objdata.dt_Price[i][M] == '' ? ' ' : M == 0 ? objdata.dt_Price[i][M] : parseFloat(objdata.dt_Price[i][M]).toFixed(2))) + "</td>";
                                }
                                else {
                                    v_HTMLStr += M == 0 ? ((objdata.dt_Price[i][M] == null || objdata.dt_Price[i][M] == '' ? "<td style='height:13px ; background-color:#D1D1D1 ; font-weight:bold'>" : "<td style='background-color:#D1D1D1; font-weight:bold'>")) + ((objdata.dt_Price[i][M] == null || objdata.dt_Price[i][M] == '' ? ' ' : M == 0 ? objdata.dt_Price[i][M] : parseFloat(objdata.dt_Price[i][M]).toFixed(2))) + "</td>"
                                                : M == objdata.dt_Price[i].length - 2 ? '<td  style="height:13px ; background-color:#D1D1D1; font-weight:bold" > ' + s_OP[1] + ' </td>' : M == 1 ? '<td style="background-color:#D1D1D1 ; font-weight:bold" colspan = ' + (objdata.dt_Price[i].length - 3) + '></td>' : '</td>';
                                }
                            }
                        }
                    }
                    v_HTMLStr += "</tr>";
                }
                if (v_HeaderText == "") {
                    v_HeaderText = s_MP_Type == "FV" ? 'Calculation of Fair Value' : 'Calculation of Intrinsic Value';
                }
            }
            $("#divARIVFVCalculations").show();
            $("#divARIVFVCalculations").html(v_HTMLStr);
            $("#lblARPopupHeader").text(v_HeaderText);
            $("#divARGridData").hide();
            $("#divCORPIVFV").hide();
            OpenPopupDiv();
        },
        failure: function (data) {
            alert('fail');
        },
        error: function (data) {
            alert('error')
        }
    });
    return false;
};

function ViewIVFVCOPRPACT(s_GrantRegID, s_MP_Type) {
    $("#hdnARCalcGrantRegID").val(s_GrantRegID);
    $("#hdnARCalcMP_Type").val(s_MP_Type);
    $.ajax({
        type: "POST",
        url: "AccountingReport.aspx/ViewIVFVCorpAct",
        data: "{'s_GrantRegID':'" + s_GrantRegID + "','s_MP_Type': '" + s_MP_Type + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        processData: false,
        success: function (data) {            
            var objdata = $.parseJSON(data.d);
            var Price_Details = data.d;
            var v_HTMLStr = "", v_HeaderText = "";;
            v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" style='font-size: 100%;' rules=\"all\" border=\"1\" id=\"gvCorpPIVFV\" style=\"border-collapse: collapse; font-size: 100%;\"><tr class=\"gridHeader\">";
            for (var i = 0; i < objdata.dt_CorpAct.length; i++) {
                if (i == 0) {
                    for (var k = 0; k < objdata.dt_CorpAct[0].split(";").length - 2; k++) {
                        v_HTMLStr += "<th scope=\"col\">" + objdata.dt_CorpAct[0].split(";")[k] + "</th>";
                    }
                    v_HTMLStr += "</tr>";

                }
                else {
                    v_HTMLStr += "<tr class=\"gridItems\">";
                    for (var M = 0 ; M < objdata.dt_CorpAct[i].length - 1; M++) {
                        {
                            if (i < (objdata.dt_CorpAct.length - 2)) {
                                v_HTMLStr += ((objdata.dt_CorpAct[i][M] == null || objdata.dt_CorpAct[i][M] == '')) ?
                                   "<td style='height:13px'>" : M == 0 ? '<td style="text-align:left;"> ' + objdata.dt_CorpAct[i][M] + ' </td>' : M == 1 ? '<td style="text-align:right;">' + (objdata.dt_CorpAct[i][M]) + '</td>' : '</td>';
                            }
                            else {
                                v_HTMLStr += M == 0 ? '<td style="background-color:#D1D1D1 ; font-weight:bold" colspan = ' + (objdata.dt_CorpAct[i].length - 2) + '> ' + objdata.dt_CorpAct[i][M] + ' </td>'
                                    : M == 1 ? '<td style="background-color:#D1D1D1 ; text-align:right; font-weight:bold" colspan = ' + (objdata.dt_CorpAct[i].length - 2) + '> ' + objdata.dt_CorpAct[i][M] + ' </td>' : '</td>';
                            }
                        }
                    }
                    v_HTMLStr += "</tr>";
                }
                if (v_HeaderText == "") {
                    v_HeaderText = s_MP_Type == "FV" ? 'Corporate Action Fair Value' : 'Corporate Action Intrinsic Value';
                }
            }
            $("#divCORPIVFV").show();
            $("#divCORPIVFV").html(v_HTMLStr);
            $("#lblARPopupHeader").text(v_HeaderText);
            $("#divARGridData").hide();
            $("#divARIVFVCalculations").hide();
            OpenPopupDiv();
        },
        failure: function (data) {
            alert('fail');
        },
        error: function (data) {
            alert('error')
        }
    });
    return false;
};

function testAdd() {
    alert("Hi");
    var s_GrantRegID = '';
    var s_MP_Type = '';
    $.ajax({
        type: "POST",
        url: "AccountingReport.aspx/HelloWorld",
        data: "",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: "true",
        cache: "false",
        success: function (msg) {
            console.log(msg);
            alert('s');
            // On success                 
        },
        Error: function (x, e) {
            // On Error
            console.log(x);
            console.log(e);
            alert('e');
        }
    });
    return false;
};

function Testadd() {
    $.ajax({
        type: "POST",
        url: "AccountingReport.aspx/HelloWorld",
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify({
            Reporting_date: $("REPORTING_DATE").val(),
            Market_Price: $("MARKET_PRICE_TYPE").val(),
            Updated_by: $("UPDATED_BY").val(),
            Display_cost_before: $("DISPLAY_COST_BEFORE").val(),
            Display_cost_after: $("DISPLAY_COST_AFTER").val(),
            Calculation_method: $("CALCULATION_METHOD").val(),
            Call_type: $("CALL_TYPE").val(),
            
        }),
        success: function (response) {
            console.log(response);
            alert('s');
        },
        error: function (response) {
            console.log(response);
            alert('g');
        }
    })
};

function Displayss() {
    if ($("#txtARDate").val() != 'dd/mmm/yyyy' && $("#txtARDate").val() != "") {
        $("#btnARDateChange").click();
    }
    return false;
};

function CloseModalPopup() {
    $('#ModalDiv').dialog("close");
    $(".ui-button").click();
};

function OpenModalDialog(s_ControlText, s_ACC_RPT_GROUP_ID, s_ControlID, s_ReportName, s_VersionNumber, s_IsLocked, s_PendingParms, s_AccRoportDate) {
    HideMessageDiv();

    if (s_ControlID == "lbtnARApproveByClient") {
        $("#pageloaddiv").fadeIn();
        $("#hdnARActionButtionID").val(s_ControlID);
        $("#hdnARACC_RPT_GRP_ID").val(s_ACC_RPT_GROUP_ID);
        $("#hdnARSelectedTemplteNme").val(s_ReportName);
        $("#btnARReviewerApproval").click();
    }
    else if (s_ControlID == "lbtnARApproveByReviewer") {
        $("#pageloaddiv").fadeIn();
        $("#hdnARActionButtionID").val(s_ControlID);
        $("#hdnARACC_RPT_GRP_ID").val(s_ACC_RPT_GROUP_ID);
        $("#hdnARSelectedTemplteNme").val(s_ReportName);
        $("#btnARReviewerApproval").click();
    }
    else if (s_ControlID == "lbtnARReviewerApproval") {
        $("#pageloaddiv").fadeIn();
        $("#hdnARActionButtionID").val(s_ControlID);
        $("#hdnARACC_RPT_GRP_ID").val(s_ACC_RPT_GROUP_ID);
        $("#hdnARSelectedTemplteNme").val(s_ReportName);
        $("#btnARReviewerApproval").click();
    }
    else if (s_ControlID == "lbtnARDownloadReport") {
        $("#hdnARACC_RPT_GRP_ID").val(s_ACC_RPT_GROUP_ID);
        $("#hdnARSelectedTemplteNme").val(s_ControlText);
        $("#btnARDownloadSlctedRport").click();
    }
    else if (s_ControlID == "lbtnAREditAndView") {
        $("#pageloaddiv").fadeIn();
        $("#hdnARACC_RPT_GRP_ID").val(s_ACC_RPT_GROUP_ID);
        $("#hdnARSelectedTemplteNme").val(s_ReportName);
        $("#hdnARReportDate").val($("#txtARDate").val());
        $("#hdnIsEdit").val("Edit");
        $("#btnAREditAndView").click();
    }
    else if (s_ControlID == "lbtnARDownloadTemplate") {
        $("#hdnARACC_RPT_GRP_ID").val(s_ACC_RPT_GROUP_ID);
        $("#hdnARSelectedTemplteNme").val(s_ControlText);
        $("#btnARDownloadSelectedDoc").click();
    }
    else if (s_ControlID == "lbtnARLocks") {
        $("#hdnAccReportDate").val('');
        if (s_ControlText == "Lock") {
            if (s_PendingParms == "1") {
                ShowMessageDiv("can't lock the report as Accounting Parameters used in this report has been pending for approval", "red");
                return false;
            }
            else if (s_PendingParms == "2") {
                ShowMessageDiv("can't lock the report as Employee wise details were pending for approval", "red");
                return false;
            }
            else {
                if (confirm("Are you sure you want to lock the selected report")) {
                    $("#pageloaddiv").fadeIn();
                    $("#hdnARActionButtionID").val(s_ControlID);
                    $("#hdnARACC_RPT_GRP_ID").val(s_ACC_RPT_GROUP_ID);
                    $("#hdnARSelectedTemplteNme").val(s_ControlText);
                    $("#hdnAccReportDate").val(s_AccRoportDate);
                    $("#hdnIsLocked").val("Locked");
                    $("#btnARLockAndDelete").click();

                }
                else return false;
            }
        }
        else {
            if (confirm("Are you sure you want to unlock the selected report")) {
                $("#pageloaddiv").fadeIn();
                $("#hdnARActionButtionID").val(s_ControlID);
                $("#hdnARACC_RPT_GRP_ID").val(s_ACC_RPT_GROUP_ID);
                $("#hdnAccReportDate").val(s_AccRoportDate);
                $("#hdnARSelectedTemplteNme").val(s_ControlText);
                $("#hdnIsLocked").val("Locked");
                $("#btnARLockAndDelete").click();
            }
            else return false;
        }
    }
    else if (s_ControlID == "lbtnARDelete") {
        if (s_IsLocked == "1") {
            ShowMessageDiv($("#hdnARCantDelAsRptLocked").val(), "red");
            return false;
        }
        else {
            if (confirm("Are you sure you want to delete the selected report")) {
                $("#pageloaddiv").fadeIn();
                $("#hdnARActionButtionID").val(s_ControlID);
                $("#hdnARACC_RPT_GRP_ID").val(s_ACC_RPT_GROUP_ID);
                $("#btnARLockAndDelete").click();
            }
            else return false;
        }
    }
    else {
        var QueryString = "ControlText=" + s_ControlText + "&" + "ACC_RPT_GROUP_ID=" + s_ACC_RPT_GROUP_ID + "&" + "VersionNumber=" + s_VersionNumber;
        var page = "AccReportingPopup.aspx?" + QueryString;
        $Modaldialog.dialog({ title: s_ControlText, height: 450, width: 700 });
        $Modaldialog.html('<iframe id="AccountingModalIframe" frameborder="0" border="0" style="border:0;" src="' + page + '" width="100%" height="100%"></iframe>');
        $Modaldialog.dialog('open');
    }
    return false;
};

function ViewGrantDetails(s_AGRMID) {
    var QueryString = "s_AGRMID=" + s_AGRMID + "&" + "s_PageName=AccountingReport";
    var page = "GrantDetails.aspx?" + QueryString;
    $Modaldialog.dialog({ title: "Grant Details", height: 650, width: 900 });
    $Modaldialog.html('<iframe id="AccountingModalIframe" frameborder="0" border="0" style="border:0;" src="' + page + '" width="100%" height="100%"></iframe>');
    $Modaldialog.dialog('open');
    return false;
};

function ViewReconColumnCell(s_GridViewName, o_this) {

    switch (s_GridViewName) {
        case "gvReconChildGridView_ColumnCell_a":
            $("tr.gvReconChildGridView_ColumnCell_b").hide();
            $("tr.gvReconChildGridView_ColumnCell_c").hide();
            $("tr.gvReconChildGridView_ColumnCell_f").hide();
            $(o_this).closest('tr').next('tr.gvReconChildGridView_ColumnCell_a').toggle(1000);
            break;

        case "gvReconChildGridView_ColumnCell_b":
            $("tr.gvReconChildGridView_ColumnCell_c").hide();
            $("tr.gvReconChildGridView_ColumnCell_f").hide();
            $("tr.gvReconChildGridView_ColumnCell_a").hide();
            $(o_this).closest('tr').next().next('tr.gvReconChildGridView_ColumnCell_b').toggle(1000);
            break;

        case "gvReconChildGridView_ColumnCell_c":
            $("tr.gvReconChildGridView_ColumnCell_f").hide();
            $("tr.gvReconChildGridView_ColumnCell_a").hide();
            $("tr.gvReconChildGridView_ColumnCell_b").hide();
            $(o_this).closest('tr').next().next().next('tr.gvReconChildGridView_ColumnCell_c').toggle(1000);
            break;

        case "gvReconChildGridView_ColumnCell_f":
            $("tr.gvReconChildGridView_ColumnCell_a").hide();
            $("tr.gvReconChildGridView_ColumnCell_b").hide();
            $("tr.gvReconChildGridView_ColumnCell_c").hide();
            $(o_this).closest('tr').next().next().next().next('tr.gvReconChildGridView_ColumnCell_f').toggle(1000);
            break;
    }

    return false;
};
function ViewAcceleratedVesting(s_VestingPeriodID, s_ReportingDate) {
    $.ajax({
        type: "POST",
        url: "AccountingReport.aspx/ViewAcceleratedVesting",
        data: "{'s_VestingPeriodID':" + JSON.stringify(s_VestingPeriodID) + ",'s_ReportingDate':" + JSON.stringify(s_ReportingDate) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        processData: false,
        success: function (data) {

            var objdata = $.parseJSON(data.d);
            var v_HTMLStr = "";
            v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"4\" rules=\"all\" border=\"1\" id=\"gvValuationParasToCompare\" style=\"border-collapse: collapse; font-size: 100%;\"><tr class=\"gridHeader\">";
            v_HTMLStr += "<th scope=\"col\">Accelerated Quantity</th><th scope=\"col\">Accelerated Date</th><tr>";

            for (var i = 0; i < objdata.DT.length - 1; i++) {
                v_HTMLStr += "<tr class=\"gridItems\">";
                v_HTMLStr += "<td align = \"right\" class=\"gridItems\">" + objdata.DT[i][0] + "</td>";
                v_HTMLStr += "<td align = \"center\" class=\"gridItems\">" + objdata.DT[i][1] + "</td>";
                v_HTMLStr += "</tr>";
            }

            v_HTMLStr += "</table>";
            $("#divARGridData").html(v_HTMLStr);
            $("#lblARPopupHeader").text("Accelerated Data");
            $(".divARIVFVCalculations").hide();
            OpenPopupDiv();
        },
        failure: function (data) {
            alert('fail');
        },
        error: function (data) {
            alert('error')
        }
    });
    return false;
};