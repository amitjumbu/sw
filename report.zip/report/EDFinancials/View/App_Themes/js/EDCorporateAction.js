﻿function pageLoad() {

    LoadScript();

    var activeIndex = parseInt($("#hdnAccordionIndex").val());

    $("#accordion").accordion({
        collapsible: false,
        heightStyle: "content",
        active: activeIndex,
        activate: function (event, ui) {
            var index = $(this).children('h4').index(ui.newHeader);
            $("#hdnAccordionIndex").val(index);
        }
    });

    $(".datepickerCAA").datepicker({
        showOn: "both",
        buttonImage: "../../App_Themes/images/datepicker.png",
        buttonImageOnly: true,
        buttonText: "Calendar",
        dateFormat: "dd/M/yy",
        changeMonth: true,
        changeYear: true,
        onClose: function (dateText, inst) {
        },
    });

    $(".datepickerCAA").Watermark('dd/mmm/yyyy');

    $("tr.gvChildGrid").hide();

    $("#h4CAASearchPanel").click(function () {
        $("#hdnddlCAAVestingDatesIndex").val("");
        $(".h3AddEdit").hide();
        $(".h3UpdateCalculate").hide();
    });

    $(".h3AddEdit").click(function () {
        $("#hdnddlCAAVestingDatesIndex").val("");
        $(".h3UpdateCalculate").hide();
    });

    $("#btnCAASearch").click(function () {
        $("#hdnddlCAAVestingDatesIndex").val("");
        if ($("#txtCAAEffectFromDate").val() == "dd/mmm/yyyy") {
            document.getElementById("regxtxtCAAEffectFromDate").validationGroup = "Search1";
        }
        else {
            document.getElementById("regxtxtCAAEffectFromDate").validationGroup = "Search";
            document.getElementById("regxtxtCAAEffectFromDate").className = "EDValidator";
        }

        if ($("#txtCAAEffectToDate").val() == "dd/mmm/yyyy") {
            document.getElementById("regxtxtCAAEffectToDate").validationGroup = "Search1";
        }
        else {
            document.getElementById("regxtxtCAAEffectToDate").validationGroup = "Search";
            document.getElementById("regxtxtCAAEffectToDate").className = "EDValidator";
        }

        Page_ClientValidate("Search");
        if (Page_IsValid) {
            return true;
        }
        else {
            return false;
        }
    });

    if ($("#hdnOpenPopUp").val() == "1") {
        OpenPopupDiv();
    }

    $("#closebtnEL").click(function () {
        ClosePopupDiv();
        $("#hdnOpenPopUp").val("");
    });

    $("#btnCAAUpdCancel").click(function () {
        if (confirm("Are you sure to Cancel?") == true) {
            $("#hdnddlCAAVestingDatesIndex").val("");
            $("#accordion").accordion("option", "active", 0);
            $(".h3AddEdit").hide();
        }
        return false;
    });

    $("#ddlCAAVestingDates").change(function () {
        $("#hdnddlCAAVestingDatesIndex").val("Set");
        $("#pageloaddiv").fadeIn();
        $("#btnCAAUpdateCorpActEffect").trigger("click");
    });

    $(".cTextBoxUpdCAA").on('change keypress paste', function () {
        var var_ID = $(this).attr('id');
        var var_VestExercisable = 0; var var_Sum = 0;

        if (var_ID.indexOf("Pre") != -1 && !$("#lblCAACorpActVal").val("OTHERS")) {
             $("#btnCAACalcSave").attr("disabled", true);
        }
    });

    $(".cTextBoxUpdCAA").blur(function () {
        Page_ClientValidate("ValdIntPre-CorpAct")
        if (Page_IsValid) {

        }
        else
            $("#btnCAACalculate").blur();
    });

    $(".cTextBoxUpdCAAPost").on('change keypress paste', function () {
        var var_ID = $(this).attr('id');
        var var_VestExercisable = 0; var var_Sum = 0;

        if (var_ID.indexOf("Pre") != -1 && !$("#lblCAACorpActVal").val("OTHERS")) {
             $("#btnCAACalcSave").attr("disabled", true);
        }
    });

    $(".cTextBoxUpdCAAPost").blur(function () {
        Page_ClientValidate("ValdIntPre-CorpAct")
        if (Page_IsValid) {

        }
        else
            $("#btnCAACalculate").blur();
    });

    $(".Validators").on("keypress keyup", function (event) {
        if ((event.which != 46 && event.which < 48) || event.which > 57) {
            event.preventDefault();
        }
    });

    $("#btnCAACalculate").click(function () {
        Page_ClientValidate("ValdIntPre-CorpAct")
        if (Page_IsValid) {
            var var_arrRatio = new Array();
            var_arrRatio = $("#hdnCAACorpActRatioVal").val().split(':');
            var var_array = new Array();
            /* Get Pre-Corporate Action Data From GridView and Store it in the Array */
            $("#gvCAAUpdateCalcCorpAction").each(function () {
                for (i = 0; i < $("#gvCAAUpdateCalcCorpAction tr").length - 1; i++) {
                    var_array[i] = $(this).closest('tr').find($("#txtBox_Pre-CorpAct_" + i)).val() == "0" ? "0" : $(this).closest('tr').find($("#txtBox_Pre-CorpAct_" + i)).val();
                }
            });

            /* Replacing comma from Numeric Field */
            for (i = 0; i < $("#gvCAAUpdateCalcCorpAction tr").length - 1; i++) {
                var_array[i] = (var_array[i].indexOf(',') > -1 ? var_array[i].replace(/,/g, "") : var_array[i]);
            }

            /* If Corporate Action Type is BONUS */
            if ($("#hdnCAACorpActVal").val() == "BONUS") {
                $("#gvCAAUpdateCalcCorpAction").each(function () {
                    for (i = 0; i < $("#gvCAAUpdateCalcCorpAction tr").length; i++) {
                        if ($("#txtBox_Pre-CorpAct_" + i).val() != "0") {
                            /* Calculation for IV, FV, Exercise Price */
                            if (i == 7 || i == 8 || i == 9)
                                $("#txtBox_Post-CorpAct_" + i).val(parseFloat(var_array[i]) * parseFloat(var_arrRatio[1]) / (parseFloat(var_arrRatio[0]) + parseFloat(var_arrRatio[1])));

                            /* Calculation in case of 'To Outstanding Options' is selected */
                            if ($('#lblCAAToOptions').html() == "Apply To Outstanding Options") {
                                /* Calculation for Vested and Unvested i.e. for Outstanding Options */
                                if (i == 5 || i == 6)
                                    $("#txtBox_Post-CorpAct_" + i).val(Math.round(parseFloat(var_array[i]) * (parseFloat(var_arrRatio[0]) + parseFloat(var_arrRatio[1]))));

                                    /* Calculation for Options */
                                else if (i != 7 && i != 8 && i != 9)
                                    $("#txtBox_Post-CorpAct_" + i).val($("#txtBox_Pre-CorpAct_" + i).val());
                            }
                                /* Calculation for Options */
                            else if (i != 7 && i != 8 && i != 9)
                                $("#txtBox_Post-CorpAct_" + i).val(Math.round(parseFloat(var_array[i]) * (parseFloat(var_arrRatio[0]) + parseFloat(var_arrRatio[1])) / parseFloat(var_arrRatio[1])));
                        }
                        else {
                            $("#txtBox_Post-CorpAct_" + i).val("0");
                        }
                    }

                    $("#txtBox_Post-CorpAct_" + i).attr("disabled", false);
                });
            }

                /* If Corporate Action Type is SPLIT */
            else if ($("#hdnCAACorpActVal").val() == "SPLIT") {
                $("#gvCAAUpdateCalcCorpAction").each(function () {
                    for (i = 0; i < $("#gvCAAUpdateCalcCorpAction tr").length; i++) {

                        /* Calculation for IV, FV, Exercise Price */
                        if (i == 7 || i == 8 || i == 9) {
                            $("#txtBox_Post-CorpAct_" + i).val(parseFloat(var_array[i]) * parseFloat(var_arrRatio[0]) / parseFloat(var_arrRatio[1]));
                        }

                        /* Calculation in case of 'To Outstanding Options' is selected */
                        if ($('#lblCAAToOptions').html() == "Apply To Outstanding Options") {
                            /* Calculation for Vested and Unvested i.e. for Outstanding Options */
                            if (i == 5 || i == 6)
                                $("#txtBox_Post-CorpAct_" + i).val(Math.round(parseFloat(var_array[i]) * (parseFloat(var_arrRatio[1]) + parseFloat(var_arrRatio[0]))));

                                /* Calculation for Options */
                            else if (i != 7 && i != 8 && i != 9)
                                $("#txtBox_Post-CorpAct_" + i).val($("#txtBox_Pre-CorpAct_" + i).val());
                        }
                            /* Calculation for Options */
                        else if (i != 7 && i != 8 && i != 9)
                            $("#txtBox_Post-CorpAct_" + i).val(Math.round(parseFloat(var_array[i]) * parseFloat(var_arrRatio[1]) / parseFloat(var_arrRatio[0])));
                    }

                    $("#txtBox_Post-CorpAct_" + i).attr("disabled", false);
                });
            }

            /* FV & IV Manual Check */
            $("#hdnIsMUIV").val($("#txtBox_Post-CorpAct_7").val());
            $("#hdnIsMUFV").val($("#txtBox_Post-CorpAct_8").val());

            /* Updating Options Granted in case of Outstanding Options */
            if ($('#lblCAAToOptions').html() == "Apply To Outstanding Options") {
                $("#txtBox_Post-CorpAct_0").val(parseInt($("#txtBox_Post-CorpAct_1").val()) + parseInt($("#txtBox_Post-CorpAct_2").val()) + parseInt($("#txtBox_Post-CorpAct_3").val()) + parseInt($("#txtBox_Post-CorpAct_4").val()) + parseInt($("#txtBox_Post-CorpAct_5").val()) + parseInt($("#txtBox_Post-CorpAct_6").val()));
            }
            $("#btnCAACalcSave").attr("disabled", false);

            return false;
        }
        else {
            $("#btnCAACalcSave").attr("disabled", true);
            $("#btnCAACalculate").blur();
        }
    });

    function CalculateFVIVExPrc() {
        var_arrRatio = $("#hdnCAACorpActRatioVal").val().split(':');

        /* If Corporate Action Type is BONUS */
        if ($("#hdnCAACorpActVal").val() == "BONUS") {
            /* Calculation for Exercise Price */
            $("#hdnCAAMasterExPrc").val(parseFloat($("#hdnCAAMasterExPrc").val()) * parseFloat(var_arrRatio[1]) / (parseFloat(var_arrRatio[0]) + parseFloat(var_arrRatio[1])));
        }
            /* If Corporate Action Type is SPLIT */
        else if ($("#hdnCAACorpActVal").val() == "SPLIT") {
            /* Calculation for Exercise Price */
            $("#hdnCAAMasterExPrc").val(parseFloat($("#hdnCAAMasterExPrc").val()) * parseFloat(var_arrRatio[0]) / parseFloat(var_arrRatio[1]));
        }
    };

    $("#btnCAACalcSave").click(function () {
        var v_Flag = false;
        $("#gvCAAUpdateCalcCorpAction").each(function () {
            for (i = 0; i < $("#gvCAAUpdateCalcCorpAction tr").length - 2; i++) {
                v_Flag = parseInt($(this).closest('tr').find($("#txtBox_Pre-CorpAct_" + i)).val()) < 0 ? true : parseInt($(this).closest('tr').find($("#txtBox_Post-CorpAct_" + i)).val()) < 0 ? true : v_Flag;

                if (v_Flag == true)
                    break;
            }
        });

        if (v_Flag == false) {
            var var_arrPreCorpAct = "";
            var var_arrPostCorpAct = "";
            var var_SumPre = "0"; var var_SumPost = "0";

            $("#hdnddlCAAVestingDatesIndex").val("");

            Page_ClientValidate("ValdIntPost-CorpAct")
            if (Page_IsValid) {
                Page_ClientValidate("ValdIntPre-CorpAct")
                if (Page_IsValid) {
                    if (confirm("Are you sure to Save the Data?") == true) {
                        for (i = 1; i < 7; i++) {
                            var_SumPre = parseInt(var_SumPre) + parseInt(($("#txtBox_Pre-CorpAct_" + i).val().indexOf(',') > -1 ? parseInt($("#txtBox_Pre-CorpAct_" + i).val().replace(/,/g, "")) : parseInt($("#txtBox_Pre-CorpAct_" + i).val())));
                            var_SumPost = parseInt(var_SumPost) + parseInt(($("#txtBox_Post-CorpAct_" + i).val().indexOf(',') > -1 ? parseInt($("#txtBox_Post-CorpAct_" + i).val().replace(/,/g, "")) : parseInt($("#txtBox_Post-CorpAct_" + i).val())));
                        }

                        if (parseInt(var_SumPre) > parseInt(($("#txtBox_Pre-CorpAct_0").val().indexOf(',') > -1 ? parseInt($("#txtBox_Pre-CorpAct_0").val().replace(/,/g, "")) : parseInt($("#txtBox_Pre-CorpAct_0").val())))) {
                            ShowMessageDiv($("#hdnlblCAASumPreGreater").val(), "red");
                            return false;
                        }
                        else if (parseInt(var_SumPost) > parseInt(($("#txtBox_Post-CorpAct_0").val().indexOf(',') > -1 ? parseInt($("#txtBox_Post-CorpAct_0").val().replace(/,/g, "")) : parseInt($("#txtBox_Post-CorpAct_0").val())))) {
                            ShowMessageDiv($("#hdnlblCAASumPostGreater").val(), "red");
                            return false;
                        }
                        else {
                            for (i = 0; i < $("#gvCAAUpdateCalcCorpAction tr").length - 1; i++) {
                                var_arrPreCorpAct = var_arrPreCorpAct + "~" + ($("#txtBox_Pre-CorpAct_" + i).val().indexOf(',') > -1 ? $("#txtBox_Pre-CorpAct_" + i).val().replace(/,/g, "") : $("#txtBox_Pre-CorpAct_" + i).val());
                                var_arrPostCorpAct = var_arrPostCorpAct + "~" + ($("#txtBox_Post-CorpAct_" + i).val().indexOf(',') > -1 ? $("#txtBox_Post-CorpAct_" + i).val().replace(/,/g, "") : $("#txtBox_Post-CorpAct_" + i).val());
                            };

                            $("#hdnArrayPreCorpAct").val(var_arrPreCorpAct);
                            $("#hdnArrayPostCorpAct").val(var_arrPostCorpAct);

                            CalculateFVIVExPrc();

                            $("#pageloaddiv").fadeIn();

                            return true;
                        }
                    }
                    else {
                        return false;
                    }
                }
                else {
                    $("#btnCAACalculate").blur();
                }
            }
            else {
                $("#btnCAACalculate").blur();
            }
        }
        else {
            alert("All Values must be positive. Should not be negative");
            return false;
        }
    });

    $("#btnCAACalcReset").click(function () {

        WebForm_OnSubmit();

        if (confirm("Are you sure to Reset the values?") == true) {
            $("#pageloaddiv").fadeIn();
            $("#btnCAAUpdateCorpActEffect").trigger("click");
        }
        return false;

    });

    $("#btnCAACalcCancel").click(function () {
        if (confirm("Are you sure to Cancel?") == true) {
            $("#hdnddlCAAVestingDatesIndex").val("");
            var current = $("#accordion").accordion("option", "active");
            var prev = current - 1 < 0 ? count : current - 1;
            $("#accordion").accordion("option", "active", prev);
            $(".h3UpdateCalculate").hide();
        }
        return false;
    });

    $("#btnCAAApply").click(function () {

        HideMessageDiv();

        if (confirm("Are you sure to Apply?") == true) {
            $("#UpdateCorpActionAdjt").show();
            $("#pageloaddiv").fadeIn();
            return true;
        }
        else
            return false;
    });

    if ($("#btnCAAApply").is(':disabled')) {
        $("#btnCAAApply").removeAttr('title');
        $("#btnCAAApply").css('cursor', 'default');
    }
    else {
        $("#btnCAAApply").attr('title', 'Click to Apply');
        $("#btnCAAApply").css('cursor', 'hand');
    }
};

function UpdateCorporateAction(s_CorpActionID, s_CorpActionType, s_CorpActRatio, s_EffectiveDate, s_hdnlblCAAToOptions, o_this) {
    if ((($(o_this).closest('td').parent()[0].sectionRowIndex == parseInt($('#gvCAAjd tr').length) - 1) && !$(o_this).closest('tr').find('input:checkbox').is(':checked')) || ($(o_this).closest('tr').next().find('input:checkbox').is(':checked') && !$(o_this).closest('tr').find('input:checkbox').is(':checked'))) {
        $("#hdnCAACorpActVal").val(s_CorpActionType);
        $("#hdnCAACorpActRatioVal").val(s_CorpActRatio);
        $("#hdnCAAEffectDateVal").val(s_EffectiveDate);
        $("#hdnlblCAAToOptions").val(s_hdnlblCAAToOptions);
        $("#pageloaddiv").fadeIn();

        $("#btnCAAUpdateCorpAct").trigger("click");
        return false;
    }
    else {
        if ($(o_this).closest('tr').find('input:checkbox').is(':checked'))
            ShowMessageDiv($("#hdnlblCAACantUpdateAlreadyApplied").val(), "");
        else
            ShowMessageDiv($("#hdnlblCAACantUpdate").val(), "");

        return false;
    }
};

function UpdateCorporateActionEffect(s_AGRMID, s_EMPID, s_GrantOptID) {
    $("#hdnAGRMID").val(s_AGRMID);
    $("#hdnEMPID").val(s_EMPID);
    $("#hdnCAAGrntOptID").val(s_GrantOptID);
    $("#hdnCalcEffectiveDate").val($("#hdnCAAEffectDateVal").val());
    $("#pageloaddiv").fadeIn();

    $("#btnCAAUpdateCorpActEffect").trigger("click");
    return false;
};

function RevertCorporateAction(s_EffectiveDate, o_this, s_IsLocked) {
    $(".h3AddEdit").hide();

    if (s_IsLocked == "1") {
        ShowMessageDiv("Can not revert this corporate action adjustment as it has been considered in the Locked Accounting Report.");
        return false;
    }
    if (($(o_this).closest('td').parent()[0].sectionRowIndex == 1 && $(o_this).closest('tr').find('input:checkbox').is(':checked')) || (!$(o_this).closest('tr').prev().find('input:checkbox').is(':checked') && $(o_this).closest('tr').find('input:checkbox').is(':checked'))) {
        if (confirm("Reverting corporate action effect shall impact the compensation cost of prior years. Please confirm") == true) {
            $("#hdnCAAEffectDateVal").val(s_EffectiveDate);
            $("#btnCAARevertCorpAct").trigger("click");
            return false;
        }
        else
            return false;
    }
    else {
        if (!$(o_this).closest('tr').find('input:checkbox').is(':checked'))
            ShowMessageDiv($("#hdnlblCAACantRevertAlreadyDone").val(), "");
        else
            ShowMessageDiv($("#hdnlblCAACantRevert").val(), "");

        return false;
    }
};

function ViewVestingDetails(o_this) {
    $(o_this).closest('tr').next('tr.gvChildGrid').toggle(1000);
    return false;
};

function ViewFVIVCalc(s_EventName, s_GrantOptID) {
    $("#hdnEventName").val(s_EventName);
    $("#hdnGrantOptionID").val(s_GrantOptID);
    $("#hdnIsFVIVPopSelected").val("Set");
    return true;
};

function ValidateSum(o_this, evt, s_val, s_Index) {

    var cls = o_this.className;
    var opt = 0;
    var txt = 0;
    switch (o_this.className) {
        case "cTextBoxUpdCAA Validators":
            var Granted_op = $(o_this).closest('tr').closest('table').find('td')[1].textContent;
            $(o_this).closest('tr').closest('table').find('.cTextBoxUpdCAA').each(function () {
                if (!($(this).closest('tr').find('.cTextBoxUpdCAA').prop('disabled'))) {
                    if (!isNaN(parseFloat($(this).val()))) {
                        txt += parseFloat(($(this).val().replace(",", "").replace(",", "").replace(",", "")));
                    }
                }
            });

            if ((txt) > parseFloat(Granted_op.replace(',', ''))) {
                $(this).val('');
                alert("Sum of all type of options should not be greater than Option Granted");
            }
            return true;
            break;

        case "cTextBoxUpdCAAPost Validators":
            var OPT_GID = $(o_this).closest('tr').closest('table').find('.cTextBoxUpdCAAPost')[0].value;
            $(o_this).closest('tr').closest('table').find('.cTextBoxUpdCAAPost').each(function () {
                if (opt != 0 && opt != 9 && opt != 8 && opt != 7) {
                    if (!isNaN(parseFloat($(this).val()))) {
                        txt += parseFloat(($(this).val()));
                    }
                }
                opt++;
            });
            if ((txt) > parseFloat(OPT_GID.replace(',', ''))) {
                $(o_this).val('');
                alert("Sum of all type of options should not be greater than Option Granted");
            }
            return true;
            break;
    }


}

