﻿var $Modaldialog;
function pageLoad() {
    var v_TabActiveIndex = parseInt($("#hdnTabActiveIndex").val());
    var v_FGCAccordionIndex = parseInt($("#hdnFGCAccordionIndex").val());
    $("#hdnUpdateRecord").val('');
    LoadScript();

    if ($("#hdnQueryStringFG").val() == 'AccountingReport') {
        DisableFGControls();
        $(".header").hide();
        $(".menuRow").hide();
        $(".lftMenu").hide();
        $(".footerMsg").hide();
        $(".container").removeAttr("style");
        $("#PopupMainContentDiv").attr("style", "background-color: white; color: black; border: 1px solid gray; padding: 8px; display: none; position: absolute; min-height: auto;width:80%;top:10%;left:10%;right:10%;bottom:10%;");
    }
    $(".datepickerControl").Watermark('dd/mmm/yyyy');
    $(".datepickerControl").datepicker({
        showOn: "both",
        buttonImage: "../../App_Themes/images/datepicker.png",
        buttonImageOnly: true,
        buttonText: "Calendar",
        dateFormat: "dd/M/yy",
        minDate: ($("#hdnFGCForFromDateToEdit").val() != "" && $("#hdnFGCForFromDateToEdit").val() != "dd/mmm/yyyy") ? new Date(ConvertToDateTime($("#hdnFGCForFromDateToEdit").val())) : new Date(ConvertToDateTime("01/Jan/1900")),
        changeMonth: true,
        changeYear: true,
        disabled: $("#hdnQueryStringFG").val() == 'AccountingReport' ? true : false,
        onClose: function (dateText, inst) {
            $(this).blur();
            switch ($(this)[0].id) {
                case "txtFRSApplFromDate":
                    if ($("#hdnFRSAppFromDate").val() != "" && $(this)[0].value == $("#hdnFRSAppFromDate").val())
                        $("#btnFRSSave").val(s_BtnFRSUpdateText).attr('title', s_BtnFRSUpdateTooltip);
                    else $("#btnFRSSave").val(s_BtnFRSSaveText).attr('title', s_BtnFRSSaveToolTip);
                    break;
            }
        }
    });
    $("#tabs").tabs({
        activate: function (event, ui) {
            var index = $("#tabs").tabs("option", "active");
            $("#hdnTabActiveIndex").val(index);
        },
        heightStyle: "content"
    });
    $("#tabs").tabs({ active: $("#hdnQueryStringFG").val() == 'AccountingReport' ? 1 : v_TabActiveIndex });
    $Modaldialog = $('<div id="ModalDiv"></div>').dialog({
        heightStyle: "content",
        autoOpen: false,
        resizable: false,
        draggable: false,
        height: 460,
        width: 750,
        modal: true,
        closeOnEscape: true,
        close: function () {
            CloseForfeitureModal(this, "");
        },
    });

    $("#accordionFGC").accordion({
        heightStyle: "content",
        collapsible: false,
        heightStyle: "content",
        active: v_FGCAccordionIndex,
        activate: function (event, ui) {
            var index = $(this).children('h3').index(ui.newHeader);
            $("#hdnFGCAccordionIndex").val(index);
        }
    });
    $(".h3FGCSearchPanel").click(function () {
        $("#btnFGCCancel").trigger('click');
        return false;
    });
    $("#btnFGCCancel").click(function () {
        Page_ClientValidate("FGCCancel");
        return true;
    });
    $("#rblFGCAssignGroupTo").change(function () {
        ShowHideSelEmpSection();
    });
    $("#hplFGCSelectEmployees").click(function () {
        var page = "AddRemoveEmployees.aspx?FGID=" + $("#hdnFGCForfrGrpIDToEdit").val();
        $Modaldialog.dialog({ title: 'Assign Employee(s)', height: 550, width: 1000 });
        $Modaldialog.html('<iframe id="AddRemoveEmployeesIframe" frameborder="0" border="0" style="border:0;" src="' + page + '" width="100%" height="100%"></iframe>');
        $Modaldialog.dialog('open');
    });
    $("#hplFGCForfeitureGrpEmpList").click(function () {
        OpenForfeitureEmpListPopup($("#hdnFGCSSRSQueryString").val());
    });
    $("#btnFGCHistoryBack").click(function () {
        var current = $("#accordionFGC").accordion("option", "active");
        var next = current - 2 < 0 ? count : current - 2;
        $("#accordionFGC").accordion("option", "active", next);
        $(".h3FGCAddEdit").hide();
        $(".h3FGCHistory").hide();
        return false;
    });

    $("#btnFGCFileUpload").click(function () {
        if ($.trim($("#txtFGCGroupName").val()) == "") {
            ShowMessageDiv("Please enter Forfeiture Group Name.", "red");
            return false;
        }
        else return true;
    });

    $("#accordionFRS,#accordionFRC,#accordionFRSAppr").accordion({
        heightStyle: "content",
        collapsible: false,
        heightStyle: "content"
    });

    $("#closebtnEL").click(function () {
        ClosePopupDiv();
    });

    $("#btnFGCSave").click(function () {
        $("#btnFGCSave").blur();
        Page_ClientValidate("FGCSave");
        if (Page_IsValid) {
            Page_ClientValidate("FGCCurrency");
            if (Page_IsValid) {
                Page_ClientValidate("FGCDateFormat");
                if (Page_IsValid) {
                    if ($("#hdnFGCForfrGrpIDToEdit").val() != "" && parseInt($("#hdnFGCForfrGrpIDToEdit").val()) > 0) {
                        if ($('#rblFGCAssignGroupTo input:checked').val() == "A") {
                            if (confirm('Are you sure, you want to associate all employees to the group being up-dated?')) {
                                $("#pageloaddiv").fadeIn();
                                return true;
                            } else return false;
                        }
                        else {
                            if (confirm('Are you sure, you want to associate selected employees to the group being up-dated?')) {
                                $("#pageloaddiv").fadeIn();
                                return true;
                            } else return false;
                        }
                    }
                    else {
                        $("#pageloaddiv").fadeIn();
                        return true;
                    }
                } else return false;
            } else return false;
        } else return false;
    });
    /* TAB#2 -  Start*/

    $("#btnFRSSave").click(function () {

        if ($('#lblFCO02').is(':checked')) {
            if ($('#divOGNetOfCancellation').find('input[type=checkbox]:checked').length == 0) {
                ShowMessageDiv("Please select atleast one options granted net of cancellation.", "");
                return false;
            }
        }

        HideMessageDiv();
        Page_ClientValidate("FRSSave");
        if (Page_IsValid) {
            Page_ClientValidate("FRSDateFormat");
            if (Page_IsValid) {
                if (parseInt($("#hdnFRS_IsApproved").val()) != 1) {
                    ShowMessageDiv(s_CanNotEditSettingsMsg, "");
                    return false;
                }
                if ($("#btnFRSSave").val() == s_BtnFRSUpdateText) {
                    if (confirm("Are You Sure you want to update the settings?") == true) {
                        $("#hdnUpdateRecord").val("U");
                        if (($('#rdoTrueUpYes').is(':checked') && !$('#lblFCO02').is(':checked')) || ($('#rdoTrueUpNo').is(':checked') && !$('#lblFCO01').is(':checked'))) {
                            if (confirm("With these settings you may get a negative numbers in the options expected to be live. These shall be considered as 0. Please confirm to change the setting and proceed ahead.") == true) {

                                $("#pageloaddiv").fadeIn();
                                return true;
                            }
                            else return false;
                        }
                        else {
                            $("#pageloaddiv").fadeIn();
                            return true;
                        }
                    }
                    else return false;
                } else {

                    if (($('#rdoTrueUpYes').is(':checked') && !$('#lblFCO02').is(':checked')) || ($('#rdoTrueUpNo').is(':checked') && !$('#lblFCO01').is(':checked'))) {
                        if (confirm("With these settings you may get a negative numbers in the options expected to be live. These shall be considered as 0. Please confirm to change the setting and proceed ahead.") == true) {

                            $("#pageloaddiv").fadeIn();
                            return true;
                        }
                        else return false;
                    }
                    else {
                        $("#pageloaddiv").fadeIn();
                        return true;
                    }
                }
            } else return false;
        } else return false;
    });

    $("#btnFRSReset").click(function (event) {
        document.forms[0].reset();
        for (var i in Page_Validators) {
            if (Page_Validators[i].validationGroup == "FRSSave" || Page_Validators[i].validationGroup == "FRSDateFormat" || Page_Validators[i].validationGroup == "FGCCurrency" || Page_Validators[i].validationGroup == "FGCSave" || Page_Validators[i].validationGroup == "FGCDateFormat" || Page_Validators[i].validationGroup == "FGCAppEditDateFormat") {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                if (Page_Validators[i].controltovalidate == "txtFRSApplFromDate" || Page_Validators[i].controltovalidate == "txtFGCApplFromDate" || Page_Validators[i].controltovalidate == "txtFGCApplFromDateEdit")
                    control.className = "cTextBox datepickerControl hasDatepicker";
                else control.className = "cTextBox";
                Page_Validators[i].style.display = "none";
                Page_Validators[i].isvalid = true;
            }
        }
        HideMessageDiv();
        ShowHideOptGrantedSection("");
        ShowHideForfeitureVeset("");
        if ($("#txtFRSApplFromDate").val() != "" && $("#txtFRSApplFromDate").val() == $("#hdnFRSAppFromDate").val())
            $("#btnFRSSave").val(s_BtnFRSUpdateText).attr('title', s_BtnFRSUpdateTooltip);
        else $("#btnFRSSave").val(s_BtnFRSSaveText).attr('title', s_BtnFRSSaveToolTip);
        $(".datepickerControl").Watermark('dd/mmm/yyyy');
        if ($("#txtFRSApplFromDate").val() != 'dd/mmm/yyyy')
            $("#txtFRSApplFromDate").attr('style', 'width: 150px !important;');
        event.preventDefault();
        return false;
    });

    $(".OptionsGranted").change(function () {
        ShowHideOptGrantedSection("Change");
    });

    $(".ForfeitureRate").change(function () {
        ShowHideForfeitureVeset("Change");
    });
    /* TAB#2 -  End*/

    $("#rdoTrueUpNo").change(function () {
        if (confirm("In accounting parameters, the calculation of net options should be set to options granted. i.e. cost of unvested cancelled, vested cancelled and lapsed should not be reversed.") == true) {
            return true;
        }
        else {
            return false;
        }
    });

    ShowHideSelEmpSection();
    ShowHideOptGrantedSection("");
    ShowHideForfeitureVeset("");

    $("#btnFGCViewDetailedReport").click(function () {
        var QueryString = $("#hdnFRCSSRSReportID").val();
        if (QueryString != "") {
            var newWin = window.open(s_ReportsURL + QueryString, "EDReports", "toolbar=0,location=0,menubar=0,status=0,scrollbars=yes,copyhistory=0,height=550,width=800,modal=yes,alwaysRaised=yes,resizable=1");
            if (newWin != null) {
                newWin.focus();
                void (0);
            }
        }
        return false;
    });
};

function ShowHideSelEmpSection() {
    if ($('#rblFGCAssignGroupTo input:checked').val() == "S") {
        $(".tdFGCSelectEmployees").show();
        $(".trFGCSelectEmployees").show();
    }
    else {
        $(".tdFGCSelectEmployees").hide();
        $(".trFGCSelectEmployees").hide();
    }
};

function ShowForfeitureEditSection(s_FGAID, s_FromDate, s_IsLocked) {
    if (s_IsLocked == "1") {
        ShowMessageDiv("Can not edit this group as this forfeiture group has been considered in the Locked Accounting Report.");
        return false;
    }
    else {
        $("#hdnFGCForfrGrpIDToEdit").val(s_FGAID);
        $("#hdnFGCForFromDateToEdit").val(s_FromDate);
        $("#btnFGCEdit").trigger('click');
        return false;
    }
};

function ViewForfeitureGrpHistory(s_FGAID) {
    $("#hdnFGCForfrGrpIDToEdit").val(s_FGAID);
    $("#btnFGCViewHistory").trigger('click');
    return false;
};

function ShowAssignedEmpPopup(s_FGAID) {
    $("#divFGCViewEmployees").show();
    OpenPopupDiv();
    return false;
};

function ForfeitureFileDownload(s_ServerPath, s_FileName) {
    $("#hdnFGCFileServerPath").val(s_ServerPath);
    $("#hdnFGCFileName").val(s_FileName);
    $("#btnFGCDownload").trigger("click");
    return false;
};

function DeleteForfeitureDocuments(s_FileName) {
    HideMessageDiv();
    $("#hdnFGCFileNameToDelete").val(s_FileName);
    $("#btnFGCDeleteFile").trigger("click");
    return false;
};

function CloseForfeitureModal(o_this, s_EventType) {
    if (o_this.innerHTML.indexOf("AddRemoveEmployeesIframe") > 0)
        $("#hdnPopupType").val("AddRemoveEmployeesIframe");
    else $("#hdnPopupType").val("");
    $('#ModalDiv').dialog("close");
    if (s_EventType == "btnARESave") {
        $(".ui-button").click();
        $("#btnFGCClosePopup").click();
    }
    return false;
};

function DeleteForfeitureGrp(s_FGAID, s_FromDate, s_IsLocked) {
    if (s_IsLocked == "1") {
        ShowMessageDiv("Can not delete this group as this forfeiture group has been considered in the Locked Accounting Report.");
        return false;
    }
    else {
        if (confirm("Are you sure you want to delete the selected Forfeiture Group?")) {
            HideMessageDiv();
            $("#hdnFGCForfrGrpIDToEdit").val(s_FGAID);
            $("#btnFGCDeleteFGrp").trigger("click");
            return false;
        }
        else return false;
    }
};

function OpenForfeitureEmpListPopup(s_QueryString) {
    var page = s_ReportURL + s_QueryString;
    $Modaldialog.dialog({ title: 'Forfeiture Group Employee List', height: 630, width: 990 });
    $Modaldialog.html('<iframe id="ForGrpEmployeeListIframe" frameborder="0" border="0" style="border:0;" src="' + page + '" width="100%" height="100%"></iframe>');
    $Modaldialog.dialog('open');
    return true;
};

function ViewFGHistoryData(s_FGAID, s_FromDate, s_Type) {
    $.ajax({
        type: "POST",
        url: "ForfeitureSetup.aspx/BindFGSHistoryGrid",
        data: "{'o_FGAID':" + JSON.stringify(s_FGAID) + ",'o_FromDate':" + JSON.stringify(s_FromDate) + ",'o_Type':" + JSON.stringify(s_Type) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        processData: false,
        success: function (data) {
            var v_HTMLStr = "", v_HeaderText = "";
            switch (s_Type) {
                case "HISTORY":
                    v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" rules=\"all\" border=\"1\" id=\"gvFGCHistory\" style=\"border-collapse: collapse; font-size: 75%;\"><tr class=\"gridHeader\">";
                    v_HTMLStr += "<th scope=\"col\">Forfeiture Rate</th><th scope=\"col\">Approval Status</th></tr>";
                    for (var i = 0; i < data.d.length; i++) {
                        v_HTMLStr += "<tr class=\"gridItems\" align=\"center\"><td>" + data.d[i].FORFEITURE_RATE + "</td>";
                        v_HTMLStr += "<td align=\"center\">" + data.d[i].APPROVAL_STATUS + "</td></tr>";
                        if (v_HeaderText == "") {
                            if (data.d[i].APPLICABLE_TO_DATE == "")
                                v_HeaderText = "History ( " + data.d[i].APPLICABLE_FROM_DATE + " - Present )";
                            else v_HeaderText = "History ( " + data.d[i].APPLICABLE_FROM_DATE + " - " + data.d[i].APPLICABLE_TO_DATE + " )";
                        }
                    }
                    break;
                case "DOCUMENTS":
                    v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" rules=\"all\" border=\"1\" id=\"gvFGCDocuments\" style=\"border-collapse: collapse; font-size: 75%;\"><tr class=\"gridHeader\">";
                    if (data.d.length > 0) {
                        v_HTMLStr += "<th scope=\"col\">File Name</th><th scope=\"col\">Download</th></tr>";
                        for (var i = 0; i < data.d.length; i++) {
                            v_HTMLStr += "<tr class=\"gridItems\"><td>" + data.d[i].FILE_NAME + "</td>";
                            v_HTMLStr += "<td><a title=\"Click here to download\" class=\"cHyperLinksp\" onclick=\"return ForfeitureFileDownload('" + data.d[i].FILE_PATH + "','" + data.d[i].FILE_NAME + "')\">Download</a></td></tr>";
                        };
                    }
                    else
                        v_HTMLStr += "<tr class=\"gridItems\"><td>Data does not exist</td></tr>";
                    if (v_HeaderText == "")
                        v_HeaderText = "View Documents";
                    break;
                case "COMMENTS":
                    v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" rules=\"all\" border=\"1\" id=\"gvFGCComments\" style=\"border-collapse: collapse; font-size: 75%;\"><tr class=\"gridHeader\">";
                    v_HTMLStr += "<th scope=\"col\">Comments</th><th scope=\"col\">Added By</th><th scope=\"col\">User Type</th></tr>";
                    for (var i = 0; i < data.d.length; i++) {
                        v_HTMLStr += "<tr class=\"gridItems\"><td style=\"text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;\">" + data.d[i].COMMENTS + "</td>";
                        v_HTMLStr += "<td>" + data.d[i].ADDED_BY + "</td>";
                        v_HTMLStr += "<td>" + data.d[i].USER_TYPE + "</td></tr>";
                    };
                    if (v_HeaderText == "")
                        v_HeaderText = "View Comments";
                    break;
            }
            v_HTMLStr += "</table>";
            $("#divFGHistoryDetails").html(v_HTMLStr);
            $("#lblFGHistoryPopupHeader").text(v_HeaderText);
            OpenPopupDiv();
        },
        failure: function (data) {
            alert('fail');
        },
        error: function (data) {
            alert('error')
        }
    });
    return false;
};

/* TAB#2 -  Start*/
function ShowHideOptGrantedSection(o_Event) {
    if ($("#lblFCO02").is(":checked")) {
        $("#divOGNetOfCancellation").show();
        if (o_Event == "Change") {
            $("#chkFRSLapsedOptions").prop('checked', false);
            $("#chkFRSVestedCancelled").prop('checked', false);
            $("#chkFRSUnvestedCancelled").prop('checked', false);
        }
    }
    else { $("#divOGNetOfCancellation").hide(); }
};

function ShowHideForfeitureVeset(s_Event) {    
    if (($("#rdoTrueUpYes").is(":checked"))) {
        $("#divFRSTrueUpForfeiture").show();
        if (s_Event == "Change") {
            if (($("#rdoCancelationDate").is(":checked"))) {
                $("#rdoCancelationDate").prop('checked', true);
            }
            else {
                $("#rdoVestingDate").prop('checked', true);
            }           
        }
    }
    else {
        $("#divFRSTrueUpForfeiture").hide();
    }
};

function ViewFRSHistoryData(o_FRSID) {
    $.ajax({
        type: "POST",
        url: "ForfeitureSetup.aspx/BindFRSHistoryGrid",
        data: "{'o_FRSID':" + JSON.stringify(o_FRSID) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        processData: false,
        success: function (data) {
            var v_HTMLStr = "", v_HeaderText = "";
            v_HTMLStr = "<table class=\"Grid\" cellspacing=\"0\" cellpadding=\"6\" rules=\"all\" border=\"1\" id=\"gvMarketPriceIV\" style=\"border-collapse: collapse; font-size: 75%;\"><tr class=\"gridHeader\">";
            v_HTMLStr += "<th scope=\"col\">True Up</th><th scope=\"col\">Forfeiture Calculation On</th><th scope=\"col\">Remark</th><th scope=\"col\">Approval Status</th></tr>";
            for (var i = 0; i < data.d.length; i++) {
                var s_IsTrueUpChecked = data.d[i].IS_TRUE_UP_CHECKED ? "Yes" : "No";
                v_HTMLStr += "<tr class=\"gridItems\"><td>" + s_IsTrueUpChecked + "</td>";
                v_HTMLStr += "<td>" + data.d[i].FORFEITURE_CALC_ON_LABEL_ID + "</td>";
                v_HTMLStr += "<td style=\"text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;\">" + data.d[i].REMARK + "</td>";
                v_HTMLStr += "<td align=\"center\">" + data.d[i].APPROVAL_STATUS + "</td></tr>";
                if (v_HeaderText == "") {
                    if (data.d[i].APPLICABLE_TO_DATE == "")
                        v_HeaderText = "History ( " + data.d[i].APPLICABLE_FROM_DATE + " - Present )";
                    else v_HeaderText = "History ( " + data.d[i].APPLICABLE_FROM_DATE + " - " + data.d[i].APPLICABLE_TO_DATE + " )";
                }
            };
            v_HTMLStr += "</table>";
            $("#divFGHistoryDetails").html(v_HTMLStr);
            $("#lblFGHistoryPopupHeader").text(v_HeaderText);
            OpenPopupDiv();
        },
        failure: function (data) {
            alert('fail');
        },
        error: function (data) {
            alert('error')
        }
    });
};
/* TAB#2 -  End*/

/* TAB#3 -  Start*/
function ViewFRCReport(o_FGID, o_this) {
    HideMessageDiv();
    var str1 = $("#hdnFGCFGIDsToViewReport").val();
    var str2 = o_FGID;
    if (o_this.checked) {
        if (str1 == "")
            $("#hdnFGCFGIDsToViewReport").val(str2 + str1);
        else $("#hdnFGCFGIDsToViewReport").val(str1 + ',' + str2);
    }
    else {
        var tmp = $("#hdnFGCFGIDsToViewReport").val().toString().split(",");
        var index = $.inArray(o_FGID, tmp);
        if (index !== -1) {
            tmp.splice(index, 1);
        }
        tmp = tmp.join(",")
        $("#hdnFGCFGIDsToViewReport").val(tmp);
        $("#chk")[0].checked = false;
    }
};

function DisableFGControls() {
    $("#rdoTrueUpYes").attr("disabled", true);
    $("#rdoTrueUpNo").attr("disabled", true);
    $("#rdoCancelationDate").attr("disabled", true);
    $("#rdoVestingDate").attr("disabled", true);
    $("#lblFCO01").attr("disabled", true);
    $("#lblFCO02").attr("disabled", true);
    $("#txtFRSApplFromDate").attr("disabled", true);
    $("#txtFRSRemark").attr("disabled", true);
    $("#btnFRSSave").hide();
    $("#btnFRSReset").hide();
    $("#chkFRSLapsedOptions").attr("disabled", true);
    $("#chkFRSVestedCancelled").attr("disabled", true);
    $("#chkFRSUnvestedCancelled").attr("disabled", true);
    $("#tabs").tabs({ disabled: [0, 2] });
};
