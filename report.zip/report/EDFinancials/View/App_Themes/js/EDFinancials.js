﻿function LoadScript() {
    $("#pageloaddiv").fadeOut();

    $(".EDValidator").html('<div class="noImg"></div>');
    $(":input").blur(function () {
        var o_ObjectNames = "";
        
        if (typeof (Page_Validators) != "undefined") {

        for (var i in Page_Validators) {
            try {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                var tmp = o_ObjectNames.toString().split(",");
                if (!Page_Validators[i].isvalid) {

                    if ($.inArray(control.id, tmp) == -1) {
                        if ($("form").attr("class") == "Login" || $("form").attr("class") == "ForgetPassword" || $("form").attr("class") == "ChangePassword")
                            control.className = "form-control-ErrorLogin";
                        else {
                            o_ObjectNames = o_ObjectNames + "," + control.id;
                            if (control.className == "cTextBoxDatepick datepickerDateAssociated txtAssociateDate hasDatepicker")
                                control.className = "form-control-Error cTextBoxDatepick datepickerDateAssociated txtAssociateDate hasDatepicker";
                            else if (control.className == "form-control-Error cTextBoxDatepick datepickerDateAssociated txtAssociateDate hasDatepicker")
                                control.className = "form-control-Error cTextBoxDatepick datepickerDateAssociated txtAssociateDate hasDatepicker";
                            else if (control.className == "cTextBox txtEditCode")
                                control.className = "form-control-Error cTextBox txtEditCode";
                            else if (control.className == "form-control-Error cTextBox txtEditCode")
                                control.className = "form-control-Error cTextBox txtEditCode";
                            else if (control.className == "cTextBoxUpdCAA Validators" || control.className == "form-control-ErrorCAA")
                                control.className = "form-control-ErrorCAA";
                            else if (control.className == "cTextBoxUpdCAAPost Validators" || control.className == "form-control-ErrorCAAPost")
                                control.className = "form-control-ErrorCAAPost";
                            else control.className = "form-control-Error";
                        }
                    }
                    else {
                        if (control.className == "cTextBoxDatepick datepickerDateAssociated txtAssociateDate hasDatepicker")
                            control.className = "form-control-Error cTextBoxDatepick datepickerDateAssociated txtAssociateDate hasDatepicker";
                        else if (control.className == "cTextBox txtEditCode")
                            control.className = "form-control-Error cTextBox txtEditCode";
                        else if (control.className == "cTextBoxUpdCAA Validators")
                            control.className = "form-control-ErrorCAA";
                        else if (control.className == "cTextBoxUpdCAAPost Validators")
                            control.className = "form-control-ErrorCAAPost";
                        else control.className = "form-control-Error";
                    }
                }
                else {
                    if ($.inArray(control.id, tmp) == -1) {
                        if ($("form").attr("class") == "Login" || $("form").attr("class") == "ForgetPassword" || $("form").attr("class") == "ChangePassword")
                            control.className = "form-controlLogin";
                        else {
                            if (control.className == "cTextBox datepickerControl hasDatepicker")
                                control.className = "cTextBox datepickerControl hasDatepicker";
                            else if (control.className == "cTextBoxDatepick datepickerDateAssociated txtAssociateDate hasDatepicker" || control.className == "form-control-Error cTextBoxDatepick datepickerDateAssociated txtAssociateDate hasDatepicker")
                                control.className = "cTextBoxDatepick datepickerDateAssociated txtAssociateDate hasDatepicker";
                            else if (control.className == "cTextBox txtEditCode" || control.className == "form-control-Error cTextBox txtEditCode")
                                control.className = "cTextBox txtEditCode";
                            else if (control.className == "cTextBoxUpdCAA Validators" || control.className == "form-control-ErrorCAA" || control.className == "aspNetDisabled cTextBoxUpdCAA Validators")
                                control.className = "cTextBoxUpdCAA Validators";
                            else if (control.className == "cTextBoxUpdCAAPost Validators" || control.className == "form-control-ErrorCAAPost" || control.className == "aspNetDisabled cTextBoxUpdCAAPost Validators")
                                control.className = "cTextBoxUpdCAAPost Validators";
                            else
                                control.className = "cTextBox";
                        }
                    }
                }

            } catch (e) { }
        }
        }
        return false;
    });

    $(document).keyup(function (e) {
        if (e.keyCode == 27) {
            ClosePopupDiv();
        }
    });
};

function WebForm_OnSubmit() {
    if (typeof (ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) {
        var o_ObjectNames = "";
        for (var i in Page_Validators) {
            try {
                var control = document.getElementById(Page_Validators[i].controltovalidate);
                var tmp = o_ObjectNames.toString().split(",");
                if (!Page_Validators[i].isvalid) {

                    if ($.inArray(control.id, tmp) == -1) {
                        if ($("form").attr("class") == "Login" || $("form").attr("class") == "ForgetPassword" || $("form").attr("class") == "ChangePassword")
                            control.className = "form-control-ErrorLogin";
                        else control.className = "form-control-Error";
                    }
                    else control.className = "form-control-Error";
                }

                if ($.inArray(control.id, o_ObjectNames) == -1) {
                    o_ObjectNames = o_ObjectNames + "," + control.id;
                }

            } catch (e) { }
        }
        return false;
    }
    return true;
};

/* common method to close the modal popup div content */
function ClosePopupDiv() {
    $("#PopupMainContentDiv").hide('500', "swing", function () { $("#PopupBackgroundDiv").fadeOut("300"); });
}

/* common method to open the modal popup div content */
function OpenPopupDiv() {
    if (document.getElementById('PopupBackgroundDiv').style.display == 'none') {
        document.getElementById('PopupBackgroundDiv').style.display = '';
        $("#PopupBackgroundDiv").hide();
    }
    if (document.getElementById('PopupMainContentDiv').style.display == 'none') {
        document.getElementById('PopupMainContentDiv').style.display = '';
        $("#PopupMainContentDiv").hide();
    }
    $("#PopupBackgroundDiv").fadeIn(300, "linear", function () { $("#PopupMainContentDiv").show(500, "swing"); });
}


/* common method to close the modal popup div content */
function CloseModalDiv() {
    $("#ModalMainContentDiv").hide('500', "swing", function () { $("#ModalBackgroundDiv").fadeOut("300"); });
}

/* common method to open the modal popup div content */
function OpenModalDiv() {
    if (document.getElementById('ModalBackgroundDiv').style.display == 'none') {
        document.getElementById('ModalBackgroundDiv').style.display = '';
        $("#ModalBackgroundDiv").hide();
    }
    if (document.getElementById('ModalMainContentDiv').style.display == 'none') {
        document.getElementById('ModalMainContentDiv').style.display = '';
        $("#ModalMainContentDiv").hide();
    }
    $("#ModalBackgroundDiv").fadeIn(300, "linear", function () { $("#ModalMainContentDiv").show(500, "swing"); });
}

/* common method to hide message div content */
function HideMessageDiv() {
    $("#divMessegebox").hide("slow");
};

/* common method to show message div content */
function ShowMessageDiv(s_MsgText, s_Color) {
    $("#lblMessage").text(s_MsgText).css('color', 'red').focus();
    if (s_Color == 'blue')
        $("#lblMessage").css('color', 'blue');
    else $("#lblMessage").css('color', 'red');
    $("#lblMessage").focus();
    $("#divMessegebox").show("slow");
};

/* common method to hide option div content */
function HideOptionsDiv() {
    $(".divrevOptions").hide("slow");
};

/* common method to hide preview div content */
function HidePreviewDiv() {
    $("#divPreviewbox").hide("slow");
};

/* common method to convert input date to IST format */
function ConvertToDateTime(date) {
    var parts = date.split("/");
    switch (parts[1]) {
        case "Jan": parts[1] = 01; break;
        case "Feb": parts[1] = 02; break;
        case "Mar": parts[1] = 03; break;
        case "Apr": parts[1] = 04; break;
        case "May": parts[1] = 05; break;
        case "Jun": parts[1] = 06; break;
        case "Jul": parts[1] = 07; break;
        case "Aug": parts[1] = 08; break;
        case "Sep": parts[1] = 09; break;
        case "Oct": parts[1] = 10; break;
        case "Nov": parts[1] = 11; break;
        case "Dec": parts[1] = 12; break;
    }
    return new Date(parts[2], parts[1] - 1, parts[0]);
};

function CalculateSelectedControls(type, control) {
    var n_result = 0;
    if (type == 1)
        n_result = parseInt(control.val()) + 1;
    else
        n_result = parseInt(control.val()) + 1;

    return n_result;
};

/* common click event of multi-select dropdown-list control  */
function MultiselectClick(o_This) {
    var id = o_This.id;
    var v_SelectedIDs = [];
    $("[id*= " + id + "] input:checked").each(function () {
        if ($(this).is(":checked")) {
            if ($(this).val() == "--- Select All ---")
                v_SelectedIDs.pop($(this).val());
            else
                v_SelectedIDs.push($(this).val());
        }
    });
    id = id.replace('_chk', '_txt');
    if (v_SelectedIDs.length > 0)
        $("#" + id + "").val(v_SelectedIDs.join(","));
    else
        $("#" + id + "").val('--- Please Select ---');
    $("#" + id + "").attr("title", $("#" + id + "").val());
};

