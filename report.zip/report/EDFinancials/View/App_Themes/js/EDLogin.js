﻿//To get the Encypted Password 
function GetSecurePassword() {    
    window.text = document.getElementById("txtLgnPassword").value;    
    var txtLgnUserName = document.getElementById("txtLgnUserName").value;    
    var txtLgnCompanyName = document.getElementById("txtLgnCompanyName").value;
    if (window.text == "" || txtLgnUserName == "" || txtLgnCompanyName == "") {
        ValidatorEnable(document.getElementById('valLgnPassword'), true);
        ValidatorEnable(document.getElementById('valLgnUserName'), true);
        ValidatorEnable(document.getElementById('valLgnCompanyName'), true);
        return false;
    }

    window.key = 'esop';

    var useHashing = true;
    if (useHashing) {
        key = CryptoJS.MD5(key).toString();
        var k1 = key.substring(0, 16);
        key = key + k1;
    }
    window.options =
    {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    };
    window.textWordArray = CryptoJS.enc.Utf8.parse(text);
    window.keyHex = CryptoJS.enc.Hex.parse(key);

    window.encrypted = CryptoJS.TripleDES.encrypt(textWordArray, keyHex, options);

    document.getElementById("txtLgnPassword").value = encrypted.toString();

    return true;
}

function DisableBackButton() {
    window.history.forward()
}

DisableBackButton();
window.onload = DisableBackButton;
window.onpageshow = function (evt) { if (evt.persisted) DisableBackButton() }
window.onunload = function () { void (0) }