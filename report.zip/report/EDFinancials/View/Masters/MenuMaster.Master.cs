﻿using EDFinancials.Model.Masters;
using System;
using System.Web.UI.WebControls;
using System.Web;

namespace EDFinancials.View.Masters
{
    /// <summary>
    /// Code behind file for MenuMaster Page
    /// </summary>
    public partial class MenuMaster : System.Web.UI.MasterPage
    {
        #region CSRF(cross site request forgery)
        /*This method is used to handle Cross-Site Request Forgery (CSRF) attack that forces an end user to execute unwanted actions on a web application in which 
          they're currently authenticated .To prevent this attck we have to save the current session ID into ViewStateUserKey.This Property help you 
         prevent attacks on your application from malicious users. It does this by allowing you to assign an identifier to the view-state variable for 
         individual users so that they cannot use the variable to generate an attack */
        #region "Page Init Handler"
        /// <summary>
        /// This Method is used to save the Current Session value
        /// </summary>
        /// <param name="e">This is event Arguement object</param>
        override protected void OnInit(EventArgs e)
        {
            //CSRF(cross site request forgery)  
            base.OnInit(e);
           
            Page.ViewStateUserKey = Session.SessionID;

        }

        private void InitializeComponent()
        {

            this.Load += new EventHandler(Page_Load);
        }
        #endregion

         #endregion

        /// <summary>
        /// Page load method for MenuMaster
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetNoStore();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            using (MenuMasterModel menuMasterModel = new MenuMasterModel())
            {
                #region Session Fixation
                //NOTE: Keep this Session and Auth Cookie check
                if (Session["IsLoginSucceed"] != null && Session["AuthToken"] != null && Request.Cookies["AuthToken"] != null)
                {
                    /* This logic makes sure that even if the ASP.NET_SessionId cookie value is known to the hijacker, 
                    he will not be able to login to the application . A hijacker can know the Cookie value but he can’t know the Session value that is stored in the web server level, and as this 
                    AuthToken value changes every time the user logs in, the older value will not work . Unless the new Session (AuthToken) value and the new Cookie (AuthToken) 
                    are the same, no one will be able to login to the application. */
                    if (!Session["AuthToken"].ToString().Equals(Request.Cookies["AuthToken"].Value))
                    {
                        // redirect to the login page 
                        Response.Redirect("~/View/Logout.aspx", false);
                    }
                }

                #endregion

                if (menuMasterModel.IsSessionInvalid())
                {
                    Response.Redirect("~/View/Login.aspx", false);
                    return;
                }
                menuMasterModel.BindMainMenus(this);
                menuMasterModel.CheckaValidUser(this);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Accordion_Menu_ItemDataBound(object sender, AjaxControlToolkit.AccordionItemEventArgs e)
        {
            using (MenuMasterModel menuMasterModel = new MenuMasterModel())
            {
                menuMasterModel.ItemDataBound(e);
            }
        }

        /// <summary>
        /// This Method is responsible for gridview gv row dataBound.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">event arguement</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            using (MenuMasterModel menuMasterModel = new MenuMasterModel())
            {
                menuMasterModel.RowDataBound(e, this);
            }
        }
    }
}