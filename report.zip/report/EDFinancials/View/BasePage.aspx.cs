﻿using System;
using System.Web;

namespace EDFinancials.View
{
    /// <summary>
    /// Class is used as base page
    /// </summary>
    public partial class BasePage : System.Web.UI.Page
    {
        /// <summary>
        /// 
        /// </summary>
        public BasePage()
        {
            base.Load += new EventHandler(Page_Load);
        }

        /// <summary>
        /// Base page load method
        /// </summary>
        /// <param name="sender">The object which has raised the event</param>
        /// <param name="e">parameter called e that contains the event data</param>
        protected virtual void Page_Load(object sender, EventArgs e)
        {
            
        }
    }
}