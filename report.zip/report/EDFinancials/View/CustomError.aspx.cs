﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View
{

    /// <summary>
    /// Code behind file for CustomError Page
    /// </summary>
    public partial class CustomError : BasePage
    {
        /// <summary>
        /// Page load method for CustomError
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {

        }
    }
}