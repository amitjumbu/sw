﻿using System;
using System.Web;

namespace EDFinancials.View
{
    /// <summary>
    /// 
    /// </summary>
    public partial class BaseUC : System.Web.UI.UserControl
    {
        /// <summary>
        /// 
        /// </summary>
        public BaseUC()
        {
            base.Load += new EventHandler(Page_Load);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual void Page_Load(object sender, EventArgs e)
        {

        }
    }
}