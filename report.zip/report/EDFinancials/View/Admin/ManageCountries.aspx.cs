﻿using EDFinancials.Model.Admin;
using EDFinancials.Model.Generic;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.Admin
{
    /// <summary>
    /// Code behind file for ManageCountries Page
    /// </summary>
    public partial class ManageCountries : BasePage
    {
        int n_index = 0, n_ID = 0, n_Delete = 0, n_Action = 0, n_DefCountry = 0;
        /// <summary>
        /// Page load method for ManageCountries
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.Cache.SetNoStore();

                if (!Page.IsPostBack)
                {
                    using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                    {
                        countryMasterModel.BindCountryDetailsGrid(this);
                        countryMasterModel.BindCountryName(this);
                        countryMasterModel.BindCountryStatus(this);
                        countryMasterModel.BindStatus(this);
                        countryMasterModel.ReadL10N_UI(this);
                        ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    }
                }

            }
            catch (Exception Ex)
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", countryMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", countryMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row bound
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">GridViewRowEventArgs</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    countryMasterModel.BindRows(e, ref n_index, ref n_ID, ref n_Delete, ref n_Action, ref n_DefCountry);
                }
            }
            catch (Exception Ex)
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", countryMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", countryMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Apply Filters
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected void btnApplyFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    countryMasterModel.BindCountryDetailsGrid(this);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", countryMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", countryMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Clear Filters
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected void btnCMClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    countryMasterModel.ClearFilters(this);
                    countryMasterModel.BindCountryName(this);
                    countryMasterModel.BindCountryStatus(this);
                    countryMasterModel.BindStatus(this);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", countryMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", countryMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        /// <summary>
        /// Save records
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    countryMasterModel.CUDCountryDetails(this);
                    countryMasterModel.ClearFilters(this);
                    countryMasterModel.BindCountryName(this);
                }
            }
            catch (Exception Ex)
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", countryMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", countryMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Delete records
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    if (!string.IsNullOrEmpty(hdnDeletedRecords.Value))
                    {
                        countryMasterModel.CUDCountryDetails(this);
                        countryMasterModel.ClearFilters(this);
                        countryMasterModel.BindCountryName(this);
                    }
                    else
                    {
                        using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                        {
                            ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMSelectRecords", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterModel.BindCountryDetailsGrid(this);
                            countryMasterModel.BindCountryName(this);
                            ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", countryMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", countryMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Index change event
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">GridViewPageEventArgs</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    countryMasterModel.PageIndexChanging(sender, e, gv, hdnDeletedRecords.Value);
                }
            }
            catch (Exception Ex)
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", countryMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", countryMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is used for Hidden Link Yes Button to reactivate the country
        /// </summary>
        public void lnkYes_Click()
        {
            try
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    countryMasterModel.ReactiveCountryDetails(this);
                    countryMasterModel.ClearFilters(this);
                    countryMasterModel.BindCountryName(this);
                    countryMasterModel.BindCountryStatus(this);
                    countryMasterModel.BindStatus(this);
                    btnCMClearFilter.Visible = false;
                }
            }
            catch (Exception Ex)
            {
                using (CountryMasterModel countryMasterModel = new CountryMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", countryMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", countryMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}