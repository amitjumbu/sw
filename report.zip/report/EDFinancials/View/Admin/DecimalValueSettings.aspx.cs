﻿using System;
using System.Web.UI;
using EDFinancials.Model.Admin;
using EDFinancials.Model.Generic;

namespace EDFinancials.View.Admin
{
    /// <summary>
    /// Code behind page for DecimalValueSettings.aspx
    /// </summary>
    public partial class DecimalValueSettings : BasePage
    {
        /// <summary>
        /// Page Load Event of DecimalValueSettings page.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (DecimalValueSettingsModel decimalValueSettingsModel = new DecimalValueSettingsModel())
                    {
                        // Method is used to bind UI                        
                        decimalValueSettingsModel.BindPageUI(this);

                        // Method is used to bind rounding parm i.e. grid and drop down list ect.
                        decimalValueSettingsModel.BindDefaultRoundingParm(this);

                        // Mehtod is used to bind default rouding value and rounding parm to control                        
                        decimalValueSettingsModel.BindDefaultValueControls(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (DecimalValueSettingsModel decimalValueSettingsModel = new DecimalValueSettingsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", decimalValueSettingsModel.userSessionInfo.ACC_CompanyName).Replace("*", decimalValueSettingsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Update button click event on DecimalValueSettings page.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                using (DecimalValueSettingsModel decimalValueSettingsModel = new DecimalValueSettingsModel())
                {
                    decimalValueSettingsModel.UpdateDecimalValueSttings(this);
                }

            }
            catch (Exception Ex)
            {
                using (DecimalValueSettingsModel decimalValueSettingsModel = new DecimalValueSettingsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", decimalValueSettingsModel.userSessionInfo.ACC_CompanyName).Replace("*", decimalValueSettingsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}