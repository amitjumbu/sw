﻿using EDFinancials.Model.Admin;
using EDFinancials.Model.Generic;
using EDFinancials.Model.SuperAdmin;
using System;
using System.Web;
using System.Web.UI;

namespace EDFinancials.View.Admin
{
    /// <summary>
    /// Code behind file for ResetPassword Page
    /// </summary>
    public partial class ResetPassword : BasePage
    {
        /// <summary>
        /// Page load method for ResetPassword
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.Cache.SetNoStore();

                if (!Page.IsPostBack)
                {
                    using (ResetPasswordModel resetPasswordModel = new ResetPasswordModel())
                    {
                        resetPasswordModel.ReadL10N_UI(this);
                        resetPasswordModel.BindLoginIDs(this);
                        ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ResetPasswordModel resetPasswordModel = new ResetPasswordModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", resetPasswordModel.userSessionInfo.ACC_CompanyName).Replace("*", resetPasswordModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Get User Details
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected void btnGetUserDetails_Click(object sender, EventArgs e)
        {
            try
            {
                using (ResetPasswordModel resetPasswordModel = new ResetPasswordModel())
                {
                    resetPasswordModel.BindLoginDetailData(this);
                }
            }
            catch (Exception Ex)
            {
                using (ResetPasswordModel resetPasswordModel = new ResetPasswordModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", resetPasswordModel.userSessionInfo.ACC_CompanyName).Replace("*", resetPasswordModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Reset Password
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected void btnRPResetPassword_Click(object sender, EventArgs e)
        {
            try
            {
                using (ResetPasswordModel resetPasswordModel = new ResetPasswordModel())
                {
                    resetPasswordModel.ResetPassword(this);
                }
            }
            catch (Exception Ex)
            {
                using (ResetPasswordModel resetPasswordModel = new ResetPasswordModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", resetPasswordModel.userSessionInfo.ACC_CompanyName).Replace("*", resetPasswordModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}