﻿using EDFinancials.Model.Admin;
using EDFinancials.Model.Generic;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.Admin
{
    /// <summary>
    /// Code behind page for ManageUsers.aspx
    /// </summary>
    public partial class Manage_Users : BasePage
    {
        int n_index = 0, n_ID = 0, n_Delete = 0, n_Action = 0;

        /// <summary>
        /// Page Load Event of ManageUser page.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                    {
                        // Bind UI
                        manageUsersModel.BindPageUI(this);
                        manageUsersModel.LoadEmpwisestatus(this);
                        loadIsActiveDropDown();
                        loadMasterGrid();
                        manageUsersModel.LoadUNameDropdown(this);
                    }
                }
                catch (Exception Ex)
                {
                    using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }

            ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
        }

        /// <summary>
        /// Used for Image buttons to load
        /// </summary>

        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl)
        {
            using (ImageButton img = new ImageButton())
            {
                img.ImageUrl = s_strUrl;
                img.ToolTip = s_strToolTip;
                img.Style.Add("cursor", "pointer");
                return img;
            }
        }

        /// <summary>
        /// this method is used to perform gridview row vise action
        /// </summary>

        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    manageUsersModel.BindRows(e, ref n_index, ref n_ID, ref n_Delete, ref n_Action);
                }
            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is resposible for handling the page index change of gridview.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Gridview Page Event</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    manageUsersModel.PageIndexChanging(sender, e, gv, hdnDeletedRecords.Value);
                }
            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD LOADS IS CONTENTS OF ISACTIVE DROPDOWNLIST 
        /// </summary>
        public void loadIsActiveDropDown()
        {
            try
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    manageUsersModel.Load_ddIsactive(ddMUIsActive, "S");
                    manageUsersModel.Load_ddIsactive(ddMUIsActiveEdit, "SE");
                    manageUsersModel.Load_ddIsactive(ddMuRoleEdit, "A");
                    manageUsersModel.Load_ddIsactive(ddMuUserType, "T");

                }
            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD LOADS GRID VIEW DATA
        /// </summary>
        public void loadMasterGrid()
        {
            try
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    manageUsersModel.LoadGridData(this, "R");
                }
            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button for Grid veiw filter depending on  the data selected.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event</param>
        protected void BtnGridfilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    manageUsersModel.FilterGridData(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD PERFORMS DELETE OPERATION IN DATABASE
        /// </summary>
        public void DeletegridviewRow()
        {
            try
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    manageUsersModel.PerformCUD(this, hdnDeletedRecords.Value.TrimStart(','), "D");
                    loadMasterGrid();
                    manageUsersModel.LoadUNameDropdown(this);
                    hdnDeletedRecords.Value = "";
                }
            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to Delete records on from Manage Module PAge.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event</param>
        protected void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(hdnDeletedRecords.Value))
                {
                    DeletegridviewRow();
                }
            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to insert new records to database
        /// </summary>
        /// <param name="sender">sender's Id</param>
        /// <param name="e">Event</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                switch (Convert.ToInt32(hdnBtnID.Value))
                {
                    case 0:
                        CUD("C");
                        break;
                    case 1:
                        CUD("U");
                        break;
                }
            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD PERFORMS CREATE / UPDATE OPERATIONS IN DATABASE.
        /// </summary>
        /// <param name="s_Action"></param>
        public void CUD(string s_Action)
        {
            try
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    manageUsersModel.PerformCUD(this, hdnEditMmId.Value.TrimStart(','), s_Action);
                    loadMasterGrid();
                    manageUsersModel.LoadUNameDropdown(this);
                }

            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button to clear filter on gridview.
        /// </summary>
        /// <param name="sender">Button's sender Id</param>
        /// <param name="e">Event</param>
        protected void btnSMClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                loadMasterGrid();
                btnMUClearFilter.Visible = false;
                ddMUUserName.SelectedIndex = -1;
                txtMuLoginId.Text = "";
                ddMUIsActive.SelectedIndex = 0;
            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is selected index change of ManageUser page's UserName dropdown. When Clicked, fetches respective LoginId and user status.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event</param>
        protected void ddMUUserName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    if (ddMUUserName.SelectedIndex != 0)
                    {
                        if (ddMUUserName.SelectedIndex > 0)
                            manageUsersModel.LoadUserDetails(this, "FU");
                    }
                    else
                    {
                        txtMuLoginId.Text = "";
                        ddMUIsActive.SelectedValue = "0";
                    }
                }

                loadMasterGrid();
            }
            catch (Exception Ex)
            {
                using (ManageUsersModel manageUsersModel = new ManageUsersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageUsersModel.userSessionInfo.ACC_CompanyName).Replace("*", manageUsersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}