﻿using EDFinancials.Model.Admin;
using EDFinancials.Model.Generic;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.Admin
{
    /// <summary>
    /// Code behind file for ManageRoles Page
    /// </summary>
    public partial class ManageRoles : BasePage
    {
        int n_Delete = 0, n_RMID = 0, n_RoleName = 0, n_IsActive = 0, n_IsDeleted = 0, n_Action = 0, n_index = 0, n_MMID = 0, n_MenuName = 0, n_View = 0, n_Add = 0, n_Edit = 0, n_Approve = 0, n_Disapprove = 0, n_Locked = 0, n_Unlocked = 0, n_indexRole = 0;
        /// <summary>
        /// Page load method for ManageRoles
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                    {
                        manageRolesModel.BindUI(this);

                        manageRolesModel.BindRoleName(this);

                        manageRolesModel.BindStatus(this);

                        manageRolesModel.BindGrid(this);

                        manageRolesModel.BindGridRights(this);

                        manageRolesModel.DisplayControls(this, "");
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is used For Create New button Event
        /// </summary>
        /// <param name="sender">Create New button</param>
        /// <param name="e">e</param>
        protected void btnMRShdnCreateNew_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.CreateNew(this);

                    manageRolesModel.BindRoleName(this);

                    manageRolesModel.BindStatus(this);

                    manageRolesModel.BindGrid(this);

                    manageRolesModel.DisplayControls(this, "btnMRShdnCreateNew");
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to perform delete operation
        /// </summary>
        /// <param name="sender">delete button</param>
        /// <param name="e">e</param>
        protected void btnMRSDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {

                    if (!string.IsNullOrEmpty(hdnDeletedRecords.Value))
                    {
                        hdnAddRecords.Value = "";

                        manageRolesModel.CUDManageRoles(this);

                        manageRolesModel.BindRoleName(this);

                        manageRolesModel.BindGrid(this);

                        manageRolesModel.DisplayControls(this, "btnMRSDelete");
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to apply filter button
        /// </summary>
        /// <param name="sender">apply filter button</param>
        /// <param name="e">e</param>
        protected void btnMRSApplyFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.BindGrid(this);

                    manageRolesModel.DisplayControls(this, "btnMRSApplyFilter");

                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear filter button
        /// </summary>
        /// <param name="sender">clear filter button</param>
        /// <param name="e">e</param>
        protected void btnMRSClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.BindRoleName(this);

                    manageRolesModel.BindStatus(this);

                    manageRolesModel.BindGrid(this);

                    manageRolesModel.DisplayControls(this, "btnMRSClearFilter");
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used for submit button
        /// </summary>
        /// <param name="sender">submit button</param>
        /// <param name="e">e</param>
        protected void btnMRSSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.btnMRSSubmit_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is for change status link button in role names grid
        /// </summary>
        /// <param name="sender">GridView status link button </param>
        /// <param name="e">e</param>
        protected void btnMRSChangeStatus_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.ChangeRoleStatus(this);

                    manageRolesModel.BindRoleName(this);

                    manageRolesModel.BindGrid(this);

                    manageRolesModel.BindGridRights(this);

                    manageRolesModel.DisplayControls(this, "btnMRSChangeStatus");
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to bind role priveledges grid on edit button click in role names grid
        /// </summary>
        /// <param name="sender">grid edit button</param>
        /// <param name="e">e</param>
        protected void btnMRPriviledgeGrid_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.BindGridRights(this);

                    manageRolesModel.BindRoleName(this);

                    manageRolesModel.BindGrid(this);

                    manageRolesModel.DisplayControls(this, "btnMRPriviledgeGrid");
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is for hidden link Yes button
        /// </summary>
        /// <param name="sender">hidden link Yes button</param>
        /// <param name="e">e</param>
        protected void lnkBtnYes_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.CUDManageRoles(this);

                    manageRolesModel.BindRoleName(this);

                    manageRolesModel.BindGrid(this);

                    manageRolesModel.DisplayControls(this, "lnkBtnYes");
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is for hidden link No button
        /// </summary>
        /// <param name="sender">hidden link No button</param>
        /// <param name="e">e</param>
        protected void lnkBtnNo_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.BindGrid(this);

                    manageRolesModel.DisplayControls(this, "lnkBtnNo");
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is for reset button
        /// </summary>
        /// <param name="sender">reset button</param>
        /// <param name="e">e</param>
        protected void btnMRSReset_Click(object sender, EventArgs e)
        {
            Page_Load(sender, e);
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.btnMRSReset_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to bind role names grid
        /// </summary>
        /// <param name="sender">Gridview gv</param>
        /// <param name="e">e</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.RowDataBound(sender, e, ref n_Delete, ref n_RMID, ref n_RoleName, ref n_IsActive, ref n_IsDeleted, ref n_Action, ref n_index);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to bind role priviledges grid 
        /// </summary>
        /// <param name="sender">GridView gv_Priviledges</param>
        /// <param name="e">e</param>
        protected void gv_PriviledgesRowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.RolesRowDataBound(sender, e, ref n_MMID, ref n_MenuName, ref n_View, ref n_Add, ref n_Edit, ref n_Delete, ref n_Approve, ref n_Disapprove, ref n_Locked, ref n_Unlocked, ref n_indexRole, ref hdnSavedIDs, this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is GridView gvPriviledges PreRender Event
        /// </summary>
        /// <param name="sender">GridView gvPriviledges</param>
        /// <param name="e">e</param>
        protected void gvPriviledges_PreRender(object sender, EventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.gvPriviledges_PreRender(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is Page Index Change Event
        /// </summary>
        /// <param name="sender">GridView gv</param>
        /// <param name="e">e</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    manageRolesModel.PageIndexChanging(e.NewPageIndex, this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageRolesModel manageRolesModel = new ManageRolesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageRolesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageRolesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}