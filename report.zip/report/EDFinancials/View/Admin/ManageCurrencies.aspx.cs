﻿using EDFinancials.Model.Admin;
using EDFinancials.Model.Generic;
using System;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.Admin
{
    /// <summary>
    /// Code behind file for ManageCurrencies Page
    /// </summary>
    public partial class ManageCurrencies : BasePage
    {
        int n_index = 0, n_ID = 0, n_Delete = 0, n_DefaultCurrency, n_Action = 0;

        /// <summary>
        /// Page load method for ManageCurrencies
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                    {
                        manageCurrenciesModel.BindUI(this);

                        manageCurrenciesModel.BindCurrencyName(this);

                        manageCurrenciesModel.BindCurrencyAlias(this);

                        manageCurrenciesModel.BindCurrencyDetailsGrid(this);

                        manageCurrenciesModel.DisplayContents(this, "");
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageCurrenciesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageCurrenciesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is used to Search or filter record
        /// </summary>
        /// <param name="sender">Search Button</param>
        /// <param name="e">e</param>
        protected void btnApplyFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    manageCurrenciesModel.BindCurrencyDetailsGrid(this);

                    manageCurrenciesModel.DisplayContents(this, "btnApplyFilter");
                }
            }
            catch (Exception Ex)
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageCurrenciesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageCurrenciesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is used to Delete the currency record
        /// </summary>
        /// <param name="sender">Delete Button</param>
        /// <param name="e">e</param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    if (!string.IsNullOrEmpty(hdnDeletedRecords.Value))
                    {
                        manageCurrenciesModel.DisplayContents(this, "btnDelete");

                        manageCurrenciesModel.BindCurrencyName(this);

                        manageCurrenciesModel.BindCurrencyAlias(this);

                        manageCurrenciesModel.BindCurrencyDetailsGrid(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageCurrenciesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageCurrenciesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row bound
        /// </summary>
        /// <param name="sender">gv GridView</param>
        /// <param name="e">e</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    manageCurrenciesModel.BindRows(e, ref n_index, ref n_ID, ref n_Delete, ref n_DefaultCurrency, ref n_Action);
                }
            }
            catch (Exception Ex)
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageCurrenciesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageCurrenciesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is used to Save and update the Currency Details
        /// </summary>
        /// <param name="sender">Currency Save Button</param>
        /// <param name="e">event id</param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    manageCurrenciesModel.CUDCurrencyDetails(this);

                    manageCurrenciesModel.BindCurrencyName(this);

                    manageCurrenciesModel.BindCurrencyAlias(this);

                    manageCurrenciesModel.BindCurrencyDetailsGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageCurrenciesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageCurrenciesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is used to Clear the textbox contents
        /// </summary>
        /// <param name="sender">Reset Button</param>
        /// <param name="e">e</param>
        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    manageCurrenciesModel.BindCurrencyName(this);

                    manageCurrenciesModel.BindCurrencyAlias(this);

                    manageCurrenciesModel.BindCurrencyDetailsGrid(this);

                    manageCurrenciesModel.DisplayContents(this, "btnClearFilter");
                }
            }
            catch (Exception Ex)
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageCurrenciesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageCurrenciesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is for hidden link Yes button
        /// </summary>
        public void lnkYes_Click()
        {
            try
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    manageCurrenciesModel.ReactivateCurrencyDetails(this);

                    manageCurrenciesModel.BindCurrencyName(this);

                    manageCurrenciesModel.BindCurrencyAlias(this);

                    manageCurrenciesModel.BindCurrencyDetailsGrid(this);

                    manageCurrenciesModel.DisplayContents(this, "lnkYes");
                }
            }
            catch (Exception Ex)
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageCurrenciesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageCurrenciesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Index Change Event
        /// </summary>
        /// <param name="sender">GridView gv</param>
        /// <param name="e">e</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    manageCurrenciesModel.PageIndexChanging(e.NewPageIndex, this);
                }
            }
            catch (Exception Ex)
            {
                using (ManageCurrenciesModel manageCurrenciesModel = new ManageCurrenciesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", manageCurrenciesModel.userSessionInfo.ACC_CompanyName).Replace("*", manageCurrenciesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}