﻿using EDFinancials.Model.Admin;
using EDFinancials.Model.Generic;
using System;
using System.Web.Services;
using System.Web.UI.WebControls;

namespace EDFinancials.View.Admin
{
    /// <summary>
    /// Code behind page for CompanySetup.aspx
    /// </summary>
    public partial class CompanySetup : BasePage
    {
        #region Declaration

        int n_ID = 0, n_index = 0, n_Action = 0, n_Delete = 0;

        #endregion

        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (CompanySetupModel companySetupModel = new CompanySetupModel())
                    {
                        companySetupModel.PopulateAllControls(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        #endregion

        #region Control Events

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.RowDataBindForGV(e, ref n_index, ref n_ID, ref n_Action, ref n_Delete);
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvAssociatedParams_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.gvAssociatedParams_RowDataBound(e);
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvListingHistory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.gvListingHistory_RowDataBound(e);
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid-view
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvCompanyNameHistory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.gvCompanyNameHistory_RowDataBound(e);
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// button click event to associate Stock exchange
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnCSAssociateSE_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.ReBindGridView(this, companySetupModel.SaveStockExchangeDetails(this, "A"));
                    companySetupModel.HideAddEditSection(this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to delete Stock Exchange
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnCSDeleteAll_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.ReBindGridView(this, companySetupModel.SaveStockExchangeDetails(this, "D"));
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.PageIndexChanging(e.NewPageIndex, this);
                    companySetupModel.ClearMessage(this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvAssociatedParams_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.gvAssociatedParams_PageIndexChanging(e.NewPageIndex, this);
                    companySetupModel.ClearMessage(this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to save Stock Exchange details
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.ReBindGridView(this, companySetupModel.SaveStockExchangeDetails(this, string.IsNullOrEmpty(hdnCSStockExchangeID.Value) ? "C" : "U"));
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to update company details
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnCSSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.UpdateCompanySetupDetails(this, 1);
                    companySetupModel.ReBindGridView(this, 0);
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Associate module button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnCSAssociateModule_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.UpdateCompanySetupDetails(this, 2);
                    companySetupModel.ReBindGridView(this, 0);
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// update link button click 
        /// </summary>
        public void lnkYes_Click()
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    companySetupModel.ReBindGridView(this, companySetupModel.SaveStockExchangeDetails(this, "U"));
                }
            }
            catch (Exception Ex)
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companySetupModel.userSessionInfo.ACC_CompanyName).Replace("*", companySetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Method is used to bind data to history grid
        /// </summary>
        /// <param name="o_CRMID">this is Type of operation to be performed</param>
        /// <returns>returns result</returns>
        [WebMethod]
        public static int UpdateDefaultCurrency(object o_CRMID)
        {
            try
            {
                using (CompanySetupModel companySetupModel = new CompanySetupModel())
                {
                    return companySetupModel.UpdateDefaultCurr(o_CRMID);
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion
    }
}