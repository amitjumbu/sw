﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.Admin
{
    /// <summary>
    /// Code behind page for Home.aspx
    /// </summary>
    public partial class Home : BasePage
    {
        /// <summary>
        /// Page Load Event of Home page.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            if (Session["IsLoginSucceed"] == null)
            {
                Response.Redirect("~/View/Login.aspx", false);
            }
        }
    }
}