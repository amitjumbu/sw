﻿using EDFinancials.Model;
using EDFinancials.Model.Generic;
using System;
using System.Drawing;
using System.Web.UI;

namespace EDFinancials.View
{
    /// <summary>
    /// Code behind file for ForgetPassword Page
    /// </summary>
    public partial class ForgetPassword : BasePage
    {
        /// <summary>
        /// Page load method for ForgetPassword
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    using (ForgetPasswordModel forgetPasswordModel = new ForgetPasswordModel())
                    {
                        // Method is used to bind UI
                        forgetPasswordModel.BindForgotPasswordPageUI(this);
                    }
                }
                catch (Exception Ex)
                {
                    using (ForgetPasswordModel forgetPasswordModel = new ForgetPasswordModel())
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forgetPasswordModel.userSessionInfo.ACC_CompanyName).Replace("*", forgetPasswordModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }
        }

        /// <summary>
        /// This is submit button's click event on forgotpassword page.
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected void btnFPSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForgetPasswordModel forgetPasswordModel = new ForgetPasswordModel())
                {
                    // Method is used to bind UI
                    forgetPasswordModel.ValidateLoginUser(this);
                }
            }
            catch (Exception Ex)
            {
                using (ForgetPasswordModel forgetPasswordModel = new ForgetPasswordModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forgetPasswordModel.userSessionInfo.ACC_CompanyName).Replace("*", forgetPasswordModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}