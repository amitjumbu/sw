﻿using EDFinancials.Model;
using EDFinancials.Model.Generic;
using System;
using System.Drawing;
using System.Web;
using System.Web.UI;

namespace EDFinancials.View
{
    /// <summary>
    /// Code behind file for Login Page
    /// </summary>
    public partial class Login : System.Web.UI.Page
    {
        /// <summary>
        /// Page load method for Login
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetNoStore();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));

            if (Session["IsLoginSucceed"] == null)
            {
                frmLogin.Visible = true;
                if (!Page.IsPostBack)
                {
                    try
                    {
                        using (LoginModel loginModel = new LoginModel())
                        {
                            // Method is used to bind UI
                            loginModel.BindLoginPageUI(this);
                        }
                    }
                    catch (Exception Ex)
                    {
                        using (LoginModel loginModel = new LoginModel())
                        {
                            CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + (string.IsNullOrEmpty(loginModel.userSessionInfo.ACC_CompanyName) ? string.Empty : CommonConstantModel.s_ExceptCompUserName.Replace("@", loginModel.userSessionInfo.ACC_CompanyName).Replace("*", loginModel.userSessionInfo.ACC_UserName)) + "\n" + Ex.StackTrace));
                        }
                    }
                }
            }
            else
            {
                Response.Redirect(Convert.ToString(Session["FirstPage"]));
            }
        }

        /// <summary>
        /// This is signIn button's click event.
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected void btnSignIn_Click(object sender, EventArgs e)
        {
            try
            {
                using (LoginModel loginModel = new LoginModel())
                {
                    Session["FirstPage"] = Convert.ToString(loginModel.ValidateLoginUser(this));

                    // Redirect to home page based on User Type
                    Response.Redirect(Convert.ToString(Session["FirstPage"]), false);
                    Session["IsLoginSucceed"] = "TRUE";

                    #region Session Fixation
                    //The below code is added to solve the session Fixation 
                    // create a new GUID and save into the session
                    string guid = loginModel.EncryptGuid(Guid.NewGuid().ToString());
                    Session["AuthToken"] = guid;

                    // now create a new cookie with this guid value
                    Response.Cookies.Add(new HttpCookie("AuthToken", guid));
                    Response.Cookies["AuthToken"].Secure = true;
                    Response.Cookies["AuthToken"].HttpOnly = true;
                    #endregion
                }
            }
            catch (EDFinancialsException Ex)
            {
                Session.Remove("IsLoginSucceed");
                Session.Abandon();
                lblLgnMessage.ForeColor = Color.Red;
                lblLgnMessage.Text = Ex.Message.ToString();
            }
            catch (Exception Ex)
            {
                if (Ex.Message.Contains("Cannot open database"))
                {
                    Session.Remove("IsLoginSucceed");
                    Session.Abandon();

                    lblLgnMessage.ForeColor = Color.Red;
                    lblLgnMessage.Text = "Invalid Company Name";
                }
                else if (Ex.Message.Contains("Could not find stored procedure"))
                {
                    Session.Remove("IsLoginSuceed");
                    Session.Abandon();
                    lblLgnMessage.ForeColor = Color.Red;
                    lblLgnMessage.Text = "Please contact to Super Admin / Admin.";
                }

                using (LoginModel loginModel = new LoginModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + (string.IsNullOrEmpty(loginModel.userSessionInfo.ACC_CompanyName) ? string.Empty : CommonConstantModel.s_ExceptCompUserName.Replace("@", loginModel.userSessionInfo.ACC_CompanyName).Replace("*", loginModel.userSessionInfo.ACC_UserName)) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}