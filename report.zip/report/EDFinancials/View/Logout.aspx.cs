﻿using System;
using System.Web;
using EDFinancials.Model;

namespace EDFinancials.View
{
    /// <summary>
    /// Code behind file for Logout Page
    /// </summary>
    public partial class Logout : BasePage
    {
        /// <summary>
        /// Page load method for Logout
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetNoStore();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            Session.Abandon();
            Session.Clear();
            Session.RemoveAll();
            System.Web.Security.FormsAuthentication.SignOut();
            HttpContext.Current.Session.Abandon();

            SessionContext.UserSessionInfo userSessionInfo;
            userSessionInfo = SessionContext.GetUserSessionInfoValues();
            userSessionInfo.ACC_UserID = 0;
            userSessionInfo.ACC_UerTypeID = 0;
            userSessionInfo.ACC_UserName = string.Empty;
            userSessionInfo.ACC_CompanyName = string.Empty;
            #region Session Fixation
            /* Here we first explicitly expire the ASP.NET_SessionId cookie to make sure that this cookie is removed from the browser 
             when the user clicks on the Logout button, and after that, we expire the AuthToken cookie as well.*/
            if (Request.Cookies["ASP.NET_SessionId"] != null)
            {
                Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
            }

            if (Request.Cookies["AuthToken"] != null)
            {
                Response.Cookies["AuthToken"].Value = string.Empty;
                Response.Cookies["AuthToken"].Expires = DateTime.Now.AddMonths(-20);
            }
            #endregion
        }       
    }
}