﻿using System;

namespace EDFinancials.View
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PageNotFound : BasePage
    {
        /// <summary>
        /// The Page Load Event
        /// </summary>
        /// <param name="sender">PageNotFound Page</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {

        }
    }
}