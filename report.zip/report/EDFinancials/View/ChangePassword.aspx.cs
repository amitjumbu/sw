﻿using EDFinancials.Model;
using EDFinancials.Model.Generic;
using System;
using System.Web.UI;

namespace EDFinancials.View
{
    /// <summary>
    /// Code behind file for ChangePassword Page
    /// </summary>
    public partial class ChangePassword : BasePage
    {
        /// <summary>
        /// Page load method for ChangePassword
        /// </summary>
        /// <param name="sender">sender's id</param>
        /// <param name="e">event id</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    using (ChangePasswordModel changePasswordModel = new ChangePasswordModel())
                    {
                        // Method is used to bind UI
                        changePasswordModel.ValidateUserInfo(this, Server.UrlDecode(Request.QueryString["UID"]).Split('|'));
                        changePasswordModel.BindChangePasswordPageUI(this);
                    }
                }
                catch (Exception Ex)
                {
                    using (ChangePasswordModel changePasswordModel = new ChangePasswordModel())
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", changePasswordModel.userSessionInfo.ACC_CompanyName).Replace("*", changePasswordModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }
        }

        /// <summary>
        /// this is submit button click event ofchangepassword page.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCPSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                using (ChangePasswordModel changePasswordModel = new ChangePasswordModel())
                {
                    // Method is used to bind UI
                    changePasswordModel.ChangePassword(this);
                }
            }
            catch (Exception Ex)
            {
                using (ChangePasswordModel changePasswordModel = new ChangePasswordModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", changePasswordModel.userSessionInfo.ACC_CompanyName).Replace("*", changePasswordModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}