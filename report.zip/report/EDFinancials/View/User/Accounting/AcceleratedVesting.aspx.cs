﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// AcceleratedVesting class
    /// </summary>
    public partial class AcceleratedVesting : BasePage
    {
        /// <summary>
        /// This dictionary is used to set values
        /// </summary>
        public Dictionary<string, int> dictionary = new Dictionary<string, int>();

        /// <summary>
        /// Page load method
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    if (!Page.IsPostBack)
                    {

                        acceleratedVestingModel.CreateDatatbleColumnsGratwise();
                        acceleratedVestingModel.CreateDatatbleColumnsVestwise();
                        SetValuesToDictionary();
                        acceleratedVestingModel.GetDataAcceleratedVesting(this);
                        acceleratedVestingModel.PopulateAllControls(this);
                        acceleratedVestingModel.BindDropDown(this);
                        acceleratedVestingModel.GetCustomizeViewData(this);
                    }
                    acceleratedVestingModel.BindGridView(this);
                    acceleratedVestingModel.AssignValuesFromTextbox(Request.Form, this);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to set values
        /// </summary>
        private void SetValuesToDictionary()
        {
            dictionary.Add("n_Index", 0);
            dictionary.Add("n_RowIndex", 1);
            dictionary.Add("n_ID", 0);
            dictionary.Add("n_Select", 0);
            dictionary.Add("n_OptionDetails", 0);
            dictionary.Add("n_AcceleratedQty", 0);
            dictionary.Add("n_AcceleratedDate", 0);
            dictionary.Add("n_Operation_Date", 0);
            dictionary.Add("n_EmployeeName", 0);
            dictionary.Add("n_EmployeeID", 0);
            dictionary.Add("n_SchemeName", 0);
            dictionary.Add("n_GrantRegistrationID", 0);
            dictionary.Add("n_GrantOptionID", 0);
            dictionary.Add("n_Operation_ID", 0);
            dictionary.Add("n_Action", 0);
            dictionary.Add("n_Granted", 0);
            dictionary.Add("n_GrantDate", 0);
        }

        /// <summary>
        /// This method is used to search record based on filters
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnAVSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.btnAVSearch_Click(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This metod is used to reset filters
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnAVReset_Click(object sender, EventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.btnAVReset_Click(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to save record
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnAVSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.btnAVSave_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// this method is used to delete record
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnAVDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.btnAVSave_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// imgButton Click Event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        public void imgButton_Click(object sender, EventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.imgButton_Click(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to get Options Details based on OptGrantID
        /// </summary>
        /// <param name="s_OptGrantID">OptGrantedID is primary key in GrantedOptions table</param>
        /// <param name="s_ButtonName">s_ButtonName is button name</param>
        /// <returns>Serializered string</returns>
        [WebMethod]
        public static string GetOptionsDetails_JSON(object s_OptGrantID, object s_ButtonName)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    return acceleratedVestingModel.GetOptionsDetails_JSON(Convert.ToString(s_OptGrantID), Convert.ToString(s_ButtonName));
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// RowDataBound for GridView gv
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gvSearch_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.gvSearch_RowDataBound(this, e, ref dictionary, sender);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row Data Bound Event Of Child GridView
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        internal void childGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.childGrid_RowDataBound(sender, e, this);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row Data Bound Event Of Child GridView
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        internal void childGridAV_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.childGridAV_RowDataBound(sender, e, this);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        /// <summary>
        /// PageIndexChanging for gv
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gvSearch_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gvAddOrUpdate_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.gvAddOrUpdate_RowDataBound(this, e, ref dictionary, sender);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Used to handle page index change event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gvAddOrUpdate_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.gvAddOrUpdate_PageIndexChanging(this, e, ref dictionary, sender);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// ddlDefaultView selected index change event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void ddlDefaultView_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.LoadSelcted_View(this);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// btnSetDefault click event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnSetDefault_Click(object sender, EventArgs e)
        {
            try
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    acceleratedVestingModel.SetDefaultView(this);
                }
            }
            catch (Exception Ex)
            {
                using (AcceleratedVestingModel acceleratedVestingModel = new AcceleratedVestingModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", acceleratedVestingModel.userSessionInfo.ACC_CompanyName).Replace("*", acceleratedVestingModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}