﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Code file for Employee Master page.
    /// </summary>
    public partial class EmployeeMaster : BasePage
    {
        int n_index = 0;

        /// <summary>
        /// static variable to return result to Json methods.
        /// </summary>
        public static string s_result;

        /// <summary>
        /// This HashTable is used to pass index key and value pair as ref parameter to GrdidView RowDataBound Method.
        /// </summary>
        Hashtable hash_EmpMaster = new Hashtable();

        /// <summary>
        /// Page Load event of Employee Master Page.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
            {
                if (!IsPostBack)
                {
                    employeeMasterModel.LoadInitialSettings(this);

                    // Encrypts query string which has to be passed on to report page.
                    employeeMasterModel.EncryptData(this);
                }
                ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }

        }

        /// <summary>
        /// This method is used for grid =view row data bound.
        /// </summary>
        /// <param name="sender">Sender's Id</param>
        /// <param name="e">Gridview Row Id</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    employeeMasterModel.BindRows(e, ref n_index, ref hash_EmpMaster);
                }
            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is a Search button click event.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void BtnEM_Search_Click(object sender, EventArgs e)
        {
            try
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    employeeMasterModel.FilterGridData(this);
                }
            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  This is a Submit button click event.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void btnEM_Submit_Click(object sender, EventArgs e)
        {
            try
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    employeeMasterModel.PerformCUD(this);
                }
            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is delete button click event.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void btnEM_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    employeeMasterModel.PerformCUD(this);
                }
            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to select only the required employee dedails from the list.
        /// </summary>
        /// <param name="s_EMPID">EmId</param>
        /// <param name="s_Employee_Id">Employee Id</param>
        /// <param name="s_BtnId">Btn Id</param>
        /// <param name="s_ModifiedField">Modified Field</param>>
        /// <returns>returns List of employee details</returns>
        [WebMethod]
        public static ModuleList[] Get_Filtered_AssociationList(string s_EMPID, string s_Employee_Id, string s_BtnId, string s_ModifiedField)
        {
            List<ModuleList> Detail = new List<ModuleList>();
            DataTable dt_FilteredModuleList = new DataTable();

            try
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    dt_FilteredModuleList = employeeMasterModel.View_EmployeeDetails(s_EMPID, s_Employee_Id, s_BtnId, s_ModifiedField);
                    foreach (DataRow dtRow in dt_FilteredModuleList.Rows)
                    {
                        if (s_BtnId.Equals("ViewEmployeeDetails"))
                        {
                            ModuleList DataObj = new ModuleList();
                            DataObj.s_DateOfJoining = dtRow["Date of Joining"].ToString() == "1/1/1900 12:00:00 AM" ? " " : dtRow["Date of Joining"].ToString();
                            DataObj.s_Designation = dtRow["Designation"].ToString();
                            DataObj.s_Department = dtRow["Department"].ToString();
                            DataObj.s_Is_Senior_Management = dtRow["Is Senior Management"].ToString();
                            DataObj.s_Country = dtRow["Country"].ToString();
                            DataObj.s_ApprovalStatus = dtRow["Approval Status"].ToString();

                            DataObj.s_SBU = dtRow["SBU"].ToString();
                            DataObj.s_Location = dtRow["Location"].ToString();

                            DataObj.s_CostCentre = dtRow["Cost Centre"].ToString();
                            DataObj.s_Entity = dtRow["Entity"].ToString();
                            DataObj.s_Grade = dtRow["Grade"].ToString();
                            Detail.Add(DataObj);
                        }
                        else
                        {
                            ModuleList DataObj = new ModuleList();
                            DataObj.s_ModifiedField = dtRow["FIELD_NAME"].ToString();
                            DataObj.s_ModifiedTo = dtRow["PARAM_VALUE"].ToString();
                            DataObj.s_ApplicableFrom = dtRow["APPLICABLE_FROM"].ToString();
                            DataObj.s_ApplicableTill = dtRow["APPLICABLE_TO"].ToString() == "" ? "-" : dtRow["APPLICABLE_TO"].ToString();
                            Detail.Add(DataObj);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
            return Detail.ToArray();
        }

        /// <summary>
        /// This method is used to select only the required employee dedails from the list.
        /// </summary>
        /// <param name="s_Employee_Id">Employee Id</param>
        /// <param name="s_ValidateType">Validate Type</param>
        /// <param name="s_NewApplicableDate">New ApplicableDate</param>>
        /// <returns>returns List of employee details</returns>
        [WebMethod]
        public static string Validate_EmployeeId(string s_Employee_Id, string s_ValidateType, string s_NewApplicableDate)
        {
            try
            {
                if (!string.IsNullOrEmpty(s_Employee_Id))
                    using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                    {
                        s_result = employeeMasterModel.Validate_EmployeeId(s_Employee_Id, s_ValidateType, s_NewApplicableDate);
                    }

            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
            return s_result;
        }


        /// <summary>
        /// Class for binding data
        /// </summary>		
        public class ModuleList
        {
            /// <summary>
            /// Tracking Modified field Name
            /// </summary>
            public string s_ModifiedField { get; set; }

            /// <summary>
            ///Tracking Field Modified To.
            /// </summary>
            public string s_ModifiedTo { get; set; }

            /// <summary>
            /// Tracking Applicable Date
            /// </summary>
            public string s_ApplicableFrom { get; set; }

            /// <summary>
            ///  Tracking Applicable till.
            /// </summary>
            public string s_ApplicableTill { get; set; }

            /// <summary>
            /// Employee Date of Joining.
            /// </summary>
            public string s_DateOfJoining { get; set; }

            /// <summary>
            /// employee Grade
            /// </summary>
            public string s_Grade { get; set; }

            /// <summary>
            /// Employee Designation
            /// </summary>
            public string s_Designation { get; set; }

            /// <summary>
            /// Employee Copuntry
            /// </summary>
            public string s_Country { get; set; }

            /// <summary>
            /// Is Employee Senior Management
            /// </summary>
            public string s_Is_Senior_Management { get; set; }

            /// <summary>
            /// Employee SBU
            /// </summary>
            public string s_SBU { get; set; }

            /// <summary>
            /// Employee Location
            /// </summary>
            public string s_Location { get; set; }

            /// <summary>
            /// Employee Department
            /// </summary>
            public string s_Department { get; set; }

            /// <summary>
            /// Employee Entity
            /// </summary>
            public string s_Entity { get; set; }

            /// <summary>
            /// Employee CostCentre
            /// </summary>
            public string s_CostCentre { get; set; }

            /// <summary>
            /// Employee ApprovalStatu
            /// </summary>
            public string s_ApprovalStatus { get; set; }


        }

        /// <summary>
        /// This is button click of ClearSearch button.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void btnEM_ClearSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    employeeMasterModel.FilterGridData(this);

                }
            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is resposible for handling the page index change of gridview.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Gridview Page Event</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
            {
                try
                {
                    employeeMasterModel.PageIndexChanging(e, this);
                }
                catch (Exception Ex)
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// ddlDefaultView change index event
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void ddlDefaultView_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    employeeMasterModel.LoadSelcted_View(this);
                }
            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// btnSetDefault click event
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void btnSetDefault_Click(object sender, EventArgs e)
        {
            try
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    employeeMasterModel.SetDefaultView(this);
                }
            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}