﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// AccountingScheduledReports
    /// </summary>
    public partial class AccountingScheduledReports : BasePage
    {
        /// <summary>
        /// This dictionary is used to set values
        /// </summary>
        public Dictionary<string, int> dictionary = new Dictionary<string, int>();

        /// <summary>
        /// Page load method
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (AccountingScheduledReportsModel accountingScheduledReportsModel = new AccountingScheduledReportsModel())
                {
                    if (!Page.IsPostBack)
                    {
                        accountingScheduledReportsModel.PopulateAllControls(this);
                    }

                    SetValuesToDictionary();
                    accountingScheduledReportsModel.BindGridView(this);
                }

            }
            catch (Exception Ex)
            {
                using (AccountingScheduledReportsModel accountingScheduledReportsModel = new AccountingScheduledReportsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingScheduledReportsModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingScheduledReportsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to set values
        /// </summary>
        private void SetValuesToDictionary()
        {
            dictionary.Add("n_Index", 0);
            dictionary.Add("n_ID", 0);
            dictionary.Add("n_ReportAsOn", 0);
            dictionary.Add("n_ScheduleDate", 0);
            dictionary.Add("n_ReportStatus", 0);
            dictionary.Add("n_MailStatus", 0);
            dictionary.Add("n_MailID", 0);
            dictionary.Add("n_ReportName", 0);
            dictionary.Add("n_Download", 0);
        }

        /// <summary>
        /// This method is used to Reset values
        /// </summary>
        private void ResetValuesToDictionary()
        {
            dictionary["n_Index"] = 0;;
            dictionary["n_ID"] = 0;;
            dictionary["n_ReportAsOn"] = 0;;
            dictionary["n_ScheduleDate"] = 0;;
            dictionary["n_ReportStatus"] = 0;;
            dictionary["n_MailStatus"] = 0;;
            dictionary["n_MailID"] = 0;;
            dictionary["n_ReportName"] = 0;;
            dictionary["n_Download"] = 0;;
        }

        /// <summary>
        /// RowDataBound method
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccountingScheduledReportsModel accountingScheduledReportsModel = new AccountingScheduledReportsModel())
                {
                    accountingScheduledReportsModel.gv_RowDataBound(this, e, ref dictionary, sender);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingScheduledReportsModel accountingScheduledReportsModel = new AccountingScheduledReportsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingScheduledReportsModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingScheduledReportsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// PageIndexChanging event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AccountingScheduledReportsModel accountingScheduledReportsModel = new AccountingScheduledReportsModel())
                {
                    ResetValuesToDictionary();
                    accountingScheduledReportsModel.PageIndexChanging(e.NewPageIndex, this);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingScheduledReportsModel accountingScheduledReportsModel = new AccountingScheduledReportsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingScheduledReportsModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingScheduledReportsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// btnReportDownload click event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnReportDownload_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingScheduledReportsModel accountingScheduledReportsModel = new AccountingScheduledReportsModel())
                {
                    accountingScheduledReportsModel.DownloadFile(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingScheduledReportsModel accountingScheduledReportsModel = new AccountingScheduledReportsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingScheduledReportsModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingScheduledReportsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}