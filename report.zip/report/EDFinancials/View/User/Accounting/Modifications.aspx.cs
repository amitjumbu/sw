﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Code file for Modification Master page.
    /// </summary>
    public partial class Modifications : BasePage
    {
        #region Static Variables
        /// <summary>
        /// Public int Variables
        /// </summary>
        public int n_Opt_Granted_Id = 0, n_Opt_Granted_Id_child = 0, n_Opt_Vest_Id = 0, n_index = 0, n_ID = 0, n_Action = 0, n_AMMID = 0, n_AGRMID = 0, n_AGDID = 0, n_EMPID = 0, n_EmployeeId = 0, n_EmployeeName = 0, n_SchemeName = 0, n_GrantOptId = 0, n_GrantRegId = 0, n_GrantDate = 0, n_Outstanding = 0, n_System_IV_Cost = 0, n_System_FV_Cost = 0, Iv_Incremental = 0, Fv_Incremental = 0, n_Operation_ID = 0, n_IsLock = 0, n_Granted = 0, n_IvPostModCost = 0, n_FvPostModCost = 0, n_Delete = 0, n_FairValue = 0, n_IntrinsicValue = 0, rowIndex = 1, n_VestIndex = 0, n_VestID = 0, n_VestDelete = 0, n_VestAction = 0, n_VestGrantDate = 0, n_VestIndexLockedRec = 0, n_VestIDLockedRec = 0, n_VestDeleteLockedRec = 0, n_VestActionLockedRec = 0, n_VestGrantDateLockedRec = 0, n_VestPercent = 0, n_FairValVest = 0, n_IntrsicValVest = 0, n_VestOptID = 0, n_gvAction = 0, n_Operation_Date = 0, n_EMPID_child = 0, n_IS_JOINT_MODIFICATION = 0, n_EMPMODITYPE = 0;

        #endregion

        int[] n_colIndex = new int[20];

        string AGRMID = "";
        string s_Empid = "";
        string Opt_Grnt_id = "";

        #region Page Load Event
        /// <summary>
        /// Page Load event of Employee Master Page.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    if (!IsPostBack)
                    {
                        modificationsModel.LoadInitialSettings(this);
                    }
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region  Button Control Events
        /// <summary>
        /// This is a Search button click event.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void BtnMD_Search_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.FilterGridData(this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is button click of ClearSearch button.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void btnEM_ClearSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.FilterGridData(this);

                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is delete button click event.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void btnMD_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.PerformCUD(this);
                    clearColumnIndexes();
                    modificationsModel.Get_Modification_Details(this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  This is a btnMD_Populate button click event.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void btnMD_Populate_Click(object sender, EventArgs e)
        {
            try
            {
                clearColumnIndexes();
                Populate_Modification_Details();

            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  This is a btnMD_Calculate button click event.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void btnMD_Calculate_Click(object sender, EventArgs e)
        {
            using (ModificationsModel modificationsModel = new ModificationsModel())
            {
                try
                {
                    modificationsModel.GetValuesFromTextbox(Request.Form, this);
                    modificationsModel.ValidateDates(this, "VESTING_PERIOD");
                    modificationsModel.ValidateDates(this, "EXERCISE_PERIOD");
                    modificationsModel.ValidateDates(this, "EXERCISE_PRICE");
                    if (modificationsModel.IsInput_Valid())
                    {
                        modificationsModel.GetCalculationsOfIncrementals(this, true);
                    }
                    else
                        modificationsModel.GetCalculationsOfIncrementals(this, false);
                }
                catch (Exception Ex)
                {
                    if (Ex.Message.Contains("This Field cannot be blank:"))
                    {
                        // Do Nothing
                        modificationsModel.Populate_Modification_Details(this);
                    }
                    else
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }
        }

        /// <summary>
        /// This is a btnMD_Save button click event.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void btnMD_Save_Click(object sender, EventArgs e)
        {
            using (ModificationsModel modificationsModel = new ModificationsModel())
            {
                try
                {
                    modificationsModel.GetValuesFromTextbox(Request.Form, this);
                    modificationsModel.ValidateDates(this, "VESTING_PERIOD");
                    modificationsModel.ValidateDates(this, "EXERCISE_PERIOD");
                    modificationsModel.ValidateDates(this, "EXERCISE_PRICE");
                    if (modificationsModel.IsInput_Valid())
                    {
                        modificationsModel.GetOnlyModifiedRows(Request.Form, this);
                        modificationsModel.GetCalculationsOfIncrementals(this, true);

                        clearColumnIndexes();
                        modificationsModel.PerformCUD(this);
                        clearColumnIndexes();
                        modificationsModel.Get_Modification_Details(this);
                    }
                }
                catch (Exception Ex)
                {
                    if (Ex.Message.Contains("This Field cannot be blank:"))
                    {
                        modificationsModel.Populate_Modification_Details(this);
                    }
                    else if (Ex.Message.Contains("There has a been a modification"))
                    {
                        // Do nothing.
                    }
                    else if (Ex.Message.Contains("Please change something to save"))
                    {
                        modificationsModel.Populate_Modification_Details(this);
                    }
                    else
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }
        }

        /// <summary>
        /// This is the click event of Reset button of Modifications Page.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void btnMD_Reset_Click(object sender, EventArgs e)
        {
            try
            {
                btnMD_Populate_Click(sender, e);
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        #region Clear Index
        /// <summary>
        /// This method clears / sets to zero, the values of all column indexes that are going to be refered while binding grids.
        /// </summary>
        public void clearColumnIndexes()
        {
            n_Opt_Granted_Id = 0; n_Opt_Vest_Id = 0; n_index = 0; n_ID = 0; n_Action = 0; n_AMMID = 0; n_AGRMID = 0; n_AGDID = 0; n_EMPID = 0; n_EmployeeId = 0; n_EmployeeName = 0; n_SchemeName = 0; n_GrantOptId = 0; n_GrantRegId = 0; n_GrantDate = 0; n_Outstanding = 0; n_System_IV_Cost = 0; n_System_FV_Cost = 0; Iv_Incremental = 0; Fv_Incremental = 0; n_Operation_ID = 0; n_IsLock = 0; n_Granted = 0; n_IvPostModCost = 0; n_FvPostModCost = 0; n_Delete = 0; n_FairValue = 0; n_IntrinsicValue = 0; rowIndex = 1; n_VestIndex = 0; n_VestID = 0; n_VestDelete = 0; n_VestAction = 0; n_VestGrantDate = 0; n_VestIndexLockedRec = 0; n_VestIDLockedRec = 0; n_VestDeleteLockedRec = 0; n_VestActionLockedRec = 0; n_VestGrantDateLockedRec = 0; n_VestPercent = 0; n_FairValVest = 0; n_IntrsicValVest = 0; n_VestOptID = 0; n_gvAction = 0; n_Operation_Date = 0; n_EMPID_child = 0; n_Opt_Granted_Id_child = 0; n_IS_JOINT_MODIFICATION = 0; n_EMPMODITYPE = 0;
        }
        #endregion

        /// <summary>
        /// This is the click event of btnMD_DummyAdd button.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event e</param>
        protected void btnMD_DummyAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    if (hdnControlID.Value == "Dummybtn")
                    {
                        modificationsModel.Populate_OptionDetails(this);
                        modificationsModel.Populate_Modification_Details(this);
                    }
                    else if (hdnControlID.Value.Contains("Options"))
                    {
                        modificationsModel.Calculate_Options(this);
                        clearColumnIndexes();
                        modificationsModel.Populate_Modification_Details(this);
                        clearColumnIndexes();
                        modificationsModel.Get_Modification_Details(this);
                    }

                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is the textchanged event of textboxes used to enter option values.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void CalculateOptions_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.Calculate_Options(this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is the click event of btnMD_SubmitOptions button.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void btnMD_SubmitOptions_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.GetData_ForOptions(this);
                    modificationsModel.PerformCUD(this);
                    Populate_Modification_Details();
                }
            }

            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is the click event of btnMD_CompensationCost button.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void btnMD_CompensationCost_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.Populate_CompensationCost_Details(this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is the click event of btnMD_SubmitCompensation button.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event e</param>
        protected void btnMD_SubmitCompensation_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.Get_CompensationCost_Inputs(this, Request.Form);
                    modificationsModel.PerformCUD(this);
                    modificationsModel.Get_Modification_Details(this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region GridView Events
        /// <summary>
        /// This Method is resposible for handling the page index change of gridview.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Gridview Page Event</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            using (ModificationsModel modificationsModel = new ModificationsModel())
            {
                try
                {
                    modificationsModel.PageIndexChanging(sender, e, gv, hdn_ModId.Value);
                }
                catch (Exception Ex)
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is resposible for handling the page index change of gridview.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Gridview Page Event</param>
        protected void gv_AddEditModifications_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            using (ModificationsModel modificationsModel = new ModificationsModel())
            {
                try
                {
                    modificationsModel.gv_AddEditModifications_PageIndexChanging(e, this);
                }
                catch (Exception Ex)
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used for gridview row data bound.
        /// </summary>
        /// <param name="sender">Sender's Id</param>
        /// <param name="e">Gridview Row Id</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.gv_BindRows(e, ref n_index, ref n_ID, ref n_Action, ref n_AMMID, ref n_Delete, ref n_IS_JOINT_MODIFICATION, ref n_EMPMODITYPE);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used for gridview row data bound.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void gv_AddEditModifications_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {

                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.gv_AddEditModifications_BindRows(e, ref n_Opt_Granted_Id, ref n_index, ref n_ID, ref n_gvAction, ref n_EMPID, ref n_EmployeeId, ref n_EmployeeName, ref n_SchemeName, ref n_GrantRegId, ref n_GrantOptId, ref n_GrantDate, ref n_Operation_ID, ref n_Operation_Date, ref n_IsLock, this, ref n_IS_JOINT_MODIFICATION, ref n_AMMID);

                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        AGRMID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "AGRMID").ToString();
                        if (rbtnMD_ModificationLevel.SelectedValue.Equals("1"))
                        {
                            s_Empid = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "EMPID").ToString();
                            Opt_Grnt_id = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "OPT GRANTED ID").ToString();
                        }

                        modificationsModel.AddChildGrid(sender, e, false, AGRMID, Opt_Grnt_id, s_Empid, ref n_VestIndex, ref n_VestID, ref n_VestDelete, ref n_VestAction, ref n_VestGrantDate, ref rowIndex, this, Path.GetFileNameWithoutExtension(Request.Path));
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used for Compensation Cost grid view row data bound.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void gv_CompensationCost_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.gv_CompesationCost_BindRows(e, ref n_Opt_Granted_Id, ref n_index, ref n_ID, ref n_EmployeeId, ref n_EmployeeName, ref n_Outstanding, ref n_System_IV_Cost, ref n_System_FV_Cost, ref Iv_Incremental, ref Fv_Incremental, ref n_IntrinsicValue, ref n_FairValue, ref n_Granted, ref n_IvPostModCost, ref n_FvPostModCost, this);

                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        AGRMID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "AGRMID").ToString();
                        s_Empid = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "EMPID").ToString();

                        modificationsModel.AddChildGrid_COC(sender, e, false, AGRMID, s_Empid, ref n_VestIndex, ref n_VestID, ref n_VestDelete, ref n_VestAction, ref n_VestGrantDate, ref rowIndex, this, Path.GetFileNameWithoutExtension(Request.Path));
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row data bound for child grid
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        public void CompesationCost_childGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                n_Action = 0;

                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.gv_CompesationCost_ChildBindRows(e, ref n_colIndex[0], ref n_colIndex[1], ref n_colIndex[2], ref n_colIndex[3], ref n_colIndex[4], ref n_colIndex[5], ref n_colIndex[6], ref n_colIndex[7], ref n_colIndex[8], ref n_colIndex[9], ref n_colIndex[10], ref n_colIndex[11], ref n_colIndex[12], ref n_colIndex[13], ref n_colIndex[14], ref n_colIndex[15], ref n_colIndex[16], ref n_colIndex[17], this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row data bound for child grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void childGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                n_Action = 0;

                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.BindChildGridViewRows(this, e, ref n_VestIndex, ref n_VestID, ref n_VestDelete, ref n_VestAction, ref n_VestGrantDate, ref n_VestPercent, ref n_FairValVest, ref n_IntrsicValVest, ref n_VestOptID, ref n_Opt_Vest_Id, ref n_Opt_Granted_Id_child, ref n_AGRMID, ref  n_AGDID, ref n_EMPID_child);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row data bound for child grid
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        public void childGridLockedRec_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                n_Action = n_index = 0;

                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.BindChildGridViewRows(this, e, ref n_VestIndexLockedRec, ref n_VestIDLockedRec, ref n_VestDeleteLockedRec, ref n_VestActionLockedRec, ref n_VestGrantDateLockedRec, ref n_VestPercent, ref n_FairValVest, ref n_IntrsicValVest, ref n_VestOptID, ref n_Opt_Vest_Id, ref n_Opt_Granted_Id, ref n_AGRMID, ref n_AGDID, ref n_EMPID);
                }

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    AGRMID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString();
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Methods
        /// <summary>
        /// This method is used to load the data of Main gv as well as the gv_AddModifications.
        /// </summary>
        public void Populate_Modification_Details()
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    clearColumnIndexes();
                    modificationsModel.Populate_Modification_Details(this);
                    clearColumnIndexes();
                    modificationsModel.Get_Modification_Details(this);
                }

            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to load option details of a particular employeee vestwise.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void ddl_AddOptions_EmpVestDate_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.GetOptionsForParticularVest(this, ddl_AddOptions_EmpVestDate.SelectedValue);
                    Populate_Modification_Details();
                }
            }

            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to load the Modification type details according to the Modification level selected.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void rbtnMD_ModificationLevel_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    modificationsModel.ModificationType_checkbox(this);
                    modificationsModel.Get_Modification_Details(this);
                    if ((hdnOperationType.Value == "UPDATE_MODIFICATION" || hdnOperationType.Value == "VIEW_MODIFICATION") && rbtnMD_ModificationLevel.SelectedValue == "1")
                    {
                        if (hdnIsCancelled.Value != "C")
                        {
                            clearColumnIndexes();
                            modificationsModel.Populate_EmployeeLevelData_AfterGrantLevelSaved(this);
                        }
                    }
                    else if ((hdnOperationType.Value == "UPDATE_MODIFICATION" || hdnOperationType.Value == "VIEW_MODIFICATION"))
                    {
                        if (hdnIsCancelled.Value != "C")
                        {
                            btnMD_Populate_Click(sender, e);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ModificationsModel modificationsModel = new ModificationsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationsModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}