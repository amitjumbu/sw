﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// The class file for approve accounting parameters page
    /// </summary>
    public partial class ApproveAccountingParameters : BasePage
    {
        #region Variables

        /// <summary>
        /// Variables declaration
        /// </summary>
        int n_Index = 0, n_Parameters = 0, n_PreviousSettings = 0, n_CurrentSettings = 0, n_CONFIGID = 0;

        #endregion

        #region Page Load Event
        /// <summary>
        /// call the method while page will load.
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (ApproveAccountingParamsModel approveAccountingParamsModel = new ApproveAccountingParamsModel())
                    {
                        approveAccountingParamsModel.BindUI(this);
                        approveAccountingParamsModel.BindApprovalGrid(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ApproveAccountingParamsModel approveAccountingParamsModel = new ApproveAccountingParamsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", approveAccountingParamsModel.userSessionInfo.ACC_CompanyName).Replace("*", approveAccountingParamsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Reviewer Section
        /// <summary>
        /// used to handle grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvAPAApprovalGrid_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            try
            {
                using (ApproveAccountingParamsModel approveAccountingParamsModel = new ApproveAccountingParamsModel())
                {
                    approveAccountingParamsModel.gvAPAApprovalGrid_RowDataBound(e, this, ref n_Index, ref n_Parameters, ref n_PreviousSettings, ref n_CurrentSettings, ref n_CONFIGID);
                }
            }
            catch (Exception Ex)
            {
                using (ApproveAccountingParamsModel approveAccountingParamsModel = new ApproveAccountingParamsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", approveAccountingParamsModel.userSessionInfo.ACC_CompanyName).Replace("*", approveAccountingParamsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// used to handle click event of button 
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnAPSApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (ApproveAccountingParamsModel approveAccountingParamsModel = new ApproveAccountingParamsModel())
                {
                    approveAccountingParamsModel.btnAPSApprove_Click(this, true);
                }
            }
            catch (Exception Ex)
            {
                using (ApproveAccountingParamsModel approveAccountingParamsModel = new ApproveAccountingParamsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", approveAccountingParamsModel.userSessionInfo.ACC_CompanyName).Replace("*", approveAccountingParamsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// used to handel click event of button 
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnAPSDisApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (ApproveAccountingParamsModel approveAccountingParamsModel = new ApproveAccountingParamsModel())
                {
                    approveAccountingParamsModel.btnAPSDisApprove_Click(this, false);
                }
            }
            catch (Exception Ex)
            {
                using (ApproveAccountingParamsModel approveAccountingParamsModel = new ApproveAccountingParamsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", approveAccountingParamsModel.userSessionInfo.ACC_CompanyName).Replace("*", approveAccountingParamsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}