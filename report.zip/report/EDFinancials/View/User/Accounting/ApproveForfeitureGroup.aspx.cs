﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// 
    /// </summary>
    public partial class ApproveForfeitureGroup : BasePage
    {
        /// <summary>
        /// 
        /// </summary>
        public string s_PgName = CommonConstantModel.s_ApproveForfeitureGroup;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/View/User/Accounting/ForfeitureSetup.aspx?PgName=" + s_PgName + "");
            }
            catch (SystemException)
            {
                // Do Nothing
            }
            catch (Exception Ex)
            {
                using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}