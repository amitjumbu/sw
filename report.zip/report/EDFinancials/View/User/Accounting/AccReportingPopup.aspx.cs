﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Accounting Reporting Popup class
    /// </summary>
    public partial class AccReportingPopup : BasePage
    {
        /// <summary>
        /// Variable Declaration
        /// </summary>
        int n_Index = 0, n_ACC_RPT_GROUP_ID = 0, n_Report_Vesion = 0, n_Comments = 0, n_TypeoOfUser = 0, n_CreatedOn = 0, n_ReportNameToDownload = 0, n_Action = 0,
             n_UP_Index = 0, n_UP_ARUDID = 0, n_UP_DocumentName = 0, n_UP_UploadedBy = 0, n_UP_Download = 0, n_UP_Delete = 0;

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                    {
                        accReportingPopupModel.Page_Load(this, Request.QueryString["ControlText"], Request.QueryString["ACC_RPT_GROUP_ID"], Request.QueryString["VersionNumber"]);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARPReportVersions_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    accReportingPopupModel.gvARPReportVersions_PageIndexChanging(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view row dada bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARPReportVersions_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    accReportingPopupModel.gvARPReportVersions_RowDataBound(this, e, ref n_Index, ref n_ACC_RPT_GROUP_ID, ref n_Report_Vesion, ref n_Comments, ref n_TypeoOfUser, ref n_CreatedOn, ref n_ReportNameToDownload, ref n_Action);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Invoice save click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARPInvoiceSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    accReportingPopupModel.btnARPInvoiceSave_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// File upload save button clcik event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARPFileUploadSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    accReportingPopupModel.btnARPFileUploadSave_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// File download button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARPFileDownload_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    accReportingPopupModel.btnARPFileDownload_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Clear button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARPClearFileContent_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    accReportingPopupModel.btnARPClearFileContent_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARPUploadedFiles_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    accReportingPopupModel.gvARPUploadedFiles_PageIndexChanging(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARPUploadedFiles_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    accReportingPopupModel.gvARPUploadedFiles_RowDataBound(this, e, ref n_UP_Index, ref n_UP_ARUDID, ref n_UP_DocumentName, ref n_UP_UploadedBy, ref n_UP_Download, ref n_UP_Delete);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// File delete click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARPFileDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    accReportingPopupModel.btnARPFileDelete_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Download report click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void imgARPDownloadReport_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    accReportingPopupModel.imgARPDownloadReport_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// this method is used to return query string
        /// </summary>
        /// <param name="s_ACC_RPT_GROUP_ID">s_ACC_RPT_GROUP_ID</param>
        /// <param name="s_VERSION_NUMBER">s_VERSION_NUMBER</param>
        /// <param name="s_ControlID">s_ControlID</param>
        /// <returns>returns query string to get SSRS report</returns>
        [WebMethod]
        public static string GetSSRSReportQueryString(object s_ACC_RPT_GROUP_ID, object s_VERSION_NUMBER, object s_ControlID)
        {
            try
            {
                using (AccReportingPopupModel accReportingPopupModel = new AccReportingPopupModel())
                {
                    return accReportingPopupModel.GetSSRSReportQueryString(s_ACC_RPT_GROUP_ID, s_VERSION_NUMBER, s_ControlID);
                }
            }
            catch
            {
                throw;
            }
        }
    }
}