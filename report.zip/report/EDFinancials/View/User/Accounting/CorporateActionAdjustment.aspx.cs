﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Code behind file CorporateActionAdjustment Page
    /// </summary>
    public partial class CorporateActionAdjustment : BasePage
    {
        #region Variables Declartion
        int n_index = 0;

        Hashtable hash_Table = new Hashtable();
        #endregion

        /// <summary>
        /// Page load method for CorporateActionAdjustment
        /// </summary>
        /// <param name="sender">CorporateActionAdjustment Page</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                    {
                        corporateActionAdjustmentModel.BindUI(this);

                        corporateActionAdjustmentModel.CheckEmployeeRolePriviledges(this);

                        corporateActionAdjustmentModel.BindGrid(this);

                        corporateActionAdjustmentModel.ClearAllTables(this);
                    }
                }
                ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch (Exception Ex)
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionAdjustmentModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionAdjustmentModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound Event of gvCAAjd GridView
        /// </summary>
        /// <param name="sender">gvCAAjd GridView</param>
        /// <param name="e">e</param>
        protected void gvCAAjd_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    corporateActionAdjustmentModel.gvCAAjd_RowDataBound(this, sender, e, ref n_index, ref hash_Table);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionAdjustmentModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionAdjustmentModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is the click Event of Search Button
        /// </summary>
        /// <param name="sender">Search Button</param>
        /// <param name="e">e</param>
        protected void btnCAASearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    corporateActionAdjustmentModel.btnCAASearch_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionAdjustmentModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionAdjustmentModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is the click Event of Reset Button
        /// </summary>
        /// <param name="sender">Reset Button</param>
        /// <param name="e">e</param>
        protected void btnCAAReset_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    corporateActionAdjustmentModel.BindGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionAdjustmentModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionAdjustmentModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Update Corporate Action Button Click Event. It will Bind gvCAAUpdateCorpAction GridView.
        /// </summary>
        /// <param name="sender">Update Corporate Action Button</param>
        /// <param name="e">e</param>
        protected void btnCAAUpdateCorpAct_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    corporateActionAdjustmentModel.btnCAAUpdateCorpAct_Click(this);

                    corporateActionAdjustmentModel.BindGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionAdjustmentModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionAdjustmentModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Revert Corporate Action Button Click Event. It will revert the Applied Corporate Action.
        /// </summary>
        /// <param name="sender">The Revert Corporate Action Button</param>
        /// <param name="e">e</param>
        protected void btnCAARevertCorpAct_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    corporateActionAdjustmentModel.btnCAARevertCorpAct_Click(this);

                    corporateActionAdjustmentModel.BindGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionAdjustmentModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionAdjustmentModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The btnCAAUpdateCorpActEffect Button Click Event. This method is used to Adjust/Update Corporate Action Data.
        /// </summary>
        /// <param name="sender">btnCAAUpdateCorpActEffect Button</param>
        /// <param name="e">e</param>
        protected void btnCAAUpdateCorpActEffect_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    corporateActionAdjustmentModel.btnCAAUpdateCorpActEffect_Click(this);

                    corporateActionAdjustmentModel.btnCAAUpdateCorpAct_Click(this);

                    corporateActionAdjustmentModel.BindGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionAdjustmentModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionAdjustmentModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Page Index Change Event of gvCAAjd GridView
        /// </summary>
        /// <param name="sender">gvCAAjd GridView</param>
        /// <param name="e">e</param>
        protected void gvCAAjd_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    corporateActionAdjustmentModel.gvCAAjd_PageIndexChanging(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionAdjustmentModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionAdjustmentModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to Bind gvCAAjd GridView
        /// </summary>
        public void BindgvCAAjdGridView()
        {
            try
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    corporateActionAdjustmentModel.BindgvCAAjdGridView(this);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionAdjustmentModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionAdjustmentModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to display the Message
        /// </summary>
        /// <param name="s_SenderID">Control ID</param>
        /// <param name="n_Result">int Result</param>
        public void DisplayMessage(string s_SenderID, int n_Result)
        {
            try
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    corporateActionAdjustmentModel.DisplayMessage(this, s_SenderID, n_Result);

                    if (!s_SenderID.Equals("btnCAAApply"))
                        corporateActionAdjustmentModel.btnCAAUpdateCorpAct_Click(this);

                    if (n_Result == 2 && s_SenderID.Equals("btnCAACalcSave"))
                        corporateActionAdjustmentModel.btnCAAUpdateCorpActEffect_Click(this);

                    corporateActionAdjustmentModel.BindGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionAdjustmentModel corporateActionAdjustmentModel = new CorporateActionAdjustmentModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionAdjustmentModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionAdjustmentModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}