﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Class AccReportingReconPopUp 
    /// </summary>
    public partial class AccReportingReconPopUp : System.Web.UI.Page
    {
        #region Variables Declaration
        int n_index = 0, n_RowIndex = 1, n_childIndex_a = 0, n_childIndex_b = 0, n_childIndex_c = 0, n_childIndex_f = 0;
        Hashtable ht_ReconGridView = new Hashtable();
        Hashtable ht_ReconChildGridView_a = new Hashtable();
        Hashtable ht_ReconChildGridView_b = new Hashtable();
        Hashtable ht_ReconChildGridView_c = new Hashtable();
        Hashtable ht_ReconChildGridView_f = new Hashtable();
        #endregion

        /// <summary>
        /// The Page Load Event
        /// </summary>
        /// <param name="sender">AccReportingReconPopUp Page</param>
        /// <param name="e">e</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    accReportingReconPopUpModel.BindgvAccReportingReconGrid(this, Convert.ToString(Request.QueryString["RptDate"]), Convert.ToString(Request.QueryString["DispCostBefore"]), Convert.ToString(Request.QueryString["DispCostAfter"]));
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingReconPopUpModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingReconPopUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The RowDataBound Event of gvAccReportingRecon GridView
        /// </summary>
        /// <param name="sender">gvAccReportingRecon GridView</param>
        /// <param name="e">e</param>
        protected void gvAccReportingRecon_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                string s_ShemeName = string.Empty;

                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    accReportingReconPopUpModel.gvAccReportingRecon_RowDataBound(this, e, Convert.ToString(Request.QueryString["RptDate"]), ref n_index, ref ht_ReconGridView);

                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        s_ShemeName = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Scheme Name").ToString();

                        if (s_ShemeName != "Total")
                        {
                            n_childIndex_a = n_childIndex_b = n_childIndex_c = n_childIndex_f = 0;

                            accReportingReconPopUpModel.AddChildGriView(sender, e, this, ref n_RowIndex, s_ShemeName, ref ht_ReconGridView);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingReconPopUpModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingReconPopUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound Event of grdView_Child_a GridView
        /// </summary>
        /// <param name="sender">grdView_Child_a GridView</param>
        /// <param name="e">e</param>
        internal void grdView_Child_a_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    accReportingReconPopUpModel.grdView_Child_RowDataBound(this, "grdView_Child_a", e, ref n_childIndex_a, ref n_childIndex_b, ref n_childIndex_c, ref n_childIndex_f, Convert.ToString(Request.QueryString["RptDate"]), ref ht_ReconChildGridView_a, ref ht_ReconChildGridView_b, ref ht_ReconChildGridView_c, ref ht_ReconChildGridView_f);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingReconPopUpModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingReconPopUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound Event of grdView_Child_b GridView
        /// </summary>
        /// <param name="sender">grdView_Child_b GridView</param>
        /// <param name="e">e</param>
        internal void grdView_Child_b_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    accReportingReconPopUpModel.grdView_Child_RowDataBound(this, "grdView_Child_b", e, ref n_childIndex_a, ref n_childIndex_b, ref n_childIndex_c, ref n_childIndex_f, Convert.ToString(Request.QueryString["RptDate"]), ref ht_ReconChildGridView_a, ref ht_ReconChildGridView_b, ref ht_ReconChildGridView_c, ref ht_ReconChildGridView_f);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingReconPopUpModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingReconPopUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound Event of grdView_Child_c GridView
        /// </summary>
        /// <param name="sender">grdView_Child_c GridView</param>
        /// <param name="e">e</param>
        internal void grdView_Child_c_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    accReportingReconPopUpModel.grdView_Child_RowDataBound(this, "grdView_Child_c", e, ref n_childIndex_a, ref n_childIndex_b, ref n_childIndex_c, ref n_childIndex_f, Convert.ToString(Request.QueryString["RptDate"]), ref ht_ReconChildGridView_a, ref ht_ReconChildGridView_b, ref ht_ReconChildGridView_c, ref ht_ReconChildGridView_f);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingReconPopUpModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingReconPopUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound Event of grdView_Child_f GridView
        /// </summary>
        /// <param name="sender">grdView_Child_f GridView</param>
        /// <param name="e">e</param>
        internal void grdView_Child_f_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    accReportingReconPopUpModel.grdView_Child_RowDataBound(this, "grdView_Child_f", e, ref n_childIndex_a, ref n_childIndex_b, ref n_childIndex_c, ref n_childIndex_f, Convert.ToString(Request.QueryString["RptDate"]), ref ht_ReconChildGridView_a, ref ht_ReconChildGridView_b, ref ht_ReconChildGridView_c, ref ht_ReconChildGridView_f);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingReconPopUpModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingReconPopUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The PreRender Event Of gvAccReportingRecon GridView
        /// </summary>
        /// <param name="sender">gvAccReportingRecon GridView</param>
        /// <param name="e">e</param>
        protected void gvAccReportingRecon_PreRender(object sender, EventArgs e)
        {
            try
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    accReportingReconPopUpModel.gvAccReportingRecon_PreRender(sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingReconPopUpModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingReconPopUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadRecon_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    accReportingReconPopUpModel.ExportToExcel(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccReportingReconPopUpModel accReportingReconPopUpModel = new AccReportingReconPopUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accReportingReconPopUpModel.userSessionInfo.ACC_CompanyName).Replace("*", accReportingReconPopUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}