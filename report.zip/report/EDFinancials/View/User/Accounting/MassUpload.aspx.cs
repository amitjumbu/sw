﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.UI;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// MassUpload Page file object
    /// </summary>
    public partial class MassUpload : BasePage
    {
        /// <summary>
        /// Used to handle Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">EventArgs's object</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (MassUploadModel massUploadModel = new MassUploadModel())
                {
                    if (!Page.IsPostBack)
                    {
                        massUploadModel.BindUI(this);
                        massUploadModel.EncryptReportID(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (MassUploadModel massUploadModel = new MassUploadModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", massUploadModel.userSessionInfo.ACC_CompanyName).Replace("*", massUploadModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}