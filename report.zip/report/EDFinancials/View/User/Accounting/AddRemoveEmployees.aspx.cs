﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User
{
    /// <summary>
    /// Add Remove Employees code behind call
    /// </summary>
    public partial class AddRemoveEmployees : BasePage
    {
        #region Variable declaration

        /// <summary>
        /// Variable declaration
        /// </summary>
        int n_EmpIndex = 0, n_EmpSelect = 0, n_EMPID = 0, n_Employee_ID = 0, n_Employee_Name = 0
           , n_Emp_Group_Name = 0, n_Emp_Deartment = 0, n_Emp_Grade = 0, n_Emp_Designation = 0, n_Emp_IS_APPROVAL_PENDING = 0
            , n_Ass_EmpIndex = 0, n_Ass_EmpSelect = 0, n_Ass_EMPID = 0, n_Ass_Employee_ID = 0, n_Ass_Employee_Name = 0
           , n_Ass_Emp_Group_Name = 0, n_Ass_Emp_Deartment = 0, n_Ass_Emp_Grade = 0, n_Ass_Emp_Designation = 0, n_Ass_IS_APPROVAL_PENDING = 0;

        #endregion

        #region Page Load Event

        /// <summary>
        /// Page Load Event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                    {
                        addRemoveEmployeesModel.Page_Load(this, Convert.ToString(Request.QueryString["FGID"]));
                    }
                }
            }
            catch (Exception Ex)
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", addRemoveEmployeesModel.userSessionInfo.ACC_CompanyName).Replace("*", addRemoveEmployeesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events

        /// <summary>
        /// AllEmployees grid-view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvAREAllEmployees_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    addRemoveEmployeesModel.gvAREAllEmployees_RowDataBound(e, ref n_EmpIndex, ref n_EmpSelect, ref n_EMPID, ref n_Employee_ID, ref n_Employee_Name, ref n_Emp_Group_Name, ref n_Emp_Deartment, ref n_Emp_Grade, ref n_Emp_Designation, ref n_Emp_IS_APPROVAL_PENDING);
                }
            }
            catch (Exception Ex)
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", addRemoveEmployeesModel.userSessionInfo.ACC_CompanyName).Replace("*", addRemoveEmployeesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// SelectedEmployees row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARESelectedEmployees_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    addRemoveEmployeesModel.gvARESelectedEmployees_RowDataBound(e, ref n_Ass_EmpIndex, ref n_Ass_EmpSelect, ref n_Ass_EMPID, ref n_Ass_Employee_ID, ref n_Ass_Employee_Name, ref n_Ass_Emp_Group_Name, ref n_Ass_Emp_Deartment, ref n_Ass_Emp_Grade, ref n_Ass_Emp_Designation, ref n_Ass_IS_APPROVAL_PENDING);
                }
            }
            catch (Exception Ex)
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", addRemoveEmployeesModel.userSessionInfo.ACC_CompanyName).Replace("*", addRemoveEmployeesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Add employee(s) row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void imgAREAddEmp_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    addRemoveEmployeesModel.imgAREAddEmp_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", addRemoveEmployeesModel.userSessionInfo.ACC_CompanyName).Replace("*", addRemoveEmployeesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Remove Employee(s) button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void imgARERemoveEmp_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    addRemoveEmployeesModel.imgARERemoveEmp_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", addRemoveEmployeesModel.userSessionInfo.ACC_CompanyName).Replace("*", addRemoveEmployeesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Filter Employee(s) button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnAREFilterEmp_Click(object sender, EventArgs e)
        {
            try
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    addRemoveEmployeesModel.btnAREFilterEmp_Click(this, true);
                }
            }
            catch (Exception Ex)
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", addRemoveEmployeesModel.userSessionInfo.ACC_CompanyName).Replace("*", addRemoveEmployeesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Clear Filter button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnAREClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    addRemoveEmployeesModel.btnAREClearFilter_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", addRemoveEmployeesModel.userSessionInfo.ACC_CompanyName).Replace("*", addRemoveEmployeesModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        /// <summary>
        /// Allow to move to next page
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void lnkPage_Click(object sender, EventArgs e)
        {
            using (AddRemoveEmployeesModel addRemoveEmployeesModel = new AddRemoveEmployeesModel())
            {
                string pageIndex = (sender as LinkButton).CommandArgument;

                addRemoveEmployeesModel.Page_IndexChangeing(this, pageIndex);
            }
        }
    }
}