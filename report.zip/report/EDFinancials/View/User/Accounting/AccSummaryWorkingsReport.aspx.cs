﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.IO;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// 
    /// </summary>
    public partial class AccSummaryWorkingsReport : System.Web.UI.Page
    {
        #region Static Variables
        /// <summary>
        /// public String variables
        /// </summary>
        public string s_LEVEL_1 = string.Empty, s_LEVEL_2 = string.Empty, s_LEVEL_3 = string.Empty, s_LEVEL_4 = string.Empty, s_LEVEL_5 = string.Empty; string s_SchemeName = ""; string s_Level1 = string.Empty;

        /// <summary>
        /// Variable Declaration
        /// </summary>
        public int n_SR_Index = 0, n_CSR_Index = 0, n_rowIndex = 2;

        /// <summary>
        /// Variable Declaration
        /// </summary>
        public Hashtable ht_SchemeWIse = new Hashtable();
        #endregion

        /// <summary>
        /// Page load method
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
                {
                    accSummaryWorkingsReportModel.CreateHashTable(ht_SchemeWIse);
                    accSummaryWorkingsReportModel.BindUI(this);
                    accSummaryWorkingsReportModel.BindControls(this, Convert.ToString(Request.QueryString["RptDate"]));
                }
            }
        }

    /// <summary>
        /// method call on ddlMultiSelectLevel1 SelectedIndexChanged  Event
        /// </summary>
        /// <param name="sender">Sender's Object</param>
        /// <param name="e">event args's object</param>
        protected void ddlMultiSelectLevel1_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
            {
                s_LEVEL_1 = ddlMultiSelectLevel1.SelectedItem.Text;
                accSummaryWorkingsReportModel.GetData(this, ddlMultiSelectLevel1.ID, s_LEVEL_1, "", "", "");
            }
        }

        /// <summary>
        /// method call on ddlMultiSelectLevel2 SelectedIndexChanged  Event
        /// </summary>
        /// <param name="sender">Sender's Object</param>
        /// <param name="e">event args's object</param>
        protected void ddlMultiSelectLevel2_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
            {
                s_LEVEL_2 = ddlMultiSelectLevel2.SelectedItem.Text;
                accSummaryWorkingsReportModel.GetData(this, ddlMultiSelectLevel2.ID, "", s_LEVEL_2, "", "");
            }
        }

        /// <summary>
        /// method call on ddlMultiSelectLevel3 SelectedIndexChanged  Event
        /// </summary>
        /// <param name="sender">Sender's Object</param>
        /// <param name="e">event args's object</param>
        protected void ddlMultiSelectLevel3_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
            {
                s_LEVEL_3 = ddlMultiSelectLevel3.SelectedItem.Text;
                accSummaryWorkingsReportModel.GetData(this, ddlMultiSelectLevel3.ID, "", "", s_LEVEL_3, "");
            }
        }


        /// <summary>
        /// method call on ddlMultiSelectLevel4 SelectedIndexChanged  Event
        /// </summary>
        /// <param name="sender">Sender's Object</param>
        /// <param name="e">event args's object</param>
        protected void ddlMultiSelectLevel4_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
            {
                s_LEVEL_4 = ddlMultiSelectLevel4.SelectedItem.Text;
                accSummaryWorkingsReportModel.GetData(this, ddlMultiSelectLevel4.ID, "", "", "", s_LEVEL_4);
            }
        }

        /// <summary>
        /// method call on ddlMultiSelectLevel5 SelectedIndexChanged  Event
        /// </summary>
        /// <param name="sender">Sender's Object</param>
        /// <param name="e">event args's object</param>
        protected void ddlMultiSelectLevel5_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
            {
                s_LEVEL_5 = ddlMultiSelectLevel5.SelectedItem.Text;
                accSummaryWorkingsReportModel.GetData(this, ddlMultiSelectLevel5.ID, "", "", "", "");
            }
        }

        /// <summary>
        ///  method call on click of Search Button
        /// </summary>
        /// <param name="sender">Sender's Object</param>
        /// <param name="e">event args's object</param>
        protected void btnSearch_Click(object sender, System.EventArgs e)
        {
            try
            {
                using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
                {
                    accSummaryWorkingsReportModel.FilterGridData(this);
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString(Ex.Message + "\n" + Ex.StackTrace));
            }
        }

        /// <summary>
        /// call on page index change event of gridview
        /// </summary>
        /// <param name="sender">Sender's Object</param>
        /// <param name="e">event args's object</param>
        protected void gvARMainReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
                {
                    accSummaryWorkingsReportModel.gvARMainReport_PageIndexChanging(this, e);
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString(Ex.Message + "\n" + Ex.StackTrace));
            }
        }

        /// <summary>
        /// call on Row Data Bound event of gridview
        /// </summary>
        /// <param name="sender">Sender's Object</param>
        /// <param name="e">event args's object</param>
        protected void gvARMainReport_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
                {
                    int n_MergeRowCount = 1;
                    accSummaryWorkingsReportModel.CustomizeGridHeader((GridView)sender, e.Row, 2, this, "gvARMainReport", e, ref n_SR_Index, ref ht_SchemeWIse, ref n_MergeRowCount);
                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        //if (!s_SchemeName.Equals(System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Scheme Name").ToString()))
                        //{
                            string s_PreviousRow = e.Row.RowIndex.Equals(0) ? string.Empty : gvARMainReport.Rows[e.Row.RowIndex - 1].Cells[0].Text;

                            s_SchemeName = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Scheme Name").ToString();
                            accSummaryWorkingsReportModel.AddChildGrid((GridView)sender, e, ref n_SR_Index, this, Path.GetFileNameWithoutExtension(Request.Path), s_SchemeName, ref n_rowIndex, ref n_MergeRowCount);
                        //}
                    }
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString(Ex.Message + "\n" + Ex.StackTrace));
            }
        }



        /// <summary>
        /// call on Row Data Bound event of Child gridview
        /// </summary>
        /// <param name="sender">Sender's Object</param>
        /// <param name="e">event args's object</param>
        internal void childGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
                {
                    accSummaryWorkingsReportModel.childGrid_RowDataBound(sender, this, e, ref n_CSR_Index, ref ht_SchemeWIse);
                    int n_MergeRowCount = 1;
                    if (e.Row.RowType == DataControlRowType.Header)
                    {
                        accSummaryWorkingsReportModel.CustomizeGridHeader((GridView)sender, e.Row, 2, this, "gvARSummaryReport", e, ref n_CSR_Index, ref ht_SchemeWIse, ref n_MergeRowCount);
                    }

                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        accSummaryWorkingsReportModel.CustomizeGridHeader((GridView)sender, e.Row, 2, this, "gvARSummaryReport", e, ref n_CSR_Index, ref ht_SchemeWIse, ref n_MergeRowCount);
                    }
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString(Ex.Message + "\n" + Ex.StackTrace));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
            {
               // accSummaryWorkingsReportModel.ExportGridToExcel(this);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnReset_Click(object sender, EventArgs e)
        {
            using (AccSummaryWorkingsReportModel accSummaryWorkingsReportModel = new AccSummaryWorkingsReportModel())
            {
               // accSummaryWorkingsReportModel.BindUI(this);
                accSummaryWorkingsReportModel.ClearControls(this);
            }
        }

    }

}

