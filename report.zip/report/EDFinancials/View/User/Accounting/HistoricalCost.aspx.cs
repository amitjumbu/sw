﻿using System;
using System.Collections.Generic;
using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Web.UI;
using System.Data;
using System.Collections;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Historical Cost page code behind class 
    /// </summary>
    public partial class HistoricalCost : BasePage
    {
        #region Static Variables
        /// <summary>
        /// Public int Variables
        /// </summary>
        public int n_index = 0, n_ID = 0, n_PValue = 0, n_VestDate = 0, n_CostBySystem = 0, n_HCostManulally = 0,n_OPGID = 0,
            n_AdjustmtEntry = 0, n_FinalCost = 0, n_Name = 0, n_CancelOptions = 0, n_PID = 0, n_EMPID = 0, n_HC_PID = 0, n_Date= 0;

        /// <summary>
        /// public decimal variables
        /// </summary>
        public decimal d_total = 0, d_UCTotal = 0, d_AdjustMent = 0, d_FCost = 0;
        #endregion

        /// <summary>
        /// Variable Declaration
        /// </summary>
        public Hashtable HC_HashTable = new Hashtable();

        /// <summary>
        /// Set value to bool variable to identify cotrol is called or not
        /// </summary>
        private bool IsTextboxControlCalled = false;

        #region Page Load Event
        /// <summary>
        /// call the method while page will load.
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {

                IsTextboxControlCalled = (Page.Request.Params["__EVENTTARGET"] == "ctl00$MainContent$txtCostAsOn");

                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    if (!IsPostBack)
                    {
                        historicalCostModel.CreateHashTable(HC_HashTable);
                        historicalCostModel.CheckEmployeeRolePriviledges(this);
                        historicalCostModel.BindUI(this);
                        historicalCostModel.CreateCustomizeView(this);
                        historicalCostModel.BindControls(this);
                        historicalCostModel.BindDropDowns(this);

                        // Encrypts query string which has to be passed on to report page.
                        historicalCostModel.EncryptData(this);
                    }
                    if (hdnShowGrid.Value.Equals("Search"))
                    {
                        historicalCostModel.FilterGridData(this, "btnSearch");

                    }
                    else
                    {
                        historicalCostModel.BindGridView(this);
                    }
                    historicalCostModel.AssignValuesFromTextbox(Request.Form, this);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events
        /// <summary>
        ///  method call on click of Search Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, System.EventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.FilterGridData(this, "btnSearch");
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvHistoricalCost_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.BindRows(e, ref n_index, ref HC_HashTable, this);
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// method call on click of search Params button
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void btnSearchParams_Click(object sender, System.EventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.FilterGridData(this, "btnSearchParams");
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  call on click of Next button in case of add HC Cost
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void btnNext_Click(object sender, System.EventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.BindAddControls(this, "", "btnNext");
                    historicalCostModel.FilterGridData(this, "btnNext");
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.BindgvRows(e, ref n_index, ref HC_HashTable, this);
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void gv_DataBound(object sender, EventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.AddNewRow(sender, this, e, "gv", gv);
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// call on click of SNext button
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void btnSNext_Click(object sender, EventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.BindAddParmsGridView(this);
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void gvAParmsHCost_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.BindgvAParmsRows(sender, this, e, ref n_index, ref n_ID, ref n_Name, ref n_CostBySystem, ref n_HCostManulally, ref n_AdjustmtEntry, ref n_FinalCost, ref d_total, ref d_UCTotal, ref n_PValue, ref n_PID, ref d_AdjustMent, ref d_FCost, ref n_EMPID,ref n_HC_PID);
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Call on click of save button
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.SaveDetails(this, (!hdnEdit.Value.Contains("U")) ? "C" : "U");
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  call on click of edit image button
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        public void imgButton_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ImageButton objImage = (ImageButton)sender;
                this.txtCostAsOn.AutoPostBack = false;
                string s_OPGID = objImage.ID.Split('_')[1];
                hdnSetDefaultControls.Value = "Y";
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.ShowEditDetails(this, "9", s_OPGID, "U");
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// call on to delete the records on click of delete button
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.SaveDetails(this, "D");
                    historicalCostModel.BindControls(this);
                    historicalCostModel.BindGridView(this);
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Method is call on text change of textbox of cost as on in case of add HC Cost.
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void txtCostAsOn_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (IsTextboxControlCalled)
                {
                    using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                    {
                        historicalCostModel.BindAddControls(this, txtCostAsOn.Text, "");
                    }
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// call on page change in gridview in case of Search 
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void gvHistoricalCost_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.PageIndexChangingvHCost(e.NewPageIndex, this, "gvHistoricalCost");
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// call on page change in gridview in case of Add 
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.PageIndexChangingvHCost(e.NewPageIndex, this, "gv");
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void gvSerachParms_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.BindgvSearchParmsRows(sender, this, e, ref n_index, ref n_ID, ref n_Name, ref n_CostBySystem, ref n_HCostManulally, ref n_AdjustmtEntry, ref n_FinalCost, ref d_total, ref d_UCTotal, ref n_PValue, ref n_PID, ref d_AdjustMent, ref d_FCost, ref n_Date, ref n_EMPID, ref n_HC_PID);
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        /// <summary>
        /// This method call on click event of checkbox
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args object</param>
        protected void chkAPams_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.VisibleTheControl(this);
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }

        }

        #region Methods
        /// <summary>
        /// Method is used to bind vest wise data to grid
        /// </summary>
        /// <param name="s_GrantID">Grant ID Object</param>
        /// <param name="s_BtnId">Button ID Object</param>
        /// <param name="IsEditVest">IsEditVest object</param>
        /// <returns>List</returns>
        [WebMethod]
        public static HCostList[] VestWiseData(string s_GrantID, string s_BtnId, string IsEditVest)
        {
            List<HCostList> Detail = new List<HCostList>();
            DataTable dt_FilteredHCList = new DataTable();

            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    dt_FilteredHCList = historicalCostModel.BindVestDetailsByID(s_GrantID, s_BtnId, IsEditVest);
                    if (dt_FilteredHCList != null && dt_FilteredHCList.Rows.Count > 0)
                    {
                        foreach (DataRow dtRow in dt_FilteredHCList.Rows)
                        {
                            HCostList DataObj = new HCostList();
                            DataObj.GID = dtRow["GID"].ToString();
                            DataObj.VestID = dtRow["VestID"].ToString();
                            DataObj.VestingDate = Convert.ToDateTime(dtRow["Vesting Date"]).ToString("dd/MMM/yyyy");
                            DataObj.CostBySystem = dtRow["CostBySystem"].ToString();
                            DataObj.UpdatedCost = dtRow["UpdatedCost"].ToString();
                            DataObj.CostByFV = dtRow["CostByFV"].ToString();
                            DataObj.CostByIV = dtRow["CostByIV"].ToString();
                            Detail.Add(DataObj);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
            return Detail.ToArray();
        }

        /// <summary>
        /// Class for binding data
        /// </summary>		
        public class HCostList
        {
            /// <summary>
            ///  string GID variable
            /// </summary>
            public string GID { get; set; }

            /// <summary>
            /// string Vest ID variable
            /// </summary>
            public string VestID { get; set; }

            /// <summary>
            /// string Vesting Date variable
            /// </summary>
            public string VestingDate { get; set; }

            /// <summary>
            /// string CostBy System variable
            /// </summary>
            public string CostBySystem { get; set; }

            /// <summary>
            /// string Updated Cost variable
            /// </summary>
            public string UpdatedCost { get; set; }

            /// <summary>
            /// string Cost By FV variable
            /// </summary>
            public string CostByFV { get; set; }

            /// <summary>
            /// string Cost By IV variable
            /// </summary>
            public string CostByIV { get; set; }
        }

        /// <summary>
        /// Method call on click of save vest details which is bind through JSON
        /// </summary>
        /// <param name="s_GID">GID object</param>
        /// <param name="s_OID">OID object</param>
        /// <param name="a_HCCost">HCOST Object</param>
        /// <param name="s_Action">Action Which wants to perform</param>
        /// <param name="a_CCost">COMPENSION COST Object</param>
        /// <param name="a_CCostFV">COMPENSION COST FV Object</param>
        /// <param name="a_TotalCost">Total COMPENSION COST Object Displayed on selection of IV/FV</param>
        /// <param name="a_VestingDate">Vesting Date object</param>
        /// <returns></returns>        
        [WebMethod]
        public static string[] VestWiseCUD(object s_GID, object s_OID, object a_HCCost, object s_Action, object a_CCost, object a_CCostFV, object a_TotalCost, object a_VestingDate)
        {
            bool IsDataFound = true;
            using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
            {
                historicalCostModel.CreateTable(Convert.ToInt16(s_GID), a_HCCost, Convert.ToString(s_OID), a_CCost, a_CCostFV, ref IsDataFound, a_TotalCost, a_VestingDate);
            }
            if (!(IsDataFound))
            { return new string[2] { "0", "Please enter the Vest Details" }; }
            else
                return new string[2] { "1", "" };
        }

        /// <summary>
        /// Method is used to bind data to history grid
        /// </summary>
        /// <param name="s_OPTGID">Primary key / ID against whom the history data will display</param>
        /// <returns></returns>
        [WebMethod]
        public static AccountingProperties[] ViewHistory(object s_OPTGID)
        {
            using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
            {
                return historicalCostModel.BindHistoryGridByID(s_OPTGID);
            }
        }
        #endregion

        /// <summary>
        /// to reset the controls
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.ClearAll(this);
                    Response.Redirect(Request.Url.ToString(), false);
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// to reset the controls
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    historicalCostModel.BindGridView(this);
                    historicalCostModel.ResetControl(this);
                    historicalCostModel.BindNullGrid(this, "gvSerachParms");
                }
            }
            catch (Exception Ex)
            {
                using (HistoricalCostModel historicalCostModel = new HistoricalCostModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", historicalCostModel.userSessionInfo.ACC_CompanyName).Replace("*", historicalCostModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}