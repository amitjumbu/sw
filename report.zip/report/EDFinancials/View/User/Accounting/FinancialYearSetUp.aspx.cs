﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Code behind file FinancialYearSetUp Page
    /// </summary>
    public partial class FinancialYearSetUp : BasePage
    {
        int n_index = 0, n_AFYMID = 0, n_FincYr = 0, n_FromDate = 0, n_ToDate = 0;

        /// <summary>
        /// Page load method for FinancialYearSetUp
        /// </summary>
        /// <param name="sender">FinancialYearSetUp aspx Page</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (FinancialYearSetUpModel financialYearSetUpModel = new FinancialYearSetUpModel())
                    {
                        financialYearSetUpModel.BindUI(this);

                        financialYearSetUpModel.CheckEmployeeRolePriviledges(this);

                        financialYearSetUpModel.BindFinYrGrid(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (FinancialYearSetUpModel financialYearSetUpModel = new FinancialYearSetUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", financialYearSetUpModel.userSessionInfo.ACC_CompanyName).Replace("*", financialYearSetUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The button click event of View Financial Year
        /// </summary>
        /// <param name="sender">View Financial Year Button</param>
        /// <param name="e">e</param>
        protected void btnFYViewFincYr_Click(object sender, EventArgs e)
        {
            try
            {
                using (FinancialYearSetUpModel financialYearSetUpModel = new FinancialYearSetUpModel())
                {
                    financialYearSetUpModel.btnFYViewFincYr_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (FinancialYearSetUpModel financialYearSetUpModel = new FinancialYearSetUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", financialYearSetUpModel.userSessionInfo.ACC_CompanyName).Replace("*", financialYearSetUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The button click event of Update Financial Year Set Up
        /// </summary>
        /// <param name="sender">Update Financial Year Button</param>
        /// <param name="e">e</param>
        protected void btnFYUpdateFY_Click(object sender, EventArgs e)
        {
            try
            {
                using (FinancialYearSetUpModel financialYearSetUpModel = new FinancialYearSetUpModel())
                {
                    financialYearSetUpModel.btnFYUpdateFY_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (FinancialYearSetUpModel financialYearSetUpModel = new FinancialYearSetUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", financialYearSetUpModel.userSessionInfo.ACC_CompanyName).Replace("*", financialYearSetUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The button click event of Save updated Financial Year
        /// </summary>
        /// <param name="sender">Save Button</param>
        /// <param name="e">e</param>
        protected void btnFYSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (FinancialYearSetUpModel financialYearSetUpModel = new FinancialYearSetUpModel())
                {
                    financialYearSetUpModel.btnFYSave_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (FinancialYearSetUpModel financialYearSetUpModel = new FinancialYearSetUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", financialYearSetUpModel.userSessionInfo.ACC_CompanyName).Replace("*", financialYearSetUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound Event of gvFincYr GridView
        /// </summary>
        /// <param name="sender">gvFincYr GridView</param>
        /// <param name="e">e</param>
        protected void gvFincYr_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (FinancialYearSetUpModel financialYearSetUpModel = new FinancialYearSetUpModel())
                {
                    financialYearSetUpModel.gvFincYr_RowDataBound(sender, e, ref n_index, ref n_AFYMID, ref n_FincYr, ref n_FromDate, ref n_ToDate, this);
                }
            }
            catch (Exception Ex)
            {
                using (FinancialYearSetUpModel financialYearSetUpModel = new FinancialYearSetUpModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", financialYearSetUpModel.userSessionInfo.ACC_CompanyName).Replace("*", financialYearSetUpModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}