﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.Services;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Page is use for create customize view
    /// </summary>
    public partial class CustomizeView : BasePage
    {
        string s_ViewName = string.Empty;

        /// <summary>
        /// Public integer variable declaration 
        /// </summary>
        public int n_index = 0, n_Delete = 0, n_ID = 0, n_Action = 0, n_gvUserIndex = 0, n_gvUserID = 0, n_No_Of_Rows = 0, n_gvUserDelete = 0,n_gvUserDefView=0,
                   n_gvAssignUserIndex = 0, n_gvAssignUserID = 0, n_gvAssignUserDelete = 0, n_gvAssignUserDefView=0;

        /// <summary>
        /// Public string variable declaration 
        /// </summary>
        public string s_SelectedColumn;

        /// <summary>
        /// Public string variable declaration 
        /// </summary>
        public string s_ColNotAvailable;

        /// <summary>
        /// HANDLE PAGE LOAD EVENT
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    if (!this.IsPostBack)
                    {
                        customizeViewModel.CheckEmployeeRolePriviledges(this);

                        customizeViewModel.BindUI(this);

                        customizeViewModel.BindControls(this);
                    }

                    customizeViewModel.BindSearchGrid(this);
                }

            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// HANDLE APPLY FILTER BUTTON EVENT
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void btnCASearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.ApplyFilter(this);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// HANDLE RESET FILTER BUTTON EVENT
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.ResetFilter(this);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// HANDEL CUSTOMZE VIEW ROW DATA BOUND EVENT
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void gvCustomizeView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.gvCustomizeView_RowDataBound(this, e, ref n_index, ref n_Delete, ref n_ID, ref n_Action, ref s_ViewName, ref n_No_Of_Rows);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// HANDLE GRID VIEW PAGE INDEX CHANGING EVENT
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void gvCustomizeView_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.gvCustomizeView_PageIndexChanging(this, sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// HANDLE DELETE 
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.DeleteCustomizeView(this);

                    customizeViewModel.BindSearchGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to load column into left gird.
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void btnLoadColumn_Click(object sender, EventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    // METHOD IS USED FOR BIND GRID HEADER
                    customizeViewModel.BindUIMessage(this);

                    customizeViewModel.BindLeftGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Method is used to bind Right hand seleted data to final grid
        /// </summary>
        /// <param name="s_Values">Parameter for selected column</param>
        /// <param name="s_PageName">Parameter for customize view for</param>
        /// <param name="o_Data">Parameter for View Id and Customize view page for</param>
        /// <returns>return stirng array as result</returns>
        [WebMethod]
        public static string BindFinalGrid(object s_Values, object s_PageName, object o_Data)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    return customizeViewModel.BindFinalGrid(s_Values, s_PageName, o_Data);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to seve final grid data to database.
        /// </summary>
        /// <param name="o_ColumnAliasNew">String array of Column new alies name</param>
        /// <param name="o_IsTotal">String array of contaits should total available for column</param>
        /// <param name="o_DecimalPoint">String array of contaits decimal point information</param>
        /// <param name="o_PageName">Parameter is used to selected page name</param>
        /// <param name="o_ViewName">Parameter is used for entered view name</param>
        /// <param name="o_NoOfRows">Parameter is used for selected no of rows</param>
        /// <param name="o_Edit">Parameter for check reuest for edit/insert</param>
        /// <returns>return stirng array as result</returns>
        [WebMethod]
        public static string[] SaveCustomizeView(object o_ColumnAliasNew, object o_IsTotal, object o_DecimalPoint, object o_PageName, object o_ViewName, object o_NoOfRows, object o_Edit)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    return customizeViewModel.SaveCustomizeView(o_ColumnAliasNew, o_IsTotal, o_DecimalPoint, o_PageName, o_ViewName, o_NoOfRows, o_Edit);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// HANDE BUTTON CANCEL EVENT
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.btnCancel_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Event is used to create customize view
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void ShowMessage(object sender, EventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.ShowMessage(this, sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        public void imgButton_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.imgButton_Click(this, sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void gvAssignedUser_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.gvAssignedUser_RowDataBound(this, e, ref n_gvAssignUserIndex, ref n_gvAssignUserID, ref n_gvAssignUserDelete, ref n_gvAssignUserDefView);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// HANDLE GRID VIEW PAGE INDEX CHANGING EVENT
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void gvAssignedUser_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.gvAssignedUser_PageIndexChanging(this, sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeleteAssignUser_Click(object sender, EventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.btnDeleteAssignUser_Click(this, sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void gvUsers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.gvUsers_RowDataBound(this, e, ref n_gvUserIndex, ref n_gvUserID, ref n_gvUserDelete, ref n_gvUserDefView);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// HANDLE GRID VIEW PAGE INDEX CHANGING EVENT
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void gvUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.gvUsers_PageIndexChanging(this, sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Method is used to Assign user to View
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void btnAssignUser_Click(object sender, EventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.btnAssignUser_Click(this, sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// METHOD IS USED TO BIND LEFT HAND GRID AFTER CLIK ON EDIT BUTTON
        /// </summary>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        protected void OnEditButton(object sender, EventArgs e)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    customizeViewModel.OnEditButton(this, sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", customizeViewModel.userSessionInfo.ACC_CompanyName).Replace("*", customizeViewModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// METHOD IS USED TO BIND RIGHT HAND GRID AFTER CLIK ON EDIT BUTTON
        /// </summary>
        /// <param name="o_Data">Parameter for View Id and Customize view page for</param>
        /// <returns>RETRUN STRING ARRAY</returns>
        [WebMethod]
        public static string BindRightGridOnEdit(object o_Data)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    return customizeViewModel.BindRightGridOnEdit(o_Data);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// METHOD IS USED TO BIND FINAL GRID ON EDIT
        /// </summary>
        /// <param name="o_Data">Parameter for View Id and Customize view page for</param>
        /// <returns>RETRUN STRING ARRAY</returns>
        [WebMethod]
        public static string BindFinalGridOnEdit(object o_Data)
        {
            try
            {
                using (CustomizeViewModel customizeViewModel = new CustomizeViewModel())
                {
                    return customizeViewModel.BindFinalGridOnEdit(o_Data);
                }
            }
            catch
            {
                throw;
            }
        }
    }
}
