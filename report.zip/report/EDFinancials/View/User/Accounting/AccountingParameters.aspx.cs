﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.UI.WebControls;
using System.Web.Services;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    ///  accounting  Parameters page code behind class
    /// </summary>
    public partial class AccountingParameters : BasePage
    {
        #region Variables

        /// <summary>
        /// Variables declaration
        /// </summary>
        int n_Index = 0, n_VAL_METH_CAL_CC = 0, n_ACC_METHOD = 0, n_RECOGNITION_CC = 0, n_COSTREVERSALAF_VC = 0, n_COSTREVERSALAF_UC = 0, n_COSTREVERSALAF_LAP = 0, n_Applicable_From_Date = 0, n_Comments = 0, n_To_Date = 0, n_APID = 0, n_Approval_Status = 0, n_View_History_Data = 0;

        #endregion

        #region Page Load Event
        /// <summary>
        /// call the method while page will load.
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                    {
                        if ((!(String.IsNullOrEmpty(Request.QueryString["PageName"]))) && (Convert.ToString(Request.QueryString["PageName"]).ToUpper().Equals("ACCOUNTINGREPORT")))
                            hdnQueryString.Value = Convert.ToString(Request.QueryString["PageName"]);
                        accountingParametersModel.PopulateAllControls(this);
                        accountingParametersModel.CheckEmployeeRolePriviledges(this);
                    }
                }
                ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events
        /// <summary>
        ///  grid view row created event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gv_RowCreated(object sender, GridViewRowEventArgs e)
        {
            using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
            {

                //If row type= header customize header cells
                if (e.Row.RowType == DataControlRowType.Header)
                    accountingParametersModel.CustomizeGridHeader((GridView)sender, e.Row, 2);
            }

        }

        /// <summary>
        ///  grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    accountingParametersModel.RowDataBindForGVAP(e, ref n_Index, ref n_VAL_METH_CAL_CC, ref n_ACC_METHOD, ref n_RECOGNITION_CC, ref n_COSTREVERSALAF_VC,
                        ref n_COSTREVERSALAF_UC, ref n_COSTREVERSALAF_LAP, ref n_Applicable_From_Date, ref n_Comments, ref n_To_Date, ref n_APID, ref n_Approval_Status, ref n_View_History_Data);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  grid view page index changing event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    accountingParametersModel.PageIndexChangingForGVACP(e.NewPageIndex, this);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// click event of button Edit
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnAPSSave_Click(object sender, EventArgs e)
        {
            using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
            {
                int n_RetValue = accountingParametersModel.UpdateAccountinParametersData(this);
            }
        }

        #endregion

        #region Methods
        /// <summary>
        /// Method is used to bind data to history grid
        /// </summary>
        /// <param name="s_ConfigID">Primary key / ID against whom the history data will display</param>
        /// <returns></returns>
        [WebMethod]
        public static AccountingProperties[] BindHistoryGridByID(object s_ConfigID)
        {
            try
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    return accountingParametersModel.BindHistoryGridByID(s_ConfigID);
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}