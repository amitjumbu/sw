﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.Services;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Forfeiture Setup code behind class
    /// </summary>
    public partial class ForfeitureSetup : BasePage
    {
        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                    {
                        if ((!(String.IsNullOrEmpty(Request.QueryString["PgName"]))) && (Convert.ToString(Request.QueryString["PgName"]).ToUpper().Equals("APPROVEFORFEITUREGROUP")))
                        {
                            Session["ApproveForfrGroup"] = Convert.ToString(Request.QueryString["PgName"]);
                            forfeitureSetupModel.Page_Load(this, true);
                        }
                        else if ((!(String.IsNullOrEmpty(Request.QueryString["PageName"]))) && (Convert.ToString(Request.QueryString["PageName"]).ToUpper().Equals("ACCOUNTINGREPORT")))
                        {
                            hdnQueryStringFG.Value = Convert.ToString(Request.QueryString["PageName"]);
                            forfeitureSetupModel.Page_Load(this, false);
                        }
                        else
                        {
                            Session["ApproveForfrGroup"] = null;
                            forfeitureSetupModel.Page_Load(this, false);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events

        /// <summary>
        /// This method is used to display error/success messages
        /// </summary>
        /// <param name="b_IsVisible">b_IsVisible</param>
        /// <param name="s_Type">s_Type</param>
        /// <param name="n_RetValue">n_RetValue</param>
        /// <param name="b_IsApprovalScreen">b_IsApprovalScreen</param>
        public void DisplayMessage(bool b_IsVisible, string s_Type, int n_RetValue, bool b_IsApprovalScreen)
        {
            try
            {
                using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                {
                    forfeitureSetupModel.DisplayMessage(b_IsVisible, this, s_Type, n_RetValue, b_IsApprovalScreen);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear message div
        /// </summary>
        public void ClearMessageDiv()
        {
            try
            {
                using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                {
                    forfeitureSetupModel.ClearMessageDiv(this);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to rebind grids on post-back
        /// </summary>
        /// <param name="s_Type">s_Type</param>
        /// <param name="b_IsApprovalPage">b_IsApprovalPage</param>
        public void RebindForfeitureGrids(string s_Type, bool b_IsApprovalPage)
        {
            try
            {
                using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                {
                    forfeitureSetupModel.RebindForfeitureGrids(this, s_Type, b_IsApprovalPage);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// History popup button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCClosePopup_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                {
                    forfeitureSetupModel.btnFGCClosePopup_Click(this);
                    RebindForfeitureGrids("PopupClose", false);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureSetupModel forfeitureSetupModel = new ForfeitureSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to bind history grid data
        /// </summary>
        /// <param name="o_FGAID">o_FGAID</param>
        /// <param name="o_FromDate">o_FromDate</param>
        /// <param name="o_Type">o_Type</param>
        /// <returns>returns list array of AccountingProperties</returns>
        [WebMethod]
        public static AccountingProperties[] BindFGSHistoryGrid(object o_FGAID, object o_FromDate, object o_Type)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    return forfeitureGroupCreationModel.BindFGSHistoryGrid(o_FGAID, o_FromDate, o_Type);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        /// <summary>
        /// This method is used to retrieve forfeiture rate settings history data 
        /// </summary>
        /// <param name="o_FRSID">o_FRSID</param>
        /// <returns>returns list array of AccountingProperties</returns>
        [WebMethod]
        public static AccountingProperties[] BindFRSHistoryGrid(object o_FRSID)
        {
            try
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    return forfeitureRateSettingsModel.BindFRSHistoryGrid(o_FRSID);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
        #endregion
    }
}