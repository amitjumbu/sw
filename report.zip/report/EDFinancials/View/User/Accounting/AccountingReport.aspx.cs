﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections;
using System.Drawing;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Accounting Report code behind class
    /// </summary>
    public partial class AccountingReport : BasePage
    {
        /// <summary>
        /// Variable Declaration
        /// </summary>
        int n_SR_Index = 0, n_MG_Index = 0;

        /// <summary>
        /// Variable Declaration
        /// </summary>
        Hashtable ht_SchemeWIse = new Hashtable();

        /// <summary>
        /// Variable Declaration
        /// </summary>
        Hashtable ht_MainGrid = new Hashtable();

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                    {
                        accountingReportModel.Page_Load(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        ///  Grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.gvARDetails_RowDataBound(e, ref n_MG_Index, ref ht_MainGrid);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.gvARDetails_PageIndexChanging(this, e);
                    accountingReportModel.ShowHideMessageDiv(this, string.Empty, false, "none");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// View Report button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARViewReport_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnARViewReport_Click(this,"SUMMARY");
                    accountingReportModel.ShowHideMessageDiv(this, string.Empty, false, "none");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARMainReport_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
                {
                    accReportingCommonModel.CustomizeGridHeader((GridView)sender, e.Row, 2, this, "gvARMainReport", ref ht_SchemeWIse);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARMainReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.gvARMainReport_PageIndexChanging(this, e);
                    accountingReportModel.ShowHideMessageDiv(this, string.Empty, false, "none");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARSummaryReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.gvARSummaryReport_PageIndexChanging(this, e);
                    accountingReportModel.ShowHideMessageDiv(this, string.Empty, false, "none");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARSummaryReport_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    using (AccReportingCommonModel AccReportingCommonModel = new AccReportingCommonModel())
                    {
                        accountingReportModel.gvARSummaryReport_RowDataBound(sender, this, e, ref n_SR_Index, ref ht_SchemeWIse);

                        AccReportingCommonModel.CustomizeGridHeader((GridView)sender, e.Row, 2, this, "gvARSummaryReport", ref ht_SchemeWIse);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARCommentsHistory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                // Do Nothing
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvARCommentsHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.gvARCommentsHistory_PageIndexChanging(this, e);
                    accountingReportModel.ShowHideMessageDiv(this, string.Empty, false, "none");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to bind valuation parameters to compare
        /// </summary>
        /// <param name="o_GrantRegID">Grant Registration ID</param>
        /// <returns>returns list object of Valuation Parameters</returns>
        [WebMethod]
        public static AccountingProperties[] BindValuationParasToCompare(object o_GrantRegID)
        {
            try
            {
                using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
                {
                    return accReportingCommonModel.BindValuationParasToCompare(o_GrantRegID);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gv2_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    switch (e.Row.RowType)
                    {
                        case DataControlRowType.Header:
                            e.Row.Cells[e.Row.Cells.Count - 1].Visible = false;
                            break;

                        case DataControlRowType.DataRow:
                            if (e.Row.RowIndex.Equals(0))
                            {
                                GridView parentGrid = (GridView)sender;

                                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                                {
                                    NewTotalRow.Font.Bold = true;
                                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                    using (TableCell HeaderCell = new TableCell())
                                    {
                                        HeaderCell.Attributes.Add("Class", "gvChildGrid");
                                        HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                        HeaderCell.Font.Bold = true;
                                        HeaderCell.Text = "Variables";
                                        HeaderCell.ColumnSpan = accountingReportModel.ac_AccountingReport.n_VestCount;
                                        HeaderCell.HorizontalAlign = HorizontalAlign.Left;
                                        NewTotalRow.Cells.Add(HeaderCell);
                                        parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1, NewTotalRow);
                                    }
                                }
                            }

                            for (int n_ColCnt = 1; n_ColCnt < e.Row.Cells.Count - 1; n_ColCnt++)
                            {
                                if (!e.Row.Cells[e.Row.Cells.Count - 1].Text.Equals("&nbsp;") && Convert.ToDecimal(e.Row.Cells[e.Row.Cells.Count - 1].Text).Equals(1))
                                {
                                    e.Row.Cells[n_ColCnt].ForeColor = Color.Green;
                                    e.Row.Cells[n_ColCnt].ToolTip = "Manually updated";
                                }
                                e.Row.Cells[e.Row.Cells.Count - 1].Visible = false;
                            }

                            switch (((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[0].ToString())
                            {
                                case "IS_MU_MKT_FV":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_MKT_IV":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_EXL":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_VOL":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_RFIR":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_DIVD":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_DIVD_MP_DIVD":
                                    e.Row.Visible = false;
                                    break;
                            }
                            break;
                    }
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gv2_DataBound(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.gv2_DataBound(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// View IV FV calculations click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARViewIVFVCalculations_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
                {
                    accReportingCommonModel.ViewIVFVCalculations(hdnARCalcGrantRegID.Value, hdnARCalcMP_Type.Value, this);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Download report click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARDownloadReport_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnARDownloadReport_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Download report edit button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARDownloadReportEdit_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.DownloadDocument(this, string.Empty);
                    accountingReportModel.ShowHideMessageDiv(this, string.Empty, false, "none");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Download PDF report click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void imgARDownloadPDFReport_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.DownloadDocument(this, string.Empty);
                    accountingReportModel.ShowHideMessageDiv(this, string.Empty, false, "none");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Download selected document click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARDownloadSelectedDoc_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.DownloadDocument(this, "btnARDownloadSelectedDoc");
                    accountingReportModel.ShowHideMessageDiv(this, string.Empty, false, "none");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Download selected report click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARDownloadSlctedRport_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.DownloadDocument(this, "btnARDownloadSlctedRport");
                    accountingReportModel.ShowHideMessageDiv(this, string.Empty, false, "none");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// date text changed event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void txtARDate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.txtARDate_TextChanged(this, txtARDate.Text,string.Empty);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Template send for review button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARTemplateSendForReview_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnARTemplateSendForReview_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Edit and View button clcik event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnAREditAndView_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnAREditAndView_Click(this, hdnARACC_RPT_GRP_ID.Value, "btnAREditAndView");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Reviewer approval button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARReviewerApproval_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnAREditAndView_Click(this, hdnARACC_RPT_GRP_ID.Value, "btnARReviewerApproval");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Create report button clcik event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARCreateAccReport_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnARCreateAccReport_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /* commenting it for now as it's not required 
       /// <summary>
       /// Reset button click event
       /// </summary>
       /// <param name="sender">sender object</param>
       /// <param name="e">event args</param>
       protected void btnARReset_Click(object sender, EventArgs e)
       {
           try
           {
               using (AccountingReportModel accountingReportModel = new AccountingReportModel())
               {
                   accountingReportModel.btnARReset_Click(this);
               }
           }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
       } */

        /// <summary>
        /// Cancel report button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARCancelReport_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.BindAllReports(this, string.Empty);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Reviewer approve button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARReviewerApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnARReviewerApprove_Click(this, "btnARReviewerApprove");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Reviewer disapprove button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARReviewerDisApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnARReviewerApprove_Click(this, "btnARReviewerDisApprove");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Client approve button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARClientApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnARReviewerApprove_Click(this, "btnARClientApprove");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Client disapprove button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARClientDisApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnARReviewerApprove_Click(this, "btnARClientDisApprove");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Report lock and delete button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnARLockAndDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.btnARLockAndDelete_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to bind valuation parameters to compare
        /// </summary>
        /// <param name="s_VestingPeriodID">Grant Registration ID</param>
        /// <param name="s_ReportingDate">Grant Registration ID</param>
        /// <returns>returns list object of Valuation Parameters</returns>
        [WebMethod]
        public static string ViewAcceleratedVesting(object s_VestingPeriodID, object s_ReportingDate)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    return accountingReportModel.GetAcceleratedData(Convert.ToString(s_VestingPeriodID), Convert.ToString(s_ReportingDate));
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind data to history grid
        /// </summary>
        /// <param name="s_GrantRegID">s_GrantRegID object</param>
        /// <param name="s_MP_Type">s_MP_Type object</param>
        /// <returns></returns>
        [WebMethod]
        public static string ViewHistory(object s_GrantRegID,object s_MP_Type)
        {
             using (AccountingReportModel accountingReportModel = new AccountingReportModel())
             {
                 return accountingReportModel.GetDetails(Convert.ToString(s_GrantRegID), Convert.ToString(s_MP_Type));
             }
        }

        /// <summary>
        /// Method is used to bind data to history grid
        /// </summary>
        /// <param name="s_GrantRegID">s_GrantRegID object</param>
        /// <param name="s_MP_Type">s_MP_Type object</param>
        /// <returns></returns>
        [WebMethod]
        public static string ViewIVFVCorpAct(object s_GrantRegID, object s_MP_Type)
        {
            using (AccountingReportModel accountingReportModel = new AccountingReportModel())
            {
                return accountingReportModel.GetIVFVCORPDetails(Convert.ToString(s_GrantRegID), Convert.ToString(s_MP_Type));
            }
        }

        /// <summary>
        /// ddlDefaultView change index event
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void ddlDefaultView_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.LoadSelcted_View(this);
                }
            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// btnSetDefault click event
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void btnSetDefault_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    accountingReportModel.SetDefaultView(this);
                }
            }
            catch (Exception Ex)
            {
                using (EmployeeMasterModel employeeMasterModel = new EmployeeMasterModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeMasterModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeMasterModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnARViewWorkings_Click(object sender, EventArgs e)
        {
            try
            {
                using (AccountingReportModel accountingReportModel = new AccountingReportModel())
                {
                    //accountingReportModel.btnARViewReport_Click(this, "SUMMARY");
                    accountingReportModel.ShowHideMessageDiv(this, string.Empty, false, "none");
                }
            }
            catch (Exception Ex)
            {
                using (AccountingParametersModel accountingParametersModel = new AccountingParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", accountingParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", accountingParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to create report subscription
        /// </summary>
        /// <param name="o_GrantRegID">o_GrantRegID</param>
        /// <param name="o_CallFOR">o_CallFOR</param>
        /// <returns>string</returns>
        [WebMethod]
        public static string SSRSReportScheduling(object o_GrantRegID, object o_CallFOR)
        {
            using (AccountingReportModel accountingReportModel = new AccountingReportModel())
            {
                return accountingReportModel.SSRSReportScheduling((string)o_GrantRegID,(string)o_CallFOR);
            }
        }

        /// <summary>
        /// lbtnRefresh_Click
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void lbtnRefresh_Click(object sender, EventArgs e)
        {
            using (AccountingReportModel accountingReportModel = new AccountingReportModel())
            {
                accountingReportModel.CheckReportGeneratedAndDownload(this);
            }
        }

    }
}