﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting.UserControl
{
    /// <summary>
    /// Forfeiture Rate Settings code behind class 
    /// </summary>
    public partial class ForfeitureRateSettingsUC : BaseUC
    {
        #region Variables declaration

        /// <summary>
        /// Variables declaration
        /// </summary>
        int n_Index = 0, n_True_Up = 0, n_Forfeiture_Calculation_On = 0, n_IS_LAPSED_OPTIONS_CHECKED = 0,
            n_IS_VESTED_CANCELLED_CHECKED = 0, n_IS_UNVESTED_CANCELLED_CHECKED = 0, n_Remark = 0, n_Applicable_From_Date = 0, n_To_Date = 0, n_FRSID = 0, n_Approval_Status = 0, n_View_History_Data = 0
            , n_Appr_Index = 0, n_Appr_PARAMETERS = 0, n_Appr_PREVIOUSSETTINGS = 0, n_Appr_CURRENTSETTINGS = 0, n_Appr_FRSAID = 0;

        #endregion

        #region Page load event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                    {
                        forfeitureRateSettingsModel.Page_Load(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureRateSettingsModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureRateSettingsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control events

        /// <summary>
        /// Forfeiture Rate settings save button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFRSSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "FRS", forfeitureRateSettingsModel.btnFRSSave_Click(this), (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureRateSettingsModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureRateSettingsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid-view page index change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvFRSDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    forfeitureRateSettingsModel.gvFRSDetails_PageIndexChanging(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureRateSettingsModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureRateSettingsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid-view row data bound event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvFRSDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    forfeitureRateSettingsModel.gvFRSDetails_RowDataBound(e, ref n_Index, ref n_True_Up, ref n_Forfeiture_Calculation_On, ref  n_IS_LAPSED_OPTIONS_CHECKED,
            ref n_IS_VESTED_CANCELLED_CHECKED, ref  n_IS_UNVESTED_CANCELLED_CHECKED, ref  n_Remark, ref n_Applicable_From_Date, ref  n_To_Date, ref  n_FRSID, ref n_Approval_Status, ref  n_View_History_Data);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureRateSettingsModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureRateSettingsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Forfeiture Rate Settings approve button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFRSApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "FRS_APPROVAL", forfeitureRateSettingsModel.btnFRSApprove_Click(this, true), (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureRateSettingsModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureRateSettingsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Forfeiture Rate Settings Disapprove button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFRSDisApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "FRS_APPROVAL", forfeitureRateSettingsModel.btnFRSDisApprove_Click(this, false), (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });

                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureRateSettingsModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureRateSettingsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvFRSApprovalGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    forfeitureRateSettingsModel.gvFRSApprovalGrid_RowDataBound(e, ref n_Appr_Index, ref n_Appr_PARAMETERS, ref n_Appr_PREVIOUSSETTINGS, ref n_Appr_CURRENTSETTINGS, ref n_Appr_FRSAID, this);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureRateSettingsModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureRateSettingsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}