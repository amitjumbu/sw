﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting.UserControl
{
    /// <summary>
    /// OptionDetails user control class
    /// </summary>
    public partial class OptionDetailsUC : BaseUC
    {
        /// <summary>
        /// This variables are used to get cell index of gvHistory gridview
        /// </summary>
        public int n_Index = 0, n_ReportYear = 0, n_DataUpdatedAsOn = 0, n_Status = 0, n_Comments = 0, n_Documents = 0, n_OprationDate = 0, n_Lock = 0;

        int n_OpIndex, n_EmployeeID = 0, n_EmployeeName = 0, n_SchemeName = 0, n_Granted = 0, n_Cancelled = 0, n_VCancelled = 0, n_UCancelled = 0, n_Lapsed = 0, n_Execrised = 0, n_Unvested = 0, n_VestedExercisable = 0, n_Outstanding = 0, n_ForfeitureRate = 0, n_Action = 0, n_RowIndex = 1, n_Rate = 0, n_GrantOptionID = 0;

        /// <summary>
        /// This variables are used to get cell index of gvHistory gridview
        /// </summary>
        public int n_DocIndex = 0, n_Doc_File_Name = 0, n_Doc_Download = 0, n_Doc_Delete = 0, n_Doc_DataUpdatedAsOn = 0;

        /// <summary>
        /// This variables are used to get cell index of gvCommentsDetails gridview
        /// </summary>
        public int n_ComIndex = 0, n_Com_DataUpdatedAsOn = 0;

        /// <summary>
        /// Set value to bool variable to identify cotrol is called or not
        /// </summary>
        private bool IsTextboxControlCalled = false;

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    IsTextboxControlCalled = (Page.Request.Params["__EVENTTARGET"] == "ctl00$MainContent$OptionDetailsUC$txtReportDate");

                    if (!Page.IsPostBack)
                    {
                        optionsDetailsModel.BindUI(this);
                        optionsDetailsModel.BindDropDown(this);
                        optionsDetailsModel.EncryptData(this);
                    }
                    optionsDetailsModel.GetUpdatedAsOnData(this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// RowDataBound event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gvHistory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.gvHistory_RowDataBound(this, sender, e, ref n_Index, ref n_ReportYear, ref n_DataUpdatedAsOn, ref n_Status, ref n_Comments, ref n_Documents, ref n_OprationDate, ref n_Lock);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// imgButton Click Event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        public void imgButton_Click(object sender, EventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.imgButton_Click(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This click event is used to search records based on filter
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnODSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.SearchRecords(this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear applied filters
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnODClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.ClearFiltrs(this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// PageIndexChanging event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gvHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

        }

        /// <summary>
        /// RowDataBound event for gvOptionDetails
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gvOptionDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.gvOptionDetails_RowDataBound(this, e, ref n_OpIndex, ref n_EmployeeID, ref n_EmployeeName, ref n_SchemeName, ref n_Granted, ref n_Cancelled, ref n_VCancelled, ref n_UCancelled, ref n_Lapsed, ref n_Execrised, ref n_Unvested, ref n_VestedExercisable, ref n_Outstanding, ref n_ForfeitureRate, ref n_Action, sender, ref n_RowIndex, ref n_Rate, ref n_GrantOptionID);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row Data Bound Event Of Child GridView
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        internal void childGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.childGrid_RowDataBound(sender, e, this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gvOptionDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.PageIndexChanging(e, this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to rebind data after save data vest wise
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnSaveData_Click(object sender, EventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.GetData(this);
                    optionsDetailsModel.SearchRecords(this);
                    optionsDetailsModel.ShowMessage(this, "lblODCreated");
                    optionsDetailsModel.ShowUpdateAllButton(this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to rebind data after save data vest wise
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnUpdateData_Click(object sender, EventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.GetUpdateData(this);
                    optionsDetailsModel.ShowMessage(this, "lblODUpdated");
                    optionsDetailsModel.ShowUpdateAllButton(this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to upload file
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnODFileUpload_Click(object sender, EventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.UploadFile(this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear file content
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnODClearFileContent_Click(object sender, EventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.btnODClearFileContent_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear upload comments
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnODUploadComments_Click(object sender, EventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.UploadComments(this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to upload files
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void gvODUploadedFiles_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.gvODUploadedFiles_RowDataBound(this, e, ref n_DocIndex, ref n_Doc_File_Name, ref n_Doc_Download, ref n_Doc_Delete, ref n_Doc_DataUpdatedAsOn);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// RowDataBound for gvCommentsDetails
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        public void gvCommentsDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.gvCommentsDetails_RowDataBound(this, e, ref n_ComIndex, ref n_Com_DataUpdatedAsOn);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// TextChanged event for txtReportDate
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void txtReportDate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (IsTextboxControlCalled)
                {
                    using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                    {
                        optionsDetailsModel.txtReportDate_TextChanged(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Update all grants
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnUpdateAll_Click(object sender, EventArgs e)
        {
            try
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    optionsDetailsModel.UpdateAllGrants(this);
                    optionsDetailsModel.SearchRecords(this);
                }
            }
            catch (Exception Ex)
            {
                using (OptionsDetailsModel optionsDetailsModel = new OptionsDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", optionsDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", optionsDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}