﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting.UserControl
{
    /// <summary>
    /// Code behind file CorporateActionUpdRevertUC Page
    /// </summary>
    public partial class CorporateActionUpdRevertUC : BaseUC
    {
        #region Variables Declaration
        int n_indexgv = 0;
        int n_rowIndex = 1, n_VestIndex = 0, n_VestID = 0, n_VestDate = 0, n_VestExpiryDate = 0, n_VestPercent = 0, n_VestGrtOptID = 0, n_VestFairValue = 0, n_VestIntrinsicValue = 0;
        int n_PopUpIndex, n_PreCorpAct = 0, n_PostCorpAct = 0;

        string s_GrantRegID = string.Empty, s_GrantOptID = string.Empty;

        Hashtable hash_Table = new Hashtable();
        #endregion

        /// <summary>
        /// Page load method for CorporateActionUpdRevertUC
        /// </summary>
        /// <param name="sender">CorporateActionUpdRevertUC  Page</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            if (hdnIsFVIVPopSelected.Value.Equals("Set"))
            {
                btnCAAUpdateCorpAct_Click(Convert.ToString(hdnEffectiveDate.Value));
            }
        }

        /// <summary>
        /// This method is used to Bind gvCAAUpdateCorpAction GridView
        /// </summary>
        /// <param name="s_EffectiveDate">string Effective Date</param>
        internal void btnCAAUpdateCorpAct_Click(string s_EffectiveDate)
        {
            try
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    corporateActionUpdRevertUCModel.btnCAAUpdateCorpAct_Click(this, s_EffectiveDate);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionUpdRevertUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionUpdRevertUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound Event of gvCAAUpdateCorpAction GridView
        /// </summary>
        /// <param name="sender">gvCAAUpdateCorpAction GridView</param>
        /// <param name="e">e</param>
        protected void gvCAAUpdateCorpAction_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    corporateActionUpdRevertUCModel.gvCAAUpdateCorpAction_RowDataBound(this, sender, e, ref n_indexgv, ref hash_Table);

                    if (e.Row.RowType == DataControlRowType.DataRow && hdnCalcMethod.Value.Equals("2"))
                    {
                        s_GrantRegID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString();
                        s_GrantOptID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Option ID").ToString();

                        corporateActionUpdRevertUCModel.AddChildGridView(this, sender, e, s_GrantRegID, s_GrantOptID, ref n_rowIndex, ref n_VestIndex, ref n_VestID, ref n_VestDate, ref n_VestExpiryDate, ref n_VestPercent);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionUpdRevertUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionUpdRevertUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row Bound event of gv_ChildGrid GridView
        /// </summary>
        /// <param name="sender">gv_ChildGrid GridView</param>
        /// <param name="e">e</param>
        internal void gv_ChildGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    corporateActionUpdRevertUCModel.gv_ChildGrid_RowDataBound(this, e, ref n_VestIndex, ref n_VestID, ref n_VestDate, ref n_VestExpiryDate, ref n_VestPercent, ref n_VestFairValue, ref n_VestIntrinsicValue, ref n_VestGrtOptID);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionUpdRevertUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionUpdRevertUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Data Bound event of gvCAAUpdateCorpAction GridView
        /// </summary>
        /// <param name="sender">gvCAAUpdateCorpAction GridView</param>
        /// <param name="e">e</param>
        protected void gvCAAUpdateCorpAction_DataBound(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    corporateActionUpdRevertUCModel.gvCAAUpdateCorpAction_DataBound(this, sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionUpdRevertUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionUpdRevertUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Page Index Change Event of gvCAAUpdateCorpAction GridView
        /// </summary>
        /// <param name="sender">gvCAAUpdateCorpAction GridView</param>
        /// <param name="e">e</param>
        protected void gvCAAUpdateCorpAction_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    corporateActionUpdRevertUCModel.gvCAAUpdateCorpAction_PageIndexChanging(this, e);

                    this.Page.GetType().InvokeMember("BindgvCAAjdGridView", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionUpdRevertUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionUpdRevertUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// LinkButton Fair Value Click Event to Bind Fair Value FV PopUp window
        /// </summary>
        /// <param name="sender">LinkButton FVIV</param>
        /// <param name="e">e</param>
        internal void LinkButtonFVIVValue_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    corporateActionUpdRevertUCModel.LinkButtonFVIVValue_Click(this, Convert.ToString(hdnEventName.Value), Convert.ToString(hdnGrantOptionID.Value));

                    this.Page.GetType().InvokeMember("BindgvCAAjdGridView", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionUpdRevertUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionUpdRevertUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row Data Bound Event Of gvPreCorpActFV GridView displayed in the PreCorporateAction FV PopUp window
        /// </summary>
        /// <param name="sender">gvPreCorpActFV GridView</param>
        /// <param name="e">e</param>
        protected void gvPreCorpActFVIV_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    corporateActionUpdRevertUCModel.gvPreCorpActFVIV_RowDataBound(this, sender, e, ref n_PopUpIndex, ref n_PreCorpAct, ref n_PostCorpAct);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionUpdRevertUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionUpdRevertUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Data Bound Event Of gvPreCorpActFV GridView displayed in the PreCorporateAction FV PopUp window 
        /// </summary>
        /// <param name="sender">gvPreCorpActFV GridView</param>
        /// <param name="e">e</param>
        protected void gvPreCorpActFVIV_DataBound(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    corporateActionUpdRevertUCModel.gvPreCorpActFVIV_DataBound(this, sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionUpdRevertUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionUpdRevertUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Apply Button Click Event. This method is used to Apply the Corpoarte Action to the Data
        /// </summary>
        /// <param name="sender">Apply Button</param>
        /// <param name="e">e</param>
        protected void btnCAAApply_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    int n_Result = corporateActionUpdRevertUCModel.btnCAAApply_Click(this);

                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { Convert.ToString(((Button)sender).ID), n_Result });
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionUpdRevertUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionUpdRevertUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to Check if Data is Locked.
        /// </summary>
        /// <param name="s_EffectiveDate">string Effective Date</param>
        /// <param name="accountingServiceClient">AccountingService accountingServiceClient Object</param>
        internal void CheckForLockedData(string s_EffectiveDate, AccountingServiceClient accountingServiceClient)
        {
            try
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    corporateActionUpdRevertUCModel.GetCorporateActionDataFromDB(s_EffectiveDate, accountingServiceClient);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionUpdRevertUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionUpdRevertUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}