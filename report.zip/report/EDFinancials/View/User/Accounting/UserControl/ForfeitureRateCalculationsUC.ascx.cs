﻿using System;

namespace EDFinancials.View.User.Accounting.UserControl
{
    /// <summary>
    /// Forfeiture Rate Calculations code behind class
    /// </summary>
    public partial class ForfeitureRateCalculationsUC : BaseUC
    {
        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {

        }
    }
}