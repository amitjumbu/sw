﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting.UserControl
{
    /// <summary>
    /// Code behind file CorporateActionCalcUC Page
    /// </summary>
    public partial class CorporateActionCalcUC : BaseUC
    {
        #region Variables Declaration
        int n_indexgvUpd = 0, n_DataUpdatedAsOn = 0, n_PreCorpAct = 0, n_PostCorpAct = 0;
        #endregion

        /// <summary>
        /// Page load method for CorporateActionCalcUC
        /// </summary>
        /// <param name="sender">CorporateActionCalcUC Page</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
        }

        /// <summary>
        /// This method is used to Bind value to all the labels and gvCAAUpdateCalcCorpAction GridView 
        /// </summary>
        /// <param name="s_GrantOptID">Grant Option ID</param>
        internal void btnCAAUpdateCorpActEffect_Click(string s_GrantOptID)
        {
            try
            {
                using (CorporateActionCalcUCModel corporateActionCalcUCModel = new CorporateActionCalcUCModel())
                {
                    corporateActionCalcUCModel.btnCAAUpdateCorpActEffect_Click(this, s_GrantOptID);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionCalcUCModel corporateActionCalcUCModel = new CorporateActionCalcUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionCalcUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionCalcUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound Event of gvCAAUpdateCalcCorpAction GridView
        /// </summary>
        /// <param name="sender">gvCAAUpdateCalcCorpAction GridView</param>
        /// <param name="e">e</param>
        protected void gvCAAUpdateCalcCorpAction_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CorporateActionCalcUCModel corporateActionCalcUCModel = new CorporateActionCalcUCModel())
                {
                    corporateActionCalcUCModel.gvCAAUpdateCalcCorpAction_RowDataBound(sender, e, this, ref n_indexgvUpd, ref n_DataUpdatedAsOn, ref n_PreCorpAct, ref n_PostCorpAct);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionCalcUCModel corporateActionCalcUCModel = new CorporateActionCalcUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionCalcUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionCalcUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// btnCAACalcSave Button Click Event. This method is used to Save the Pre-Coporate and Post-Corporate Action Data.
        /// </summary>
        /// <param name="sender">btnCAACalcSave Button</param>
        /// <param name="e">e</param>
        protected void btnCAACalcSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionCalcUCModel corporateActionCalcUCModel = new CorporateActionCalcUCModel())
                {
                    int n_Result = corporateActionCalcUCModel.btnCAACalcSave_Click(this, Convert.ToString(hdnAGRMID.Value), Convert.ToString(hdnEMPID.Value), Convert.ToString(hdnCAAUpdGrntOptID.Value), Convert.ToString(hdnCalcEffectiveDate.Value), Convert.ToString(hdnArrayPreCorpAct.Value), Convert.ToString(hdnArrayPostCorpAct.Value));

                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { Convert.ToString(((Button)sender).ID), n_Result });
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionCalcUCModel corporateActionCalcUCModel = new CorporateActionCalcUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionCalcUCModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionCalcUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}