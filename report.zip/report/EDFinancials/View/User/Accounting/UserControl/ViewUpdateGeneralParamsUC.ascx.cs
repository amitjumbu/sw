﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting.UserControl
{
    /// <summary>
    /// 
    /// </summary>
    public partial class ViewUpdateGeneralParamsUC : BaseUC
    {
        int n_UVPindex = 0, n_Currency = 0, n_ExPrc = 0, n_VestDet = 0, n_Ratio = 0, n_MissingPrices = 0, n_RowIndex = 1;

        #region Page Load
        /// <summary>
        /// This is page load event of  ViewUpdateGeneralParamsUC page
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {

        }
        #endregion

        #region Redirection from Grant Detils Page to respective pages
        /// <summary>
        /// This method is used to redirect from Grant Detils Page to respective pages on the click event(s) of Link Button(s)
        /// </summary>
        /// <param name="sender">Link Button(s) On View Updae General Parameters Tab</param>
        /// <param name="e">e</param>
        protected void lnkMarketPrice_Click(object sender, EventArgs e)
        {
            switch (Convert.ToString(((LinkButton)sender).ID).ToUpper())
            {
                case "LNKMARKETPRICE":
                    Response.Redirect("../Valuation/MarketPriceSetup.aspx", false);
                    break;

                case "LNKDIVIDEND":
                    Response.Redirect("../Valuation/DividendSetup.aspx", false);
                    break;

                case "LNKPEERCOMPANY":
                    Response.Redirect("../Valuation/PeerCompanySetUp.aspx", false);
                    break;

                case "LNKCORPACTION":
                    Response.Redirect("../Valuation/CorporateAction.aspx", false);
                    break;
            }
            Session["Tab3GrantD"] = "Set";
            Session["PageNameGrantDetails"] = HttpContext.Current.Request.Url.AbsolutePath;
        }
        #endregion

        #region Redirection to Valuation Report Page on Click of Proceed to Valuation Report Button Click
        /// <summary>
        /// This will redirect user to Valuation Report Page
        /// </summary>
        /// <param name="sender">Proceed to Valuation Report Button</param>
        /// <param name="e">e</param>
        protected void btnViewValuationReport_Click(object sender, EventArgs e)
        {
            Response.Redirect("../Valuation/ValuationReport.aspx", false);
        }
        #endregion

        #region RowBound of gvGVPGrantDetails GridView
        /// <summary>
        /// RowBound of gvGVPGrantDetails GridView
        /// </summary>
        /// <param name="sender">The View DataEntered GridView</param>
        /// <param name="e">e</param>
        protected void gvUGPGrantDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ViewUpdateGeneralParamsUCModel viewUpdateGeneralParamsUCModel = new ViewUpdateGeneralParamsUCModel())
                {
                    viewUpdateGeneralParamsUCModel.gvUGPGrantDetails_RowDataBound(this, sender, e, ref n_UVPindex, ref n_Currency, ref n_ExPrc, ref n_VestDet, ref n_Ratio, ref n_RowIndex, ref n_MissingPrices);
                }
            }
            catch (Exception Ex)
            {
                using (ViewUpdateGeneralParamsUCModel viewUpdateGeneralParamsUCModel = new ViewUpdateGeneralParamsUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", viewUpdateGeneralParamsUCModel.userSessionInfo.ACC_CompanyName).Replace("*", viewUpdateGeneralParamsUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        /// <summary>
        /// Row Data Bound Event Of Child GridView
        /// </summary>
        /// <param name="sender">Child GridView</param>
        /// <param name="e">e</param>
        internal void childGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ViewUpdateGeneralParamsUCModel viewUpdateGeneralParamsUCModel = new ViewUpdateGeneralParamsUCModel())
                {
                    viewUpdateGeneralParamsUCModel.childGrid_RowDataBound(sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (ViewUpdateGeneralParamsUCModel viewUpdateGeneralParamsUCModel = new ViewUpdateGeneralParamsUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", viewUpdateGeneralParamsUCModel.userSessionInfo.ACC_CompanyName).Replace("*", viewUpdateGeneralParamsUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}