﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting.UserControl
{
    /// <summary>
    /// Forfeiture Group Creation code behind class
    /// </summary>
    public partial class ForfeitureGroupCreationUC : BaseUC
    {
        #region Variable Declaration

        /// <summary>
        /// variable declaration 
        /// </summary>
        int n_Index = 0, n_FGID = 0, n_FGAID = 0, n_Group_Name = 0, n_Forfeiture_Rate = 0, n_No_of_Employees = 0, n_Applicable_From_Date = 0, n_Action = 0, n_To_Date = 0, n_Approval_Status = 0
            , n_DocIndex = 0, n_Doc_FGAID = 0, n_Doc_File_Name = 0, n_Doc_File_Path = 0, n_Doc_Download = 0, n_Doc_Delete = 0
            , n_Ass_EmpIndex = 0, n_Ass_EmpSelect = 0, n_Ass_EMPID = 0, n_Ass_Employee_ID = 0, n_Ass_Employee_Name = 0
           , n_Ass_Emp_Group_Name = 0, n_Ass_Emp_Deartment = 0, n_Ass_Emp_Grade = 0, n_Ass_Emp_Designation = 0, n_Ass_IS_APPROVAL_PENDING = 0,
           n_His_Index = 0, n_His_FGAID = 0, n_His_Rate = 0, n_His_Grp_Name = 0, n_His_From_Date = 0, n_His_To_Date = 0, n_His_Is_Approved = 0, n_His_Actions = 0;

        #endregion

        #region Page Load Event

        /// <summary>
        /// Page Load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                    {
                        forfeitureGroupCreationModel.Page_Load(this);

                    }
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events

        /// <summary>
        /// Save button click event to save forfeiture group
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "FGC", forfeitureGroupCreationModel.btnFGCSave_Click(this, Server.MapPath("../../Uploads/" + forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName + "/ForfeitureGroupFiles/")), (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// File upload button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCFileUpload_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "FGC_FILE_UPLOAD", forfeitureGroupCreationModel.btnFGCFileUpload_Click(this, Server.MapPath("../../Uploads/" + forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName + "/ForfeitureGroupFiles/")), (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// File download button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCDownload_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.DownloadFile(this);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// View History button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCViewHistory_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.btnFGCViewHistory_Click(this);
                    this.Page.GetType().InvokeMember("RebindForfeitureGrids", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { "FGC", (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                    this.Page.GetType().InvokeMember("ClearMessageDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Delete File button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCDeleteFile_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "FGC_FILE_UPLOAD", forfeitureGroupCreationModel.btnFGCDeleteFile_Click(this), (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Forfeiture Group Edit/Update button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCEdit_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.btnFGCEdit_Click(this, (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false);
                    this.Page.GetType().InvokeMember("RebindForfeitureGrids", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { "FGC_FILE_UPLOAD", (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                    this.Page.GetType().InvokeMember("ClearMessageDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Add New Group Button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFCGAddNewGroup_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.btnFCGAddNewGroup_Click(this);
                    this.Page.GetType().InvokeMember("RebindForfeitureGrids", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { "FGC_FILE_UPLOAD", (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                    this.Page.GetType().InvokeMember("ClearMessageDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Clear file content button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCClearFileContent_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.btnFGCClearFileContent_Click(this);
                    this.Page.GetType().InvokeMember("RebindForfeitureGrids", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { "FGC_FILE_UPLOAD", (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                    this.Page.GetType().InvokeMember("ClearMessageDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Approve Forfeiture Group button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "FGC_APPROVAL", forfeitureGroupCreationModel.btnFGCApprove_Click(this, true), (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Disapprove forfeiture group button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCDisapprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "FGC_APPROVAL", forfeitureGroupCreationModel.btnFGCDisapprove_Click(this), (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Delete Forfeiture Group button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnFGCDeleteFGrp_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "FGC", forfeitureGroupCreationModel.btnFGCDeleteFGrp_Click(this), (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnFGCCancel_Click(object sender, EventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.btnFGCCancel_Click(this);
                    this.Page.GetType().InvokeMember("RebindForfeitureGrids", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { "FGC_FILE_UPLOAD", (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false });
                    this.Page.GetType().InvokeMember("ClearMessageDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Gridview Events

        /// <summary>
        /// Grid view Row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvFGCForfeitureGroup_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.gvFGCForfeitureGroup_RowDataBound(this, e, ref n_Index, ref n_FGID, ref n_FGAID, ref n_Group_Name, ref n_Forfeiture_Rate, ref n_No_of_Employees, ref n_Applicable_From_Date, ref n_To_Date, ref n_Approval_Status, ref n_Action, (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvFGCForfeitureGroup_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.gvFGCForfeitureGroup_PageIndexChanging(this, e);
                    this.Page.GetType().InvokeMember("ClearMessageDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvFGCUploadedFiles_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.gvFGCUploadedFiles_RowDataBound(this, e, ref n_DocIndex, ref n_Doc_FGAID, ref n_Doc_File_Name, ref n_Doc_File_Path, ref n_Doc_Download, ref n_Doc_Delete, (!String.IsNullOrEmpty(Convert.ToString(Session["ApproveForfrGroup"])) && (Convert.ToString(Session["ApproveForfrGroup"]).ToUpper().Equals("APPROVEFORFEITUREGROUP"))) ? true : false);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Uploaded files grid page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvFGCUploadedFiles_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.gvFGCUploadedFiles_PageIndexChanging(this, e);
                    this.Page.GetType().InvokeMember("ClearMessageDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// History Grid row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvFGCHistory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.gvFGCHistory_RowDataBound(this, e, ref n_His_Index, ref n_His_FGAID, ref n_His_Rate, ref n_His_Grp_Name, ref n_His_From_Date, ref n_His_To_Date, ref n_His_Is_Approved, ref n_His_Actions);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// History Grid page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvFGCHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.gvFGCHistory_PageIndexChanging(this, e);
                    this.Page.GetType().InvokeMember("ClearMessageDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view associated employees row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvFGCAssociatedEmployees_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.gvFGCAssociatedEmployees_RowDataBound(e, ref n_Ass_EmpIndex, ref n_Ass_EmpSelect, ref n_Ass_EMPID, ref n_Ass_Employee_ID, ref n_Ass_Employee_Name, ref n_Ass_Emp_Group_Name, ref n_Ass_Emp_Deartment, ref n_Ass_Emp_Grade, ref n_Ass_Emp_Designation, ref n_Ass_IS_APPROVAL_PENDING);
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Associated Employees grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvFGCAssociatedEmployees_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.gvFGCAssociatedEmployees_PageIndexChanging(this, e);
                    this.Page.GetType().InvokeMember("ClearMessageDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", forfeitureGroupCreationModel.userSessionInfo.ACC_CompanyName).Replace("*", forfeitureGroupCreationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}