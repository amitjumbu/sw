﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting.UserControl
{
    /// <summary>
    /// 
    /// </summary>
    public partial class UCGrantDetails : BaseUC
    {
        int n_cnt = 0, n_index = 0, n_ID = 0, n_Delete = 0, n_Action = 0, n_AGRMID = 0, n_GrantDate = 0, n_GrantID = 0, n_FairValue = 0, n_Status = 0, n_DocumentDownload = 0, n_DocumentName = 0,
             n_DocumentPath = 0, n_Actions = 0, n_IntrinsicValue = 0, rowIndex = 1, n_VestIndex = 0, n_VestID = 0, n_VestDelete = 0, n_VestAction = 0, n_VestGrantDate = 0, n_indexLockedRec = 0,
             n_IDLockedRec = 0, n_DeleteLockedRec = 0, n_ActionLockedRec = 0, n_GrantDateLockedRec = 0, n_GrantIDLockedRec = 0, n_VestIndexLockedRec = 0, n_VestIDLockedRec = 0, n_VestDeleteLockedRec = 0,
             n_VestActionLockedRec = 0, n_VestGrantDateLockedRec = 0, rowIndexLockedRec = 1, n_FairValueLockedRec = 0, n_IntrinsicValueLockedRec = 0, n_GrpNum = 0, n_CompanyLevel = 0, n_GrantLevel = 0,
             n_ValIndex = 0, n_ManuallyUploaded = 0, n_DatList = 0, n_MarketValue = 0, n_VestPercent = 0, n_FairValVest = 0, n_IntrsicValVest = 0;
        
        int n_OptionsGranted = 0, n_OptionsCancelled = 0, n_VestedOptions = 0, n_OutstandingOptions = 0, n_EmployeeDetails = 0, n_VestedCancelled = 0, n_UnestedCancelled = 0, n_Lapsed = 0, n_Exercised = 0, n_Unvested = 0;

        int n_OptionsGranted_Locked = 0, n_OptionsCancelled_Locked = 0, n_VestedOptions_Locked = 0, n_OutstandingOptions_Locked = 0, n_EmployeeDetails_Locked = 0, n_VestedCancelled_Locked = 0, n_UnestedCancelled_Locked = 0, n_Lapsed_Locked = 0, n_Exercised_Locked = 0, n_Unvested_Locked = 0;

        string GrantID = "";

        int n_IsMUFV = 0, n_IsMUIV = 0, n_ExerPrice = 0;

        #region Page Load
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    if (string.IsNullOrEmpty(Convert.ToString(Session["StepNumber"])))
                        ReSetVariables();

                    ReadValuationReportUI();

                    BindPageUI();

                    if (string.IsNullOrEmpty(Convert.ToString(Session["StepNumber"])))
                        BindGrid();
                }
                else
                {
                    BindGrid();
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is used to ResetVaribles
        /// </summary>
        private void ReSetVariables()
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.ReSetVariables(this);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is used to Read Valuation Report UI
        /// </summary>
        private void ReadValuationReportUI()
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.ReadValuationReportUI(this);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is Used to Bind Page UI
        /// </summary>
        private void BindPageUI()
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.BindPageUI(this, Path.GetFileNameWithoutExtension(Request.Path));
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Bind Search Grid
        /// <summary>
        /// Page load event
        /// </summary>
        public void BindGrid()
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {

                    if (!Page.IsPostBack)
                    {
                        gv.VirtualItemCount = 2;
                        o_gvUserControlModel.BindGridView(this, Path.GetFileNameWithoutExtension(Request.Path));

                        if (!string.IsNullOrEmpty(Convert.ToString(Session["ValuationParam"])))
                        {
                            hdnGrantID.Value = Convert.ToString(Session["ValuationParam"]);
                            Session["ValuationParam"] = string.Empty;
                        }
                        o_gvUserControlModel.LoadDefault_ViewDropDowns(this);
						o_gvUserControlModel.BindPagerForGridView(this);
                    }

                    if ((!string.IsNullOrEmpty(hdnGrantID.Value) || (!string.IsNullOrEmpty(hdnViewParametersID.Value)) || (!string.IsNullOrEmpty(hdnIsDeleted.Value)) || (!string.IsNullOrEmpty(hdnDropDownChange.Value)) || (!string.IsNullOrEmpty(hdnSelectedGrants.Value)) || (!string.IsNullOrEmpty(o_gvUserControlModel.ac_SearchGrantDetails.s_SelectedGrants))))
                    {
                        if (string.IsNullOrEmpty(hdnPagerClicked.Value) || string.IsNullOrEmpty(hdnPagerClicked_locked.Value))
                        {
                            n_index = n_indexLockedRec = 0;
                            rowIndex = rowIndexLockedRec = 1;

							o_gvUserControlModel.BindGridView(this, Path.GetFileNameWithoutExtension(Request.Path));

							hdnReset.Value = string.Empty;
 							hdngvPagination.Value = string.Empty; 
                        }
                    }
                    btnVRProceed.Visible = Path.GetFileNameWithoutExtension(Request.Path).Equals("ValuationReport") && ((o_gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report != null && o_gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report.Rows.Count > 0));
                    btnGDAddGrant.Visible = Path.GetFileNameWithoutExtension(Request.Path).Equals("GrantDetails");
                    btnGDDelete.Visible = Path.GetFileNameWithoutExtension(Request.Path).Equals("GrantDetails") && ((o_gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report != null && o_gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report.Rows.Count > 0));
                }
            }
            catch
            {
                throw;
            }

        }
        #endregion

        #region Download File
        /// <summary>
        /// The Document Download Code
        /// </summary>
        /// <param name="sender">btnDocumentDownload Button</param>
        /// <param name="e">e</param>
        protected void btnDocumentDownload_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.DownloadFile(this);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Button/LinkButton click events
        /// <summary>
        /// LinkButton FairValue Click Event
        /// </summary>
        /// <param name="sender">LinkButton FairValue</param>
        /// <param name="e">e</param>
        public void LinkButtonFairValue_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.PivotTable("FairValue", this);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// imgButton Click Event
        /// </summary>
        /// <param name="sender">imgButton</param>
        /// <param name="e">e</param>
        public void imgButton_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.ac_SearchGrantDetails.s_StepNumber = "0";
                    o_gvUserControlModel.GetValuationParameters(this);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Go to Step Button Click Event
        /// </summary>
        /// <param name="sender">Go to Step Button</param>
        /// <param name="e">e</param>
        public void lbtnGotoStep_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    if (!Path.GetFileNameWithoutExtension(Request.Path).Equals("ValuationReport"))
                    {
                        Response.Redirect("ValuationReport.aspx", false);
                        o_gvUserControlModel.RedirectFromGrantDetails();
                    }
                    o_gvUserControlModel.GotoStep(this, Path.GetFileNameWithoutExtension(Request.Path));
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// LinkButton IntrinsicValue Click Evne
        /// </summary>
        /// <param name="sender">LinkButton IntrinsicValue</param>
        /// <param name="e">e</param>
        public void LinkButtonIntrinsicValue_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.PivotTable("IntrinsicValue", this);
                }

            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grant Date Button Click event
        /// </summary>
        /// <param name="sender">Grant Date Button</param>
        /// <param name="e">e</param>
        public void lbtnGrantDate_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.ac_SearchGrantDetails.s_GrantID = hdnGrantID.Value;
                    o_gvUserControlModel.ac_SearchGrantDetails.s_StepNumber = "0";
                    o_gvUserControlModel.ac_SearchGrantDetails.s_ChildPageName = "GrantDetails";
                    Response.Redirect("GrantDetails.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Common methods
        /// <summary>
        /// This method is used to create validation control within child grid
        /// </summary>
        /// <param name="row">GridViewRow</param>
        /// <param name="n_CellIndex">Cell Index</param>
        private void CreateValidator(GridViewRow row, int n_CellIndex)
        {
            try
            {
                row.Cells[n_CellIndex].Controls.Add(new RequiredFieldValidator()
                {
                    ID = "rfvtxt" + n_cnt,
                    ErrorMessage = n_cnt + " Required",
                    ControlToValidate = "txt_" + (n_cnt - 1),
                    ValidationGroup = "rfv"
                });
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to create text box within child grid
        /// </summary>
        /// <param name="s_Control">Control Name</param>
        /// <param name="s_CSSName">CSS name</param>
        /// <param name="s_DefaultText">Default Text</param>
        /// <param name="s_RowIndex">Row Index</param>
        /// <returns>Control</returns>
        private Control CreateControl(string s_Control, string s_CSSName, string s_DefaultText, int s_RowIndex)
        {
            string s = hdnSelectedRow.Value;
            switch (s_Control)
            {
                case "TextBox":
                    using (TextBox textBox = new TextBox())
                    {
                        textBox.ID = "txt_" + n_cnt;
                        textBox.Text = s_DefaultText;
                        textBox.Attributes.Add("onBlur", "return GetTextboxValues(this)");
                        textBox.ValidationGroup = "rfv";


                        switch (s_CSSName)
                        {
                            case "":
                                textBox.CssClass = "cTextBox";
                                break;

                            case "datepickerControl":
                                textBox.CssClass = "cTextBox";
                                textBox.CssClass += " datepickerControl";
                                break;
                        }
                        n_cnt++;
                        return textBox;
                    }
            }
            return new TextBox();
        }
        #endregion

        #region Bind Unlocked records to grid-view
        /// <summary>
        /// Row bound parent grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (gvUserControlModel userControlModel = new gvUserControlModel())
                {
                    userControlModel.BindRows(sender, this, e, ref n_index, ref n_ID, ref n_Delete, ref n_Action, ref n_GrantDate, ref n_FairValue, ref n_IntrinsicValue, ref n_DocumentDownload, ref n_DocumentName, ref n_DocumentPath, ref n_Status, ref n_Actions, ref n_AGRMID, Path.GetFileNameWithoutExtension(Request.Path), false, ref n_GrantID, ref n_GrpNum, ref n_IsMUFV, ref n_IsMUIV, ref n_ExerPrice, ref n_OptionsGranted, ref n_OptionsCancelled, ref n_VestedOptions, ref n_OutstandingOptions, ref n_EmployeeDetails, ref n_VestedCancelled, ref n_UnestedCancelled, ref n_Lapsed, ref n_Exercised, ref n_Unvested);

                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        if (!GrantID.Equals(System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString()))
                        {
                            if (hdnIsDeleted.Value.Equals("true"))
                            {
                                n_index = n_indexLockedRec = 0;
                                rowIndex = rowIndexLockedRec = 1;
                            }
                            GrantID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString();

                            userControlModel.AddChildGrid(sender, e, false, GrantID, ref n_VestIndex, ref n_VestID, ref n_VestDelete, ref n_VestAction, ref n_VestGrantDate, ref rowIndex, this, Path.GetFileNameWithoutExtension(Request.Path));
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row data bound for child grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void childGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            string s = hdnSelectedRow.Value;
            try
            {
                n_Action = 0;

                using (gvUserControlModel userControlModel = new gvUserControlModel())
                {
                    userControlModel.BindChildGridViewRows(this, e, ref n_VestIndex, ref n_VestID, ref n_VestDelete, ref n_VestAction, ref n_VestGrantDate, ref n_VestPercent, ref n_FairValVest, ref n_IntrsicValVest);
                }

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    GrantID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString();
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Data bound for parent grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_DataBound(object sender, EventArgs e)
        {
            try
            {
                using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal))
                {
                    using (TableHeaderCell cell = new TableHeaderCell())
                    {
                        cell.Text = "Grant(s)";
                        cell.ColumnSpan = 22;
                        row.Controls.Add(cell);
                        if (gv.HeaderRow != null)
                        {
                            gv.HeaderRow.Parent.Controls.AddAt(0, row);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Index change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (gvUserControlModel userControlModel = new gvUserControlModel())
                {
                    userControlModel.PageIndexChangingUnlocked(sender, e, gv, this, Path.GetFileNameWithoutExtension(Request.Path));
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

		#region Clear Filter
        /// <summary>
        /// This event is used to swtich between the pages of gv.
        /// </summary>
        /// <param name="sender">Clear Filter Button</param>
        /// <param name="e">e</param>
        protected void btn_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.btn_Click(this, sender);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Bind Locked records to grid-view
        /// <summary>
        /// Row Bound for Locked Records
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvLockedRecords_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (gvUserControlModel userControlModel = new gvUserControlModel())
                {
                    if (!string.IsNullOrEmpty(hdnVRReset.Value))
                    {
                        n_index = n_indexLockedRec = 0;
                        rowIndex = rowIndexLockedRec = 1;
                        hdnVRReset.Value = string.Empty;
                    }

                    userControlModel.BindRows(sender, this, e, ref n_indexLockedRec, ref n_IDLockedRec, ref n_DeleteLockedRec, ref n_ActionLockedRec, ref n_GrantDateLockedRec, ref n_FairValueLockedRec, ref n_IntrinsicValueLockedRec, ref n_DocumentDownload, ref n_DocumentName, ref n_DocumentPath, ref n_Status, ref n_Actions, ref n_AGRMID, Path.GetFileNameWithoutExtension(Request.Path), true, ref n_GrantIDLockedRec, ref n_GrpNum, ref n_IsMUFV, ref n_IsMUIV, ref n_ExerPrice, ref n_OptionsGranted_Locked, ref n_OptionsCancelled_Locked, ref n_VestedOptions_Locked, ref n_OutstandingOptions_Locked, ref n_EmployeeDetails_Locked, ref n_VestedCancelled_Locked, ref n_UnestedCancelled_Locked, ref n_Lapsed_Locked, ref n_Exercised_Locked, ref n_Unvested_Locked);

                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        if (!GrantID.Equals(System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString()))
                        {
                            GrantID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString();
                            userControlModel.AddChildGrid(sender, e, true, GrantID, ref n_VestIndexLockedRec, ref n_VestIDLockedRec, ref n_VestDeleteLockedRec, ref n_VestActionLockedRec, ref n_VestGrantDateLockedRec, ref rowIndexLockedRec, this, Path.GetFileNameWithoutExtension(Request.Path));
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Page index change for Locked Records
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvLockedRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (gvUserControlModel userControlModel = new gvUserControlModel())
                {
                    userControlModel.PageIndexChangingLocked(sender, e, gv, this, Path.GetFileNameWithoutExtension(Request.Path));
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row data bound for child grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void childGridLockedRec_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            string s = hdnSelectedRow.Value;

            try
            {
                n_Action = n_index = 0;

                using (gvUserControlModel userControlModel = new gvUserControlModel())
                {
                    userControlModel.BindChildGridViewRows(this, e, ref n_VestIndexLockedRec, ref n_VestIDLockedRec, ref n_VestDeleteLockedRec, ref n_VestActionLockedRec, ref n_VestGrantDateLockedRec, ref n_VestPercent, ref n_FairValVest, ref n_IntrsicValVest);
                }

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    GrantID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString();
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Data bound for Locked Records
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvLockedRecords_DataBound(object sender, EventArgs e)
        {
            try
            {
                using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal))
                {
                    using (TableHeaderCell cell = new TableHeaderCell())
                    {
                        cell.Text = "Locked Grant(s)";
                        cell.ColumnSpan = 25;
                        row.Controls.Add(cell);
                        if (gvLockedRecords.HeaderRow != null)
                        {
                            gvLockedRecords.HeaderRow.Parent.Controls.AddAt(0, row);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Bind calculations of IV and FV to grid-view
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void gv2_DataBound(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
                    {
                        TableCell cell = new TableCell();
                        cell.Text = o_gvUserControlModel.ac_SearchGrantDetails.s_FinalValue;
                        cell.ColumnSpan = 1;
                        cell.Font.Bold = true;
                        cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        cell.HorizontalAlign = HorizontalAlign.Left;
                        row.Controls.Add(cell);
                        cell = new TableCell();

                        cell.ColumnSpan = o_gvUserControlModel.ac_SearchGrantDetails.n_VestCount - 1;
                        cell.Font.Bold = true;
                        cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        cell.HorizontalAlign = HorizontalAlign.Right;
                        cell.Text = o_gvUserControlModel.ac_SearchGrantDetails.s_FairValue;
                        row.Controls.Add(cell);

                        gv2.HeaderRow.Parent.Controls.AddAt(o_gvUserControlModel.ac_SearchGrantDetails.n_RowCount + 3, row);
                        cell.Dispose();
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void gv2_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.gv2_RowDataBound(e, ref n_index, ref n_DatList, ref n_MarketValue);

                    switch (e.Row.RowType)
                    {
                        case DataControlRowType.Header:
                            e.Row.Cells[e.Row.Cells.Count - 1].Visible = false;
                            break;

                        case DataControlRowType.DataRow:
                            if (e.Row.RowIndex.Equals(0))
                            {
                                GridView parentGrid = (GridView)sender;

                                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                                {
                                    NewTotalRow.Font.Bold = true;
                                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                    using (TableCell HeaderCell = new TableCell())
                                    {
                                        HeaderCell.Attributes.Add("Class", "gvChildGrid");
                                        HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                        HeaderCell.Font.Bold = true;
                                        HeaderCell.Text = "Variables";
                                        HeaderCell.ColumnSpan = o_gvUserControlModel.ac_SearchGrantDetails.n_VestCount;
                                        HeaderCell.HorizontalAlign = HorizontalAlign.Left;
                                        NewTotalRow.Cells.Add(HeaderCell);
                                        parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1, NewTotalRow);
                                    }
                                }
                            }

                            for (int n_ColCnt = 1; n_ColCnt < e.Row.Cells.Count - 1; n_ColCnt++)
                            {
                                if (!e.Row.Cells[e.Row.Cells.Count - 1].Text.Equals("&nbsp;") && Convert.ToDecimal(e.Row.Cells[e.Row.Cells.Count - 1].Text).Equals(1))
                                {
                                    e.Row.Cells[n_ColCnt].ForeColor = Color.Green;
                                    e.Row.Cells[n_ColCnt].ToolTip = "Manually updated";
                                }
                                e.Row.Cells[e.Row.Cells.Count - 1].Visible = false;
                            }


                            switch (((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[0].ToString())
                            {
                                case "IS_MU_MKT_FV":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_MKT_IV":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_EXL":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_VOL":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_RFIR":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_DIVD":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_DIVD_MP_DIVD":
                                    e.Row.Visible = false;
                                    break;
                            }
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Bind Valuation Parameters
        /// <summary>
        /// Bind Valuation Parameters
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void gvValuationParameters_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (gvUserControlModel userControlModel = new gvUserControlModel())
                {
                    userControlModel.BindRowsValuationParam(this, e, ref n_CompanyLevel, ref n_GrantLevel, ref n_ValIndex, ref n_ManuallyUploaded);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Proceed to next step
        /// <summary>
        /// Proceed to next step
        /// </summary>
        /// <param name="sender">Procced Button</param>
        /// <param name="e">e</param>
        protected void btnVRProceed_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.SetWorkflowStatus(this);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Search/Filter Data
        /// <summary>
        /// This method is for binding search grid
        /// </summary>
        /// <param name="sender">Search Button</param>
        /// <param name="e">e</param>
        protected void btnGDSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
					n_index = 0; rowIndex = 1;

                    if (!Request.UrlReferrer.AbsolutePath.Contains("GrantDetails"))
                        hdnVRReset.Value = "Set";

                    int n_SearchResult = o_gvUserControlModel.btnGDSearch_Click(this, gv, gvLockedRecords, Path.GetFileNameWithoutExtension(Request.Path));

                    if (Request.UrlReferrer.AbsolutePath.Contains("GrantDetails"))
                    {
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { "btnGDSearch", n_SearchResult });
                    }
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Clear Filter
        /// <summary>
        /// This Method is used to Clear Filters
        /// </summary>
        /// <param name="sender">Clear Filter Button</param>
        /// <param name="e">e</param>
        protected void btnGDClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    n_index = 0; rowIndex = 1;

                    if (!Request.UrlReferrer.AbsolutePath.Contains("GrantDetails"))
                        hdnVRReset.Value = "Set";

                    o_gvUserControlModel.btnGDClearFilter_Click(this, gv, gvLockedRecords, Path.GetFileNameWithoutExtension(Request.Path));

                    if (Request.UrlReferrer.AbsolutePath.Contains("GrantDetails"))
                    {
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { "btnGDClearFilter", 1 });
                    }
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Delete Grant(s)
        /// <summary>
        /// This Method is used to delete Grant(s)
        /// </summary>
        /// <param name="sender">Delete Button of Grant Details Page</param>
        /// <param name="e">e</param>
        protected void btnGDDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    int n_RetValue = o_gvUserControlModel.btnGDDelete_Click(this);

                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { "btnGDDelete", n_RetValue });

                    BindGrid();
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Add Grant(s)
        /// <summary>
        /// This method is used for Add Grant Button Click Event
        /// </summary>
        /// <param name="sender">Add Grant Button</param>
        /// <param name="e">e</param>
        protected void btnGDAddGrant_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    using (Button btn = (Button)sender)
                    {
                        o_gvUserControlModel.btnGDAddGrant_Click(this);

                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { btn.ID.Equals("btnGDAddGrant") ? "btnGDAddGrant" : "btnAddOptionDetails", 0 });
                    }
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        /// <summary>
        /// This method is used to View Documents Uploaded
        /// </summary>
        /// <param name="sender">LinkButton ViewDocument</param>
        /// <param name="e">e</param>
        internal void LinkButtonViewDocument_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.LinkButtonViewDocument_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row DataBound Event of gvViewDocument GridView
        /// </summary>
        /// <param name="sender">gvViewDocument GridView</param>
        /// <param name="e">e</param>
        protected void gvViewDocument_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.gvViewDocument_RowDataBound(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to View Documents Uploaded
        /// </summary>
        /// <param name="sender">LinkButton ViewDocument</param>
        /// <param name="e">e</param>
        internal void lbtnEmployeeDetails_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.LinkButtonViewDocument_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method will check Adding / Editing Validation of Grant(s) against Locked Accounting Report 
        /// case 1:- if Accounting Report is Locked and user 
        ///          is trying to add a grant which Grant Date entered is before the Locked Reporting Date
        /// case 2:- if Report is locked and user is editing the 
        ///          grant which falls under Locked Accounting Report.
        /// Then the User is not allowed to add/edit the respective Grant
        /// </summary>
        /// <param name="s_GrantDate">string Grant Date</param>
        /// <param name="s_Action">string Action Add/Edit</param>
        /// <returns>int Count of Locked Reporting Date(s) Greater than Grant Date</returns>
        internal int CheckAgainstLockedAccountingReport(string s_GrantDate, string s_Action)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    return o_gvUserControlModel.CheckAgainstLockedAccountingReport(s_GrantDate, s_Action);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }

            return 0;
        }

        /// <summary>
        /// This method is used to apply selected view
        /// </summary>
        /// <param name="sender">btnSetDefault Button</param>
        /// <param name="e">e</param>
        protected void ddlDefaultView_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.LoadSelcted_View(this);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to set default view
        /// </summary>
        /// <param name="sender">btnSetDefault Button</param>
        /// <param name="e">e</param>
        protected void btnSetDefault_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    o_gvUserControlModel.SetDefaultView(this);
                }
            }
            catch (Exception Ex)
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", o_gvUserControlModel.userSessionInfo.ACC_CompanyName).Replace("*", o_gvUserControlModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

		/// <summary>
        /// The Row DataBound Event of gvViewDocument GridView
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void lnkPage_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    string pageIndex = (sender as LinkButton).CommandArgument;

                    o_gvUserControlModel.Page_IndexChangeing(this, pageIndex);
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString(Ex.Message + "\n" + Ex.StackTrace));
            }
        }

        /// <summary>
        /// This method is used to allow to next page for locked records
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void lnkPage_Locked_Click(object sender, EventArgs e)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    string pageIndex = (sender as LinkButton).CommandArgument;

                    o_gvUserControlModel.Page_IndexChangeing_Locked(this, pageIndex);
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString(Ex.Message + "\n" + Ex.StackTrace));
            }
        }
    }
}