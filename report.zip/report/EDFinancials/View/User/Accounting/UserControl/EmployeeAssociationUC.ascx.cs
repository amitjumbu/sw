﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting.UserControl
{
    /// <summary>
    /// EmployeeAssociationUC class
    /// </summary>
    public partial class EmployeeAssociationUC : System.Web.UI.UserControl
    {
        /// <summary>
        /// This veriables are used to set index
        /// </summary>
        public int n_UVPindex = 0, n_Currency = 0, n_ExPrc = 0, n_VestDet = 0, n_Ratio = 0, n_RowIndex = 1, n_AssociateEmployees = 0, n_GrantID = 0, n_VestCount = 0;

        /// <summary>
        /// RowBound of gvCurrentGrants GridView
        /// </summary>
        /// <param name="sender">The View DataEntered GridView</param>
        /// <param name="e">e</param>
        protected void gvCurrentGrants_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            using (EmployeeAssociationModel employeeAssociationModel = new EmployeeAssociationModel())
            {
                employeeAssociationModel.gvCurrentGrants_RowDataBound(this, sender, e, ref n_UVPindex, ref n_Currency, ref n_ExPrc, ref n_VestDet, ref n_Ratio, ref n_RowIndex, ref n_AssociateEmployees, ref n_GrantID, ref n_VestCount);
            }
        }

        /// <summary>
        /// Row Data Bound Event Of Child GridView
        /// </summary>
        /// <param name="sender">Child GridView</param>
        /// <param name="e">e</param>
        internal void childGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (EmployeeAssociationModel employeeAssociationModel = new EmployeeAssociationModel())
                {
                    employeeAssociationModel.childGrid_RowDataBound(sender, e);
                }
            }
            catch (Exception Ex)
            {
                using (EmployeeAssociationModel employeeAssociationModel = new EmployeeAssociationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", employeeAssociationModel.userSessionInfo.ACC_CompanyName).Replace("*", employeeAssociationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}