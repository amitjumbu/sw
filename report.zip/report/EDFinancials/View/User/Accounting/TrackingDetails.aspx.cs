﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Accounting;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Accounting
{
    /// <summary>
    /// Code file for Traking Details page.
    /// </summary>
    public partial class TrackingDetails : BasePage
    {
        int n_index = 0, n_ID = 0, n_Delete = 0, n_AtmID = 0;

        /// <summary>
        /// Page Load event for Traking Details Page.
        /// </summary>
        /// <param name="sender">sender Id</param>
        /// <param name="e">Event</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                    {
                        trackingDetailsModel.LoadInitialSettings(this);
                    }
                }
                ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch (Exception Ex)
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", trackingDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", trackingDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// this method is used to perform gridview row vise action
        /// </summary>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    trackingDetailsModel.BindRows(e, ref n_index, ref n_ID, ref n_Delete, ref n_AtmID);
                }
            }
            catch (Exception Ex)
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", trackingDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", trackingDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD  IS USED  FOR CHANGING GRIDVIEW PAGE NUMBER
        /// </summary>
        /// <param name="sender">Sender Id</param>
        /// <param name="e">Event</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    trackingDetailsModel.PageIndexChanging(sender, e, gv, hdnDeletedRecords.Value);
                }
            }
            catch (Exception Ex)
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", trackingDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", trackingDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD LOADS GRID VIEW DATA.
        /// </summary>
        public void loadMasterGrid()
        {
            try
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    trackingDetailsModel.LoadGridData(this);
                }
            }
            catch (Exception Ex)
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", trackingDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", trackingDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD FILTERS DATA FROM GRID VIEW ACCORDING TO FILTER TRAKING DETAILS NAME AND ITS STATUS.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event</param>
        protected void BtnTD_Search_Click(object sender, EventArgs e)
        {
            try
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    trackingDetailsModel.FilterGridData(this);
                }
            }
            catch (Exception Ex)
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", trackingDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", trackingDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is Delete button click event .
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event e</param>
        protected void btnTD_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    if (!trackingDetailsModel.PerformCUD(this, hdnDeletedRecords.Value.TrimStart(',')))
                        loadMasterGrid();
                }
            }
            catch (Exception Ex)
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", trackingDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", trackingDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This submit Button click event.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event</param>
        protected void btnTD_Submit_Click(object sender, EventArgs e)
        {
            try
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    trackingDetailsModel.PerformCUD(this, hdnEditMmId.Value.TrimStart(','));
                    loadMasterGrid();
                }
            }
            catch (Exception Ex)
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", trackingDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", trackingDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is ddTDSearch_TrackingType index change event to filter grid data based on selection.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event</param>
        protected void ddTDSearch_TrackingType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    trackingDetailsModel.FilterGridData(this);
                }
            }
            catch (Exception Ex)
            {
                using (TrackingDetailsModel trackingDetailsModel = new TrackingDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", trackingDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", trackingDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}