﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User
{
    /// <summary>
    /// This is code bend class for Home page.
    /// </summary>
    public partial class Home : BasePage
    {
        /// <summary>
        /// Page load event for Home page.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">EventArgs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            if (Session["IsLoginSucceed"] == null)
            {
                Response.Redirect("~/View/Login.aspx", false);
            }
        }
    }
}