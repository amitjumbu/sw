﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Web;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// This is ReportParameters page's back code file.
    /// </summary>
    public partial class ReportParameters : BasePage
    {
        /// <summary>
        /// 
        /// </summary>
        public string s_PgName = CommonConstantModel.s_ReportParamaters;

        /// <summary>
        /// This is ReportParameters page's load event.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">This is event Arguement object</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/View/User/Valuation/ValuationParameters.aspx?PgName=" + s_PgName + "");
            }
            catch (SystemException)
            {
                // Do Nothing
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}