﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation
{

    /// <summary>
    /// This is code behind class for MarketPriceSetup page .
    /// </summary>
    public partial class MarketPriceSetup : BasePage
    {
        #region Page Load

        /// <summary>
        /// The Page Load
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (MarketPriceSetupModel marketPriceSetupModel = new MarketPriceSetupModel())
                    {
                        marketPriceSetupModel.BindUI(this);
                        marketPriceSetupModel.EncryptData(this);
                        marketPriceSetupModel.ShowHideBtnViewMPForUnlisted(this);
                        if (Convert.ToString(Session["Tab3GrantD"]).Equals("Set"))
                        {
                            marketPriceSetupModel.ShowHideBacktoGDBtn(this, true);
                        }
                        else marketPriceSetupModel.ShowHideBacktoGDBtn(this, false);
                        // Start of Back button for PeerCompany setup page 
                        if (!(Session["NavigatePeerToMktPrice"] == null))
                        {
                            marketPriceSetupModel.ShowHideBacktoPeerBtn(this, true);
                        }
                        else marketPriceSetupModel.ShowHideBacktoPeerBtn(this, false);
                        // End of  Back button for PeerCompany setup page
                    }
                }
            }
            catch (Exception Ex)
            {
                using (MarketPriceSetupModel marketPriceSetupModel = new MarketPriceSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", marketPriceSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", marketPriceSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        /// <summary>
        /// This method is used to return back from Market Price Setup page to Grant Details
        /// </summary>
        /// <param name="sender">Back To Grant Details Button</param>
        /// <param name="e">e</param>
        protected void btnBackToGD_Click(object sender, EventArgs e)
        {
            string s_AGRMID = Convert.ToString(Session["AGRMID"]);
            if (Convert.ToString(Session["PageNameGrantDetails"]).Equals("/View/User/Accounting/GrantDetails.aspx"))
            {
                Response.Redirect("../Accounting/GrantDetails.aspx?s_AGRMID=" + s_AGRMID, false);
            }
            else
            {
                Response.Redirect("GrantDetails.aspx?s_AGRMID=" + s_AGRMID, false);
            }
        }

        /// <summary>
        /// This button click of btnBackToPeer_Click that navigates back to peerCompany Setup page.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void btnBackToPeer_Click(object sender, EventArgs e)
        {
            Session.Remove("NavigatePeerToMktPrice");
            Response.Redirect("PeerCompanySetup.aspx", false);
        }
    }
}