﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using EDFinancials.View;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.UserControl.User.Valuation
{
    /// <summary>
    /// Market Price user control code behind class
    /// </summary>
    public partial class MarketPriceUC : BaseUC
    {
        #region Variables

        /// <summary>
        /// Variables declaration
        /// </summary>
        int n_Index_IV = 0, n_Stock_Exchange_IV = 0, n_SHORT_NAME_IV = 0, n_Date_of_Market_Price_IV = 0, n_Remark_IV = 0, n_Applicable_From_Date_IV = 0, n_To_Date_IV = 0, n_AMPCID_IV = 0, n_Approval_Status_IV = 0, n_View_History_Data_IV = 0,
            n_Index_FV = 0, n_Stock_Exchange_FV = 0, n_SHORT_NAME_FV = 0, n_Date_of_Market_Price_FV = 0, n_Remark_FV = 0, n_Applicable_From_Date_FV = 0, n_To_Date_FV = 0, n_AMPCID_FV = 0, n_Approval_Status_FV = 0, n_View_History_Data_FV = 0;

        #endregion

        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    if ((!(String.IsNullOrEmpty(Request.QueryString["PgName"]))) && (Convert.ToString(Request.QueryString["PgName"]).ToUpper().Equals("REPORTPARAMETERS")))
                    {
                        InitialSettings();

                        using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                        {
                            reportParametersModel.Get_SavedParameterText("GET_PARAMETER_TEXT");
                            reportParametersModel.Bind_ParameterText_ToControls(this, "MarketPrice");
                            reportParametersModel.Load_SequenceDropdown(ddIVStockExtext_Rank, "GET_MPTEXT_SEQUENCE");
                            reportParametersModel.Load_SequenceDropdown(ddIVMarketPriceDate_Rank, "GET_MPTEXT_SEQUENCE");
                            reportParametersModel.Load_SequenceDropdown(ddFVStockExtext_Rank, "GET_MPTEXT_SEQUENCE");
                            reportParametersModel.Load_SequenceDropdown(ddFVMarketPriceDate_Rank, "GET_MPTEXT_SEQUENCE");
                            reportParametersModel.Bind_Default_Sequence(this, "MarketPrice");
                            reportParametersModel.Show_Parameter_text_Columns(this, "MarketPrice", true);
                            reportParametersModel.BindPageUI(this, "MarketPrice");
                            reportParametersModel.CheckEmployeeRolePriviledges(this, "MarketPrice");
                        }
                    }
                }
                ctrPreview_MPIV.b_IsVisible = false;
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events

        /// <summary>
        /// IV config save button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnVPSSaveIV_Click(object sender, EventArgs e)
        {
            try
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {                    
                    int n_RetValue = marketPriceUCModel.UpdateMarketPriceConfigData(this, "MPC_IV");
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "lblVPSSaveMessage", "MPC_IV", n_RetValue });
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "MPC_IV" });
                    if (n_RetValue.Equals(1) && marketPriceUCModel.userSessionInfo.ACC_UerTypeID.Equals(3))
                    {
                        using (VPSCommonModel vPSCommonModel = new VPSCommonModel())
                        {
                            vPSCommonModel.SendMailForApproval("Market Price - IV");
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", marketPriceUCModel.userSessionInfo.ACC_CompanyName).Replace("*", marketPriceUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// FV config save button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnVPSSaveFV_Click(object sender, EventArgs e)
        {                            
            try
            {
                               
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {                    
                    int n_RetValue = marketPriceUCModel.UpdateMarketPriceConfigData(this, "MPC_FV");
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "lblVPSSaveMessage", "MPC_FV", n_RetValue });
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "MPC_FV" });
                    if (n_RetValue.Equals(1) && marketPriceUCModel.userSessionInfo.ACC_UerTypeID.Equals(3))
                    {
                        using (VPSCommonModel vPSCommonModel = new VPSCommonModel())
                        {
                            vPSCommonModel.SendMailForApproval("Market Price - FV");
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", marketPriceUCModel.userSessionInfo.ACC_CompanyName).Replace("*", marketPriceUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
            
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvMarketPriceIV_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {
                    marketPriceUCModel.RowDataBindForGVMPIV(e, ref n_Index_IV, ref n_Stock_Exchange_IV, ref n_SHORT_NAME_IV, ref n_Date_of_Market_Price_IV, ref n_Remark_IV,
                        ref n_Applicable_From_Date_IV, ref n_To_Date_IV, ref n_AMPCID_IV, ref n_Approval_Status_IV, ref n_View_History_Data_IV);
                }
            }
            catch (Exception Ex)
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", marketPriceUCModel.userSessionInfo.ACC_CompanyName).Replace("*", marketPriceUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvMarketPriceIV_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {
                    marketPriceUCModel.PageIndexChangingForGVMPIV(e.NewPageIndex, this);
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "MPC_IV" });
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "MPC_IV", 0 });
                }
            }
            catch (Exception Ex)
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", marketPriceUCModel.userSessionInfo.ACC_CompanyName).Replace("*", marketPriceUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvMarketPriceFV_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {
                    marketPriceUCModel.RowDataBindForGVMPFV(e, ref n_Index_FV, ref n_Stock_Exchange_FV, ref n_SHORT_NAME_FV, ref n_Date_of_Market_Price_FV, ref n_Remark_FV,
                        ref n_Applicable_From_Date_FV, ref n_To_Date_FV, ref n_AMPCID_FV, ref n_Approval_Status_FV, ref n_View_History_Data_FV);
                }
            }
            catch (Exception Ex)
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", marketPriceUCModel.userSessionInfo.ACC_CompanyName).Replace("*", marketPriceUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvMarketPriceFV_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {
                    marketPriceUCModel.PageIndexChangingForGVMPFV(e.NewPageIndex, this);
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "MPC_FV" });
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "MPC_FV", 0 });
                }
            }
            catch (Exception Ex)
            {
                using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", marketPriceUCModel.userSessionInfo.ACC_CompanyName).Replace("*", marketPriceUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
        
        #region Report Parameters

        /// <summary>
        /// This is the inintial settings required for report parameters page.
        /// </summary>
        public void InitialSettings()
        {
            try
            {
                lblIVSE01.AutoPostBack = true;
                lblIVSE02.AutoPostBack = true;
                lblIVDMP01.AutoPostBack = true;
                lblIVDMP02.AutoPostBack = true;
                ddlIVStockExchange.AutoPostBack = true;
                lblFVSE01.AutoPostBack = true;
                lblFVSE02.AutoPostBack = true;
                lblFVDMP01.AutoPostBack = true;
                lblFVDMP02.AutoPostBack = true;
                ddlFVStockExchange.AutoPostBack = true;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// FV config save text button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnMPParameterTextSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    string s_OutputMessage = reportParametersModel.PerformCUD_marketPriceIV(this);
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, s_OutputMessage, "MPC_IV", 1 });
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// FV config save text button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnMPFVText_Click(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    string s_OutputMessage = reportParametersModel.PerformCUD_marketPriceFV(this);

                    using (VolatilityUCModel volatilityUCModel = new VolatilityUCModel())
                    {
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, s_OutputMessage, "MPC_FV", 1 });
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is the click event for Market price IV preview button.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void btnMPIVPreview_Click(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.GetPriview_MPIV(this, "Market_Price_IV");
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblIVSE01.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblIVSE01_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, ddlIVStockExchange.SelectedValue, txtIVStockExchangeType);
                    reportParametersModel.ShowHideIVFVAccordion("IV", this);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblIVSE02.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblIVSE02_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtIVStockExchangeType);
                    reportParametersModel.ShowHideIVFVAccordion("IV", this);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblIVDMP01.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblIVDMP01_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtIVDateOfMarketPriceText);
                    reportParametersModel.ShowHideIVFVAccordion("IV", this);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblIVDMP02.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblIVDMP02_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtIVDateOfMarketPriceText);
                    reportParametersModel.ShowHideIVFVAccordion("IV", this);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for ddlIVStockExchange.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void ddlIVStockExchange_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lblIVSE01.Checked)
            {
                try
                {
                    using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                    {
                        reportParametersModel.changeTextOnRadioSelection("lblIVSE01", ddlIVStockExchange.SelectedValue, txtIVStockExchangeType);
                        reportParametersModel.ShowHideIVFVAccordion("IV", this);
                    }
                }
                catch (Exception Ex)
                {
                    using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }
        }

        /// <summary>
        /// This is checked event for lblFVSE01.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblFVSE01_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, ddlFVStockExchange.SelectedValue, txtFVStockExchangeTypeText);
                    reportParametersModel.ShowHideIVFVAccordion("FV", this);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblFVSE02.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblFVSE02_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtFVStockExchangeTypeText);
                    reportParametersModel.ShowHideIVFVAccordion("FV", this);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblFVDMP01.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblFVDMP01_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtFVDateOfMarketPriceText);
                    reportParametersModel.ShowHideIVFVAccordion("FV", this);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblFVDMP02.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblFVDMP02_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtFVDateOfMarketPriceText);
                    reportParametersModel.ShowHideIVFVAccordion("FV", this);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is index changed event for ddlFVStockExchange.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void ddlFVStockExchange_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lblFVSE01.Checked)
            {
                try
                {
                    using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                    {
                        reportParametersModel.changeTextOnRadioSelection("lblFVSE01", ddlFVStockExchange.SelectedValue, txtFVStockExchangeTypeText);
                        reportParametersModel.ShowHideIVFVAccordion("FV", this);
                    }
                }
                catch (Exception Ex)
                {
                    using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }
        }

        /// <summary>
        /// This is the click event for MArket price FV preview button.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void btnMPFVPreview_Click(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.GetPriview_MPIV(this, "Market_Price_FV");
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}

