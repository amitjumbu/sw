﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation.UserControl
{
    /// <summary>
    /// Final Report User Control
    /// </summary>
    public partial class FinalReportUC : BaseUC
    {
        /// <summary>
        /// 
        /// </summary>
        public string s_QueryStringParams = null;
        int n_index, n_Action = 0, n_Group_ID = 0;
        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    if (!Page.IsPostBack)
                    {
                        finalReportUCModel.ReadL10N_UI(this);
                        finalReportUCModel.BindStatus(this);
                    }
                    finalReportUCModel.HideTR(this);
                    s_QueryStringParams = finalReportUCModel.ac_ValuationReport.s_QueryStringParams;
                    Page.Form.Attributes.Add("enctype", "multipart/form-data");
                    if (!string.IsNullOrEmpty(hdnGroupNo.Value))
                    {
                        finalReportUCModel.BindGrid(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", finalReportUCModel.userSessionInfo.ACC_CompanyName).Replace("*", finalReportUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Download report
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnDownloadReport_Click(object sender, EventArgs e)
        {
            try
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    finalReportUCModel.Download_Report(this);
                }
            }
            catch (Exception Ex)
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", finalReportUCModel.userSessionInfo.ACC_CompanyName).Replace("*", finalReportUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Save final report
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    finalReportUCModel.SaveContinue(this, "Create");
                }
            }
            catch (Exception Ex)
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", finalReportUCModel.userSessionInfo.ACC_CompanyName).Replace("*", finalReportUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Upload document
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            try
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    finalReportUCModel.UploadFile(this);
                }
            }
            catch (Exception Ex)
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", finalReportUCModel.userSessionInfo.ACC_CompanyName).Replace("*", finalReportUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button is used to download uploaded report
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnDownloadUplDoc_Click(object sender, EventArgs e)
        {
            try
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    finalReportUCModel.DownloadUploadedFile(this, "DocDownload", string.Empty);
                }
            }
            catch (Exception Ex)
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", finalReportUCModel.userSessionInfo.ACC_CompanyName).Replace("*", finalReportUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button is used to download previous version document
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        public void lbtnDownload_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    ImageButton lbtn = (ImageButton)sender;
                    finalReportUCModel.DownloadUploadedFile(this, "VersionDoc", lbtn.ID);
                }
            }
            catch (Exception Ex)
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", finalReportUCModel.userSessionInfo.ACC_CompanyName).Replace("*", finalReportUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAgree_Click(object sender, EventArgs e)
        {
            try
            {
                System.Web.UI.WebControls.Button button = (System.Web.UI.WebControls.Button)sender;

                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    switch (button.ID)
                    {
                        case "btnSendToClient":
                            finalReportUCModel.Save_FinalTemplate(this, "btnSendToClient");
                            break;

                        case "btnAgree":
                            finalReportUCModel.Save_FinalTemplate(this, "btnAgree");
                            break;

                        case "btnDisagree":
                            Response.Redirect("ValuationReport.aspx", false);
                            break;
                    }
                }
            }
            catch (Exception Ex)
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", finalReportUCModel.userSessionInfo.ACC_CompanyName).Replace("*", finalReportUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row bound parent grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvVersionDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    string s_controlID = string.Empty;
                    finalReportUCModel.BindGrid(this, e, ref n_index, ref n_Action, ref n_Group_ID, out s_controlID);

                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        ImageButton imageButton = (ImageButton)e.Row.FindControl(s_controlID);
                        ScriptManager sm = (ScriptManager)Page.Master.FindControl("scriptManager");
                        sm.RegisterPostBackControl(imageButton);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", finalReportUCModel.userSessionInfo.ACC_CompanyName).Replace("*", finalReportUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Unlock grants
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUnlockGrants_Click(object sender, EventArgs e)
        {
            try
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    finalReportUCModel.UnlockGrants(this);
                    Response.Redirect("ValuationReport.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                using (FinalReportUCModel finalReportUCModel = new FinalReportUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", finalReportUCModel.userSessionInfo.ACC_CompanyName).Replace("*", finalReportUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}