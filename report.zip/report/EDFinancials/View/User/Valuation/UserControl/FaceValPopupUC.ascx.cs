﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation.UserControl
{
    /// <summary>
    /// Face Value popup window page code behind class
    /// </summary>
    public partial class FaceValPopupUC : BaseUC
    {
        #region Page Load event

        /// <summary>
        /// Page Load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            // Do Nothing
        }

        #endregion

        #region Control Events

        /// <summary>
        /// Button click event to update company details
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnCIFaceValSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    int a_result = companyInfoPopupModel.UpdateFaceValue(this, "FACE_VALUE", "");

                    this.Page.GetType().InvokeMember("ShowMsgDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { a_result });
                    this.Page.GetType().InvokeMember("ReBindAllGrids", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInfoPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInfoPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to delete face value 
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnCIFaceValDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    int a_result = companyInfoPopupModel.UpdateFaceValue(this, "FACE_VALUE", "D");
                    this.Page.GetType().InvokeMember("ShowMsgDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { a_result });
                    this.Page.GetType().InvokeMember("ReBindAllGrids", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInfoPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInfoPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvCIFaceValueHistory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    companyInfoPopupModel.RowDataBindCIFaceValHistory(e);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInfoPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInfoPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvCIFaceValueHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    companyInfoPopupModel.gvCIFaceValuePageIndexChang(this, e.NewPageIndex);

                    this.Page.GetType().InvokeMember("ShowMsgDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { 8 });
                    this.Page.GetType().InvokeMember("BindAllGrids", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInfoPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInfoPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">grid view row wvent args</param>
        protected void gvCIFaceValueCurrent_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    companyInfoPopupModel.RowDataBindCIFaceVal(e);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInfoPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInfoPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvCIFaceValueCurrent_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    companyInfoPopupModel.gvCIFaceValueCurrentPageIndexChang(this, e.NewPageIndex);

                    this.Page.GetType().InvokeMember("ShowMsgDiv", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { 0 });
                    this.Page.GetType().InvokeMember("BindAllGrids", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { });
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInfoPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInfoPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}