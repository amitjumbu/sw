﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using EDFinancials.View;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.UserControl.User.Valuation
{
    /// <summary>
    /// Dividend user control code behind class
    /// </summary>
    public partial class DividendUC : BaseUC
    {
        /// <summary>
        /// Variable declaration
        /// </summary>
        int n_Index = 0, n_DIVIDEND_LABEL_ID = 0, n_NO_OF_YEARS = 0, n_MP_TO_CAL_DIVIDEND_LABEL_ID = 0, n_SHORT_NAME = 0, n_SPECIAL_DIVIDEND = 0, n_REMARK = 0, n_APPLICABLE_FROM_DATE = 0, n_TO_DATE = 0, n_ADCID = 0, n_ApprovalStatus = 0,
            n_ViewHistoryData = 0, n_SEID = 0, n_ADCAID = 0, n_Inc_Index = 0, n_Inc_ADCID = 0, n_Inc_From_Date = 0, n_Inc_To_Date = 0, n_Inc_Dividend = 0;

        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    if ((!(String.IsNullOrEmpty(Request.QueryString["PgName"]))) && (Convert.ToString(Request.QueryString["PgName"]).ToUpper().Equals("REPORTPARAMETERS")))
                    {
                        InitialSettings();

                        using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                        {
                            reportParametersModel.Bind_ParameterText_ToControls(this, "Dividend");
                            reportParametersModel.Load_SequenceDropdown(ddDivToBeConsidered_Rank, "GET_DIVIDEND_TEXT_SEQUENCE");
                            reportParametersModel.Load_SequenceDropdown(ddSpecialDiv_Rank, "GET_DIVIDEND_TEXT_SEQUENCE");
                            reportParametersModel.Load_SequenceDropdown(ddMPDivCal_Rank, "GET_DIVIDEND_TEXT_SEQUENCE");
                            reportParametersModel.Bind_Default_Sequence(this, "Dividend");
                            reportParametersModel.BindPageUI(this, "Dividend");
                            reportParametersModel.Show_Parameter_text_Columns(this, "Dividend", true);
                            reportParametersModel.CheckEmployeeRolePriviledges(this, "Dividend");

                        }
                    }
                }
                ctrPreview_DC.b_IsVisible = false;
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events

        /// <summary>
        /// Dividend save button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnDividendSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {                    
                    int n_RetValue = dividendUCModel.UpdateDividendConfigData(this, "DC");
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "lblVPSSaveMessage", "DC", n_RetValue });
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "DC" });
                    if (n_RetValue.Equals(1) && dividendUCModel.userSessionInfo.ACC_UerTypeID.Equals(3))
                    {
                        using (VPSCommonModel vPSCommonModel = new VPSCommonModel())
                        {
                            vPSCommonModel.SendMailForApproval("Dividend");
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendUCModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvDividend_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    dividendUCModel.RowDataBindForGVDividend(e, ref n_Index, ref n_DIVIDEND_LABEL_ID, ref n_NO_OF_YEARS, ref n_MP_TO_CAL_DIVIDEND_LABEL_ID, ref n_SHORT_NAME, ref n_SPECIAL_DIVIDEND, ref n_REMARK, ref n_APPLICABLE_FROM_DATE, ref n_TO_DATE, ref n_ADCID, ref n_ApprovalStatus, ref n_ViewHistoryData, ref n_SEID, ref n_ADCAID);
                }
            }
            catch (Exception Ex)
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendUCModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvDividend_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    dividendUCModel.PageIndexChangingForGVDividend(e.NewPageIndex, this);
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "DC" });
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "DC", 0 });
                }
            }
            catch (Exception Ex)
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendUCModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// IncorpDividend button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnVPSIncorpDividend_Click(object sender, EventArgs e)
        {
            try
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    int n_RetVal = dividendUCModel.BindIncorpDivToGrid(this);
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "IncorpDividend" });
                    if (n_RetVal.Equals(2))
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "lblVPSRecAlreadyExists", "DC", 1 });
                    else if (n_RetVal.Equals(3))
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "lblVPSEnterValidFromDate", "DC", 1 });
                    else if (n_RetVal.Equals(4))
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "lblVPSEnterValidToDate", "DC", 1 });
                    else if (n_RetVal.Equals(5))
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "lblVPSEnterValidFromToDate", "DC", 1 });
                    else this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "lblVPSIncorpSaveMessage", "DC", 1 });
                }
            }
            catch (Exception Ex)
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendUCModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvVPSIncorpDividend_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    dividendUCModel.PageIndexChangingForGVEncorpDiv(e.NewPageIndex, this);
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "" });
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "DC", 0 });
                }
            }
            catch (Exception Ex)
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendUCModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvVPSIncorpDividend_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    dividendUCModel.RowDataBindForGVIncorpDividend(e, ref n_Inc_Index, ref n_Inc_ADCID, ref n_Inc_From_Date, ref n_Inc_To_Date, ref n_Inc_Dividend);
                }
            }
            catch (Exception Ex)
            {
                using (DividendUCModel dividendUCModel = new DividendUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendUCModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Report Parameters
        /// <summary>
        /// This is initial settings required to set for report paprameters page.
        /// </summary>
        public void InitialSettings()
        {
            try
            {
                lblDIV01.AutoPostBack = true;
                lblDIV02.AutoPostBack = true;
                lblDIV03.AutoPostBack = true;
                lblDIV04.AutoPostBack = true;
                chkVPSSpecialDividend.AutoPostBack = true;
                lblMPTCD01.AutoPostBack = true;
                lblMPTCD02.AutoPostBack = true;
                ddlVPSStockExchge_DC.AutoPostBack = true;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This is button click for Dividend text save .
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDividendSave_Text_Click(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    string s_OutputMessage = reportParametersModel.PerformCUD_Dividend(this);

                    using (VolatilityUCModel volatilityUCModel = new VolatilityUCModel())
                    {
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, s_OutputMessage, "DC", 6 });
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblDIV01.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblDIV01_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtDividendConsideredText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblDIV02.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblDIV02_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtDividendConsideredText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblDIV03.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblDIV03_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtDividendConsideredText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblDIV04.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblDIV04_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtDividendConsideredText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for chkVPSSpecialDivident.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void chkVPSSpecialDivident_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((CheckBox)sender).ID, Convert.ToString(Convert.ToInt16(((CheckBox)sender).Checked)), txtSpecialDividendText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblMPTCD01.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblMPTCD01_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, "0", txtDividendYeildText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblMPTCD02.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblMPTCD02_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection(((RadioButton)sender).ID, ddlVPSStockExchge_DC.SelectedValue, txtDividendYeildText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is index changed event for ddlVPSStockExchge.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void ddlVPSStockExchge_DC_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lblMPTCD02.Checked)
            {
                try
                {
                    using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                    {
                        reportParametersModel.changeTextOnRadioSelection("lblMPTCD02", ddlVPSStockExchge_DC.SelectedValue, txtDividendYeildText);
                    }
                }
                catch (Exception Ex)
                {
                    using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                    {
                        CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                    }
                }
            }
        }

        /// <summary>
        /// This is click event for preview button on dividend page.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDividendPreview_Click(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.GetPriview_MPIV(this, "Dividend");
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}