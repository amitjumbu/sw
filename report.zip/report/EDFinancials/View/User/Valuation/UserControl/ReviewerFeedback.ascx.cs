﻿using EDFinancials.Model.User.Valuation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation.UserControl
{
    /// <summary>
    /// Reviewer Feedback user control
    /// </summary>
    public partial class ReviewerFeedback : BaseUC
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            using (ReviewerFeedbackModelUC reviewerFeedbackModelUC = new ReviewerFeedbackModelUC())
            {
                if (!Page.IsPostBack)
                {
                    reviewerFeedbackModelUC.ReadL10N_UI(this);
                    reviewerFeedbackModelUC.BindStatus(this);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSaveContinue_Click(object sender, EventArgs e)
        {
            using (ReviewerFeedbackModelUC reviewerFeedbackModelUC = new ReviewerFeedbackModelUC())
            {
                reviewerFeedbackModelUC.SaveContinue(this, "Create");
            }
        }
    }
}