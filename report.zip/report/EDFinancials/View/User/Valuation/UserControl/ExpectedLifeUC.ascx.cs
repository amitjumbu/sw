﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using EDFinancials.View;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.UserControl.User.Valuation
{
    /// <summary>
    /// Expected Life user control code behind class
    /// </summary>
    public partial class ExpectedLifeUC : BaseUC
    {
        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    if ((!(String.IsNullOrEmpty(Request.QueryString["PgName"]))) && (Convert.ToString(Request.QueryString["PgName"]).ToUpper().Equals("REPORTPARAMETERS")))
                    {
                        InitialSettings();

                        using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                        {
                            reportParametersModel.Show_Parameter_text_Columns(this, "ExpectedLife", true);
                            reportParametersModel.Bind_ParameterText_ToControls(this, "ExpectedLife");
                            reportParametersModel.BindPageUI(this, "ExpectedLife");
                            reportParametersModel.CheckEmployeeRolePriviledges(this, "ExpectedLife");
                        }
                    }
                }
                ctrPreview_EL.b_IsVisible = false;
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events

        /// <summary>
        /// Save button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnVPSExpectedLifeSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {                    
                    string s_PastExerciseFolderPath = Server.MapPath("../../Uploads/" + expectedLifeUCModel.userSessionInfo.ACC_CompanyName + "/ExpectedLife/PastExerciseFiles/");
                    string s_SpecifiedPeriodFolderPath = Server.MapPath("../../Uploads/" + expectedLifeUCModel.userSessionInfo.ACC_CompanyName + "/ExpectedLife/SpecifiedPeriodFiles/");

                    int n_RetValue = expectedLifeUCModel.UpdateExpectedLifeConfigData(this, "ELC", s_PastExerciseFolderPath, s_SpecifiedPeriodFolderPath);
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "lblVPSSaveMessage", "ELC", n_RetValue });
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "ELC" });
                    if (n_RetValue.Equals(1) && expectedLifeUCModel.userSessionInfo.ACC_UerTypeID.Equals(3))
                    {
                        using (VPSCommonModel vPSCommonModel = new VPSCommonModel())
                        {
                            vPSCommonModel.SendMailForApproval("Expected Life");
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", expectedLifeUCModel.userSessionInfo.ACC_CompanyName).Replace("*", expectedLifeUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvExpectedLife_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    expectedLifeUCModel.RowDataBindForGVEL(e);
                }
            }
            catch (Exception Ex)
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", expectedLifeUCModel.userSessionInfo.ACC_CompanyName).Replace("*", expectedLifeUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvExpectedLife_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    expectedLifeUCModel.PageIndexChangingForGVEL(e.NewPageIndex, this);
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "ELC" });
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "ELC", 0 });
                }
            }
            catch (Exception Ex)
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", expectedLifeUCModel.userSessionInfo.ACC_CompanyName).Replace("*", expectedLifeUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// file download button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnVPSESFileDownload_Click(object sender, EventArgs e)
        {
            try
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    expectedLifeUCModel.DownloadFile(this);
                }
            }
            catch (Exception Ex)
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", expectedLifeUCModel.userSessionInfo.ACC_CompanyName).Replace("*", expectedLifeUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Gridview row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvVPSCurrEstDtOfListing_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    expectedLifeUCModel.gvVPSCurrEstDtOfListing_RowDataBound(e);
                }
            }
            catch (Exception Ex)
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", expectedLifeUCModel.userSessionInfo.ACC_CompanyName).Replace("*", expectedLifeUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear the file content
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnClearFileSpecPrdFromVD_Click(object sender, EventArgs e)
        {
            try
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    expectedLifeUCModel.ClearFileContent(fielUpVPSELSpecPrdFromVD);
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "ELC" });
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "ELC", 0 });
                }
            }
            catch (Exception Ex)
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", expectedLifeUCModel.userSessionInfo.ACC_CompanyName).Replace("*", expectedLifeUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to clear the file content
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnClearFilePastExerBehavior_Click(object sender, EventArgs e)
        {
            try
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    expectedLifeUCModel.ClearFileContent(fileUpVPSELPastExerBehavior);
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "ELC" });
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "ELC", 0 });
                }
            }
            catch (Exception Ex)
            {
                using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", expectedLifeUCModel.userSessionInfo.ACC_CompanyName).Replace("*", expectedLifeUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Report parameters
        /// <summary>
        /// This is the inintial settings required for report parameters page.
        /// </summary>
        public void InitialSettings()
        {
            try
            {
                lblMCEL01.AutoPostBack = true;
                rdoELPastExerBehaviorYrs.AutoPostBack = true;
                rdoELPastExerBehaviorMnts.AutoPostBack = true;
                rdoELPastExerBehaviorDays.AutoPostBack = true;
                rdoExpLifeYears.AutoPostBack = true;
                rdoExpLifeMonths.AutoPostBack = true;
                rdoExpLifeDays.AutoPostBack = true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Click event for Parameter text save button of Expected life
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnExpectedLifeSave_Text_Click(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    string s_OutputMessage = reportParametersModel.PerformCUD_ExpectedLife(this);

                    using (VolatilityUCModel volatilityUCModel = new VolatilityUCModel())
                    {
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, s_OutputMessage, "ELC", 1 });
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for lblMCEL01.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void lblMCEL01_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection("lblMCEL01", "0", txtExpectedLifeMethodText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for rdoELPastExerBehaviorYrs.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void rdoELPastExerBehaviorYrs_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection("lblMCEL02", "Y", txtExpectedLifeMethodText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for rdoELPastExerBehaviorMnts.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void rdoELPastExerBehaviorMnts_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection("lblMCEL02", "M", txtExpectedLifeMethodText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for  rdoELPastExerBehaviorDays.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void rdoELPastExerBehaviorDays_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection("lblMCEL02", "D", txtExpectedLifeMethodText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for rdoExpLifeYears.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void rdoExpLifeYears_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection("lblMCEL03", "Y", txtExpectedLifeMethodText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for rdoExpLifeMonths.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void rdoExpLifeMonths_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection("lblMCEL03", "M", txtExpectedLifeMethodText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is checked event for rdoExpLifeDays.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">e</param>
        protected void rdoExpLifeDays_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.changeTextOnRadioSelection("lblMCEL03", "D", txtExpectedLifeMethodText);
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is click event of Expected life preview.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExpLifePreview_Click(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.GetPriview_MPIV(this, "Expected_Life");
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}