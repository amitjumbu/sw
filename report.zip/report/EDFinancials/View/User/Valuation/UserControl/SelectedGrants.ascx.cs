﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation.UserControl
{
    /// <summary>
    /// 
    /// </summary>
    public partial class SelectedGrants : BaseUC
    {
        int n_index = 0, n_Action = 0, n_ExerPrice = 0, n_IntrinsicValue = 0, n_FairVal = 0;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {

        }


        /// <summary>
        /// Data bound for parent grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_DataBound(object sender, EventArgs e)
        {
            try
            {
                using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal))
                {
                    using (TableHeaderCell cell = new TableHeaderCell())
                    {
                        cell.Text = "Selected Grant(s)";
                        cell.ColumnSpan = 11;
                        row.Controls.Add(cell);
                        if (gvSelectedGrants.HeaderRow != null)
                        {
                            gvSelectedGrants.HeaderRow.Parent.Controls.AddAt(0, row);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (SelectedGrantsUCModel selectedGrantsUCModel = new SelectedGrantsUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", selectedGrantsUCModel.userSessionInfo.ACC_CompanyName).Replace("*", selectedGrantsUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (SelectedGrantsUCModel selectedGrantsUCModel = new SelectedGrantsUCModel())
                {
                    selectedGrantsUCModel.BindRows(this, e, ref n_index, ref n_Action, ref n_ExerPrice, ref n_IntrinsicValue, ref n_FairVal);
                }
            }
            catch (Exception Ex)
            {
                using (SelectedGrantsUCModel selectedGrantsUCModel = new SelectedGrantsUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", selectedGrantsUCModel.userSessionInfo.ACC_CompanyName).Replace("*", selectedGrantsUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}