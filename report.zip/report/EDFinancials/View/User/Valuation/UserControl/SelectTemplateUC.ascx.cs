﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation.UserControl
{
    /// <summary>
    /// 
    /// </summary>
    public partial class SelectTemplateUC : BaseUC
    {
        /// <summary>
        /// 
        /// </summary>
        public static int n_IsListed = 1;

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (SelectTemplateUCModel selectTemplateUCModel = new SelectTemplateUCModel())
                    {
                        selectTemplateUCModel.ReadL10N_UI(this, ref n_IsListed);
                        selectTemplateUCModel.load_ddTemplatelist(this);
                    }

                    if (!string.IsNullOrEmpty(Convert.ToString(Session["Template_Name"])))
                    {
                        ddlTemplateNames.SelectedIndex = ddlTemplateNames.Items.IndexOf(ddlTemplateNames.Items.FindByText(Convert.ToString(Session["Template_Name"])));
                        Session["Template_Name"] = string.Empty;
                    }
                }
            }
            catch (Exception Ex)
            {
                using (SelectTemplateUCModel selectTemplateUCModel = new SelectTemplateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", selectTemplateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", selectTemplateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Save and continue for next step
        /// </summary>`
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSTSaveContinue_Click(object sender, EventArgs e)
        {
            try
            {
                using (SelectTemplateUCModel selectTemplateUCModel = new SelectTemplateUCModel())
                {
                    selectTemplateUCModel.SaveContinue(this);
                }
            }
            catch (Exception Ex)
            {
                using (SelectTemplateUCModel selectTemplateUCModel = new SelectTemplateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", selectTemplateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", selectTemplateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnView_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRedirectToTemplateGen_Click(object sender, EventArgs e)
        {
            try
            {
                Session["Template_Name"] = ddlTemplateNames.SelectedItem.Text;

                Response.Redirect("ReportFormat.aspx", false);
            }
            catch (Exception Ex)
            {
                using (SelectTemplateUCModel selectTemplateUCModel = new SelectTemplateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", selectTemplateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", selectTemplateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}