﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using EDFinancials.Model.User.Valuation.UserControl_Model;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation.UserControl
{
    /// <summary>
    /// 
    /// </summary>
    public partial class CompareGrantsUC : BaseUC
    {
        string s_Header = string.Empty;
        int n_Index = 0, n_Findings = 0, n_Comments = 0, n_ManuallyUploaded = 0, n_ValIndex = 0, n_GrantLevel = 0, n_CompanyLevel = 0, n_ParamID = 0;

        /// <summary>
        /// Page Load event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    if (!Page.IsPostBack)
                    {

                        compareGrantsUCModel.ReadL10N_UI(this);
                        compareGrantsUCModel.BindGrantIDDropdown(this);
                        ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    }
                    compareGrantsUCModel.AssignValuesFromTextbox(Request.Form, this);
                }
                if (hdnIsViewClick.Value.Equals("true") && (rdbFairValue.Checked || rdbInrinsicValue.Checked) && (rdbParameters.Checked || rdbValue.Checked))
                {
                    using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                    {
                        if (!hdnIsSaveCommentsClicked.Value.Equals("True"))
                        {
                            compareGrantsUCModel.BindSelectedGridValues(this, rdbFairValue.Checked.Equals(true) ? "FairValue" : "IntrinsicValue", true);
                        }
                    }
                }

                hdnIsViewClick.Value = string.Empty;
            }
            catch (Exception Ex)
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", compareGrantsUCModel.userSessionInfo.ACC_CompanyName).Replace("*", compareGrantsUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        #region Bind calculations of IV and FV to grid-view

        /// <summary>
        /// Bind header and footer to calculated grid
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        public void gv_DataBound(object sender, EventArgs e)
        {
            try
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {

                    compareGrantsUCModel.BindHeaderFooter(sender, compareGrantsUCModel, this);
                }
            }
            catch
            {
                throw;
            }
        }



        /// <summary>
        /// Row data bound for Grant Level parameters
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        public void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                    {
                        compareGrantsUCModel.ac_ValuationReport.n_VestCount = o_gvUserControlModel.ac_SearchGrantDetails.n_VestCount;
                    }

                    compareGrantsUCModel.BindRowsValuationParam(this, e, ref n_ValIndex, ref n_ManuallyUploaded, ref n_GrantLevel, ref n_CompanyLevel, ref n_ParamID);

                    if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowIndex.Equals(0) && rdbValue.Checked)
                    {
                        GridView parentGrid = (GridView)sender;

                        using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                        {
                            NewTotalRow.Font.Bold = true;
                            NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                            using (TableCell HeaderCell = new TableCell())
                            {
                                HeaderCell.Attributes.Add("Class", "gvChildGrid");
                                HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                HeaderCell.Font.Bold = true;
                                HeaderCell.Text = "Variables";
                                HeaderCell.ColumnSpan = compareGrantsUCModel.ac_ValuationReport.n_VestCount;
                                HeaderCell.HorizontalAlign = HorizontalAlign.Left;
                                NewTotalRow.Cells.Add(HeaderCell);
                                parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1, NewTotalRow);
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// Row data bound of Compare Grants 
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        public void gvLockedRecIVnFV_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    compareGrantsUCModel.BindGrid(this, e, ref s_Header, ref n_Index, ref n_Findings, ref n_Comments, sender);
                    if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowIndex.Equals(0) && rdbValue.Checked)
                    {
                        GridView parentGrid = (GridView)sender;

                        using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                        {
                            NewTotalRow.Font.Bold = true;
                            NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                            using (TableCell HeaderCell = new TableCell())
                            {
                                HeaderCell.Attributes.Add("Class", "gvChildGrid");
                                HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                HeaderCell.Font.Bold = true;
                                HeaderCell.Text = "Variables";
                                HeaderCell.ColumnSpan = compareGrantsUCModel.ac_ValuationReport.n_VestCount + 1;
                                HeaderCell.HorizontalAlign = HorizontalAlign.Left;
                                NewTotalRow.Cells.Add(HeaderCell);
                                parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1, NewTotalRow);
                            }
                        }
                    }

                }
            }
            catch (Exception Ex)
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", compareGrantsUCModel.userSessionInfo.ACC_CompanyName).Replace("*", compareGrantsUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Save and Continue for next step
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnSaveContinue_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    compareGrantsUCModel.SaveContinue(this, "Create", sender);

                    using (Button button = (Button)sender)
                    {
                        if (button.ID.Equals("btnSaveComments"))
                        {
                            btnViewValues_Click(sender, e);
                            hdnIsSaveCommentsClicked.Value = string.Empty;
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", compareGrantsUCModel.userSessionInfo.ACC_CompanyName).Replace("*", compareGrantsUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// View selected option button values i.e. FareValue/IntrinsicValue
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        public void btnViewValues_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    compareGrantsUCModel.BindSelectedGridValues(this, rdbFairValue.Checked.Equals(true) ? "FairValue" : "IntrinsicValue", false);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", compareGrantsUCModel.userSessionInfo.ACC_CompanyName).Replace("*", compareGrantsUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Bind Valuation Parameters
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        public void gvValuationParameters_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        /// <summary>
        /// Redirect to Grant Details
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        public void lbtnUPGrantLevelParam_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    Session["PageName"] = compareGrantsUCModel.RedirectToGrantDetails(this, sender)[0];
                    Session["GrantID"] = compareGrantsUCModel.RedirectToGrantDetails(this, sender)[1];
                    Session["GrantDate"] = compareGrantsUCModel.RedirectToGrantDetails(this, sender)[2];
                    Session["SelectedGrant"] = ddlGrantIDList.SelectedItem.Text;
                    Session["ValuationParam"] = hdnGrantRegID.Value;
                    Response.Redirect("ValuationParameters.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                using (CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", compareGrantsUCModel.userSessionInfo.ACC_CompanyName).Replace("*", compareGrantsUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void RerdirectedFromValuationParam()
        {
            ddlGrantIDList.SelectedIndex = ddlGrantIDList.Items.IndexOf(ddlGrantIDList.Items.FindByText(Convert.ToString(Session["SelectedGrant"])));
            rdbParameters.Checked = true;
            rdbFairValue.Checked = true;
            btnViewValues_Click(btnViewValues, null);
        }
    }
}