﻿using EDFinancials.Model;
using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Web;
using System.Web.UI;

namespace EDFinancials.View.User.Valuation.UserControl
{
    /// <summary>
    /// 
    /// </summary>
    public partial class DownloadReportWithWorkingUC : BaseUC
    {
        /// <summary>
        /// 
        /// </summary>
        public string s_QueryStringParams = null;

        /// <summary>
        /// 
        /// </summary>
        int n_index = 0, n_ID = 0;

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            using (DownloadReportUCModel downloadReportUCModel = new DownloadReportUCModel())
            {
                if (!Page.IsPostBack)
                {
                    downloadReportUCModel.ReadL10N_UI(this);
                    switch (downloadReportUCModel.userSessionInfo.ACC_UerTypeID)
                    {
                        case 3:
                        case 4:
                            break;

                        case 5:
                            txtUserComments.Enabled = false;
                            break;
                    }
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }

                s_QueryStringParams = downloadReportUCModel.ac_ValuationReport.s_QueryStringParams;
            }
        }

        /// <summary>
        /// Download report button click
        /// </summary>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">information about control</param>
        protected void btnDownloadReport_Click(object sender, EventArgs e)
        {
            try
            {
                using (DownloadReportUCModel compareGrantsUCModel = new DownloadReportUCModel())
                {
                    compareGrantsUCModel.Download_Report(this);
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (DownloadReportUCModel downloadReportUCModel = new DownloadReportUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + 
                        System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + 
                        Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", downloadReportUCModel.userSessionInfo.ACC_CompanyName)
                        .Replace("*", downloadReportUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace)
                        );
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSendForReview_Click(object sender, EventArgs e)
        {
            using (DownloadReportUCModel compareGrantsUCModel = new DownloadReportUCModel())
            {
                compareGrantsUCModel.SaveContinue(this, "Create", "SendForReview");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdateComments_Click(object sender, EventArgs e)
        {
            using (DownloadReportUCModel compareGrantsUCModel = new DownloadReportUCModel())
            {
                compareGrantsUCModel.SaveContinue(this, "Create", "UpdateComments");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvCommentsDetails_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            try
            {
                using(DownloadReportUCModel downloadReportUCModel = new DownloadReportUCModel())
                {
                    downloadReportUCModel.BindRows(this, e, ref n_index, ref n_ID);
                }
            }
            catch
            {
                // Do Nothing
            }
        }
    }
}