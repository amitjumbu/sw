﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using EDFinancials.View;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.UserControl.User.Valuation
{
    /// <summary>
    /// RFIR user control code behind class
    /// </summary>
    public partial class RiskFreeInterestRateUC : BaseUC
    {
        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    if ((!(String.IsNullOrEmpty(Request.QueryString["PgName"]))) && (Convert.ToString(Request.QueryString["PgName"]).ToUpper().Equals("REPORTPARAMETERS")))
                    {
                        using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                        {
                            reportParametersModel.Bind_ParameterText_ToControls(this, "RFIR");
                            reportParametersModel.BindPageUI(this, "RFIR");
                            reportParametersModel.Show_Parameter_text_Columns(this, "RFIR", true);
                            reportParametersModel.CheckEmployeeRolePriviledges(this, "RFIR");
                        }
                    }
                }

                ctrPreview_RFIR.b_IsVisible = false;
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events
        /// <summary>
        /// Country dropdown selected index changed event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void ddlVPSRFIRCountryList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (RFIR_td1.Visible)
                {
                    using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                    {
                        if (((DropDownList)sender).SelectedItem.ToString() != "--- Please Select ---")
                            reportParametersModel.changeTextOnRadioSelection(((DropDownList)sender).ID, ((DropDownList)sender).SelectedValue, txtVPSRFIRCountryText);
                        ctrPreview_RFIR.b_IsVisible = false;
                    }
                }
                else
                {
                    using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                    {
                        riskFreeInterestRateUCModel.VPSRFIRCountrySelIndChanged(this, "");
                        this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "RFIRC" });
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "RFIRC", 0 });
                    }
                }
            }
            catch (Exception Ex)
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", riskFreeInterestRateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", riskFreeInterestRateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    riskFreeInterestRateUCModel.RowDataBindForGVRFIR(e, ddlVPSRFIRCountryList.SelectedItem.Text.ToUpper().Equals("INDIA"));
                }
            }
            catch (Exception Ex)
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", riskFreeInterestRateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", riskFreeInterestRateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view page index chnage event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    riskFreeInterestRateUCModel.PageIndexChangingForGVRFIR(e.NewPageIndex, this);

                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, "RFIRC" });
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "RFIRC", 0 });
                }
            }
            catch (Exception Ex)
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", riskFreeInterestRateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", riskFreeInterestRateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button apply filter click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnRFIRApplyFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    riskFreeInterestRateUCModel.VPSRFIRCountrySelIndChanged(this, "");

                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "RFIRC" });
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "", 0 });
                }
            }
            catch (Exception Ex)
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", riskFreeInterestRateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", riskFreeInterestRateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// btn RFIR clear filter click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnRFIRClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    riskFreeInterestRateUCModel.VPSRFIRCountrySelIndChanged(this, "Reset");
                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "RFIRC" });
                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "", "RFIRC", 0 });
                }
            }
            catch (Exception Ex)
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", riskFreeInterestRateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", riskFreeInterestRateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// RFIR download button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnRFIRDownload_Click(object sender, EventArgs e)
        {
            try
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    riskFreeInterestRateUCModel.DownloadFile(this);
                }
            }
            catch (Exception Ex)
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", riskFreeInterestRateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", riskFreeInterestRateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to save RFIR details
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnRFIRSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {                    
                    string s_MsgToDisplay = string.Empty;
                    int n_RetValue = riskFreeInterestRateUCModel.SaveRFIRDetails(this, string.IsNullOrEmpty(hdnVPSRFIRID.Value) ? "C" : "U");

                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "RFIRC" });

                    switch (n_RetValue)
                    {
                        case 1: s_MsgToDisplay = "lblRFIRSaveMessage"; break;
                        case 2: s_MsgToDisplay = "lblRFIRUpdateMessage"; break;
                        case 3: s_MsgToDisplay = "lblRFIRDeleteMessage"; break;
                        case 4: s_MsgToDisplay = "lblRFIRRecordAlreadyExists"; break;
                        default: break;
                    }

                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, s_MsgToDisplay, "RFIRC", 1 });
                }
            }
            catch (Exception Ex)
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", riskFreeInterestRateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", riskFreeInterestRateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to delete RFIR details from table ACC_RFIR_DETAILS
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void btnRFIRDeleteAll_Click(object sender, EventArgs e)
        {
            try
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    string s_MsgToDisplay = string.Empty;
                    int n_RetValue = riskFreeInterestRateUCModel.SaveRFIRDetails(this, "D");

                    this.Page.GetType().InvokeMember("ReBindGridsOnPostBack", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { false, "RFIRC" });

                    switch (n_RetValue)
                    {
                        case 1: s_MsgToDisplay = "lblRFIRSaveMessage"; break;
                        case 2: s_MsgToDisplay = "lblRFIRUpdateMessage"; break;
                        case 3: s_MsgToDisplay = "lblRFIRDeleteMessage"; break;
                        case 4: s_MsgToDisplay = "lblRFIRRecordAlreadyExists"; break;
                        default: break;
                    }

                    this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, s_MsgToDisplay, "RFIRC", 1 });
                }
            }
            catch (Exception Ex)
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", riskFreeInterestRateUCModel.userSessionInfo.ACC_CompanyName).Replace("*", riskFreeInterestRateUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Report Parameters
        /// <summary>
        /// This is click event of RFIR save button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRFIRSave_Text_Click(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    string s_OutputMessage = reportParametersModel.PerformCUD_RFIR(this);

                    using (VolatilityUCModel volatilityUCModel = new VolatilityUCModel())
                    {
                        this.Page.GetType().InvokeMember("DisplayMessage", System.Reflection.BindingFlags.InvokeMethod, null, this.Page, new object[] { true, s_OutputMessage, "RFIRC", 1 });
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is click event of RFIR preview button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRFIRPreview_Click(object sender, EventArgs e)
        {
            try
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    reportParametersModel.GetPriview_MPIV(this, "RFIR");
                }
            }
            catch (Exception Ex)
            {
                using (ReportParametersModel reportParametersModel = new ReportParametersModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportParametersModel.userSessionInfo.ACC_CompanyName).Replace("*", reportParametersModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}