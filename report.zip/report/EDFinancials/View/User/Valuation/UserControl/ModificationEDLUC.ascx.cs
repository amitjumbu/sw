﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation.UserControl
{
    /// <summary>
    /// The ModificationEDLUC Page Class
    /// </summary>
    public partial class ModificationEDLUC : BaseUC
    {
        int n_index = 0, n_ID = 0, n_Action = 0, n_GrantID = 0, n_GrantDate = 0, n_ExerPrc = 0, n_VestSchedule = 0, n_FairValue = 0, n_IntrinsicValue = 0, n_Status = 0, n_AGRMID = 0, n_GrpNum = 0, n_IsMUFV = 0, n_IsMUIV = 0, n_Opt_ID = 0, n_Opt_Date = 0,
            n_DatList = 0, n_MarketValue = 0, n_CompanyLevel = 0, n_GrantLevel = 0, n_ValIndex = 0, n_ManuallyUploaded = 0,
            n_VestIndex = 0, n_VestID = 0, n_VestAction = 0, n_VestGrantDate = 0, n_rowIndex = 1, n_VestPercent = 0, n_FairValVest = 0, n_IntrsicValVest = 0, n_VestOptID = 0;

        string s_GrantID = string.Empty;

        /// <summary>
        /// The Page Load Method of ModificationEDLUC Page
        /// </summary>
        /// <param name="sender">ModificationEDLUC Page Object</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    if (!Page.IsPostBack)
                    {
                        modificationEDLUCModel.GetModEDLData(this);

                        modificationEDLUCModel.BindUI(this);

                        modificationEDLUCModel.BindDropDown(this);
                    }

                    if (!hdnIsModEDLVisible.Value.Equals("False") && hdnModEDLTabClicked.Value.Equals("true"))
                        BindGrid();
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Bound Event of gvModEDL GridView
        /// </summary>
        /// <param name="sender">gvModEDL GridView</param>
        /// <param name="e">e</param>
        protected void gvModEDL_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    modificationEDLUCModel.gvModEDL_RowDataBound(sender, e, this, ref n_index, ref n_Action, ref n_ID, ref n_GrantID, ref n_GrantDate, ref n_ExerPrc, ref n_VestSchedule, ref n_FairValue, ref n_IntrinsicValue, ref n_Status, ref n_AGRMID, ref n_GrpNum, ref n_IsMUFV, ref n_IsMUIV, ref n_Opt_ID, ref n_Opt_Date);

                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        if (!s_GrantID.Equals(System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString()))
                        {
                            s_GrantID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString();

                            modificationEDLUCModel.AddChildGrid(sender, e, s_GrantID, ref n_VestIndex, ref n_VestID, ref n_VestAction, ref n_VestGrantDate, ref n_rowIndex, this);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Grant ID LinkButton Pop up to show parameters
        /// </summary>
        /// <param name="sender">Grant ID LinkButton</param>
        /// <param name="e">e</param>
        public void lnkFVClick(object sender, EventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    modificationEDLUCModel.GetValuationParameters(this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Data Bound event of gv2ME GridView
        /// </summary>
        /// <param name="sender">gv2ME GridView</param>
        /// <param name="e">e</param>
        protected void gv2ME_DataBound(object sender, EventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
                    {
                        TableCell cell = new TableCell();
                        cell.Text = modificationEDLUCModel.ac_SearchGrantDetails.s_FinalValue;
                        cell.ColumnSpan = 1;
                        cell.Font.Bold = true;
                        cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        cell.HorizontalAlign = HorizontalAlign.Left;
                        row.Controls.Add(cell);
                        cell = new TableCell();

                        cell.ColumnSpan = modificationEDLUCModel.ac_SearchGrantDetails.n_VestCount - 1;
                        cell.Font.Bold = true;
                        cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        cell.HorizontalAlign = HorizontalAlign.Right;
                        cell.Text = modificationEDLUCModel.ac_SearchGrantDetails.s_FairValue;
                        row.Controls.Add(cell);

                        gv2ME.HeaderRow.Parent.Controls.AddAt(modificationEDLUCModel.ac_SearchGrantDetails.n_RowCount + 3, row);
                        cell.Dispose();
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound event of gv2ME GridView
        /// </summary>
        /// <param name="sender">gv2ME GridView</param>
        /// <param name="e">e</param>
        protected void gv2ME_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    modificationEDLUCModel.gv2ME_RowDataBound(e, ref n_index, ref n_DatList, ref n_MarketValue);

                    switch (e.Row.RowType)
                    {
                        case DataControlRowType.Header:
                            e.Row.Cells[e.Row.Cells.Count - 1].Visible = false;
                            break;

                        case DataControlRowType.DataRow:
                            if (e.Row.RowIndex.Equals(0))
                            {
                                GridView parentGrid = (GridView)sender;

                                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                                {
                                    NewTotalRow.Font.Bold = true;
                                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                    using (TableCell HeaderCell = new TableCell())
                                    {
                                        HeaderCell.Attributes.Add("Class", "gvChildGrid");
                                        HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                        HeaderCell.Font.Bold = true;
                                        HeaderCell.Text = "Variables";
                                        HeaderCell.ColumnSpan = modificationEDLUCModel.ac_SearchGrantDetails.n_VestCount;
                                        HeaderCell.HorizontalAlign = HorizontalAlign.Left;
                                        NewTotalRow.Cells.Add(HeaderCell);
                                        parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1, NewTotalRow);
                                    }
                                }
                            }

                            for (int n_ColCnt = 1; n_ColCnt < e.Row.Cells.Count - 1; n_ColCnt++)
                            {
                                if (!e.Row.Cells[e.Row.Cells.Count - 1].Text.Equals("&nbsp;") && Convert.ToDecimal(e.Row.Cells[e.Row.Cells.Count - 1].Text).Equals(1))
                                {
                                    e.Row.Cells[n_ColCnt].ForeColor = Color.Green;
                                    e.Row.Cells[n_ColCnt].ToolTip = "Manually updated";
                                }
                                e.Row.Cells[e.Row.Cells.Count - 1].Visible = false;
                            }

                            switch (((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[0].ToString())
                            {
                                case "IS_MU_MKT_FV":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_MKT_IV":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_EXL":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_VOL":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_RFIR":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_DIVD":
                                    e.Row.Visible = false;
                                    break;

                                case "IS_MU_DIVD_MP_DIVD":
                                    e.Row.Visible = false;
                                    break;
                            }
                            break;
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound event of gvMEValuationParameters GridView
        /// </summary>
        /// <param name="sender">gvMEValuationParameters GridView</param>
        /// <param name="e">e</param>
        protected void gvMEValuationParameters_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    modificationEDLUCModel.gvMEValuationParameters_RowDataBound(this, e, ref n_CompanyLevel, ref n_GrantLevel, ref n_ValIndex, ref n_ManuallyUploaded);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Grant ID Link Button Click Event to open pop up to view Valuation Parameters
        /// </summary>
        /// <param name="sender">Grant ID Link Button</param>
        /// <param name="e">e</param>
        public void lnkBtnGrantID_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    modificationEDLUCModel.GetValuationParameters(this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row DataBound Event of child GridView within Parent GridView
        /// </summary>
        /// <param name="sender">child GridView</param>
        /// <param name="e">e</param>
        internal void gvchildGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    modificationEDLUCModel.gvchildGrid_RowDataBound(e, this, ref n_VestIndex, ref n_VestID, ref n_VestAction, ref n_VestGrantDate, ref n_VestPercent, ref n_FairValVest, ref n_IntrsicValVest, ref n_VestOptID);
                }

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    s_GrantID = System.Web.UI.DataBinder.Eval(e.Row.DataItem, "Grant Registration ID").ToString();
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Intrinsic Value Link Button Click Event to show IV values in the pop up
        /// </summary>
        /// <param name="sender">Intrinsic Value Link Button</param>
        /// <param name="e">e</param>
        internal void lnkBtnIntrinsicValue_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    modificationEDLUCModel.BindIVFV("IntrinsicValue", Convert.ToInt32(hdnMEOptID.Value), Convert.ToString(hdnMEOptDate.Value), this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Fair Value Link Button Click Event to show FV values in the pop up
        /// </summary>
        /// <param name="sender">Fair Value Link Button</param>
        /// <param name="e">e</param>
        internal void lnkBtnFairValue_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    modificationEDLUCModel.BindIVFV("FairValue", Convert.ToInt32(hdnMEOptID.Value), Convert.ToString(hdnMEOptDate.Value), this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Reprocess Button Click Event
        /// </summary>
        /// <param name="sender">Reprocess Button</param>
        /// <param name="e">e</param>
        protected void btnMEReprocess_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    modificationEDLUCModel.btnMEReprocess_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Status Link Button Click Event to gor to the respective step of Grant(s) to process it
        /// </summary>
        /// <param name="sender">Status Link Button</param>
        /// <param name="e">e</param>
        internal void lnkBtnGotoStepME_Click(object sender, EventArgs e)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    modificationEDLUCModel.lnkBtnGotoStepME_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to Bind The GridView on Modification/EDL Tab
        /// </summary>
        public void BindGrid()
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    if (hdnMEBindGrid.Value == "1")
                        ddlMETypeOfOperation.SelectedIndex = ddlMETypeOfOperation.SelectedItem.Text.Equals("Modification") ? 0 : 1;

                    if (hdnMEReset.Value == "1")
                        modificationEDLUCModel.BindDropDown(this);

                    if (hdnMEBindGrid.Value == "1" || hdnMEReset.Value == "1" || hdnbtnMEProceed.Value.Equals("True") || hdnMEProceed.Value.Equals("True"))
                    {
                        n_index = 0; n_rowIndex = 1;

                        hdnMEBindGrid.Value = hdnMEReset.Value = string.Empty;
                    }

                    modificationEDLUCModel.BindGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", modificationEDLUCModel.userSessionInfo.ACC_CompanyName).Replace("*", modificationEDLUCModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}