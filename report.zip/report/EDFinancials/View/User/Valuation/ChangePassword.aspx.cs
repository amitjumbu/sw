﻿using System;
using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// Code behind file for valuation's ChangePassword.aspx page
    /// </summary>
    public partial class ChangePassword : BasePage
    {
        /// <summary>
        /// Page load method of View.User.Valuation.ChangePassword.aspx
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e"> event arguement</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (ChangePasswordModel changePasswordModel = new ChangePasswordModel())
                    {
                        changePasswordModel.BindPageUI(this);
                        changePasswordModel.CheckEmployeeRolePriviledges(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ChangePasswordModel changePasswordModel = new ChangePasswordModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", changePasswordModel.userSessionInfo.ACC_CompanyName).Replace("*", changePasswordModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Update button that  submits the data and intialises the update action via Model layer 
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event</param>
        protected void btnCPSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                using (ChangePasswordModel changePasswordModel = new ChangePasswordModel())
                {
                    if (changePasswordModel.ValidatePasswordPattern(this))
                    {
                        changePasswordModel.PerformCUD(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ChangePasswordModel changePasswordModel = new ChangePasswordModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", changePasswordModel.userSessionInfo.ACC_CompanyName).Replace("*", changePasswordModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}