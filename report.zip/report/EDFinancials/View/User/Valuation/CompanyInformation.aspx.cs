﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// Company Information page code behind class
    /// </summary>
    public partial class CompanyInformation : BasePage
    {
        #region Page Load Event

        /// <summary>
        /// Page Load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                    {
                        companyInformationModel.PopulateAllControls(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInformationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInformationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events

        /// <summary>
        /// grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvCIShareCapDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    companyInformationModel.RowDataBindCIShareCapDetails(e);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInformationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInformationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvCIFaceValueDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    companyInformationModel.RowDataBindCIFaceValueDetails(e);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInformationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInformationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Dialog close button click event to repopulate parent page controls
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnCIClosePopup_Click(object sender, EventArgs e)
        {
            try
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    companyInformationModel.SetControlValuesOnPopupClose(this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInformationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInformationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvCIStockExchange_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    companyInformationModel.PageIndexChanging(e.NewPageIndex, this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInformationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInformationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event agrs</param>
        protected void gvAssociatedParams_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    companyInformationModel.gvAssociatedParams_PageIndexChanging(e.NewPageIndex, this);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInformationModel companyInformationModel = new CompanyInformationModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInformationModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInformationModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}