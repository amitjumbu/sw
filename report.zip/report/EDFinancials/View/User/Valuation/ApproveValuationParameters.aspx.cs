﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation
{

    /// <summary>
    /// 
    /// </summary>
    public partial class ApproveValuationParameters : BasePage
    {
        int n_Index = 0, n_SelectAll = 0, n_Parameters = 0, n_PreviousSettings = 0, n_CurrentSettings = 0, n_CONFIGID = 0;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (ApproveValuationParamsModel approveValuationParamsModel = new ApproveValuationParamsModel())
                    {
                        approveValuationParamsModel.BindUI(this);
                        approveValuationParamsModel.BindApprovalGrid(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (ApproveValuationParamsModel approveValuationParamsModel = new ApproveValuationParamsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", approveValuationParamsModel.userSessionInfo.ACC_CompanyName).Replace("*", approveValuationParamsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        #region Reviewer Section

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvVPAApprovalGrid_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            try
            {
                using (ApproveValuationParamsModel approveValuationParamsModel = new ApproveValuationParamsModel())
                {
                    approveValuationParamsModel.gvVPAApprovalGrid_RowDataBound(e, this, ref n_Index, ref n_SelectAll, ref n_Parameters, ref n_PreviousSettings, ref n_CurrentSettings, ref n_CONFIGID);
                }
            }
            catch (Exception Ex)
            {
                using (ApproveValuationParamsModel approveValuationParamsModel = new ApproveValuationParamsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", approveValuationParamsModel.userSessionInfo.ACC_CompanyName).Replace("*", approveValuationParamsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnVPSApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (ApproveValuationParamsModel approveValuationParamsModel = new ApproveValuationParamsModel())
                {
                    approveValuationParamsModel.btnVPSApprove_Click(this, true);
                }
            }
            catch (Exception Ex)
            {
                using (ApproveValuationParamsModel approveValuationParamsModel = new ApproveValuationParamsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", approveValuationParamsModel.userSessionInfo.ACC_CompanyName).Replace("*", approveValuationParamsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnVPSDisApprove_Click(object sender, EventArgs e)
        {
            try
            {
                using (ApproveValuationParamsModel approveValuationParamsModel = new ApproveValuationParamsModel())
                {
                    approveValuationParamsModel.btnVPSDisApprove_Click(this, false);
                }
            }
            catch (Exception Ex)
            {
                using (ApproveValuationParamsModel approveValuationParamsModel = new ApproveValuationParamsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", approveValuationParamsModel.userSessionInfo.ACC_CompanyName).Replace("*", approveValuationParamsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}