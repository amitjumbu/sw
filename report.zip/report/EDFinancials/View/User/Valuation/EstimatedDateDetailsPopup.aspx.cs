﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// EstimatedDateDetailsPopup page code behind class
    /// </summary>
    public partial class EstimatedDateDetailsPopup : BasePage
    {
        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (EstimatedDetailsPopupModel estimatedDetailsPopupModel = new EstimatedDetailsPopupModel())
                    {
                        estimatedDetailsPopupModel.PopulateAllControls(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (EstimatedDetailsPopupModel estimatedDetailsPopupModel = new EstimatedDetailsPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", estimatedDetailsPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", estimatedDetailsPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Control Events

        /// <summary>
        /// Button click event to perform CUD operation for Estimated Date details 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCIListgDetailsSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (EstimatedDetailsPopupModel estimatedDetailsPopupModel = new EstimatedDetailsPopupModel())
                {
                    int n_IsValid = estimatedDetailsPopupModel.ShowMsgDiv(this, estimatedDetailsPopupModel.ValidateEDLDates(this));

                    if (n_IsValid == 0)
                        estimatedDetailsPopupModel.ShowMsgDiv(this, estimatedDetailsPopupModel.CUDEstimatedDOL(this, ""));

                    estimatedDetailsPopupModel.ReBindAllGrids(this);
                }
            }
            catch (Exception Ex)
            {
                using (EstimatedDetailsPopupModel estimatedDetailsPopupModel = new EstimatedDetailsPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", estimatedDetailsPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", estimatedDetailsPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Gridview row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvCIListgDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (EstimatedDetailsPopupModel estimatedDetailsPopupModel = new EstimatedDetailsPopupModel())
                {
                    estimatedDetailsPopupModel.gvCIListgDetails_RowDataBound(e);
                }
            }
            catch (Exception Ex)
            {
                using (EstimatedDetailsPopupModel estimatedDetailsPopupModel = new EstimatedDetailsPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", estimatedDetailsPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", estimatedDetailsPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gvCIListgDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (EstimatedDetailsPopupModel estimatedDetailsPopupModel = new EstimatedDetailsPopupModel())
                {
                    estimatedDetailsPopupModel.gvCIListgDetails_PageIndexChanging(e.NewPageIndex, this);
                }
            }
            catch (Exception Ex)
            {
                using (EstimatedDetailsPopupModel estimatedDetailsPopupModel = new EstimatedDetailsPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", estimatedDetailsPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", estimatedDetailsPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Button click event to delete Estimated Date of listing
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event arg</param>
        protected void btnCIListingDetailsDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (EstimatedDetailsPopupModel estimatedDetailsPopupModel = new EstimatedDetailsPopupModel())
                {
                    estimatedDetailsPopupModel.ShowMsgDiv(this, estimatedDetailsPopupModel.CUDEstimatedDOL(this, "D"));

                    estimatedDetailsPopupModel.ReBindAllGrids(this);
                }
            }
            catch (Exception Ex)
            {
                using (EstimatedDetailsPopupModel estimatedDetailsPopupModel = new EstimatedDetailsPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", estimatedDetailsPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", estimatedDetailsPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}