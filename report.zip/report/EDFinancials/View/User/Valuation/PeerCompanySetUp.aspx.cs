﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Collections.Generic;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PeerCompanySetUp : BasePage
    {
        int n_index = 0, n_ID = 0, n_FromDate = 0, n_SEID = 0, n_DELETE = 0, n_GroupId = 0;
        int n_index_History = 0, n_ID_History, n_Createdby_History = 0, n_StatusCode__History = 0, n_Updated_By_History = 0, n_Updated_On_History = 0, n_GroupId_History = 0;

        /// <summary>
        /// PEER COMANY'S PAGE LOAD EVENT.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
            {
                try
                {
                    if (!IsPostBack)
                    {
                        peerCompanyModel.BindPageUI(this);
                        loadMasterGrid();
                        peerCompanyModel.ResetAllParameters(this);
                        peerCompanyModel.CheckEmployeeRolePriviledges(this);
                        peerCompanyModel.Calculate_Total_Weightage(this);
                    }
                    ctrSuccessErrorMessage.s_MessageText = string.Empty;
                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    btnBackToGD.Visible = string.IsNullOrEmpty(Convert.ToString(Session["Tab3GrantD"])) ? false : true;
                }
                catch (Exception Ex)
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is used to perform row column add/ hide / functions for history grid view
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">gridview row event object</param>
        protected void gv_History_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
            {
                try
                {
                    peerCompanyModel.Bind_Gv_History(e, ref n_index_History, ref n_ID_History, ref n_Createdby_History, ref n_StatusCode__History, ref n_Updated_By_History, ref n_Updated_On_History, ref n_GroupId_History);
                }
                catch (Exception Ex)
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is used to perform row column add/ hide / functions for Main grid view
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">gridview row event object</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
            {
                try
                {
                    peerCompanyModel.BindRows(e, ref n_index, ref n_ID, ref n_FromDate, ref n_SEID, ref n_DELETE, ref n_GroupId);
                }
                catch (Exception Ex)
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is resposible for handling the page index change of gridview.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Gridview Page Event</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
            {
                try
                {
                    peerCompanyModel.PageIndexChanging(sender, e, gv, hdnDeletedRecords.Value);
                }
                catch (Exception Ex)
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This Method is resposible for handling the page index change of gridview.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Gridview Page Event</param>
        protected void gv_History_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
            {
                try
                {
                    peerCompanyModel.gv_History_PageIndexChanging(sender, e, this, hdnDeletedRecords.Value);
                    updMain.Update();
                    hdnAccordionIndex.Value = "2";
                    h3AddEdit.Style.Add("display", "none");
                    h3History.Style.Add("display", "");
                }
                catch (Exception Ex)
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// THIS METHOD LOADS Master GRID VIEW DATA.
        /// </summary>
        public void loadMasterGrid()
        {
            try
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    peerCompanyModel.LoadGridData(this, "LoadGridView");
                    updMain.Update();
                }
            }
            catch (Exception Ex)
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Thisd is Row Databound event of EditGridview and used to add controls, hide column/ rows
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">GridView row Event object</param>
        protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    try
                    {
                        DropDownList ddDynamicStockExName = new DropDownList();
                        DropDownList ddDynamicStatus = new DropDownList();
                        CheckBox chkDynamicSelection = new CheckBox();

                        ddDynamicStatus = (DropDownList)e.Row.FindControl("ddEditPeerStatus_gv");
                        ddDynamicStockExName = (DropDownList)e.Row.FindControl("ddPeerEditStockEcName");
                        chkDynamicSelection = (CheckBox)e.Row.FindControl("chk");

                        if (ddDynamicStockExName != null && ddDynamicStatus != null && chkDynamicSelection != null)
                        {
                            ddDynamicStockExName.DataSource = peerCompanyModel.BindDropdowns("STOCK_EX_NAME"); ;
                            ddDynamicStockExName.DataTextField = "DATA";
                            ddDynamicStockExName.DataValueField = "VALUE";
                            ddDynamicStockExName.DataBind();

                            ddDynamicStatus.DataSource = peerCompanyModel.BindDropdowns("STATUS"); ;
                            ddDynamicStatus.DataTextField = "DATA";
                            ddDynamicStatus.DataValueField = "VALUE";
                            ddDynamicStatus.DataBind();
                            chkDynamicSelection.InputAttributes.Add("Value", peerCompanyModel.ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[e.Row.RowIndex][1].ToString());
                            chkDynamicSelection.InputAttributes.Add("Onclick", "return DeleteSelectedRecords('" + peerCompanyModel.ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[e.Row.RowIndex][1].ToString() + "',this)");

                        }
                        peerCompanyModel.Bind_Validators_To_Grid(this, e);
                        ddDynamicStockExName.SelectedValue = peerCompanyModel.ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[e.Row.RowIndex][9].ToString();
                        string s_Status = Convert.ToString(peerCompanyModel.ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[e.Row.RowIndex][6]);
                        ddDynamicStatus.SelectedValue = s_Status.Contains("Activate") ? "1" : s_Status.Contains("Deactivate") ? "0" : "-1";

                    }
                    catch (Exception)
                    {
                        // Do nothing                       
                    }
                }
            }
            catch (Exception Ex)
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is the click event of reset button, when clicked resets the gv_FinalListOfPeers gridview and its corresponding datatable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPeersReset_Click(object sender, EventArgs e)
        {
            try
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    peerCompanyModel.Reset_Gv1(this);
                    peerCompanyModel.Accordian_HideShow(this, 1);
                }
            }
            catch (Exception Ex)
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is the click event of Save button and saves the final list of peer companies to database.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPeerSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    peerCompanyModel.SavePeersToDatabase(this, "CREATE");
                }
            }
            catch (Exception Ex)
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Ths method calls addnewrowtogrid method that adds new row in edit gridview.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AddNewRow_Click(object sender, EventArgs e)
        {
            try
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    peerCompanyModel.addNewRowToGrid(this);
                    peerCompanyModel.Accordian_HideShow(this, 1);
                }
            }
            catch (Exception Ex)
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method deletes particular row from the corresponding source data table and loads that datatable to edit gridview. This method does not delete anything from database.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    peerCompanyModel.DeleteRecordFrom_Gv1(this);
                    hdnDeletedRecords.Value = "";
                    updMain.Update();
                }
            }
            catch (Exception Ex)
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method loads the 'Grants applicable to' date, one day prior to the selected new 'grants applicable from' date. 
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">event arguement</param>
        protected void txtPeerNewFromDate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    peerCompanyModel.txtPeerNewFromDate_TextChanged(this);
                    peerCompanyModel.Accordian_HideShow(this, 1);
                }
            }
            catch (Exception Ex)
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// this method calculates the total weightage, when a change in any of the weightage textbox is observed.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">event arguement</param>
        protected void txtPeerEditWeightage_gv_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Page.Validate("WeightageCount");

                if (Page.IsValid)
                {
                    using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                    {
                        ctrSuccessErrorMessage.s_MessageText = "";
                        ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                        h3AddEdit.Style.Add("display", "");
                        peerCompanyModel.Calculate_Total_Weightage(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This is click event of cancel button on peer company setup page.
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">event arguement</param>
        protected void btnPeersCancel_Click(object sender, EventArgs e)
        {
            try
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    peerCompanyModel.Reset_Gv1(this);
                    peerCompanyModel.Accordian_HideShow(this, 0);
                    hdnAccordionIndex.Value = "0";
                }
            }
            catch (Exception Ex)
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to return back from Peer Company Setup page to Grant Details
        /// </summary>
        /// <param name="sender">Back To Grant Details Button</param>
        /// <param name="e">e</param>
        protected void btnBackToGD_Click(object sender, EventArgs e)
        {
            string s_AGRMID = Convert.ToString(Session["AGRMID"]);
            if (Convert.ToString(Session["PageNameGrantDetails"]).Equals("/View/User/Accounting/GrantDetails.aspx"))
            {
                Response.Redirect("../Accounting/GrantDetails.aspx?s_AGRMID=" + s_AGRMID, false);
            }
            else
            {
                Response.Redirect("GrantDetails.aspx?s_AGRMID=" + s_AGRMID, false);
            }
        }

        /// <summary>
        /// This MEthod Navigates to MarketPriceSetup page.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguement e</param>
        protected void btnNavigateToMarketPrice_Click(object sender, EventArgs e)
        {
            Session["NavigatePeerToMktPrice"] = "1";
            Response.Redirect("MarketPriceSetup.aspx", false);
        }

        /// <summary>
        /// alculates the wieghtage when peer company's status is changed
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void ddEditPeerStatus_gv_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                txtPeerEditWeightage_gv_TextChanged(sender, e);
            }
            catch (Exception Ex)
            {
                using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", peerCompanyModel.userSessionInfo.ACC_CompanyName).Replace("*", peerCompanyModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}