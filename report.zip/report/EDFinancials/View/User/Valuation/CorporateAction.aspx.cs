﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// This is code behind class for CorporateAction page.
    /// </summary>
    public partial class CorporateAction : BasePage
    {
        #region Variables Declaration
        int n_index = 0;

        Hashtable hash_Table = new Hashtable();
        #endregion

        /// <summary>
        /// Validation message if user tries to edit previous corporate action
        /// </summary>
        public string s_ValidationMessage;

        /// <summary>
        /// Page Load Method 
        /// </summary>
        /// <param name="sender">Sender as Parameter</param>
        /// <param name="e">Event Args (e) as Parameter</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                    {
                        // Check employee Role Privileged
                        corporateActionModel.CheckEmployeeRolePriviledges(this);

                        // Method is used to bind UI
                        corporateActionModel.BindPageUI(this);

                        // Method is used to bind page level validation
                        s_ValidationMessage = corporateActionModel.BindValidationMessage(this);

                        // Method is used to bind all controls i.e. grid and drop down list etcW.
                        corporateActionModel.BindControls(this);
                    }

                    btnBackToGD.Visible = string.IsNullOrEmpty(Convert.ToString(Session["Tab3GrantD"])) ? false : true;
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">Sender as Parameter</param>
        /// <param name="e">Event Args (e) as Parameter</param>
        protected void btnCASearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    corporateActionModel.ApplyFilter(this);
                }

            }
            catch (Exception Ex)
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">Sender as Parameter</param>
        /// <param name="e">Event Args (e) as Parameter</param>
        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    corporateActionModel.ResetFilter(this);
                }

            }
            catch (Exception Ex)
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">Sender as Parameter</param>
        /// <param name="e">Event Args (e) as Parameter</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    corporateActionModel.GridViewRowDataBound(this, e, ref n_index, ref hash_Table);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">Sender as Parameter</param>
        /// <param name="e">Event Args (e) as Parameter</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    corporateActionModel.gv_PageIndexChanging(sender, e, this);

                    // Method is used to bind page level validation
                    s_ValidationMessage = corporateActionModel.BindValidationMessage(this);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Perform Insert / Update Operation
        /// </summary>
        /// <param name="sender">Sender as Parameter</param>
        /// <param name="e">Event Args (e) as Parameter</param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    corporateActionModel.CUDCorporateAction(this);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Perform delete Operation
        /// </summary>
        /// <param name="sender">Sender as Parameter</param>
        /// <param name="e">Event Args (e) as Parameter</param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    corporateActionModel.CUDCorporateAction(this);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to return back from Corporate Action page to Grant Details
        /// </summary>
        /// <param name="sender">Sender as Parameter</param>
        /// <param name="e">Event Args (e) as Parameter</param>
        protected void btnBackToGD_Click(object sender, EventArgs e)
        {
            try
            {
                string s_AGRMID = Convert.ToString(Session["AGRMID"]);

                if (Convert.ToString(Session["PageNameGrantDetails"]).Equals("/View/User/Accounting/GrantDetails.aspx"))
                {
                    Response.Redirect("../Accounting/GrantDetails.aspx?s_AGRMID=" + s_AGRMID, false);
                }
                else
                {
                    Response.Redirect("GrantDetails.aspx?s_AGRMID=" + s_AGRMID, false);
                }
            }
            catch (Exception Ex)
            {
                using (CorporateActionModel corporateActionModel = new CorporateActionModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", corporateActionModel.userSessionInfo.ACC_CompanyName).Replace("*", corporateActionModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}