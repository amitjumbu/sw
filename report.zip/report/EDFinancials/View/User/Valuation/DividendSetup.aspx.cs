﻿using System;
using System.Web.UI.WebControls;
using EDFinancials.Model.User.Valuation;
using EDFinancials.Model.Generic;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// This is code behind class for DividendSetup page .
    /// </summary>
    public partial class DividendSetup : BasePage
    {
        int n_index = 0, n_ID = 0, n_Delete = 0, n_Action = 0, n_Remark = 0, n_DivPerShare = 0, n_Percentage = 0;

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                    {
                        dividendSetupModel.CheckEmployeeRolePriviledges(this);

                        dividendSetupModel.ReadL10N_UI(this);

                        dividendSetupModel.ReadDividendSetup(this);
                    }
                    btnBackToGD.Visible = string.IsNullOrEmpty(Convert.ToString(Session["Tab3GrantD"])) ? false : true;
                }
            }
            catch (Exception Ex)
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Save records
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected void btnDSSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    dividendSetupModel.CUDDividendSetup(this);

                    dividendSetupModel.ReadDividendSetup(this);
                }
            }
            catch (Exception Ex)
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Delete records
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnDSDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    dividendSetupModel.CUDDividendSetup(this);

                    dividendSetupModel.ReadDividendSetup(this);
                }
            }
            catch (Exception Ex)
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Apply Filters
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected void btnDSApplyFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    dividendSetupModel.ApplyFilters(this, false);

                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Clear Filters
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnDSClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    dividendSetupModel.ApplyFilters(this, true);

                    ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
            }
            catch (Exception Ex)
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Row bound
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">GridViewRowEventArgs</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    dividendSetupModel.BindRows(e, ref n_index, ref n_ID, ref n_Delete, ref n_Action, ref n_Remark, ref n_DivPerShare, ref n_Percentage);
                }
            }
            catch (Exception Ex)
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Index change event
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">GridViewPageEventArgs</param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    dividendSetupModel.PageIndexChanging(sender, e, gv, hdnDeletedRecords.Value, this);

                    hdnAccordionIndex.Value = "0";
                }
            }
            catch (Exception Ex)
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This method is used to return back from Dividend Setup page to Grant Details
        /// </summary>
        /// <param name="sender">Back To Grant Details Button</param>
        /// <param name="e">e</param>
        protected void btnBackToGD_Click(object sender, EventArgs e)
        {
            try
            {
                string s_AGRMID = Convert.ToString(Session["AGRMID"]);

                if (Convert.ToString(Session["PageNameGrantDetails"]).Equals("/View/User/Accounting/GrantDetails.aspx"))
                {
                    Response.Redirect("../Accounting/GrantDetails.aspx?s_AGRMID=" + s_AGRMID, false);
                }
                else
                {
                    Response.Redirect("GrantDetails.aspx?s_AGRMID=" + s_AGRMID, false);
                }
            }
            catch (Exception Ex)
            {
                using (DividendSetupModel dividendSetupModel = new DividendSetupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", dividendSetupModel.userSessionInfo.ACC_CompanyName).Replace("*", dividendSetupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}