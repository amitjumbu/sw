﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// Code behind class file
    /// </summary>
    public partial class DownloadAddins : BasePage
    {
        int n_index = 0, n_Download = 0, n_FileName = 0, n_FilePath = 0, n_SrNo = 0;

        /// <summary>
        /// page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (DownloadAddinsModel downloadAddinsModel = new DownloadAddinsModel())
                    {
                        downloadAddinsModel.BindControls(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (DownloadAddinsModel downloadAddinsModel = new DownloadAddinsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", downloadAddinsModel.userSessionInfo.ACC_CompanyName).Replace("*", downloadAddinsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// grid-view row data bound event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (DownloadAddinsModel downloadAddinsModel = new DownloadAddinsModel())
                {
                    downloadAddinsModel.gv_RowDataBound(e, ref n_index, ref n_Download, ref n_FileName, ref n_FilePath, ref n_SrNo);
                }
            }
            catch (Exception Ex)
            {
                using (DownloadAddinsModel downloadAddinsModel = new DownloadAddinsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", downloadAddinsModel.userSessionInfo.ACC_CompanyName).Replace("*", downloadAddinsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// File download button click event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void btnAddInDownload_Click(object sender, EventArgs e)
        {
            try
            {
                using (DownloadAddinsModel downloadAddinsModel = new DownloadAddinsModel())
                {
                    downloadAddinsModel.DownloadFile(this);
                }
            }
            catch (Exception Ex)
            {
                using (DownloadAddinsModel downloadAddinsModel = new DownloadAddinsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", downloadAddinsModel.userSessionInfo.ACC_CompanyName).Replace("*", downloadAddinsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}