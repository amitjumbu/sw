﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.IO;
using System.Web.Services;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// This is code behind class for GrantDetails page.
    /// </summary>
    public partial class GrantDetails : BasePage
    {
        #region Page Load
        /// <summary>
        /// The Page Load
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    if (Convert.ToString(Session["Tab3GrantD"]) == "Set")
                    {
                        string s_AGRMID = string.IsNullOrEmpty(Convert.ToString(Session["GrantID"])) ? Request.QueryString["s_AGRMID"] : string.Empty;

                        grantDetailsModel.ClearCommonTables();

                        grantDetailsModel.BindUI(this);

                        grantDetailsModel.GetGrantDetails(this);

                        grantDetailsModel.ShowEditSection(this, s_AGRMID, Convert.ToString(Session["GrantID"]), string.Empty);

                        grantDetailsModel.SetFields(this);

                        Session["Tab3GrantD"] = null;
                    }
                    else
                    {
                        //Do not modify this code. It will affect on Valuation Report page.
                        #region Do not modify this code. It will affect on Valuation Report page.
                        if (!IsPostBack)
                        {
                            grantDetailsModel.ClearCommonTables();

                            grantDetailsModel.BindUI(this);

                            grantDetailsModel.GetGrantDetails(this);

                            grantDetailsModel.CheckEmployeeRolePriviledges(this);

                            //Request.UrlReferrer.AbsolutePath : used to get previous path
                            if (Request.UrlReferrer.AbsolutePath.Contains("ValuationReport"))
                            {
                                grantDetailsModel.BindUI(this);

                                grantDetailsModel.GetGrantDetails(this);

                                grantDetailsModel.RedirectFromValuationRep(this);
                            }
                        }

                        #endregion
                    }
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Scheme Name Dropdown Chage Event
        /// <summary>
        /// This Method is used for index change event of Scheme Name dropdown
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void ddlAddGrantSchemeName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.ddlAddGrantSchemeName_SelectedIndexChanged(this);

                    grantDetailsModel.EnableDisableControls(this, Convert.ToString(((DropDownList)sender).ID));

                    grantDetailsModel.DisplayMessage(this, "ddlAddGrantSchemeName", 0);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Populate Vest Grid
        /// <summary>
        /// This Method is used to Populate Vest Grid
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void btnAddGrantPopulateVestDetails_Click(object sender, EventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.PopulateVestdetails(this);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Vest Details Grid View RowBound Method
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void gvVestExercisePopulate_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.gvVestExercisePopulateRowDataBound(sender, e, this);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Upadate Params Grid View
        /// <summary>
        /// This method is used for Change Event On Radio Button selection for Update Params GridView
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void rdbtnUpdateParams_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.PopulateUpdateParamsGrid(this);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// Update Params GridView Row Bound Method
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void gvUpdateFairParams_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.gvUpdateFairParams_RowDataBound(sender, e, this);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Save and Continue
        /// <summary>
        /// This Method is for Save and Continue Grant Details Button Click
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        protected void btnAddGrantSaveContinue_Click(object sender, EventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    if (hdnAction.Value.Equals("U"))
                    {
                        grantDetailsModel.PopulateVestDetails(this);

                        grantDetailsModel.SaveVestExerciseGrid(this);

                        grantDetailsModel.CheckPopulatedGrid(this);
                    }

                    if (grantDetailsModel.ac_GrantDetails.s_Error.Equals("Set"))
                        grantDetailsModel.ac_GrantDetails.s_Error = string.Empty;

                    else
                    {
                        grantDetailsModel.SaveContinueGrant(this, sender, e);

                        Session["GrantID"] = txtAddGrantGrantID.Text;
                    }
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Display Message Box
        /// <summary>
        /// This Method is used to dispaly messagebox
        /// </summary>
        /// <param name="s_ButtonID">Button ID</param>
        /// <param name="n_Result">n_Result</param>
        public void DisplayMessage(string s_ButtonID, int n_Result)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.DisplayMessage(this, s_ButtonID, n_Result);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Edit Functionality
        /// <summary>
        /// This Method is used to Perform Edit Functionality Of Grant Details Page
        /// </summary>
        /// <param name="sender">hdnBtn Update Button sender</param>
        /// <param name="e">e</param>
        protected void hdnBtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.ShowEditSection(this, this.UCUpdateGeneralParams.hdnARMID_ToEdit.Value, "", "U");

                    grantDetailsModel.EnableDisableControls(this, Convert.ToString(((Button)sender).ID));

                    grantDetailsModel.CheckEmployeeRolePriviledges(this);

                    Session["AGRMID"] = this.UCUpdateGeneralParams.hdnARMID_ToEdit.Value;
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region ddlAddGrantVestingParams DropDown Index Change Event
        /// <summary>
        /// The DropDown ddlAddGrantVestingParams Index Change
        /// </summary>
        /// <param name="sender">DropDown ddlAddGrantVestingParams</param>
        /// <param name="e">e</param>
        protected void ddlAddGrantVestingParams_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.ddlAddGrantVestingParams_SelectedIndexChanged(this);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Back to Valuation Report Page
        /// <summary>
        /// Back to Valuation Report page
        /// </summary>
        /// <param name="sender">Valuation Report sender</param>
        /// <param name="e">e</param>
        protected void btnBackToValParams_Click(object sender, EventArgs e)
        {
            Response.Redirect("ValuationReport.aspx", false);
        }
        #endregion

        #region Grant Date TextBox Change Event
        /// <summary>
        /// This is txtAddGrantGrantDate Grant Date TextBox Change Event
        /// </summary>
        /// <param name="sender">Grant Date TextBox</param>
        /// <param name="e">e</param>
        protected void txtAddGrantGrantDate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.txtAddGrantGrantDate_TextChanged(this);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        /// <summary>
        /// The File Upload Button Click Event
        /// </summary>
        /// <param name="sender">File Upload Button</param>
        /// <param name="e">e</param>
        protected void btnAddGrantFileUpload_Click(object sender, EventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.btnAddGrantFileUpload_Click(this);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Data Bound Event of gvFileUpload GridView
        /// </summary>
        /// <param name="sender">gvFileUpload GridView</param>
        /// <param name="e">e</param>
        protected void gvFileUpload_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.gvFileUpload_RowDataBound(e);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// The Row Deleting Event of gvFileUpload GridView
        /// </summary>
        /// <param name="sender">gvFileUpload GridView</param>
        /// <param name="e">e</param>
        protected void gvFileUpload_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.gvFileUpload_RowDeleting(this, e);
                }
            }
            catch (Exception Ex)
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", grantDetailsModel.userSessionInfo.ACC_CompanyName).Replace("*", grantDetailsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// This web method is used to get vest details
        /// </summary>
        /// <param name="s_GrantRegID">GrantRegID</param>
        /// <returns>string</returns>
        [WebMethod]
        public static string GetVestingDetails(object s_GrantRegID)
        {
            try
            {
                using (ValuationReportModel valuationReportModel = new ValuationReportModel())
                {
                    return valuationReportModel.GetVestWiseDetails(Convert.ToString(s_GrantRegID));
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString(Ex.Message + "\n" + Ex.StackTrace));
                return "error";
            }

        }
    }
}