﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;
using System.Web.UI.WebControls;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// Company Info Popup page code behind class
    /// </summary>
    public partial class CompanyInfoPopup : BasePage
    {
        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    /* DivID
                      2 - Issued and Paid up Shares Details
                      3 - Face Value Details
                     */
                    int n_DivID;
                    int.TryParse(Request.QueryString["DivID"], out n_DivID);
                    using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                    {
                        companyInfoPopupModel.PopulateAllControls(this, n_DivID);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInfoPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInfoPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion

        #region Common methods

        /// <summary>
        /// This method is used to show/hide msg div content based on input/passed parameter(a_result)
        /// </summary>
        /// <param name="a_result">input parameter</param>
        public void ShowMsgDiv(int a_result)
        {
            try
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    companyInfoPopupModel.ShowMsgDiv(this, a_result);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all the grids
        /// </summary>
        public void ReBindAllGrids()
        {
            try
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    companyInfoPopupModel.ReBindAllGrids(this);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all the grids
        /// </summary>
        public void BindAllGrids()
        {
            try
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    companyInfoPopupModel.BindAllGrids(this, Convert.ToInt32(hdnCIPDivID.Value));
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// grid view row data bound event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvCIListingDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    companyInfoPopupModel.RowDataBindCIListingStatus(e);
                }
            }
            catch (Exception Ex)
            {
                using (CompanyInfoPopupModel companyInfoPopupModel = new CompanyInfoPopupModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", companyInfoPopupModel.userSessionInfo.ACC_CompanyName).Replace("*", companyInfoPopupModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
        #endregion
    }
}