﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using System;

namespace EDFinancials.View.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public partial class HelpDoc : BasePage
    {
        /// <summary>
        /// The Page Load Event
        /// </summary>
        /// <param name="sender">HelpDoc Page</param>
        /// <param name="e">e</param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    using (HelpDocModel helpDocModel = new HelpDocModel())
                    {
                        helpDocModel.LoadTreeview(this);
                    }
                }
            }
            catch (Exception Ex)
            {
                using (HelpDocModel helpDocModel = new HelpDocModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpDocModel.userSessionInfo.ACC_CompanyName).Replace("*", helpDocModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }

        /// <summary>
        /// TreeView tvHelp Select Node Chaged Event
        /// </summary>
        /// <param name="sender">TreeView tvHelp</param>
        /// <param name="e">e</param>
        protected void tvHelp_SelectedNodeChanged(object sender, EventArgs e)
        {
            try
            {
                using (HelpDocModel helpDocModel = new HelpDocModel())
                {
                    helpDocModel.tvHelp_SelectedNodeChanged(this);
                }
            }
            catch (Exception Ex)
            {
                using (HelpDocModel helpDocModel = new HelpDocModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", helpDocModel.userSessionInfo.ACC_CompanyName).Replace("*", helpDocModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}