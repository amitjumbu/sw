﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.Reports;
using System;

namespace EDFinancials.View.Reports
{
    /// <summary>
    /// 
    /// </summary>
    public partial class Reports : BasePage
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (IsPostBack)
                    return;

                using (ReportsModel reportsModel = new ReportsModel())
                {
                    reportsModel.Page_Load(this);
                }
            }
            catch (Exception Ex)
            {
                using (ReportsModel reportsModel = new ReportsModel())
                {
                    CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", reportsModel.userSessionInfo.ACC_CompanyName).Replace("*", reportsModel.userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
                }
            }
        }
    }
}