﻿using System;
using System.Collections.Specialized;
using System.Web;

namespace EDFinancials
{
    /// <summary>
    /// This is ASP.NET application file,that contains code for responding to application-level and session-level events. 
    /// </summary>
    public class Global : System.Web.HttpApplication
    {
        /// <summary>
        /// Code that runs on application startup
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_Start(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// This method is fired only when a new session for a user starts
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Session_Start(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// This method is fired on all requests handled by the ASP.NET runtime
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            HttpContext.Current.Response.AddHeader("x-frame-options", "SAMEORIGIN");
        }

        /// <summary>
        /// This method is fired before ASP.NET sends HTTP headers to the client. 
        /// It is mainly used for Penetration testing to remove excessive HTTP response.
        /// </summary>
        /// <param name="sender">sender Application</param>
        /// <param name="e">e</param>
        protected void Application_PreSendRequestHeaders(object sender, EventArgs e)
        {
            try
            {
                // Remove the "Server" HTTP Header from response
                using (HttpApplication app = sender as HttpApplication)
                {
                    if (app != null && app.Request != null && app.Context != null && app.Context.Response != null)
                    {
                        NameValueCollection headers = app.Context.Response.Headers;

                        if (headers != null)
                        {
                            headers.Remove("Server");
                        }
                    }
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// This method is fired when the request (user) that is already authenticated?
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// This method is fired when an unhandled error occurs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_Error(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// This method is fired when session for a user ended.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Session_End(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// This method is fired when application shutdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_End(object sender, EventArgs e)
        {
            Exception ex = Server.GetLastError();
            if (ex != null)
            {
                Response.Redirect("~/View/CustomError.aspx");
            }
        }
    }
}