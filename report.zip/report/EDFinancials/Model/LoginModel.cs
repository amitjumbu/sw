﻿using EDFinancials.Model.Generic;
using System;
using System.Data;
using System.Drawing;
using System.Web;

namespace EDFinancials.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class LoginModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public LoginModel()
        {
            if (ac_MenuMaster == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_MenuMaster);
                ac_MenuMaster = (CommonModel.AC_MenuMaster)HttpContext.Current.Session[CommonConstantModel.s_AC_MenuMaster];
            }
        }

        /// <summary>
        /// Method is used to bind UI 
        /// </summary>
        /// <param name="login">Login Page object</param>             
        internal void BindLoginPageUI(View.Login login)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    using (DataSet dataSetLoginUI = genericServiceClient.COMMON_LoadL10N_UI())
                    {
                        if ((dataSetLoginUI != null) && (dataSetLoginUI.Tables.Count > 0) && (dataSetLoginUI.Tables[0].Rows.Count > 0))
                        {
                            login.lblLgnUserName.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblUserName'"))[0]["LabelName"]);
                            login.lblLgnUserName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblUserName'"))[0]["LabelToolTip"]);
                            login.valLgnUserName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblUserName'"))[0]["ErrorText"]);
                            login.valLgnUserName.SetFocusOnError = true;

                            login.lblLgnPassword.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblPassword'"))[0]["LabelName"]);
                            login.lblLgnPassword.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblPassword'"))[0]["LabelToolTip"]);
                            login.valLgnPassword.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblPassword'"))[0]["ErrorText"]);
                            login.valLgnPassword.SetFocusOnError = true;

                            login.lblLgnCompanyName.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCompanyName'"))[0]["LabelName"]);
                            login.lblLgnCompanyName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCompanyName'"))[0]["LabelToolTip"]);
                            login.valLgnCompanyName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCompanyName'"))[0]["ErrorText"]);
                            login.valLgnCompanyName.SetFocusOnError = true;

                            login.btnLgnSignIn.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'btnSignIn'"))[0]["LabelName"]);
                            login.btnLgnSignIn.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'btnSignIn'"))[0]["LabelToolTip"]);

                            login.valLgnUserName.Text = login.valLgnPassword.Text = login.valLgnCompanyName.Text = "*";
                            login.valLgnUserName.ForeColor = login.valLgnPassword.ForeColor = login.valLgnCompanyName.ForeColor = Color.Red;
                            login.txtLgnUserName.Focus();
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used check login user is valid or not
        /// </summary>
        /// <param name="login">Login Page object</param>
        /// <returns>return string as Redirect page name for respective user type</returns>
        internal string ValidateLoginUser(View.Login login)
        {
            try
            {
                string s_RedirectMessage = string.Empty;

                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    using (DataTable dt_LoginInformation = genericServiceClient.ValidateUserLogin(login.txtLgnUserName.Text, login.txtLgnPassword.Text, login.txtLgnCompanyName.Text))
                    {
                        if (dt_LoginInformation.Rows.Count > 0)
                        {
                            if (!dt_LoginInformation.Rows[0]["IS_ACTIVE"].Equals(1))
                            {
                                ac_MenuMaster.s_LastLoginDetails = dt_LoginInformation.Rows[0]["LAST_LOGGED_IN"].Equals(DBNull.Value) ?
                                                                 "Current Login : " + DateTime.Now.ToString("dd-MMM-yyyy h:mm tt") : Convert.ToDateTime(dt_LoginInformation.Rows[0]["LAST_LOGGED_IN"]).ToString("dd-MMM-yyyy h:mm tt");

                                switch (Convert.ToInt32(dt_LoginInformation.Rows[0]["USER_TYPE_ID"]))
                                {
                                    // For Super Admin
                                    case 1:
                                        s_RedirectMessage = "~/View/SuperAdmin/CompanyCreation.aspx";
                                        BindSession(login, dt_LoginInformation);
                                        break;

                                    // For Admin
                                    case 2:
                                        s_RedirectMessage = "~/View/Admin/CompanySetup.aspx";
                                        BindSession(login, dt_LoginInformation);
                                        break;

                                    // For User
                                    case 3:
                                    case 4:
                                        s_RedirectMessage = "~/View/User/Valuation/CompanyInformation.aspx";
                                        BindSession(login, dt_LoginInformation);
                                        break;

                                    case 5:
                                        s_RedirectMessage = "~/View/User/Valuation/CompanyInformation.aspx";
                                        BindSession(login, dt_LoginInformation);
                                        break;
                                    default:
                                        throw new EDFinancialsException(s_RedirectMessage);
                                }
                                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                genericServiceClient.UpdateLastLoggedIn(genericProperties);
                            }
                            else
                            {
                                throw new EDFinancialsException(genericServiceClient.COMMON_LoadL10N("LGN_InactiveUser"));
                            }
                        }
                        else
                        {
                            throw new EDFinancialsException(genericServiceClient.COMMON_LoadL10N("LGN_InvalidLogin"));
                        }

                    }
                }

                return s_RedirectMessage;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind session variable
        /// </summary>
        /// <param name="login">Login Page object</param>
        /// <param name="dt_LoginInformation">this is dataTable for login information</param>      
        internal void BindSession(View.Login login, DataTable dt_LoginInformation)
        {
            userSessionInfo.ACC_UserID = Convert.ToInt32(dt_LoginInformation.Rows[0]["UMID"]);
            userSessionInfo.ACC_UserName = login.txtLgnUserName.Text;
            userSessionInfo.ACC_CompanyName = login.txtLgnCompanyName.Text;
            userSessionInfo.ACC_UerTypeID = Convert.ToInt32(dt_LoginInformation.Rows[0]["USER_TYPE_ID"]);
            userSessionInfo.ACC_IsListed = !Convert.ToBoolean(dt_LoginInformation.Rows[0]["IS_LISTED"]) ? 0 : 1;
            userSessionInfo.ACC_IsMYESOPsClient = !Convert.ToBoolean(dt_LoginInformation.Rows[0]["IS_MYESOPS_CLIENT"]) ? 0 : 1;
            userSessionInfo.ACC_CompanyTitle = Convert.ToString(dt_LoginInformation.Rows[0]["COMPANY_NAME"]);
            userSessionInfo.ACC_CMID = Convert.ToInt32(dt_LoginInformation.Rows[0]["CMID"]);
            userSessionInfo.ACC_CalculationMethod = Convert.ToInt32(dt_LoginInformation.Rows[0]["CALCULATION_METHOD"]);
            userSessionInfo.ACC_EmailID = Convert.ToString(dt_LoginInformation.Rows[0]["EMAIL_ID"]);
            if (userSessionInfo.ACC_UerTypeID > 2)
                userSessionInfo.ACC_IsEmpAccess = Convert.ToBoolean(dt_LoginInformation.Rows[0]["EMP_WISE_ACCESS"]);
            SessionContext.SetUserSessionInfoValues(userSessionInfo);
        }

        /// <summary>
        /// This method is used to encrypt the GUID(Global Unique Identifier)
        /// </summary>
        /// <param name="s_Guid">string GUID(Global Unique Identifier)</param>
        /// <returns>Encrypted string GUID(Global Unique Identifier)</returns>
        internal string EncryptGuid(string s_Guid)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    return genericServiceClient.EncryptString(s_Guid);
                }
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// 
        /// </summary>
        ~LoginModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// 
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// 
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}