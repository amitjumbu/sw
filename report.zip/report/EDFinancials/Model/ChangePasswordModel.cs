﻿using EDFinancials.Model.Generic;
using EDFinancials.View;
using System;
using System.Data;
using System.Web;

namespace EDFinancials.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class ChangePasswordModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public ChangePasswordModel()
        {
            if (ac_ChangeForgetPassword == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ChangeForgetPassword);
                ac_ChangeForgetPassword = (CommonModel.AC_ChangeForgetPassword)HttpContext.Current.Session[CommonConstantModel.s_AC_ChangeForgetPassword];
            }
        }

        /// <summary>
        /// Method is used to bind UI 
        /// </summary>
        /// <param name="changePassword">Login Page object</param>
        internal void BindChangePasswordPageUI(ChangePassword changePassword)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    using (DataSet dataSetLoginUI = genericServiceClient.COMMON_LoadL10N_UI())
                    {
                        if ((dataSetLoginUI != null) && (dataSetLoginUI.Tables.Count > 0) && (dataSetLoginUI.Tables[0].Rows.Count > 0))
                        {
                            changePassword.lblCPUserName.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCPUserName'"))[0]["LabelName"]);
                            changePassword.lblCPUserName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCPUserName'"))[0]["LabelToolTip"]);
                            changePassword.valCPUserName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCPUserName'"))[0]["ErrorText"]);
                            changePassword.valCPUserName.SetFocusOnError = true;

                            changePassword.lblCPCompanyName.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCompanyName'"))[0]["LabelName"]);
                            changePassword.lblCPCompanyName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCompanyName'"))[0]["LabelToolTip"]);
                            changePassword.valCPCompanyName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCompanyName'"))[0]["ErrorText"]);
                            changePassword.valCPCompanyName.SetFocusOnError = true;

                            changePassword.lblPassword.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblPassword'"))[0]["LabelName"]);
                            changePassword.lblPassword.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblPassword'"))[0]["LabelToolTip"]);
                            changePassword.lblPassword.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblPassword'"))[0]["ErrorText"]);
                            changePassword.rfvCPPassword.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'rfvCPPassword'"))[0]["LabelToolTip"]);

                            changePassword.lblConfirmPassword.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblConfirmPassword'"))[0]["LabelName"]);
                            changePassword.lblConfirmPassword.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblConfirmPassword'"))[0]["LabelToolTip"]);
                            changePassword.lblConfirmPassword.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblConfirmPassword'"))[0]["ErrorText"]);
                            changePassword.rfvCPConfirmPassword.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'rfvCPConfirmPassword'"))[0]["LabelToolTip"]);

                            changePassword.Header1.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'Header1'"))[0]["LabelName"]);

                            changePassword.btnCPSubmit.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'btnCPSubmit'"))[0]["LabelName"]);
                            changePassword.btnCPSubmit.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'btnCPSubmit'"))[0]["LabelToolTip"]);

                            changePassword.txtCPUserName.Focus();
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="changePassword"></param>
        /// <param name="EncryptedData"></param>
        internal void ValidateUserInfo(ChangePassword changePassword, string[] EncryptedData)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                ac_ChangeForgetPassword.s_CompanyName = genericServiceClient.DecryptString(EncryptedData[0].Replace("%2B", "+"));
                ac_ChangeForgetPassword.s_LoginID = genericServiceClient.DecryptString(EncryptedData[1].Replace("%2B", "+"));
                ac_ChangeForgetPassword.s_Date = genericServiceClient.DecryptString(EncryptedData[2].Replace("%2B", "+"));

                if (Convert.ToInt32((Convert.ToDateTime(DateTime.Now) - Convert.ToDateTime(ac_ChangeForgetPassword.s_Date)).TotalDays) <= 3)
                {
                    using (DataTable dt_LoginInformation = genericServiceClient.ValiadateUserID(ac_ChangeForgetPassword.s_CompanyName, ac_ChangeForgetPassword.s_LoginID))
                    {
                        changePassword.txtCPUserName.Text = Convert.ToString(dt_LoginInformation.Rows[0]["LOGIN_ID"]);
                        changePassword.txtCPCompanyName.Text = ac_ChangeForgetPassword.s_CompanyName.ToUpper();

                        changePassword.txtCPUserName.Enabled = false;
                        changePassword.txtCPCompanyName.Enabled = false;
                    }
                }
                else
                {
                    changePassword.main.Visible = false;
                    changePassword.URLExpired.Visible = true;
                    changePassword.lblURLExpired.Text = new GenericServiceClient().COMMON_LoadL10N("lblURLExpired");
                }
            }
        }

        /// <summary>
        /// Method is used check login user is valid or not
        /// </summary>
        /// <param name="changePassword">Login Page object</param>
        /// <returns>return string as Redirect page name for respective user type</returns>
        internal string ChangePassword(ChangePassword changePassword)
        {
            try
            {
                string s_RedirectMessage = string.Empty;
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericServiceClient.ChangePassword(changePassword.txtPassword.Text, ac_ChangeForgetPassword.s_LoginID, ac_ChangeForgetPassword.s_CompanyName);
                    changePassword.lblCPSuccessMsg.Text = genericServiceClient.ChangePassword(changePassword.txtPassword.Text, ac_ChangeForgetPassword.s_LoginID, ac_ChangeForgetPassword.s_CompanyName).Equals(1)
                                                          ? new GenericServiceClient().COMMON_LoadL10N("lblCPSuccessMsg") : "";
                    changePassword.Visible = true;
                    changePassword.main.Visible = true;
                    changePassword.Success.Visible = true;
                }

                return s_RedirectMessage;
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ChangePasswordModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}