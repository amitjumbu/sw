﻿using EDFinancials.Model.Generic;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Principal;
using System.Web;

namespace EDFinancials.Model.Reports
{
    /// <summary>
    /// 
    /// </summary>
    public class ReportsModel : BaseModel, IDisposable
    {
        #region All Vairables
        private string UID = string.Empty;
        private string PASS = string.Empty;
        private string ServerName = string.Empty;
        private string SSRSReportPath = ConfigurationManager.AppSettings["SSRSReportPath"];
        private string TitleName = string.Empty;
        private string ReportName = string.Empty;
        private string RptID = string.Empty;
        private string GrpNo = string.Empty;
        private string FGAID = string.Empty;
        private string FORFEITUREGROUP = string.Empty;
        private string DATE_OF_GRANT = string.Empty;
        private string REPORTING_DATE = string.Empty;
        private string MARKET_PRICE_TYPE = string.Empty;
        private string SCHEME_NAME = string.Empty;
        private string EMPLOYEE_ID = string.Empty;
        private string EMPLOYEE_NAME = string.Empty;
        private string GRANT_REG_ID = string.Empty;
        private string GRANT_OPTION_ID = string.Empty;
        private string SENIOR_MANAGEMENT = string.Empty;
        private string GRANT_FROM_DATE = string.Empty;
        private string GRANT_TO_DATE = string.Empty;
        private string DISPLAY_COST_FOR = string.Empty;
        private string COST_FOR_FYNC_YR_FROM = string.Empty;
        private string COST_FOR_FYNC_YR_TO = string.Empty;
        private string COST_FOR_FYNC_QTR_FROM = string.Empty;
        private string COST_FOR_FYNC_QTR_TO = string.Empty;
        private string COST_FOR_FYNC_MONTH_FROM = string.Empty;
        private string COST_FOR_FYNC_MONTH_TO = string.Empty;
        private string TRANSFER_CASES = string.Empty;
        private string TRANSFER_CASES_FROM_DATE = string.Empty;
        private string TRANSFER_CASES_TO_DATE = string.Empty;
        private string OPTIONS = string.Empty;
        private string CANCELLATION_FROM_DATE = string.Empty;
        private string CANCELLATION_TO_DATE = string.Empty;
        private string ACC_RPT_GROUP_ID = string.Empty;
        private string VERSION_NUMBER = string.Empty;
        private string CALCULATION_METHOD = string.Empty;
        private string DISPLAY_COST_BEFORE = string.Empty;
        private string DISPLAY_COST_AFTER = string.Empty;
        private string IS_EMP_ACCESS = string.Empty;
        private string LEVEL1 = string.Empty;
        private string LEVEL2 = string.Empty;
        private string LEVEL3 = string.Empty;
        private string LEVEL4 = string.Empty;
        private string LEVEL5 = string.Empty;
		private string GrantRegistrationID = string.Empty;
        private string VestingPeriodID = string.Empty;
        private string COMPANY_NAME = string.Empty;
        private string COMPANY_NAME_PARM = string.Empty;
        private string REPORT_STATUS = string.Empty;
        private string PENDING_STAGE = string.Empty;
        private string USERS_NAME = string.Empty;
        private string MODULE_NAME = string.Empty;
        private string FROM_DATE = string.Empty;
        private string TO_DATE = string.Empty; 
        private string _rptName = string.Empty;
        private string strURL = string.Empty;
        private string DATE_CONSIDER_FOR_UNVESTED_OPTIONS = string.Empty; 
        private Hashtable hashtable = new Hashtable();
        #endregion


        /// <summary>
        /// Constructor for ReportsModel
        /// </summary>
        public ReportsModel()
        {
            hashtable.Add("1", "FairValuation|Fair Valuation");
            hashtable.Add("2", "AdjustedMarketPrice|Adjusted Market Price Details");
            hashtable.Add("3", "MarketPrice_Unlisted|Market Price Details");
            hashtable.Add("4", "CompanyDetails|View Company Details");
            hashtable.Add("5", "Volatility|Volatility");
            hashtable.Add("6", "EmployeeMaster|View Employee Master Details");
            hashtable.Add("7", "ForfeitureGroupEmpList|Forfeiture Group Employee List");
            hashtable.Add("8", "ForfeitureRateCalculations|Forfeiture Rate Calculations");
            hashtable.Add("9", "EDLModification|Estimated Date of Listing and Modification");
            hashtable.Add("10", "OptionDetails|Option Details");
            hashtable.Add("11", "HistoricalCost|Historical Cost");
            hashtable.Add("12", "AccountingReport|Accounting Report");
            hashtable.Add("13", "AccountingReport_Vestwise|Vestwise Report");
            hashtable.Add("14", "AccountingCancellationWorking|Cancellation Report");
            hashtable.Add("15", "SummaryWorking_Grantwise|Summary Report");
            hashtable.Add("16", "SummaryWorking_Vestwise|Summary Report");
			hashtable.Add("17", "MissingVolatilityDates|Missing Volatility Dates");
            hashtable.Add("18", "DW_OptionDetailsVestWise|Option Vestwise Details");
            hashtable.Add("19", "StatusReport|Status Report Details");
            hashtable.Add("20", "StatusReportValuation|Status Report Valuation Details");
            hashtable.Add("21", "StatusReportAccounting|Status Report Accounting Details");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reports"></param>
        internal void Page_Load(View.Reports.Reports reports)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {

                    if (reports.Request.QueryString.Count.Equals(0)) return;

                    DecryptQueryString(reports);
                    SetReportName(reports);

                    UID = genericServiceClient.DecryptString(ConfigurationManager.AppSettings["SSRS_UID"]);
                    PASS = genericServiceClient.DecryptString(ConfigurationManager.AppSettings["SSRS_PASS"]);
                    ServerName = genericServiceClient.DecryptString(ConfigurationManager.AppSettings["SSRS_DomainName"]);

                    reports.EDRptViewer.SizeToReportContent = true;
                    reports.EDRptViewer.ProcessingMode = ProcessingMode.Remote;
                    reports.EDRptViewer.PreRender += (EDRptViewer_PreRender);
                    reports.Title = TitleName;
                    reports.EDRptViewer.ServerReport.ReportPath = SSRSReportPath + ReportName;
                    reports.EDRptViewer.ServerReport.ReportServerUrl = new Uri(ConfigurationManager.AppSettings["SSRS_URL"]);
                    IReportServerCredentials irsc = new MyReportServerCredentials(UID, PASS, ServerName);
                    reports.EDRptViewer.ServerReport.ReportServerCredentials = irsc;
                    reports.EDRptViewer.ShowParameterPrompts = true;
                    reports.EDRptViewer.AsyncRendering = true;
                    reports.EDRptViewer.ShowPrintButton = true;
                    reports.EDRptViewer.ServerReport.SetParameters(SetParametersToReport(reports));
                    reports.EDRptViewer.ServerReport.Refresh();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reports"></param>
        private void SetReportName(View.Reports.Reports reports)
        {
            try
            {
                ReportName = hashtable[RptID].ToString().Split('|')[0];
                TitleName = hashtable[RptID].ToString().Split('|')[1];
                reports.EDRptViewer.ServerReport.DisplayName = userSessionInfo.ACC_CompanyTitle.ToString() + "_" + ReportName;

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reports"></param>
        private void DecryptQueryString(View.Reports.Reports reports)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    RptID = string.Empty;
                    foreach (string perQS in Convert.ToString(reports.Request.QueryString).Split('&'))
                    {
                        string s_QueryString = genericServiceClient.DecryptString(HttpUtility.UrlDecode(perQS.Replace("%2B", "+")));
                        switch (s_QueryString.Split('=')[0].ToString().ToUpper())
                        {
                            case "RPTID":
                                RptID = s_QueryString.Split('=')[1];
                                break;

                            case "GRPNO":
                                GrpNo = s_QueryString.Split('=')[1];
                                break;

                            case "FGAID":
                                FGAID = s_QueryString.Split('=')[1];
                                break;

                            case "FORFEITUREGROUP":
                                FORFEITUREGROUP = s_QueryString.Split('=')[1];
                                break;
                           
                            case "MARKET_PRICE_TYPE":
                                MARKET_PRICE_TYPE = s_QueryString.Split('=')[1];
                                break;

                            case "GRANT_OPTION_ID":
                                GRANT_OPTION_ID = s_QueryString.Split('=')[1];
                                break;

                            case "REPORTING_DATE":
                                REPORTING_DATE = s_QueryString.Split('=')[1];
                                break;

                            case "GRANT_REG_ID":
                                GRANT_REG_ID = s_QueryString.Split('=')[1];
                                break;

                            case "EMPLOYEE_ID":
                                EMPLOYEE_ID = s_QueryString.Split('=')[1];
                                break;

                            case "EMPLOYEE_NAME":
                                EMPLOYEE_NAME = s_QueryString.Split('=')[1];
                                break;

                            case "DATE_OF_GRANT":
                                DATE_OF_GRANT = s_QueryString.Split('=')[1];
                                break;

                            case "SCHEME_NAME":
                                SCHEME_NAME = s_QueryString.Split('=')[1];
                                break;

                            case "SENIOR_MANAGEMENT":
                                SENIOR_MANAGEMENT = s_QueryString.Split('=')[1];
                                break;

                            case "GRANT_FROM_DATE":
                                GRANT_FROM_DATE = s_QueryString.Split('=')[1];
                                break;

                            case "GRANT_TO_DATE":
                                GRANT_TO_DATE = s_QueryString.Split('=')[1];
                                break;

                            case "DISPLAY_COST_FOR":
                                DISPLAY_COST_FOR = s_QueryString.Split('=')[1];
                                break;

                            case "COST_FOR_FYNC_YR_FROM":
                                COST_FOR_FYNC_YR_FROM = s_QueryString.Split('=')[1];
                                break;

                            case "COST_FOR_FYNC_YR_TO":
                                COST_FOR_FYNC_YR_TO = s_QueryString.Split('=')[1];
                                break;

                            case "COST_FOR_FYNC_QTR_FROM":
                                COST_FOR_FYNC_QTR_FROM = s_QueryString.Split('=')[1];
                                break;

                            case "COST_FOR_FYNC_QTR_TO":
                                COST_FOR_FYNC_QTR_TO = s_QueryString.Split('=')[1];
                                break;

                            case "COST_FOR_FYNC_MONTH_FROM":
                                COST_FOR_FYNC_MONTH_FROM = s_QueryString.Split('=')[1];
                                break;

                            case "COST_FOR_FYNC_MONTH_TO":
                                COST_FOR_FYNC_MONTH_TO = s_QueryString.Split('=')[1];
                                break;

                            case "OPTIONS":
                                OPTIONS = s_QueryString.Split('=')[1];
                                break;

                            case "CANCELLATION_FROM_DATE":
                                CANCELLATION_FROM_DATE = s_QueryString.Split('=')[1];
                                break;

                            case "CANCELLATION_TO_DATE":
                                CANCELLATION_TO_DATE = s_QueryString.Split('=')[1];
                                break;

                            case "ACC_RPT_GROUP_ID":
                                ACC_RPT_GROUP_ID = s_QueryString.Split('=')[1];
                                break;

                            case "VERSION_NUMBER":
                                VERSION_NUMBER = s_QueryString.Split('=')[1];
                                break;

                            case "CALCULATION_METHOD":
                                CALCULATION_METHOD = s_QueryString.Split('=')[1];
                                break;

                            case "DISPLAY_COST_BEFORE":
                                DISPLAY_COST_BEFORE = s_QueryString.Split('=')[1];
                                break;

                            case "DISPLAY_COST_AFTER":
                                DISPLAY_COST_AFTER = s_QueryString.Split('=')[1];
                                break;

                            case "LEVEL1":
                                LEVEL1 = s_QueryString.Split('=')[1];
                                break;

                            case "LEVEL2":
                                LEVEL2 = s_QueryString.Split('=')[1];
                                break;

                            case "LEVEL3":
                                LEVEL3 = s_QueryString.Split('=')[1];
                                break;

                            case "LEVEL4":
                                LEVEL4 = s_QueryString.Split('=')[1];
                                break;

                            case "LEVEL5":
                                LEVEL5 = s_QueryString.Split('=')[1];
                                break;

                            case "IS_EMP_ACCESS":
                                IS_EMP_ACCESS = s_QueryString.Split('=')[1];
                                break;
 							
							case "GRANTREGISTRATIONID":
                                GrantRegistrationID = s_QueryString.Split('=')[1];
                                break;

                            case "VESTINGPERIODID":
                                VestingPeriodID = s_QueryString.Split('=')[1];
                                break;

                             case "DATE_CONSIDER_FOR_UNVESTED_OPTIONS":
                                DATE_CONSIDER_FOR_UNVESTED_OPTIONS = s_QueryString.Split('=')[1];
                                break;

							 case "COMPANY_NAME":
                                COMPANY_NAME = s_QueryString.Split('=')[1];
                                break;

                            case "COMPANY_NAME_PARM":
                                COMPANY_NAME_PARM = s_QueryString.Split('=')[1];
                                break;

                            case "REPORT_STATUS":
                                REPORT_STATUS = s_QueryString.Split('=')[1];
                                break;

                            case "PENDING_STAGE":
                                PENDING_STAGE = s_QueryString.Split('=')[1];
                                break;

                            case "USERS_NAME":
                                USERS_NAME = s_QueryString.Split('=')[1];
                                break;

                            case "MODULE_NAME":
                                MODULE_NAME = s_QueryString.Split('=')[1];
                                break;

                            case "FROM_DATE":
                                FROM_DATE = s_QueryString.Split('=')[1];
                                break;

                            case "TO_DATE":
                                TO_DATE = s_QueryString.Split('=')[1];
                                break; 
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void EDRptViewer_PreRender(object sender, EventArgs e)
        {
            try
            {
                // For PDF
                ShowHideExportFormat((ReportViewer)sender, "PDF", false);
                //For Tiff File
                ShowHideExportFormat((ReportViewer)sender, "IMAGE", false);
                //For XML File
                ShowHideExportFormat((ReportViewer)sender, "XML", false);
                //For CSV File
                ShowHideExportFormat((ReportViewer)sender, "CSV", false);
                //For MHTML File
                ShowHideExportFormat((ReportViewer)sender, "MHTML", false);
                //For WORD File 
                ShowHideExportFormat((ReportViewer)sender, "WORD", false);
                //For WORDOPENXML File 
                ShowHideExportFormat((ReportViewer)sender, "WORDOPENXML", false);
                //For EXCEL File 
                ShowHideExportFormat((ReportViewer)sender, "EXCEL", false);
                //For EXCELOPENXML File 
                ShowHideExportFormat((ReportViewer)sender, "EXCELOPENXML", true);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Show / Hide the special SSRS rendering format in ReportViewer control
        /// </summary>
        /// <param name="ReportViewerID">The ID of the relevant ReportViewer control</param>
        /// <param name="strFormatName">Format Name</param>
        /// <param name="isVisible"> </param>
        private void ShowHideExportFormat(ReportViewer ReportViewerID, string strFormatName, bool isVisible)
        {
            try
            {
                FieldInfo info;
                foreach (RenderingExtension extension in ReportViewerID.ServerReport.ListRenderingExtensions())
                {
                    if (extension.Name == strFormatName)
                    {
                        info = extension.GetType().GetField("m_isVisible", BindingFlags.Instance | BindingFlags.NonPublic);
                        info.SetValue(extension, isVisible);
                        break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to set the Datasource Server Name and Datasource Database Name to the SSRS report
        /// </summary>
        private IEnumerable<ReportParameter> SetParametersToReport(View.Reports.Reports reports)
        {
            var dataSourceCredentials = new Microsoft.Reporting.WebForms.DataSourceCredentials();
            ReportParameter[] reportParameterCollection = null;
            int intCnt = 0;

            switch (RptID)
            {
                case "1":
                case "5":
                    reportParameterCollection = new ReportParameter[4];
                    break;
                case "7":
                    reportParameterCollection = new ReportParameter[3];
                    break;
                case "12":
                    reportParameterCollection = new ReportParameter[20];
                    break;
                case "13":
                    reportParameterCollection = new ReportParameter[10];
                    break;
                case "14":
                    reportParameterCollection = new ReportParameter[27];
                    break;
                case "15":
                    reportParameterCollection = new ReportParameter[29];
                    break;
                case "16":
                    reportParameterCollection = new ReportParameter[29];
                    break;
                case "17":
                    reportParameterCollection = new ReportParameter[4];
                    break;
                case "19":
                    reportParameterCollection = new ReportParameter[5];
                    break;
                case "20":
                    reportParameterCollection = new ReportParameter[9];
                    break;
                case "21":
                    reportParameterCollection = new ReportParameter[11];
                    break;     
                default:
                    reportParameterCollection = new ReportParameter[2];
                    break;
            }

            try
            {
                string[] s_str = new string[] { };
                // Datasource being used by report
                foreach (var dataSource in reports.EDRptViewer.ServerReport.GetDataSources())
                {
                    dataSourceCredentials.Name = dataSource.Name;
                    dataSourceCredentials.UserId = ExtractConnectionStringFor("User ID=");
                    dataSourceCredentials.Password = ExtractConnectionStringFor("Password=");
                    reports.EDRptViewer.ServerReport.SetDataSourceCredentials(new Microsoft.Reporting.WebForms.DataSourceCredentials[1] { dataSourceCredentials });
                    reports.EDRptViewer.ShowCredentialPrompts = false;
                }


                //Setting Datasource Server Name
                reportParameterCollection[intCnt] = new ReportParameter();
                reportParameterCollection[intCnt].Name = "SERVER_NAME";
                reportParameterCollection[intCnt].Values.Add(ExtractConnectionStringFor("Data Source="));
                reportParameterCollection[intCnt].Visible = false;
                intCnt++;

                //Setting Datasource Database Name
                reportParameterCollection[intCnt] = new ReportParameter();
                reportParameterCollection[intCnt].Name = "DATABASE_NAME";
                reportParameterCollection[intCnt].Values.Add(userSessionInfo.ACC_CompanyName.ToString());
                reportParameterCollection[intCnt].Visible = false;
                intCnt++;

                switch (RptID)
                {
                    case "1":
                    case "5":
                        //Setting GROUP_NUMBER
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GROUP_NUMBER";
                        reportParameterCollection[intCnt].Values.Add(GrpNo);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                        {
                            //Setting SITE_URL
                            reportParameterCollection[intCnt] = new ReportParameter();
                            reportParameterCollection[intCnt].Name = "SITE_URL";
                            reportParameterCollection[intCnt].Values.Add(reports.Request.Url.AbsoluteUri.Split('?')[0] + "?" + Convert.ToString(genericServiceClient.EncryptString("RptID=" + (RptID.Equals("1") ? 5 : 1)) + "&" + genericServiceClient.EncryptString("GrpNo=" + GrpNo)));
                            reportParameterCollection[intCnt].Visible = false;
                            intCnt++;
                        }
                        break;
                    case "7":
                        //Setting FORFEITURE GROUP AUDIT ID
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "FGAID";
                        if(FGAID.Equals("0"))
                            reportParameterCollection[intCnt].Values.Add("ALL FORFEITURE GROUP");
                        else
                            reportParameterCollection[intCnt].Values.Add(FORFEITUREGROUP);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        break;
                    case "12":
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "REPORTING_DATE";
                        reportParameterCollection[intCnt].Values.Add(REPORTING_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "MARKET_PRICE_TYPE";
                        reportParameterCollection[intCnt].Values.Add(MARKET_PRICE_TYPE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;                        
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "SENIOR_MANAGEMENT";
                        reportParameterCollection[intCnt].Values.Add(SENIOR_MANAGEMENT);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GRANT_FROM_DATE";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(GRANT_FROM_DATE) ? null : GRANT_FROM_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GRANT_TO_DATE";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(GRANT_TO_DATE) ? null : GRANT_TO_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "DISPLAY_COST_FOR";
                        reportParameterCollection[intCnt].Values.Add(DISPLAY_COST_FOR);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_YR_FROM";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_YR_FROM);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_YR_TO";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_YR_TO);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_QTR_FROM";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_QTR_FROM);
                        reportParameterCollection[intCnt].Visible = DISPLAY_COST_FOR.Equals("Q");
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_QTR_TO";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_QTR_TO);
                        reportParameterCollection[intCnt].Visible = DISPLAY_COST_FOR.Equals("Q");
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_MONTH_FROM";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_MONTH_FROM);
                        reportParameterCollection[intCnt].Visible = DISPLAY_COST_FOR.Equals("M");
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_MONTH_TO";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_MONTH_TO);
                        reportParameterCollection[intCnt].Visible = DISPLAY_COST_FOR.Equals("M");
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "ACC_RPT_GROUP_ID";
                        reportParameterCollection[intCnt].Values.Add(ACC_RPT_GROUP_ID);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "VERSION_NUMBER";
                        reportParameterCollection[intCnt].Values.Add(VERSION_NUMBER);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "CALCULATION_METHOD";
                        reportParameterCollection[intCnt].Values.Add(CALCULATION_METHOD);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "DISPLAY_COST_BEFORE";
                        reportParameterCollection[intCnt].Values.Add(DISPLAY_COST_BEFORE);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "DISPLAY_COST_AFTER";
                        reportParameterCollection[intCnt].Values.Add(DISPLAY_COST_AFTER);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "IS_EMP_ACCESS";
                        reportParameterCollection[intCnt].Values.Add(IS_EMP_ACCESS);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        break;
                    case "13":
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "MARKET_PRICE_TYPE";
                        reportParameterCollection[intCnt].Values.Add(MARKET_PRICE_TYPE);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GRANT_OPTION_ID";
                        reportParameterCollection[intCnt].Values.Add(GRANT_OPTION_ID);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "REPORTING_DATE";
                        reportParameterCollection[intCnt].Values.Add(REPORTING_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GRANT_REG_ID";
                        reportParameterCollection[intCnt].Values.Add(GRANT_REG_ID);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "EMPLOYEE_ID";
                        reportParameterCollection[intCnt].Values.Add(EMPLOYEE_ID);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "EMPLOYEE_NAME";
                        reportParameterCollection[intCnt].Values.Add(EMPLOYEE_NAME);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "DATE_OF_GRANT";
                        reportParameterCollection[intCnt].Values.Add(DATE_OF_GRANT);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "IS_EMP_ACCESS";
                        reportParameterCollection[intCnt].Values.Add(IS_EMP_ACCESS);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        break;
                    case "14":
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "REPORTING_DATE";
                        reportParameterCollection[intCnt].Values.Add(REPORTING_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "MARKET_PRICE_TYPE";
                        reportParameterCollection[intCnt].Values.Add(MARKET_PRICE_TYPE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        if (!string.IsNullOrEmpty(SCHEME_NAME))
                        {
                            s_str = SCHEME_NAME.Split(',');
                            for (int i = 0; i < s_str.Length; i++)
                            {
                                reportParameterCollection[intCnt].Name = "SCHEME_NAME";
                                reportParameterCollection[intCnt].Values.Add(s_str[i]);
                            }
                        }
                        else
                        {
                            reportParameterCollection[intCnt].Name = "SCHEME_NAME";
                            reportParameterCollection[intCnt].Values.Add("");
                        }
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        if (!string.IsNullOrEmpty(EMPLOYEE_ID))
                        {
                            s_str = EMPLOYEE_ID.Split(',');
                            for (int i = 0; i < s_str.Length; i++)
                            {
                                reportParameterCollection[intCnt].Name = "EMPLOYEE_ID";
                                reportParameterCollection[intCnt].Values.Add(s_str[i]);
                            }
                        }
                        else
                        {
                            reportParameterCollection[intCnt].Name = "EMPLOYEE_ID";
                            reportParameterCollection[intCnt].Values.Add("");
                        }
                        reportParameterCollection[intCnt].Visible = IS_EMP_ACCESS.Equals("Y")? true :false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        if (!string.IsNullOrEmpty(EMPLOYEE_NAME))
                        {
                            s_str = EMPLOYEE_NAME.Split(',');
                            for (int i = 0; i < s_str.Length; i++)
                            {
                                reportParameterCollection[intCnt].Name = "EMPLOYEE_NAME";
                                reportParameterCollection[intCnt].Values.Add(s_str[i]);
                            }
                        }
                        else
                        {
                            reportParameterCollection[intCnt].Name = "EMPLOYEE_NAME";
                            reportParameterCollection[intCnt].Values.Add("");
                        }
                        reportParameterCollection[intCnt].Visible = IS_EMP_ACCESS.Equals("Y") ? true : false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        if (!string.IsNullOrEmpty(GRANT_REG_ID))
                        {
                            s_str = GRANT_REG_ID.Split(',');
                            for (int i = 0; i < s_str.Length; i++)
                            {
                                reportParameterCollection[intCnt].Name = "GRANT_REG_ID";
                                reportParameterCollection[intCnt].Values.Add(s_str[i]);
                            }
                        }
                        else
                        {
                            reportParameterCollection[intCnt].Name = "GRANT_REG_ID";
                            reportParameterCollection[intCnt].Values.Add("");
                        }
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        if (!string.IsNullOrEmpty(GRANT_OPTION_ID))
                        {
                            s_str = GRANT_OPTION_ID.Split(',');
                            for (int i = 0; i < s_str.Length; i++)
                            {
                                reportParameterCollection[intCnt].Name = "GRANT_OPTION_ID";
                                reportParameterCollection[intCnt].Values.Add(s_str[i]);
                            }
                        }
                        else
                        {
                            reportParameterCollection[intCnt].Name = "GRANT_OPTION_ID";
                            reportParameterCollection[intCnt].Values.Add("");
                        }
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "SENIOR_MANAGEMENT";
                        reportParameterCollection[intCnt].Values.Add(SENIOR_MANAGEMENT);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GRANT_FROM_DATE";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(GRANT_FROM_DATE) ? null : GRANT_FROM_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GRANT_TO_DATE";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(GRANT_TO_DATE) ? null : GRANT_TO_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "DISPLAY_COST_FOR";
                        reportParameterCollection[intCnt].Values.Add(DISPLAY_COST_FOR);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_YR_FROM";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_YR_FROM);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_YR_TO";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_YR_TO);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_QTR_FROM";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_QTR_FROM);
                        reportParameterCollection[intCnt].Visible = DISPLAY_COST_FOR.Equals("Q");
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_QTR_TO";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_QTR_TO);
                        reportParameterCollection[intCnt].Visible = DISPLAY_COST_FOR.Equals("Q");
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_MONTH_FROM";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_MONTH_FROM);
                        reportParameterCollection[intCnt].Visible = DISPLAY_COST_FOR.Equals("M");
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_MONTH_TO";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_MONTH_TO);
                        reportParameterCollection[intCnt].Visible = DISPLAY_COST_FOR.Equals("M");
                        intCnt++;
                        s_str = new string[] { "Vested Cancelled", "Unvested Cancelled", "Lapsed" };
                        reportParameterCollection[intCnt] = new ReportParameter();
                        for (int i = 0; i < s_str.Length; i++)
                        {
                            reportParameterCollection[intCnt].Name = "OPTIONS";
                            reportParameterCollection[intCnt].Values.Add(s_str[i]);
                        }
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "CANCELLATION_FROM_DATE";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(CANCELLATION_FROM_DATE) ? null : CANCELLATION_FROM_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "CANCELLATION_TO_DATE";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(CANCELLATION_TO_DATE) ? null : CANCELLATION_TO_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "ACC_RPT_GROUP_ID";
                        reportParameterCollection[intCnt].Values.Add(ACC_RPT_GROUP_ID);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "VERSION_NUMBER";
                        reportParameterCollection[intCnt].Values.Add(VERSION_NUMBER);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "CALCULATION_METHOD";
                        reportParameterCollection[intCnt].Values.Add(CALCULATION_METHOD);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "IS_EMP_ACCESS";
                        reportParameterCollection[intCnt].Values.Add(IS_EMP_ACCESS);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "DATE_CONSIDER_FOR_UNVESTED_OPTIONS";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(DATE_CONSIDER_FOR_UNVESTED_OPTIONS) ? null : DATE_CONSIDER_FOR_UNVESTED_OPTIONS);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        break;
                    case "15":
                    case "16":
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "REPORTING_DATE";
                        reportParameterCollection[intCnt].Values.Add(REPORTING_DATE);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "MARKET_PRICE_TYPE";
                        reportParameterCollection[intCnt].Values.Add(MARKET_PRICE_TYPE);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "SCHEME_NAME";
                        reportParameterCollection[intCnt].Values.Add(SCHEME_NAME);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "EMPLOYEE_ID";
                        reportParameterCollection[intCnt].Values.Add(EMPLOYEE_ID);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "EMPLOYEE_NAME";
                        reportParameterCollection[intCnt].Values.Add(EMPLOYEE_NAME);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GRANT_REGISTRATION_ID";
                        reportParameterCollection[intCnt].Values.Add(GRANT_REG_ID);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GRANT_OPTION_ID";
                        reportParameterCollection[intCnt].Values.Add(GRANT_OPTION_ID);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "SENIOR_MANAGEMENT";
                        reportParameterCollection[intCnt].Values.Add(SENIOR_MANAGEMENT);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GRANT_FROM_DATE";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(GRANT_FROM_DATE) ? null : GRANT_FROM_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GRANT_TO_DATE";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(GRANT_TO_DATE) ? null : GRANT_TO_DATE);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "DISPLAY_COST_FOR";
                        reportParameterCollection[intCnt].Values.Add(DISPLAY_COST_FOR);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_YR_FROM";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_YR_FROM);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_YR_TO";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_YR_TO);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_QTR_FROM";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_QTR_FROM);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_QTR_TO";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_QTR_TO);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_MONTH_FROM";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_MONTH_FROM);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COST_FOR_FYNC_MONTH_TO";
                        reportParameterCollection[intCnt].Values.Add(COST_FOR_FYNC_MONTH_TO);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "ACC_RPT_GROUP_ID";
                        reportParameterCollection[intCnt].Values.Add(ACC_RPT_GROUP_ID);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "VERSION_NUMBER";
                        reportParameterCollection[intCnt].Values.Add(VERSION_NUMBER);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "CALCULATION_METHOD";
                        reportParameterCollection[intCnt].Values.Add(CALCULATION_METHOD);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "DISPLAY_COST_BEFORE";
                        reportParameterCollection[intCnt].Values.Add(DISPLAY_COST_BEFORE);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "DISPLAY_COST_AFTER";
                        reportParameterCollection[intCnt].Values.Add(DISPLAY_COST_AFTER);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "LEVEL1";
                        reportParameterCollection[intCnt].Values.Add(LEVEL1);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "LEVEL2";
                        reportParameterCollection[intCnt].Values.Add(LEVEL2);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "LEVEL3";
                        reportParameterCollection[intCnt].Values.Add(LEVEL3);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "LEVEL4";
                        reportParameterCollection[intCnt].Values.Add(LEVEL4);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "LEVEL5";
                        reportParameterCollection[intCnt].Values.Add(LEVEL5);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;
                        break;

					case "17":
                        
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "GrantRegistrationID";
                        reportParameterCollection[intCnt].Values.Add(GrantRegistrationID);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "VestingPeriodID";
                        reportParameterCollection[intCnt].Values.Add(VestingPeriodID);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        break;
                   
                    case "19":
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COMPANY_NAME";
                        reportParameterCollection[intCnt].Values.Add(COMPANY_NAME);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "PAGE_INDEX";
                        reportParameterCollection[intCnt].Values.Add("1");
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "PAGE_SIZE";
                        reportParameterCollection[intCnt].Values.Add("1000");
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        break;

                    case "20":
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COMPANY_NAME_PARM";
                        reportParameterCollection[intCnt].Values.Add(null);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "REPORT_STATUS";
                        reportParameterCollection[intCnt].Values.Add(null);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "PENDING_STAGE";
                        reportParameterCollection[intCnt].Values.Add(null);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "USERS_NAME";
                        reportParameterCollection[intCnt].Values.Add(null);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "MODULE_NAME";
                        reportParameterCollection[intCnt].Values.Add(null);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "PAGE_INDEX";
                        reportParameterCollection[intCnt].Values.Add("1");
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "PAGE_SIZE";
                        reportParameterCollection[intCnt].Values.Add("1000");
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        break;

                    case "21":
                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "COMPANY_NAME_PARM";
                        reportParameterCollection[intCnt].Values.Add(null);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "REPORT_STATUS";
                        reportParameterCollection[intCnt].Values.Add(null);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "PENDING_STAGE";
                        reportParameterCollection[intCnt].Values.Add(null);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "USERS_NAME";
                        reportParameterCollection[intCnt].Values.Add(null);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "MODULE_NAME";
                        reportParameterCollection[intCnt].Values.Add(null);
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "FROM_DATE";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(FROM_DATE) ? null : FROM_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "TO_DATE";
                        reportParameterCollection[intCnt].Values.Add(string.IsNullOrEmpty(TO_DATE) ? null : TO_DATE);
                        reportParameterCollection[intCnt].Visible = true;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "PAGE_INDEX";
                        reportParameterCollection[intCnt].Values.Add("1");
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;

                        reportParameterCollection[intCnt] = new ReportParameter();
                        reportParameterCollection[intCnt].Name = "PAGE_SIZE";
                        reportParameterCollection[intCnt].Values.Add("1000");
                        reportParameterCollection[intCnt].Visible = false;
                        intCnt++;
                        break;
                   
                    default:
                        break;
                }
            }
            catch (System.Web.HttpUnhandledException)
            {
                // Do Nothing
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return reportParameterCollection;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        private string ExtractConnectionStringFor(string param)
        {
            var result = string.Empty;

            foreach (var value in Convert.ToString(ConfigurationManager.ConnectionStrings[1].ConnectionString).Split(';').Where(value => value.Contains(param)))
            {
                result = value.Replace(param, string.Empty);
            }
            return result;
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ReportsModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }

    /// <summary>
    /// 
    /// </summary>
    public class MyReportServerCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="DomainName"></param>
        public MyReportServerCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        /// <summary>
        /// 
        /// </summary>
        public WindowsIdentity ImpersonationUser
        {
            get
            {
                return null;  // not use ImpersonationUser
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public ICredentials NetworkCredentials
        {
            get
            {

                // use NetworkCredentials
                return new NetworkCredential(_UserName, _PassWord, _DomainName);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="authCookie"></param>
        /// <param name="user"></param>
        /// <param name="password"></param>
        /// <param name="authority"></param>
        /// <returns></returns>
        public bool GetFormsCredentials(out Cookie authCookie, out string user, out string password, out string authority)
        {
            // not use FormsCredentials unless you have implements a custom autentication.
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }
}