﻿
namespace EDFinancials.Model.Reports
{
    /// <summary>
    /// 
    /// </summary>
    public class BaseModel : EDFinancials.Model.BaseModel
    {
        /// <summary>
        /// 
        /// </summary>
        public BaseModel() 
        {

        }

    }
}