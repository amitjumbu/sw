﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// Model class for ManageStockExchangeModel.aspx
    /// </summary>
    public class ManageStockExchangeModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public ManageStockExchangeModel()
        {
            if (ac_ManageStockExchange == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageStockExchange);
                ac_ManageStockExchange = (CommonModel.AC_ManageStockExchange)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageStockExchange];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty;

        #endregion

        /// <summary>
        /// This method is used to populate all the controls 
        /// </summary>
        /// <param name="manageStockExchange">ManageStockExchange page object</param>
        public void PopulateAllControls(ManageStockExchange manageStockExchange)
        {
            try
            {
                BindAllLabelsFromL10N_UI(manageStockExchange);
                BindSearchFilters(manageStockExchange);
                BindCurrencyDropDown(manageStockExchange);
                BindGridview(manageStockExchange);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to bind all the labels from L10N_UI.xml
        /// </summary>
        /// <param name="manageStockExchange">ManageStockExchange page object</param>
        private void BindAllLabelsFromL10N_UI(ManageStockExchange manageStockExchange)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_ManageSEMUI = superAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_ManageStockExchange))
                    {
                        manageStockExchange.lblSEStockExchangeName.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEStockExchangeName'"))[0]["LabelName"]);
                        manageStockExchange.lblSEStockExchangeName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEStockExchangeName'"))[0]["LabelToolTip"]);
                        manageStockExchange.rfvStockExchangeName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEStockExchangeName'"))[0]["ErrorText"]);
                        manageStockExchange.lblSEShortName.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEShortName'"))[0]["LabelName"]);
                        manageStockExchange.lblSEShortName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEShortName'"))[0]["LabelToolTip"]);
                        manageStockExchange.rfvShortName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEShortName'"))[0]["ErrorText"]);
                        manageStockExchange.lblStockExchangeName.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEStockExchangeName'"))[0]["LabelName"]);
                        manageStockExchange.lblStockExchangeName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEStockExchangeName'"))[0]["LabelToolTip"]);
                        manageStockExchange.lblShortName.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEShortName'"))[0]["LabelName"]);
                        manageStockExchange.lblShortName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEShortName'"))[0]["LabelToolTip"]);
                        manageStockExchange.btnSESave.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSESave'"))[0]["LabelName"]);
                        manageStockExchange.btnSESave.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSESave'"))[0]["LabelToolTip"]);
                        manageStockExchange.btnSECancel.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSECancel'"))[0]["LabelName"]);
                        manageStockExchange.btnSECancel.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSECancel'"))[0]["LabelToolTip"]);
                        manageStockExchange.btnSEDeleteAll.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEDeleteAll'"))[0]["LabelName"]);
                        manageStockExchange.btnSEDeleteAll.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEDeleteAll'"))[0]["LabelToolTip"]);
                        manageStockExchange.btnSEApplyFilter.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEApplyFilter'"))[0]["LabelName"]);
                        manageStockExchange.btnSEApplyFilter.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEApplyFilter'"))[0]["LabelToolTip"]);
                        manageStockExchange.btnSEClearFilter.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEClearFilter'"))[0]["LabelName"]);
                        manageStockExchange.btnSEClearFilter.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEClearFilter'"))[0]["LabelToolTip"]);
                        manageStockExchange.btnSECreateNew.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSECreateNew'"))[0]["LabelName"]);
                        manageStockExchange.btnSECreateNew.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSECreateNew'"))[0]["LabelToolTip"]);
                        manageStockExchange.lblSESearchPanel.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSESearchPanel'"))[0]["LabelName"]);
                        manageStockExchange.lblSEAddEditPanel.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEAddEditPanel'"))[0]["LabelName"]);
                        manageStockExchange.lblSEPageHeader.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSEPageHeader'"))[0]["LabelName"]);
                        manageStockExchange.lblCurreny.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSECurrency'"))[0]["LabelName"]);
                        manageStockExchange.lblCurreny.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSECurrency'"))[0]["LabelToolTip"]);
                        manageStockExchange.lblSECurrency.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSECurrency'"))[0]["LabelName"]);
                        manageStockExchange.lblSECurrency.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSECurrency'"))[0]["LabelToolTip"]);
                        manageStockExchange.rfvSECurrency.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'rfvSECurrency'"))[0]["LabelToolTip"]);
                        manageStockExchange.gv.EmptyDataText = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblSENoRecordsFound'"))[0]["LabelName"]);
                        s_BtnUpdateText = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEUpdate'"))[0]["LabelName"]);
                        s_BtnUpdateToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEUpdate'"))[0]["LabelToolTip"]);
                        s_BtnSaveText = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSESave'"))[0]["LabelName"]);
                        s_BtnSaveTooltip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSESave'"))[0]["LabelToolTip"]);
                        ac_ManageStockExchange.s_BtnEditText = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEEdit'"))[0]["LabelName"]);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to bind Stock Exchange Details to gridview
        /// </summary>
        /// <param name="manageStockExchange">ManageStockExchange page object</param>
        public void BindGridview(ManageStockExchange manageStockExchange)
        {
            try
            {
                superAdminProperties = new SuperAdminProperties();
                superAdminProperties.StockExchangeName = (manageStockExchange.ddlStockExchangeName.SelectedItem.Value == "0") ? string.Empty : manageStockExchange.ddlStockExchangeName.SelectedItem.Text;
                superAdminProperties.ShortName = (manageStockExchange.ddlShortName.SelectedItem.Value == "0") ? string.Empty : manageStockExchange.ddlShortName.SelectedItem.Text;
                superAdminProperties.CRMID = Convert.ToInt32(manageStockExchange.ddlCurrency.SelectedItem.Value);

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.PageName = CommonConstantModel.s_ManageStockExchange;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_ManageStockExchange.dt_StockExchangeDetails = superAdminCRUDProperties.ds_Result.Tables[0];
                    ac_ManageStockExchange.dt_StockExchangeDetails.AcceptChanges();
                    manageStockExchange.gv.DataSource = ac_ManageStockExchange.dt_StockExchangeDetails;
                    manageStockExchange.gv.DataBind();
                }

                manageStockExchange.btnSEClearFilter.Visible = (manageStockExchange.ddlCurrency.SelectedValue != "0" || manageStockExchange.ddlStockExchangeName.SelectedValue != "0" || manageStockExchange.ddlShortName.SelectedValue != "0") ? true : false;
                manageStockExchange.btnSEDeleteAll.Visible = (ac_ManageStockExchange.dt_StockExchangeDetails.Rows.Count > 0) ? true : false;
                manageStockExchange.hdnID.Value = string.Empty;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to save/update data
        /// </summary>
        /// <param name="manageStockExchange">ManageStockExchange page object</param>
        /// <param name="s_Action">CUD action</param>
        public void SaveStockExchangeDetails(ManageStockExchange manageStockExchange, string s_Action)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties = new SuperAdminProperties();
                    superAdminProperties.StockExchangeName = string.IsNullOrEmpty(manageStockExchange.txtStockExchangeName.Text) ? string.Empty : manageStockExchange.txtStockExchangeName.Text;
                    superAdminProperties.ShortName = string.IsNullOrEmpty(manageStockExchange.txtShortName.Text) ? string.Empty : manageStockExchange.txtShortName.Text;

                    if (s_Action.Equals("C"))
                        superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;

                    superAdminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    superAdminProperties.Action = s_Action;
                    superAdminProperties.SEMultipleIDs = string.IsNullOrEmpty(manageStockExchange.hdnID.Value) ? "0" : manageStockExchange.hdnID.Value.TrimStart();
                    superAdminProperties.PageName = CommonConstantModel.s_ManageStockExchange;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CRMID = Convert.ToInt32(manageStockExchange.ddlSECurrency.SelectedItem.Value);

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                    switch (superAdminCRUDProperties.a_result)
                    {
                        case 1:
                            manageStockExchange.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblSESaveMessage");
                            manageStockExchange.hdnAccordionIndex.Value = "0";
                            manageStockExchange.h3AddEdit.Style.Add("display", "none");
                            manageStockExchange.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageStockExchange.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;
                        case 2:
                            manageStockExchange.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblSEUpdateMessage");
                            manageStockExchange.hdnAccordionIndex.Value = "0";
                            manageStockExchange.h3AddEdit.Style.Add("display", "none");
                            manageStockExchange.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageStockExchange.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;
                        case 3:
                            manageStockExchange.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblSEDeleteMessage");
                            manageStockExchange.h3AddEdit.Style.Add("display", "none");
                            manageStockExchange.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageStockExchange.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;
                        case 4:
                            manageStockExchange.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblSERecordAlreadyExists");
                            manageStockExchange.h3AddEdit.Style.Add("display", "block");
                            manageStockExchange.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageStockExchange.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;
                        case 5:
                            manageStockExchange.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblSEExistWithDeletedState");
                            manageStockExchange.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageStockExchange.ctrSuccessErrorMessage.s_RevOptionsDisplay = "block";
                            manageStockExchange.h3AddEdit.Style.Add("display", "block");
                            break;

                        default:
                            break;
                    }
                }
            }
            manageStockExchange.hdnID.Value = string.Empty;
        }

        /// <summary>
        /// This method is used to repopulate filter dropdowns
        /// </summary>
        /// <param name="manageStockExchange">ManageStockExchange page object</param>
        public void BindSearchFilters(ManageStockExchange manageStockExchange)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties = new SuperAdminProperties();
                    superAdminProperties.StockExchangeName = superAdminProperties.ShortName = string.Empty;
                    superAdminProperties.PageName = CommonConstantModel.s_ManageStockExchange;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_ManageStockExchange.ds_SEDetails = superAdminCRUDProperties.ds_Result;
                    ac_ManageStockExchange.dt_SEDetails = ac_ManageStockExchange.ds_SEDetails.Tables[0];

                    /* Bind Stock exchange name */
                    manageStockExchange.ddlStockExchangeName.DataSource = ac_ManageStockExchange.dt_SEDetails.AsEnumerable().Select(s => s.Field<string>("Stock Exchange Name")).ToArray<string>();
                    manageStockExchange.ddlStockExchangeName.DataBind();
                    BindToolTip(manageStockExchange.ddlStockExchangeName);
                    manageStockExchange.ddlStockExchangeName.Items.Insert(0, new ListItem("--- Please Select ---", "0"));

                    /* Bind Short name */
                    manageStockExchange.ddlShortName.DataSource = ac_ManageStockExchange.dt_SEDetails.AsEnumerable().Select(s => s.Field<string>("Short Name")).ToArray<string>();
                    manageStockExchange.ddlShortName.DataBind();
                    BindToolTip(manageStockExchange.ddlShortName);
                    manageStockExchange.ddlShortName.Items.Insert(0, new ListItem("--- Please Select ---", "0"));

                    /* Bind currency filter */
                    ac_ManageStockExchange.dt_Currencies = ac_ManageStockExchange.ds_SEDetails.Tables[1];
                    manageStockExchange.ddlCurrency.DataSource = ac_ManageStockExchange.dt_Currencies;
                    manageStockExchange.ddlCurrency.DataTextField = "Currency Name";
                    manageStockExchange.ddlCurrency.DataValueField = "ID";
                    manageStockExchange.ddlCurrency.DataBind();
                    manageStockExchange.ddlCurrency.Items.Insert(0, new ListItem("--- Please Select ---", "0"));
                    BindToolTip(manageStockExchange.ddlCurrency);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to populate currency grid
        /// </summary>
        /// <param name="manageStockExchange">ManageStockExchange page object</param>
        public void BindCurrencyDropDown(ManageStockExchange manageStockExchange)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties = new SuperAdminProperties();
                    superAdminProperties.CRMID = 0;
                    superAdminProperties.CRMAliasID = 0;
                    superAdminProperties.PageName = "CurrencyMaster";
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    SuperAdminCRUDProperties superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    manageStockExchange.ddlSECurrency.DataSource = superAdminCRUDProperties.dt_Result;
                    manageStockExchange.ddlSECurrency.DataTextField = "Currency Name";
                    manageStockExchange.ddlSECurrency.DataValueField = "ID";
                    manageStockExchange.ddlSECurrency.DataBind();
                    manageStockExchange.ddlSECurrency.Items.Insert(0, new ListItem("--- Please Select ---", "0"));
                    BindToolTip(manageStockExchange.ddlSECurrency);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Used to bind tool-tips to drop-down items
        /// </summary>
        /// <param name="list">ListControl object</param>
        private void BindToolTip(ListControl list)
        {
            foreach (ListItem item in list.Items)
            {
                item.Attributes.Add("title", item.Text);
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid-view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="n_index">index</param>
        /// <param name="n_ID">SEID row Index</param>
        /// <param name="n_Action">action row index</param>
        /// <param name="n_Delete">delete check-box row index</param>
        public void RowDataBindForGV(GridViewRowEventArgs e, ref int n_index, ref  int n_ID, ref int n_Action, ref int n_Delete)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "SEID":
                                n_ID = n_index;
                                perColumn.Visible = false;
                                break;

                            case "SELECT ALL":
                                n_Delete = n_index;
                                e.Row.Cells[n_Delete].Controls.Add(AddSelectAllCheckBox());
                                break;

                            case "STATUS":
                                perColumn.Visible = false;
                                break;

                            case "CODE":
                                perColumn.Visible = false;
                                break;

                            case "ACTION":
                                n_Action = n_index;
                                break;

                            case "CRMID":
                                perColumn.Visible = false;
                                break;
                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    e.Row.Cells[n_ID].Visible = e.Row.Cells[4].Visible = e.Row.Cells[8].Visible = e.Row.Cells[6].Visible = false;
                    e.Row.Cells[n_Action].HorizontalAlign = e.Row.Cells[n_Delete].HorizontalAlign = HorizontalAlign.Center;
                    e.Row.Cells[n_Action].Controls.Add((Control)AddImageLink(ac_ManageStockExchange.s_BtnEditText, "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[n_ID].Text, (string.IsNullOrEmpty(e.Row.Cells[6].Text) || e.Row.Cells[6].Text.Equals("&nbsp;")) ? "0" : e.Row.Cells[6].Text));
                    e.Row.Cells[n_Delete].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                    break;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_BtnEditText">this is Image button text</param>
        /// <param name="s_Url">image URL</param>
        /// <param name="s_StockExhchangeID">Stock Exchange ID</param>
        /// <param name="s_StockExhchangeName">Stock Exchange Name</param>
        /// <param name="s_ShortName">Short Name</param>
        /// <param name=" c_HdnID">this is HdnId</param>
        /// <param name="s_CRMID">this is CRMID</param>
        /// <returns>returns image button</returns>
        private ImageButton AddImageLink(string s_BtnEditText, string s_Url, string s_StockExhchangeID, string s_StockExhchangeName, string s_ShortName, string c_HdnID, string s_CRMID)
        {
            using (ImageButton img = new ImageButton())
            {
                img.ImageUrl = s_Url;
                img.ToolTip = s_BtnEditText;
                img.Style.Add("cursor", "pointer");
                img.Style.Add("text-align", "center");
                img.TabIndex = 8;
                img.Attributes.Add("onclick", "return ShowEditSection('" + s_StockExhchangeName + "','" + s_ShortName + "','" + c_HdnID + "','" + s_BtnUpdateText + "','" + s_CRMID + "')");
                return img;
            }
        }

        /// <summary>
        /// This method is used to add delete checkbox to gridview rows
        /// </summary>
        /// <param name="s_SEID">Stock Exchange ID</param>
        /// <param name="b_IsDeleted">Boolean value for Deleted</param>
        /// <returns>returns CheckBox control</returns>
        private CheckBox AddCheckBox(string s_SEID, bool b_IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_SEID);
                checkBox.ID = "chk";
                checkBox.ClientIDMode = ClientIDMode.Static;
                checkBox.Checked = b_IsDeleted;
                checkBox.TabIndex = 7;
                checkBox.Style.Add("cursor", "pointer");
                checkBox.Style.Add("text-align", "center");
                checkBox.Attributes.Add("name", "Types");
                if (!string.IsNullOrEmpty(s_SEID))
                {
                    checkBox.Attributes.Add("onclick", "DeleteSelectedRecords('" + s_SEID + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// This method is used to add delete all checkbox to gridview header
        /// </summary>
        /// <returns>returns checkbox control</returns>
        private CheckBox AddSelectAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chk";
                checkBox.Attributes.Add("name", "Types");
                checkBox.Text = string.Empty;
                checkBox.TabIndex = 6;
                checkBox.Style.Add("cursor", "pointer");
                checkBox.Attributes.Add("onclick", "SelectAllCheckBoxes(this)");
                return checkBox;
            }
        }

        /// <summary>
        /// Method to clear/reset all the controls
        /// </summary>
        /// <param name="manageStockExchange">ManageStockExchange page object</param>
        public void ResetAllControls(ManageStockExchange manageStockExchange)
        {
            try
            {
                manageStockExchange.btnSEClearFilter.Visible = false;
                PopulateAllControls(manageStockExchange);
                manageStockExchange.ddlCurrency.SelectedValue = manageStockExchange.ddlStockExchangeName.SelectedValue = manageStockExchange.ddlShortName.SelectedValue = "0";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// grid-view page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="manageStockExchange">ManageStockExchange page object</param>
        internal void PageIndexChanging(int NewPageIndex, ManageStockExchange manageStockExchange)
        {
            try
            {
                manageStockExchange.gv.PageIndex = NewPageIndex;
                manageStockExchange.gv.DataSource = ac_ManageStockExchange.dt_StockExchangeDetails;
                manageStockExchange.gv.DataBind();

                if (!string.IsNullOrEmpty(manageStockExchange.hdnID.Value))
                {
                    string[] s_StockExgIDs = manageStockExchange.hdnID.Value.TrimStart(',').Split(',');
                    foreach (string s_PerID in s_StockExgIDs)
                    {
                        foreach (DataRow perRow in ac_ManageStockExchange.dt_StockExchangeDetails.Select("SEID='" + s_PerID + "'"))
                        {
                            perRow["Select All"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to clear success/error message
        /// </summary>
        /// <param name="manageStockExchange">ManageStockExchange page object</param>
        public void ClearMessage(ManageStockExchange manageStockExchange)
        {
            manageStockExchange.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            manageStockExchange.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
        }

        /// <summary>
        /// This method is used to hide Add/Edit Section
        /// </summary>
        /// <param name="manageStockExchange">ManageStockExchange page object</param>
        public void HideAddEditSection(ManageStockExchange manageStockExchange)
        {
            manageStockExchange.h3AddEdit.Style.Add("display", "none");
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ManageStockExchangeModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}