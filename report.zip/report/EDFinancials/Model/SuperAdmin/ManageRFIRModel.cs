﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Data;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// Model class for ManageRFIRModel.aspx
    /// </summary>
    public class ManageRFIRModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public ManageRFIRModel()
        {
            if (ac_ManageRFIR == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageRFIR);
                ac_ManageRFIR = (CommonModel.AC_ManageRFIR)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageRFIR];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty;

        #endregion

        /// <summary>
        /// This method is used to populate all the controls 
        /// </summary>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        public void PopulateAllControls(ManageRFIR manageRFIR)
        {
            try
            {
                BindAllLabelsFromL10N_UI(manageRFIR);
                BindDropDown(manageRFIR);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all the dropdown controls
        /// </summary>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        private void BindDropDown(ManageRFIR manageRFIR)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.PageName = CommonConstantModel.s_ManageCountries;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.IsActive = 1;
                    superAdminProperties.CMID = 0;

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    using (DataTable dt_CountryList = superAdminCRUDProperties.dt_Result)
                    {
                        manageRFIR.ddlRFIRCountryList.ClearSelection();
                        manageRFIR.ddlRFIRCountryList.DataSource = dt_CountryList;
                        if (dt_CountryList.Rows.Count > 0)
                        {
                            manageRFIR.ddlRFIRCountryList.DataTextField = "Country Name";
                            manageRFIR.ddlRFIRCountryList.DataValueField = "Country Name";
                        }
                        manageRFIR.ddlRFIRCountryList.DataBind();
                        manageRFIR.ddlRFIRCountryList.Items.Insert(0, new ListItem("--- Please Select ---", "0"));
                        BindToolTip(manageRFIR.ddlRFIRCountryList);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Used to bind tooltips to dropdown items
        /// </summary>
        /// <param name="list">ListControl object</param>
        private void BindToolTip(ListControl list)
        {
            try
            {
                foreach (ListItem item in list.Items)
                {
                    item.Attributes.Add("title", item.Text);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to bind all the labels from L10N_UI.xml
        /// </summary>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        private void BindAllLabelsFromL10N_UI(ManageRFIR manageRFIR)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_ManageRFIRUI = superAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_ManageRFIR))
                    {
                        if ((dt_ManageRFIRUI != null) && (dt_ManageRFIRUI.Rows.Count > 0))
                        {
                            manageRFIR.lblRFIRSearchPanel.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRSearchPanel'"))[0]["LabelName"]);
                            manageRFIR.lblRFIRCountry.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRCountry'"))[0]["LabelName"]);
                            manageRFIR.lblRFIRCountry.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRCountry'"))[0]["LabelToolTip"]);
                            manageRFIR.lblRFIRFromDate.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRFromDate'"))[0]["LabelName"]);
                            manageRFIR.lblRFIRFromDate.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRFromDate'"))[0]["LabelToolTip"]);
                            manageRFIR.rfvRFIREditFromDate.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRFromDate'"))[0]["ErrorText"]);
                            manageRFIR.lblRFIRToDate.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRToDate'"))[0]["LabelName"]);
                            manageRFIR.lblRFIRToDate.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRToDate'"))[0]["LabelToolTip"]);
                            manageRFIR.btnRFIRApplyFilter.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRApplyFilter'"))[0]["LabelName"]);
                            manageRFIR.btnRFIRApplyFilter.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRApplyFilter'"))[0]["LabelToolTip"]);
                            manageRFIR.btnRFIRDeleteAll.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRDeleteAll'"))[0]["LabelName"]);
                            manageRFIR.btnRFIRDeleteAll.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRDeleteAll'"))[0]["LabelToolTip"]);
                            manageRFIR.btnRFIRClearFilter.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRClearFilter'"))[0]["LabelName"]);
                            manageRFIR.btnRFIRClearFilter.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRClearFilter'"))[0]["LabelToolTip"]);
                            manageRFIR.lblRFIREditFromDate.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRFromDate'"))[0]["LabelName"]);
                            manageRFIR.lblRFIREditFromDate.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRFromDate'"))[0]["LabelToolTip"]);
                            manageRFIR.lblRFIREditToDate.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRToDate'"))[0]["LabelName"]);
                            manageRFIR.lblRFIREditToDate.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRToDate'"))[0]["LabelToolTip"]);
                            manageRFIR.lblRFIREditSlot3to5Yrs.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot3to5Yrs'"))[0]["LabelName"]);
                            manageRFIR.lblRFIREditSlot3to5Yrs.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot3to5Yrs'"))[0]["LabelToolTip"]);
                            manageRFIR.rfvRFIREditSlot3to5Yrs.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot3to5Yrs'"))[0]["ErrorText"]);
                            manageRFIR.lblRFIREditSlot1to3Yrs.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot1to3Yrs'"))[0]["LabelName"]);
                            manageRFIR.lblRFIREditSlot1to3Yrs.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot1to3Yrs'"))[0]["LabelToolTip"]);
                            manageRFIR.rfvRFIREditSlot1to3Yrs.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot1to3Yrs'"))[0]["ErrorText"]);
                            manageRFIR.lblRFIREditSlot5to10Yrs.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot5to10Yrs'"))[0]["LabelName"]);
                            manageRFIR.lblRFIREditSlot5to10Yrs.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot5to10Yrs'"))[0]["LabelToolTip"]);
                            manageRFIR.rfvRFIREditSlot5to10Yrs.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot5to10Yrs'"))[0]["ErrorText"]);
                            manageRFIR.lblRFIREditSlot10PlusYrs.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot10PlusYrs'"))[0]["LabelName"]);
                            manageRFIR.lblRFIREditSlot10PlusYrs.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot10PlusYrs'"))[0]["LabelToolTip"]);
                            manageRFIR.rfvRFIREditSlot10PlusYrs.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIREditSlot10PlusYrs'"))[0]["ErrorText"]);
                            manageRFIR.btnRFIRSave.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRSave'"))[0]["LabelName"]);
                            manageRFIR.btnRFIRCancel.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRCancel'"))[0]["LabelName"]);
                            manageRFIR.btnRFIRCancel.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRCancel'"))[0]["LabelToolTip"]);
                            manageRFIR.lblRFIRPageHeader.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRPageHeader'"))[0]["LabelName"]);
                            manageRFIR.gv.EmptyDataText = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRNoRecordsFound'"))[0]["LabelName"]);
                            manageRFIR.lblRFIRAddEditPanel.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'lblRFIRAddEditPanel'"))[0]["LabelName"]);
                            manageRFIR.btnCSCreateNew.Text = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnCSCreateNew'"))[0]["LabelName"]);
                            manageRFIR.btnCSCreateNew.ToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnCSCreateNew'"))[0]["LabelToolTip"]);
                            s_BtnUpdateText = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRUpdate'"))[0]["LabelName"]);
                            s_BtnUpdateToolTip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRUpdate'"))[0]["LabelToolTip"]);
                            s_BtnSaveText = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRSave'"))[0]["LabelName"]);
                            s_BtnSaveTooltip = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIRSave'"))[0]["LabelToolTip"]);
                            ac_ManageRFIR.s_BtnEditText = Convert.ToString((dt_ManageRFIRUI.Select("LabelID = 'btnRFIREdit'"))[0]["LabelName"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="n_index">index</param>
        /// <param name="n_ID">RFIRID row Index</param>
        /// <param name="n_Action">action row index</param>
        /// <param name="n_Delete">delete checkbox row index</param>
        /// <param name="IsIndia">variable checks Whether Country is India </param>
        public void RowDataBindForGV(GridViewRowEventArgs e, ref int n_index, ref  int n_ID, ref int n_Action, ref int n_Delete, bool IsIndia)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SELECT ALL":
                                    n_ID = n_index;
                                    e.Row.Cells[n_ID].Controls.Add(AddSelectAllCheckBox());
                                    break;

                                case "RFIRID":
                                    perColumn.Visible = false;
                                    break;

                                case "SERVER_PATH":
                                    perColumn.Visible = false;
                                    break;

                                case "FILE NAME":
                                    perColumn.Visible = IsIndia;
                                    break;

                                case "DATE":
                                    perColumn.Visible = IsIndia;
                                    break;

                                case "DOWNLOAD":
                                    perColumn.Visible = IsIndia;
                                    n_Delete = n_index;
                                    break;

                                case "REFERENCE URL":
                                    perColumn.Visible = IsIndia;
                                    break;

                                case "COUNTRY":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "FROM DATE":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "1 - 3 YEARS":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "3 - 5 YEARS":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "5 - 10 YEARS":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "MORE THAN 10 YEARS":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "TO DATE":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "ACTION":
                                    perColumn.Visible = !IsIndia;
                                    n_Action = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_ID + 1].Visible = e.Row.Cells[n_ID + 2].Visible = false;
                        e.Row.Cells[3].Visible = e.Row.Cells[4].Visible = e.Row.Cells[5].Visible = e.Row.Cells[6].Visible = IsIndia;
                        e.Row.Cells[7].Visible = e.Row.Cells[8].Visible = e.Row.Cells[9].Visible = e.Row.Cells[10].Visible = e.Row.Cells[11].Visible = e.Row.Cells[12].Visible = e.Row.Cells[13].Visible = e.Row.Cells[14].Visible = !IsIndia;
                        e.Row.Cells[n_ID].HorizontalAlign = e.Row.Cells[n_Delete].HorizontalAlign = e.Row.Cells[n_Delete + 1].HorizontalAlign = e.Row.Cells[4].HorizontalAlign =
                            e.Row.Cells[n_Action].HorizontalAlign = e.Row.Cells[8].HorizontalAlign = e.Row.Cells[13].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[9].HorizontalAlign = e.Row.Cells[10].HorizontalAlign = e.Row.Cells[11].HorizontalAlign = e.Row.Cells[12].HorizontalAlign = HorizontalAlign.Right;
                        if (!string.IsNullOrEmpty(e.Row.Cells[6].Text) && !e.Row.Cells[6].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_Delete + 1].Controls.Add((Control)AddHyperLink("Click here to download", e.Row.Cells[6].Text));
                        if (IsIndia)
                        {
                            e.Row.Cells[4].Text = Convert.ToDateTime(e.Row.Cells[4].Text).ToString("dd/MMM/yyyy");
                            e.Row.Cells[n_Delete].Controls.Add((Control)AddImageLink("Click here to download", "~/View/App_Themes/images/download.png", e.Row.Cells[2].Text, e.Row.Cells[3].Text));
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(e.Row.Cells[8].Text))
                                e.Row.Cells[8].Text = Convert.ToDateTime(e.Row.Cells[8].Text).ToString("dd/MMM/yyyy");
                            if (!string.IsNullOrEmpty(e.Row.Cells[9].Text))
                                e.Row.Cells[9].Text = e.Row.Cells[9].Text + "%";
                            if (!string.IsNullOrEmpty(e.Row.Cells[10].Text))
                                e.Row.Cells[10].Text = e.Row.Cells[10].Text + "%";
                            if (!string.IsNullOrEmpty(e.Row.Cells[11].Text))
                                e.Row.Cells[11].Text = e.Row.Cells[11].Text + "%";
                            if (!string.IsNullOrEmpty(e.Row.Cells[12].Text))
                                e.Row.Cells[12].Text = e.Row.Cells[12].Text + "%";
                            if (!string.IsNullOrEmpty(e.Row.Cells[13].Text) && !e.Row.Cells[13].Text.Equals("&nbsp;"))
                                e.Row.Cells[13].Text = Convert.ToDateTime(e.Row.Cells[13].Text).ToString("dd/MMM/yyyy");
                            e.Row.Cells[n_Action].Controls.Add((Control)AddActionImageLink(ac_ManageRFIR.s_BtnEditText, "~/View/App_Themes/images/Edit.png", e.Row.Cells[1].Text, e.Row.Cells[8].Text, e.Row.Cells[9].Text, e.Row.Cells[10].Text, e.Row.Cells[11].Text, e.Row.Cells[12].Text, e.Row.Cells[13].Text));
                        }
                        e.Row.Cells[n_ID].Controls.Add(AddCheckBox(e.Row.Cells[1].Text, e.Row.Cells[n_ID].Text.Equals("1")));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add delete all checkbox to gridview header
        /// </summary>
        /// <returns>returns CheckBox control</returns>
        private CheckBox AddSelectAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chk";
                checkBox.Attributes.Add("name", "Types");
                checkBox.TabIndex = 6;
                checkBox.Style.Add("cursor", "pointer");
                checkBox.Attributes.Add("onclick", "SelectAllCheckBoxes(this)");
                return checkBox;
            }
        }

        /// <summary>
        /// This method is used to add delete checkbox to gridview rows
        /// </summary>
        /// <param name="s_RFIRID">RFIRID</param>
        /// <param name="b_IsDeleted">Delete check</param>
        /// <returns>return CheckBox control</returns>
        private CheckBox AddCheckBox(string s_RFIRID, bool b_IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_RFIRID);
                checkBox.ID = "chk";
                checkBox.ClientIDMode = ClientIDMode.Static;
                checkBox.Checked = b_IsDeleted;
                checkBox.TabIndex = 7;
                checkBox.Style.Add("cursor", "pointer");
                checkBox.Attributes.Add("name", "Types");
                if (!string.IsNullOrEmpty(s_RFIRID))
                {
                    checkBox.Attributes.Add("onclick", "DeleteSelectedRecords('" + s_RFIRID + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_ToolTip">Tooltip to image button</param>
        /// <param name="s_Url">image URL</param>
        /// <param name="s_ServerPath">server path to download file</param>
        /// <param name="s_FileName">File name</param>
        /// <returns></returns>
        private ImageButton AddImageLink(string s_ToolTip, string s_Url, string s_ServerPath, string s_FileName)
        {
            using (ImageButton img = new ImageButton())
            {
                img.ImageUrl = s_Url;
                img.ToolTip = s_ToolTip;
                img.Style.Add("cursor", "pointer");
                img.TabIndex = 8;
                img.Attributes.Add("onclick", "return SetHiddenFields('" + s_ServerPath.Replace("\\", "~") + "','" + s_FileName + "')");
                return img;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_ToolTip">image tooltip</param>
        /// <param name="s_Url">image URL</param>
        /// <param name="n_ID">image ID</param>
        /// <param name="s_FromDate">From Date</param>
        /// <param name="s_Slot1to3">input parameter</param>
        /// <param name="s_Slot3to5">input parameter</param>
        /// <param name="s_Slot5to10">input parameter</param>
        /// <param name="s_Slot10Plus">input parameter</param>
        /// <param name="s_ToDate">input parameter</param>
        /// <returns>returns ImageButton control</returns>
        private ImageButton AddActionImageLink(string s_ToolTip, string s_Url, string n_ID, string s_FromDate, string s_Slot1to3, string s_Slot3to5, string s_Slot5to10, string s_Slot10Plus, string s_ToDate)
        {
            using (ImageButton img = new ImageButton())
            {
                img.ImageUrl = s_Url;
                img.ToolTip = s_ToolTip;
                img.Style.Add("cursor", "pointer");
                img.TabIndex = 8;
                img.Attributes.Add("onclick", "return ShowEditPanel('" + n_ID + "','" + s_FromDate + "','" + s_Slot1to3 + "','" + s_Slot3to5 + "','" + s_Slot5to10 + "','" + s_Slot10Plus + "','" + s_ToDate + "')");
                return img;
            }
        }

        /// <summary>
        /// This is used to add hyperlink to gridview rows
        /// </summary>
        /// <param name="s_ToolTip">link tooltip</param>
        /// <param name="s_Url">link URL</param>
        /// <returns>returns HyperLink control</returns>
        private HyperLink AddHyperLink(string s_ToolTip, string s_Url)
        {
            using (HyperLink hyperLink = new HyperLink())
            {
                hyperLink.NavigateUrl = s_Url;
                hyperLink.Text = s_Url;
                hyperLink.ToolTip = s_ToolTip;
                hyperLink.TabIndex = 9;
                return hyperLink;
            }
        }

        /// <summary>
        /// Method to bind RFIR Details to gridview
        /// </summary>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        public void BindGridview(ManageRFIR manageRFIR)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.FROM_DATE = (string.IsNullOrEmpty(manageRFIR.datepickerFromDate.Value) || manageRFIR.datepickerFromDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(manageRFIR.datepickerFromDate.Value).ToString("MM/dd/yyyy");
                    superAdminProperties.TO_DATE = (string.IsNullOrEmpty(manageRFIR.datepickerToDate.Value) || manageRFIR.datepickerToDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(manageRFIR.datepickerToDate.Value).ToString("MM/dd/yyyy");
                    superAdminProperties.COUNTRY_NAME = manageRFIR.ddlRFIRCountryList.SelectedItem.Value.ToUpper();
                    superAdminProperties.PageName = CommonConstantModel.s_ManageRFIR;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_ManageRFIR.dt_RFIRDetails = superAdminCRUDProperties.dt_Result;
                    ac_ManageRFIR.dt_RFIRDetails.AcceptChanges();
                    manageRFIR.gv.DataSource = ac_ManageRFIR.dt_RFIRDetails;
                    manageRFIR.gv.DataBind();

                    manageRFIR.gv.Visible = true;
                    manageRFIR.btnRFIRClearFilter.Visible = (!manageRFIR.ddlRFIRCountryList.SelectedItem.Value.Equals("0") || !manageRFIR.datepickerFromDate.Value.Equals("dd/mmm/yyyy") || !manageRFIR.datepickerToDate.Value.Equals("dd/MMM/yyyy") || !string.IsNullOrEmpty(manageRFIR.datepickerFromDate.Value) || !string.IsNullOrEmpty(manageRFIR.datepickerToDate.Value)) ? true : false;
                    manageRFIR.btnRFIRDeleteAll.Visible = ac_ManageRFIR.dt_RFIRDetails.Rows.Count > 0 ? true : false;
                    manageRFIR.hdnID.Value = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">new page index</param>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        internal void PageIndexChanging(int NewPageIndex, ManageRFIR manageRFIR)
        {
            try
            {
                manageRFIR.gv.PageIndex = NewPageIndex;
                manageRFIR.gv.DataSource = ac_ManageRFIR.dt_RFIRDetails;
                manageRFIR.gv.DataBind();

                if (!string.IsNullOrEmpty(manageRFIR.hdnID.Value))
                {
                    string[] s_StockExgIDs = manageRFIR.hdnID.Value.TrimStart(',').Split(',');
                    foreach (string s_PerID in s_StockExgIDs)
                    {
                        foreach (DataRow perRow in ac_ManageRFIR.dt_RFIRDetails.Select("RFIRID='" + s_PerID + "'"))
                        {
                            perRow["Select All"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to save/update data
        /// </summary>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        /// <param name="s_Action">CUD action</param>
        public void SaveRFIRDetails(ManageRFIR manageRFIR, string s_Action)
        {
            try
            {
                if (s_Action.Equals("D") && string.IsNullOrEmpty(manageRFIR.hdnID.Value))
                {
                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        manageRFIR.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblRFIRSelectItemToDelete");
                    }
                }
                else
                {
                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                        {
                            superAdminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                            superAdminProperties.Action = s_Action;
                            superAdminProperties.RDFIRIDs = string.IsNullOrEmpty(manageRFIR.hdnID.Value) ? string.Empty : manageRFIR.hdnID.Value.TrimStart();
                            if (s_Action.Equals("C") || s_Action.Equals("U"))
                            {
                                superAdminProperties.COUNTRY_NAME = manageRFIR.ddlRFIRCountryList.SelectedItem.Value;
                                superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                                superAdminProperties.IsDeleted = false;
                                superAdminProperties.FROM_DATE = (string.IsNullOrEmpty(manageRFIR.txtRFIREditFromDate.Text) || manageRFIR.txtRFIREditFromDate.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(manageRFIR.txtRFIREditFromDate.Text).ToString("MM/dd/yyyy");
                                superAdminProperties.TO_DATE = (string.IsNullOrEmpty(manageRFIR.txtRFIREditToDate.Text) || manageRFIR.txtRFIREditToDate.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(manageRFIR.txtRFIREditToDate.Text).ToString("MM/dd/yyyy");
                                superAdminProperties.SLOT_1TO3YEARS = Convert.ToDecimal(manageRFIR.txtRFIREditSlot1to3Yrs.Text);
                                superAdminProperties.SLOT_3TO5YEARS = Convert.ToDecimal(manageRFIR.txtRFIREditSlot3to5Yrs.Text);
                                superAdminProperties.SLOT_5TO10YEARS = Convert.ToDecimal(manageRFIR.txtRFIREditSlot5to10Yrs.Text);
                                superAdminProperties.SLOT_MORETHAN10YEARS = Convert.ToDecimal(manageRFIR.txtRFIREditSlot10PlusYrs.Text);
                            }
                            superAdminProperties.PageName = CommonConstantModel.s_ManageRFIR;
                            superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                            superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                            int n_RetValue = superAdminCRUDProperties.a_result;
                            switch (n_RetValue)
                            {
                                case 1:
                                    manageRFIR.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblRFIRSaveMessage");
                                    manageRFIR.hdnAccordionIndex.Value = "0";
                                    manageRFIR.h3AddEdit.Style.Add("display", "none");
                                    manageRFIR.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    break;
                                case 2:
                                    manageRFIR.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblRFIRUpdateMessage");
                                    manageRFIR.hdnAccordionIndex.Value = "0";
                                    manageRFIR.h3AddEdit.Style.Add("display", "none");
                                    manageRFIR.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    break;
                                case 3:
                                    manageRFIR.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblRFIRDeleteMessage");
                                    manageRFIR.h3AddEdit.Style.Add("display", "none");
                                    manageRFIR.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    break;
                                case 4:
                                    manageRFIR.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblRFIRRecordAlreadyExists");
                                    manageRFIR.h3AddEdit.Style.Add("display", "block");
                                    manageRFIR.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    break;
                                default: break;
                            }
                        }
                    }
                }
                manageRFIR.hdnID.Value = string.Empty;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to clear success/error message
        /// </summary>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        public void ClearMessage(ManageRFIR manageRFIR)
        {
            manageRFIR.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
        }

        /// <summary>
        /// Method to clear/reset all the controls
        /// </summary>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        public void ResetAllControls(ManageRFIR manageRFIR)
        {
            try
            {
                manageRFIR.btnRFIRClearFilter.Visible = false;
                manageRFIR.datepickerFromDate.Value = manageRFIR.datepickerToDate.Value = string.Empty;
                manageRFIR.gv.Visible = false;
                manageRFIR.btnRFIRDeleteAll.Visible = false;
                manageRFIR.btnCSCreateNew.Visible = false;
                PopulateAllControls(manageRFIR);
                manageRFIR.trRFIRDateDiv.Style.Add("display", "none");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to download file from server folder
        /// </summary>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        public void DownloadFile(ManageRFIR manageRFIR)
        {
            try
            {
                using (WebClient o_WebClient = new WebClient())
                {
                    HttpResponse o_HttpResponse = HttpContext.Current.Response;
                    o_HttpResponse.Clear();
                    o_HttpResponse.ClearContent();
                    o_HttpResponse.ClearHeaders();
                    o_HttpResponse.Buffer = true;
                    manageRFIR.Response.AddHeader("Content-Disposition", "attachment;filename=" + manageRFIR.hdnFileName.Value);
                    o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(manageRFIR.hdnFileServerPath.Value.Replace("~", "\\")));
                    // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.Flush();
                    // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.Response.SuppressContent = true;
                    // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.  
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch
            {
                //Do nothing
            }
        }

        /// <summary>
        /// This method is used to show hide sections based on country selection
        /// </summary>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        public void ShowHideSections(ManageRFIR manageRFIR)
        {
            try
            {
                if (string.IsNullOrEmpty(manageRFIR.ddlRFIRCountryList.SelectedItem.Value) || manageRFIR.ddlRFIRCountryList.SelectedItem.Value.Equals("0"))
                {
                    manageRFIR.btnRFIRClearFilter.Visible = false;
                    manageRFIR.datepickerFromDate.Value = manageRFIR.datepickerToDate.Value = string.Empty;
                    manageRFIR.trRFIRDateDiv.Style.Add("display", "none");
                    manageRFIR.gv.Visible = false;
                    manageRFIR.btnRFIRDeleteAll.Visible = false;
                    manageRFIR.btnCSCreateNew.Visible = false;
                }
                else
                {
                    manageRFIR.trRFIRDateDiv.Style.Add("display", "");
                    BindGridview(manageRFIR);
                }
                manageRFIR.hdnID.Value = string.Empty;
                manageRFIR.btnCSCreateNew.Visible = (string.IsNullOrEmpty(manageRFIR.ddlRFIRCountryList.SelectedItem.Value) || manageRFIR.ddlRFIRCountryList.SelectedItem.Value.Equals("0") || manageRFIR.ddlRFIRCountryList.SelectedItem.Value.ToUpper().Equals("INDIA")) ? false : true;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to hide Add/Edit Section
        /// </summary>
        /// <param name="manageRFIR">ManageRFIR page object</param>
        public void HideAddEditSection(ManageRFIR manageRFIR)
        {
            manageRFIR.h3AddEdit.Style.Add("display", "none");
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ManageRFIRModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}