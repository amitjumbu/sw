﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// Model file for ManageSubModule.aspx.cs
    /// </summary>
    public class ManageSubModuleModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public ManageSubModuleModel()
        {
            if (ac_ManageModule == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageModule);
                ac_ManageModule = (CommonModel.AC_ManageModule)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageModule];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty;

        #endregion

        /// <summary>
        /// This Method is used to fetch messages from L10N xml via superadmin WCF service.
        /// </summary>
        /// <param name="MessegeId"></param>
        /// <returns>string as the message</returns>
        public string SAP_L10N(string MessegeId)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    return superAdminServiceClient.LoadL10N(MessegeId);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to load all label text from L10N_UI via wcf service
        /// </summary>
        /// <param name="manageSubModule">Parameter to get the entire page at model side using 'this' keyword</param>
        public void BindPageUI(ManageSubmodule manageSubModule)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_SubModuleUI = superAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_ManageSubModule))
                    {
                        if ((dt_SubModuleUI != null) && (dt_SubModuleUI.Rows.Count > 0))
                        {
                            manageSubModule.lblSMPagehead.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMPagehead'"))[0]["LabelName"]);
                            manageSubModule.lblSMName.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMName'"))[0]["LabelName"]);
                            manageSubModule.lblSMName.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMName'"))[0]["LabelToolTip"]);
                            manageSubModule.lblSMStatus.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMStatus'"))[0]["LabelName"]);
                            manageSubModule.lblSMStatus.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMStatus'"))[0]["LabelToolTip"]);
                            manageSubModule.lblSMNameEdit.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMNameEdit'"))[0]["LabelName"]);
                            manageSubModule.lblSMNameEdit.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMNameEdit'"))[0]["LabelToolTip"]);
                            manageSubModule.lblSMStatusEdit.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMStatusEdit'"))[0]["LabelName"]);
                            manageSubModule.lblSMStatusEdit.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMStatusEdit'"))[0]["LabelToolTip"]);
                            manageSubModule.BtnSMGridfilter.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='BtnSMGridfilter'"))[0]["LabelName"]);
                            manageSubModule.BtnSMGridfilter.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='BtnSMGridfilter'"))[0]["LabelToolTip"]);
                            manageSubModule.btnSMClearFilter.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='btnSMClearFilter'"))[0]["LabelName"]);
                            manageSubModule.btnSMClearFilter.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='btnSMClearFilter'"))[0]["LabelToolTip"]);
                            manageSubModule.btnSMCreateNew.Value = Convert.ToString((dt_SubModuleUI.Select("LabelID='btnSMCreateNew'"))[0]["LabelName"]);
                            manageSubModule.btnSMSubmit.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='btnSMSubmit'"))[0]["LabelName"]);
                            manageSubModule.btnSMSubmit.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='btnSMSubmit'"))[0]["LabelToolTip"]);
                            manageSubModule.btnSMCancel.Value = Convert.ToString((dt_SubModuleUI.Select("LabelID='btnSMCancel'"))[0]["LabelName"]);
                            manageSubModule.btnSMDelete.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='btnSMDelete'"))[0]["LabelName"]);
                            manageSubModule.btnSMDelete.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='btnSMDelete'"))[0]["LabelToolTip"]);
                            manageSubModule.lblSMAccordMngeHead.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMAccordMngeHead'"))[0]["LabelName"]);
                            manageSubModule.lblSMAccordMngeHead.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMAccordMngeHead'"))[0]["LabelToolTip"]);
                            manageSubModule.lblSMAccordEditHead.Text = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMAccordEditHead'"))[0]["LabelName"]);
                            manageSubModule.RqdFieldTxtEditMName.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMNameEdit'"))[0]["ErrorText"]);
                            manageSubModule.RegExpLoginId.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMNameEdit'"))[0]["ErrorText2"]);
                            manageSubModule.ValidateStatusEdit.ToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID='lblSMStatusEdit'"))[0]["ErrorText"]);
                            s_BtnUpdateText = Convert.ToString((dt_SubModuleUI.Select("LabelID = 'btnSMUpdate'"))[0]["LabelName"]);
                            s_BtnUpdateToolTip = Convert.ToString((dt_SubModuleUI.Select("LabelID = 'btnSMUpdate'"))[0]["LabelToolTip"]);
                            s_BtnSaveText = Convert.ToString((dt_SubModuleUI.Select("LabelID = 'btnSMSubmit'"))[0]["LabelName"]);
                            s_BtnSaveTooltip = Convert.ToString((dt_SubModuleUI.Select("LabelID = 'btnSMSubmit'"))[0]["LabelToolTip"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// This method is used to load content of IsActive dropdownlist
        /// </summary>
        internal void PerformCUD(ManageSubmodule manageSubModule, string MmId, string s_CRUDOpt)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                superAdminProperties.Id = MmId.Contains(",") ? 0 : Convert.ToInt32(MmId);
                superAdminProperties.Ids = MmId;
                superAdminProperties.Name = CommonModel.ReplaceApostrophe(manageSubModule.txtCreateEditSModuleName.Text);
                superAdminProperties.IsActive = Convert.ToInt16(manageSubModule.ddCreatenewIsActive.SelectedValue);
                superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                superAdminProperties.Action = s_CRUDOpt;
                superAdminProperties.PageName = CommonConstantModel.s_ManageSubModule;
                superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                try
                {
                    switch (superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result)
                    {
                        case 0:
                            manageSubModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMError");
                            manageSubModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            manageSubModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;

                        case 1:
                            manageSubModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMSAdded");
                            manageSubModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            manageSubModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;


                        case 2:

                            manageSubModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblSMUpdated");
                            manageSubModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            manageSubModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;


                        case 3:
                            manageSubModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMSDeleted");
                            manageSubModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            manageSubModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;

                        case 4:
                            manageSubModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblSMNameExist");
                            manageSubModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            manageSubModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;

                        case 5:
                            manageSubModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblSMReverse");
                            manageSubModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            manageSubModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "block";
                            ac_ManageModule.reversingModuleName = superAdminProperties.Name;
                            ac_ManageModule.reversingModuleStatus = superAdminProperties.IsActive;
                            break;

                        case 7:
                            manageSubModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblSMSubModCantBeDeleted");
                            manageSubModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            manageSubModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;
                    }
                    manageSubModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    manageSubModule.txtCreateEditSModuleName.Text = "";
                    manageSubModule.ddCreatenewIsActive.SelectedIndex = 0;
                    manageSubModule.updGridView.Update();
                    manageSubModule.UpdMessages.Update();
                }
                catch
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// This method reverse the deleted item and makes it usable again
        /// </summary>
        /// <param name="manageSubmodule">Manage_Module Page</param>
        public void ReverseDeletedRecord(ManageSubmodule manageSubmodule)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.Name = ac_ManageModule.reversingModuleName;
                    superAdminProperties.IsActive = ac_ManageModule.reversingModuleStatus;
                    superAdminProperties.Action = "REV";
                    superAdminProperties.PageName = CommonConstantModel.s_ManageSubModule;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                    switch (superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result)
                    {
                        case 0:
                            manageSubmodule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMError");
                            manageSubmodule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageSubmodule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;

                        case 6:
                            manageSubmodule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblSMUpdated");
                            manageSubmodule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageSubmodule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            break;
                    }
                    manageSubmodule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                    manageSubmodule.UpdMessages.Update();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to load gridview data 
        /// </summary>
        /// <returns></returns>
        public void LoadGridData(ManageSubmodule manageSubmodule, string s_CRUDOpt)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.Name = manageSubmodule.ddSModuleName.SelectedItem != null ? manageSubmodule.ddSModuleName.SelectedItem.ToString() : ""; ;
                    superAdminProperties.IsActive = Convert.ToInt16(manageSubmodule.ddIsActive.SelectedValue);
                    superAdminProperties.Action = s_CRUDOpt;
                    superAdminProperties.PageName = CommonConstantModel.s_ManageSubModule;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    ac_ManageModule.dt_GridViewDataTable = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result;
                    manageSubmodule.gv.DataSource = ac_ManageModule.dt_GridViewDataTable;
                    manageSubmodule.gv.DataBind();
                    manageSubmodule.updGridView.Update();

                    manageSubmodule.btnSMDelete.Visible = manageSubmodule.gv.Rows.Count > 0 ? true : false;
                    manageSubmodule.btnSMClearFilter.Visible = false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Filters Gridview data according to the parameters selected
        /// </summary>
        /// <param name="manageSubmodule">Sub Module Page</param>
        public void FilterGridData(ManageSubmodule manageSubmodule)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                try
                {
                    string s_ModuleName = manageSubmodule.ddSModuleName.SelectedIndex > 0 ? "[SubModule Name] = '" + Convert.ToString(manageSubmodule.ddSModuleName.SelectedValue) + "'" : string.Empty;
                    string s_Status = manageSubmodule.ddIsActive.SelectedItem.ToString() != "--- Please Select ---" ? "[Status] = '" + Convert.ToString(manageSubmodule.ddIsActive.SelectedItem.ToString()) + "'" : string.Empty;


                    if ((!(string.IsNullOrEmpty(s_ModuleName))) || (!(string.IsNullOrEmpty(s_Status))))
                    {
                        manageSubmodule.btnSMClearFilter.Visible = true;
                        manageSubmodule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    }

                    ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_GridViewDataTable;

                    try
                    {
                        if (!(string.IsNullOrEmpty(s_ModuleName)))
                            ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_ModuleDataTable.Select("" + s_ModuleName + "").CopyToDataTable();

                        if (!(string.IsNullOrEmpty(s_Status)))
                            ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_ModuleDataTable.Select("" + s_Status + "").CopyToDataTable();

                        if ((string.IsNullOrEmpty(s_Status) && string.IsNullOrEmpty(s_ModuleName)))
                        {
                            ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_GridViewDataTable;
                            manageSubmodule.btnSMClearFilter.Visible = false;
                        }
                    }
                    catch
                    {
                        ac_ManageModule.dt_ModuleDataTable = new DataTable();
                    }

                    manageSubmodule.gv.DataSource = ac_ManageModule.dt_ModuleDataTable;
                    manageSubmodule.gv.DataBind();
                    manageSubmodule.updGridView.Update();
                    manageSubmodule.btnSMDelete.Visible = manageSubmodule.gv.Rows.Count > 0 ? true : false;
                }
                catch
                {
                    throw;
                }

                manageSubmodule.updGridView.Update();
                manageSubmodule.btnSMDelete.Visible = manageSubmodule.gv.Rows.Count > 0 ? true : false;
            }
        }

        /// <summary>
        /// load Module_Name dropdownlist
        /// </summary>
        /// <returns>DropDownList</returns>
        public DropDownList loadModuleNameDropdown(DropDownList dropdownlist)
        {
            try
            {
                superAdminProperties.Action = "N";
                superAdminProperties.PageName = CommonConstantModel.s_ManageSubModule;
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    dropdownlist.DataSource = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result;
                    dropdownlist.DataTextField = "SUB_MODULE_NAME";
                    dropdownlist.DataBind();
                }

                return dropdownlist;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// load IsActive selection dropdownlist
        /// </summary>
        /// <param name="dropDownList"></param>
        /// <param name="s_Action"></param>
        /// <returns></returns>
        public DropDownList Load_ddIsactive(DropDownList dropDownList, String s_Action)
        {

            try
            {
                superAdminProperties.Action = s_Action;
                superAdminProperties.PageName = CommonConstantModel.s_ManageSubModule;
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;

                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    dropDownList.DataSource = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result;
                    dropDownList.DataTextField = "DATA";
                    dropDownList.DataValueField = "VALUE";
                    dropDownList.DataBind();
                }
                return dropDownList;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add Delete all checkbox
        /// </summary>
        /// <returns>CheckBox</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chkDeleteAll";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Text = string.Empty;
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }

        }

        /// <summary>
        /// Binds Row of gridview and restructures column according to needs.
        /// </summary>
        /// <param name="e">Gridview Row Event Argum.</param>
        /// <param name="n_index">index number</param>
        /// <param name="n_ID">SMID</param>
        /// <param name="n_Delete">Row  Id to be deleted</param>
        /// <param name="n_Action">Action to be performed</param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "SMID":
                                n_ID = n_index;
                                perColumn.Visible = false;
                                break;

                            case "DELETE":
                                n_Delete = n_index;
                                e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());

                                break;

                            case "ACTION":
                                n_Action = n_index;
                                break;
                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    try
                    {
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, "Edit"));
                        e.Row.Cells[1].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        e.Row.Cells[n_Delete].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        break;
                    }
                    catch
                    {
                        throw;
                    }
            }
        }

        /// <summary>
        /// This method adds image button to gridview Action column at runtime .
        /// </summary>
        /// <param name="s_strToolTip">ToolTip for Button</param>
        /// <param name="s_strUrl">Image Url</param>
        /// <param name="s_SMID">SubModule Id</param>
        /// <param name="s_SMName">SubModule Name</param>
        /// <param name="s_Status">status</param>
        /// <param name="s_Action">Action to be performed</param>
        /// <returns>Imagebutton</returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_SMID, string s_SMName, string s_Status, string s_Action)
        {
            int n_status = s_Status == "Activated" ? 2 : 1;
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");
                if (!string.IsNullOrEmpty(s_SMName))
                {
                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_SMName + "','" + n_status + "','" + s_SMID + "','" + 1 + "')");
                    }
                }
                return imgButton;
            }
        }

        /// <summary>
        /// this method adds checkboxes in the first column of the gridview 
        /// </summary>
        /// <param name="s_ManageModuleGroupID"></param>
        /// <param name="IsDeleted"></param>
        /// <returns></returns>
        private CheckBox AddCheckBox(string s_ManageModuleGroupID, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_ManageModuleGroupID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");
                if (!string.IsNullOrEmpty(s_ManageModuleGroupID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_ManageModuleGroupID + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// To change pages of gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <param name="gv"></param>
        /// <param name="s_ManageSubModuleGroupID"></param>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_ManageSubModuleGroupID)
        {
            try
            {
                string[] s_AssociateModuleGpID = s_ManageSubModuleGroupID.TrimStart(',').Split(',');
                foreach (string perID in s_AssociateModuleGpID)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_ManageModule.dt_GridViewDataTable.Select("SMID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_ManageModule.dt_GridViewDataTable;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ManageSubModuleModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}