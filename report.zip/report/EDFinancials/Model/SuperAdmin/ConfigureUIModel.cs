﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// 
    /// </summary>
    public class ConfigureUIModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public ConfigureUIModel()
        {
            if (ac_ConfigureUI == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ConfigureUI);
                ac_ConfigureUI = (CommonModel.AC_ConfigureUI)HttpContext.Current.Session[CommonConstantModel.s_AC_ConfigureUI];
            }
        }

        /// <summary>
        /// Bind Label Text
        /// </summary>
        /// <param name="configureUI"></param>
        internal void BindL10N_UI(UIConfiguration configureUI)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    using (DataSet ds_configureUI = genericServiceClient.COMMON_LoadL10N_UI())
                    {
                        if ((ds_configureUI != null) && (ds_configureUI.Tables.Count > 0) && (ds_configureUI.Tables[0].Rows.Count > 0))
                        {
                            configureUI.lblCUITopHeader.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUITopHeader'"))[0]["LabelName"]);
                            configureUI.lblCUIHeader1.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIHeader1'"))[0]["LabelName"]);

                            configureUI.lblCUIFileName.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIFileName'"))[0]["LabelName"]);
                            configureUI.lblCUIFileName.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIFileName'"))[0]["LabelToolTip"]);

                            configureUI.lblCUIPageName.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIPageName'"))[0]["LabelName"]);
                            configureUI.lblCUIPageName.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIPageName'"))[0]["LabelToolTip"]);

                            configureUI.lblCUIControlType.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIControlType'"))[0]["LabelName"]);
                            configureUI.lblCUIControlType.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIControlType'"))[0]["LabelToolTip"]);

                            configureUI.btnCUIClearFilter.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'btnCUIClearFilter'"))[0]["LabelName"]);
                            configureUI.btnCUIClearFilter.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'btnCUIClearFilter'"))[0]["LabelToolTip"]);

                            configureUI.lblCUIHeader2.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIHeader2'"))[0]["LabelName"]);

                            configureUI.lblCUILabelName.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUILabelName'"))[0]["LabelName"]);
                            configureUI.lblCUILabelName.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUILabelName'"))[0]["LabelToolTip"]);
                            configureUI.lblCUILabelName.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUILabelName'"))[0]["ErrorText"]);

                            configureUI.lblCUITootipText.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUITootipText'"))[0]["LabelName"]);
                            configureUI.lblCUITootipText.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUITootipText'"))[0]["LabelToolTip"]);

                            configureUI.lblCUIErrorMsgTooltip.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIErrorMsgTooltip'"))[0]["LabelName"]);
                            configureUI.lblCUIErrorMsgTooltip.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIErrorMsgTooltip'"))[0]["LabelToolTip"]);

                            configureUI.lblCUIErroeMsg2Tooltip.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIErrorMsg2Tooltip'"))[0]["LabelName"]);
                            configureUI.lblCUIErroeMsg2Tooltip.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'lblCUIErrorMsg2Tooltip'"))[0]["LabelToolTip"]);

                            configureUI.btnCUISave.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'btnCUISave'"))[0]["LabelName"]);
                            configureUI.btnCUISave.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'btnCUISave'"))[0]["LabelToolTip"]);

                            configureUI.btnCUICancel.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'btnCUICancel'"))[0]["LabelName"]);
                            configureUI.btnCUICancel.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'btnCUICancel'"))[0]["LabelToolTip"]);

                            configureUI.btnApplyFilter.Text = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'btnApplyFilter'"))[0]["LabelName"]);
                            configureUI.btnApplyFilter.ToolTip = Convert.ToString((ds_configureUI.Tables[0].Select("LabelID = 'btnApplyFilter'"))[0]["LabelToolTip"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Get L10N_UI file names
        /// </summary>
        /// <param name="configureUI">UIConfiguration</param>
        internal void BindFileNameDropdown(UIConfiguration configureUI)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    configureUI.ddlCUIFileName.DataSource = genericServiceClient.ReadFileNames(genericProperties);
                }
                configureUI.ddlCUIFileName.DataTextField = "PageName";
                configureUI.ddlCUIFileName.DataValueField = "FileName";
                configureUI.ddlCUIFileName.DataBind();

                configureUI.ddlCUIFileName.Items.Insert(0, "--- Please Select ---");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Get L10N_UI file names
        /// </summary>
        /// <param name="configureUI">UIConfiguration</param>
        internal void BindPageNameDropdown(UIConfiguration configureUI)
        {
            DataTable dt = new DataTable("DT");
            DataRow dataRow = null;
            try
            {
                if (!configureUI.ddlCUIFileName.SelectedIndex.Equals(0))
                {
                    BindDataSet(configureUI, dt, dataRow);
                    configureUI.ddlCUIPageName.DataSource = dt;
                    configureUI.ddlCUIPageName.DataTextField = "PageName";
                    configureUI.ddlCUIPageName.DataBind();
                    configureUI.ddlCUIPageName.Items.Insert(0, "--- Please Select ---");
                }
                else
                {
                    configureUI.ddlCUIPageName.DataSource = dt;
                    configureUI.ddlCUIPageName.DataBind();
                    configureUI.ddlCUIPageName.Items.Insert(0, "--- Please Select ---");
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                dt.Dispose();
            }
        }

        /// <summary>
        /// Get L10N_UI file names
        /// </summary>
        /// <param name="configureUI"></param>
        /// <param name="dt"></param>
        /// <param name="dataRow"></param>
        /// <returns></returns>
        private DataRow BindDataSet(UIConfiguration configureUI, DataTable dt, DataRow dataRow)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                dt.Columns.Add("PageName");
                ac_ConfigureUI.ds_ConfigUI = genericServiceClient.Get_L10N_UI(configureUI.ddlCUIFileName.SelectedItem.Value);
                foreach (DataTable item in ac_ConfigureUI.ds_ConfigUI.Tables)
                {
                    dataRow = dt.NewRow();
                    dataRow["PageName"] = item.TableName;
                    dt.Rows.Add(dataRow);
                }
            }
            return dataRow;
        }

        /// <summary>
        /// Get L10N_UI file names
        /// </summary>
        /// <param name="configureUI">UIConfiguration</param>
        internal void BindControlUITypeDropdown(UIConfiguration configureUI)
        {
            DataTable dt = new DataTable("DT");
            DataRow dataRow = null;
            try
            {
                if (!configureUI.ddlCUIFileName.SelectedIndex.Equals(0))
                {
                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        dt.Columns.Add("ControlType");
                        ac_ConfigureUI.ds_ConfigUI = genericServiceClient.Get_L10N_UI(configureUI.ddlCUIFileName.SelectedItem.Value);
                        foreach (DataRow perRow in ac_ConfigureUI.ds_ConfigUI.Tables[configureUI.ddlCUIPageName.SelectedItem.Value].Rows)
                        {
                            dataRow = dt.NewRow();
                            dataRow["ControlType"] = Convert.ToString(perRow["ControlType"]);
                            dt.Rows.Add(dataRow);
                        }
                    }
                    using (DataView View = new DataView(dt))
                    {
                        View.Sort = "ControlType ASC";
                        dt = View.ToTable(true);
                        configureUI.ddlCUIControlType.DataSource = dt;
                        configureUI.ddlCUIControlType.DataTextField = "ControlType";
                        configureUI.ddlCUIControlType.DataBind();
                        configureUI.ddlCUIControlType.Items.Insert(0, "--- Please Select ---"); 
                    }
                }
                else
                {
                    configureUI.ddlCUIControlType.DataSource = dt;
                    configureUI.ddlCUIControlType.DataBind();
                    configureUI.ddlCUIControlType.Items.Insert(0, "--- Please Select ---");
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                dt.Dispose();
            }
        }

        /// <summary>
        /// Get L10N_UI file names
        /// </summary>
        /// <param name="configureUI">UIConfiguration</param>
        internal void BindGrid(UIConfiguration configureUI)
        {
            try
            {
                ac_ConfigureUI.dt_ConfigUI = configureUI.ddlCUIControlType.SelectedItem.Text.Equals("--- Please Select ---") ? (DataTable)ac_ConfigureUI.ds_ConfigUI.Tables[configureUI.ddlCUIPageName.SelectedItem.Text] :
                                             ac_ConfigureUI.ds_ConfigUI.Tables[configureUI.ddlCUIPageName.SelectedItem.Text].Select("ControlType = '" + configureUI.ddlCUIControlType.SelectedItem.Text + "'").CopyToDataTable();
               
                using (DataView GView = new DataView(ac_ConfigureUI.dt_ConfigUI))
                {
                    GView.Sort = "ControlType ASC";
                    configureUI.gv.DataSource = ac_ConfigureUI.dt_ConfigUI = GView.ToTable();
                    configureUI.gv.DataBind();
                    configureUI.gv.Visible = true;
                }
             
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Get L10N_UI file names
        /// </summary>
        /// <param name="configureUI">UIConfiguration</param>
        internal void BindNullGrid(UIConfiguration configureUI)
        {
            try
            {
                DataTable dt = new DataTable("DT");
                configureUI.gv.DataSource = dt;
                configureUI.gv.DataBind();
                configureUI.gv.Visible = true;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Get L10N_UI file names
        /// </summary>
        /// <param name="configureUI">UIConfiguration</param>
        internal void BindNullPageNameDDL(UIConfiguration configureUI)
        {
            try
            {
                DataTable dt = new DataTable("DT");
                configureUI.ddlCUIPageName.DataSource = dt;
                configureUI.ddlCUIPageName.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Rename Labels and Tooltips
        /// </summary>
        /// <param name="configureUI"></param>
        internal void RenameLabelNames(UIConfiguration configureUI)
        {
            try
            {
                DataTable dt = new DataTable("DT");
                DataRow dataRow = null;
                XDocument document = XDocument.Load(ConfigurationManager.AppSettings["UiCulturePath"] + configureUI.ddlCUIFileName.SelectedItem.Value);

                var query = from c in document.Root.Elements(configureUI.ddlCUIPageName.SelectedItem.Text)
                            where c.Attribute("LabelID").Value == configureUI.hdnLabelID.Value
                            select c;

                query.First().Attribute("LabelName").SetValue(configureUI.txtCUILabelName.Text);
                query.First().Attribute("LabelToolTip").SetValue(configureUI.txtCUITootipText.Text);
                query.First().Attribute("ErrorText").SetValue("ERROR: " + configureUI.txtCUIErrorMsgTooltip.Text);
                query.First().Attribute("ErrorText2").SetValue("ERROR: " + configureUI.txtCUIErrorMsg2Tooltip.Text);
                
                document.Save(ConfigurationManager.AppSettings["UiCulturePath"] + configureUI.ddlCUIFileName.SelectedItem.Value);
                configureUI.gv.Visible = false;

                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    configureUI.ctrSuccessErrorMessage.s_MessageText = genericServiceClient.Get_L10N("CUI_Updated", "Message", "COMMON_L10N.xml");
                    configureUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                }
                
                BindDataSet(configureUI, dt, dataRow);
                if (!configureUI.ddlCUIControlType.SelectedItem.Text.Equals("--- Please Select ---"))
                {
                    dt = ac_ConfigureUI.ds_ConfigUI.Tables[configureUI.ddlCUIPageName.SelectedItem.Text].Select("ControlType = '" + configureUI.ddlCUIControlType.SelectedItem.Text + "'").CopyToDataTable();
                }
            }
            catch
            {
                throw;
            }
        }

        #region Bind/Hide rows into GridView gv
        /// <summary>
        /// Bind GridView Rows
        /// </summary>
        /// <param name="e"></param>
        /// <param name="n_index">index</param>
        /// <param name="n_ID">ID</param>
        /// <param name="n_Delete">Delete column index</param>
        /// <param name="n_Action">Action</param>
        /// <param name="n_ControlType">ControlType column</param>
        /// <param name="n_LabelName">LabelName column</param>
        /// <param name="n_LabelToolTip">LabelToolTip column</param>
        /// <param name="n_ErrorText">ErrorText column</param>
        /// <param name="n_ErrorText2">ErrorText2 column</param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action, ref int n_ControlType, ref int n_LabelName, ref int n_LabelToolTip, ref int n_ErrorText, ref int n_ErrorText2)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "LABELID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    break;
                               
                                case "CONTROLTYPE":
                                    e.Row.Cells[n_index].Text = "Control Type";
                                    n_ControlType = n_index;
                                    break;

                                case "LABELNAME":
                                    e.Row.Cells[n_index].Text = "Label Name";
                                    n_LabelName = n_index;
                                    break;

                                case "LABELTOOLTIP":
                                    e.Row.Cells[n_index].Text = "Label ToolTip";
                                    n_LabelToolTip = n_index;
                                    break;

                                case "ERRORTEXT":
                                    e.Row.Cells[n_index].Text = "Error Text";
                                    n_ErrorText = n_index;
                                    break;

                                case "ERRORTEXT2":
                                    e.Row.Cells[n_index].Text = "Error Text2";
                                    n_ErrorText2 = n_index;
                                    break;
                            }
                            n_index = n_index + 1;

                        }
                        break;

                    case DataControlRowType.DataRow:

                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png",e.Row.Cells[1].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, "Edit",e.Row.Cells[5].Text));
                        e.Row.Cells[2].Attributes.Add("style", "word-break:break-all;word-wrap:break-word");
                        e.Row.Cells[3].Attributes.Add("style", "word-break:break-all;word-wrap:break-word");
                        e.Row.Cells[4].Attributes.Add("style", "word-break:break-all;word-wrap:break-word");
                        e.Row.Cells[5].Attributes.Add("style", "word-break:break-all;word-wrap:break-word");
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[0].Width = Unit.Percentage(20);
                        e.Row.Cells[2].Width = Unit.Percentage(20);
                        e.Row.Cells[3].Width = Unit.Percentage(20);
                        e.Row.Cells[4].Width = Unit.Percentage(20);
                        e.Row.Cells[5].Width = Unit.Percentage(10);
                        e.Row.Cells[n_Action].Width = Unit.Percentage(10);

                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Create Image button
        /// </summary>
        /// <param name="s_strToolTip">ToolTip</param>
        /// <param name="s_strUrl">URL</param>
        /// <param name="s_LabelID">CountryID</param>
        /// <param name="s_LabelName">CountryName</param>
        /// <param name="s_ToolTipText">Status</param>
        /// <param name="s_ErrorMessage">this is Error message.</param>                
        /// <param name="s_Action">Action</param>
        /// <param name="s_ErrorMessage2"></param>
        /// <returns>ImageButton control</returns>        
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_LabelID, string s_LabelName, string s_ToolTipText, string s_ErrorMessage, string s_Action, string s_ErrorMessage2)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");
                if (!string.IsNullOrEmpty(s_LabelName))
                {
                    imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_LabelName + "','" + s_ToolTipText + "','" + s_LabelID + "','" + s_ErrorMessage + "','" + s_ErrorMessage2 + "')");
                }
                return imgButton;
            }
        }

        /// <summary>
        /// Bind CheckBox for delete multiple records
        /// </summary>
        /// <param name="s_CountryID">CountryID</param>
        /// <param name="IsDeleted">IsDeleted</param>
        /// <returns>CheckBox control</returns>
        private CheckBox AddCheckBox(string s_CountryID, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_CountryID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");
                if (!string.IsNullOrEmpty(s_CountryID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_CountryID + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// Add Delete all checkbox
        /// </summary>
        /// <returns>CheckBox control</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chkDeleteAll";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Text = " Select All";
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }
        #endregion

        /// <summary>
        /// Bind next page data
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">GridViewPageEventArgs</param>
        /// <param name="gv">GridView</param>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv)
        {
            try
            {
                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_ConfigureUI.dt_ConfigUI;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ConfigureUIModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}