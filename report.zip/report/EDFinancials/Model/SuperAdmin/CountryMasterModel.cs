﻿using EDFinancials.Model.Generic;
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Linq;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// Modlel class for CountryMasterModel.aspx
    /// </summary>
    public class CountryMasterModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public CountryMasterModel()
        {
            if (ac_ManageCountry == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageCountry);
                ac_ManageCountry = (CommonModel.AC_ManageCountry)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageCountry];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty;

        #endregion

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="countryMasterUI"></param>
        internal void ReadL10N_UI(View.SuperAdmin.CountryMaster countryMasterUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_ManageCountryUI = objSuperAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_ManageCountries))
                    {
                        if ((dt_ManageCountryUI != null) && (dt_ManageCountryUI.Rows.Count > 0))
                        {
                            countryMasterUI.lblParamCountryName.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblParamCountryName'"))[0]["LabelName"]);
                            countryMasterUI.lblCMStatus.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMStatus'"))[0]["LabelName"]);
                            countryMasterUI.lblIsDefault.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblIsDefault'"))[0]["LabelName"]);
                            countryMasterUI.btnCMApplyFilter.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMApplyFilter'"))[0]["LabelName"]);
                            countryMasterUI.btnCMCreateNew.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMCreateNew'"))[0]["LabelName"]);
                            countryMasterUI.btnCMDelete.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMDelete'"))[0]["LabelName"]);
                            countryMasterUI.lblCountryName.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCountryName'"))[0]["LabelName"]);
                            countryMasterUI.lblCMIsActive.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMIsActive'"))[0]["LabelName"]);
                            countryMasterUI.btnCMSave.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMSave'"))[0]["LabelName"]);
                            countryMasterUI.btnCMCancel.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMCancel'"))[0]["LabelName"]);
                            countryMasterUI.lblCMHeader1.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMHeader1'"))[0]["LabelName"]);
                            countryMasterUI.lblCMHeader2.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMHeader2'"))[0]["LabelName"]);
                            countryMasterUI.lblCMHeader3.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMHeader3'"))[0]["LabelName"]);
                            countryMasterUI.btnCMClearFilter.Text = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMClearFilter'"))[0]["LabelName"]);
                            s_BtnUpdateText = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMUpdate'"))[0]["LabelName"]);
                            s_BtnUpdateToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMUpdate'"))[0]["LabelToolTip"]);
                            s_BtnSaveText = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMSave'"))[0]["LabelName"]);
                            s_BtnSaveTooltip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMSave'"))[0]["LabelToolTip"]);

                            countryMasterUI.lblParamCountryName.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblParamCountryName'"))[0]["LabelToolTip"]);
                            countryMasterUI.lblCMStatus.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMStatus'"))[0]["LabelToolTip"]);
                            countryMasterUI.lblIsDefault.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblIsDefault'"))[0]["LabelToolTip"]);
                            countryMasterUI.btnCMApplyFilter.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMApplyFilter'"))[0]["LabelToolTip"]);
                            countryMasterUI.btnCMCreateNew.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMCreateNew'"))[0]["LabelToolTip"]);
                            countryMasterUI.btnCMDelete.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMDelete'"))[0]["LabelToolTip"]);
                            countryMasterUI.lblCountryName.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCountryName'"))[0]["LabelToolTip"]);
                            countryMasterUI.lblCMIsActive.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMIsActive'"))[0]["LabelToolTip"]);
                            countryMasterUI.btnCMSave.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMSave'"))[0]["LabelToolTip"]);
                            countryMasterUI.btnCMCancel.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMCancel'"))[0]["LabelToolTip"]);
                            countryMasterUI.lblCMHeader1.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMHeader1'"))[0]["LabelToolTip"]);
                            countryMasterUI.lblCMHeader2.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMHeader2'"))[0]["LabelToolTip"]);
                            countryMasterUI.lblCMHeader3.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMHeader3'"))[0]["LabelToolTip"]);
                            countryMasterUI.btnCMClearFilter.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'btnCMClearFilter'"))[0]["LabelToolTip"]);
                            countryMasterUI.reqName.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCountryName'"))[0]["ErrorText"]);
                            countryMasterUI.reqStatus.ToolTip = Convert.ToString((dt_ManageCountryUI.Select("LabelID = 'lblCMIsActive'"))[0]["ErrorText"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used for bind the data in GridView 
        /// </summary>
        /// <param name="countryMasterUI">this is countryMasterUI page  object</param>
        internal void BindCountryDetailsGrid(View.SuperAdmin.CountryMaster countryMasterUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.CMID = countryMasterUI.ddlParamCountryName.SelectedValue == ("--- Please Select ---") || countryMasterUI.ddlParamCountryName.SelectedValue == ("") ? 0 : Convert.ToInt32(countryMasterUI.ddlParamCountryName.SelectedValue);
                    superAdminProperties.IsActive = countryMasterUI.ddlCMStatus.SelectedValue == ("--- Please Select ---") || countryMasterUI.ddlCMStatus.SelectedValue == ("") ? 0 : Convert.ToInt32(countryMasterUI.ddlCMStatus.SelectedValue);
                    superAdminProperties.PageName = CommonConstantModel.s_ManageCountries;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_ManageCountry.dt_Countries = superAdminCRUDProperties.dt_Result;
                    countryMasterUI.gv.DataSource = superAdminCRUDProperties.dt_Result;
                    countryMasterUI.gv.DataBind();

                    if (!(countryMasterUI.ddlParamCountryName.SelectedValue == ("--- Please Select ---") || countryMasterUI.ddlParamCountryName.SelectedValue == ("")))
                    {
                        countryMasterUI.btnCMClearFilter.Visible = true;
                    }
                    if (!(countryMasterUI.ddlCMStatus.SelectedValue == ("--- Please Select ---") || countryMasterUI.ddlCMStatus.SelectedValue == ("")))
                    {
                        countryMasterUI.btnCMClearFilter.Visible = true;
                    }

                    countryMasterUI.btnCMDelete.Visible = ac_ManageCountry.dt_Countries.Rows.Count > 0;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used for bind the data in GridView 
        /// </summary>
        /// <param name="countryMasterUI">this is countryMasterUI page object</param>
        internal void ResetGrid(View.SuperAdmin.CountryMaster countryMasterUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.CMID = 0;
                    superAdminProperties.IsActive = 0;
                    superAdminProperties.PageName = CommonConstantModel.s_ManageCountries;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_ManageCountry.dt_Countries = superAdminCRUDProperties.dt_Result;
                    countryMasterUI.gv.DataSource = superAdminCRUDProperties.dt_Result;
                    countryMasterUI.gv.DataBind();

                    countryMasterUI.btnCMDelete.Visible = superAdminCRUDProperties.dt_Result.Rows.Count > 0;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Country Master
        /// </summary>
        /// <param name="countryMasterUI"></param>
        internal void BindCountryName(View.SuperAdmin.CountryMaster countryMasterUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.CMID = 0;
                    superAdminProperties.IsActive = 0;
                    superAdminProperties.PageName = CommonConstantModel.s_ManageCountries;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    countryMasterUI.ddlParamCountryName.DataSource = superAdminCRUDProperties.dt_Result;
                    countryMasterUI.ddlParamCountryName.DataTextField = "Country Name";
                    countryMasterUI.ddlParamCountryName.DataValueField = "ID";
                    countryMasterUI.ddlParamCountryName.DataBind();
                    countryMasterUI.ddlParamCountryName.Items.Insert(0, "--- Please Select ---");

                    countryMasterUI.hdnCountryMasterID.Value = string.Empty;
                    countryMasterUI.hdnDeletedRecords.Value = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Dropdown for Country Status
        /// </summary>
        /// <param name="countryMasterUI"></param>
        internal void BindCountryStatus(View.SuperAdmin.CountryMaster countryMasterUI)
        {
            try
            {
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("STATUS_ID", typeof(string));
                dataTable.Columns.Add("STATUS", typeof(string));

                DataRow dataRow = null;
                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "1";
                dataRow["STATUS"] = "Activated";
                dataTable.Rows.Add(dataRow);

                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "2";
                dataRow["STATUS"] = "Deactivated";
                dataTable.Rows.Add(dataRow);

                countryMasterUI.ddlCMStatus.DataSource = dataTable;
                countryMasterUI.ddlCMStatus.DataTextField = "STATUS";
                countryMasterUI.ddlCMStatus.DataValueField = "STATUS_ID";
                countryMasterUI.ddlCMStatus.DataBind();

                countryMasterUI.ddlCMStatus.Items.Insert(0, "--- Please Select ---");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Dropdown for Country Status
        /// </summary>
        /// <param name="countryMasterUI"></param>
        internal void BindStatus(View.SuperAdmin.CountryMaster countryMasterUI)
        {
            try
            {
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("STATUS_ID", typeof(string));
                dataTable.Columns.Add("STATUS", typeof(string));

                DataRow dataRow = null;
                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "1";
                dataRow["STATUS"] = "Activated";
                dataTable.Rows.Add(dataRow);

                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "2";
                dataRow["STATUS"] = "Deactivated";
                dataTable.Rows.Add(dataRow);

                countryMasterUI.ddlStatus.DataSource = dataTable;
                countryMasterUI.ddlStatus.DataTextField = "STATUS";
                countryMasterUI.ddlStatus.DataValueField = "STATUS_ID";
                countryMasterUI.ddlStatus.DataBind();

                countryMasterUI.ddlStatus.Items.Insert(0, "--- Please Select ---");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// CUD[Create/Update/Delete] operation on Forfeiture Group
        /// </summary>
        /// <param name="countryMasterUI">UI object</param>
        /// <returns></returns>
        internal void CUDCountryDetails(View.SuperAdmin.CountryMaster countryMasterUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    if (string.IsNullOrEmpty(countryMasterUI.hdnCountryMasterID.Value) && !string.IsNullOrEmpty(countryMasterUI.hdnDeletedRecords.Value))
                        superAdminProperties.Action = "D";
                    else
                        superAdminProperties.Action = string.IsNullOrEmpty(countryMasterUI.hdnCountryMasterID.Value) ? "C" : "U";

                    superAdminProperties.CountryName = countryMasterUI.txtCountryName.Text;
                    superAdminProperties.IsActive = superAdminProperties.Action.Equals("D") ? 0 : Convert.ToInt32(countryMasterUI.ddlStatus.SelectedValue);
                    superAdminProperties.IsDefault = countryMasterUI.chkIsDefault.Checked ? true : false;
                    superAdminProperties.IsDeleted = string.IsNullOrEmpty(countryMasterUI.hdnDeletedRecords.Value) ? false : true;
                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    superAdminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    superAdminProperties.CMID = string.IsNullOrEmpty(countryMasterUI.hdnCountryMasterID.Value) ? 0 : Convert.ToInt32(countryMasterUI.hdnCountryMasterID.Value);
                    superAdminProperties.CMDeleteID = string.IsNullOrEmpty(countryMasterUI.hdnDeletedRecords.Value) ? string.Empty : countryMasterUI.hdnDeletedRecords.Value.TrimStart(',');
                    countryMasterUI.txtCountryName.Text = "";
                    countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    superAdminProperties.PageName = CommonConstantModel.s_ManageCountries;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    if (countryMasterUI.hdnDefCountry.Value == "Yes" || countryMasterUI.SelectAllChecked.Value.Equals("true"))
                    {
                        string s_IsDefault = (from r in ac_ManageCountry.dt_Countries.AsEnumerable()
                                              where r.Field<string>("Default Country") == "Yes"
                                              select r.Field<string>("Default Country")).First<string>();
                        if (s_IsDefault.Equals("Yes"))
                        {
                            superAdminCRUDProperties.a_result = 6;
                        }
                    }
                    else
                        superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                    countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;

                    switch (superAdminCRUDProperties.a_result)
                    {
                        case 0:
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCMError");
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 1:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCMCreated");
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 2:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCMUpdated");
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 3:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCMDeleted");
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 4:
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCMIsExist");
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 5:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCMReactive");
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            countryMasterUI.ctrSuccessErrorMessage.s_RevOptionsDisplay = "block";
                            ac_ManageCountry.s_CountryName = superAdminProperties.CountryName;
                            break;

                        case 6:
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCMDefaultCurrency");
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            countryMasterUI.hdnDefCountry.Value = string.Empty;
                            countryMasterUI.hdnDeletedRecords.Value = string.Empty;
                            countryMasterUI.SelectAllChecked.Value = string.Empty;
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// CUD[Create/Update/Delete] operation on Forfeiture Group
        /// </summary>
        /// <param name="countryMasterUI">UI object</param>
        /// <returns></returns>
        internal void ReactiveCountryDetails(View.SuperAdmin.CountryMaster countryMasterUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.Action = "U";

                    superAdminProperties.CountryName = ac_ManageCountry.s_CountryName;
                    superAdminProperties.IsDeleted = false;
                    superAdminProperties.IsDefault = countryMasterUI.chkIsDefault.Checked ? true : false;
                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    superAdminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    superAdminProperties.CMID = 0;
                    countryMasterUI.txtCountryName.Text = "";
                    countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    superAdminProperties.PageName = CommonConstantModel.s_ManageCountries;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                    switch (superAdminCRUDProperties.a_result)
                    {
                        case 0:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCMError");
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 2:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCMUpdated");
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;
                    }
                    countryMasterUI.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                }
            }
            catch
            {
                throw;
            }
        }

        #region Bind/Hide rows into GridView gv
        /// <summary>
        ///  Bind GridView Rows
        /// </summary>
        /// <param name="e"></param>
        /// <param name="n_index"></param>
        /// <param name="n_ID"></param>
        /// <param name="n_Delete"></param>
        /// <param name="n_Action"></param>
        /// <param name="n_DefCountry"></param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action, ref int n_DefCountry)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    n_Delete = n_index;
                                    e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                    break;

                                case "DEFAULT COUNTRY":
                                    n_DefCountry = n_index;
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, "Edit"));
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[1].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[n_DefCountry].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Create Image button
        /// </summary>
        /// <param name="s_strToolTip">ToolTip</param>
        /// <param name="s_strUrl">Url</param>
        /// <param name="s_CountryID">CountryID</param>
        /// <param name="s_CountryName">CountryName</param>
        /// <param name="s_Status">Status</param>
        /// <param name="s_IsDefault">flag to check if is default</param>
        /// <param name="s_Action">Action</param>
        /// <returns></returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_CountryID, string s_CountryName, string s_Status, string s_IsDefault, string s_Action)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");
                if (!string.IsNullOrEmpty(s_CountryName))
                {
                    imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_CountryName + "','" + s_Status + "','" + s_CountryID + "','" + s_IsDefault + "')");
                }
                return imgButton;
            }
        }

        /// <summary>
        /// Bind CheckBox for delete multiple records
        /// </summary>
        /// <param name="s_CountryID"></param>
        /// <param name="s_DefCountry"></param>
        /// <param name="IsDeleted"></param>
        /// <returns></returns>
        private CheckBox AddCheckBox(string s_CountryID, string s_DefCountry, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_CountryID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");
                if (!string.IsNullOrEmpty(s_CountryID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_CountryID + "','" + s_DefCountry + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// Add Delete all checkbox
        /// </summary>
        /// <returns></returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chk";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.Text = string.Empty;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }
        #endregion

        /// <summary>
        /// Bind next page data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <param name="gv"></param>
        /// <param name="s_CountryID"></param>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_CountryID)
        {
            try
            {
                string[] s_CountryGpID = s_CountryID.TrimStart(',').Split(',');

                ac_ManageCountry.dt_Countries.Columns["Delete"].Expression = string.Empty;
                ac_ManageCountry.dt_Countries.AcceptChanges();

                foreach (string perID in s_CountryGpID)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_ManageCountry.dt_Countries.Select("ID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_ManageCountry.dt_Countries;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CountryMasterModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}