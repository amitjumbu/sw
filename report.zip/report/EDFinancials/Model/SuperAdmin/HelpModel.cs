﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using MSWord = Microsoft.Office.Interop.Word;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// 
    /// </summary>
    public class HelpModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public HelpModel()
        {
            if (ac_CompanyCreation == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_Help);
                ac_Help = (CommonModel.AC_Help)HttpContext.Current.Session[CommonConstantModel.s_AC_Help];
            }
        }

        /// <summary>
        /// This Method is used to bind UI lables to all controls from AP_L10_UIxml file at pageload
        /// </summary>
        /// <param name="help">help</param>
        internal void BindUI(Help help)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (System.Data.DataTable dt_ADMHelpUI = superAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_Help))
                    {
                        if ((dt_ADMHelpUI != null) && (dt_ADMHelpUI.Rows.Count > 0))
                        {
                            help.lblHelpPageName.Text = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'lblHelpPageName'"))[0]["LabelName"]);
                            help.lblPaneOneHeader.Text = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'lblPaneOneHeader'"))[0]["LabelName"]);
                            help.lblHelpSelectPage.Text = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'lblHelpSelectPage'"))[0]["LabelName"]);
                            help.lblHelpSelectedPageName.Text = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'lblHelpSelectedPageName'"))[0]["LabelName"]);
                            help.lblHelpPagewise.Text = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'lblHelpPagewise'"))[0]["LabelName"]);
                            help.btnPageWiseUpload.Text = help.btnFileOthersUpload.Text = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'btnPageWiseUpload'"))[0]["LabelName"]);
                            help.lnkbtnFileRemove.Text = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'lnkbtnFileRemove'"))[0]["LabelName"]);
                            help.lblHelpOthers.Text = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'lblHelpOthers'"))[0]["LabelName"]);
                            help.btnHelpSave.Text = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'btnHelpSave'"))[0]["LabelName"]);
                            help.btnPageWiseUpload.ToolTip = help.btnFileOthersUpload.ToolTip = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'btnPageWiseUpload'"))[0]["LabelToolTip"]);
                            help.lnkbtnFileRemove.ToolTip = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'lnkbtnFileRemove'"))[0]["LabelToolTip"]);
                            help.btnHelpSave.ToolTip = Convert.ToString((dt_ADMHelpUI.Select("LabelID = 'btnHelpSave'"))[0]["LabelToolTip"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to Bind Page Names To The DropDownlist
        /// </summary>
        /// <param name="help">help</param>
        internal void BindPageDropDown(Help help)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    help.ddlHelpSelectPage.Items.Clear();

                    superAdminProperties.PageName = CommonConstantModel.s_Help;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PopulateControls = "DropDownSelectPage";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                    help.ddlHelpSelectPage.DataSource = (DataTable)superAdminCRUDProperties.dt_Result.Select("MENU_NAME <> 'null' AND PARENT_MMID <> 0 AND MENU_NAME <> 'Help' AND MENU_NAME <> 'HelpDoc' AND MENU_NAME <> 'Logout'").CopyToDataTable().DefaultView.ToTable(false, "MMID", "MENU_NAME");
                    help.ddlHelpSelectPage.DataTextField = "MENU_NAME";
                    help.ddlHelpSelectPage.DataValueField = "MMID";
                    help.ddlHelpSelectPage.DataBind();

                    help.ddlHelpSelectPage.Items.Insert(0, "--- Please Select ---");

                    help.lblSelectedPageName.Text = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// This method is used to bind selected page name to lblSelectedPageName
        /// </summary>
        /// <param name="help">help</param>
        internal void GetPageNames(Help help)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.PageName = CommonConstantModel.s_Help;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PopulateControls = "SelectedPageName";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                    ac_Help.dt_Help_PageNames = (DataTable)superAdminCRUDProperties.dt_Result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind the PageWise GridView
        /// </summary>
        /// <param name="help">help</param>
        internal void BindPageWiseGrid(Help help)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.PageName = CommonConstantModel.s_Help;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PopulateControls = "PageWiseGrid";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                    ac_Help.dt_Help_PGrid = (DataTable)superAdminCRUDProperties.dt_Result;

                    if (ac_Help.dt_Help_PGrid != null && ac_Help.dt_Help_PGrid.Rows.Count > 0)
                        help.trgvPageWise.Style.Add("display", "normal");
                    else
                        help.trgvPageWise.Style.Add("display", "none");

                    help.gvPageWise.DataSource = ac_Help.dt_Help_PGrid;
                    help.gvPageWise.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind Others GridView
        /// </summary>
        /// <param name="help">help</param>
        internal void BindOthersGrid(Help help)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.PageName = CommonConstantModel.s_Help;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PopulateControls = "OthersGrid";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                    ac_Help.dt_Help_OGrid = (DataTable)superAdminCRUDProperties.dt_Result;

                    if (ac_Help.dt_Help_OGrid != null && ac_Help.dt_Help_OGrid.Rows.Count > 0)
                        help.trgv.Style.Add("display", "normal");
                    else
                        help.trgv.Style.Add("display", "none");

                    help.gv.DataSource = ac_Help.dt_Help_OGrid;
                    help.gv.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The PageWise PageWise Upload Complete Method
        /// </summary>
        /// <param name="help">help</param>
        /// <param name="s_MainFolderPath">s_MainFolderPath</param>
        internal void FileUploadPageWise_UploadedComplete(Help help, string s_MainFolderPath)
        {
            try
            {
                string filename = Convert.ToString(help.ddlHelpSelectPage.SelectedItem.Text).Replace(" ", "") + Convert.ToString(System.IO.Path.GetFileName(help.FilePagewiseUpload.FileName)).Substring(Convert.ToString(System.IO.Path.GetFileName(help.FilePagewiseUpload.FileName)).LastIndexOf('.'));

                string newPath = System.IO.Path.Combine(s_MainFolderPath, help.ddlHelpSelectPage.SelectedItem.Text);
                DirectoryInfo objDirectory = new DirectoryInfo(newPath);

                if (!objDirectory.Exists)
                {
                    System.IO.Directory.CreateDirectory(newPath);
                }

                string subFolderOne = System.IO.Path.Combine(newPath, "PageWise");
                objDirectory = new DirectoryInfo(subFolderOne);

                if (Directory.Exists(subFolderOne))
                {
                    foreach (string s_filename in Directory.GetFiles(subFolderOne))
                    {
                        File.Delete(s_filename);
                    }
                    foreach (string subfolders in Directory.GetDirectories(subFolderOne))
                    {
                        Directory.Delete(subfolders, true);
                    }
                }
                else
                    System.IO.Directory.CreateDirectory(subFolderOne);

                help.FilePagewiseUpload.SaveAs(subFolderOne + "/" + filename);

                string s_FileNameWithoutExt = filename.Substring(0, filename.LastIndexOf("."));

                //Creating the instance of Word Application
                MSWord.Application word = new MSWord.Application();

                try
                {
                    // specifying the Source & Target file names
                    object Source = subFolderOne + "/" + filename;
                    object Target = subFolderOne + "/" + s_FileNameWithoutExt + ".htm";

                    // Use for the parameter whose type are not known or  
                    // say Missing
                    object Unknown = Type.Missing;

                    // Source document open here
                    // Additional Parameters are not known so that are  
                    // set as a missing type
                    word.Documents.Open(ref Source, ref Unknown,
                         ref Unknown, ref Unknown, ref Unknown,
                         ref Unknown, ref Unknown, ref Unknown,
                         ref Unknown, ref Unknown, ref Unknown,
                         ref Unknown, ref Unknown, ref Unknown, ref Unknown);

                    // Specifying the format in which you want the output file 
                    object format = Microsoft.Office.Interop.Word.WdSaveFormat.wdFormatHTML;

                    //Changing the format of the document
                    word.ActiveDocument.SaveAs(ref Target, ref format,
                            ref Unknown, ref Unknown, ref Unknown,
                            ref Unknown, ref Unknown, ref Unknown,
                            ref Unknown, ref Unknown, ref Unknown,
                            ref Unknown, ref Unknown, ref Unknown,
                            ref Unknown, ref Unknown);

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                // for closing the application
                finally
                {
                    object Unknown = System.Reflection.Missing.Value;
                    ((MSWord._Application)word).Quit(ref Unknown, ref Unknown, ref Unknown);
                    System.Threading.Thread.Sleep(1000);
                }

                //Delete the Uploaded Word File
                File.Delete(subFolderOne + "\\" + filename);

                help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                help.trImg.Style.Add("display", "normal");
                help.trMsg.Style.Add("display", "normal");
                help.imgUploadComplete.Visible = help.lblFileName.Visible = help.lnkbtnFileRemove.Visible = help.lblFileUploaded.Visible = true;
                help.lblFileName.Text = filename;
                help.lblFileUploaded.ForeColor = Color.Blue;
                help.lblFileUploaded.Text = "File uploaded successfully";

                if (ac_Help.dt_Help_PageWise == null)
                    ac_Help.dt_Help_PageWise = new System.Data.DataTable();

                if (ac_Help.dt_Help_PageWise.Columns.Count == 0)
                {
                    ac_Help.dt_Help_PageWise.Columns.Add("DOCUMENT_NAME", typeof(string));
                    ac_Help.dt_Help_PageWise.Columns.Add("DOCUMENT_PATH", typeof(string));
                    ac_Help.dt_Help_PageWise.Columns.Add("DOCUMENT_UPLOAD_TYPE", typeof(string));
                }

                DataRow drHelpPageWise = ac_Help.dt_Help_PageWise.NewRow();
                drHelpPageWise["DOCUMENT_NAME"] = filename;
                drHelpPageWise["DOCUMENT_PATH"] = subFolderOne + "\\" + filename;
                drHelpPageWise["DOCUMENT_UPLOAD_TYPE"] = "P";
                ac_Help.dt_Help_PageWise.Rows.Add(drHelpPageWise);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Others PageWise Upload Complete Method
        /// </summary>
        /// <param name="help">help</param>
        /// <param name="s_MainFolderPath">s_MainFolderPath</param>
        internal void FileUploadOthers_UploadedComplete(Help help, string s_MainFolderPath)
        {
            try
            {
                string filename = System.IO.Path.GetFileName(help.FileOthersUpload.FileName);

                string subFolderOne = System.IO.Path.Combine(s_MainFolderPath, "Others");
                DirectoryInfo objDirectory = new DirectoryInfo(subFolderOne);

                if (!objDirectory.Exists)
                {
                    System.IO.Directory.CreateDirectory(subFolderOne);
                }

                help.FileOthersUpload.SaveAs(subFolderOne + "\\" + filename);

                if (ac_Help.dt_Help_OGrid == null)
                    ac_Help.dt_Help_OGrid = new System.Data.DataTable();

                if (ac_Help.dt_Help_OGrid.Columns.Count == 0)
                {
                    ac_Help.dt_Help_OGrid.Columns.Add("File Uploaded", typeof(string));
                    ac_Help.dt_Help_OGrid.Columns.Add("Action", typeof(string));
                }

                ac_Help.dt_Help_OGrid.Rows.Add(filename);

                help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                help.trgv.Style.Add("display", "normal");
                help.gv.DataSource = ac_Help.dt_Help_OGrid;
                help.gv.DataBind();

                if (ac_Help.dt_Help_Others == null)
                    ac_Help.dt_Help_Others = new System.Data.DataTable();

                if (ac_Help.dt_Help_Others.Columns.Count == 0)
                {
                    ac_Help.dt_Help_Others.Columns.Add("DOCUMENT_NAME", typeof(string));
                    ac_Help.dt_Help_Others.Columns.Add("DOCUMENT_PATH", typeof(string));
                    ac_Help.dt_Help_Others.Columns.Add("DOCUMENT_UPLOAD_TYPE", typeof(string));
                }

                DataRow drHelpOthers = ac_Help.dt_Help_Others.NewRow();
                drHelpOthers["DOCUMENT_NAME"] = filename;
                drHelpOthers["DOCUMENT_PATH"] = subFolderOne + "\\" + filename;
                drHelpOthers["DOCUMENT_UPLOAD_TYPE"] = "O";
                ac_Help.dt_Help_Others.Rows.Add(drHelpOthers);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Remove File After Upload 
        /// </summary>
        /// <param name="help">help</param>
        /// <param name="s_MainFolderPath">s_MainFolderPath</param>
        /// <returns>1</returns>
        internal int lnkbtnFileRemove_Click(Help help, string s_MainFolderPath)
        {
            try
            {
                string newPath = System.IO.Path.Combine(s_MainFolderPath, help.ddlHelpSelectPage.SelectedItem.Text) + "\\PageWise";

                if (Directory.Exists(newPath))
                {
                    foreach (string s_filename in Directory.GetFiles(newPath))
                    {
                        File.Delete(s_filename);
                    }
                }

                ac_Help.dt_Help_PageWise = null;

                help.trImg.Style.Add("display", "none");
                help.imgUploadComplete.Visible = help.lblFileName.Visible = help.lnkbtnFileRemove.Visible = false;
                help.lblFileUploaded.Visible = true;
                help.lblFileUploaded.ForeColor = Color.Red;
                help.lblFileUploaded.Text = "File removed successfully";
                return 1;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The GridView gvPageWise RowBound Event
        /// </summary>
        /// <param name="help">help</param>
        /// <param name="e">e</param>
        internal void gvPageWise_RowDataBound(Help help, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Center;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The GridView gvPageWise Delete Event
        /// </summary>
        /// <param name="help">GridView gvPageWise</param>
        /// <param name="e">e</param>
        /// <param name="s_MainFolderPath">s_MainFolderPath</param>
        internal void gvPageWise_RowDeleting(Help help, GridViewDeleteEventArgs e, string s_MainFolderPath)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    string s_DirectoryPath = System.IO.Path.Combine(s_MainFolderPath, ac_Help.dt_Help_PGrid.Rows[e.RowIndex][1].ToString()) + "\\PageWise";

                    superAdminProperties.PageName = CommonConstantModel.s_Help;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.FILE_NAME = string.Empty;
                    superAdminProperties.Action = "D";
                    superAdminProperties.MMID = Convert.ToInt32(ac_Help.dt_Help_PGrid.Rows[e.RowIndex][0].ToString());
                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                    superAdminCRUDProperties.a_result = (int)superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result;

                    switch (superAdminCRUDProperties.a_result)
                    {
                        case 0:
                            help.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            help.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(superAdminServiceClient.LoadL10N("lblHLPFileDeleteError"));
                            break;

                        case 1:
                            help.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            help.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(superAdminServiceClient.LoadL10N("lblHLPFileDeleted"));

                            BindPageWiseGrid(help);

                            BindPageDropDown(help);

                            BindOthersGrid(help);

                            if (Directory.Exists(s_DirectoryPath))
                            {
                                RemoveDirectories(s_DirectoryPath);
                            }

                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Remove directories, file and subfolders
        /// </summary>
        /// <param name="s_DirectoryPath">s_DirectoryPath</param>
        private void RemoveDirectories(string s_DirectoryPath)
        {
            try
            {
                //Delete all files from the Directory
                foreach (string file in Directory.GetFiles(s_DirectoryPath))
                {
                    File.Delete(file);
                }

                //Delete all child Directories
                foreach (string directory in Directory.GetDirectories(s_DirectoryPath))
                {
                    RemoveDirectories(directory);
                }

                //Delete a Directory
                Directory.Delete(s_DirectoryPath);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The GridView gv RowBound Event
        /// </summary>
        /// <param name="e">e</param>
        /// <param name="n_oIndex">n_oIndex</param>
        /// <param name="n_oFileName">n_oFileName</param>
        /// <param name="n_oAction">n_oAction</param>
        internal void gv_RowDataBound(GridViewRowEventArgs e, ref int n_oIndex, ref int n_oFileName, ref int n_oAction)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "FILE UPLOADED":
                                    n_oFileName = n_oIndex;
                                    break;

                                case "&NBSP;":
                                    n_oAction = n_oIndex;
                                    break;
                            }
                            n_oIndex = n_oIndex + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_oFileName].HorizontalAlign = HorizontalAlign.Left;
                        e.Row.Cells[n_oAction].HorizontalAlign = HorizontalAlign.Center;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The GridView gv Delete Event
        /// </summary>
        /// <param name="help">help</param>
        /// <param name="e">e</param>
        /// <param name="s_MainFolderPath">s_MainFolderPath</param>
        internal void gv_RowDeleting(Help help, GridViewDeleteEventArgs e, string s_MainFolderPath)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    string s_FileName = s_MainFolderPath + "\\Others\\" + ac_Help.dt_Help_OGrid.Rows[e.RowIndex][0].ToString();

                    superAdminProperties.PageName = CommonConstantModel.s_Help;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.FILE_NAME = ac_Help.dt_Help_OGrid.Rows[e.RowIndex][0].ToString();
                    superAdminProperties.Action = "O";
                    superAdminProperties.MMID = 0;
                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                    superAdminCRUDProperties.a_result = (int)superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result;

                    switch (superAdminCRUDProperties.a_result)
                    {
                        case 0:
                            help.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            help.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(superAdminServiceClient.LoadL10N("lblHLPFileDeleteError"));
                            break;

                        case 1:
                            help.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            help.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(superAdminServiceClient.LoadL10N("lblHLPFileDeleted"));

                            BindPageWiseGrid(help);

                            BindPageDropDown(help);

                            BindOthersGrid(help);

                            if (File.Exists(s_FileName))
                            {
                                File.Delete(s_FileName);
                            }

                            break;
                    }
                }

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This will Save File(s) to database
        /// </summary>
        /// <param name="help">help</param>
        internal void btnHelpSave_Click(Help help)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    if (ac_Help.dt_Help_PageWise == null)
                        ac_Help.dt_Help_PageWise = new System.Data.DataTable();

                    if (ac_Help.dt_Help_Others == null)
                        ac_Help.dt_Help_Others = new System.Data.DataTable();

                    ac_Help.dt_Help_PageWise.Merge(ac_Help.dt_Help_Others);

                    if (ac_Help.dt_Help_PageWise.Rows.Count > 0)
                    {
                        superAdminProperties.PageName = CommonConstantModel.s_Help;
                        superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                        superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        superAdminProperties.dt_DBHelpUpload = ac_Help.dt_Help_PageWise;
                        superAdminProperties.dt_DBHelpUpload.TableName = "DT";
                        superAdminProperties.FILE_NAME = string.Empty;
                        superAdminProperties.Action = "S";
                        superAdminProperties.MMID = help.ddlHelpSelectPage.SelectedItem.Value.Equals("--- Please Select ---") && ac_Help.dt_Help_PageWise.Select("DOCUMENT_UPLOAD_TYPE = 'P'").Count() == 0 ? 0 : Convert.ToInt32(help.ddlHelpSelectPage.SelectedItem.Value);
                        superAdminProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                        superAdminCRUDProperties.a_result = (int)superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result;

                        if (superAdminCRUDProperties.a_result.Equals(1))
                        {
                            help.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            help.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(superAdminServiceClient.LoadL10N("lblHLPFileSaved"));
                        }
                        else
                        {
                            help.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            help.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(superAdminServiceClient.LoadL10N("lblHLPFileSaveError"));
                        }
                    }
                    else
                    {
                        help.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                        help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        help.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(superAdminServiceClient.LoadL10N("lblHLPSelectFileFirst"));
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Clear All Tables
        /// </summary>
        /// <param name="help">help</param>
        internal void ClearAllTable(Help help)
        {
            try
            {
                ac_Help.dt_Help_OGrid = null;
                ac_Help.dt_Help_PageWise = null;
                ac_Help.dt_Help_Others = null;
                ac_Help.dt_DBHelpUpload = null;

                help.trImg.Style.Add("display", "none");
                help.trMsg.Style.Add("display", "none");
                help.trgv.Style.Add("display", "none");

                help.imgUploadComplete.Visible = help.lblFileName.Visible = help.lnkbtnFileRemove.Visible = help.lblFileUploaded.Visible = false;

                help.ddlHelpSelectPage.SelectedIndex = -1;

                ac_Help.dt_Help_OGrid = new System.Data.DataTable();

                help.gv.DataSource = ac_Help.dt_Help_OGrid;
                help.gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Dropdown ddlHelpSelectPage Index change event
        /// </summary>
        /// <param name="help">help</param>
        internal void ddlHelpSelectPage_SelectedIndexChanged(Help help)
        {
            try
            {
                if (help.ddlHelpSelectPage.SelectedIndex != 0)
                {
                    DataRow[] dr = (DataRow[])ac_Help.dt_Help_PageNames.AsEnumerable()
                            .Where(r => r.Field<int>("MMID") == Convert.ToInt32(help.ddlHelpSelectPage.SelectedItem.Value)).CopyToDataTable().Select();

                    string s_PageName = dr[0][1].ToString();
                    help.lblSelectedPageName.Text = s_PageName.Substring(s_PageName.LastIndexOf('/')).Split('/')[1].Split('.')[0];
                }
                else
                    help.lblSelectedPageName.Text = string.Empty;

                help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Page index change event of gvPageWise GridView 
        /// </summary>
        /// <param name="help">help Page Object</param>
        /// <param name="e">e</param>
        internal void gvPageWise_PageIndexChanging(Help help, GridViewPageEventArgs e)
        {
            try
            {
                help.gvPageWise.PageIndex = e.NewPageIndex;

                help.gvPageWise.DataSource = ac_Help.dt_Help_PGrid;
                help.gvPageWise.DataBind();

                help.gv.DataSource = ac_Help.dt_Help_OGrid;
                help.gv.DataBind();

                help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Page index change event of gv GridView
        /// </summary>
        /// <param name="help">help Page Object</param>
        /// <param name="e">e</param>
        internal void gv_PageIndexChanging(Help help, GridViewPageEventArgs e)
        {
            try
            {
                help.gv.PageIndex = e.NewPageIndex;

                help.gv.DataSource = ac_Help.dt_Help_OGrid;
                help.gv.DataBind();

                help.gvPageWise.DataSource = ac_Help.dt_Help_PGrid;
                help.gvPageWise.DataBind();

                help.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~HelpModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}