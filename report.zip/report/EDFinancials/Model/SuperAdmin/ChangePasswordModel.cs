﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Data;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// Model for ChangePassword.aspx.cs 
    /// </summary>
    public class ChangePasswordModel : BaseModel, IDisposable
    {
        /// <summary>
        /// This Method is used to fetch messages from L10N xml via superadmin WCF service.
        /// </summary>
        /// <param name="MessegeId"></param>
        /// <returns>string as the message</returns>
        public string SAP_L10N(string MessegeId)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                return superAdminServiceClient.LoadL10N(MessegeId);
            }
        }

        /// <summary>
        /// This method is used to load all label text from L10N_UI via wcf service
        /// </summary>
        /// <param name="changePassword">Entire page is sent to module using 'this' keyword</param>
        public void BindPageUI(ChangePassword changePassword)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_ChangPWEUI = superAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_ChangePassword))
                    {
                        if ((dt_ChangPWEUI != null) && (dt_ChangPWEUI.Rows.Count > 0))
                        {
                            changePassword.lblCPHeader.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPHeader'"))[0]["LabelName"]);
                            changePassword.lblCPoldPassword.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPoldPassword'"))[0]["LabelName"]);
                            changePassword.lblCPoldPassword.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPoldPassword'"))[0]["LabelToolTip"]);
                            changePassword.rqdoldpaswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPoldPassword'"))[0]["ErrorText"]);

                            changePassword.lblCPnewPassword.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPnewPassword'"))[0]["LabelName"]);
                            changePassword.lblCPnewPassword.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPnewPassword'"))[0]["LabelToolTip"]);
                            changePassword.rqdnewpswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPnewPassword'"))[0]["ErrorText"]);

                            changePassword.lblCPconfirmPassword.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["LabelName"]);
                            changePassword.lblCPconfirmPassword.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["LabelToolTip"]);
                            changePassword.rqdconfmpaswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["ErrorText2"]);
                            changePassword.cmpconfmpswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["ErrorText"]);

                            changePassword.btnCPSubmit.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='btnCPSubmit'"))[0]["LabelName"]);
                            changePassword.btnCPSubmit.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='btnCPSubmit'"))[0]["LabelToolTip"]);
                            changePassword.btnCPCancel.Value = Convert.ToString((dt_ChangPWEUI.Select("LabelID='btnCPCancel'"))[0]["LabelName"]);
                            changePassword.lblPasswordpattern.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='PasswordPatternHelp'"))[0]["LabelName"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to perform Update Operation
        /// </summary>
        internal void PerformCUD(ChangePassword changePassword)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    superAdminProperties.Id = userSessionInfo.ACC_UserID;
                    superAdminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                }
                superAdminProperties.Ids = changePassword.txtCPoldPassword.Text;
                superAdminProperties.Name = changePassword.txtCPnewPassword.Text;
                superAdminProperties.Action = "P";
                superAdminProperties.PageName = CommonConstantModel.s_ChangePassword;
                superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                try
                {
                    switch (superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result)
                    {
                        case 0:
                            changePassword.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMFGError");
                            changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;

                        case 4:
                            changePassword.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblCPNoMatch");
                            changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;


                        case 2:
                            changePassword.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblCPUpdated");
                            changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            break;

                    }
                    changePassword.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    changePassword.txtCPoldPassword.Text = string.Empty;
                    changePassword.txtCPnewPassword.Text = string.Empty;
                    changePassword.txtCPconfirmPassword.Text = string.Empty;
                }
                catch
                {
                    throw;
                }

            }
        }

        /// <summary>
        /// This method validates the new password string according to the predefined password standard.
        /// </summary>
        /// <param name="changePassword">object of change password page</param>
        /// <returns>returns boolean</returns>
        internal bool ValidatePasswordPattern(ChangePassword changePassword)
        {
            bool b_Flag = false;
            try
            {
                string[] s_IsInValidPassword = new string[2];
                s_IsInValidPassword = CommonModel.ValidatePasswordPattern(changePassword.txtCPconfirmPassword.Text);
                if (!(string.IsNullOrEmpty(s_IsInValidPassword[0])))
                {
                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        changePassword.ctrSuccessErrorMessage.s_MessageText = genericServiceClient.Get_L10N(s_IsInValidPassword[0], "Message", "COMMON_L10N.xml");
                        changePassword.ctrSuccessErrorMessage.s_MessageText = changePassword.ctrSuccessErrorMessage.s_MessageText + s_IsInValidPassword[1].ToString() + genericServiceClient.Get_L10N(s_IsInValidPassword[2], "Message", "COMMON_L10N.xml");
                    }
                    changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                    changePassword.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    b_Flag = false;
                }
                else
                {
                    b_Flag = true;
                }
            }
            catch
            {
                throw;
            }
            return b_Flag;
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ChangePasswordModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}