﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// Model for MAnageModule.aspx.cs page.
    /// </summary>
    public class ManageModuleModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public ManageModuleModel()
        {
            if (ac_ManageModule == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageModule);
                ac_ManageModule = (CommonModel.AC_ManageModule)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageModule];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty;

        #endregion

        /// <summary>
        /// This Method is used to fetch messages from L10N xml via superadmin WCF service.
        /// </summary>
        /// <param name="MessegeId"></param>
        /// <returns>string as the message</returns>
        public string SAP_L10N(string MessegeId)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                try
                {
                    return superAdminServiceClient.LoadL10N(MessegeId);
                }
                catch
                {
                    throw;
                }
            }

        }

        /// <summary>
        /// This method is used to load all label text from L10N_UI via wcf service
        /// </summary>
        /// <param name="ManageModule">Manage Module Page</param>
        public void BindPageUI(Manage_Module ManageModule)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_ManageModuleUI = superAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_ManageModule))
                    {
                        if ((dt_ManageModuleUI != null) && (dt_ManageModuleUI.Rows.Count > 0))
                        {
                            ManageModule.lblPagehead.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMPagehead'"))[0]["LabelName"]);
                            ManageModule.lblMMAccordMngeHead.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMAccordMngeHead'"))[0]["LabelName"]);
                            ManageModule.lblMMAccordMngeHead.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMAccordMngeHead'"))[0]["LabelToolTip"]);
                            ManageModule.lblMMAccordEditHead.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMAccordEditHead'"))[0]["LabelName"]);
                            ManageModule.lblModuleName.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMName'"))[0]["LabelName"]);
                            ManageModule.lblModuleName.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMName'"))[0]["LabelToolTip"]);
                            ManageModule.lblModuleStatus.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMStatus'"))[0]["LabelName"]);
                            ManageModule.lblModuleStatus.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMStatus'"))[0]["LabelToolTip"]);
                            ManageModule.lblModuleNameEdit.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMNameEdit'"))[0]["LabelName"]);
                            ManageModule.lblModuleNameEdit.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMNameEdit'"))[0]["LabelToolTip"]);
                            ManageModule.lblModuleStatusEdit.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMStatusEdit'"))[0]["LabelName"]);
                            ManageModule.lblModuleStatusEdit.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMStatusEdit'"))[0]["LabelToolTip"]);
                            ManageModule.BtnGridfilter.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='BtnMMGridfilter'"))[0]["LabelName"]);
                            ManageModule.BtnGridfilter.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='BtnMMGridfilter'"))[0]["LabelToolTip"]);
                            ManageModule.btnClearFilter.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMClearFilter'"))[0]["LabelName"]);
                            ManageModule.btnClearFilter.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMClearFilter'"))[0]["LabelToolTip"]);
                            ManageModule.btnCreateNew.Value = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMCreateNew'"))[0]["LabelName"]);
                            ManageModule.btnSubmit.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMSubmit'"))[0]["LabelName"]);
                            ManageModule.btnSubmit.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMSubmit'"))[0]["LabelToolTip"]);
                            ManageModule.btnCancel.Value = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMCancel'"))[0]["LabelName"]);
                            ManageModule.btndelete.Text = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMDelete'"))[0]["LabelName"]);
                            ManageModule.btndelete.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMDelete'"))[0]["LabelToolTip"]);
                            ManageModule.RqdFieldTxtEditMName.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMNameEdit'"))[0]["ErrorText"]);
                            ManageModule.RegExpLoginId.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMNameEdit'"))[0]["ErrorText2"]);
                            ManageModule.StatusValidEdit.ToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='lblMMStatus'"))[0]["ErrorText"]);
                            s_BtnUpdateText = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMUpdate'"))[0]["LabelName"]);
                            s_BtnUpdateToolTip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMUpdate'"))[0]["LabelToolTip"]);
                            s_BtnSaveText = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMSubmit'"))[0]["LabelName"]);
                            s_BtnSaveTooltip = Convert.ToString((dt_ManageModuleUI.Select("LabelID='btnMMSubmit'"))[0]["LabelName"]);
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        /// <summary>
        /// This method is used to load content of IsActive dropdownlist
        /// </summary>
        /// <returns>void</returns>
        internal void CRUDManageModuleDetails(Manage_Module manageModule, string MmId, string s_CRUDOpt)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                superAdminProperties.Id = MmId.Contains(",") ? 0 : Convert.ToInt32(MmId);
                superAdminProperties.Ids = MmId;
                superAdminProperties.Name = CommonModel.ReplaceApostrophe(manageModule.txtCreateEditModuleName.Text);
                superAdminProperties.IsActive = Convert.ToInt16(manageModule.ddCreatenew_IsActive.SelectedValue);
                superAdminProperties.Action = s_CRUDOpt;
                superAdminProperties.PageName = CommonConstantModel.s_ManageModule;
                superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;

                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;

                switch (superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result)
                {
                    case 0:
                        manageModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMError");
                        manageModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        manageModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                        manageModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                        break;

                    case 1:
                        manageModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMAdded");
                        manageModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                        manageModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                        break;


                    case 2:
                        manageModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMUpdated");
                        manageModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                        manageModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                        break;


                    case 3:
                        manageModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMRowDeleted");
                        manageModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                        manageModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                        break;

                    case 4:
                        manageModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMModNameExists");
                        manageModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                        manageModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                        break;

                    case 5:
                        manageModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMReverse");
                        manageModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                        manageModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "block";
                        ac_ManageModule.reversingModuleName = superAdminProperties.Name;
                        ac_ManageModule.reversingModuleStatus = superAdminProperties.IsActive;
                        break;

                    case 7:
                        manageModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMModCantBeDeleted");
                        manageModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                        manageModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                        break;
                }
                manageModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                manageModule.txtCreateEditModuleName.Text = "";
                manageModule.ddCreatenew_IsActive.SelectedIndex = 0;
                manageModule.UpdMessages.Update();

            }
        }

        /// <summary>
        /// This method reverse the deleted item and makes it usable again
        /// </summary>
        /// <param name="manageModule">Manage_Module Page</param>
        public void ReverseDeletedRecord(Manage_Module manageModule)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.Name = ac_ManageModule.reversingModuleName;
                    superAdminProperties.IsActive = ac_ManageModule.reversingModuleStatus;
                    superAdminProperties.Action = "REV";
                    superAdminProperties.PageName = CommonConstantModel.s_ManageModule;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                    switch (superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result)
                    {
                        case 0:
                            manageModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMError");
                            manageModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;

                        case 6:
                            manageModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMUpdated");
                            manageModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            break;
                    }
                    manageModule.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                    manageModule.txtCreateEditModuleName.Text = "";
                    manageModule.ddCreatenew_IsActive.SelectedIndex = 0;
                    manageModule.UpdMessages.Update();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="manageModule"></param>
        /// <param name="s_Action">Action to be performed</param>
        public void LoadGridData(Manage_Module manageModule, string s_Action)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.Name = manageModule.ddModuleName.SelectedItem != null ? manageModule.ddModuleName.SelectedItem.ToString() : "";
                    superAdminProperties.Action = s_Action;
                    superAdminProperties.PageName = CommonConstantModel.s_ManageModule;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    ac_ManageModule.dt_GridViewDataTable = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result;
                    manageModule.gv.DataSource = ac_ManageModule.dt_GridViewDataTable;
                    manageModule.gv.DataBind();
                    manageModule.updGridView.Update();
                    manageModule.btndelete.Visible = manageModule.gv.Rows.Count > 0 ? true : false;
                    manageModule.btnClearFilter.Visible = false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is responsible to execute filtering action on GridView.
        /// </summary>
        /// <param name="manageModule">Manage Module Page</param>
        public void FilterGridData(Manage_Module manageModule)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {

                try
                {
                    string s_ModuleName = manageModule.ddModuleName.SelectedIndex > 0 ? "[Module Name] = '" + Convert.ToString(manageModule.ddModuleName.SelectedValue) + "'" : string.Empty;
                    string s_Status = manageModule.ddIsActive.SelectedItem.ToString() != "--- Please Select ---" ? "[Status] = '" + Convert.ToString(manageModule.ddIsActive.SelectedItem.ToString()) + "'" : string.Empty;


                    if ((!(string.IsNullOrEmpty(s_ModuleName))) || (!(string.IsNullOrEmpty(s_Status))))
                    {
                        manageModule.btnClearFilter.Visible = true;
                        manageModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    }

                    ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_GridViewDataTable;

                    try
                    {
                        if (!(string.IsNullOrEmpty(s_ModuleName)))
                            ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_ModuleDataTable.Select("" + s_ModuleName + "").CopyToDataTable();

                        if (!(string.IsNullOrEmpty(s_Status)))
                            ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_ModuleDataTable.Select("" + s_Status + "").CopyToDataTable();

                        if ((string.IsNullOrEmpty(s_Status) && string.IsNullOrEmpty(s_ModuleName)))
                        {
                            ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_GridViewDataTable;
                            manageModule.btnClearFilter.Visible = false;
                        }
                    }
                    catch
                    {
                        ac_ManageModule.dt_ModuleDataTable = new DataTable();
                    }

                    manageModule.gv.DataSource = ac_ManageModule.dt_ModuleDataTable;
                    manageModule.gv.DataBind();
                    manageModule.updGridView.Update();
                    manageModule.btndelete.Visible = manageModule.gv.Rows.Count > 0 ? true : false;
                }
                catch
                {
                    throw;
                }

            }
        }

        /// <summary>
        /// this method loads Module_Name dropdownlist
        /// </summary>
        /// <returns>DropDownList</returns>
        public DropDownList loadModuleNameDropdown(DropDownList dropdownlist)
        {
            try
            {
                superAdminProperties.Action = "N";
                superAdminProperties.PageName = CommonConstantModel.s_ManageModule;
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    dropdownlist.DataSource = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result;
                    dropdownlist.DataTextField = "MODULE_NAME";
                    dropdownlist.DataBind();
                }

                return dropdownlist;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method loads IsActive selection dropdownlist
        /// </summary>
        /// <param name="dropDownList"></param>
        /// <param name="s_Action"></param>
        /// <returns></returns>
        public DropDownList Load_ddIsactive(DropDownList dropDownList, string s_Action)
        {
            try
            {
                superAdminProperties.Action = s_Action;
                superAdminProperties.PageName = CommonConstantModel.s_ManageModule;
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;

                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    dropDownList.DataSource = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result;
                    dropDownList.DataTextField = "DATA";
                    dropDownList.DataValueField = "VALUE";
                    dropDownList.DataBind();
                }
                return dropDownList;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method Adds 'Delete all' checkbox in the Header Part
        /// </summary>
        /// <returns>Checkbox</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chkDeleteAll";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Text = string.Empty;
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }

        /// <summary>
        /// This Method binds row in gridview / hides some of the columns .
        /// </summary>
        /// <param name="e">gridviewRow event</param>
        /// <param name="n_index"> index number</param>
        /// <param name="n_ID">MMID</param>
        /// <param name="n_Delete">Delete ID</param>
        /// <param name="n_Action">Action to be performed</param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "MMID":
                                n_ID = n_index;
                                perColumn.Visible = false;
                                break;

                            case "DELETE":
                                n_Delete = n_index;
                                e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                break;

                            case "ACTION":
                                n_Action = n_index;
                                break;
                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    try
                    {
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, "Edit"));
                        e.Row.Cells[1].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        e.Row.Cells[n_Delete].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        break;
                    }
                    catch
                    {
                        throw;
                    }
            }
        }

        /// <summary>
        /// This method adds image button to gridview Action column at runtime .
        /// </summary>
        /// <param name="s_strToolTip">ToolTip for Button</param>
        /// <param name="s_strUrl">Image Url</param>
        /// <param name="s_MMID">Module Id</param>
        /// <param name="s_MMName">Module Name</param>
        /// <param name="s_Status">status</param>
        /// <param name="s_Action">Action to be performed</param>
        /// <returns>Imagebutton</returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_MMID, string s_MMName, string s_Status, string s_Action)
        {
            int n_Status = s_Status == "Activated" ? 2 : 1;
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");
                if (!string.IsNullOrEmpty(s_MMName))
                {
                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_MMName + "','" + n_Status + "','" + s_MMID + "','" + 1 + "')");
                    }
                }
                return imgButton;
            }
        }


        /// <summary>
        /// This Method add checkboxes in the gridview first column.
        /// </summary>
        /// <param name="s_ManageModuleGroupID"></param>
        /// <param name="IsDeleted"></param>
        /// <returns></returns>
        private CheckBox AddCheckBox(string s_ManageModuleGroupID, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_ManageModuleGroupID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");

                if (!string.IsNullOrEmpty(s_ManageModuleGroupID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_ManageModuleGroupID + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// To change pages of gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <param name="gv"></param>
        /// <param name="s_ManageModuleGroupID"></param>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_ManageModuleGroupID)
        {
            try
            {
                string[] s_AssociateModuleGpID = s_ManageModuleGroupID.TrimStart(',').Split(',');
                foreach (string perID in s_AssociateModuleGpID)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_ManageModule.dt_GridViewDataTable.Select("MMID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_ManageModule.dt_GridViewDataTable;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ManageModuleModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}