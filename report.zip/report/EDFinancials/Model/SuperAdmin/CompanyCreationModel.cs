﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;
using System.Linq;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// 
    /// </summary>
    public class CompanyCreationModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public CompanyCreationModel()
        {
            if (ac_CompanyCreation == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_CompanyCreation);
                ac_CompanyCreation = (CommonModel.AC_CompanyCreation)HttpContext.Current.Session[CommonConstantModel.s_AC_CompanyCreation];
            }
        }

        /// <summary>
        /// Method is used bind UI for Company Creation Page
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>        
        internal void BindPageUI(CompanyCreation companyCreation)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_CompanyCreationUI = superAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_CompanyCreation))
                    {
                        if ((dt_CompanyCreationUI != null) && (dt_CompanyCreationUI.Rows.Count > 0))
                        {
                            companyCreation.lblCCPageHeader.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCPageHeader'"))[0]["LabelName"]);
                            companyCreation.lblCCSearch.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCSearch'"))[0]["LabelName"]);
                            companyCreation.lblCCHeaderCURD.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCHeaderCURD'"))[0]["LabelName"]);
                            companyCreation.lblCCCompanyName.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCompanyName'"))[0]["LabelName"]);
                            companyCreation.lblCCCompanyName.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCompanyName'"))[0]["LabelToolTip"]);
                            companyCreation.lblCCCreatedDateFrom.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCreatedDateFrom'"))[0]["LabelName"]);
                            companyCreation.lblCCCreatedDateFrom.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCreatedDateFrom'"))[0]["LabelToolTip"]);
                            companyCreation.lblCCCreatedDateTo.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCreatedDateTo'"))[0]["LabelName"]);
                            companyCreation.lblCCCreatedDateTo.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCreatedDateTo'"))[0]["LabelToolTip"]);
                            companyCreation.lblCCCompanyType.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCompanyType'"))[0]["LabelName"]);
                            companyCreation.lblCCCompanyType.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCompanyType'"))[0]["LabelToolTip"]);
                            companyCreation.lblCCListingStatus.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCListingStatus'"))[0]["LabelName"]);
                            companyCreation.lblCCListingStatus.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCListingStatus'"))[0]["LabelToolTip"]);
                            companyCreation.lblCCDatabaseName.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCDatabaseName'"))[0]["LabelName"]);
                            companyCreation.lblCCDatabaseName.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCDatabaseName'"))[0]["LabelToolTip"]);
                            companyCreation.btnCCSearch.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCCSearch'"))[0]["LabelName"]);
                            companyCreation.btnCCSearch.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCCSearch'"))[0]["LabelToolTip"]);
                            companyCreation.btnCCCreate.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCCCreate'"))[0]["LabelName"]);
                            companyCreation.btnCCCreate.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCCCreate'"))[0]["LabelToolTip"]);
                            companyCreation.lblCURDCompanyName.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCompanyName'"))[0]["LabelName"]);
                            companyCreation.lblCURDCompanyName.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCompanyName'"))[0]["LabelToolTip"]);
                            companyCreation.lblCRUDCompanyType.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCompanyType'"))[0]["LabelName"]);
                            companyCreation.lblCRUDCompanyType.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCCompanyType'"))[0]["LabelToolTip"]);
                            companyCreation.lblCRUDListingStatus.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCListingStatus'"))[0]["LabelName"]);
                            companyCreation.lblCRUDListingStatus.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCListingStatus'"))[0]["LabelToolTip"]);
                            companyCreation.lblCRUDDatabaseNameL.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCDatabaseName'"))[0]["LabelName"]);
                            companyCreation.lblCRUDDatabaseNameL.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCDatabaseName'"))[0]["LabelToolTip"]);
                            companyCreation.lblCRUDDatabaseNameUNL.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCDatabaseName'"))[0]["LabelName"]);
                            companyCreation.lblCRUDDatabaseNameUNL.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCDatabaseName'"))[0]["LabelToolTip"]);
                            companyCreation.lblCRUDAdminMailId.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDAdminMailId'"))[0]["LabelName"]);
                            companyCreation.lblCRUDAdminMailId.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDAdminMailId'"))[0]["LabelToolTip"]);
                            companyCreation.lblCRUDDefaultParm.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDDefaultParm'"))[0]["LabelName"]);
                            companyCreation.lblCRUDDefaultParm.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDDefaultParm'"))[0]["LabelToolTip"]);
                            companyCreation.btnCURDCreate.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCURDCreate'"))[0]["LabelName"]);
                            companyCreation.btnCURDCreate.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCURDCreate'"))[0]["LabelToolTip"]);
                            companyCreation.btnCURDCancel.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCURDCancel'"))[0]["LabelName"]);
                            companyCreation.btnCURDCancel.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCURDCancel'"))[0]["LabelToolTip"]);
                            companyCreation.valReqCompanyName.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'valReqCompanyName'"))[0]["LabelToolTip"]);
                            companyCreation.valReqAdminEmailId.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'valReqAdminEmailId'"))[0]["LabelToolTip"]);
                            companyCreation.valRegAdminEmialId.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'valRegAdminEmialId'"))[0]["LabelToolTip"]);
                            companyCreation.btnClearFilter.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnClearFilter'"))[0]["LabelName"]);
                            companyCreation.btnClearFilter.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnClearFilter'"))[0]["LabelToolTip"]);
                            companyCreation.lblCRUDModuleId.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDModuleId'"))[0]["LabelName"]);
                            companyCreation.lblCRUDModuleId.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDModuleId'"))[0]["LabelToolTip"]);
                            companyCreation.lblCRUDSubModule.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDSubModule'"))[0]["LabelName"]);
                            companyCreation.lblCRUDSubModule.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDSubModule'"))[0]["LabelToolTip"]);
                            companyCreation.btnCRUDAddToGrid.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCRUDAddToGrid'"))[0]["LabelName"]);
                            companyCreation.btnCRUDAddToGrid.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCRUDAddToGrid'"))[0]["LabelToolTip"]);
                            companyCreation.valRegNonMyESOPDBName.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'valRegNonMyESOPDBName'"))[0]["LabelToolTip"]);
                            companyCreation.valReqMyESOPsDBName.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'valReqMyESOPsDBName'"))[0]["LabelToolTip"]);
                            companyCreation.valReqNonMyESOPsDBName.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'valReqNonMyESOPsDBName'"))[0]["LabelToolTip"]);
                            companyCreation.valReqCompanyType.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'valReqCompanyType'"))[0]["LabelToolTip"]);
                            companyCreation.valReqListingStatus.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'valReqListingStatus'"))[0]["LabelToolTip"]);
                            companyCreation.lblCRUDAppFromDate.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDAppFromDate'"))[0]["LabelName"]);
                            companyCreation.lblCRUDAppFromDate.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDAppFromDate'"))[0]["LabelToolTip"]);
                            companyCreation.rfvCRUDAppFromDate.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDAppFromDate'"))[0]["ErrorText"]);
                            companyCreation.lblModuleViewPopHeading.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblModuleAssociationList'"))[0]["LabelName"]);
                            companyCreation.lblCompanyCreationRemark.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCompanyCreationRemark'"))[0]["LabelName"]);
                            companyCreation.lblCompanyCreationRemark.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCompanyCreationRemark'"))[0]["LabelToolTip"]);
                            companyCreation.lblCCIsSaasClient.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCIsSaasClient'"))[0]["LabelName"]);
                            companyCreation.lblCCIsSaasClient.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCIsSaasClient'"))[0]["LabelToolTip"]);
                            companyCreation.lblCalMethod.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCalMethod'"))[0]["LabelName"]);
                            companyCreation.lblCalMethod.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCalMethod'"))[0]["LabelToolTip"]);
                            companyCreation.ReqddAmCMethod.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID='lblCalMethod'"))[0]["ErrorText"]);
                            companyCreation.lblAMMMName.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDModuleId'"))[0]["LabelName"]);
                            companyCreation.lblAMMMName.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDModuleId'"))[0]["LabelToolTip"]);
                            companyCreation.lblAMSMName.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDSubModule'"))[0]["LabelName"]);
                            companyCreation.lblAMSMName.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDSubModule'"))[0]["LabelToolTip"]);
                            companyCreation.lblAMCMName.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCalMethod'"))[0]["LabelName"]);
                            companyCreation.lblAMCMName.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCalMethod'"))[0]["LabelToolTip"]);
                            companyCreation.lblCCStatusEdit.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCStatusEdit'"))[0]["LabelName"]);
                            companyCreation.lblCCStatusEdit.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCStatusEdit'"))[0]["LabelToolTip"]);

                            companyCreation.lblEditModuleHeading.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblEditModuleHeading'"))[0]["LabelName"]);
                            companyCreation.lblEditModuleHeading.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblEditModuleHeading'"))[0]["LabelToolTip"]);
                            companyCreation.lblCompanyHeading.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCompanyHeading'"))[0]["LabelName"]);
                            companyCreation.lblCompanyHeading.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCompanyHeading'"))[0]["LabelToolTip"]);
                            companyCreation.btnCCAddSubmit.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCCAddSubmit'"))[0]["LabelName"]);
                            companyCreation.btnCCAddSubmit.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCCAddSubmit'"))[0]["LabelToolTip"]);
                            companyCreation.btnCC_AddCancel.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCURDCancel'"))[0]["LabelName"]);
                            companyCreation.BtnEditCancel.Value = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnCURDCancel'"))[0]["LabelName"]);

                            companyCreation.RngeValidtrMM.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDModuleId'"))[0]["LabelToolTip"]);
                            companyCreation.RngeValidtrSM.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCRUDSubModule'"))[0]["LabelToolTip"]);
                            companyCreation.rqdCcCalMethod.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCalMethod'"))[0]["LabelToolTip"]);
                            companyCreation.redCCValidMStatus.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'lblCCStatusEdit'"))[0]["LabelToolTip"]);
                            companyCreation.btnExportToExcel.Text = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnExportToExcel'"))[0]["LabelName"]);
                            companyCreation.btnExportToExcel.ToolTip = Convert.ToString((dt_CompanyCreationUI.Select("LabelID = 'btnExportToExcel'"))[0]["LabelToolTip"]);

                            companyCreation.btnClearFilter.Visible = false;

                            companyCreation.trDDLDatabaseName.Visible = false;
                            companyCreation.trTXTDatabaseName.Visible = true;

                            ac_CompanyCreation.dt_TempModulAssociationDetails = new DataTable();

                            companyCreation.ddlCRUDSubModule.Items.Insert(0, "--- Please Select ---");

                            companyCreation.btnCURDCreate.Visible = false;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used bind controls
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void BindControls(CompanyCreation companyCreation)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    ac_CompanyCreation.dt_GetCompanyDetails = superAdminServiceClient.GetCompanyDetails(superAdminProperties);
                    ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_GetCompanyDetails;

                    // bind Company Name drop down list available in search context
                    companyCreation.ddlCCCompanyName.DataSource = (DataTable)ac_CompanyCreation.dt_GetCompanyDetails;
                    companyCreation.ddlCCCompanyName.DataTextField = "Company Name";
                    companyCreation.ddlCCCompanyName.DataValueField = "Company Name";
                    companyCreation.ddlCCCompanyName.DataBind();
                    companyCreation.ddlCCCompanyName.Items.Insert(0, "--- Please Select ---");

                    // bind Database Name drop down list available in search context
                    companyCreation.ddlCCDatabaseName.DataSource = (DataTable)ac_CompanyCreation.dt_GetCompanyDetails;
                    companyCreation.ddlCCDatabaseName.DataTextField = "Database Name";
                    companyCreation.ddlCCDatabaseName.DataValueField = "Database Name";
                    companyCreation.ddlCCDatabaseName.DataBind();
                    companyCreation.ddlCCDatabaseName.Items.Insert(0, "--- Please Select ---");

                    // bind grid view
                    companyCreation.gv.DataSource = ac_CompanyCreation.dt_GetCompanyDetails;
                    companyCreation.gv.DataBind();
                }
            }
            catch
            {
                throw;
            }

            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    // bind company type drop down list available in search context
                    companyCreation.ddlCCCompanyType.DataSource = (DataTable)genericServiceClient.GetCompanyType(genericProperties);
                    companyCreation.ddlCCCompanyType.DataTextField = "COMPANY_TYPE";
                    companyCreation.ddlCCCompanyType.DataValueField = "CTID";
                    companyCreation.ddlCCCompanyType.DataBind();
                    companyCreation.ddlCCCompanyType.Items.Insert(0, "--- Please Select ---");

                    // bind listing status drop down list available in search context
                    companyCreation.ddlCCListingStatus.DataSource = (DataTable)genericServiceClient.GetListingStatus(genericProperties);
                    companyCreation.ddlCCListingStatus.DataTextField = "LISTING_STATUS";
                    companyCreation.ddlCCListingStatus.DataValueField = "LSID";
                    companyCreation.ddlCCListingStatus.DataBind();
                    companyCreation.ddlCCListingStatus.Items.Insert(0, "--- Please Select ---");

                    // bind company type drop down list available for CURD context
                    companyCreation.ddlCRUDCompanyType.DataSource = (DataTable)genericServiceClient.GetCompanyType(genericProperties);
                    companyCreation.ddlCRUDCompanyType.DataTextField = "COMPANY_TYPE";
                    companyCreation.ddlCRUDCompanyType.DataValueField = "CTID";
                    companyCreation.ddlCRUDCompanyType.DataBind();
                    companyCreation.ddlCRUDCompanyType.Items.Insert(0, "--- Please Select ---");

                    // bind listing status drop down list available for CURD context
                    companyCreation.ddlCRUDListingStatus.DataSource = (DataTable)genericServiceClient.GetListingStatus(genericProperties);
                    companyCreation.ddlCRUDListingStatus.DataTextField = "LISTING_STATUS";
                    companyCreation.ddlCRUDListingStatus.DataValueField = "LSID";
                    companyCreation.ddlCRUDListingStatus.DataBind();
                    companyCreation.ddlCRUDListingStatus.Items.Insert(0, "--- Please Select ---");

                    // bind MyESOPs Client List                    
                    companyCreation.ddlCRUDDatabaseName.DataSource = (DataTable)genericServiceClient.GetMyESOPsClientList(genericProperties);
                    companyCreation.ddlCRUDDatabaseName.DataTextField = "CNAME";
                    companyCreation.ddlCRUDDatabaseName.DataValueField = "CNAME";
                    companyCreation.ddlCRUDDatabaseName.DataBind();
                    companyCreation.ddlCRUDDatabaseName.Items.Insert(0, "--- Please Select ---");
                }
            }
            catch
            {
                throw;
            }

            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                try
                {
                    SuperAdminCRUDProperties superAdminCRUDProperties = ReadDetails(superAdminServiceClient, "POPULATE_CONTROLS", userSessionInfo.ACC_CompanyName);
                    ac_CompanyCreation.dt_ModuleAssociationDetails = superAdminCRUDProperties.dt_Result;
                    companyCreation.ddlCRUDModuleId.DataSource = ac_CompanyCreation.dt_ModuleAssociationDetails.DefaultView.ToTable(true, "MMID", "Module");
                    companyCreation.ddlCRUDModuleId.DataTextField = "Module";
                    companyCreation.ddlCRUDModuleId.DataValueField = "MMID";
                    companyCreation.ddlCRUDModuleId.DataBind();
                    companyCreation.ddlCRUDModuleId.Items.Insert(0, "--- Please Select ---");
                    companyCreation.ddlCRUDSubModule.SelectedIndex = -1;
                    companyCreation.ddAMMMName.DataSource = ac_CompanyCreation.dt_ModuleAssociationDetails.DefaultView.ToTable(true, "MMID", "Module");
                    companyCreation.ddAMMMName.DataTextField = "Module";
                    companyCreation.ddAMMMName.DataValueField = "MMID";
                    companyCreation.ddAMMMName.DataBind();
                    companyCreation.ddAMMMName.Items.Insert(0, "--- Please Select ---");
                    companyCreation.ddAMMMName.SelectedIndex = -1;
                    companyCreation.ddAMSMName.Items.Insert(0, "--- Please Select ---");
                    companyCreation.ddAMSMName.DataBind();
                }
                catch
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// This method Namvigates back to search panel section.
        /// </summary>
        /// <param name="companyCreation">companyCreation object</param>
        /// <param name="b_UpadateStatus">Status to check whether cancel button is clicked or Seach Panel is clicked.</param>
        public void BacktoSearch(CompanyCreation companyCreation, bool b_UpadateStatus)
        {
            try
            {
                companyCreation.h3SearchPanel.Style.Add("display", "block");
                companyCreation.h3AddEditModules.Style.Add("display", "none");
                companyCreation.hdnIsPanelExpand.Value = "0";
                companyCreation.h3AddEdit.Style.Add("display", "none");
                companyCreation.divAddModule.Style.Add("display", "none");
                companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                companyCreation.ddAMMMName.SelectedIndex = 0;
                companyCreation.ddAMSMName.SelectedIndex = 0;
                companyCreation.ddAMSMName.Enabled = false;
                companyCreation.ctrSuccessErrorMessage.s_MessageText = string.Empty;

                companyCreation.gv.DataSource = ac_CompanyCreation.dt_TempCompanyDetails;
                companyCreation.gv.DataBind();

                if (b_UpadateStatus)
                    companyCreation.upnlCompanyCreation.Update();
                else
                    companyCreation.updAdd.Update();
            }
            catch
            {
                throw;
            }

        }
        /// <summary>
        /// Method is used to read details from the database.
        /// </summary>
        /// <param name="superAdminServiceClient">Pass parameter as SuperAdminServices object</param>
        /// <param name="s_PopulateControl">Pass parameter as populate control name</param>
        /// <param name="s_CompanyName">Pass parameter as company name</param>
        /// <returns></returns>
        private SuperAdminCRUDProperties ReadDetails(SuperAdminServiceClient superAdminServiceClient, string s_PopulateControl, string s_CompanyName)
        {
            try
            {
                superAdminProperties.PageName = CommonConstantModel.s_CompanyCreation;
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.PopulateControls = s_PopulateControl;
                superAdminProperties.SEN_CompanyName = s_CompanyName;

                superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                return superAdminCRUDProperties;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view Row data bound event
        /// </summary>
        /// <param name="sender">Pass parameter as sender</param>
        /// <param name="e">Pass parameter as Event Args</param>
        /// <param name="companyCreation">Pass parameter as page</param>
        /// <param name="n_index">Pass parameter for row index</param>
        /// <param name="n_ID">Pass parameter for company id</param>
        /// <param name="n_CompCreatedOn">Pass parameter as company created on</param> 
        /// <param name="n_ModuleAssociastion">n_ModuleAssociastion index</param> 
        /// <param name="n_Remark">n_Remark index</param> 
        /// <param name="n_Action">n_Action index</param> 
        internal void GvRowDatabaBind(object sender, GridViewRowEventArgs e, CompanyCreation companyCreation, ref int n_index, ref int n_ID, ref int n_CompCreatedOn, ref int n_ModuleAssociastion, ref int n_Remark, ref int n_Action)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "ID":
                                n_ID = n_index;
                                perColumn.Visible = false;
                                break;

                            case "COMP CREATED ON":
                                n_CompCreatedOn = n_index;
                                perColumn.Visible = false;
                                break;

                            case "MODULE":
                                n_ModuleAssociastion = n_index;
                                break;

                            case "REMARK":
                                n_Remark = n_index;
                                break;

                            case "ACTION":
                                n_Action = n_index;
                                break;
                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    e.Row.Cells[n_ID].Visible = false;
                    e.Row.Cells[n_CompCreatedOn].Visible = false;
                    e.Row.Cells[n_ModuleAssociastion].Controls.Add(AddImageLink("View Module", "~/View/App_Themes/images/View.png", e.Row.Cells[2].Text));
                    e.Row.Cells[n_Action].Controls.Add(EditImageLink("Add", "~/View/App_Themes/images/Add.png", e.Row.Cells[0].Text, e.Row.Cells[1].Text, e.Row.Cells[2].Text, "Add"));
                    e.Row.Cells[n_Action].Controls.Add(EditImageLink("Edit", "~/View/App_Themes/images/Edit.png", "0", e.Row.Cells[1].Text, e.Row.Cells[2].Text, "Edit"));
                    e.Row.Cells[n_ModuleAssociastion].HorizontalAlign = HorizontalAlign.Center;
                    e.Row.Cells[n_Remark].Attributes.Add("style", "word-break:break-all;word-wrap:break-word");
                    break;
            }
        }

        /// <summary>
        /// Method is used to apply Filter on grid
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void ApplyFilterToGrid(CompanyCreation companyCreation)
        {
            try
            {
                string s_CompanyName = companyCreation.ddlCCCompanyName.SelectedIndex > 0 ? "[Company Name] = '" + Convert.ToString(companyCreation.ddlCCCompanyName.SelectedValue) + "'" : string.Empty;
                string s_DatabaseName = companyCreation.ddlCCDatabaseName.SelectedIndex > 0 ? "[Database Name] = '" + Convert.ToString(companyCreation.ddlCCDatabaseName.SelectedValue) + "'" : string.Empty;
                string s_CompanyType = companyCreation.ddlCCCompanyType.SelectedIndex > 0 ? "[Company Type] = '" + Convert.ToString(companyCreation.ddlCCCompanyType.SelectedItem) + "'" : string.Empty;
                string s_IsListed = companyCreation.ddlCCListingStatus.SelectedIndex > 0 ? "[Listing Status] = '" + Convert.ToString(companyCreation.ddlCCListingStatus.SelectedItem) + "'" : string.Empty;
                string s_FromDate = string.IsNullOrEmpty(companyCreation.datepickerFromDate.Value) || companyCreation.datepickerFromDate.Value.Equals("dd/mmm/yyyy") ? string.Empty : "[Comp Created On] = '" + Convert.ToDateTime(companyCreation.datepickerFromDate.Value).Date + "'";
                string s_ToDate = string.IsNullOrEmpty(companyCreation.datepickerToDate.Value) || companyCreation.datepickerToDate.Value.Equals("dd/mmm/yyyy") ? string.Empty : "[Comp Created On] = '" + Convert.ToDateTime(companyCreation.datepickerToDate.Value).Date + "'";
                string s_DateCompair = string.Empty;

                if ((!(string.IsNullOrEmpty(s_FromDate))) && ((string.IsNullOrEmpty(s_ToDate))))
                {
                    s_DateCompair = "[Comp Created On] >= #" + Convert.ToDateTime(companyCreation.datepickerFromDate.Value).Date + "# AND [Comp Created On] <= #" + System.DateTime.Now.Date + "# ";
                }
                else if ((!(string.IsNullOrEmpty(s_FromDate))) && (!(string.IsNullOrEmpty(s_ToDate))))
                {
                    s_DateCompair = "[Comp Created On] >= #" + Convert.ToDateTime(companyCreation.datepickerFromDate.Value).Date + "# AND [Comp Created On] <= #" + Convert.ToDateTime(companyCreation.datepickerToDate.Value).Date + "# ";
                }

                if ((!(string.IsNullOrEmpty(s_CompanyName))) || (!(string.IsNullOrEmpty(s_DatabaseName))) || (!(string.IsNullOrEmpty(s_CompanyType)))
                    || (!(string.IsNullOrEmpty(s_IsListed))) || (!(string.IsNullOrEmpty(s_FromDate))) || (!(string.IsNullOrEmpty(s_ToDate))))
                {
                    companyCreation.btnClearFilter.Visible = true;
                }

                ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_GetCompanyDetails;

                try
                {
                    if (!(string.IsNullOrEmpty(s_CompanyName)))
                        ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_TempCompanyDetails.Select("" + s_CompanyName + "").CopyToDataTable();

                    ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_TempCompanyDetails.Select("[Company Name] like '%" + Convert.ToString(companyCreation.ddlCCCompanyName.SelectedValue) + "%'").CopyToDataTable();

                    if (!(string.IsNullOrEmpty(s_DatabaseName)))
                        ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_TempCompanyDetails.Select("" + s_DatabaseName + "").CopyToDataTable();

                    if (!(string.IsNullOrEmpty(s_CompanyType)))
                        ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_TempCompanyDetails.Select("" + s_CompanyType + "").CopyToDataTable();

                    if (!(string.IsNullOrEmpty(s_IsListed)))
                        ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_TempCompanyDetails.Select("" + s_IsListed + "").CopyToDataTable();

                    if ((!(string.IsNullOrEmpty(s_FromDate))) && ((string.IsNullOrEmpty(s_ToDate))))
                    {
                        ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_TempCompanyDetails.Select("" + s_DateCompair + "").CopyToDataTable();
                    }
                    else if ((!(string.IsNullOrEmpty(s_FromDate))) && (!(string.IsNullOrEmpty(s_ToDate))))
                    {
                        ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_TempCompanyDetails.Select("" + s_DateCompair + "").CopyToDataTable();
                    }
                    else
                    {
                        if (!(string.IsNullOrEmpty(s_FromDate)))
                            ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_TempCompanyDetails.Select("" + s_FromDate + "").CopyToDataTable();

                        if (!(string.IsNullOrEmpty(s_ToDate)))
                            ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_TempCompanyDetails.Select("" + s_ToDate + "").CopyToDataTable();
                    }
                }
                catch
                {
                    ac_CompanyCreation.dt_TempCompanyDetails = new DataTable();
                }

                companyCreation.gv.DataSource = ac_CompanyCreation.dt_TempCompanyDetails;
                companyCreation.gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to Clear filter from grid
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void ClearFilterFromGrid(CompanyCreation companyCreation)
        {
            try
            {
                ResetFilter(companyCreation);

                LoadGvData(companyCreation);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to Clear filter from grid
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        private void ResetFilter(CompanyCreation companyCreation)
        {
            try
            {
                companyCreation.ddlCCCompanyName.SelectedIndex = companyCreation.ddlCCDatabaseName.SelectedIndex = companyCreation.ddlCCCompanyType.SelectedIndex = companyCreation.ddlCCListingStatus.SelectedIndex = -1;
                companyCreation.datepickerFromDate.Value = companyCreation.datepickerToDate.Value = string.Empty;


                ac_CompanyCreation.dt_TempCompanyDetails = ac_CompanyCreation.dt_GetCompanyDetails;
                companyCreation.btnClearFilter.Visible = false;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method Loads Main gridview Gv
        /// </summary>
        /// <param name="companyCreation">companyCreation page object</param>
        public void LoadGvData(CompanyCreation companyCreation)
        {
            companyCreation.gv.DataSource = ac_CompanyCreation.dt_GetCompanyDetails;
            companyCreation.gv.DataBind();
        }

        /// <summary>
        /// Method is used to Create Company perform  CURD operation
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void CompanyCreation(CompanyCreation companyCreation)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.PageName = CommonConstantModel.s_CompanyCreation;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.FILE_NAME = "PROC_ACC_COMPANY_CREATION";

                    superAdminProperties.CompanyName = CommonModel.ReplaceApostrophe(companyCreation.txtCRUDCompanyName.Text);

                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CompanyType = Convert.ToInt32(Convert.ToString(companyCreation.ddlCRUDCompanyType.SelectedValue));
                    superAdminProperties.IsListed = Convert.ToInt32(Convert.ToString(companyCreation.ddlCRUDListingStatus.SelectedValue));
                    superAdminProperties.Is_Saas_Client = companyCreation.chkCCIsSaasClient.Checked;
                    superAdminProperties.Remark = CommonModel.ReplaceApostrophe(companyCreation.txtCompanyCreationRemark.Text);
                    superAdminProperties.DateOfListing = Convert.ToString(Convert.ToDateTime(companyCreation.txtCRUDDateOfListing.Value));

                    switch (superAdminProperties.CompanyType)
                    {
                        case 0:
                            superAdminProperties.DatabaseName = CommonModel.ReplaceApostrophe(companyCreation.txtCRUDDatabaseName.Text);
                            break;

                        case 1:
                            superAdminProperties.DatabaseName = Convert.ToString(companyCreation.ddlCRUDDatabaseName.SelectedValue);
                            break;
                    }

                    superAdminProperties.DefaultDatabaseName = (companyCreation.ddlCRUDDefaultCompany.SelectedValue == "--- Please Select ---") ? "DEFAULT_COMPANY" : Convert.ToString(companyCreation.ddlCRUDDefaultCompany.SelectedValue);
                    superAdminProperties.AdminEmaiId = CommonModel.ReplaceApostrophe(companyCreation.txtCRUDAdminMailId.Text);

                    ac_CompanyCreation.dt_TempModulAssociationDetails.TableName = "DT";
                    superAdminProperties.dt_CompanyModuleAssociation = ac_CompanyCreation.dt_TempModulAssociationDetails;

                    if (superAdminProperties.dt_CompanyModuleAssociation.Rows.Count == 0)
                    {
                        throw new EDFinancialsException(superAdminServiceClient.LoadL10N("CCSelectModule"));
                    }

                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    }

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                    StringBuilder sbMessage = new StringBuilder();
                    bool b_IsSuccessful = false;

                    if ((superAdminCRUDProperties.ds_Result != null) && (superAdminCRUDProperties.ds_Result.Tables.Count > 0))
                    {
                        for (int i = 0; i < superAdminCRUDProperties.ds_Result.Tables.Count; i++)
                        {
                            switch (superAdminCRUDProperties.ds_Result.Tables.Count)
                            {
                                case 1:
                                    foreach (DataRow drRecord in superAdminCRUDProperties.ds_Result.Tables[i].Rows)
                                    {
                                        sbMessage.Append(drRecord["ReturnMessage"]);
                                        ClearCRUDDetails(companyCreation, false);
                                        b_IsSuccessful = true;
                                    }
                                    break;

                                default:
                                    foreach (DataRow drRecord in superAdminCRUDProperties.ds_Result.Tables[i].Rows)
                                    {
                                        sbMessage.AppendLine("<br/>");
                                        sbMessage.Append(Convert.ToString(i + 1) + ".");
                                        sbMessage.Append("\t"); sbMessage.Append("\t");
                                        sbMessage.Append("User Message: "); sbMessage.Append("\t"); sbMessage.Append(drRecord["ReturnMessage"]);
                                        sbMessage.Append("\t"); sbMessage.Append("\t");
                                        sbMessage.Append("ErrorNumber : "); sbMessage.Append("\t"); sbMessage.Append(drRecord["ErrorNumber"]);
                                        sbMessage.Append("\t"); sbMessage.Append("\t");
                                        sbMessage.Append("ErrorProcedure : "); sbMessage.Append("\t"); sbMessage.Append(drRecord["ErrorProcedure"]);
                                        sbMessage.Append("\t"); sbMessage.Append("\t");
                                        sbMessage.Append("Error Line : "); sbMessage.Append("\t"); sbMessage.Append(drRecord["ErrorLine"]);
                                        sbMessage.Append("\t"); sbMessage.Append("\t");
                                        sbMessage.Append("Error Message : "); sbMessage.Append("\t"); sbMessage.Append(drRecord["ErrorMessage"]);
                                    }
                                    break;
                            }
                        }
                    }

                    if (b_IsSuccessful)
                    {
                        companyCreation.hdnIsPanelExpand.Value = "0";
                        companyCreation.h3AddEdit.Style.Add("display", "none");
                        companyCreation.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                        companyCreation.ctrSuccessErrorMessage.s_MessageText = sbMessage.ToString();
                        companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        companyCreation.txtCompanyCreationRemark.Text = "";
                        companyCreation.chkCCIsSaasClient.Checked = false;
                        companyCreation.ddCalMethod.SelectedValue = "0";
                        companyCreation.upnlCompanyCreation.Update();

                        BindControls(companyCreation);

                        ResetFilter(companyCreation);

                        try
                        {
                            SendMailConfirmationToAdmin(superAdminProperties);
                        }
                        catch
                        {
                            throw;
                        }
                    }
                    else
                    {
                        companyCreation.h3AddEdit.Style.Add("display", "block");
                        throw new EDFinancialsException(Convert.ToString(sbMessage));
                    }
                }
            }
            catch (EDFinancialsException Ex)
            {
                companyCreation.h3AddEdit.Style.Add("display", "block");
                companyCreation.hdnIsPanelExpand.Value = "1";
                companyCreation.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                companyCreation.ctrSuccessErrorMessage.s_MessageText = Ex.Message.ToString();
                companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                companyCreation.upnlCompanyCreation.Update();
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        /// <summary>
        /// Method is used to send mail to company admin person.
        /// </summary>
        /// <param name="superAdminProperties">Super Admin properties class</param>        
        private void SendMailConfirmationToAdmin(SuperAdminProperties superAdminProperties)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    var s_MailBody = File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\UserLoginDetailsMailAlert.html");
                    emailProperties.s_MailBody = s_MailBody.Replace("@UserName", "Admin").Replace("@URL", ConfigurationManager.AppSettings["SiteURL"]).Replace("@LoginName", "Admin").Replace("@Password", "Admin").Replace("@CompanyName", superAdminProperties.DatabaseName).Replace("@ValCustSupportID", ConfigurationManager.AppSettings["ValCustSupport"]);
                    emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                    emailProperties.b_IsBodyHtml = true;
                    emailProperties.s_MailTo = superAdminProperties.AdminEmaiId;
                    emailProperties.s_MailCC = "";
                    emailProperties.s_MailBCC = "";
                    emailProperties.s_MailSubject = "EDFinancials - Login Details";
                    genericServiceClient.SaveSendMail(emailProperties);
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// Method is used to clear details and reset drop down list
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        /// <param name="isCancelbtnClicked">true when called from cancel button only</param>
        internal void ClearCRUDDetails(CompanyCreation companyCreation, bool isCancelbtnClicked)
        {
            try
            {
                companyCreation.hdnIsPanelExpand.Value = "0";
                companyCreation.h3AddEdit.Style.Add("display", "none");
                companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                companyCreation.ctrSuccessErrorMessage.s_MessageText = string.Empty;
                companyCreation.txtCRUDCompanyName.Text = companyCreation.txtCRUDDatabaseName.Text = companyCreation.txtCRUDAdminMailId.Text = companyCreation.txtCRUDDateOfListing.Value = companyCreation.txtCompanyCreationRemark.Text = "";
                companyCreation.chkCCIsSaasClient.Checked = false;
                companyCreation.ddCalMethod.SelectedValue = "0";

                companyCreation.ddlCRUDCompanyType.SelectedIndex = companyCreation.ddlCRUDListingStatus.SelectedIndex = companyCreation.ddlCRUDDatabaseName.SelectedIndex = -1;
                companyCreation.ddlCRUDModuleId.SelectedIndex = companyCreation.ddlCRUDSubModule.SelectedIndex = -1;

                ac_CompanyCreation.dt_TempModulAssociationDetails = new DataTable();

                companyCreation.gvModuleAssociation.DataSource = ac_CompanyCreation.dt_TempModulAssociationDetails;
                companyCreation.gvModuleAssociation.DataBind();

                companyCreation.gvModuleAssociation.Visible = ac_CompanyCreation.dt_TempModulAssociationDetails.Rows.Count > 0 ? true : false;

                companyCreation.trDDLDatabaseName.Visible = false;
                companyCreation.trTXTDatabaseName.Visible = true;

                if (companyCreation.ddlCRUDCompanyType.SelectedIndex == -1)
                {
                    companyCreation.trDDLDatabaseName.Visible = false;
                    companyCreation.trTXTDatabaseName.Visible = true;
                }

                companyCreation.ddlCRUDDefaultCompany.ClearSelection();
                companyCreation.ddlCRUDDefaultCompany.Enabled = false;
                companyCreation.ddlCRUDDatabaseName.SelectedIndex = 0;

                companyCreation.btnCURDCreate.Visible = false;

                if (isCancelbtnClicked)
                {
                    companyCreation.gv.DataSource = ac_CompanyCreation.dt_GetCompanyDetails;
                    companyCreation.gv.DataBind();
                    companyCreation.gv_editModule.DataSource = ac_CompanyCreation.dt_ModuleAssociationList;
                    companyCreation.gv_editModule.DataBind();
                }

                ShowHideDOLDiv(companyCreation);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method used to work when grid view paging
        /// </summary>
        /// <param name="sender">Object Parameter</param>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void GvPageIndexChanging(object sender, GridViewPageEventArgs e, CompanyCreation companyCreation)
        {
            try
            {
                companyCreation.gv.PageIndex = e.NewPageIndex;
                companyCreation.gv.DataSource = ac_CompanyCreation.dt_TempCompanyDetails;
                companyCreation.gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind sub module drop down list
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void BindSubModule(CompanyCreation companyCreation)
        {
            try
            {
                companyCreation.hdnIsPanelExpand.Value = "1";
                companyCreation.h3AddEdit.Style.Add("display", "block");
                companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                if (companyCreation.ddlCRUDModuleId.SelectedIndex > 0)
                {
                    using (DataTable dt_BindSubModule = ac_CompanyCreation.dt_ModuleAssociationDetails.Select("MMID = '" + Convert.ToString(companyCreation.ddlCRUDModuleId.SelectedValue) + "'").CopyToDataTable())
                    {
                        companyCreation.ddlCRUDSubModule.DataSource = dt_BindSubModule;
                        companyCreation.ddlCRUDSubModule.DataTextField = "Sub Module";
                        companyCreation.ddlCRUDSubModule.DataValueField = "SMID";
                        companyCreation.ddlCRUDSubModule.DataBind();
                        companyCreation.ddlCRUDSubModule.Items.Insert(0, "--- Please Select ---");


                    }
                }
                else
                {
                    DataTable dt_TempTable = new DataTable();
                    companyCreation.ddlCRUDSubModule.DataSource = dt_TempTable;
                    companyCreation.ddlCRUDSubModule.DataBind();
                    companyCreation.ddlCRUDSubModule.Items.Insert(0, "--- Please Select ---");
                }
            }
            catch
            {

                throw;
            }
        }

        /// <summary>
        /// Method is used add Module-Submodule combination to grid view
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void AddModuleDetailToGrid(CompanyCreation companyCreation)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    companyCreation.hdnIsPanelExpand.Value = "1";
                    companyCreation.h3AddEdit.Style.Add("display", "block");
                    string s_ModuleId = companyCreation.ddlCRUDModuleId.SelectedIndex > 0 ? Convert.ToString(companyCreation.ddlCRUDModuleId.SelectedValue) : string.Empty;
                    string s_ModuleName = companyCreation.ddlCRUDModuleId.SelectedIndex > 0 ? Convert.ToString(companyCreation.ddlCRUDModuleId.SelectedItem) : string.Empty;

                    string s_SubModuleId = companyCreation.ddlCRUDSubModule.SelectedIndex > 0 ? Convert.ToString(companyCreation.ddlCRUDSubModule.SelectedValue) : string.Empty;
                    string s_SubModuleName = companyCreation.ddlCRUDSubModule.SelectedIndex > 0 ? Convert.ToString(companyCreation.ddlCRUDSubModule.SelectedItem) : string.Empty;

                    string s_CalMethodId = companyCreation.ddCalMethod.SelectedIndex > 0 ? Convert.ToString(companyCreation.ddCalMethod.SelectedValue) : string.Empty;
                    string s_CalMethodName = companyCreation.ddCalMethod.SelectedIndex > 0 ? Convert.ToString(companyCreation.ddCalMethod.SelectedItem) : string.Empty;

                    if (string.IsNullOrEmpty(s_ModuleName))
                        throw new EDFinancialsException(superAdminServiceClient.LoadL10N("CCSelectModuleName"));

                    if (string.IsNullOrEmpty(s_SubModuleName))
                        throw new EDFinancialsException(superAdminServiceClient.LoadL10N("CCSelectSubModuleName"));

                    if (companyCreation.ddlCRUDModuleId.SelectedIndex > 0)
                    {
                        companyCreation.ctrSuccessErrorMessage.s_MessageText = string.Empty;
                        companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                        if (ac_CompanyCreation.dt_TempModulAssociationDetails != null)
                        {
                            if (ac_CompanyCreation.dt_TempModulAssociationDetails.Columns.Count < 2)
                            {
                                CreateDatatable(ac_CompanyCreation.dt_TempModulAssociationDetails);
                            }
                        }


                        DataRow tableRow = ac_CompanyCreation.dt_TempModulAssociationDetails.NewRow();

                        tableRow["MMID"] = s_ModuleId;
                        tableRow["MODULE_NAME"] = s_ModuleName;
                        tableRow["SMID"] = s_SubModuleId;
                        tableRow["SUB_MODULE_NAME"] = s_SubModuleName;
                        tableRow["CMID"] = s_CalMethodId;
                        tableRow["CALCULATION_METHOD"] = s_CalMethodName;
                        tableRow["IS_ACTIVE"] = "2";
                        tableRow["Status"] = "Activated";

                        ac_CompanyCreation.dt_TempModulAssociationDetails.Rows.Add(tableRow);


                        //if (ac_CompanyCreation.dt_TempModulAssociationDetails == null && ac_CompanyCreation.dt_TempModulAssociationDetails.Rows.Count > 0)
                        //{
                        //    ac_CompanyCreation.dt_TempModulAssociationDetails = dt_ModuleAssociation;
                        //}
                        //ac_CompanyCreation.dt_TempModulAssociationDetails.Merge(dt_ModuleAssociation);

                        if (ac_CompanyCreation.dt_TempModulAssociationDetails.Select("MMID = '" + s_ModuleId + "' AND SMID = '" + s_SubModuleId + "'").Length == 1)
                        {
                            companyCreation.gvModuleAssociation.DataSource = ac_CompanyCreation.dt_TempModulAssociationDetails;
                            companyCreation.gvModuleAssociation.DataBind();
                        }
                        else
                        {
                            ac_CompanyCreation.dt_TempModulAssociationDetails = ac_CompanyCreation.dt_TempModulAssociationDetails.DefaultView.ToTable(true, "MMID", "MODULE_NAME", "SMID", "SUB_MODULE_NAME", "CMID", "CALCULATION_METHOD", "IS_ACTIVE", "Status");
                            throw new EDFinancialsException(superAdminServiceClient.LoadL10N("CCSelectModuleSubCombination"));
                        }

                        companyCreation.gvModuleAssociation.Visible = ac_CompanyCreation.dt_TempModulAssociationDetails.Rows.Count > 0 ? true : false;

                        companyCreation.btnCURDCreate.Visible = true;
                    }
                    else
                    {
                        throw new EDFinancialsException(superAdminServiceClient.LoadL10N("CCSelectModuleName"));
                    }

                }
            }
            catch (EDFinancialsException Ex)
            {
                companyCreation.hdnIsPanelExpand.Value = "1";
                companyCreation.h3AddEdit.Style.Add("display", "block");
                companyCreation.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                companyCreation.ctrSuccessErrorMessage.s_MessageText = Ex.Message.ToString();
                companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Create Temp  table
        /// </summary>
        /// <param name="dt_ModuleAssociation">This object used to return the dadatble</param>
        private void CreateDatatable(DataTable dt_ModuleAssociation)
        {
            dt_ModuleAssociation.Columns.Add("MMID", typeof(String));
            dt_ModuleAssociation.Columns.Add("MODULE_NAME", typeof(String));
            dt_ModuleAssociation.Columns.Add("SMID", typeof(String));
            dt_ModuleAssociation.Columns.Add("SUB_MODULE_NAME", typeof(String));
            dt_ModuleAssociation.Columns.Add("CMID", typeof(String));
            dt_ModuleAssociation.Columns.Add("CALCULATION_METHOD", typeof(String));
            dt_ModuleAssociation.Columns.Add("IS_ACTIVE", typeof(String));
            dt_ModuleAssociation.Columns.Add("Status", typeof(String));
        }

        /// <summary>
        /// Method is used as grid view row data bound event and hide ID's column from end user
        /// </summary>
        /// <param name="sender">Pass parameter as Sender object</param>
        /// <param name="e">Pass parameter as Event Args Parameter</param>
        /// <param name="companyCreation">Pass parameter as page</param>
        /// <param name="n_index">Pass parameters Grid view index</param>
        /// <param name="n_MMID">Pass parameter as Module Id</param>
        /// <param name="n_SMID">Pass parameter as Sub module id</param>
        /// <param name="n_CMID">Pass parameter as Calculation Method</param>
        /// <param name="n_IsActive">Pass parameter as Status</param>
        internal void GvModuleAssociationRowDatabaBind(object sender, GridViewRowEventArgs e, CompanyCreation companyCreation, ref int n_index, ref int n_MMID, ref int n_SMID, ref int n_CMID, ref int n_IsActive)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "MMID":
                                    n_MMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "MODULE_NAME":
                                    perColumn.Text = "Module Name";
                                    break;

                                case "SMID":
                                    n_SMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "SUB_MODULE_NAME":
                                    perColumn.Text = "Submodule Name";
                                    break;

                                case "CMID":
                                    n_CMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "CALCULATION_METHOD":
                                    perColumn.Text = "Calculation Method";
                                    break;

                                case "IS_ACTIVE":
                                    n_IsActive = n_index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_MMID].Visible = false;
                        e.Row.Cells[n_SMID].Visible = false;
                        e.Row.Cells[n_CMID].Visible = false;
                        e.Row.Cells[n_IsActive].Visible = false;
                        break;
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// Method used to work when grid view paging
        /// </summary>
        /// <param name="sender">Pass parameter as Sender object</param>
        /// <param name="e">Pass parameter as Event Args Parameter</param>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void GvModuleAssociationPageIndexChanging(object sender, GridViewPageEventArgs e, CompanyCreation companyCreation)
        {
            try
            {
                companyCreation.gvModuleAssociation.PageIndex = e.NewPageIndex;
                companyCreation.gvModuleAssociation.DataSource = ac_CompanyCreation.dt_TempModulAssociationDetails;
                companyCreation.gvModuleAssociation.DataBind();
                companyCreation.h3AddEdit.Style.Add("display", "block");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to hide tr for on the basis of company type  1 : MyESOPs and  2 : Non MyESOPs
        /// </summary>
        /// <param name="sender">Pass parameter as Sender object</param>
        /// <param name="e">Pass parameter as Event Args Parameter</param>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void ddlCURDTypeSelectedIndexChanged(object sender, EventArgs e, CompanyCreation companyCreation)
        {
            companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            if (companyCreation.ddlCRUDCompanyType.SelectedIndex > 0 && companyCreation.ddlCRUDCompanyType.SelectedValue == "1")
            {
                companyCreation.trDDLDatabaseName.Visible = true;
                companyCreation.trTXTDatabaseName.Visible = false;
            }
            else
            {
                companyCreation.trDDLDatabaseName.Visible = false;
                companyCreation.trTXTDatabaseName.Visible = true;
            }

            companyCreation.h3AddEdit.Style.Add("display", "block");
        }

        /// <summary>
        /// Method is used to hide tr for on the basis of company type  1 : MyESOPs and  2 : Non MyESOPs
        /// </summary>
        /// <param name="sender">Pass parameter as Sender object</param>
        /// <param name="e">Pass parameter as Event Args Parameter</param>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void ddlCRUDListingStatus_SelectedIndexChanged(object sender, EventArgs e, CompanyCreation companyCreation)
        {
            try
            {
                companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                ShowHideDOLDiv(companyCreation);
                BindDefaultCompanies(companyCreation);
                companyCreation.h3AddEdit.Style.Add("display", "block");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind default companies to the drop down to copy default parameters
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        private void BindDefaultCompanies(CompanyCreation companyCreation)
        {
            companyCreation.ddlCRUDDefaultCompany.ClearSelection();
            if (companyCreation.ddlCRUDListingStatus.SelectedIndex > 0)
            {
                companyCreation.ddlCRUDDefaultCompany.Enabled = true;
                DataTable dt_DefaultCompanies = new DataTable();
                DataRow[] dr = (companyCreation.ddlCRUDListingStatus.SelectedIndex > 0 && companyCreation.ddlCRUDListingStatus.SelectedValue == "1") ?
                    (from row in ac_CompanyCreation.dt_GetCompanyDetails.AsEnumerable() where row.Field<string>("Listing Status") == "Listed" select row).ToArray() :
                    (from row in ac_CompanyCreation.dt_GetCompanyDetails.AsEnumerable() where row.Field<string>("Listing Status") == "Unlisted" select row).ToArray();
                if (dr.Length > 0)
                    dt_DefaultCompanies = (dr).CopyToDataTable();
                companyCreation.ddlCRUDDefaultCompany.DataSource = dt_DefaultCompanies;
                companyCreation.ddlCRUDDefaultCompany.DataTextField = "Company Name";
                companyCreation.ddlCRUDDefaultCompany.DataValueField = "Database Name";
                companyCreation.ddlCRUDDefaultCompany.DataBind();
                companyCreation.ddlCRUDDefaultCompany.Items.Insert(0, "--- Please Select ---");
                companyCreation.ddlCRUDDefaultCompany.SelectedIndex = -1;
            }
            else
            {
                companyCreation.ddlCRUDDefaultCompany.Enabled = false;
            }
        }

        /// <summary>
        /// Method is used to show/hide Date Of Listing div
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        private static void ShowHideDOLDiv(CompanyCreation companyCreation)
        {
            try
            {
                if (companyCreation.ddlCRUDListingStatus.SelectedIndex > 0)
                {
                    companyCreation.tdlblCRUDAppFromDate.Visible = true;
                    companyCreation.tdtxtCRUDDateOfListing.Visible = true;
                    companyCreation.tdddlCRUDListingStatus.ColSpan = 1;
                    companyCreation.rfvCRUDAppFromDate.Enabled = true;
                }
                else
                {
                    companyCreation.tdlblCRUDAppFromDate.Visible = false;
                    companyCreation.tdtxtCRUDDateOfListing.Visible = false;
                    companyCreation.tdddlCRUDListingStatus.ColSpan = 3;
                    companyCreation.rfvCRUDAppFromDate.Enabled = false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Reset page parameter on Company Creation button
        /// </summary>
        /// <param name="sender">Pass parameter as Sender object</param>
        /// <param name="e">Pass parameter as Event Args Parameter</param>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void btnCCCreate_Click(object sender, EventArgs e, CompanyCreation companyCreation)
        {
            try
            {
                ClearCRUDDetails(companyCreation, false);
                companyCreation.hdnIsPanelExpand.Value = "1";
                companyCreation.h3AddEdit.Style.Add("display", "block");
                companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                ResetFilter(companyCreation);
                LoadGvData(companyCreation);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method adds image button to grid view Action column at runtime .
        /// </summary>
        /// <param name="s_strToolTip">ToolTip for Button</param>
        /// <param name="s_ImgUrl">This is database name</param>
        /// <param name="s_DatabaseName">This is action to be performed</param>
        /// <returns>returns link button</returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_ImgUrl, string s_DatabaseName)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_ImgUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");
                if (!string.IsNullOrEmpty(s_DatabaseName))
                {
                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        imgButton.Attributes.Add("onclick", "return ViewModuleAssociations('" + s_DatabaseName + "','View')");
                    }
                }
                return imgButton;
            }
        }

        /// <summary>
        /// Adding Edit Image button and its corresponding click event 
        /// </summary>
        /// <param name="s_strToolTip">s_strToolTip</param>
        /// <param name="s_strUrl">s_strUrl</param>
        /// <param name="s_CompanyID">s_CompanyID</param>
        /// <param name="s_CompanyName">s_CompanyName</param>
        /// <param name="s_DatabaseName">s_DatabaseName</param>
        /// <param name="s_BtnId">s_BtnId</param>
        /// <returns>returns image button</returns>
        private ImageButton EditImageLink(string s_strToolTip, string s_strUrl, string s_CompanyID, string s_CompanyName, string s_DatabaseName, string s_BtnId)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");
                if (!string.IsNullOrEmpty(s_DatabaseName))
                {
                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_CompanyID + "','" + s_CompanyName + "','" + s_DatabaseName + "','" + s_BtnId + "')");
                    }
                }
                return imgButton;
            }
        }

        internal void load_dt_ModuleAssociationList()
        {
            try
            {
                superAdminProperties.PageName = CommonConstantModel.s_CompanyCreation;
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.PopulateControls = "GET_MODULE_ASSOCIATION_LIST";
                superAdminProperties.Action = "GET_MODULE_ASSOCIATION_LIST";
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    ac_CompanyCreation.dt_ModuleAssociationList = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyCreation"></param>
        public void GetModuleAssociationList(CompanyCreation companyCreation)
        {
            try
            {

                load_dt_ModuleAssociationList();
                companyCreation.gv_ModuleAssociations.DataSource = ac_CompanyCreation.dt_ModuleAssociationList;
                companyCreation.gv_ModuleAssociations.DataBind();
                companyCreation.gv_editModule.DataSource = ac_CompanyCreation.dt_ModuleAssociationList;
                companyCreation.gv_editModule.DataBind();


            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method Filters the module list based on the database name provided.
        /// </summary>
        /// <param name="s_DatabasesName">This has Database name of the company selected</param>
        public DataTable Filter_ModuleAssociationList(string s_DatabasesName)
        {
            try
            {
                load_dt_ModuleAssociationList();
                if (!(string.IsNullOrEmpty(s_DatabasesName)))
                    using (DataTable dt_selectedModules = ac_CompanyCreation.dt_ModuleAssociationList.Select("Database_Name = '" + s_DatabasesName + "'").CopyToDataTable())
                    {
                        return dt_selectedModules;
                    }
                else
                    return null;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method binds Module, SubModule and calculation method drop down.
        /// </summary>
        /// <param name="companyCreation"></param>
        public void Bind_CMthd_dropdowns(CompanyCreation companyCreation)
        {
            try
            {
                superAdminProperties.PageName = CommonConstantModel.s_CompanyCreation;
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.PopulateControls = "GET_MODULE_ASSOCIATION_LIST";
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                superAdminProperties.Action = "CALCULATION_METHOD";

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_BindCalculaionMethod = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result)
                    {
                        companyCreation.ddCalMethod.DataSource = dt_BindCalculaionMethod;
                        companyCreation.ddCalMethod.DataTextField = "METHOD_NAME";
                        companyCreation.ddCalMethod.DataValueField = "CMID";
                        companyCreation.ddCalMethod.DataBind();

                        companyCreation.ddAMCMName.DataSource = dt_BindCalculaionMethod;
                        companyCreation.ddAMCMName.DataTextField = "METHOD_NAME";
                        companyCreation.ddAMCMName.DataValueField = "CMID";
                        companyCreation.ddAMCMName.DataBind();
                    }
                    superAdminProperties.Action = "STATUS";
                    using (DataTable dt_BindStatusDropdown = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result)
                    {
                        companyCreation.ddIsActiveEdit.DataSource = dt_BindStatusDropdown;
                        companyCreation.ddIsActiveEdit.DataTextField = "DATA";
                        companyCreation.ddIsActiveEdit.DataValueField = "VALUE";
                        companyCreation.ddIsActiveEdit.DataBind();
                    }

                }

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind sub module drop down list
        /// </summary>
        /// <param name="companyCreation">Pass parameter as page</param>
        internal void Bind_EditSubModule(CompanyCreation companyCreation)
        {
            try
            {
                if (companyCreation.ddAMMMName.SelectedIndex > 0)
                {
                    using (DataTable dt_BindSubModule = ac_CompanyCreation.dt_ModuleAssociationDetails.Select("MMID = '" + Convert.ToString(companyCreation.ddAMMMName.SelectedValue) + "'").CopyToDataTable())
                    {
                        companyCreation.ddAMSMName.DataSource = dt_BindSubModule;
                        companyCreation.ddAMSMName.DataTextField = "Sub Module";
                        companyCreation.ddAMSMName.DataValueField = "SMID";
                        companyCreation.ddAMSMName.DataBind();
                        companyCreation.ddAMSMName.Items.Insert(0, "--- Please Select ---");
                    }
                }
                else
                {
                    DataTable dt_TempTable = new DataTable();
                    companyCreation.ddAMSMName.DataSource = dt_TempTable;
                    companyCreation.ddAMSMName.DataBind();
                    companyCreation.ddAMSMName.Items.Insert(0, "--- Please Select ---");
                }
            }
            catch
            {
                throw;
            }
            companyCreation.gv.DataSource = ac_CompanyCreation.dt_GetCompanyDetails;
            companyCreation.gv.DataBind();
            companyCreation.ddAMSMName.Enabled = true;
            companyCreation.h3AddEditModules.Style.Add("display", "block");
            companyCreation.h3SearchPanel.Style.Add("display", "block");
            companyCreation.hdnIsPanelExpand.Value = "2";
            companyCreation.lblCompanyName.Text = companyCreation.hdnCompanyName.Value;
            companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

            companyCreation.updAdd.Update();

        }

        /// <summary>
        /// This method is used to load content of IsActive drop down list
        /// </summary>
        /// <returns>int</returns>
        internal void PerformCUD(EDFinancials.View.SuperAdmin.CompanyCreation companyCreation, string s_CompanyId, string s_Action)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.FILE_NAME = "PROC_ACC_CUD_COMPANY_MODULES";
                    superAdminProperties.CompanyName = companyCreation.hdnCompanyId.Value;
                    superAdminProperties.DatabaseName = companyCreation.hdnDatabaseName.Value;
                    superAdminProperties.MmId = Convert.ToInt16(companyCreation.ddAMMMName.SelectedValue);
                    superAdminProperties.SmId = Convert.ToInt16(companyCreation.ddAMSMName.SelectedValue);
                    superAdminProperties.CMID = companyCreation.ddAMCMName.SelectedValue != "" ? Convert.ToInt16(companyCreation.ddAMCMName.SelectedValue) : 0;
                    superAdminProperties.IsActive = Convert.ToInt16(companyCreation.ddIsActiveEdit.SelectedValue);
                    superAdminProperties.Action = s_Action;
                    superAdminProperties.PageName = CommonConstantModel.s_CompanyCreation;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;

                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                    switch (superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result)
                    {
                        case 0:
                            companyCreation.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMError");
                            companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            companyCreation.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;

                        case 1:
                            companyCreation.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMAAdded");
                            companyCreation.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;


                        case 2:
                            companyCreation.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMAUpdated");
                            companyCreation.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 4:
                            companyCreation.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMAExists");
                            companyCreation.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 5:
                            companyCreation.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblCalMethodExists");
                            companyCreation.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 6:
                            companyCreation.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblCanNotEditBeingUsed");
                            companyCreation.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            companyCreation.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;
                    }
                    companyCreation.ddIsActiveEdit.SelectedIndex = -1;
                    companyCreation.hdnIsPanelExpand.Value = "0";
                    companyCreation.h3AddEdit.Style.Add("display", "none");
                    companyCreation.h3AddEditModules.Style.Add("display", "none");
                    companyCreation.upnlCompanyCreation.Update();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <param name="companyCreation"></param>
        /// <param name="n_index"></param>
        /// <param name="n_MMID"></param>
        /// <param name="n_SMID"></param>
        /// <param name="n_CMID"></param>
        /// <param name="n_IsActive"></param>
        internal void gv_EditModule_RowDatabound(object sender, GridViewRowEventArgs e, CompanyCreation companyCreation, ref int n_index, ref int n_MMID, ref int n_SMID, ref int n_CMID, ref int n_IsActive)
        {
            try
            {
                n_index = 0;
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "MMID":
                                    n_MMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "MODULE_NAME":
                                    perColumn.Text = "Module Name";
                                    break;

                                case "SMID":
                                    n_SMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "SUB_MODULE_NAME":
                                    perColumn.Text = "Submodule Name";
                                    break;

                                case "CMID":
                                    n_CMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "CALCULATION_METHOD":
                                    perColumn.Text = "Calculation Method";
                                    break;

                                case "IS_ACTIVE":
                                    n_IsActive = n_index;
                                    perColumn.Visible = false;
                                    break;

                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_MMID].Visible = false;
                        e.Row.Cells[n_SMID].Visible = false;
                        e.Row.Cells[n_CMID].Visible = false;
                        e.Row.Cells[n_IsActive].Visible = false;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method toggles the Is_Active status of selected module.
        /// </summary>
        /// <param name="s_CompanyName">s_CompanyName</param>
        /// <param name="CompanyId">CompanyId</param>
        /// <param name="Mmid">Mmid</param>
        /// <param name="Smid">Smid</param>
        /// <param name="Cmid">Cmid</param>
        /// <param name="s_Status">s_Status</param>
        /// <returns>returns string </returns>
        public string AlterModuleStatus(string s_CompanyName, int CompanyId, int Mmid, int Smid, string Cmid, string s_Status)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    string s_DisplayMessage = string.Empty;
                    superAdminProperties.FILE_NAME = "PROC_ACC_CUD_COMPANY_MODULES";
                    superAdminProperties.CompanyName = Convert.ToString(CompanyId);
                    superAdminProperties.DatabaseName = s_CompanyName;
                    superAdminProperties.MmId = Mmid;
                    superAdminProperties.SmId = Smid;
                    superAdminProperties.CMID = Cmid != "" ? Convert.ToInt16(Cmid) : 0;
                    superAdminProperties.IsActive = s_Status == "Activated" ? 1 : 2;
                    superAdminProperties.Action = "UPDATE_MODULE";
                    superAdminProperties.PageName = CommonConstantModel.s_CompanyCreation;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;

                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                    switch (superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result)
                    {
                        case 0:
                            s_DisplayMessage = superAdminServiceClient.LoadL10N("lblMMError");

                            break;

                        case 2:
                            s_DisplayMessage = superAdminServiceClient.LoadL10N("lblMAUpdated");
                            break;

                        case 4:
                            s_DisplayMessage = superAdminServiceClient.LoadL10N("lblMAExists");
                            break;

                        case 5:
                            s_DisplayMessage = superAdminServiceClient.LoadL10N("lblCalMethodExists");
                            break;

                    }
                    return s_DisplayMessage;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Encrypt query string that has to pass on to report page  for report view.
        /// </summary>
        /// <param name="companyCreation">object of companyCreation page</param>
        internal void EncryptData(CompanyCreation companyCreation)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                companyCreation.hdnQueryStringParams.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=4").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                companyCreation.hdnQueryStringParams.Dispose();
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CompanyCreationModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}