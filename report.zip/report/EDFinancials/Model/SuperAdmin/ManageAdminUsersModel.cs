﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// Modlel class for ManageAdminUsersModel
    /// </summary>
    public class ManageAdminUsersModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public ManageAdminUsersModel()
        {
            if (ac_ManageAdminUsers == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageAdminUsers);
                ac_ManageAdminUsers = (CommonModel.AC_ManageAdminUsers)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageAdminUsers];
            }
        }

        #region Bind UI
        /// <summary>
        /// This Method is used to bind UI Controls
        /// </summary>
        /// <param name="manageAdminUsers">manageAdminUsers</param>
        internal void BindUI(View.SuperAdmin.ManageAdminUsers manageAdminUsers)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_ManageAdminUI = superAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_ManageAdminUsers))
                    {
                        if ((dt_ManageAdminUI != null) && (dt_ManageAdminUI.Rows.Count > 0))
                        {
                            manageAdminUsers.lblMAUPageName.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUPageName'")[0]["LabelName"]);
                            manageAdminUsers.lblMAUCompanyName.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUCompanyName'")[0]["LabelName"]);
                            manageAdminUsers.lblMAUCompanyName.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUCompanyName'")[0]["LabelToolTip"]);
                            manageAdminUsers.lblMAUMailID.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUMailID'")[0]["LabelName"]);
                            manageAdminUsers.lblMAUMailID.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUMailID'")[0]["LabelToolTip"]);
                            manageAdminUsers.lblMAUAdminMailID.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUAdminMailID'")[0]["LabelName"]);
                            manageAdminUsers.lblMAUAdminMailID.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUAdminMailID'")[0]["LabelToolTip"]);
                            manageAdminUsers.ReqFldMail.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUAdminMailID'")[0]["ErrorText"]);
                            manageAdminUsers.RegExpMail.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUAdminMailIDRegEx'")[0]["ErrorText"]);
                            manageAdminUsers.btnMAUSave.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUSave'")[0]["LabelName"]);
                            manageAdminUsers.btnMAUCancelEdit.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUCancelEdit'")[0]["LabelName"]);
                            manageAdminUsers.lblMAUNewPassword.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUNewPassword'")[0]["LabelName"]);
                            manageAdminUsers.lblMAUNewPassword.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUNewPassword'")[0]["LabelToolTip"]);
                            manageAdminUsers.ReqFldPassword.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUNewPassword'")[0]["ErrorText"]);
                            manageAdminUsers.RegExpPasswordLength.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUNewPasswordRegEx'")[0]["ErrorText"]);
                            manageAdminUsers.lblMAUConfirmPassword.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUConfirmPassword'")[0]["LabelName"]);
                            manageAdminUsers.lblMAUConfirmPassword.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUConfirmPassword'")[0]["LabelToolTip"]);
                            manageAdminUsers.ReqFldConfirmPassword.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUConfirmPassword'")[0]["ErrorText"]);
                            manageAdminUsers.CompareValPassword.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUConfirmPasswordCmpVal'")[0]["ErrorText"]);
                            manageAdminUsers.btnMAUApplyFilter.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUApplyFilter'")[0]["LabelName"]);
                            manageAdminUsers.btnMAUClearFilter.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUClearFilter'")[0]["LabelName"]);
                            manageAdminUsers.btnMAUSavePassword.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUSavePassword'")[0]["LabelName"]);
                            manageAdminUsers.btnMAUSaveSendMail.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUSaveSendMail'")[0]["LabelName"]);
                            manageAdminUsers.btnMAUCancelResetPWD.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUCancelResetPWD'")[0]["LabelName"]);
                            manageAdminUsers.btnMAUApplyFilter.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUApplyFilter'")[0]["LabelToolTip"]);
                            manageAdminUsers.btnMAUSave.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUSave'")[0]["LabelToolTip"]);
                            manageAdminUsers.btnMAUSavePassword.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUSavePassword'")[0]["LabelToolTip"]);
                            manageAdminUsers.btnMAUSaveSendMail.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUSaveSendMail'")[0]["LabelToolTip"]);
                            manageAdminUsers.lblPaneOneHeader.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblPaneOneHeader'")[0]["LabelName"]);
                            manageAdminUsers.lblPaneTwoHeader.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblPaneTwoHeader'")[0]["LabelName"]);
                            manageAdminUsers.lblPaneOneHeader.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblPaneOneHeader'")[0]["LabelToolTip"]);
                            manageAdminUsers.lblPaneTwoHeader.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblPaneTwoHeader'")[0]["LabelToolTip"]);
                            manageAdminUsers.btnMAUClearFilter.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUClearFilter'")[0]["LabelToolTip"]);
                            manageAdminUsers.btnMAUCancelEdit.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUCancelEdit'")[0]["LabelToolTip"]);
                            manageAdminUsers.btnMAUCancelResetPWD.ToolTip = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'btnMAUCancelResetPWD'")[0]["LabelToolTip"]);
                            manageAdminUsers.lblMAUPasswordPattern.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUPasswordPattern'")[0]["LabelName"]);
                            manageAdminUsers.lblMAUViewHistory.Text = Convert.ToString(dt_ManageAdminUI.Select("LabelID = 'lblMAUViewHistory'")[0]["LabelName"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Search/ Apply Fiter
        /// <summary>
        /// This Method is used to bind comapany names to dropdown
        /// </summary>
        /// <param name="manageAdminUsers">manageAdminUsers</param>
        /// <returns>Datatable Company Names List</returns>
        internal void BindCompanyList(ManageAdminUsers manageAdminUsers)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.PageName = CommonConstantModel.s_ManageAdminUsers;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.PopulateControls = "FillAdminUserGrid";
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CompanyName = "--- Please Select ---";
                    superAdminProperties.AdminEmaiId = "";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    manageAdminUsers.ddlMAUCompanyName.DataSource = (DataTable)superAdminCRUDProperties.dt_Result;

                    manageAdminUsers.ddlMAUCompanyName.DataTextField = "Company Name";
                    manageAdminUsers.ddlMAUCompanyName.DataValueField = "Database Name";
                    manageAdminUsers.ddlMAUCompanyName.DataBind();

                    manageAdminUsers.ddlMAUCompanyName.Items.Insert(0, "--- Please Select ---");
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind admin user list to grid
        /// </summary>
        /// <param name="manageAdminUsers">manageAdminUsers</param>
        /// <returns>Datatable of admin user list</returns>
        internal void GetAdminUsersList(ManageAdminUsers manageAdminUsers)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CompanyName = manageAdminUsers.ddlMAUCompanyName.SelectedValue;
                    superAdminProperties.AdminEmaiId = manageAdminUsers.txtMAUMailID.Text;
                    superAdminProperties.PageName = CommonConstantModel.s_ManageAdminUsers;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.PopulateControls = "FillAdminUserGrid";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_ManageAdminUsers.dt_ManageAdminUsers = (DataTable)superAdminCRUDProperties.dt_Result;

                    manageAdminUsers.gv.DataSource = ac_ManageAdminUsers.dt_ManageAdminUsers;
                    manageAdminUsers.gv.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to Display or Hide Controls and set Accordian index
        /// </summary>
        /// <param name="manageAdminUsers">manageAdminUsers</param>
        /// <param name="s_ButtonID">Button ID</param>
        /// <param name="Ex">Ex</param>
        internal void DisplayContents(ManageAdminUsers manageAdminUsers, string s_ButtonID, EDFinancialsException Ex)
        {
            try
            {
                manageAdminUsers.btnMAUClearFilter.Visible = false;
                manageAdminUsers.hdnAccordionIndex.Value = "0";

                switch (s_ButtonID)
                {
                    case "":
                        break;

                    case "btnMAUApplyFilter":
                        manageAdminUsers.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                        manageAdminUsers.btnMAUClearFilter.Visible = (String.IsNullOrEmpty(manageAdminUsers.txtMAUMailID.Text)) && (manageAdminUsers.ddlMAUCompanyName.SelectedItem.Text.Equals("--- Please Select ---")) ? false : true;

                        break;

                    case "btnSavepwdException":
                        manageAdminUsers.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                        manageAdminUsers.ctrSuccessErrorMessage.s_MessageText = Ex.Message.ToString();
                        manageAdminUsers.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        break;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Update Admin Mail
        /// <summary>
        /// This method is used to update admin mail id
        /// </summary>
        /// <param name="manageAdminUsers">manageAdminUsers</param>
        /// <param name="s_Action">Action</param>
        /// <param name="s_CompanyName">CompanyName</param>
        internal void UpdateAdminMail(ManageAdminUsers manageAdminUsers, string s_Action, string s_CompanyName)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.Action = s_Action;
                    superAdminProperties.CompanyName = s_CompanyName;
                    superAdminProperties.AdminEmaiId = CommonModel.ReplaceApostrophe(manageAdminUsers.txtMAUEditMailID.Text);
                    superAdminProperties.PageName = CommonConstantModel.s_ManageAdminUsers;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.PopulateControls = "UpdateAdminMail";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    int result = superAdminCRUDProperties.a_result;

                    if (superAdminProperties.Action == "U")
                    {
                        if (result.Equals(0))
                        {
                            manageAdminUsers.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            manageAdminUsers.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(superAdminServiceClient.LoadL10N("MAUErrorUpdateEmailID"));
                            manageAdminUsers.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageAdminUsers.UpdatePanelManageAdminUsers.Update();
                        }
                        else
                        {
                            manageAdminUsers.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            manageAdminUsers.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(superAdminServiceClient.LoadL10N("MAUUpdateEmailID"));
                            manageAdminUsers.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            manageAdminUsers.UpdatePanelManageAdminUsers.Update();
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Reset Password
        /// <summary>
        /// This method is used to reset and update the admin users password
        /// </summary>
        /// <param name="s_CompanyName">CompanyName</param>
        /// <param name="s_UserPassword">UserPassword</param>
        /// <param name="s_MailBody">MailBody</param>
        /// <param name="s_UserName">UserName</param>
        /// <param name="s_MailID">MailID</param>
        /// <param name="s_LoginID">LoginID</param>
        internal void ResetAdminPassword(string s_CompanyName, string s_UserPassword, string s_MailBody, string s_UserName, string s_MailID, string s_LoginID)
        {
            try
            {
                string s_ConfimMessage = string.Empty;

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CompanyName = s_CompanyName;
                    superAdminProperties.SAP_UserPassword = s_UserPassword;
                    superAdminProperties.PageName = CommonConstantModel.s_ManageAdminUsers;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.PopulateControls = "ResetPassword";

                    if (!(String.IsNullOrEmpty(s_UserPassword)))
                    {
                        superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                        int n_result = superAdminCRUDProperties.a_result;

                        if (n_result.Equals(1))
                        {
                            if (!string.IsNullOrEmpty(s_MailBody))
                            {
                                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                                {
                                    emailProperties.s_MailBody = s_MailBody.Replace("@UserName", s_UserName).Replace("@URL", ConfigurationManager.AppSettings["SiteURL"]).Replace("@Password", s_UserPassword).Replace("@CompanyName", superAdminProperties.CompanyName).Replace("@ValCustSupportID", ConfigurationManager.AppSettings["ValCustSupport"]).Replace("@LoginID", s_UserName);
                                    emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                                    emailProperties.b_IsBodyHtml = true;
                                    emailProperties.s_MailTo = s_MailID;
                                    emailProperties.s_MailCC = "";
                                    emailProperties.s_MailBCC = "";
                                    emailProperties.s_MailSubject = "EDFinancial: Password reset";
                                    genericServiceClient.SaveSendMail(emailProperties);
                                }
                            }
                            s_ConfimMessage = string.IsNullOrEmpty(s_MailBody) ? superAdminServiceClient.LoadL10N("MAUUpdatePassword") : superAdminServiceClient.LoadL10N("MAUMailSent");
                            throw new EDFinancialsException(s_ConfimMessage);
                        }

                        else
                        {
                            throw new EDFinancialsException(superAdminServiceClient.LoadL10N("MAUErrorUpdatePassword"));
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Manage Admin Users GridView RowBound
        /// <summary>
        /// This method is used to bind rows to grid
        /// </summary>
        /// <param name="sender">Manage Admin Users Grid</param>
        /// <param name="e">e</param>
        /// <param name="n_Action">Action</param>
        /// <param name="n_EmailID">EmailID</param>
        /// <param name="n_index">index</param>
        /// <param name="n_UMID">UMID</param>
        /// <param name="n_CompanyName">CompanyName</param>
        /// <param name="n_IsActive">IsActive</param>
        /// <param name="n_Loginid">Loginid</param>
        /// <param name="n_dbName">Database Name</param>
        /// <param name="n_isDeleted">IsDeleted</param>
        public void RowDataBound(object sender, GridViewRowEventArgs e, ref int n_Action, ref int n_EmailID, ref int n_index, ref int n_UMID, ref int n_CompanyName, ref int n_IsActive, ref int n_Loginid, ref int n_dbName, ref int n_isDeleted)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "COMPANY NAME":
                                    n_CompanyName = n_index;
                                    break;

                                case "UMID":
                                    n_UMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "MAIL ID":
                                    n_EmailID = n_index;
                                    break;

                                case "LOGIN ID":
                                    n_Loginid = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ISACTIVE":
                                    n_IsActive = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTIONS":
                                    n_Action = n_index;
                                    break;

                                case "DATABASE NAME":
                                    n_dbName = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ISDELETED":
                                    n_isDeleted = n_index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_UMID].Visible = false;
                        e.Row.Cells[n_IsActive].Visible = false;
                        e.Row.Cells[n_Loginid].Visible = false;
                        e.Row.Cells[n_dbName].Visible = false;
                        e.Row.Cells[n_isDeleted].Visible = false;
                        e.Row.Cells[n_CompanyName].HorizontalAlign = e.Row.Cells[4].HorizontalAlign = e.Row.Cells[n_EmailID].HorizontalAlign = HorizontalAlign.Left;
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Action].Controls.Add((Control)AddImageButton("Edit", "Click here to Edit Mail", "~/View/App_Themes/images/Edit.png", e.Row.Cells[n_EmailID].Text, e.Row.Cells[n_dbName].Text, string.Empty, string.Empty));
                        e.Row.Cells[n_Action].Controls.Add((Control)AddImageButton("Reset Password", "Click here to Reset Password", "~/View/App_Themes/images/resetPassword.png", e.Row.Cells[n_EmailID].Text, e.Row.Cells[n_dbName].Text, e.Row.Cells[4].Text, e.Row.Cells[n_Loginid].Text));
                        e.Row.Cells[n_Action].Controls.Add((Control)AddImageButton("View History", "Click here to View Admin Mail History", "~/View/App_Themes/images/history.png", e.Row.Cells[n_UMID].Text, e.Row.Cells[n_dbName].Text, string.Empty, string.Empty));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Add Control Dynamically to the Manage Admin Users GridView
        /// <summary>
        /// This Method is used to Add ImageButtons
        /// </summary>
        /// <param name="s_Action">Action</param>
        /// <param name="s_ToolTips">ToolTip</param>
        /// <param name="s_Url">Image Url</param>
        /// <param name="s_EmailID">EmailID</param>
        /// <param name="s_CompanyName">CompanyName</param>
        /// <param name="s_UserName">UserName</param>
        /// <param name="s_LoginID">LoginID</param>
        /// <returns>image</returns>
        private ImageButton AddImageButton(string s_Action, string s_ToolTips, string s_Url, string s_EmailID, string s_CompanyName, string s_UserName, string s_LoginID)
        {
            using (ImageButton img = new ImageButton())
            {
                img.ImageUrl = s_Url;
                img.ToolTip = s_ToolTips;
                img.Style.Add("cursor", "pointer");
                img.Style.Add("text-align", "center");

                if (s_Action.Equals("Edit"))
                    img.TabIndex = 8;

                else img.TabIndex = 9;

                if (s_Action.Equals("View History"))
                    img.Attributes.Add("onclick", "return ViewHistory('" + s_EmailID + "','" + s_CompanyName + "')");
                else
                    img.Attributes.Add("onclick", "return UpdateMailPassword('" + s_Action + "','" + s_EmailID + "','" + s_CompanyName + "','" + s_UserName + "','" + s_LoginID + "')");
                return img;
            }
        }
        #endregion

        #region Manage Admin Users GridView Page Index Change Event
        /// <summary>
        /// Page Index Change Event
        /// </summary>
        /// <param name="manageAdminUsers">manageAdminUsers Page Object</param>
        /// <param name="e">e</param>
        internal void gv_PageIndexChanging(ManageAdminUsers manageAdminUsers, GridViewPageEventArgs e)
        {
            try
            {
                manageAdminUsers.gv.PageIndex = e.NewPageIndex;
                manageAdminUsers.gv.DataSource = ac_ManageAdminUsers.dt_ManageAdminUsers;
                manageAdminUsers.gv.DataBind();

                manageAdminUsers.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region View History
        /// <summary>
        /// This Method is used to View History Of Mail In PopUp Div
        /// </summary>
        /// <param name="manageAdminUsers">manageAdminUsers Page Object</param>
        /// <returns>DataTable of Admin Mail History</returns>
        internal DataTable btnMAUViewHistory_Click(ManageAdminUsers manageAdminUsers)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CompanyName = manageAdminUsers.hdnCompanyName.Value;
                    superAdminProperties.SAP_UMID = manageAdminUsers.hdnUMID.Value;
                    superAdminProperties.PageName = CommonConstantModel.s_ManageAdminUsers;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.PopulateControls = "ViewHistory";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                    manageAdminUsers.gvViewHistory.DataSource = (DataTable)superAdminCRUDProperties.dt_Result;
                    manageAdminUsers.gvViewHistory.DataBind();

                    manageAdminUsers.hdnMAUPopUp.Value = "1";

                    manageAdminUsers.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                    return (DataTable)superAdminCRUDProperties.dt_Result;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// The Row Bound Event Of gvViewHistory GridView
        /// </summary>
        /// <param name="e">e</param>
        internal void gvViewHistory_RowDataBound(GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Page index change event of gvViewHistory GridView
        /// </summary>
        /// <param name="manageAdminUsers">manageAdminUsers Page Object</param>
        /// <param name="e">e</param>
        internal void gvViewHistory_PageIndexChanging(ManageAdminUsers manageAdminUsers, GridViewPageEventArgs e)
        {
            try
            {
                manageAdminUsers.gvViewHistory.PageIndex = e.NewPageIndex;

                manageAdminUsers.gvViewHistory.DataSource = btnMAUViewHistory_Click(manageAdminUsers);
                manageAdminUsers.gvViewHistory.DataBind();

                manageAdminUsers.gv.DataSource = ac_ManageAdminUsers.dt_ManageAdminUsers;
                manageAdminUsers.gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ManageAdminUsersModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}