﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Linq;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// Modlel class for CurrencyMasterModel.aspx
    /// </summary>
    public class CurrencyMasterModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public CurrencyMasterModel()
        {
            if (ac_CompanyCreation == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageCurrency);
                ac_ManageCurrency = (CommonModel.AC_ManageCurrency)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageCurrency];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty;

        #endregion

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="manageCurrenciesUI"></param>
        internal void ReadL10N_UI(ManageCurrencies manageCurrenciesUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_ManageCurrencyUI = objSuperAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_ManageCurrencies))
                    {
                        if ((dt_ManageCurrencyUI != null) && (dt_ManageCurrencyUI.Rows.Count > 0))
                        {
                            manageCurrenciesUI.lblParamCurrencyName.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblParamCurrencyName'"))[0]["LabelName"]);
                            manageCurrenciesUI.lblParamCMAlias.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblParamCMAlias'"))[0]["LabelName"]);
                            manageCurrenciesUI.lblCRMIsDefault.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblCRMIsDefault'"))[0]["LabelName"]);
                            manageCurrenciesUI.btnCRMApplyFilter.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMApplyFilter'"))[0]["LabelName"]);
                            manageCurrenciesUI.btnCRMCreateNew.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMCreateNew'"))[0]["LabelName"]);
                            manageCurrenciesUI.btnCRMDelete.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMDelete'"))[0]["LabelName"]);
                            manageCurrenciesUI.lblCurrencyName.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblCurrencyName'"))[0]["LabelName"]);
                            manageCurrenciesUI.lblCRMCurrencyAlias.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblCRMCurrencyAlias'"))[0]["LabelName"]);
                            manageCurrenciesUI.btnCRMSave.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMSave'"))[0]["LabelName"]);
                            manageCurrenciesUI.btnCRMCancel.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMCancel'"))[0]["LabelName"]);
                            manageCurrenciesUI.lblHeader1.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblHeader1'"))[0]["LabelName"]);
                            manageCurrenciesUI.lblHeader2.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblHeader2'"))[0]["LabelName"]);
                            manageCurrenciesUI.lblTopHeader.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblTopHeader'"))[0]["LabelName"]);
                            manageCurrenciesUI.btnCRMClearFilter.Text = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMClearFilter'"))[0]["LabelName"]);

                            manageCurrenciesUI.lblParamCurrencyName.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblParamCurrencyName'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.lblParamCMAlias.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblParamCMAlias'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.lblCRMIsDefault.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblCRMIsDefault'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.btnCRMApplyFilter.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMApplyFilter'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.btnCRMCreateNew.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMCreateNew'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.btnCRMDelete.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMDelete'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.lblCurrencyName.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblCurrencyName'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.lblCRMCurrencyAlias.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblCRMCurrencyAlias'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.btnCRMSave.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMSave'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.btnCRMCancel.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMCancel'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.lblHeader1.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblHeader1'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.lblHeader2.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblHeader2'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.lblTopHeader.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblTopHeader'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.btnCRMClearFilter.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMClearFilter'"))[0]["LabelToolTip"]);
                            manageCurrenciesUI.reqName.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblCurrencyName'"))[0]["ErrorText"]);
                            manageCurrenciesUI.reqAlias.ToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'lblCRMCurrencyAlias'"))[0]["ErrorText"]);

                            s_BtnUpdateText = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMUpdate'"))[0]["LabelName"]);
                            s_BtnUpdateToolTip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMUpdate'"))[0]["LabelToolTip"]);
                            s_BtnSaveText = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMSave'"))[0]["LabelName"]);
                            s_BtnSaveTooltip = Convert.ToString((dt_ManageCurrencyUI.Select("LabelID = 'btnCRMSave'"))[0]["LabelToolTip"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used for bind the data in GridView 
        /// </summary>
        /// <param name="manageCurrenciesUI"></param>
        internal void BindCurrencyDetailsGrid(ManageCurrencies manageCurrenciesUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.CRMID = manageCurrenciesUI.ddlCurrencyName.SelectedValue == ("--- Please Select ---") || manageCurrenciesUI.ddlCurrencyName.SelectedValue == ("") ? 0 : Convert.ToInt32(manageCurrenciesUI.ddlCurrencyName.SelectedValue);
                    superAdminProperties.CRMAliasID = manageCurrenciesUI.ddlCMAlias.SelectedValue == ("--- Please Select ---") || manageCurrenciesUI.ddlCMAlias.SelectedValue == ("") ? 0 : Convert.ToInt32(manageCurrenciesUI.ddlCMAlias.SelectedValue);
                    superAdminProperties.PageName = "CurrencyMaster";
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_ManageCurrency.dt_Currencies = superAdminCRUDProperties.dt_Result;
                    manageCurrenciesUI.gv.DataSource = superAdminCRUDProperties.dt_Result;
                    manageCurrenciesUI.btnCRMDelete.Visible = superAdminCRUDProperties.dt_Result.Rows.Count > 0;

                    if (!(manageCurrenciesUI.ddlCurrencyName.SelectedValue == ("--- Please Select ---") || manageCurrenciesUI.ddlCurrencyName.SelectedValue == ("")))
                    {
                        manageCurrenciesUI.btnCRMClearFilter.Visible = true;
                    }
                    if (!(manageCurrenciesUI.ddlCMAlias.SelectedValue == ("--- Please Select ---") || manageCurrenciesUI.ddlCMAlias.SelectedValue == ("")))
                    {
                        manageCurrenciesUI.btnCRMClearFilter.Visible = true;
                    }
                    manageCurrenciesUI.gv.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used for bind the data in GridView 
        /// </summary>
        /// <param name="manageCurrenciesUI"></param>
        internal void ResetGrid(ManageCurrencies manageCurrenciesUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.CRMID = 0;
                    superAdminProperties.CRMAliasID = 0;
                    superAdminProperties.PageName = "CurrencyMaster";
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    manageCurrenciesUI.gv.DataSource = superAdminCRUDProperties.dt_Result;

                    manageCurrenciesUI.btnCRMDelete.Visible = superAdminCRUDProperties.dt_Result.Rows.Count > 0;

                    manageCurrenciesUI.gv.DataBind();
                }
            }
            catch { throw; }
        }

        /// <summary>
        /// Bind Currency Master
        /// </summary>
        /// <param name="manageCurrenciesUI"></param>
        internal void BindCurrencyName(ManageCurrencies manageCurrenciesUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.CRMID = 0;
                    superAdminProperties.CRMAliasID = 0;
                    superAdminProperties.PageName = "CurrencyMaster";
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    manageCurrenciesUI.ddlCurrencyName.DataSource = superAdminCRUDProperties.dt_Result;
                    manageCurrenciesUI.ddlCurrencyName.DataTextField = "Currency Name";
                    manageCurrenciesUI.ddlCurrencyName.DataValueField = "ID";
                    manageCurrenciesUI.ddlCurrencyName.DataBind();
                    manageCurrenciesUI.ddlCurrencyName.Items.Insert(0, "--- Please Select ---");

                    manageCurrenciesUI.hdnCurrencyMasterID.Value = string.Empty;
                    manageCurrenciesUI.hdnDeletedRecords.Value = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Dropdown for Alias Name of Currencies
        /// </summary>
        /// <param name="manageCurrenciesUI"></param>
        internal void BindCurrencyAlias(ManageCurrencies manageCurrenciesUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.CRMID = 0;
                    superAdminProperties.CRMAliasID = 0;
                    superAdminProperties.PageName = "CurrencyMaster";
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    manageCurrenciesUI.ddlCMAlias.DataSource = superAdminCRUDProperties.dt_Result;
                    manageCurrenciesUI.ddlCMAlias.DataTextField = "Alias";
                    manageCurrenciesUI.ddlCMAlias.DataValueField = "ID";
                    manageCurrenciesUI.ddlCMAlias.DataBind();
                    manageCurrenciesUI.ddlCMAlias.Items.Insert(0, "--- Please Select ---");

                    manageCurrenciesUI.hdnCurrencyMasterID.Value = string.Empty;
                    manageCurrenciesUI.hdnDeletedRecords.Value = string.Empty;
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// CUD[Create/Update/Delete] operation on Forfeiture Group
        /// </summary>
        /// <param name="manageCurrenciesUI"></param>
        /// <returns></returns>
        internal int CUDCurrencyDetails(ManageCurrencies manageCurrenciesUI)
        {
            using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
            {
                if (string.IsNullOrEmpty(manageCurrenciesUI.hdnCurrencyMasterID.Value) && !string.IsNullOrEmpty(manageCurrenciesUI.hdnDeletedRecords.Value))
                    superAdminProperties.Action = "D";
                else
                    superAdminProperties.Action = string.IsNullOrEmpty(manageCurrenciesUI.hdnCurrencyMasterID.Value) ? "C" : "U";

                superAdminProperties.CurrencyName = manageCurrenciesUI.txtCurrencyName.Text;
                superAdminProperties.CurrencyNameAlias = manageCurrenciesUI.txtCurrencyAlias.Text;
                superAdminProperties.IsDefault = manageCurrenciesUI.chkCRMIsDefault.Checked ? true : false;
                superAdminProperties.IsDeleted = string.IsNullOrEmpty(manageCurrenciesUI.hdnDeletedRecords.Value) ? false : true;
                superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                superAdminProperties.ModifiedBy = userSessionInfo.ACC_UserID; ;
                superAdminProperties.CRMID = string.IsNullOrEmpty(manageCurrenciesUI.hdnCurrencyMasterID.Value) ? 0 : Convert.ToInt32(manageCurrenciesUI.hdnCurrencyMasterID.Value);
                superAdminProperties.DeleteIDs = string.IsNullOrEmpty(manageCurrenciesUI.hdnDeletedRecords.Value) ? string.Empty : manageCurrenciesUI.hdnDeletedRecords.Value.TrimStart(',');
                manageCurrenciesUI.txtCurrencyName.Text = "";
                manageCurrenciesUI.txtCurrencyAlias.Text = "";

                manageCurrenciesUI.chkCRMIsDefault.Checked = superAdminProperties.IsDefault == true ? true : false;

                int n_retValue = 0;
                manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                superAdminProperties.PageName = "CurrencyMaster";
                superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                if (manageCurrenciesUI.hdnDefaultCurrency.Value == "Yes" || manageCurrenciesUI.SelectAllChecked.Value.Equals("true"))
                {
                    string s_IsDefault = (from r in ac_ManageCurrency.dt_Currencies.AsEnumerable()
                                              where r.Field<string>("Default Currency") == "Yes"
                                              select r.Field<string>("Default Currency")).First<string>();
                        if (s_IsDefault.Equals("Yes"))
                        {
                            superAdminCRUDProperties.a_result = 6;
                        }
                }
                else
                    superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;

                switch (superAdminCRUDProperties.a_result)
                {
                    case 0:
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCRMError");
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        n_retValue = 0;
                        break;

                    case 1:
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCRMCreated");
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        n_retValue = 1;
                        break;

                    case 2:
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCRMUpdated");
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        n_retValue = 2;
                        break;

                    case 3:
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCRMDeleted");
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        n_retValue = 3;
                        break;

                    case 4:
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCRMIsExist");
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        n_retValue = 3;
                        break;

                    case 5:
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCRMReactive");
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_RevOptionsDisplay = "block";
                        ac_ManageCurrency.s_CurrencyName = superAdminProperties.CurrencyName;
                        n_retValue = 3;
                        break;

                    case 6:
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        manageCurrenciesUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCRMDefaultCurrency");
                        manageCurrenciesUI.hdnDefaultCurrency.Value = string.Empty;
                        manageCurrenciesUI.hdnDeletedRecords.Value = string.Empty;
                        manageCurrenciesUI.SelectAllChecked.Value = string.Empty;
                        n_retValue = 3;
                        break;
                }
                return n_retValue;
            }
        }
        /// <summary>
        /// CUD[Create/Update/Delete] operation on Forfeiture Group
        /// </summary>
        /// <param name="manageCurrenciesUI"></param>
        /// <returns></returns>
        internal void ReactivateCurrencyDetails(ManageCurrencies manageCurrenciesUI)
        {
            try
            {
                using (SuperAdminServiceClient objSuperAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.Action = "U";
                    superAdminProperties.CurrencyName = ac_ManageCurrency.s_CurrencyName;
                    superAdminProperties.IsDeleted = false;
                    superAdminProperties.IsDefault = manageCurrenciesUI.chkCRMIsDefault.Checked ? true : false;
                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    superAdminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    superAdminProperties.CRMID = 0;
                    manageCurrenciesUI.txtCurrencyName.Text = "";
                    manageCurrenciesUI.txtCurrencyAlias.Text = "";
                    manageCurrenciesUI.chkCRMIsDefault.Checked = false;

                    manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    superAdminProperties.PageName = "CurrencyMaster";
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    superAdminCRUDProperties = objSuperAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    switch (superAdminCRUDProperties.a_result)
                    {
                        case 0:
                            manageCurrenciesUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCRMError");
                            manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 2:
                            manageCurrenciesUI.ctrSuccessErrorMessage.s_MessageText = objSuperAdminServiceClient.LoadL10N("lblCRMUpdated");
                            manageCurrenciesUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;


                    }
                    manageCurrenciesUI.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                }
            }
            catch
            {
                throw;
            }
        }

        #region Bind/Hide rows into GridView gv
        /// <summary>
        /// Bind GridView Rows
        /// </summary>
        /// <param name="e"></param>
        /// <param name="n_index"></param>
        /// <param name="n_ID"></param>
        /// <param name="n_Delete"></param>
        /// <param name="n_Action"></param>
        /// <param name="n_DefCurrency"></param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action, ref int n_DefCurrency)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    n_Delete = n_index;
                                    e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                    break;

                                case "DEFAULT CURRENCY":
                                    n_DefCurrency = n_index;
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, "Edit"));
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[1].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[n_DefCurrency].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Create Image button
        /// </summary>
        /// <param name="s_strToolTip"></param>
        /// <param name="s_strUrl"></param>
        /// <param name="s_CurrencyID"></param>
        /// <param name="s_CurrencyName"></param>
        /// <param name="s_Status"></param>
        /// <param name="s_IsDefault"></param>
        /// <param name="s_Action"></param>
        /// <returns></returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_CurrencyID, string s_CurrencyName, string s_Status, string s_IsDefault, string s_Action)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");
                if (!string.IsNullOrEmpty(s_CurrencyName))
                {
                    imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_CurrencyName + "','" + s_Status + "','" + s_CurrencyID + "','" + s_IsDefault + "')");
                }
                return imgButton;
            }
        }

        /// <summary>
        /// Bind CheckBox for delete multiple records
        /// </summary>
        /// <param name="s_CurrencyID"></param>
        /// <param name="s_DefCurrency"></param>
        /// <param name="IsDeleted"></param>
        /// <returns></returns>
        private CheckBox AddCheckBox(string s_CurrencyID, string s_DefCurrency, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_CurrencyID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");
                if (!string.IsNullOrEmpty(s_CurrencyID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_CurrencyID + "','" + s_DefCurrency + "',this)");
                }
                return checkBox;
            }

        }
        /// <summary>
        /// Add Delete all checkbox
        /// </summary>
        /// <returns></returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chk";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.Text = string.Empty;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }
        #endregion

        /// <summary>
        /// Bind next page data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <param name="gv"></param>
        /// <param name="s_CurrencyID"></param>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_CurrencyID)
        {
            try
            {
                string[] s_CurrencyIDs = s_CurrencyID.TrimStart(',').Split(',');

                ac_ManageCurrency.dt_Currencies.Columns["Delete"].Expression = string.Empty;
                ac_ManageCurrency.dt_Currencies.AcceptChanges();

                foreach (string perID in s_CurrencyIDs)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_ManageCurrency.dt_Currencies.Select("ID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_ManageCurrency.dt_Currencies;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CurrencyMasterModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}