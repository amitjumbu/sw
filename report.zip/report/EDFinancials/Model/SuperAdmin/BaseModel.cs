﻿using EDFinancials.Model.Generic;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// Base class model for Super Admin
    /// </summary>
    public class BaseModel : EDFinancials.Model.BaseModel
    {
        /// <summary>
        /// DEFAULT CONSTRUCTOR
        /// </summary>
        public BaseModel()
        {
            if ((SuperAdminProperties)System.Web.HttpContext.Current.Session["superAdminProperties"] == null)
            {
                superAdminProperties = new SuperAdminProperties();
                System.Web.HttpContext.Current.Session["superAdminProperties"] = superAdminProperties;
            }
            else
            {
                superAdminProperties = (SuperAdminProperties)System.Web.HttpContext.Current.Session["superAdminProperties"];
            }


            if ((SuperAdminCRUDProperties)System.Web.HttpContext.Current.Session["superAdminCRUDProperties"] == null)
            {
                superAdminCRUDProperties = new SuperAdminCRUDProperties();
                System.Web.HttpContext.Current.Session["superAdminCRUDProperties"] = superAdminCRUDProperties;
            }
            else
            {
                superAdminCRUDProperties = (SuperAdminCRUDProperties)System.Web.HttpContext.Current.Session["superAdminCRUDProperties"];
            }                  
        }
            
        /// <summary>
        /// PRIVATE DECLARATION FOR SUPERADMIN PROPERTY
        /// </summary>
        private SuperAdminProperties _superAdminProperties;

        /// <summary>
        /// PUBLIC DECLARATION FOR SUPERADMIN PROPERTY
        /// </summary>
        public SuperAdminProperties superAdminProperties
        {
            get { return _superAdminProperties; }
            set { _superAdminProperties = value; }
        }

        /// <summary>
        /// PRIVATE DECLARATION FOR SUPER ADMIN CURD PROPERTY
        /// </summary>
        private SuperAdminCRUDProperties _superAdminCRUDProperties;

        /// <summary>
        /// PUBLIC DECLARATION FOR SUPER ADMIN CURD PROPERTY
        /// </summary>
        public SuperAdminCRUDProperties superAdminCRUDProperties
        {
            get { return _superAdminCRUDProperties; }
            set { _superAdminCRUDProperties = value; }
        }

        /// <summary>
        /// OBJECT OF COMPANY ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_CompanyCreation ac_CompanyCreation;

        /// <summary>
        /// OBJECT OF MANAGE ADMIN USERS ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ManageAdminUsers ac_ManageAdminUsers;

        /// <summary>
        ///  OBJECT OF STATUS REPORT ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_StatusReport ac_StatusReport;

        /// <summary>
        /// OBJECT OF MANAGE MODULE, SUB MODULE, ASSOCIATE MODULE-SUBMODULE ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ManageModule ac_ManageModule;

        /// <summary>
        /// OBJECT OF MANAGE STOCK EXCHANGE ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ManageStockExchange ac_ManageStockExchange;

        /// <summary>
        /// OBJECT OF MANAGE CURRENCY ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ManageCurrency ac_ManageCurrency;

        /// <summary>
        /// OBJECT OF MANAGE FORFEITURE GROUP ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ManageForefeiture ac_ManageForefeiture;

        /// <summary>
        /// OBJECT OF MANAGE COUNTRY ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ManageCountry ac_ManageCountry;

        /// <summary>
        /// OBJECT OF MANAGE RFIR ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ManageRFIR ac_ManageRFIR;

        /// <summary>
        /// OBJECT OF UI CONFIGURATION ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ConfigureUI ac_ConfigureUI;

        /// <summary>
        /// OBJECT OF HELP ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_Help ac_Help;
    }
}