﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.SuperAdmin
{

    /// <summary>
    /// Model Class for StatusReportModel
    /// </summary>
    public class StatusReportModel : BaseModel, IDisposable
    {

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public StatusReportModel()
        {
            if (ac_StatusReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_StatusReport);
                ac_StatusReport = (CommonModel.AC_StatusReport)HttpContext.Current.Session[CommonConstantModel.s_AC_StatusReport];
            }
        }
        #endregion

        /// <summary>
        ///  Variable
        /// </summary>
        public string s_IsMailSent = string.Empty;

        #region Bind  UI
        /// <summary>
        ///  This Method is used to bind UI Controls     
        /// </summary>
        /// <param name="statusReport">statusReport</param>
        internal void BindUI(View.SuperAdmin.StatusReport statusReport)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    if (ac_StatusReport.dt_StatusReportUI == null || ac_StatusReport.dt_StatusReportUI.Rows.Count.Equals(0))
                    {
                        ac_StatusReport.dt_StatusReportUI = superAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_StatusReport);
                    }
                    if ((ac_StatusReport.dt_StatusReportUI != null) && (ac_StatusReport.dt_StatusReportUI.Rows.Count > 0))
                    {
                        foreach (Control control in statusReport.dvMain.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, statusReport, ac_StatusReport.dt_StatusReportUI, (Label)control, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, statusReport, ac_StatusReport.dt_StatusReportUI, null, (TextBox)control, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, statusReport, ac_StatusReport.dt_StatusReportUI, null, null, (Button)control, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, statusReport, ac_StatusReport.dt_StatusReportUI, null, null, null, (BaseValidator)control, null, null);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, statusReport, ac_StatusReport.dt_StatusReportUI, null, null, null, null, (BaseValidator)control, null);
                                    break;

                                case CommonConstantModel.s_cntrlTypeGridView:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, statusReport, ac_StatusReport.dt_StatusReportUI, null, null, null, null, null, (GridView)control);
                                    break;
                            }
                        }
                        statusReport.lblPaneHeader.Text = Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID='lblPaneHeader'"))[0]["LabelName"]);
                        statusReport.lblURPageName.Text = Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID='lblURPageName'"))[0]["LabelName"]);
                        statusReport.lblValHeader.Text = Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID='lblValHeader'"))[0]["LabelName"]);
                        statusReport.lblAccHeader.Text = Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID='lblAccHeader'"))[0]["LabelName"]);
                        //statusReport.lblDiscHeader.Text = Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID='lblDiscHeader'"))[0]["LabelName"]);
                    }
                }
            }
            catch (Exception ex)
            {

                throw (ex);
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="statusReport">The Status Report class object</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="label">The label control object</param>
        /// <param name="textBox">The text-box control object</param>
        /// <param name="button">The button control object</param>
        /// <param name="ReqValidator">validator control object</param>
        /// <param name="RegExpValidator">validator control object</param>
        /// <param name="gridView">gridview control object</param>
        private void BindPropertiesToControl(string s_cntrlType, StatusReport statusReport, DataTable Dt_Get_L10N_UI, Label label, TextBox textBox, Button button, BaseValidator ReqValidator, BaseValidator RegExpValidator, GridView gridView)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    gridView.EmptyDataText = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + gridView.ID + "'"))[0]["LabelName"]);
                    break;

                case CommonConstantModel.s_cntrlTypeTextBox:
                    break;
            }
        }

        #endregion

        #region Bind Company List
        /// <summary>
        ///  This Method is used to bind comapany names to AutoCompleteTextbox
        /// </summary>
        /// <param name="company">Company</param>     
        public List<string> BindSRCompnyList(string company)
        {
            List<string> companylist = new List<string>();
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    companylist = (from b in ac_StatusReport.ds_Filter_StatusResult.Tables[1].AsEnumerable()
                                   where b.Field<string>("COMPANY") != null && b.Field<string>("COMPANY").StartsWith(Convert.ToString(company).Trim(), StringComparison.OrdinalIgnoreCase)
                                   select b.Field<string>("COMPANY")).Distinct().ToList();

                    return companylist;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used for getting all records from database
        /// </summary>
        internal void GetValuesFromDatabase(StatusReport statusReport)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                superAdminProperties.PAGE_INDEX = 1;
                superAdminProperties.PAGE_SIZE = 10;
                superAdminProperties.CompanyName = String.Empty;
                statusReport.btnResetStatus.Visible = false;

                superAdminProperties.PopulateControls = "CompanyDetails";

                superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                ac_StatusReport.ds_StatusResult = (DataSet)superAdminCRUDProperties.ds_Result;

                ac_StatusReport.n_GrdRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[2].Rows[0]["TOTAL_COUNT"]));

                ac_StatusReport.ds_Filter_StatusResult = ac_StatusReport.ds_StatusResult;
                statusReport.GV.DataSource = ac_StatusReport.ds_Filter_StatusResult.Tables[0];
                statusReport.GV.DataBind();
                GetGVColumnsByStatus(statusReport);
                BindPagerForGridView(statusReport);
                statusReport.GV.Columns[1].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                statusReport.GV.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                statusReport.GV.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                statusReport.GV.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                statusReport.hdnAccordionIndex.Value = "0";
                statusReport.h3ACCAddEdit.Style.Add("display", "none");
            }
        }

        /// <summary>
        /// This method is used for Custom Pagination and bind all records from database
        /// </summary>
        internal void GetPaginationValues(StatusReport statusReport)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                superAdminProperties.PAGE_INDEX = ac_StatusReport.n_PageIndex.Equals(0) ? 1 : ac_StatusReport.n_PageIndex;
                superAdminProperties.PAGE_SIZE = ac_StatusReport.n_PageSize.Equals(0) ? 10 : ac_StatusReport.n_PageSize;
                superAdminProperties.CompanyName = String.Empty;
                statusReport.btnResetStatus.Visible = true;

                superAdminProperties.PopulateControls = "CompanyDetails";

                superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                ac_StatusReport.ds_StatusResult = (DataSet)superAdminCRUDProperties.ds_Result;

                ac_StatusReport.n_GrdRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[2].Rows[0]["TOTAL_COUNT"]));

                ac_StatusReport.ds_Filter_StatusResult = ac_StatusReport.ds_StatusResult;
                statusReport.GV.DataSource = ac_StatusReport.ds_Filter_StatusResult.Tables[0];
                statusReport.GV.DataBind();
                GetGVColumnsByStatus(statusReport);

                BindPagerForGridView(statusReport);
                statusReport.GV.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                statusReport.GV.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                statusReport.GV.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;

                if (statusReport.btnResetStatus.Text != "Reset")
                {
                    switch (statusReport.ddlStatusRepo.SelectedItem.Value)
                    {
                        case "1":
                            statusReport.GV.Columns[3].Visible = false;
                            statusReport.GV.Columns[4].Visible = false;
                            break;
                        case "2":
                            statusReport.GV.Columns[2].Visible = false;
                            statusReport.GV.Columns[4].Visible = false;
                            break;
                        case "3":
                            statusReport.GV.Columns[2].Visible = false;
                            statusReport.GV.Columns[3].Visible = false;
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Get GridView Columns by status
        /// </summary>
        /// <param name="statusReport"></param>
        internal void GetGVColumnsByStatus(StatusReport statusReport)
        {
            switch (statusReport.ddlStatusRepo.SelectedItem.Value)
            {
                case "1":
                    statusReport.GV.Columns[2].Visible = true;
                    statusReport.GV.Columns[3].Visible = false;
                    statusReport.GV.Columns[4].Visible = false;
                    break;
                case "2":
                    statusReport.GV.Columns[2].Visible = false;
                    statusReport.GV.Columns[3].Visible = true;
                    statusReport.GV.Columns[4].Visible = false;
                    break;
                case "3":
                    statusReport.GV.Columns[2].Visible = false;
                    statusReport.GV.Columns[3].Visible = false;
                    statusReport.GV.Columns[4].Visible = true;
                    break;

                default:
                    statusReport.GV.Columns[1].Visible = true;
                    statusReport.GV.Columns[2].Visible = true;
                    statusReport.GV.Columns[3].Visible = true;
                    statusReport.GV.Columns[4].Visible = true;
                    break;
            }
        }

        /// <summary>
        /// This method is used for Reload all records from database
        /// </summary>
        internal void ReloadGrid(StatusReport statusReport)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                superAdminProperties.PAGE_INDEX = ac_StatusReport.n_PageIndex.Equals(0) ? 1 : ac_StatusReport.n_PageIndex;
                superAdminProperties.PAGE_SIZE = ac_StatusReport.n_PageSize.Equals(0) ? 10 : ac_StatusReport.n_PageSize;
                superAdminProperties.CompanyName = String.Empty;
                statusReport.btnResetStatus.Visible = false;

                superAdminProperties.PopulateControls = "CompanyDetails";

                superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                ac_StatusReport.ds_StatusResult = (DataSet)superAdminCRUDProperties.ds_Result;

                ac_StatusReport.n_GrdRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[2].Rows[0]["TOTAL_COUNT"]));

                ac_StatusReport.ds_Filter_StatusResult = ac_StatusReport.ds_StatusResult;
                statusReport.GV.DataSource = ac_StatusReport.ds_Filter_StatusResult.Tables[0];
                statusReport.GV.DataBind();
                statusReport.GV.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                statusReport.GV.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                statusReport.GV.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                statusReport.GV.Columns[2].Visible = true;
                statusReport.GV.Columns[3].Visible = true;
                statusReport.GV.Columns[4].Visible = true;
            }
        }

        #endregion

        #region Bind Status List
        /// <summary>
        /// This method is used to bind SubModule to the Dropdownlist
        /// </summary>
        /// <param name="statusReport"></param>        
        internal void BindStatus(StatusReport statusReport)
        {
            try
            {
                Button btn = new Button();
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PopulateControls = "StatusDetails";


                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    statusReport.ddlStatusRepo.DataSource = (DataTable)superAdminCRUDProperties.dt_Result;

                    statusReport.ddlStatusRepo.DataTextField = "DISPLAY";
                    statusReport.ddlStatusRepo.DataValueField = "SN";
                    statusReport.ddlStatusRepo.DataBind();

                    statusReport.ddlStatusRepo.Items.Insert(0, "--- Please Select ---");
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Bind Valuation Company List
        /// <summary>
        ///  This Method is used to bind comapany names to AutoCompleteTextbox
        /// </summary>
        /// <param name="company">Company</param>     
        public List<string> BindValCompnyList(string company)
        {
            List<string> companylist = new List<string>();
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    companylist = (from b in ac_StatusReport.ds_StatusValResult.Tables[2].AsEnumerable()
                                   where b.Field<string>("COMPANY") != null && b.Field<string>("COMPANY").StartsWith(Convert.ToString(company).Trim(), StringComparison.OrdinalIgnoreCase)
                                   select b.Field<string>("COMPANY")).Distinct().ToList();

                    return companylist;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Bind Accounting Company List
        /// <summary>
        ///  This Method is used to bind comapany names to AutoCompleteTextbox
        /// </summary>
        /// <param name="company">Company</param>     
        public List<string> BindAccCompnyList(string company)
        {
            List<string> companylist = new List<string>();
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    companylist = (from b in ac_StatusReport.ds_StatusAccResult.Tables[2].AsEnumerable()
                                   where b.Field<string>("COMPANY") != null && b.Field<string>("COMPANY").StartsWith(Convert.ToString(company).Trim(), StringComparison.OrdinalIgnoreCase)
                                   select b.Field<string>("COMPANY")).Distinct().ToList();

                    return companylist;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Get Valuation Status List
        /// <summary>
        ///  This method is used to bind Status Report list to grid
        /// </summary>
        /// <param name="statusReport">statusReport</param>
        /// <returns> Data table of Status Report list </returns>
        internal void GetValStatusReportList(StatusReport statusReport)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.CompanyName = (string.IsNullOrEmpty(statusReport.TxtVALCompany.Text)) ? "" : statusReport.TxtVALCompany.Text;
                    superAdminProperties.Report_Status = (string.IsNullOrEmpty(statusReport.ddlValStatus.SelectedValue) || (statusReport.ddlValStatus.SelectedValue.Equals("--- Please Select ---"))) ? "" : statusReport.ddlValStatus.SelectedValue;
                    superAdminProperties.Pending_Stage = (string.IsNullOrEmpty(statusReport.ddlPendStag.SelectedValue) || (statusReport.ddlPendStag.SelectedValue.Equals("--- Please Select ---"))) ? "" : statusReport.ddlPendStag.SelectedValue;
                    superAdminProperties.Users_Name = (string.IsNullOrEmpty(statusReport.ddlValUsers.SelectedValue) || (statusReport.ddlValUsers.SelectedValue.Equals("--- Please Select ---"))) ? "" : statusReport.ddlValUsers.SelectedValue;
                    superAdminProperties.Module_Name = (string.IsNullOrEmpty(statusReport.ddlValModule.SelectedValue) || (statusReport.ddlValModule.SelectedValue.Equals("--- Please Select ---"))) ? "" : statusReport.ddlValModule.SelectedValue;
                    superAdminProperties.PAGE_INDEX = ac_StatusReport.n_ValPageIndex.Equals(0) ? 1 : ac_StatusReport.n_ValPageIndex;
                    superAdminProperties.PAGE_SIZE = ac_StatusReport.n_ValPageSize.Equals(0) ? 10 : ac_StatusReport.n_ValPageSize;
                    statusReport.BtnResetValRepo.Visible = false;
                    superAdminProperties.PopulateControls = "StatusValuationDetails";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_StatusReport.ds_StatusValResult = (DataSet)superAdminCRUDProperties.ds_Result;

                    ac_StatusReport.n_GridViewRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_COUNT"]));

                    statusReport.ddlValStatus.DataSource = (from b in ac_StatusReport.ds_StatusValResult.Tables[2].AsEnumerable()
                                                            where b.Field<string>("WORKFLOW_STATUS") != null
                                                            select b.Field<string>("WORKFLOW_STATUS")).Distinct();
                    statusReport.ddlValStatus.DataBind();

                    statusReport.ddlPendStag.DataSource = (from b in ac_StatusReport.ds_StatusValResult.Tables[2].AsEnumerable()
                                                           where b.Field<string>("PENDING_STAGE") != null
                                                           select b.Field<string>("PENDING_STAGE")).Distinct();
                    statusReport.ddlPendStag.DataBind();

                    statusReport.ddlValModule.DataSource = (from b in ac_StatusReport.ds_StatusValResult.Tables[2].AsEnumerable()
                                                            where b.Field<string>("MODULE_ASSOCIATE") != null
                                                            select b.Field<string>("MODULE_ASSOCIATE")).Distinct();
                    statusReport.ddlValModule.DataBind();

                    statusReport.ddlValUsers.DataSource = (from b in ac_StatusReport.ds_StatusValResult.Tables[1].AsEnumerable()
                                                           where b.Field<string>("TEMP_USER_ID") != null
                                                           select b.Field<string>("TEMP_USER_ID")).Distinct();
                    statusReport.ddlValUsers.DataBind();

                    statusReport.GVVal.DataSource = ac_StatusReport.ds_StatusValResult.Tables[0];
                    statusReport.GVVal.Columns[0].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[1].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVVal.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[5].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVVal.Columns[6].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVVal.DataBind();
                    BindPagerForValGridView(statusReport);
                    statusReport.ddlValStatus.Items.Insert(0, "--- Please Select ---");
                    statusReport.ddlPendStag.Items.Insert(0, "--- Please Select ---");
                    statusReport.ddlValModule.Items.Insert(0, "--- Please Select ---");
                    statusReport.ddlValUsers.Items.Insert(0, "--- Please Select ---");
                    ac_StatusReport.s_Valutaitonlnk = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Get Accounting Status List
        /// <summary>
        ///  This method is used to bind Status Report list to grid
        /// </summary>
        /// <param name="statusReport">statusReport</param>
        /// <returns> Data table of Status Report list </returns>
        internal void GetAccStatusReportList(StatusReport statusReport)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.CompanyName = (string.IsNullOrEmpty(statusReport.TxtAccComp.Text)) ? "" : statusReport.TxtAccComp.Text;
                    superAdminProperties.Report_Status = (string.IsNullOrEmpty(statusReport.ddlAccStatus.SelectedValue)) || (statusReport.ddlAccStatus.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccStatus.SelectedValue;
                    superAdminProperties.Pending_Stage = (string.IsNullOrEmpty(statusReport.ddlAccPendStag.SelectedValue)) || (statusReport.ddlAccPendStag.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccPendStag.SelectedValue;
                    superAdminProperties.Users_Name = (string.IsNullOrEmpty(statusReport.ddlAccUser.SelectedValue) || (statusReport.ddlAccUser.SelectedValue.Equals("--- Please Select ---"))) ? "" : statusReport.ddlAccUser.SelectedValue;
                    superAdminProperties.Module_Name = (string.IsNullOrEmpty(statusReport.ddlAccModule.SelectedValue)) || (statusReport.ddlAccModule.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccModule.SelectedValue;
                    superAdminProperties.Acc_From_Date = (string.IsNullOrEmpty(statusReport.datepickerFromDate.Value) || statusReport.datepickerFromDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : (statusReport.datepickerFromDate.Value);
                    superAdminProperties.Acc_To_Date = (string.IsNullOrEmpty(statusReport.datepickerToDate.Value) || statusReport.datepickerToDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : (statusReport.datepickerToDate.Value);
                    superAdminProperties.PAGE_INDEX = ac_StatusReport.n_AccPageIndex.Equals(0) ? 1 : ac_StatusReport.n_AccPageIndex;
                    superAdminProperties.PAGE_SIZE = ac_StatusReport.n_AccPageSize.Equals(0) ? 10 : ac_StatusReport.n_AccPageSize;
                    statusReport.BtnResetAccRepo.Visible = false;
                    superAdminProperties.PopulateControls = "StatusAccountingDetails";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_StatusReport.ds_StatusAccResult = (DataSet)superAdminCRUDProperties.ds_Result;

                    ac_StatusReport.n_GrdViewAccRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_COUNT"]));

                    statusReport.ddlAccStatus.DataSource = (from b in ac_StatusReport.ds_StatusAccResult.Tables[2].AsEnumerable()
                                                            where b.Field<string>("WORKFLOW_STATUS") != null
                                                            select b.Field<string>("WORKFLOW_STATUS")).Distinct();
                    statusReport.ddlAccStatus.DataBind();

                    statusReport.ddlAccPendStag.DataSource = (from b in ac_StatusReport.ds_StatusAccResult.Tables[2].AsEnumerable()
                                                              where b.Field<string>("PENDING_STAGE") != null
                                                              select b.Field<string>("PENDING_STAGE")).Distinct();
                    statusReport.ddlAccPendStag.DataBind();

                    statusReport.ddlAccModule.DataSource = (from b in ac_StatusReport.ds_StatusAccResult.Tables[2].AsEnumerable()
                                                            where b.Field<string>("MODULE_ASSOCIATE") != null
                                                            select b.Field<string>("MODULE_ASSOCIATE")).Distinct();
                    statusReport.ddlAccModule.DataBind();

                    statusReport.ddlAccUser.DataSource = (from b in ac_StatusReport.ds_StatusAccResult.Tables[1].AsEnumerable()
                                                          where b.Field<string>("TEMP_USER_ID") != null
                                                          select b.Field<string>("TEMP_USER_ID")).Distinct();
                    statusReport.ddlAccUser.DataBind();

                    statusReport.GVACC.DataSource = ac_StatusReport.ds_StatusAccResult.Tables[0];
                    statusReport.GVACC.DataBind();
                    statusReport.GVACC.Columns[0].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[1].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVACC.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[5].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[6].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    BindPagerForAccGridView(statusReport);
                    statusReport.ddlAccStatus.Items.Insert(0, "--- Please Select ---");
                    statusReport.ddlAccPendStag.Items.Insert(0, "--- Please Select ---");
                    statusReport.ddlAccModule.Items.Insert(0, "--- Please Select ---");
                    statusReport.ddlAccUser.Items.Insert(0, "--- Please Select ---");
                    ac_StatusReport.s_Accountinglnk = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Apply filter in GridView
        /// <summary>
        ///  Apply Filter in Gridview For Paritcular Status and Company
        /// </summary>
        /// <param name="statusReport">statusReport</param>
        /// <param name="sender">sender</param>
        internal void GV_Filter(StatusReport statusReport, object sender)
        {
            Button btn = (Button)sender;

            switch (btn.ID)
            {
                case "btnSearchStatus":

                    statusReport.btnResetStatus.Visible = (((statusReport.txtSRCompanyName.Text.Equals("")) && (statusReport.ddlStatusRepo.SelectedValue.Equals("--- Please Select ---"))) ? false : true);
                    statusReport.lblURPageName.Text = statusReport.ddlStatusRepo.Text.Equals("--- Please Select ---") ? Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID='lblURPageName'"))[0]["LabelName"]) : Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID='lblURPageName'"))[0]["LabelName"]) + " : " +
                                                      (statusReport.ddlStatusRepo.SelectedValue.Equals("1") ? Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID ='lblValHeader'"))[0]["LabelName"]) :
                                                      statusReport.ddlStatusRepo.SelectedValue.Equals("2") ? Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID='lblAccHeader'"))[0]["LabelName"]) :
                                                      Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID='lblDiscHeader'"))[0]["LabelName"]));

                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                        superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                        superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        superAdminProperties.CompanyName = statusReport.txtSRCompanyName.Text;
                        superAdminProperties.PAGE_INDEX = ac_StatusReport.n_PageIndex.Equals(0) ? 1 : ac_StatusReport.n_PageIndex;
                        superAdminProperties.PAGE_SIZE = ac_StatusReport.n_PageSize.Equals(0) ? 10 : ac_StatusReport.n_PageSize;
                        statusReport.btnResetStatus.Visible = (statusReport.txtSRCompanyName.Text.Equals("")) && (statusReport.ddlStatusRepo.SelectedIndex.Equals(0)) ? false : true;
                        superAdminProperties.PopulateControls = "CompanyDetails";

                        superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                        ac_StatusReport.ds_StatusResult = (DataSet)superAdminCRUDProperties.ds_Result;


                        ac_StatusReport.n_GrdRecordsCount = Convert.ToInt16(Convert.ToString(ac_StatusReport.ds_StatusResult.Tables[2].Rows[0]["TOTAL_COUNT"]));

                        var s_AGRMID = string.Join(",", statusReport.txtSRCompanyName.Text.TrimStart(',').Split(',').Select(x => x.Trim().Insert(0, "'") + "'").ToArray());

                        string s_Query = "COMPANY IN (" + s_AGRMID + ")";

                        if (!string.IsNullOrEmpty(statusReport.txtSRCompanyName.Text))
                            ac_StatusReport.ds_Filter_StatusResult.Tables[1].DefaultView.RowFilter = s_Query;

                        if ((statusReport.ddlStatusRepo.SelectedItem.Value.Equals("1") || statusReport.ddlStatusRepo.SelectedItem.Value.Equals("2") || statusReport.ddlStatusRepo.SelectedItem.Value.Equals("3")) && (statusReport.txtSRCompanyName.Text.Equals("")))
                        {
                            DataTable dt_FilteredDropdown = ac_StatusReport.ds_StatusResult.Tables[0].DefaultView.ToTable();
                            statusReport.GV.DataSource = dt_FilteredDropdown;
                            statusReport.GV.DataBind();
                            statusReport.GV.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                            statusReport.GV.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                            statusReport.GV.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                            BindPagerForGridView(statusReport);
                            GetGVColumnsByStatus(statusReport);
                            statusReport.h3AddEdit.Style.Add("display", "none");
                            statusReport.h3ACCAddEdit.Style.Add("display", "none");
                        }
                        else
                        {
                            if (((statusReport.txtSRCompanyName.Text.Equals("")) && (statusReport.ddlStatusRepo.SelectedValue.Equals("--- Please Select ---"))))
                            {
                                DataTable dt_FilterSearch = ac_StatusReport.ds_StatusResult.Tables[0].DefaultView.ToTable();
                                statusReport.GV.DataSource = dt_FilterSearch;
                                statusReport.GV.DataBind();
                                statusReport.GV.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                                statusReport.GV.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                                statusReport.GV.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                                BindPagerForGridView(statusReport);
                                GetGVColumnsByStatus(statusReport);
                                statusReport.h3AddEdit.Style.Add("display", "none");
                                statusReport.h3ACCAddEdit.Style.Add("display", "none");
                            }

                            if ((!statusReport.txtSRCompanyName.Text.Equals("")))
                            {
                                DataTable dt_FilteredDatatable = ac_StatusReport.ds_StatusResult.Tables[1].DefaultView.ToTable();
                                ac_StatusReport.s_status = statusReport.ddlStatusRepo.SelectedItem.Value;

                                statusReport.GV.DataSource = dt_FilteredDatatable;
                                statusReport.GV.DataBind();
                                statusReport.GV.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                                statusReport.GV.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                                statusReport.GV.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                                BindPagerForGridView(statusReport);
                                GetGVColumnsByStatus(statusReport);
                                statusReport.h3AddEdit.Style.Add("display", "none");
                                statusReport.h3ACCAddEdit.Style.Add("display", "none");
                            }

                        }

                    }
                    break;
            }
        }
        #endregion

        #region Apply filter in Valuation Gridview
        /// <summary>
        /// Apply Filter on ValuationStatusReport GridView 
        /// </summary>
        /// <param name="statusReport">statusReport</param>
        /// <param name="sender">sender</param>
        internal void GV_Valuation_Filter(StatusReport statusReport, object sender)
        {
            Button btn = (Button)sender;

            switch (btn.ID)
            {
                case "BtnSearchValRepo":

                    statusReport.BtnResetValRepo.Visible = (((statusReport.TxtVALCompany.Text.Equals("")) || (statusReport.ddlValStatus.SelectedValue.Equals("--- Please Select ---")) || (statusReport.ddlPendStag.SelectedValue.Equals("--- Please Select ---")) || (statusReport.ddlValModule.SelectedValue.Equals("--- Please Select ---"))) || (!string.IsNullOrEmpty(statusReport.TxtVALCompany.Text)) || (!string.IsNullOrEmpty(statusReport.ddlValStatus.SelectedValue)) || (!string.IsNullOrEmpty(statusReport.ddlPendStag.SelectedValue)) || (!string.IsNullOrEmpty(statusReport.ddlValModule.SelectedValue)) ? true : false);

                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                        superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                        superAdminProperties.CompanyName = string.Join(",", statusReport.TxtVALCompany.Text.TrimStart(',').Split(',').Select(x => x.Trim().Insert(0, "") + "").ToArray());
                        superAdminProperties.Report_Status = (statusReport.ddlValStatus.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlValStatus.SelectedValue;
                        superAdminProperties.Pending_Stage = (statusReport.ddlPendStag.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlPendStag.SelectedValue;
                        superAdminProperties.Users_Name = (statusReport.ddlValUsers.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlValUsers.SelectedValue;
                        superAdminProperties.Module_Name = (statusReport.ddlValModule.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlValModule.SelectedValue;
                        superAdminProperties.PAGE_INDEX = 1;
                        superAdminProperties.PAGE_SIZE = 10;
                        statusReport.BtnResetValRepo.Visible = true;
                        superAdminProperties.PopulateControls = "StatusValuationDetails";

                        superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                        ac_StatusReport.ds_StatusValResult = (DataSet)superAdminCRUDProperties.ds_Result;

                        ac_StatusReport.n_GridViewRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_COUNT"]));

                        DataTable dt_FilteredValDatatable = ac_StatusReport.ds_StatusValResult.Tables[0].DefaultView.ToTable();
                        if (dt_FilteredValDatatable.Rows[0]["WORKFLOW_STATUS"].Equals("Step : 6  Locked"))
                        {
                            statusReport.GVVal.Columns[0].Visible = false;
                            statusReport.GVVal.DataSource = dt_FilteredValDatatable;
                            statusReport.GVVal.DataBind();
                        }
                        else
                        {
                            statusReport.GVVal.Columns[0].Visible = true;
                            statusReport.GVVal.DataSource = dt_FilteredValDatatable;
                            statusReport.GVVal.DataBind();
                        }
                        BindPagerForValGridView(statusReport);
                        GetValuesFromDatabase(statusReport);
                        statusReport.hdnAccordionIndex.Value = "1";
                        statusReport.h3AddEdit.Style.Add("display", "block");
                        statusReport.h3ACCAddEdit.Style.Add("display", "none");
                        statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    }
                    break;
            }
        }
        #endregion

        #region Apply filter in Accounting Gridview
        /// <summary>
        /// Apply Filter on AccountingStatusReport GridView 
        /// </summary>
        /// <param name="statusReport">statusReport</param>
        /// <param name="sender">sender</param>
        internal void GV_Accounting_Filter(StatusReport statusReport, object sender)
        {
            Button btn = (Button)sender;

            switch (btn.ID)
            {
                case "BtnSearchAccRepo":

                    statusReport.BtnResetAccRepo.Visible = (((statusReport.TxtAccComp.Text.Equals("")) || (statusReport.ddlAccStatus.SelectedValue.Equals("--- Please Select ---")) || (statusReport.ddlAccPendStag.SelectedValue.Equals("--- Please Select ---")) || (statusReport.ddlAccModule.SelectedValue.Equals("--- Please Select ---"))) || (!string.IsNullOrEmpty(statusReport.TxtAccComp.Text)) || (!string.IsNullOrEmpty(statusReport.ddlAccStatus.SelectedValue)) || (!string.IsNullOrEmpty(statusReport.ddlAccPendStag.SelectedValue)) || (!string.IsNullOrEmpty(statusReport.ddlAccModule.SelectedValue)) ? true : false);

                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                        superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                        superAdminProperties.CompanyName = string.Join(",", statusReport.TxtAccComp.Text.TrimStart(',').Split(',').Select(x => x.Trim().Insert(0, "") + "").ToArray());
                        superAdminProperties.Report_Status = (statusReport.ddlAccStatus.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccStatus.SelectedValue;
                        superAdminProperties.Pending_Stage = (statusReport.ddlAccPendStag.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccPendStag.SelectedValue;
                        superAdminProperties.Users_Name = (statusReport.ddlAccUser.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccUser.SelectedValue;
                        superAdminProperties.Module_Name = (statusReport.ddlAccModule.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccModule.SelectedValue;
                        superAdminProperties.Acc_From_Date = (string.IsNullOrEmpty(statusReport.datepickerFromDate.Value) || statusReport.datepickerFromDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : (statusReport.datepickerFromDate.Value);
                        superAdminProperties.Acc_To_Date = (string.IsNullOrEmpty(statusReport.datepickerToDate.Value) || statusReport.datepickerToDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : (statusReport.datepickerToDate.Value);
                        superAdminProperties.PAGE_INDEX = 1;
                        superAdminProperties.PAGE_SIZE = 10;
                        statusReport.BtnResetAccRepo.Visible = true;
                        superAdminProperties.PopulateControls = "StatusAccountingDetails";

                        superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                        ac_StatusReport.ds_StatusAccResult = (DataSet)superAdminCRUDProperties.ds_Result;

                        ac_StatusReport.n_GrdViewAccRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_COUNT"]));

                        DataTable dt_FilteredAccDatatable = ac_StatusReport.ds_StatusAccResult.Tables[0].DefaultView.ToTable();
                        if (dt_FilteredAccDatatable.Rows[0]["WORKFLOW_STATUS"].Equals("Locked"))
                        {
                            statusReport.GVACC.Columns[0].Visible = false;
                            statusReport.GVACC.DataSource = dt_FilteredAccDatatable;
                            statusReport.GVACC.DataBind();
                        }
                        else
                        {
                            statusReport.GVACC.Columns[0].Visible = true;
                            statusReport.GVACC.DataSource = dt_FilteredAccDatatable;
                            statusReport.GVACC.DataBind();
                        }
                        statusReport.GVACC.DataSource = dt_FilteredAccDatatable;
                        statusReport.GVACC.DataBind();
                        BindPagerForAccGridView(statusReport);
                        GetValuesFromDatabase(statusReport);
                        statusReport.hdnAccordionIndex.Value = "2";
                        statusReport.h3AddEdit.Style.Add("display", "none");
                        statusReport.h3ACCAddEdit.Style.Add("display", "block");
                        statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    }
                    break;
            }
        }
        #endregion

        #region LinkButton Apply Filter in GridView
        /// <summary>
        /// Apply Filter GridView Using LinkButton
        /// </summary>
        /// <param name="statusReport"></param>
        /// <param name="e"></param>
        internal void lnkVal_RowCommand(StatusReport statusReport, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "VALUATION")
            {
                statusReport.hdnValutaitonlnk.Value = "True";

                ac_StatusReport.s_Valutaitonlnk = "True";

                var str = e.CommandArgument.ToString();

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.CompanyName = str;
                    superAdminProperties.Report_Status = (statusReport.ddlValStatus.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlValStatus.SelectedValue;
                    superAdminProperties.Pending_Stage = (statusReport.ddlPendStag.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlPendStag.SelectedValue;
                    superAdminProperties.Users_Name = (statusReport.ddlValUsers.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlValUsers.SelectedValue;
                    superAdminProperties.Module_Name = (statusReport.ddlValModule.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlValModule.SelectedValue;
                    superAdminProperties.PAGE_INDEX = 1;
                    superAdminProperties.PAGE_SIZE = 10;
                    statusReport.BtnResetValRepo.Visible = true;
                    superAdminProperties.PopulateControls = "StatusValuationDetails";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_StatusReport.ds_StatusValResult = (DataSet)superAdminCRUDProperties.ds_Result;

                    ac_StatusReport.ds_StatusValCpyResult = ac_StatusReport.ds_StatusValResult;

                    ac_StatusReport.n_GridViewRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_COUNT"]));

                    DataTable dt_FilteredValDatatable = ac_StatusReport.ds_StatusValResult.Tables[0].DefaultView.ToTable();
                    statusReport.GVVal.DataSource = dt_FilteredValDatatable;
                    statusReport.GVVal.DataBind();
                    statusReport.hdnAccordionIndex.Value = "1";
                    statusReport.h3AddEdit.Style.Add("display", "block");
                    statusReport.h3ACCAddEdit.Style.Add("display", "none");
                    statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    BindPagerForValGridView(statusReport);
                    GetValuesFromDatabase(statusReport);
                }
            }

            if (e.CommandName == "ACCOUNTING")
            {
                statusReport.hdnAccountinglnk.Value = "True";

                ac_StatusReport.s_Accountinglnk = "True";

                var str = e.CommandArgument.ToString();

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.CompanyName = str;
                    superAdminProperties.Report_Status = (statusReport.ddlAccStatus.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccStatus.SelectedValue;
                    superAdminProperties.Pending_Stage = (statusReport.ddlAccPendStag.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccPendStag.SelectedValue;
                    superAdminProperties.Users_Name = (statusReport.ddlAccUser.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccUser.SelectedValue;
                    superAdminProperties.Module_Name = (statusReport.ddlAccModule.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccModule.SelectedValue;
                    superAdminProperties.Acc_From_Date = (string.IsNullOrEmpty(statusReport.datepickerFromDate.Value) || statusReport.datepickerFromDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : (statusReport.datepickerFromDate.Value);
                    superAdminProperties.Acc_To_Date = (string.IsNullOrEmpty(statusReport.datepickerToDate.Value) || statusReport.datepickerToDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : (statusReport.datepickerToDate.Value);
                    superAdminProperties.PAGE_INDEX = 1;
                    superAdminProperties.PAGE_SIZE = 10;
                    statusReport.BtnResetAccRepo.Visible = true;
                    superAdminProperties.PopulateControls = "StatusAccountingDetails";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_StatusReport.ds_StatusAccResult = (DataSet)superAdminCRUDProperties.ds_Result;

                    ac_StatusReport.ds_StatusAccCpyResult = ac_StatusReport.ds_StatusAccResult;

                    ac_StatusReport.n_GrdViewAccRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_COUNT"]));

                    DataTable dt_FilteredValDatatable = ac_StatusReport.ds_StatusAccResult.Tables[0].DefaultView.ToTable();
                    statusReport.GVACC.DataSource = dt_FilteredValDatatable;
                    statusReport.GVACC.DataBind();
                    statusReport.hdnAccordionIndex.Value = "2";
                    statusReport.h3ACCAddEdit.Style.Add("display", "block");
                    statusReport.h3AddEdit.Style.Add("display", "none");
                    statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    BindPagerForAccGridView(statusReport);
                    GetValuesFromDatabase(statusReport);
                }
            }
        }
        #endregion

        #region Bind GridView Valuation
        /// <summary>
        ///  This method is used to bind grid for ValuatinStatusReport 
        /// </summary>
        /// <param name="statusReport">statusReport</param>
        /// <returns> Data table of Status Report list </returns>
        internal void BindValStatusReportList(StatusReport statusReport)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.CompanyName = (string.IsNullOrEmpty(statusReport.TxtVALCompany.Text)) ? "" : statusReport.TxtVALCompany.Text;
                    superAdminProperties.Report_Status = (string.IsNullOrEmpty(statusReport.ddlValStatus.SelectedValue) || (statusReport.ddlValStatus.SelectedValue.Equals("--- Please Select ---"))) ? "" : statusReport.ddlValStatus.SelectedValue;
                    superAdminProperties.Pending_Stage = (string.IsNullOrEmpty(statusReport.ddlPendStag.SelectedValue) || (statusReport.ddlPendStag.SelectedValue.Equals("--- Please Select ---"))) ? "" : statusReport.ddlPendStag.SelectedValue;
                    superAdminProperties.Users_Name = (string.IsNullOrEmpty(statusReport.ddlValUsers.SelectedValue) || (statusReport.ddlValUsers.SelectedValue.Equals("--- Please Select ---"))) ? "" : statusReport.ddlValUsers.SelectedValue;
                    superAdminProperties.Module_Name = (string.IsNullOrEmpty(statusReport.ddlValModule.SelectedValue) || (statusReport.ddlValModule.SelectedValue.Equals("--- Please Select ---"))) ? "" : statusReport.ddlValModule.SelectedValue;
                    superAdminProperties.PAGE_INDEX = ac_StatusReport.n_ValPageIndex.Equals(0) ? 1 : ac_StatusReport.n_ValPageIndex;
                    superAdminProperties.PAGE_SIZE = ac_StatusReport.n_ValPageSize.Equals(0) ? 10 : ac_StatusReport.n_ValPageSize;
                    statusReport.BtnResetValRepo.Visible = true;
                    superAdminProperties.PopulateControls = "StatusValuationDetails";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_StatusReport.ds_StatusValResult = (DataSet)superAdminCRUDProperties.ds_Result;

                    ac_StatusReport.n_GridViewRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_COUNT"]));

                    statusReport.GVVal.DataSource = ac_StatusReport.ds_StatusValResult.Tables[0];
                    statusReport.GVVal.Columns[0].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[1].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVVal.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[5].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVVal.Columns[6].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVVal.DataBind();
                    BindPagerForValGridView(statusReport);
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Bind GridView Accounting
        /// <summary>
        ///  This method is used to bind grid for AccountingStatusReport
        /// </summary>
        /// <param name="statusReport">statusReport</param>
        /// <returns> Data table of Status Report list </returns>
        internal void BindAccStatusReportList(StatusReport statusReport)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.CompanyName = (string.IsNullOrEmpty(statusReport.TxtAccComp.Text)) ? "" : statusReport.TxtAccComp.Text;
                    superAdminProperties.Report_Status = (string.IsNullOrEmpty(statusReport.ddlAccStatus.SelectedValue)) || (statusReport.ddlAccStatus.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccStatus.SelectedValue;
                    superAdminProperties.Pending_Stage = (string.IsNullOrEmpty(statusReport.ddlAccPendStag.SelectedValue)) || (statusReport.ddlAccPendStag.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccPendStag.SelectedValue;
                    superAdminProperties.Users_Name = (string.IsNullOrEmpty(statusReport.ddlAccUser.SelectedValue)) || (statusReport.ddlAccUser.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccUser.SelectedValue;
                    superAdminProperties.Module_Name = (string.IsNullOrEmpty(statusReport.ddlAccModule.SelectedValue)) || (statusReport.ddlAccModule.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccModule.SelectedValue;
                    superAdminProperties.Acc_From_Date = (string.IsNullOrEmpty(statusReport.datepickerFromDate.Value) || statusReport.datepickerFromDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : (statusReport.datepickerFromDate.Value);
                    superAdminProperties.Acc_To_Date = (string.IsNullOrEmpty(statusReport.datepickerToDate.Value) || statusReport.datepickerToDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : (statusReport.datepickerToDate.Value);
                    superAdminProperties.PAGE_INDEX = ac_StatusReport.n_AccPageIndex.Equals(0) ? 1 : ac_StatusReport.n_AccPageIndex;
                    superAdminProperties.PAGE_SIZE = ac_StatusReport.n_AccPageSize.Equals(0) ? 10 : ac_StatusReport.n_AccPageSize;
                    statusReport.BtnResetAccRepo.Visible = false;
                    superAdminProperties.PopulateControls = "StatusAccountingDetails";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_StatusReport.ds_StatusAccResult = (DataSet)superAdminCRUDProperties.ds_Result;

                    ac_StatusReport.n_GrdViewAccRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_COUNT"]));

                    statusReport.GVACC.DataSource = ac_StatusReport.ds_StatusAccResult.Tables[0];
                    statusReport.GVACC.DataBind();
                    statusReport.GVACC.Columns[0].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[1].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVACC.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[5].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[6].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    BindPagerForAccGridView(statusReport);
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Modify values of RowDataBound
        /// <summary>
        /// This Method is used to modifiy the value of Griview Row field
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="statusReport">StatusReport</param>
        /// <param name="e">e</param>
        internal void grd_RowDataBound(object sender, StatusReport statusReport, GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.DataRow:
                        if ((e.Row.RowState == DataControlRowState.Normal) || (e.Row.RowState == (DataControlRowState.Alternate | DataControlRowState.Normal)))
                        {
                            using (LinkButton lnkbtnVal = (LinkButton)e.Row.FindControl("lnkVAL"))
                            {
                                if (lnkbtnVal.Visible = ((Convert.ToString(DataBinder.Eval(e.Row.DataItem, "VALUATION"))).Equals("-")))
                                {
                                    e.Row.Cells[2].Text = "-";
                                }
                                else
                                {
                                    lnkbtnVal.Visible = true;
                                    lnkbtnVal.Text = ((Convert.ToString(DataBinder.Eval(e.Row.DataItem, "VALUATION"))).Equals("0")) ? e.Row.Cells[2].Text = "0" : lnkbtnVal.Text;
                                }
                            }
                            using (LinkButton lnkbtnAcc = (LinkButton)e.Row.FindControl("lnkACC"))
                            {
                                if (lnkbtnAcc.Visible = ((Convert.ToString(DataBinder.Eval(e.Row.DataItem, "ACCOUNTING"))).Equals("-")))
                                {
                                    e.Row.Cells[3].Text = "-";
                                }
                                else
                                {
                                    lnkbtnAcc.Visible = true;
                                    lnkbtnAcc.Text = (((Convert.ToString(DataBinder.Eval(e.Row.DataItem, "ACCOUNTING"))).Equals("0"))) ? e.Row.Cells[3].Text = "0" : lnkbtnAcc.Text;
                                }
                            }
                            using (LinkButton lnkbtnDisc = (LinkButton)e.Row.FindControl("lnkDISC"))
                            {
                                if (lnkbtnDisc.Visible = ((Convert.ToString(DataBinder.Eval(e.Row.DataItem, "DISCLSOURE"))).Equals("-")))
                                {
                                    e.Row.Cells[4].Text = "-";
                                }
                                else
                                {
                                    lnkbtnDisc.Visible = true;
                                    lnkbtnDisc.Text = (((Convert.ToString(DataBinder.Eval(e.Row.DataItem, "DISCLSOURE"))).Equals("0"))) ? e.Row.Cells[4].Text = "0" : lnkbtnDisc.Text;
                                }
                            }
                        }
                        break;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region RowDataBound Of Status Valuation Report GridView
        /// <summary>
        /// This method is used to bind data to the grid at pageload
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">e</param>
        /// <param name="n_index">n_index</param>
        /// <param name="n_CompanyName">n_CompanyName</param>
        /// <param name="n_GroupNumber">n_GroupNumber</param>
        /// <param name="n_Status_of_Report">n_Status_of_Report</param>
        /// <param name="n_Pending_Stage">n_Pending_Stage</param>
        /// <param name="n_Associated_Users">n_Associated_Users</param>
        /// <param name="n_Associated_Modules">n_Associated_Modules</param>
        internal void GVVal_RowDataBound(object sender, GridViewRowEventArgs e, ref int n_index, ref int n_CompanyName, ref int n_GroupNumber, ref int n_Status_of_Report, ref int n_Pending_Stage, ref int n_Associated_Users, ref int n_Associated_Modules)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:

                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "COMPANY":
                                    n_CompanyName = n_index;
                                    break;

                                case "Group Number":
                                    n_GroupNumber = n_index;
                                    break;

                                case "Status of Report":
                                    n_Status_of_Report = n_index;
                                    break;

                                case "Pending Stage":
                                    n_Pending_Stage = n_index;
                                    break;

                                case "Associated Users":
                                    n_Associated_Users = n_index;
                                    break;

                                case "Associated Modules":
                                    n_Associated_Modules = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;
                    case DataControlRowType.DataRow:

                        using (CheckBox chkBoxVal = (CheckBox)e.Row.FindControl("GrdChk"))
                        {
                            if (((Convert.ToString(DataBinder.Eval(e.Row.DataItem, "WORKFLOW_STATUS"))).Equals("Step : 6  Locked")))
                            {
                                chkBoxVal.Enabled = false;
                            }
                            else
                            {
                                chkBoxVal.Visible = true;
                            }
                        }
                        e.Row.Cells[n_CompanyName].HorizontalAlign = e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
                        e.Row.Cells[n_GroupNumber].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Status_of_Report].HorizontalAlign = HorizontalAlign.Left;
                        e.Row.Cells[n_Pending_Stage].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Associated_Users].HorizontalAlign = HorizontalAlign.Left;
                        e.Row.Cells[n_Associated_Modules].HorizontalAlign = HorizontalAlign.Left;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region RowDataBound Of Status Accounting Report GridView
        /// <summary>
        /// This method is used to bind data to the grid at pageload
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">e</param>
        /// <param name="n_index">n_index</param>
        /// <param name="n_CompanyName">n_CompanyName</param>        
        /// <param name="n_Status_of_Report">n_Status_of_Report</param>
        /// <param name="n_Pending_Stage">n_Pending_Stage</param>
        /// <param name="n_Associated_Users">n_Associated_Users</param>
        /// <param name="n_Associated_Modules">n_Associated_Modules</param>
        internal void GVAcc_RowDataBound(object sender, GridViewRowEventArgs e, ref int n_index, ref int n_CompanyName, ref int n_Status_of_Report, ref int n_Pending_Stage, ref int n_Associated_Users, ref int n_Associated_Modules)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "COMPANY":
                                    n_CompanyName = n_index;
                                    break;

                                case "STATUS OF REPORT":
                                    n_Status_of_Report = n_index;
                                    break;

                                case "PENDING STAGE":
                                    n_Pending_Stage = n_index;
                                    break;

                                case "ASSOCIATED USERS":
                                    n_Associated_Users = n_index;
                                    break;

                                case "ASSOCIATED MODULES":
                                    n_Associated_Modules = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        {
                            using (CheckBox chkboxAcc = (CheckBox)e.Row.FindControl("GrdAccChk"))
                            {
                                if (((Convert.ToString(DataBinder.Eval(e.Row.DataItem, "WORKFLOW_STATUS"))).Equals("Locked")))
                                {
                                    chkboxAcc.Enabled = false;
                                }
                                else
                                {
                                    chkboxAcc.Visible = true;
                                }
                            }
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Display and Hide Buttons
        /// <summary>
        /// This Method is used to Display or Hide Controls and set Accordian index
        /// </summary>
        /// <param name="statusReport">StatusReport</param>
        /// <param name="sender">Sender</param>
        internal void DisplayContents(StatusReport statusReport, object sender)
        {
            statusReport.btnResetStatus.Visible = false;
            statusReport.BtnResetValRepo.Visible = false;
            statusReport.BtnResetAccRepo.Visible = false;
            statusReport.hdnAccordionIndex.Value = "0";

            Button Btn = (Button)sender;
            try
            {
                switch (Btn.ID)
                {
                    case "btnResetStatus":
                        statusReport.ddlStatusRepo.SelectedValue = "--- Please Select ---";
                        statusReport.txtSRCompanyName.Text = string.Empty;
                        superAdminProperties.PAGE_INDEX = 1;
                        superAdminProperties.PAGE_SIZE = 10;
                        statusReport.lblURPageName.Text = Convert.ToString((ac_StatusReport.dt_StatusReportUI.Select("LabelID='lblURPageName'"))[0]["LabelName"]);
                        GetValuesFromDatabase(statusReport);
                        ac_StatusReport.s_Valutaitonlnk = string.Empty;
                        ac_StatusReport.s_Accountinglnk = string.Empty;
                        break;

                    case "BtnResetValRepo":
                        GetValuesFromDatabase(statusReport);
                        ResetGrid(statusReport);
                        break;

                    case "BtnResetAccRepo":
                        GetValuesFromDatabase(statusReport);
                        ResetGrid(statusReport);
                        ResetAccountingGrid(statusReport);
                        break;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Select All Checkboxes
        /// <summary>
        ///  Select all checkbox of GridView
        /// </summary>
        /// <param name="statusReport"></param>
        internal void ChkedChkBox(StatusReport statusReport)
        {
            CheckBox chckheader = (CheckBox)statusReport.GVVal.HeaderRow.FindControl("ChkValAll");

            foreach (GridViewRow row in statusReport.GVVal.Rows)
            {
                var CheckBoxchckrw = (CheckBox)row.FindControl("GrdChk");

                if (chckheader.Checked == true && CheckBoxchckrw.Enabled)
                {
                    CheckBoxchckrw.Checked = true;
                }
                else
                {
                    CheckBoxchckrw.Checked = false;
                }
            }
            GetValuesFromDatabase(statusReport);
            statusReport.hdnAccordionIndex.Value = "1";
            statusReport.h3AddEdit.Style.Add("display", "block");
            statusReport.h3ACCAddEdit.Style.Add("display", "none");
            statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
        }

        /// <summary>
        ///  Select all checkbox of GridView
        /// </summary>
        /// <param name="statusReport"></param>
        internal void ChkedAccChkBox(StatusReport statusReport)
        {
            CheckBox chckheader = (CheckBox)statusReport.GVACC.HeaderRow.FindControl("ChkAccAll");

            foreach (GridViewRow row in statusReport.GVACC.Rows)
            {
                var CheckBoxchckrw = (CheckBox)row.FindControl("GrdAccChk");

                if (chckheader.Checked == true && CheckBoxchckrw.Enabled)
                {
                    CheckBoxchckrw.Checked = true;
                }
                else
                {
                    CheckBoxchckrw.Checked = false;
                }
            }
            GetValuesFromDatabase(statusReport);
            statusReport.hdnAccordionIndex.Value = "2";
            statusReport.h3ACCAddEdit.Style.Add("display", "block");
            statusReport.h3AddEdit.Style.Add("display", "none");
            statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
        }
        #endregion

        #region Custom Pagination
        /// <summary>
        /// Bind Pager For GridView
        /// </summary>
        /// <param name="statusReport"></param>
        internal void BindPagerForGridView(StatusReport statusReport)
        {
            PopulatePagerForGridView(statusReport, ac_StatusReport.n_GrdRecordsCount, 1, 1);
        }

        /// <summary>
        /// Bind Pager For GridView
        /// </summary>
        /// <param name="statusReport"></param>
        internal void BindPagerForValGridView(StatusReport statusReport)
        {
            PopulatePagerForValGridView(statusReport, ac_StatusReport.n_GridViewRecordsCount, 1, 1);
        }

        /// <summary>
        /// Bind Pager For GridView
        /// </summary>
        /// <param name="statusReport"></param>
        internal void BindPagerForAccGridView(StatusReport statusReport)
        {
            PopulatePagerForAccGridView(statusReport, ac_StatusReport.n_GrdViewAccRecordsCount, 1, 1);
        }

        /// <summary>
        /// This method is used to add pager for gridview
        /// </summary>
        /// <param name="statusReport">Page object</param>
        /// <param name="recordCounT">recordCounT</param>
        /// <param name="currentPage">CurrentPage</param>
        /// <param name="n_pageIndex">n_pageIndex</param>
        private void PopulatePagerForGridView(StatusReport statusReport, int recordCounT, int currentPage, int n_pageIndex)
        {
            if (!recordCounT.Equals(0))
            {
                double dblPageCount = (double)((decimal)recordCounT / decimal.Parse("10"));
                int pageCount = (int)Math.Ceiling(dblPageCount);
                int n_TempCurrentPage = currentPage.Equals(1) ? 1 : Convert.ToInt32(Convert.ToInt32(currentPage / 10) + 9);

                int n_pageCount = 1, n_loopCount = 1;

                List<ListItem> pages = new List<ListItem>();
                if (pageCount > 0)
                {
                    for (int i = 1; i <= pageCount; i++)
                    {
                        pages.Add(new ListItem(i.ToString(), i.ToString() + "|" + n_pageCount, i != currentPage));

                        if (n_loopCount.Equals(10))
                        {
                            n_loopCount = 1;
                            n_pageCount = n_pageCount + 1;
                        }
                        else
                        {
                            n_loopCount++;
                        }
                    }
                }

                var v_Get10Records = pages.Skip((n_pageIndex - 1) * 10).Take(10).ToList();

                var NextFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 1;
                var NextLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 10;

                var PreviousFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 10;
                var PreviousLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 1;

                v_Get10Records.Insert(0, new ListItem("First", "1", currentPage > 1));

                if (currentPage > 10)
                {
                    v_Get10Records.Insert(1, new ListItem("....", PreviousFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1) + "-" + PreviousLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1), currentPage > 10));
                }

                if (pageCount > 10)
                {
                    v_Get10Records.Add(new ListItem("....", NextFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1) + "-" + NextLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1), currentPage < pageCount));
                }

                v_Get10Records.Add(new ListItem("Last", pageCount.ToString() + "|" + n_pageCount, currentPage < pageCount));

                statusReport.rptpager.Visible = true;
                statusReport.rptpager.DataSource = v_Get10Records;
                statusReport.rptpager.DataBind();
            }
            else
            {
                statusReport.rptpager.Visible = false;
            }
        }

        /// <summary>
        /// This method is used to add pager for gridview
        /// </summary>
        /// <param name="statusReport">Page object</param>
        /// <param name="recordCount">RecordCount</param>
        /// <param name="currentPage">CurrentPage</param>
        /// <param name="n_pageIndex">n_pageIndex</param>
        private void PopulatePagerForValGridView(StatusReport statusReport, int recordCount, int currentPage, int n_pageIndex)
        {
            if (!recordCount.Equals(0))
            {
                double dblPageCount = (double)((decimal)recordCount / decimal.Parse("10"));
                int pageCount = (int)Math.Ceiling(dblPageCount);
                int n_TempCurrentPage = currentPage.Equals(1) ? 1 : Convert.ToInt32(Convert.ToInt32(currentPage / 10) + 9);

                int n_pageCount = 1, n_loopCount = 1;

                List<ListItem> pages = new List<ListItem>();
                if (pageCount > 0)
                {
                    for (int i = 1; i <= pageCount; i++)
                    {
                        pages.Add(new ListItem(i.ToString(), i.ToString() + "|" + n_pageCount, i != currentPage));

                        if (n_loopCount.Equals(10))
                        {
                            n_loopCount = 1;
                            n_pageCount = n_pageCount + 1;
                        }
                        else
                        {
                            n_loopCount++;
                        }
                    }
                }

                //Paging logic goes here  
                var v_Get10Records = pages.Skip((n_pageIndex - 1) * 10).Take(10).ToList();

                var NextFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 1;
                var NextLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 10;

                var PreviousFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 10;
                var PreviousLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 1;

                v_Get10Records.Insert(0, new ListItem("First", "1", currentPage > 1));

                if (currentPage > 10)
                {
                    v_Get10Records.Insert(1, new ListItem("....", PreviousFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1) + "-" + PreviousLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1), currentPage > 10));
                }

                if (pageCount > 10)
                {
                    v_Get10Records.Add(new ListItem("....", NextFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1) + "-" + NextLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1), currentPage < pageCount));
                }

                v_Get10Records.Add(new ListItem("Last", pageCount.ToString() + "|" + n_pageCount, currentPage < pageCount));

                statusReport.rptValPager.Visible = true;
                statusReport.rptValPager.DataSource = v_Get10Records;
                statusReport.rptValPager.DataBind();
            }
            else
            {
                statusReport.rptValPager.Visible = false;
            }
        }

        /// <summary>
        /// This method is used to add pager for gridview
        /// </summary>
        /// <param name="statusReport">Page object</param>
        /// <param name="recordCount">RecordCount</param>
        /// <param name="currentPage">CurrentPage</param>
        /// <param name="n_pageIndex">n_pageIndex</param>
        private void PopulatePagerForAccGridView(StatusReport statusReport, int recordCount, int currentPage, int n_pageIndex)
        {
            if (!recordCount.Equals(0))
            {
                double dblPageCount = (double)((decimal)recordCount / decimal.Parse("10"));
                int pageCount = (int)Math.Ceiling(dblPageCount);
                int n_TempCurrentPage = currentPage.Equals(1) ? 1 : Convert.ToInt32(Convert.ToInt32(currentPage / 10) + 9);

                int n_pageCount = 1, n_loopCount = 1;

                List<ListItem> pages = new List<ListItem>();
                if (pageCount > 0)
                {
                    for (int i = 1; i <= pageCount; i++)
                    {
                        pages.Add(new ListItem(i.ToString(), i.ToString() + "|" + n_pageCount, i != currentPage));

                        if (n_loopCount.Equals(10))
                        {
                            n_loopCount = 1;
                            n_pageCount = n_pageCount + 1;
                        }
                        else
                        {
                            n_loopCount++;
                        }
                    }
                }

                //Paging logic goes here  
                var v_Get10Records = pages.Skip((n_pageIndex - 1) * 10).Take(10).ToList();

                var NextFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 1;
                var NextLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 10;

                var PreviousFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 10;
                var PreviousLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 1;

                v_Get10Records.Insert(0, new ListItem("First", "1", currentPage > 1));

                if (currentPage > 10)
                {
                    v_Get10Records.Insert(1, new ListItem("....", PreviousFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1) + "-" + PreviousLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1), currentPage > 10));
                }

                if (pageCount > 10)
                {
                    v_Get10Records.Add(new ListItem("....", NextFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1) + "-" + NextLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1), currentPage < pageCount));
                }

                v_Get10Records.Add(new ListItem("Last", pageCount.ToString() + "|" + n_pageCount, currentPage < pageCount));

                statusReport.rptAccPager.Visible = true;
                statusReport.rptAccPager.DataSource = v_Get10Records;
                statusReport.rptAccPager.DataBind();
            }
            else
            {
                statusReport.rptAccPager.Visible = false;
            }
        }

        #endregion

        #region Status Report Gridview Page Index Change Event
        /// <summary>
        /// This method is used to move to next page
        /// </summary>
        /// <param name="statusReport">statusReport</param>
        /// <param name="pageIndex">pageIndex</param>
        internal void Page_IndexChangeing(StatusReport statusReport, string pageIndex)
        {
            ac_StatusReport.s_status = pageIndex.Split('-').Length > 1 ? "Selected" : string.Empty;
            ac_StatusReport.n_PageIndex = Convert.ToInt32(pageIndex.Split('-').First().Split('|').First());
            ac_StatusReport.n_PageSize = 10;
            GetPaginationValues(statusReport);
            statusReport.h3AddEdit.Style.Add("display", "none");
            statusReport.h3ACCAddEdit.Style.Add("display", "none");
            PopulatePagerForGridView(statusReport, ac_StatusReport.n_GrdRecordsCount, Convert.ToInt32(pageIndex.Split('-').First().Split('|').First()), Convert.ToInt32(pageIndex.Split('-').First().Split('|').Last()));
        }
        #endregion

        #region Status valuation Report Gridview Page Index Change Event
        /// <summary>
        /// This method is used to move to next page
        /// </summary>
        /// <param name="statusReport">statusReport page object</param>
        /// <param name="pageIndex">PageIndex</param>
        internal void PageVal_IndexChangeing(StatusReport statusReport, string pageIndex)
        {
            ac_StatusReport.s_status = pageIndex.Split('-').Length > 1 ? "Selected" : string.Empty;
            ac_StatusReport.n_ValPageIndex = Convert.ToInt32(pageIndex.Split('-').First().Split('|').First());
            ac_StatusReport.n_ValPageSize = 10;
            BindValStatusReportList(statusReport);
            GetValuesFromDatabase(statusReport);
            ChkedChkBox(statusReport);
            statusReport.hdnAccordionIndex.Value = "1";
            statusReport.h3AddEdit.Style.Add("display", "block");
            statusReport.h3ACCAddEdit.Style.Add("display", "none");
            statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
            PopulatePagerForValGridView(statusReport, ac_StatusReport.n_GridViewRecordsCount, Convert.ToInt32(pageIndex.Split('-').First().Split('|').First()), Convert.ToInt32(pageIndex.Split('-').First().Split('|').Last()));
        }
        #endregion

        #region Status Accounting Report Gridview Page Index Change Event
        /// <summary>
        /// This method is used to move to next page
        /// </summary>
        /// <param name="statusReport">statusReport page object</param>
        /// <param name="pageIndex">PageIndex</param>
        internal void PageAcc_IndexChangeing(StatusReport statusReport, string pageIndex)
        {
            ac_StatusReport.s_status = pageIndex.Split('-').Length > 1 ? "Selected" : string.Empty;
            ac_StatusReport.n_AccPageIndex = Convert.ToInt32(pageIndex.Split('-').First().Split('|').First());
            ac_StatusReport.n_AccPageSize = 10;
            BindAccStatusReportList(statusReport);
            GetValuesFromDatabase(statusReport);
            ChkedAccChkBox(statusReport);
            statusReport.hdnAccordionIndex.Value = "2";
            statusReport.h3ACCAddEdit.Style.Add("display", "block");
            statusReport.h3AddEdit.Style.Add("display", "none");
            statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
            PopulatePagerForAccGridView(statusReport, ac_StatusReport.n_GrdViewAccRecordsCount, Convert.ToInt32(pageIndex.Split('-').First().Split('|').First()), Convert.ToInt32(pageIndex.Split('-').First().Split('|').Last()));
        }
        #endregion

        #region  Reset Valuation GridView
        /// <summary>
        /// Reset Valuation Gridview 
        /// </summary>
        /// <param name="statusReport"></param>
        internal void ResetGrid(StatusReport statusReport)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.CompanyName = string.Empty;
                    superAdminProperties.Report_Status = string.Empty;
                    superAdminProperties.Pending_Stage = string.Empty;
                    superAdminProperties.Users_Name = string.Empty;
                    superAdminProperties.Module_Name = string.Empty;
                    superAdminProperties.PAGE_INDEX = 1;
                    superAdminProperties.PAGE_SIZE = 10;
                    statusReport.BtnResetValRepo.Visible = false;
                    superAdminProperties.PopulateControls = "StatusValuationDetails";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_StatusReport.ds_StatusValResult = (DataSet)superAdminCRUDProperties.ds_Result;

                    ac_StatusReport.n_GridViewRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_COUNT"]));

                    statusReport.GVVal.DataSource = ac_StatusReport.ds_StatusValResult.Tables[0];
                    statusReport.GVVal.Columns[0].Visible = true;
                    statusReport.GVVal.Columns[0].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[1].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVVal.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVVal.Columns[5].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVVal.Columns[6].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVVal.DataBind();
                    BindPagerForValGridView(statusReport);
                    statusReport.ddlValStatus.SelectedIndex = 0;
                    statusReport.ddlPendStag.SelectedIndex = 0;
                    statusReport.ddlValModule.SelectedIndex = 0;
                    statusReport.ddlValUsers.SelectedIndex = 0;
                    statusReport.TxtVALCompany.Text = string.Empty;
                    statusReport.h3AddEdit.Style.Add("display", "none");
                    statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    ac_StatusReport.s_Valutaitonlnk = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region  Reset Accounting GridView
        /// <summary>
        /// Reset Accounting Gridview 
        /// </summary>
        /// <param name="statusReport"></param>
        internal void ResetAccountingGrid(StatusReport statusReport)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.CompanyName = string.Empty;
                    superAdminProperties.Report_Status = string.Empty;
                    superAdminProperties.Pending_Stage = string.Empty;
                    superAdminProperties.Users_Name = string.Empty;
                    superAdminProperties.Module_Name = string.Empty;
                    superAdminProperties.Acc_From_Date = string.Empty;
                    superAdminProperties.Acc_To_Date = string.Empty;
                    superAdminProperties.PAGE_INDEX = 1;
                    superAdminProperties.PAGE_SIZE = 10;
                    statusReport.BtnResetValRepo.Visible = false;
                    superAdminProperties.PopulateControls = "StatusAccountingDetails";

                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                    ac_StatusReport.ds_StatusAccResult = (DataSet)superAdminCRUDProperties.ds_Result;

                    ac_StatusReport.n_GrdViewAccRecordsCount = Convert.ToInt16(Convert.ToString(superAdminCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_COUNT"]));

                    statusReport.GVACC.DataSource = ac_StatusReport.ds_StatusAccResult.Tables[0];
                    statusReport.GVACC.DataBind();
                    statusReport.GVACC.Columns[0].Visible = true;
                    statusReport.GVACC.Columns[0].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[1].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    statusReport.GVACC.Columns[2].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[3].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[4].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[5].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    statusReport.GVACC.Columns[6].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    BindPagerForAccGridView(statusReport);
                    statusReport.ddlAccStatus.SelectedIndex = 0;
                    statusReport.ddlAccPendStag.SelectedIndex = 0;
                    statusReport.ddlAccModule.SelectedIndex = 0;
                    statusReport.ddlAccModule.SelectedIndex = 0;
                    statusReport.ddlAccUser.SelectedIndex = 0;
                    statusReport.TxtAccComp.Text = string.Empty;
                    statusReport.h3ACCAddEdit.Style.Add("display", "none");
                    statusReport.h3AddEdit.Style.Add("display", "none");
                    statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    ac_StatusReport.s_Accountinglnk = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Back Button of Valuation and Accounting
        /// <summary>
        ///  Back Buttton event of valulation
        /// </summary>
        /// <param name="statusReport"></param>
        internal void Btn_ValBack(StatusReport statusReport)
        {
            GetValuesFromDatabase(statusReport);
            statusReport.h3AddEdit.Style.Add("display", "none");
            statusReport.h3SearchPanel.Style.Add("display", "block");
            statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
        }

        /// <summary>
        ///  Back Buttton event of Accounting
        /// </summary>
        /// <param name="statusReport"></param>
        internal void Btn_AccBack(StatusReport statusReport)
        {
            GetValuesFromDatabase(statusReport);
            statusReport.h3AddEdit.Style.Add("display", "none");
            statusReport.h3SearchPanel.Style.Add("display", "block");
            statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "none";
        }
        #endregion

        #region SSRS REPORT
        /// <summary>
        /// This method is used to Encrypt query string that has to pass on to report page  for report view.
        /// </summary>
        /// <param name="statusReport">object of statusReport page</param>
        internal void EncryptData(StatusReport statusReport)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                statusReport.hdnQueryStringParams.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=19").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                statusReport.hdnQueryStringValParams.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=20").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                statusReport.hdnQueryStringAccParams.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=21").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                statusReport.hdnQueryStringParams.Dispose();
                statusReport.hdnQueryStringValParams.Dispose();
                statusReport.hdnQueryStringAccParams.Dispose();
            }
        }
        #endregion

        #region Send Mails to Diffrent Users
        /// <summary>
        /// Send Mails to Accounting and Valuation Users
        /// </summary>
        /// <param name="statusReport">statusReport</param>
        /// <param name="sender">sender</param>
        internal void SendMail(StatusReport statusReport, object sender)
        {
            string s_ChkBoxName = string.Empty;            

            Button btnSendMail = (Button)sender;

            List<string> email_list = new List<string>(); 

            try
            {
                switch (btnSendMail.ID)
                {
                    case "BtnValEmail":

                        s_IsMailSent = "ValuationMail";

                        using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                        {
                            superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                            superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                            superAdminProperties.CompanyName = string.Join(",", statusReport.TxtVALCompany.Text.TrimStart(',').Split(',').Select(x => x.Trim().Insert(0, "") + "").ToArray());
                            superAdminProperties.Report_Status = (statusReport.ddlValStatus.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlValStatus.SelectedValue;
                            superAdminProperties.Pending_Stage = (statusReport.ddlPendStag.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlPendStag.SelectedValue;
                            superAdminProperties.Users_Name = (statusReport.ddlValUsers.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlValUsers.SelectedValue;
                            superAdminProperties.Module_Name = (statusReport.ddlValModule.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlValModule.SelectedValue;
                            superAdminProperties.PAGE_INDEX = ac_StatusReport.n_ValPageIndex.Equals(0) ? 1 : ac_StatusReport.n_ValPageIndex;
                            superAdminProperties.PAGE_SIZE = ac_StatusReport.n_ValPageSize.Equals(0) ? 10 : ac_StatusReport.n_ValPageSize;
                            statusReport.BtnResetValRepo.Visible = true;
                            superAdminProperties.PopulateControls = "StatusValuationDetails";

                            superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                            ac_StatusReport.ds_StatusValResult = (DataSet)superAdminCRUDProperties.ds_Result;

                            DataTable dt_ValFilteredData = ac_StatusReport.s_Valutaitonlnk.Equals("True") ? ac_StatusReport.ds_StatusValCpyResult.Tables[0] : ac_StatusReport.ds_StatusValResult.Tables[0];

                            foreach (GridViewRow gvrow in statusReport.GVVal.Rows)
                            {
                                CheckBox checkbokx = (CheckBox)gvrow.FindControl("GrdChk");

                                HiddenField hiddenfield = (HiddenField)gvrow.FindControl("hdnChkVal");

                                if (checkbokx != null && checkbokx.Checked)
                                {
                                    s_ChkBoxName = s_ChkBoxName + "," + hiddenfield.Value;
                                }
                            }

                            dt_ValFilteredData.DefaultView.RowFilter = "SR_NO IN (" + s_ChkBoxName.TrimStart(',') + ")";
                            dt_ValFilteredData = dt_ValFilteredData.DefaultView.ToTable();

                            foreach (DataRow dr in dt_ValFilteredData.Rows)
                            {
                                email_list.Add(dr["EMAIL_ID"].ToString());
                            }

                            email_list = email_list.SelectMany(i => i.Split(',').Select(v => v.Trim())).Distinct().ToList();

                            foreach (var emails in email_list)
                            {
                                DataTable dt_FilteredData = dt_ValFilteredData.Select("[EMAIL_ID] like '%" + emails + "%'").CopyToDataTable();

                                StringBuilder s_TextBody = new StringBuilder("<table style='width: 100%; border: 1px solid #ddd; font-family: Calibri; font-size: 14px; line-height: 20px;'><tr border: 1px solid #ddd ; bgcolor='#D5DBDB'><td align='center'><b>Company</b></td> <td align='center'> <b>Group ID</b></td> <td align='center'> <b>Workflow Status</b> </td> <td align='center'> <b>Pending Stage</b> </td> <td align='center'> <b>Module Associate</b> </td></tr>");

                                foreach (DataRow perItem in dt_FilteredData.Rows)
                                {
                                    s_TextBody.Append("<tr><td align='left'>" + perItem["COMPANY"] + "</td><td align='center'> " + perItem["GROUP_ID"] + "</td><td align='left'> " + perItem["WORKFLOW_STATUS"] + "</td><td align='center'> " + perItem["PENDING_STAGE"] + "</td><td align='center'> " + perItem["MODULE_ASSOCIATE"] + "</td></tr>");
                                }
                                s_TextBody.Append("</table>");

                                SendMail(emails, userSessionInfo.ACC_CompanyName, "Valuation", Convert.ToString(s_TextBody), s_IsMailSent);
                            }

                            statusReport.ctrnlSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            statusReport.ctrnlSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("SRVMailSent");
                            statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            statusReport.h3AddEdit.Style.Add("display", "none");
                            statusReport.h3AddEdit.Style.Add("display", "block");
                        }
                        break;

                    case "BtnAccEmail":

                        s_IsMailSent = "AccountingMail";

                        using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                        {
                            superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            superAdminProperties.PageName = CommonConstantModel.s_StatusReport;
                            superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                            superAdminProperties.CompanyName = string.Join(",", statusReport.TxtVALCompany.Text.TrimStart(',').Split(',').Select(x => x.Trim().Insert(0, "") + "").ToArray());
                            superAdminProperties.Report_Status = (statusReport.ddlAccStatus.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccStatus.SelectedValue;
                            superAdminProperties.Pending_Stage = (statusReport.ddlAccPendStag.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccPendStag.SelectedValue;
                            superAdminProperties.Users_Name = (statusReport.ddlAccUser.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccUser.SelectedValue;
                            superAdminProperties.Module_Name = (statusReport.ddlAccModule.SelectedValue.Equals("--- Please Select ---")) ? "" : statusReport.ddlAccModule.SelectedValue;
                            superAdminProperties.Acc_From_Date = (string.IsNullOrEmpty(statusReport.datepickerFromDate.Value) || statusReport.datepickerFromDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : (statusReport.datepickerFromDate.Value);
                            superAdminProperties.Acc_To_Date = (string.IsNullOrEmpty(statusReport.datepickerToDate.Value) || statusReport.datepickerToDate.Value.Equals("dd/mmm/yyyy")) ? string.Empty : (statusReport.datepickerToDate.Value);
                            superAdminProperties.PAGE_INDEX = ac_StatusReport.n_AccPageIndex.Equals(0) ? 1 : ac_StatusReport.n_AccPageIndex;
                            superAdminProperties.PAGE_SIZE = ac_StatusReport.n_AccPageSize.Equals(0) ? 10 : ac_StatusReport.n_AccPageSize;
                            statusReport.BtnResetAccRepo.Visible = true;
                            superAdminProperties.PopulateControls = "StatusAccountingDetails";

                            superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                            ac_StatusReport.ds_StatusAccResult = (DataSet)superAdminCRUDProperties.ds_Result;

                            DataTable dt_FilteredData = ac_StatusReport.s_Accountinglnk.Equals("True") ? ac_StatusReport.ds_StatusAccCpyResult.Tables[0] : ac_StatusReport.ds_StatusAccResult.Tables[2];

                            foreach (GridViewRow gvrow in statusReport.GVACC.Rows)
                            {
                                CheckBox checkbox = (CheckBox)gvrow.FindControl("GrdAccChk");

                                HiddenField hiddenfield = (HiddenField)gvrow.FindControl("hdnChkAcc");

                                if (checkbox != null & checkbox.Checked)
                                {
                                    s_ChkBoxName = s_ChkBoxName + "," + hiddenfield.Value;
                                }
                            }

                            dt_FilteredData.DefaultView.RowFilter = "SR_NO IN (" + s_ChkBoxName.TrimStart(',') + ")";
                            dt_FilteredData = dt_FilteredData.DefaultView.ToTable();

                            foreach (DataRow dr in dt_FilteredData.Rows)
                            {
                                email_list.Add(dr["EMAIL_ID"].ToString());
                            }

                            email_list = email_list.SelectMany(i => i.Split(',').Select(v => v.Trim())).Distinct().ToList();

                            foreach (var emails in email_list)
                            {
                                DataTable dt_AccFilteredData = dt_FilteredData.Select("[EMAIL_ID] like '%" + emails + "%'").CopyToDataTable();

                                StringBuilder s_TextBody = new StringBuilder("<table style='width: 100%; border: 1px solid #ddd; font-family: Calibri; font-size: 14px; line-height: 20px;'><tr border: 1px solid #ddd ; bgcolor='#D5DBDB'><td align='center'><b>Company</b></td> <td align='center'> <b>Group ID</b> </td> <td align='center'> <b>Accounting Report Date</b> </td> <td align='center'> <b>Workflow Status</b> </td> <td align='center'> <b>Pending Stage</b> </td> <td align='center'> <b>Module Associate</b> </td></tr>");

                                foreach (DataRow perItem in dt_AccFilteredData.Rows)
                                {
                                    s_TextBody.Append("<tr><td align='left'>" + perItem["COMPANY"] + "</td><td align='center'> " + perItem["GROUP_ID"] + "</td><td align='center'>" + perItem["ACCOUNTING_REPORT"] + "</td><td align='left'> " + perItem["WORKFLOW_STATUS"] + "</td><td align='center'> " + perItem["PENDING_STAGE"] + "</td><td align='center'> " + perItem["MODULE_ASSOCIATE"] + "</td></tr>");
                                }
                                s_TextBody.Append("</table>");

                                SendMail(emails, userSessionInfo.ACC_CompanyName, "Accounting", Convert.ToString(s_TextBody), s_IsMailSent);
                            }

                            statusReport.ctrnlSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            statusReport.ctrnlSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("SRVMailSent");
                            statusReport.ctrnlSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            statusReport.h3ACCAddEdit.Style.Add("Display", "block");
                        }
                        break;
                }
            }

            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        ///  Mail Template
        /// </summary>
        /// <param name="s_EmailModule">s_EmailModule</param>
        /// <param name="s_Company">s_Company</param>
        /// <param name="s_Module">s_Module</param>
        /// <param name="s_TextBody">s_TextBody</param>
        /// <param name="s_MailSent">s_MailSent</param>
        private void SendMail(string s_EmailModule, string s_Company, string s_Module, string s_TextBody, string s_MailSent)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                string s_MailBody = MailBody(s_MailSent.Equals("ValuationMail") ? "StatusReport" : "StatusAccountingReport", s_Company, s_Module, s_TextBody);
                emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                emailProperties.b_IsBodyHtml = true;
                emailProperties.s_MailBody = s_MailBody;
                emailProperties.s_MailTo = s_EmailModule;
                emailProperties.s_MailCC = "";
                emailProperties.s_MailBCC = "";
                emailProperties.s_MailSubject = Regex.Match(s_MailBody.ToString(), @"<Title>\s*(.+?)\s*</Title>").Value.
                                                Replace("\r", "").Replace("<Title>", "").Replace("</Title>", "").Replace("\n", "").Replace("\t", "");
                genericServiceClient.SaveSendMail(emailProperties);
            }
        }

        /// <summary>
        /// This method is used to replace parameters from template
        /// </summary>
        /// <param name="s_TemplateName">s_TemplateName</param>
        /// <param name="s_CompanyName">s_CompanyName</param>
        /// <param name="s_ModuleName">s_ModuleName</param>
        /// <param name="c_Table">c_Table</param>
        /// <returns></returns>
        private string MailBody(string s_TemplateName, string s_CompanyName, string s_ModuleName, string c_Table)
        {
            StringBuilder s_MailBody = new StringBuilder();
            s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\" + s_TemplateName + ".html"));
            s_MailBody.Replace("@Company_Name", s_CompanyName);
            s_MailBody.Replace("@Report_Name", s_ModuleName);
            s_MailBody.Replace("@Company_Table", c_Table);
            return s_MailBody.ToString();
        }
        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~StatusReportModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}