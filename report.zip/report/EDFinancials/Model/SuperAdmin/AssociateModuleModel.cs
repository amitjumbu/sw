﻿using EDFinancials.Model.Generic;
using EDFinancials.View.SuperAdmin;
using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.SuperAdmin
{
    /// <summary>
    /// Model File for Associate Module Page.
    /// </summary>
    public class AssociateModuleModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AssociateModuleModel()
        {
            if (ac_ManageModule == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageModule);
                ac_ManageModule = (CommonModel.AC_ManageModule)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageModule];
            }
        }

        /// <summary>
        /// This Method is used to fetch messages from L10N xml via superadmin WCF service.
        /// </summary>
        /// <param name="MessegeId"></param>
        /// <returns>string as the message</returns>
        public string SAP_L10N(string MessegeId)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                try
                {
                    return superAdminServiceClient.LoadL10N(MessegeId);

                }
                catch
                {
                    throw;
                }
            }

        }

        /// <summary>
        /// This method is used to load all label text from L10N_UI via wcf service
        /// </summary>
        /// <param name="associateModule"></param>
        public void BindPageUI(AssociateModule associateModule)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    using (DataTable dt_associateModuleUI = superAdminServiceClient.LoadL10N_UI(CommonConstantModel.s_AssociateModule))
                    {
                        if ((dt_associateModuleUI != null) && (dt_associateModuleUI.Rows.Count > 0))
                        {
                            associateModule.lblAMPagehead.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMPagehead'"))[0]["LabelName"]);
                            associateModule.lblAMAccordMngeHead.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMAccordMngeHead'"))[0]["LabelName"]);
                            associateModule.lblAMAccordEditHead.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMAccordEditHead'"))[0]["LabelName"]);
                            associateModule.lblAMName.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMName'"))[0]["LabelName"]);
                            associateModule.lblAMName.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMName'"))[0]["LabelToolTip"]);

                            associateModule.lblAMSName.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMSName'"))[0]["LabelName"]);
                            associateModule.lblAMSName.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMSName'"))[0]["LabelToolTip"]);

                            associateModule.lblAMStatus.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMStatus'"))[0]["LabelName"]);
                            associateModule.lblAMStatus.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMStatus'"))[0]["LabelToolTip"]);

                            associateModule.lblAMMMName.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMMMName'"))[0]["LabelName"]);
                            associateModule.lblAMMMName.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMMMName'"))[0]["LabelToolTip"]);

                            associateModule.lblAMSMName.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMSMName'"))[0]["LabelName"]);
                            associateModule.lblAMSMName.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMSMName'"))[0]["LabelToolTip"]);

                            associateModule.lblAMStatusEdit.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMStatusEdit'"))[0]["LabelName"]);
                            associateModule.lblAMStatusEdit.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMStatusEdit'"))[0]["LabelToolTip"]);

                            associateModule.BtnAMGridfilter.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='BtnAMGridfilter'"))[0]["LabelName"]);
                            associateModule.BtnAMGridfilter.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='BtnAMGridfilter'"))[0]["LabelToolTip"]);

                            associateModule.btnAMClearFilter.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='btnAMClearFilter'"))[0]["LabelName"]);
                            associateModule.btnAMClearFilter.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='btnAMClearFilter'"))[0]["LabelToolTip"]);

                            associateModule.btnAMCreateNew.Value = Convert.ToString((dt_associateModuleUI.Select("LabelID='btnAMCreateNew'"))[0]["LabelName"]);
                            associateModule.btnAMSubmit.Text = Convert.ToString((dt_associateModuleUI.Select("LabelID='btnAMSubmit'"))[0]["LabelName"]);
                            associateModule.btnAMSubmit.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='btnAMSubmit'"))[0]["LabelToolTip"]);

                            associateModule.btnAMCancel.Value = Convert.ToString((dt_associateModuleUI.Select("LabelID='btnAMCancel'"))[0]["LabelName"]);
                            associateModule.RngeValidtrMM.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMMMName'"))[0]["ErrorText"]);
                            associateModule.RngeValidtrSM.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMSMName'"))[0]["ErrorText"]);
                            associateModule.rfvValidMStatus.ToolTip = Convert.ToString((dt_associateModuleUI.Select("LabelID='lblAMStatusEdit'"))[0]["ErrorText"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// This method is used to load content of IsActive dropdownlist
        /// </summary>
        /// <returns>int</returns>
        internal void PerformCUD(EDFinancials.View.SuperAdmin.AssociateModule associateModule, string MmId, string s_Action)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.Id = MmId.Contains(",") ? 0 : Convert.ToInt32(MmId);
                    superAdminProperties.Ids = MmId;
                    superAdminProperties.MmId = Convert.ToInt16(associateModule.ddAMMMName.SelectedValue);
                    superAdminProperties.SmId = Convert.ToInt16(associateModule.ddAMSMName.SelectedValue);
                    superAdminProperties.IsActive = Convert.ToInt16(associateModule.ddIsActiveEdit.SelectedValue);
                    superAdminProperties.Action = s_Action;
                    superAdminProperties.PageName = "ModuleAssociation";
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;

                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                    switch (superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result)
                    {
                        case 0:
                            associateModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMError");
                            associateModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            associateModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;

                        case 1:
                            associateModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMAAdded");
                            associateModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            associateModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;


                        case 2:
                            associateModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMAUpdated");
                            associateModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            associateModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 4:
                            associateModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMAExists");
                            associateModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            associateModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 5:
                            associateModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMAReverse");
                            associateModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            associateModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 7:
                            associateModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblCanNotEditBeingUsed");
                            associateModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            associateModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;
                    }
                    associateModule.ddIsActiveEdit.SelectedIndex = -1;
                    associateModule.UpdMessages.Update();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method reverse the deleted item and makes it usable again
        /// </summary>
        /// <param name="associateModule">ModuleAssociation Page</param>
        public void ReverseDeletedRecord(EDFinancials.View.SuperAdmin.AssociateModule associateModule)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {

                    superAdminProperties.Action = "REV";
                    superAdminProperties.PageName = "ModuleAssociation";
                    superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                    switch (superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).a_result)
                    {
                        case 0:
                            associateModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMMError");
                            associateModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            associateModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 6:
                            associateModule.ctrSuccessErrorMessage.s_MessageText = superAdminServiceClient.LoadL10N("lblMAUpdated");
                            associateModule.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            associateModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;
                    }
                    associateModule.UpdMessages.Update();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to load gridview data 
        /// </summary>
        /// <returns></returns>
        public void LoadGridData(EDFinancials.View.SuperAdmin.AssociateModule associateModule, string s_Action)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.Name = associateModule.ddModuleName.SelectedItem != null ? associateModule.ddModuleName.SelectedItem.ToString() : "";
                    superAdminProperties.IsActive = associateModule.ddIsActive.SelectedValue != "" ? Convert.ToInt16(associateModule.ddIsActive.SelectedValue) : 0;
                    superAdminProperties.Action = s_Action;
                    superAdminProperties.PageName = "ModuleAssociation";
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    ac_ManageModule.dt_GridViewDataTable = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result;
                    associateModule.gv.DataSource = ac_ManageModule.dt_GridViewDataTable;
                    associateModule.gv.DataBind();
                    associateModule.updGridView.Update();

                    associateModule.btnAMClearFilter.Visible = false;
                }
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// This Method Filters Grid View using dt_GridViewDataTable
        /// </summary>
        /// <param name="associateModule">Associate Module Page</param>
        public void filterGridData(EDFinancials.View.SuperAdmin.AssociateModule associateModule)
        {
            try
            {
                string s_ModuleName = associateModule.ddModuleName.SelectedIndex > 0 ? "[Module] = '" + Convert.ToString(associateModule.ddModuleName.SelectedValue) + "'" : string.Empty;
                string s_Status = associateModule.ddIsActive.SelectedIndex > 0 ? "[Status] = '" + Convert.ToString(associateModule.ddIsActive.SelectedItem.ToString()) + "'" : string.Empty;
                string s_SubModuleName = associateModule.ddAMSName.SelectedIndex > 0 ? "[SMID] = '" + Convert.ToString(associateModule.ddAMSName.SelectedValue) + "'" : string.Empty;
               
                if ((!(string.IsNullOrEmpty(s_ModuleName))) || (!(string.IsNullOrEmpty(s_SubModuleName))) || (!(string.IsNullOrEmpty(s_Status))))
                {
                    associateModule.btnAMClearFilter.Visible = true;
                    associateModule.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }

                ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_GridViewDataTable;

                try
                {
                    if (!(string.IsNullOrEmpty(s_ModuleName)))
                        ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_ModuleDataTable.Select("" + s_ModuleName + "").CopyToDataTable();

                    if (!(string.IsNullOrEmpty(s_SubModuleName)))
                        ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_ModuleDataTable.Select("" + s_SubModuleName + "").CopyToDataTable();

                  

                    if (!(string.IsNullOrEmpty(s_Status)))
                        ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_ModuleDataTable.Select("" + s_Status + "").CopyToDataTable();

                    if ((string.IsNullOrEmpty(s_Status) && string.IsNullOrEmpty(s_ModuleName) && string.IsNullOrEmpty(s_SubModuleName)))
                    {
                        ac_ManageModule.dt_ModuleDataTable = ac_ManageModule.dt_GridViewDataTable;
                        associateModule.btnAMClearFilter.Visible = false;
                    }
                }
                catch
                {
                    ac_ManageModule.dt_ModuleDataTable = new DataTable();
                }

                associateModule.gv.DataSource = ac_ManageModule.dt_ModuleDataTable;
                associateModule.gv.DataBind();
                associateModule.updGridView.Update();
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// This Method clears any Filter apllied on Gridview.
        /// </summary>
        /// <param name="associateModule">Associate Module Page</param>
        public void ClearGridFilter(AssociateModule associateModule)
        {
            associateModule.gv.DataSource = ac_ManageModule.dt_GridViewDataTable;
            associateModule.gv.DataBind();
            associateModule.ddModuleName.SelectedIndex = 0;
            associateModule.ddAMSName.SelectedIndex = 0;
            associateModule.ddIsActive.SelectedIndex = 0;
            associateModule.updGridView.Update();
            associateModule.btnAMClearFilter.Visible = false;
        }

        /// <summary>
        /// loads Module_Name dropdownlist
        /// </summary>
        /// <returns>DropDownList</returns>
        public DropDownList loadModuleNameDropdown(DropDownList dropdownlist)
        {
            try
            {
                superAdminProperties.Action = "SML";
                superAdminProperties.PageName = "ModuleAssociation";
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    dropdownlist.DataSource = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result;
                    dropdownlist.DataTextField = "Module_Name";
                    dropdownlist.DataBind();
                }
                return dropdownlist;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  load IsActive selection dropdownlist
        /// </summary>
        /// <param name="dropDownList"></param>
        /// <param name="s_Action"></param>
        /// <param name="s_DataTextField"></param>
        /// <param name="s_DataValueField"></param>
        /// <returns></returns>
        public DropDownList LoadDropdownLists(DropDownList dropDownList, string s_Action, string s_DataTextField, string s_DataValueField)
        {
            try
            {
                superAdminProperties.Action = s_Action;
                superAdminProperties.PageName = "ModuleAssociation";
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    DataTable dt_SubModule = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result;
                    dropDownList.DataSource = dt_SubModule;
                    dropDownList.DataTextField = s_DataTextField;
                    dropDownList.DataValueField = s_DataValueField;
                    dropDownList.DataBind();
                }
                return dropDownList;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method binds row in gridview.
        /// </summary>
        /// <param name="e">gridviewRow event</param>
        /// <param name="n_index"> index number</param>
        /// <param name="n_ID">MMID</param>
        /// <param name="n_Delete">Delete ID</param>
        /// <param name="n_Action">Action to be performed</param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "AMID":
                                n_ID = n_index;
                                perColumn.Visible = false;
                                break;

                            case "MMID":
                                perColumn.Visible = false;
                                break;

                            case "SMID":
                                perColumn.Visible = false;
                                break;

                            case "IS_ACTIVE":
                                perColumn.Visible = false;
                                break;

                            case "ACTION":
                                n_Action = n_index;
                                break;
                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:

                    try
                    {
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[1].Text, e.Row.Cells[3].Text, e.Row.Cells[5].Text, "Edit"));
                        e.Row.Cells[n_Delete].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[1].Visible = false;
                        e.Row.Cells[3].Visible = false;
                        e.Row.Cells[5].Visible = false;
                        break;
                    }
                    catch
                    {
                        throw;
                    }
            }
        }

        /// <summary>
        /// Adding Edit Image button and its corresponding click event 
        /// </summary>
        /// <param name="s_strToolTip"></param>
        /// <param name="s_strUrl"></param>
        /// <param name="s_AMID">Associate Module Id</param>
        /// <param name="s_ModuleName">Module Name</param>
        /// <param name="s_SubModuleName">Sub Module Name</param>
        /// <param name="s_Status">Status</param>
        /// <param name="s_Action">Action</param>
        /// <returns></returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_AMID, string s_ModuleName, string s_SubModuleName, string s_Status, string s_Action)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");
                if (!string.IsNullOrEmpty(s_ModuleName))
                {
                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_ModuleName + "','" + s_SubModuleName + "','" + s_Status + "','" + s_AMID + "','" + 1 + "')");
                    }
                }
                return imgButton;
            }
        }


        /// <summary>
        /// To change pages of gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <param name="gv"></param>
        /// <param name="s_AssociateModuleGroupID"></param>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_AssociateModuleGroupID)
        {
            try
            {
                string[] s_AssociateModuleGpID = s_AssociateModuleGroupID.TrimStart(',').Split(',');
                foreach (string perID in s_AssociateModuleGpID)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_ManageModule.dt_GridViewDataTable.Select("AMID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_ManageModule.dt_GridViewDataTable;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~AssociateModuleModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}