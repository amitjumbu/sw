﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDFinancials.Model
{
    /// <summary>
    /// This is session context class in Model
    /// </summary>
    public class SessionContext
    {
        /// <summary>
        /// UserSessionInfoWrapper
        /// </summary>
        private class UserSessionInfoWrapper : UserSessionInfo
        {
            public UserSessionInfoWrapper()
            {

            }
        }

        /// <summary>
        /// Gets the user session info values.
        /// </summary>
        /// <returns></returns>
        public static UserSessionInfo GetUserSessionInfoValues()
        {
            UserSessionInfo userSessionInfo = (UserSessionInfo)HttpContext.Current.Session["USERSESSIONINFO"];

            if (userSessionInfo == null)
                userSessionInfo = new UserSessionInfoWrapper();

            return userSessionInfo;
        }

        /// <summary>
        /// Sets the user session info values.
        /// </summary>
        /// <param name="userSessionInfo">The user session info.</param>
        public static void SetUserSessionInfoValues(UserSessionInfo userSessionInfo)
        {
            if (userSessionInfo == null)
                throw new ArgumentNullException();

            HttpContext.Current.Session["USERSESSIONINFO"] = userSessionInfo;
        }

        /// <summary>
        /// Class is used for stored session properties
        /// </summary>
        public abstract class UserSessionInfo
        {
            /// <summary>
            /// ACC_UserID is Used to Stored login User table Identity Value 
            /// </summary>
            public int ACC_UserID { get; set; }

            /// <summary>
            /// ACC_UserName is Used to Stored Login User Id
            /// </summary>
            public string ACC_UserName { get; set; }

            /// <summary>
            /// ACC_CompanyName is Used to Stored Login Company Name / database name
            /// </summary>
            public string ACC_CompanyName { get; set; }

            /// <summary>
            /// ACC_UerTypeID is used to stored Login User Type
            /// </summary>
            public int ACC_UerTypeID { get; set; }

            /// <summary>
            /// ACC_IsListed Stored compnay is listed or unlisted
            /// 0 : Unlisted
            /// 1 : Listed 
            /// </summary>
            public int ACC_IsListed { get; set; }

            /// <summary>
            /// ACC_IsMYESOPsClient is used to stored company is MyESOPs client or not
            /// 0 : for NoMyESOPs Client
            /// 1 : for MyESOPs Client 
            /// </summary>
            public int ACC_IsMYESOPsClient { get; set; }

            /// <summary>
            /// ACC_ActualCompanyName company Name
            /// </summary>
            public string ACC_CompanyTitle { get; set; }


            /// <summary>
            /// ACC_CMID is used to store Company Master ID
            /// </summary>
            public int ACC_CMID { get; set; }

            /// <summary>
            /// ACC_CalculationMethod is used to store Calculation Method
            /// 1: Grantwise
            /// 2: Vestwise
            /// </summary>
            public int ACC_CalculationMethod { get; set; }

            /// <summary>
            /// property is used to stored whether user has Employee wise access or not.
            /// 0 : for No Emp Access
            /// 1 : has Emp Access.
            /// </summary>
            public bool ACC_IsEmpAccess { get; set; }

            /// <summary>
            /// This property is used to store the Email ID of the User.
            /// </summary>
            public string ACC_EmailID { get; set; }
        }
        
    }
}