﻿using EDFinancials.Model.Masters;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI.WebControls;
using System.Linq;

namespace EDFinancials.Model.Generic
{
    /// <summary>
    /// This class model is used to maintain generic member variables.
    /// </summary>
    public class CommonModel : IDisposable
    {
        #region Implementation of Singleton Pattern
        /// <summary>
        /// This is a singleton Pattern used for DBUtility
        /// </summary>
        private static CommonModel _instance;

        /// <summary>
        /// Constructor of DBUtility class
        /// </summary>
        protected CommonModel()
        {
            // TODO: Add constructor logic here        
        }

        #region Wrapper Classes

        #region SuperAdmin

        private class AC_MenuMasterWrapper : AC_MenuMaster
        {
            public AC_MenuMasterWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_CompanyCreationWrapper : AC_CompanyCreation
        {
            public AC_CompanyCreationWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ManageAdminUsersWrapper : AC_ManageAdminUsers
        {
            public AC_ManageAdminUsersWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_StatusReportWrapper :  AC_StatusReport 
        {
            public AC_StatusReportWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ManageModuleWrapper : AC_ManageModule
        {
            public AC_ManageModuleWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ManageStockExchangeWrapper : AC_ManageStockExchange
        {
            public AC_ManageStockExchangeWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ManageCurrencyWrapper : AC_ManageCurrency
        {
            public AC_ManageCurrencyWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ManageCountryWrapper : AC_ManageCountry
        {
            public AC_ManageCountryWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ManageForefeitureWrapper : AC_ManageForefeiture
        {
            public AC_ManageForefeitureWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ManageRFIRWrapper : AC_ManageRFIR
        {
            public AC_ManageRFIRWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ConfigureUIWrapper : AC_ConfigureUI
        {
            public AC_ConfigureUIWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ChangeForgetPasswordWrapper : AC_ChangeForgetPassword
        {
            public AC_ChangeForgetPasswordWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// AC_Help Wrapper Class
        /// </summary>
        private class AC_HelpWrapper : AC_Help
        {
            public AC_HelpWrapper()
            {
                // Do Nothing
            }
        }
        #endregion

        #region Admin

        private class AC_CompanySetupWrapper : AC_CompanySetup
        {
            public AC_CompanySetupWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ManageRolesWrapper : AC_ManageRoles
        {
            public AC_ManageRolesWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ManageUserWrapper : AC_ManageUser
        {
            public AC_ManageUserWrapper()
            {
                // Do Nothing
            }
        }

        #endregion

        #region Valuation

        private class AC_CompanyInformationWrapper : AC_CompanyInformation
        {
            public AC_CompanyInformationWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_CorporateActionWrapper : AC_CorporateAction
        {
            public AC_CorporateActionWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_DividendSetUpWrapper : AC_DividendSetUp
        {
            public AC_DividendSetUpWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_PeerCompanySetupWrapper : AC_PeerCompanySetup
        {
            public AC_PeerCompanySetupWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ValuationParameterWrapper : AC_ValuationParameter
        {
            public AC_ValuationParameterWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ReportPamameterWrapper : AC_ReportPamameter
        {
            public AC_ReportPamameterWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ReportFormatWrapper : AC_ReportFormat
        {
            public AC_ReportFormatWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_GrantDetailsWrapper : AC_GrantDetails
        {
            public AC_GrantDetailsWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_ValuationReportWrapper : AC_ValuationReport
        {
            public AC_ValuationReportWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_SearchGrantDetailsWrapper : AC_SearchGrantDetails
        {
            public AC_SearchGrantDetailsWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// AC_Help Wrapper Class
        /// </summary>
        private class AC_ValHelpWrapper : AC_ValHelp
        {
            public AC_ValHelpWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// AC_ApproveValuationParams Wrapper Class
        /// </summary>
        private class AC_ApproveValuationParamsWrapper : AC_ApproveValuationParams
        {
            public AC_ApproveValuationParamsWrapper()
            {
                // Do Nothing
            }
        }
        #endregion

        #region Accounting
        private class AC_AccountingParameterWrapper : AC_AccountingParameter
        {
            public AC_AccountingParameterWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// AC_ApproveAccountingParamsWrapper Wrapper Class
        /// </summary>
        private class AC_ApproveAccountingParamsWrapper : AC_ApproveAccountingParams
        {
            public AC_ApproveAccountingParamsWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// AC_CustomizeViewWrapper Wrapper Class
        /// </summary>
        private class AC_CustomizeViewWrapper : AC_CustomizeView
        {
            public AC_CustomizeViewWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// Wrapper class of FinancialYearSetUp
        /// </summary>
        private class AC_FinancialYearSetUpWrapper : AC_FinancialYearSetUp
        {
            public AC_FinancialYearSetUpWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// AC_HistoricalCostWrapper Wrapper Class
        /// </summary>
        private class AC_HistoricalCostWrapper : AC_HistoricalCost
        {
            public AC_HistoricalCostWrapper()
            {
                // Do Nothing
            }
        }

        private class AC_EmployeeMasterWrapper : AC_EmployeeMaster
        {
            public AC_EmployeeMasterWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// Wrapper class of ForfeitureSetup
        /// </summary>
        private class AC_ForfeitureSetupWrapper : AC_ForfeitureSetup
        {
            public AC_ForfeitureSetupWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// Wrapper class of ForfeitureSetup
        /// </summary>
        private class AC_AcceleratedVestingWrapper : AC_AcceleratedVesting
        {
            public AC_AcceleratedVestingWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// Wrapper class of CorporateActionAdjustment
        /// </summary>
        private class AC_CorporateActionAdjustmentWrapper : AC_CorporateActionAdjustment
        {
            public AC_CorporateActionAdjustmentWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// Wrapper class of AccountingReport
        /// </summary>
        private class AC_AccountingReportWrapper : AC_AccountingReport
        {
            public AC_AccountingReportWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// Wrapper class of Modifications
        /// </summary>
        private class AC_ModificationsWrapper : AC_Modifications
        {
            public AC_ModificationsWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// Wrapper class of Tracking Details
        /// </summary>
        private class AC_TrackingDetailsWrapper : AC_TrackingDetails
        {
            public AC_TrackingDetailsWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// Wrapper class of Summary Working
        /// </summary>
        private class AC_SummaryWorkingsWrapper : AC_SummaryWorkings
        {
            public AC_SummaryWorkingsWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// Wrapper class of Mass Upload
        /// </summary>
        private class AC_MassUploadWrapper : AC_MassUpload
        {
            public AC_MassUploadWrapper()
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// Wrapper class of Mass Upload
        /// </summary>
        private class AC_AccountingScheduledReportsWrapper : AC_AccountingScheduledReports
        {
            public AC_AccountingScheduledReportsWrapper()
            {
                // Do Nothing
            }
        }
        #endregion

        /// <summary>
        /// Creating an instance of a DBUtility class
        /// </summary>
        /// <returns>returning the instance of an object</returns>
        public static CommonModel Instance(string s_AbstractClass)
        {
            switch (s_AbstractClass)
            {
                #region Abstract Class SuperAdmin Instances

                case CommonConstantModel.s_AC_MenuMaster:
                    AC_MenuMaster ac_MenuMaster = (AC_MenuMaster)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_MenuMaster == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_MenuMasterWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_MenuMaster;
                    }
                    break;

                case CommonConstantModel.s_AC_CompanyCreation:
                    AC_CompanyCreation ac_CompanyCreation = (AC_CompanyCreation)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_CompanyCreation == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_CompanyCreationWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_CompanyCreation;
                    }
                    break;

                case CommonConstantModel.s_AC_ManageAdminUsers:
                    AC_ManageAdminUsers ac_ManageAdminUsers = (AC_ManageAdminUsers)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ManageAdminUsers == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ManageAdminUsersWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ManageAdminUsers;
                    }
                    break;


                case CommonConstantModel.s_AC_ManageModule:
                    AC_ManageModule ac_ManageModule = (AC_ManageModule)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ManageModule == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ManageModuleWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ManageModule;
                    }
                    break;

                case CommonConstantModel.s_AC_ManageStockExchange:
                    AC_ManageStockExchange ac_ManageStockExchange = (AC_ManageStockExchange)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ManageStockExchange == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ManageStockExchangeWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ManageStockExchange;
                    }
                    break;

                case CommonConstantModel.s_AC_ManageCurrency:
                    AC_ManageCurrency ac_ManageCurrency = (AC_ManageCurrency)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ManageCurrency == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ManageCurrencyWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ManageCurrency;
                    }
                    break;

                case CommonConstantModel.s_AC_ManageCountry:
                    AC_ManageCountry ac_ManageCountry = (AC_ManageCountry)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ManageCountry == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ManageCountryWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ManageCountry;
                    }
                    break;

                case CommonConstantModel.s_AC_ManageForefeiture:
                    AC_ManageForefeiture ac_ManageForefeiture = (AC_ManageForefeiture)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ManageForefeiture == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ManageForefeitureWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ManageForefeiture;
                    }
                    break;

                case CommonConstantModel.s_AC_ManageRFIR:
                    AC_ManageRFIR ac_ManageRFIR = (AC_ManageRFIR)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ManageRFIR == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ManageRFIRWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ManageRFIR;
                    }
                    break;

                case CommonConstantModel.s_AC_ConfigureUI:
                    AC_ConfigureUI ac_ConfigureUI = (AC_ConfigureUI)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ConfigureUI == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ConfigureUIWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ConfigureUI;
                    }
                    break;

                case CommonConstantModel.s_AC_ChangeForgetPassword:
                    AC_ChangeForgetPassword ac_ChangeForgetPassword = (AC_ChangeForgetPassword)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ChangeForgetPassword == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ChangeForgetPasswordWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ChangeForgetPassword;
                    }
                    break;

                case CommonConstantModel.s_AC_Help:
                    AC_Help ac_Help = (AC_Help)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_Help == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_HelpWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_Help;
                    }
                    break;

                case CommonConstantModel.s_AC_StatusReport:
                    AC_StatusReport ac_StatusReport = (AC_StatusReport)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_StatusReport == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_StatusReportWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_StatusReport;
                    }
                    break;
                #endregion

                #region Abstract Class Admin Instances

                case CommonConstantModel.s_AC_CompanySetup:
                    AC_CompanySetup ac_CompanySetup = (AC_CompanySetup)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_CompanySetup == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_CompanySetupWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_CompanySetup;
                    }
                    break;

                case CommonConstantModel.s_AC_ManageRoles:
                    AC_ManageRoles ac_ManageRoles = (AC_ManageRoles)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ManageRoles == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ManageRolesWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ManageRoles;
                    }
                    break;

                case CommonConstantModel.s_AC_ManageUser:
                    AC_ManageUser ac_ManageUser = (AC_ManageUser)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ManageUser == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ManageUserWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ManageUser;
                    }
                    break;

                #endregion

                #region Abstract Class Valuation Instances

                case CommonConstantModel.s_AC_CompanyInformation:
                    AC_CompanyInformation ac_CompanyInformation = (AC_CompanyInformation)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_CompanyInformation == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_CompanyInformationWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_CompanyInformation;
                    }
                    break;

                case CommonConstantModel.s_AC_CorporateAction:
                    AC_CorporateAction ac_CorporateAction = (AC_CorporateAction)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_CorporateAction == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_CorporateActionWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_CorporateAction;
                    }
                    break;

                case CommonConstantModel.s_AC_DividendSetUp:
                    AC_DividendSetUp ac_DividendSetUp = (AC_DividendSetUp)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_DividendSetUp == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_DividendSetUpWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_DividendSetUp;
                    }
                    break;

                case CommonConstantModel.s_AC_PeerCompanySetup:
                    AC_PeerCompanySetup ac_PeerCompanySetup = (AC_PeerCompanySetup)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_PeerCompanySetup == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_PeerCompanySetupWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_PeerCompanySetup;
                    }
                    break;

                case CommonConstantModel.s_AC_ValuationParameter:
                    AC_ValuationParameter ac_ValuationParameter = (AC_ValuationParameter)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ValuationParameter == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ValuationParameterWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ValuationParameter;
                    }
                    break;

                case CommonConstantModel.s_AC_ReportPamameter:
                    AC_ReportPamameter ac_ReportPamameter = (AC_ReportPamameter)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ReportPamameter == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ReportPamameterWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ReportPamameter;
                    }
                    break;

                case CommonConstantModel.s_AC_ReportFormat:
                    AC_ReportFormat ac_ReportFormat = (AC_ReportFormat)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ReportFormat == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ReportFormatWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ReportFormat;
                    }
                    break;

                case CommonConstantModel.s_AC_GrantDetails:
                    AC_GrantDetails ac_GrantDetails = (AC_GrantDetails)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_GrantDetails == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_GrantDetailsWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_GrantDetails;
                    }
                    break;

                case CommonConstantModel.s_AC_ValuationReport:
                    AC_ValuationReport ac_ValuationReport = (AC_ValuationReport)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ValuationReport == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ValuationReportWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ValuationReport;
                    }
                    break;

                case CommonConstantModel.s_AC_SearchGrantDetails:
                    AC_SearchGrantDetails ac_SearchGrantDetails = (AC_SearchGrantDetails)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_SearchGrantDetails == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_SearchGrantDetailsWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_SearchGrantDetails;
                    }
                    break;

                case CommonConstantModel.s_AC_ValHelp:
                    AC_ValHelp ac_ValHelp = (AC_ValHelp)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ValHelp == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ValHelpWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ValHelp;
                    }
                    break;

                case CommonConstantModel.s_AC_ApproveValuationParams:
                    AC_ApproveValuationParams ac_ApproveValuationParams = (AC_ApproveValuationParams)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ApproveValuationParams == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ApproveValuationParamsWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ApproveValuationParams;
                    }
                    break;

                #endregion

                #region Abstract Class Accounting Instances
                case CommonConstantModel.s_AC_FinancialYearSetUp:
                    AC_FinancialYearSetUp ac_FinancialYearSetUp = (AC_FinancialYearSetUp)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_FinancialYearSetUp == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_FinancialYearSetUpWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_FinancialYearSetUp;
                    }
                    break;

                case CommonConstantModel.s_AC_AccountingParameter:
                    AC_AccountingParameter ac_AccountingParameter = (AC_AccountingParameter)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_AccountingParameter == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_AccountingParameterWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_AccountingParameter;
                    }
                    break;

                case CommonConstantModel.s_AC_HistoricalCost:
                    AC_HistoricalCost ac_HistoricalCost = (AC_HistoricalCost)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_HistoricalCost == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_HistoricalCostWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_HistoricalCost;
                    }
                    break;

                case CommonConstantModel.s_AC_EmployeeMaster:
                    AC_EmployeeMaster ac_EmployeeMaster = (AC_EmployeeMaster)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_EmployeeMaster == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_EmployeeMasterWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_EmployeeMaster;
                    }
                    break;


                case CommonConstantModel.s_AC_ApproveAccountingParams:
                    AC_ApproveAccountingParams ac_ApproveAccountingParams = (AC_ApproveAccountingParams)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ApproveAccountingParams == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ApproveAccountingParamsWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ApproveAccountingParams;
                    }
                    break;

                case CommonConstantModel.s_AC_CustomizeView:
                    AC_CustomizeView ac_CustomizeView = (AC_CustomizeView)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_CustomizeView == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_CustomizeViewWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_CustomizeView;
                    }
                    break;

                case CommonConstantModel.s_AC_ForfeitureSetup:
                    AC_ForfeitureSetup ac_ForfeitureSetup = (AC_ForfeitureSetup)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_ForfeitureSetup == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ForfeitureSetupWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_ForfeitureSetup;
                    }
                    break;

                case CommonConstantModel.s_AC_AcceleratedVesting:
                    AC_AcceleratedVesting ac_AcceleratedVesting = (AC_AcceleratedVesting)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_AcceleratedVesting == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_AcceleratedVestingWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_AcceleratedVesting;
                    }
                    break;

                case CommonConstantModel.s_AC_CorporateActionAdjustment:
                    AC_CorporateActionAdjustment ac_CorporateActionAdjustment = (AC_CorporateActionAdjustment)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_CorporateActionAdjustment == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_CorporateActionAdjustmentWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_CorporateActionAdjustment;
                    }
                    break;

                case CommonConstantModel.s_AC_AccountingReport:
                    AC_AccountingReport ac_AccountingReport = (AC_AccountingReport)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_AccountingReport == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_AccountingReportWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_AccountingReport;
                    }
                    break;

                case CommonConstantModel.s_AC_Modifications:
                    AC_Modifications ac_Modifications = (AC_Modifications)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_Modifications == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_ModificationsWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_Modifications;
                    }
                    break;

                case CommonConstantModel.s_AC_TrackingDetails:
                    AC_TrackingDetails ac_TrackingDetails = (AC_TrackingDetails)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_TrackingDetails == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_TrackingDetailsWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_TrackingDetails;
                    }
                    break;

                case CommonConstantModel.s_AC_AccSummaryWorkings:
                    AC_SummaryWorkings ac_SummaryWorkings = (AC_SummaryWorkings)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_SummaryWorkings == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_SummaryWorkingsWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_SummaryWorkings;
                    }
                    break;

                case CommonConstantModel.s_AC_MassUpload:
                    AC_MassUpload ac_MassUpload = (AC_MassUpload)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_MassUpload == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_MassUploadWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_MassUpload;
                    }
                    break;

                case CommonConstantModel.s_AC_AccountingScheduledReportsWrapper:
                    AC_AccountingScheduledReportsWrapper ac_AccountingScheduledReportsWrapper = (AC_AccountingScheduledReportsWrapper)HttpContext.Current.Session[s_AbstractClass];

                    if (ac_AccountingScheduledReportsWrapper == null)
                    {
                        HttpContext.Current.Session[s_AbstractClass] = new AC_AccountingScheduledReportsWrapper();
                    }
                    else
                    {
                        HttpContext.Current.Session[s_AbstractClass] = ac_AccountingScheduledReportsWrapper;
                    }
                    break;
                #endregion
            }

            if (_instance == null)
            {
                _instance = new CommonModel();
            }

            return _instance;
        }
        #endregion

        #region Abstract Class Super Admin

        #region Menu Master
        /// <summary>
        /// Menu master page varaiable declarations 
        /// </summary>
        public abstract class AC_MenuMaster
        {
            /// <summary>
            /// Get menu details into datatable
            /// </summary>
            public System.Data.DataTable dt_GetMenus = new System.Data.DataTable();

            /// <summary>
            /// Stored last login id to string
            /// </summary>
            public string s_LastLoginDetails = string.Empty;

            /// <summary>
            ///  stored the page url
            /// </summary>
            public const string s_PageName = "/View/User/Accounting/AccSummaryWorkingsReport.aspx";
        }
        #endregion

        #region Company Creation
        /// <summary>
        /// Company Creation page varaiable declarations 
        /// </summary>        
        public abstract class AC_CompanyCreation
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_GetCompanyDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_TempCompanyDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ModuleAssociationDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_TempModulAssociationDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_PeerNameAutoPopTable = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_TempGridviewTable = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_EmployeeParameters = new System.Data.DataTable();

            /// <summary>
            /// This datatable has list of Modules associated to all the companies.
            /// </summary>
            public System.Data.DataTable dt_ModuleAssociationList = new System.Data.DataTable();

        }
        #endregion

        #region Manage Admin Users
        /// <summary>
        /// Manage admin user varaiable declarations 
        /// </summary>
        public abstract class AC_ManageAdminUsers
        {
            /// <summary>
            /// Get admin user list to datatable
            /// </summary>
            public System.Data.DataTable dt_ManageAdminUsers = new System.Data.DataTable();
        }
        #endregion

        #region Status Report
       /// <summary>
        /// Manage status report varaiable declarations 
       /// </summary>
        public abstract class AC_StatusReport
        {
            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_PageIndex = 0;
            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_PageSize = 0;
            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_ValPageIndex = 0;
            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_ValPageSize = 0;
            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_AccPageIndex = 0;
            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_AccPageSize = 0;
            /// <summary>
            ///  Empty Variable
            /// </summary>
            public string s_status = string.Empty;
            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_GridViewRecordsCount = 0;
            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_GrdRecordsCount = 0;
            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_GrdViewAccRecordsCount = 0;
            /// <summary>
            /// Get Valuation linkbutton value
            /// </summary>
            public string s_Valutaitonlnk = string.Empty;
            /// <summary>
            /// Get Accounting linkbutton value
            /// </summary>
            public string s_Accountinglnk = string.Empty;
            /// <summary>
            /// Get status report UI list to datatable
            /// </summary>
            public System.Data.DataTable dt_StatusReportUI = new System.Data.DataTable();
            /// <summary>
            ///  Get status result list to dataset   
            /// </summary>
            public System.Data.DataSet ds_StatusResult = new System.Data.DataSet();
            /// <summary>
            ///  Get status result filter to dataset   
            /// </summary>          
            public System.Data.DataSet ds_Filter_StatusResult = new System.Data.DataSet();
            /// <summary>
            ///  get status valuation result to dataset
            /// </summary>
            public System.Data.DataSet  ds_StatusValResult = new System.Data.DataSet();
            /// <summary>
            ///  get status Accounting result to dataset
            /// </summary>
            public System.Data.DataSet ds_StatusAccResult = new System.Data.DataSet();
            /// <summary>
            ///  get result to dataset for send reminder mail of valuation
            /// </summary>
            public System.Data.DataSet ds_StatusValCpyResult = new System.Data.DataSet();
            /// <summary>
            ///  get result to dataset for send reminder mail of Accounting
            /// </summary>
            public System.Data.DataSet ds_StatusAccCpyResult = new System.Data.DataSet();
        }
        #endregion

        #region ManageModule members
        /// <summary>
        /// Manage module page varaiable declarations
        /// </summary>
        public abstract class AC_ManageModule
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ModuleDataTable = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_GridViewDataTable = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public string reversingModuleName = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public int reversingModuleStatus = 0;
        }
        #endregion

        #region Stock Exchange members
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ManageStockExchange
        {
            /// <summary>
            /// This DataSet is used to store stock exchange details
            /// </summary>
            public System.Data.DataSet ds_SEDetails = new System.Data.DataSet();

            /// <summary>
            /// This datatable is used to store stock exchange details
            /// </summary>
            public System.Data.DataTable dt_StockExchangeDetails = new System.Data.DataTable();

            /// <summary>
            /// This datatable is used to store stock exchange details
            /// </summary>
            public System.Data.DataTable dt_SEDetails = new System.Data.DataTable();

            /// <summary>
            /// This datatable is used to store currencies
            /// </summary>
            public System.Data.DataTable dt_Currencies = new System.Data.DataTable();

            /// <summary>
            /// Variable to store Edit button text
            /// </summary>
            public string s_BtnEditText = string.Empty;
        }
        #endregion

        #region Currency Master members
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ManageCurrency
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_Currencies = null;

            /// <summary>
            /// 
            /// </summary>
            public string s_CurrencyName = string.Empty;
        }
        #endregion

        #region Country Master members
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ManageCountry
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_Countries = null;

            /// <summary>
            /// 
            /// </summary>
            public string s_CountryName = string.Empty;
        }
        #endregion

        #region ForefeitureGroup members
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ManageForefeiture
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ForefeitureGroup = null;

            /// <summary>
            /// 
            /// </summary>
            public string s_ForfeitureGroupName = string.Empty;
        }
        #endregion

        #region RFIR Members
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ManageRFIR
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_RFIRDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public string s_BtnEditText = string.Empty;
        }
        #endregion

        #region Configure UI members
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ConfigureUI
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ConfigUI = null;

            /// <summary>
            /// 
            /// </summary>
            public DataSet ds_ConfigUI = null;
        }
        #endregion

        #region Change Password and Forget Password
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ChangeForgetPassword
        {
            /// <summary>
            /// 
            /// </summary>
            public string s_CompanyName = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_LoginID = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_Date = string.Empty;
        }
        #endregion

        #region Help
        /// <summary>
        /// Abstract class AC_Help
        /// </summary>
        public abstract class AC_Help
        {
            /// <summary>
            /// DataTable dt_Help_PGrid 
            /// </summary>
            public System.Data.DataTable dt_Help_PGrid = new System.Data.DataTable();

            /// <summary>
            /// DataTable dt_Help_OGrid
            /// </summary>
            public System.Data.DataTable dt_Help_OGrid = new System.Data.DataTable();

            /// <summary>
            /// DataTable dt_Help_PageWise
            /// </summary>
            public System.Data.DataTable dt_Help_PageWise = new System.Data.DataTable();

            /// <summary>
            /// DataTable dt_Help_Others
            /// </summary>
            public System.Data.DataTable dt_Help_Others = new System.Data.DataTable();

            /// <summary>
            /// DataTable dt_DBHelpUpload
            /// </summary>
            public System.Data.DataTable dt_DBHelpUpload = new System.Data.DataTable();

            /// <summary>
            /// DataTable dt_Help_PageNames
            /// </summary>
            public System.Data.DataTable dt_Help_PageNames = new System.Data.DataTable();
        }
        #endregion

        #endregion

        #region Abstract Class Admin

        #region Admin Company Setup members
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_CompanySetup
        {
            /// <summary>
            /// This DataSet is used to store Company details
            /// </summary>
            public System.Data.DataSet ds_CompanyDetails = new System.Data.DataSet();

            /// <summary>
            /// This Datatbale is used to store Company type
            /// </summary>
            public System.Data.DataTable dt_CompanyType = new System.Data.DataTable();

            /// <summary>
            /// This Datatbale is used to store master currencies
            /// </summary>
            public System.Data.DataTable dt_Currencies = new System.Data.DataTable();

            /// <summary>
            /// This Datatbale is used to store Company Information
            /// </summary>
            public System.Data.DataTable dt_CompanyDetails = new System.Data.DataTable();

            /// <summary>
            /// This Datatbale is used to store Listing History data
            /// </summary>
            public System.Data.DataTable dt_ListingHistory = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>                                         
            public System.Data.DataTable dt_AssociatedParameters = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_StockExchangeDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_CompanyNameHistoryData = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public string s_BtnUpdateText = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_BtnCancelText = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_BtnEditText = string.Empty;
        }
        #endregion

        #region Manage Roles
        /// <summary>
        /// 
        /// </summary>     
        public abstract class AC_ManageRoles
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ManageRoles = new System.Data.DataTable();
        }

        #endregion

        #region Manage User
        /// <summary>
        /// 
        /// </summary>     
        public abstract class AC_ManageUser
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ManageUsers = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_TempManageUsers = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public string reversingUName = null;

            /// <summary>
            /// 
            /// </summary>
            public string reversingEmail = null;

            /// <summary>
            /// 
            /// </summary>
            public int reversingUStatus = 0;

            /// <summary>
            /// 
            /// </summary>
            public int reversingURole = 0;

            /// <summary>
            /// 
            /// </summary>
            public int reversingUType = 0;

            /// <summary>
            /// 
            /// </summary>
            public int reversingEmpwiseAcc = 0;
        }

        #endregion

        #endregion

        #region Abstract Class Valuation

        #region Company Info Members

        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_CompanyInformation
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_CompanyInfoSetupUI = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_CompanyInfoPopUI = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public DataSet ds_CompanyInfo = new System.Data.DataSet();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_CompanyInfo = new System.Data.DataTable();

            /// <summary>
            /// This Datatbale is used to store currencies
            /// </summary>
            public System.Data.DataTable dt_Currencies = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ListingStatusHistory = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_CurrentShareCap = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ShareCapDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ShareCapHistory = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_CurrentFaceValue = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_FaceValueDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_FaceValueHistory = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_AssociatedStockExchange = new System.Data.DataTable();

            /// <summary>
            /// This DataTable is used to store Company type
            /// </summary>
            public System.Data.DataTable dt_CompanyType = new System.Data.DataTable();

            /// <summary>
            /// This DataTable is used to store Associated Modules
            /// </summary>
            public System.Data.DataTable dt_AssociatedModules = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public string ListingStatus = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public bool b_IsEditRights = false;

            /// <summary>
            /// 
            /// </summary>
            public bool b_IsDeleteRights = false;
        }
        #endregion

        #region Corporate Action members
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_CorporateAction
        {
            /// <summary>
            /// Data table is used for entered corporate action details
            /// </summary>
            public System.Data.DataTable dt_CorporateAction = new System.Data.DataTable();

            /// <summary>
            /// Data table is used to stored temp data  for entered corporate action details
            /// </summary>
            public System.Data.DataTable dt_TempCorporateAction = new System.Data.DataTable();

            /// <summary>
            /// bool variable is used to store for perviledges
            /// </summary>
            public bool Is_Edit = false;
        }
        #endregion

        #region Dividend Setup
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_DividendSetUp
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_temp_DividendDate = new System.Data.DataTable();

            /// <summary>
            /// Check edit rights
            /// </summary>
            public bool b_IsEditRights = false;

            /// <summary>
            /// This Datatable is used to store Financial Year Data in DividendSetUp Page.
            /// </summary>
            public System.Data.DataTable dt_DivdFinanYr = new System.Data.DataTable();
        }
        #endregion

        #region Peer Company Setup
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_PeerCompanySetup
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ViewHistory = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_PeerCompanyUI = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_NewPeerCompanies = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public double totalWeightage = 0;

            /// <summary>
            /// 
            /// </summary>
            public string[,] editGridview_data;

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_TempGridviewTable = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_GridViewDataTable = new System.Data.DataTable();
        }
        #endregion

        #region Valuation Parameters Setup members
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ValuationParameter
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataSet ds_ValuationParameters = new System.Data.DataSet();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_MarketPriceIV = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_MarketPriceFV = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ExpectedLife = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_Volatility = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_Dividend = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ValuParaSetupUI = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_PeerCompanies = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_VolExcludeDetails = new System.Data.DataTable();

            /// <summary>
            /// This DataTable is used to save Incorp Dividend details
            /// </summary>
            public System.Data.DataTable dt_IncorpDividendToSave = new System.Data.DataTable();

            /// <summary>
            /// This DataTable is used to save Incorp Dividend details
            /// </summary>
            public System.Data.DataTable dt_IncorpDividendDetails = new System.Data.DataTable();

            /// <summary>
            /// This DataTable is used to save Incorp Dividend details
            /// </summary>
            public System.Data.DataTable dt_IncorpDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_RFIRDetails = new System.Data.DataTable();

            /// <summary>
            /// DataTable variable used to store approval data
            /// </summary>
            public System.Data.DataTable dt_ApprovalData = new System.Data.DataTable();

            /// <summary>
            /// DataTable variable used to store reviewer details
            /// </summary>
            public System.Data.DataTable dt_ReviewerDetails = new System.Data.DataTable();

            /// <summary>
            /// DataTable is used to store messages from xml
            /// </summary>
            public System.Data.DataTable dt_EstDateDetailsUI = new System.Data.DataTable();

            /// <summary>
            /// DataTable is used to store current estimated date details
            /// </summary>
            public System.Data.DataTable dt_CurrEstimatedDOLDetails = new System.Data.DataTable();

            /// <summary>
            /// DataTable is used to store estimated date details
            /// </summary>
            public System.Data.DataTable dt_EstimatedDOLDetails = new System.Data.DataTable();

            /// <summary>
            /// Boolean variable is used to store company's listing status
            /// </summary>
            public bool b_IsListed;

            /// <summary>
            /// Boolean variable is used to store user's edit righhts
            /// </summary>
            public bool b_IsEditRights = false;

            /// <summary>
            /// Boolean variable is used to store user's delete righhts
            /// </summary>
            public bool b_IsDeleteRights = false;
        }
        #endregion

        #region Report Parameters
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ReportPamameter
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ReportParameterText = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_GetPeerCompanies = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public bool b_IsListed;

            /// <summary>
            /// 
            /// </summary>
            public List<string> Parameterlist = new List<string>();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ValuParaSetupUI = new System.Data.DataTable();
        }
        #endregion

        #region Reprot Format
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ReportFormat
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ReportFormatParameters = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public List<string> ImageNamelist = new List<string>();

            /// <summary>
            /// 
            /// </summary>
            public string s_TemplateRootPath = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_DefaultTemplatePath = string.Empty;
        }

        #endregion

        #region Grant Details
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_GrantDetails
        {
            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_GrantDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_GetGrantDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ChildVestDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_UnlockedGrants = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_LockedGrants = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_UpdateGenParams = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_TempVestDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ViewDataEntered = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public DateTime dat_ListingDate = new DateTime();

            /// <summary>
            /// 
            /// </summary>
            public decimal n_VestTotalPercent;

            /// <summary>
            /// 
            /// </summary>
            public int n_NoOfColumns = 0;

            /// <summary>
            /// 
            /// </summary>
            public int n_NoVest = 0;

            /// <summary>
            /// 
            /// </summary>
            public int n_Real_NoVest = 0;

            /// <summary>
            /// 
            /// </summary>
            public int n_Mult_Exer_Period_Value = 0;

            /// <summary>
            /// 
            /// </summary>
            public string n_Mult_Exer_Period_Freq = "Y";

            /// <summary>
            /// 
            /// </summary>
            public string n_Mult_Exer_Period_Freq_From = "G";

            /// <summary>
            /// 
            /// </summary>
            public bool is_ChkPercent = false;

            /// <summary>
            /// 
            /// </summary>
            public DateTime dat_VestDate = new DateTime();

            /// <summary>
            /// 
            /// </summary>
            public bool is_TableCreated = false;

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_GrantRegMaster = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_GrantRegDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_DBGrantRegMaster = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_DBGrantRegDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_FileUploads = new System.Data.DataTable();

            /// <summary>
            /// This Datatable is used to store data about uploaded file
            /// </summary>
            public System.Data.DataTable dt_gvFileUploads = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public string s_GRMIDs = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_PageName = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_Error = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_ChildPageName = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_GrantID;

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_Valuation_Report_UI_Text = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_temp_Unlocked_Valuation_Report = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_temp_Locked_Valuation_Report = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_ValuParaSetupUI = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_Countries = null;

            /// <summary>
            /// 
            /// </summary>
            public string s_SelectedGrants;

            /// <summary>
            /// used to save Updated As On Data
            /// </summary>
            public System.Data.DataTable dt_UpdatedAsOnData = null;

            /// <summary>
            /// used to save Updated As On Data Comments
            /// </summary>
            public System.Data.DataTable dt_UpdatedAsOnDataComments = null;

            /// <summary>
            /// used to save Updated As On Data Documents
            /// </summary>
            public System.Data.DataTable dt_UpdatedAsOnDataDocuments = null;

            /// <summary>
            /// Option Details UI
            /// </summary>
            public System.Data.DataTable dt_OptionDetailsUI = new System.Data.DataTable();

            /// <summary>
            /// Option Details Data
            /// </summary>
            public System.Data.DataTable dt_OptionDetailsData = new System.Data.DataTable();

            /// <summary>
            /// Option Details Data Vestwise
            /// </summary>
            public System.Data.DataTable dt_OptionDetailsDataVestwise = new System.Data.DataTable();

            /// <summary>
            /// Option Details Uploaded Data
            /// </summary>
            public System.Data.DataTable dt_OptionDetailsUploadedData = new System.Data.DataTable();

            /// <summary>
            /// Uploaded Doc Names
            /// </summary>
            public System.Data.DataTable dt_OptionDetailsDocDetails = new System.Data.DataTable();

            /// <summary>
            /// used to save Updated As On Data
            /// </summary>
            public string s_IsEditedRecordLocked = null;

            /// <summary>
            /// used to save Store Grant List in array
            /// </summary>
            public string s_GrantsWithNoEmp = null;


            /// <summary>
            /// used to save Agrmid
            /// </summary>
            public string s_AGRMID;
        }
        #endregion

        #region Valuation Report
        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_ValuationReport
        {
            /// <summary>
            /// 
            /// </summary>
            public string s_VestingDetails;

            /// <summary>
            /// 
            /// </summary>
            public string s_GrantDetails;

            /// <summary>
            /// 
            /// </summary>
            public string s_ParametersDetails;

            /// <summary>
            /// 
            /// </summary>
            public string s_GrantID;

            /// <summary>
            /// 
            /// </summary>
            public string s_SelectedGrants;

            /// <summary>
            /// 
            /// </summary>
            public string s_StepNumber = "0";

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_main_Unlocked_Valuation_Report = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_temp_Unlocked_Valuation_Report = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_temp_Locked_Valuation_Report = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_all_Grants = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_Selected = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_Valuation_Report_UI_Text = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_VersionDetails = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public int n_VestCount;

            /// <summary>
            /// 
            /// </summary>
            public int n_RowCount;

            /// <summary>
            /// 
            /// </summary>
            public string s_FairValue;

            /// <summary>
            /// 
            /// </summary>
            public string s_FinalValue;

            /// <summary>
            /// 
            /// </summary>
            public string s_GrantRegID;

            /// <summary>
            /// 
            /// </summary>
            public string s_CompareGrantID;

            /// <summary>
            /// 
            /// </summary>
            public string s_ChildPageName = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_QueryStringParams = string.Empty;

            /// <summary>
            /// 
            /// </summary>
            public string s_PageName = string.Empty;

            /// <summary>
            /// This dataset contains the selected datatables in 2nd tab
            /// </summary>
            public DataSet ds_SelectedDataTables = new DataSet();

            /// <summary>
            /// This dataset contains the selected datatables in 2nd tab
            /// </summary>
            public DataSet ds_CalculationDetails = new DataSet();

            /// <summary>
            /// This dataset contains the selected datatables in 2nd tab
            /// </summary>
            public DataSet ds_SelectedDT_IntrinsicValue = new DataSet();

            /// <summary>
            /// This dataset contains the selected datatables in 2nd tab
            /// </summary>
            public DataSet ds_CalculationDetails_IntrinsicValue = new DataSet();

            /// <summary>
            /// This dataset contains the selected datatables in 2nd tab
            /// </summary>
            public System.Data.DataTable dt_CommentsDetails = new System.Data.DataTable();

            /// <summary>
            /// This DataTable is used to maintain Country 
            /// </summary>
            public System.Data.DataTable dt_CountryNames = new System.Data.DataTable();

            /// <summary>
            /// Check edit rights
            /// </summary>
            public bool b_IsEditEnabled = false;
        }
        #endregion

        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_SearchGrantDetails
        {
            /// <summary>
            /// 
            /// </summary>
            public int n_VestCount;

            /// <summary>
            /// 
            /// </summary>
            public string s_GrantID;

            /// <summary>
            /// 
            /// </summary>
            public string s_SelectedGrants;

            /// <summary>
            /// 
            /// </summary>
            public string s_StepNumber = "0";

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_main_Unlocked_Valuation_Report = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_main_Locked_Valuation_Report = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_temp_Unlocked_Valuation_Report = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_temp_Locked_Valuation_Report = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_all_Grants = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public System.Data.DataTable dt_Valuation_Report_UI_Text = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public int n_RowCount;

            /// <summary>
            /// 
            /// </summary>
            public string s_FairValue;

            /// <summary>
            /// 
            /// </summary>
            public string s_FinalValue;

            /// <summary>
            /// 
            /// </summary>
            public string s_GrantRegID;

            /// <summary>
            /// 
            /// </summary>
            public string s_CompareGrantID;

            /// <summary>
            /// 
            /// </summary>
            public string s_ChildPageName = string.Empty;

            /// <summary>
            /// Report Status List
            /// </summary>
            public System.Data.DataTable dt_ReportStatus = new System.Data.DataTable();

            /// <summary>
            /// This DataTable is used to store Valuation Report Page UI controls 
            /// </summary>
            public System.Data.DataTable dt_GrantDetailUI = new System.Data.DataTable();

            /// <summary>
            /// This DataTable is used to store all grant(s) data which comes under Modification/EDL date(s)
            /// </summary>
            public System.Data.DataTable dt_ModEDLGrants = new System.Data.DataTable();

            /// <summary>
            /// This string is used to store hidden field value in  Modification/EDL tab
            /// </summary>
            public string s_ModEDLset = string.Empty;

            /// <summary>
            ///  Data table for Customized View for Employee Master.
            /// </summary>
            public System.Data.DataTable dt_CustmizedViewGrantDetails = new System.Data.DataTable();

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_GridViewRecordsCount = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_SchemeNameRecordsCount = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_PageIndex = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_PageSize = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_PageIndexSchemeName = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_PageSizeSchemeName = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public string n_FromAndToSelected = string.Empty;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public string n_FromAndToSelected_Locked = string.Empty;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_PageIndex_Locked = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_PageSize_Locked = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_GridViewRecordsCount_Locked = 0;

            /// <summary>
            /// 
            /// </summary>
            public string s_LatestOperationDate = string.Empty;

        }

        /// <summary>
        /// Abstract class AC_ValHelp
        /// </summary>
        public abstract class AC_ValHelp
        {
        }

        /// <summary>
        /// Abstract class AC_ApproveValuationParams
        /// </summary>
        public abstract class AC_ApproveValuationParams
        {
            /// <summary>
            /// DataTable is used to store Page UI label text
            /// </summary>
            public System.Data.DataTable dt_ApprValParamsSetupUI = new System.Data.DataTable();

            /// <summary>
            /// DataTable is used to store Incorporate Details
            /// </summary>
            public System.Data.DataTable dt_IncorporateDetails = new System.Data.DataTable();

            /// <summary>
            /// DataTable is used to store pending valuation parameters for approval
            /// </summary>
            public System.Data.DataSet ds_ApprValParams = new System.Data.DataSet();
        }

        #endregion

        #region Abstract Class Accounting
        /// <summary>
        /// Abstract Class of SET ACCOUNTING PARAMETER
        /// </summary>
        public abstract class AC_AccountingParameter
        {
            /// <summary>
            /// DataSet variable used to retrive accounting Parameters details
            /// </summary>
            public System.Data.DataSet ds_AccountingParameters = new System.Data.DataSet();

            /// <summary>
            /// DatatTable variable used to store accounting Parameters UI text details
            /// </summary>
            public System.Data.DataTable dt_AccountingParametersUI = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store accounting Parameters details
            /// </summary>
            public System.Data.DataTable dt_AccountingParameters = new System.Data.DataTable();

            /// <summary>
            /// DataTable variable used to store reviewer details
            /// </summary>
            public System.Data.DataTable dt_ReviewerDetails = new System.Data.DataTable();
        }

        /// <summary>
        /// Abstract Class of APPROVE ACCOUNTING PARAMETER
        /// </summary>
        public abstract class AC_ApproveAccountingParams
        {
            /// <summary>
            /// DataTable is used to store Page UI  text
            /// </summary>
            public System.Data.DataTable dt_ApprAccParamsSetupUI = new System.Data.DataTable();

            /// <summary>
            /// DataTable is used to store pending accounting parameters for approval
            /// </summary>
            public System.Data.DataSet ds_ApprAccParams = new System.Data.DataSet();
        }

        /// <summary>
        /// Abstract Class of FinancialYearSetUp
        /// </summary>
        public abstract class AC_FinancialYearSetUp
        {
            /// <summary>
            /// The Datatable to store financial year data
            /// </summary>
            public System.Data.DataTable dt_FincYr = new System.Data.DataTable();

            /// <summary>
            /// The Datatable to store locked data
            /// </summary>
            public System.Data.DataTable dt_LockedData = new System.Data.DataTable();

            /// <summary>
            /// The DataTable to store Financial Year Data
            /// </summary>
            public System.Data.DataTable dt_UpdatedFYData = new System.Data.DataTable();
        }

        /// <summary>
        /// Abstract class for Customize View
        /// </summary>
        public abstract class AC_CustomizeView
        {
            /// <summary>
            /// Datatable is used for Bind UI
            /// </summary>
            public System.Data.DataTable dt_Bind_UI = new System.Data.DataTable();

            /// <summary>
            /// Datatable is used for store customize view details
            /// </summary>
            public System.Data.DataTable dt_CustomizeView = new System.Data.DataTable();

            /// <summary>
            /// Datatable is used for store customize view details on temporary basis
            /// </summary>
            public System.Data.DataTable dt_Temp_CustomizeView = new System.Data.DataTable();

            /// <summary>
            /// bool variable is used to store for perviledges
            /// </summary>
            public bool Is_Edit = false;

            /// <summary>
            /// Datatable is used for bind left grid
            /// </summary>
            public System.Data.DataTable dt_LeftGridData = new System.Data.DataTable();

            /// <summary>
            /// Data table is uesd for bind final data
            /// </summary>
            public System.Data.DataTable dt_FinalData = new System.Data.DataTable("dt_FinalData");

            /// <summary>
            /// Datatable is used for stored user list available in system.
            /// </summary>
            public System.Data.DataTable dt_UserList = new System.Data.DataTable();

            /// <summary>
            /// Datatable is used for stored user list available in system on temporary basis
            /// </summary>
            public System.Data.DataTable dt_Temp_UserList = new System.Data.DataTable();

            /// <summary>
            /// Datatable is used for stored assign user list for selected view
            /// </summary>
            public System.Data.DataTable dt_AssignUserList = new System.Data.DataTable();

            /// <summary>
            /// Parameter is used for set view id for assign user to view
            /// </summary>
            public string s_ViewId = string.Empty;

            /// <summary>
            /// Table is used to stored assign users to view.
            /// </summary>
            public System.Data.DataTable dt_AssignUserToView = new System.Data.DataTable("dt_AssignUserToView");

            /// <summary>
            /// Table is used to stored assign data to right grid on edit.
            /// </summary>
            public System.Data.DataTable dt_EditRightView = new System.Data.DataTable("dt_EditRightView");

            /// <summary>
            /// Table is used to stored assign data to final grid on edit.
            /// </summary>
            public System.Data.DataTable dt_EditFinalView = new System.Data.DataTable("dt_EditFinalView");
        }

        /// <summary>
        /// Abstract Class of Historical Cost 
        /// </summary>
        public abstract class AC_HistoricalCost
        {
            /// <summary>
            /// DataTable is used to store Page UI  text
            /// </summary>
            public System.Data.DataTable dt_HistoricalCostUI = new System.Data.DataTable();

            /// <summary>
            /// DataSet is used to store Historcial Cost deatils
            /// </summary>
            public System.Data.DataSet ds_HistoricalCost = new System.Data.DataSet();

            /// <summary>
            /// DataSet is used to store Historcial Cost deatils
            /// </summary>
            public System.Data.DataSet ds_HCDetails = new System.Data.DataSet();

            /// <summary>
            /// DataSet is used to store Historcial Cost deatils
            /// </summary>
            public System.Data.DataSet ds_RptDetails = new System.Data.DataSet();

            /// <summary>
            /// DataSet is used to store Historcial Cost deatils
            /// </summary>
            public System.Data.DataTable dt_FYDetails = new System.Data.DataTable();

            /// <summary>
            ///  DataTable is used to store temp Historcial Cost deatils
            /// </summary>
            public System.Data.DataTable dt_temp_HC_details = new System.Data.DataTable();

            /// <summary>
            ///  DataTable is used to store to add  Historcial Cost deatils
            /// </summary>
            public System.Data.DataTable dt_Add_HC_details = new System.Data.DataTable();

            /// <summary>
            ///  DataTable is used to store Historcial Cost deatils by search Parmaeters(Location,SBU,Dept,Entity,Cost Centre)
            /// </summary>
            public System.Data.DataTable dt_SP_HC_details = new System.Data.DataTable();

            /// <summary>
            /// bool variable used to check if this is first reocrd
            /// </summary>
            public bool IsFirstSelection = true;

            /// <summary>
            ///  DataTable is used to store Historcial Cost deatils by searching the record in case of add operation
            /// </summary>
            public System.Data.DataTable dt_FilterDetails = new System.Data.DataTable();

            /// <summary>
            ///  DataTable is used to store Historcial Cost deatils by searching the record in case of Search Parameter view functionality
            /// </summary>
            public System.Data.DataTable dt_FilterMaintainedHCDetails = new System.Data.DataTable();

            /// <summary>
            /// int variable used to store the rowcount for grid view
            /// </summary>
            public int Rowcount;

            /// <summary>
            /// int variable used to store the rowcount for gvAParms grid view
            /// </summary>
            public int AParmsRowcount;

            /// <summary>
            /// int variable used to store the rowcount for gvAParms grid view
            /// </summary>
            public int AParmsColcount;

            /// <summary>
            ///  DataTable is used to store to add  Historcial Cost deatils
            /// </summary>
            public System.Data.DataTable dt_Add_SParms_details = new System.Data.DataTable();

            /// <summary>
            /// This is selected datatables in add gridview for grantwise
            /// </summary>
            public System.Data.DataTable dt_SelectedDataTables = new System.Data.DataTable("SelectedDataTables");

            /// <summary>
            /// This is selected datatables in add gridview for vestwise
            /// </summary>
            public System.Data.DataTable dt_SelectedForVestwise = new System.Data.DataTable("SelectedForVestwise");

            /// <summary>
            /// This dataset contains the searched data for gridview.
            /// </summary>
            public System.Data.DataTable dt_HCFiltered = new System.Data.DataTable();

            /// <summary>
            /// Datatable used to searched data for gridview.
            /// </summary>
            public System.Data.DataTable dt_HCEditDetails = new System.Data.DataTable("HCEditDetails");

            /// <summary>
            ///  DataTable is used to store to add  Historcial Cost deatils
            /// </summary>
            public System.Data.DataTable dt_HCEditVestWise = new System.Data.DataTable("HCEditVestWise");

            /// <summary>
            ///  DataTable is used to store to add  Historcial Cost deatils vestwise
            /// </summary>
            public System.Data.DataTable dt_Add_VestWise_details = new System.Data.DataTable();

            /// <summary>
            /// 
            /// </summary>
            public string IsParameterCheck = string.Empty;

            /// <summary>
            /// used to store the parameter name 
            /// </summary>
            public string PARAMETER_NAME = string.Empty;

            /// <summary>
            /// Datatble is used for  the selected parameters in add gridview
            /// </summary>
            public System.Data.DataTable dt_SelectedForParameter = new System.Data.DataTable("SelectedForParameter");

            /// <summary>
            /// This is selected datatables in add gridview for grantwise
            /// </summary>
            public System.Data.DataTable dt_SelectedParmsFilter = new System.Data.DataTable("SelectedParmsFilter");

            /// <summary>
            /// This is selected datatables in add gridview for grantwise
            /// </summary>
            public System.Data.DataTable dt_SelectedParmameter = new System.Data.DataTable("SelectedParameter");

            /// <summary>
            /// used to store the OPT_Grant_ID 
            /// </summary>
            public string OPT_Granted_ID = string.Empty;

            /// <summary>
            /// This is selected datatables in add gridview for grantwise
            /// </summary>
            public System.Data.DataTable dt_Maintaind_HCost = new System.Data.DataTable();

            /// <summary>
            /// This is selected datatables for edit the maintained HC Details
            /// </summary>
            public System.Data.DataTable dt_Edit_Maintaind_HCost = new System.Data.DataTable("Edit_Maintaind_HCost");

            /// <summary>
            /// This is used to store operation date
            /// </summary>
            public string Cost_As_On = string.Empty;

            /// <summary>
            ///  Data table for Customized View for Historical Cost.
            /// </summary>
            public System.Data.DataTable dt_CustmizedViewHistoricalCost = new System.Data.DataTable();

            /// <summary>
            /// This is used to store columns name
            /// It represent name of column for which you want to select records
            /// </summary>
            public string[] selectedColumnsForHC = new[] { "COST_AS_PER_SYSTEM", "EMPID", "UPDATECOST", "ADJUSTMENT_ENTRY", "ATMDID", "FINAL_COST", "HC_PID" };

            /// <summary>
            /// This is used to store columns name
            /// </summary>
            public string[] selectedColumnsForVest = new[] { "OPT_GRANTED_ID", "VPD_VESTING_PERIOD_ID", "VPD_VESTING_DATE", "COST_AS_PER_SYSTEM", "H_COST_MANUALLY", "COST_AS_PER_SYSTEM_BY_FV", "COST_AS_PER_SYSTEM_BY_IV" };  //It represent name of column for which you want to select records

            /// <summary>
            ///  DataTable is used to store Copen Cost deatils  
            /// </summary>
            public System.Data.DataTable dt_Report_details = new System.Data.DataTable("ReportDetails");

            /// <summary>
            /// This is used to store columns name
            /// </summary>
            public string[] selectedColumnsForRDetails = new[] { "AGRMID", "OPT_GRANTED_ID", "Grant Date", "Total Compensation Cost", "GRANT_OPTION_ID", "VPD_VESTING_PERIOD_ID", "2009-2010", "2010-2011", "2011-2012", "2012-2013", "2013-2014" };  //It represent name of column for which you want to select records

            /// <summary>
            /// This is used to store operation date
            /// </summary>
            public bool b_IsLocked = false;

            /// <summary>
            /// String variable
            /// </summary>
            public string s_OPGlist = string.Empty;
        }

        /// <summary>
        /// Abstract class of Employee Master page.
        /// </summary>
        public abstract class AC_EmployeeMaster
        {
            /// <summary>
            /// Data table for Employee master UI.
            /// </summary>
            public System.Data.DataTable dt_EmployeeMasterUIText = new System.Data.DataTable();
            /// <summary>
            ///  Data table for Employee's Details.
            /// </summary>
            public System.Data.DataTable dt_EmployeeDataList = new System.Data.DataTable();

            /// <summary>
            ///  Data table for Employee's history Details.
            /// </summary>
            public System.Data.DataTable dt_EmployeeHistoryData = new System.Data.DataTable();

            /// <summary>
            /// Flag to check if it is a first selection or repeted one.
            /// </summary>
            public bool IsFirstSelection = true;

            /// <summary>
            ///  Data table for Customized View for Employee Master.
            /// </summary>
            public System.Data.DataTable dt_CustmizedViewEmpMaster = new System.Data.DataTable();

            /// <summary>
            /// array string used to store Column Names 
            /// </summary>
            public string[] s_ColumnsName;
        }

        /// <summary>
        /// Abstract Class of ForfeitureSetup
        /// </summary>
        public abstract class AC_ForfeitureSetup
        {
            #region TAB#1 Forfeiture Group Creation

            /// <summary>
            /// DatatTable variable used to store forfeiture setup UI
            /// </summary>
            public System.Data.DataTable dt_ForfeitureSetupUI = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Forfeiture Setup Details
            /// </summary>
            public System.Data.DataSet ds_ForfeitureSetupDetails = new System.Data.DataSet();

            /// <summary>
            /// DatatTable variable used to store Forfeiture Edit Details
            /// </summary>
            public System.Data.DataSet ds_ForfeitureEditDetails = new System.Data.DataSet();

            /// <summary>
            /// DatatTable variable used to store Forfeiture Setup Details
            /// </summary>
            public System.Data.DataTable dt_ForfeitureSetupDetails = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Associated Employees List
            /// </summary>
            public System.Data.DataTable dt_AssociatedEmployeesList = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store All Employees List
            /// </summary>
            public System.Data.DataTable dt_AllEmployeesList = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Selected Employees List
            /// </summary>
            public System.Data.DataTable dt_SelectedEmployeesList = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Selected Employees List
            /// </summary>
            public System.Data.DataTable dt_SelectedFGEmployeesList = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store All Forfeiture Documents
            /// </summary>
            public System.Data.DataTable dt_AllForfeitureDocuments = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Forfeiture Documents
            /// </summary>
            public System.Data.DataTable dt_ForfeitureDocuments = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Forfeiture History Data
            /// </summary>
            public System.Data.DataTable dt_ForfeitureHistoryData = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store All Employees List
            /// </summary>
            public System.Data.DataTable dt_ReviewerDetails = new System.Data.DataTable();

            /// <summary>
            /// bool to store Edit Rights
            /// </summary>
            public bool b_IsEditRights = false;

            /// <summary>
            /// bool to store Delete Rights
            /// </summary>
            public bool b_IsDeleteRights = false;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_PageIndex = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_PageSize = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public int n_GridViewRecordsCount = 0;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public string s_FromAndToSelected = string.Empty;

            /// <summary>
            /// Set gridview record count
            /// </summary>
            public string s_hdnFGCForfrGrpIDToEdit = string.Empty;

            /// <summary>
            /// Set Type used in Forfeiture Group
            /// </summary>
            public string s_Type = string.Empty;
            #endregion

            #region TAB#2 Forfeiture Rate Settings

            /// <summary>
            /// DatatTable variable used to store Forfeiture Rate Settings
            /// </summary>
            public System.Data.DataSet ds_ForfeitureRateSettings = new System.Data.DataSet();

            /// <summary>
            /// DatatTable variable used to store Forfeiture Rate Settings
            /// </summary>
            public System.Data.DataTable dt_FRSDetails = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Forfeiture Rate Settings history data
            /// </summary>
            public System.Data.DataTable dt_FRSHistoryData = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Forfeiture Rate Settings
            /// </summary>
            public System.Data.DataTable dt_ForfeitreRteSettgsToApprve = new System.Data.DataTable();

            #endregion

            #region TAB#3 Forfeuiture Rate Calculations

            /// <summary>
            /// DatatTable variable used to store Forfeiture Setup Details
            /// </summary>
            public System.Data.DataTable dt_ForfeitureCalcReport = new System.Data.DataTable();

            #endregion
        }

        /// <summary>
        /// Abstract Class of AcceleratedVesting
        /// </summary>
        public abstract class AC_AcceleratedVesting
        {
            /// <summary>
            ///  Data table for Accelerated Vesting UI.
            /// </summary>
            public System.Data.DataTable dt_AcceleratedVestingUI = new System.Data.DataTable();

            /// <summary>
            ///  Data table for Accelerated Vesting Data.
            /// </summary>
            public System.Data.DataTable dt_AcceleratedVestingData = new System.Data.DataTable();

            /// <summary>
            ///  Data table for Accelerated Vesting Data.
            /// </summary>
            public System.Data.DataTable dt_AcceleratedVestingDataVestwise = new System.Data.DataTable();

            /// <summary>
            ///  Data table for Accelerated Vesting Data[Option Details].
            /// </summary>
            public System.Data.DataTable dt_ODAcceleratedVestingGrantWise = new System.Data.DataTable();

            /// <summary>
            ///  Data table for Accelerated Vesting Data[Option Details].
            /// </summary>
            public System.Data.DataTable dt_ODAcceleratedVestingVestWise = new System.Data.DataTable();

            /// <summary>
            ///  Data table to save Accelerated Vesting Data.
            /// </summary>
            public System.Data.DataTable dt_SaveAcceleratedVestingVestWise = new System.Data.DataTable("dt_SaveAcceleratedVestingVestWise");

            /// <summary>
            ///  Data table to save Accelerated Vesting Data.
            /// </summary>
            public System.Data.DataTable dt_SaveAcceleratedVesting = new System.Data.DataTable("dt_SaveAcceleratedVesting");

            /// <summary>
            /// Used to set True is user clicked on Edit Button
            /// </summary>
            public bool b_IsEdit = false;

            /// <summary>
            ///  Data table for Customized View for Employee Master.
            /// </summary>
            public System.Data.DataTable dt_CustmizedViewAcceVesting = new System.Data.DataTable();
        }

        /// <summary>
        /// Abstract Class of AC_CorporateActionAdjustment
        /// </summary>
        public abstract class AC_CorporateActionAdjustment
        {
            /// <summary>
            /// The Datatable to store the Role Priviledges of an User
            /// </summary>
            public System.Data.DataTable dt_RolePreviledges = new System.Data.DataTable();

            /// <summary>
            /// The Datatable to store Corporate Action Adjustment UI
            /// </summary>
            public System.Data.DataTable dt_CorpActionAdjUI = new System.Data.DataTable();

            /// <summary>
            /// The Datatable to store Corporate Action GridView Data
            /// </summary>
            public System.Data.DataTable dt_CorpActAdj = new System.Data.DataTable();

            /// <summary>
            /// The DataSet used to store Update Corporate Action GridView Datatables
            /// </summary>
            public System.Data.DataSet ds_UpdateCorpActAdj = new System.Data.DataSet();

            /// <summary>
            /// The Datatable to store Update Corporate Action GridView Data
            /// </summary>
            public System.Data.DataTable dt_UpdateCorpActAdj = new System.Data.DataTable();

            /// <summary>
            /// The Datatable to store Update Corporate Action Vestwise GridView Data
            /// </summary>
            public System.Data.DataTable dt_UpdateCorpActAdjVestwise = new System.Data.DataTable();

            /// <summary>
            /// The Datatable to store Corporate Action Shadow Data
            /// </summary>
            public System.Data.DataTable dt_SavedCorpActAdjShadow = new System.Data.DataTable();

            /// <summary>
            /// The Datatable to store Corporate Action Vestwise Shadow Data
            /// </summary>
            public System.Data.DataTable dt_SavedCorpActAdjVestwiseShadow = new System.Data.DataTable();

            /// <summary>
            /// This string is used to store label for Pre-Corporate Action Fair Value or Intrinsic Value
            /// </summary>
            public string s_PreCorpActFVIV;

            /// <summary>
            /// This string is used to store value for Pre-Corporate Action Fair Value or Intrinsic Value
            /// </summary>
            public string s_PreCorpActFVIVVal;

            /// <summary>
            /// This string is used to store label for Compensation Cost Pre-Corporate Action By FV or By IV
            /// </summary>
            public string s_ComCostPreCorpActByFVIV;

            /// <summary>
            /// This string is used to store value for Compensation Cost Pre-Corporate Action By FV or By IV
            /// </summary>
            public string s_ComCostPreCorpActByFVIVVal;

            /// <summary>
            /// This string is used to store label for Post-Corporate Action Fair Value or Intrinsic Value
            /// </summary>
            public string s_PostCorpActFVIV;

            /// <summary>
            /// This string is used to store value for Post-Corporate Action Fair Value or Intrinsic Value
            /// </summary>
            public string s_PostCorpActFVIVVal;

            /// <summary>
            /// This string is used to store label for Compensation Cost Post-Corporate Action By FV or By IV
            /// </summary>
            public string s_ComCostPostCorpActByFVIV;

            /// <summary>
            /// This string is used to store value for Compensation Cost Post-Corporate Action By FV or By IV
            /// </summary>
            public string s_ComCostPostCorpActByFVIVVal;

            /// <summary>
            /// This string is used to store Event Name of Corporate Action whetherit is PreCorpAct or PostCorpAct
            /// </summary>
            public string s_PopUpEventName;

            /// <summary>
            /// The Datatable to Save the Corporate Action Grant Options Data
            /// </summary>
            public System.Data.DataTable dt_CorpActGrantedOptionsShadow = new System.Data.DataTable();

            /// <summary>
            /// The Datatable to Save the Corporate Action Vestwise Grant Options Data
            /// </summary>
            public System.Data.DataTable dt_CorpActVestGrantedOptionsShadow = new System.Data.DataTable();

            /// <summary>
            /// The Temporary DataTable used to Save the Corporate Action Vestwise Grant Options Data
            /// </summary>
            public System.Data.DataTable dt_TempCorpActVestGrantedOptionsShadow = new System.Data.DataTable();

            /// <summary>
            /// This is used to store vest count
            /// </summary>
            public int n_VestCount;

            /// <summary>
            /// The Temporary DataTable used to Save the Data Updated date
            /// </summary>
            public System.Data.DataTable dt_DataUpdatedOn = new System.Data.DataTable();
        }

        /// <summary>
        /// Abstract Class of Accounting Report
        /// </summary>
        public abstract class AC_AccountingReport
        {
            /// <summary>
            /// DatatTable variable used to store Report Details
            /// </summary>
            public System.Data.DataSet ds_ReportDetails = new System.Data.DataSet();

            /// <summary>
            /// DatatTable variable used to store Report Filters
            /// </summary>
            public System.Data.DataSet ds_ReportFilters = new System.Data.DataSet();

            /// <summary>
            /// DatatTable variable used to store Accounting Report UI
            /// </summary>
            public System.Data.DataTable dt_AccountingReportUI = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Report Details
            /// </summary>
            public System.Data.DataTable dt_ReportDetails = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Main Report Details
            /// </summary>
            public System.Data.DataTable dt_MainReportDetails = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Report Valuation Params
            /// </summary>
            public System.Data.DataSet ds_ReportValuationParams = new System.Data.DataSet();

            /// <summary>
            /// DatatTable variable used to store Report Valuation Params
            /// </summary>
            public System.Data.DataTable dt_ReportValuationParams = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Vesting Details
            /// </summary>
            public System.Data.DataTable dt_VestingDetails = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Accounting Report Data
            /// </summary>
            public System.Data.DataTable dt_AccountingReportData = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Uploaded Files
            /// </summary>
            public System.Data.DataTable dt_UploadedFiles = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Comments History
            /// </summary>
            public System.Data.DataTable dt_CommentsHistory = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store All Grants
            /// </summary>
            public System.Data.DataTable dt_AllGrants = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Version Details
            /// </summary>
            public System.Data.DataTable dt_VersionDetails = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Compensation Cost Details
            /// </summary>
            public System.Data.DataTable dt_CompensationCostDetails = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Summary Report
            /// </summary>
            public System.Data.DataTable dt_SummaryReport = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Summary Report
            /// </summary>
            public System.Data.DataTable dt_MainReport = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Comment Log
            /// </summary>
            public System.Data.DataTable dt_CommentLog = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Reviewer Details
            /// </summary>
            public System.Data.DataTable dt_ReviewerDetails = new System.Data.DataTable();

            /// <summary>
            /// Variable used to store report date
            /// </summary>
            public string s_ReportDate = string.Empty;

            /// <summary>
            /// variable to store Fair Value
            /// </summary>
            public string s_FairValue = string.Empty;

            /// <summary>
            /// variable to store Final Value
            /// </summary>
            public string s_FinalValue = string.Empty;

            /// <summary>
            /// string variable used to store IVFV
            /// </summary>
            public string s_CorpActFVIV = string.Empty;

            /// <summary>
            /// string variable used to store IV or FV Value
            /// </summary>
            public string s_CorpActFVIVVal = string.Empty;
            /// <summary>
            /// variable to store Vest Count
            /// </summary>
            public int n_VestCount;

            /// <summary>
            /// variable to store
            /// </summary>
            public int n_RowCount;

            /// <summary>
            /// variable to store Selected Grants
            /// </summary>
            public string s_Selected_Opt_GrantIDs;

            /// <summary>
            /// variable to store Reporting Date
            /// </summary>
            public string s_Reporting_Date;

            /// <summary>
            /// variable to store GroupID 
            /// </summary>
            public string s_GroupID = "0";

            /// <summary>
            /// variable to store Version No
            /// </summary>
            public int n_VersionNo = 1;

            /// <summary>
            /// variable to store File Name To Download
            /// </summary>
            public string s_FileNameToDownload = "";

            /// <summary>
            /// variable to store Client Approval Status
            /// </summary>
            public int n_ClientApprovalStatus = 0;

            /// <summary>
            /// variable to store Reviewer Approval Status
            /// </summary>
            public int n_ReviewerApprovalStatus = 0;

            /// <summary>
            ///  Data table for Customized View for Accounting.
            /// </summary>
            public System.Data.DataTable dt_CustmizedViewAccounting = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Previous Locked Report Details
            /// </summary>
            public System.Data.DataSet ds_PrevLockedReport = new System.Data.DataSet();

            /// <summary>
            /// DatatTable variable used to store Reconciliation Report Details
            /// </summary>
            public System.Data.DataSet ds_ReconReport = new System.Data.DataSet();

            /// <summary>
            /// Dataset is used to store the Accounting Parameters Details
            /// </summary>
            public System.Data.DataSet ds_AccountingParams = new System.Data.DataSet();

            /// <summary>
            /// Dataset is used to store the Accounting Report Grant(s) and Locked Valution Report Grant(s)
            /// </summary>
            public System.Data.DataSet ds_ValidateLockGrant = new System.Data.DataSet();

            /// <summary>
            ///  Data table for Customized View for Accounting Report.
            /// </summary>
            public System.Data.DataTable dt_CustmizedViewAccReport = new System.Data.DataTable();

            /// <summary>
            /// used to store GOP List
            /// </summary>
            public string s_GOPIDList = string.Empty;

            /// <summary>
            /// DatatTable variable used to store Summary Report
            /// </summary>
            public System.Data.DataTable dt_SummaryDReport = new System.Data.DataTable();

            /// <summary>
            /// DatatTable variable used to store Report Details
            /// </summary>
            public System.Data.DataSet ds_CompCostReportDetails = new System.Data.DataSet();

            /// <summary>
            /// used to store GOP List
            /// </summary>
            public string s_ReportName = string.Empty;
        }

        /// <summary>
        /// Abstract class for Modifications page.
        /// </summary>
        public abstract class AC_Modifications
        {
            /// <summary>
            /// Data table for Modification UI.
            /// </summary>
            public System.Data.DataTable dt_ModificationsUIText = new System.Data.DataTable();

            /// <summary>
            /// Data table for Modification data.
            /// </summary>
            public System.Data.DataTable dt_Get_Modification_details = new System.Data.DataTable();

            /// <summary>
            /// Data table for Modification grantwise.
            /// </summary>
            public System.Data.DataTable dt_Populate_Modification_Grantwise = new System.Data.DataTable();

            /// <summary>
            /// Data table forModification vestwise.
            /// </summary>
            public System.Data.DataTable dt_Populate_Modification_details = new System.Data.DataTable();

            /// <summary>
            /// Data table for Modification calculated values.
            /// </summary>
            public System.Data.DataTable dt_Calculated_IV_FV_details = new System.Data.DataTable();

            /// <summary>
            /// Data table for Modification menu data.
            /// </summary>
            public System.Data.DataTable dt_LoadMenuData = new System.Data.DataTable();

            /// <summary>
            /// Data table for Modification input output data.
            /// </summary>
            public System.Data.DataTable dt_ModificationInput_Outputs = new System.Data.DataTable();

            /// <summary>
            /// Data table for Modification Pre Mod data.
            /// </summary>
            public System.Data.DataTable dt_Pre_Modification_Details = new System.Data.DataTable();

            /// <summary>
            /// Column index number of AGRMID when populating data in grid.
            /// </summary>
            public int n_AGRMIDIndex = 0;

            /// <summary>
            /// Column index number of AGDID when populating data in grid.
            /// </summary>
            public int n_AGDIDIndex = 0;

            /// <summary>
            /// Column index number of EMPID when populating data in grid.
            /// </summary>
            public int n_EMPIDIndex = 0;

            /// <summary>
            /// Column index number of Exercise price when populating data in grid.
            /// </summary>
            public int n_ExerPriceIndex = 0;

            /// <summary>
            /// Column index number of Exercise period when populating data in grid.
            /// </summary>
            public int n_ExerPeriodIndex = 0;

            /// <summary>
            /// Column index number of vesting period when populating data in grid.
            /// </summary>
            public int n_VestPeriodIndex = 0;

            /// <summary>
            /// Column index number of IV Incremental when populating data in grid.
            /// </summary>
            public int n_IVIncremental = 0;

            /// <summary>
            /// Column index number of FV Incremental when populating data in grid.
            /// </summary>
            public int n_FVIncremental = 0;

            /// <summary>
            /// Col Names and sequence for Input datatable for calculations
            /// </summary>
            public string[] s_ColumnNames = { "AGRMID", "AGDID", "EXERCISE_PRICE", "EXERCISE_PERIOD", "VESTING_PERIOD", "IV_INCREMENTAL", "FV_INCREMENTAL", "OPTION_INTRISIC_VALUE", "OPTION_FAIR_VALUE", "OPT_GRANTED_ID", "GRANT_OPTION_ID", "EMPID", "VPD_VESTING_PERIOD_ID", "VPD_VESTING_DATE", "GRANTED_OPTIONS", "CANCELLED_OPTIONS", "VESTED_CANCELLED_OPTIONS", "UNVESTED_CANCELLED_OPTIONS", "LAPSED_OPTIONS", "EXERCISED_OPTIONS", "UNVESTED_OPTIONS", "VESTED_AND_EXERCISABLE", "OUTSTANDING_OPTIONS", "COST_AS_PER_SYSTEM", "Vesting Period Number", "OPERATION_ID", "OPERATION_DATE", "PRE_POST_MOD", "CREATED_BY", "OPT_VEST_ID", "REPORTING_DATE", "COST_IV", "COST_FV", "IV_INCREMENTAL_COST", "FV_INCREMENTAL_COST", "IS_IV_INPUT_MANUAL", "IS_FV_INPUT_MANUAL" };

            /// <summary>
            /// Col Names and sequence for Input datatable for calculations
            /// </summary>
            public string[] s_EmployeeVestWise_ColumnNames = { "AGRMID", "OPT GRANTED ID", "EMPID", "Employee Id", "Employee Name", "Vesting Schedule", "Grant Date", "Grant Registration ID", "Grant Option ID", "CURRENCY NAME", "EXERCISE PRICE" };

            /// <summary>
            /// Col Names and sequence for compensation cost default data.
            /// </summary>
            public string[] s_CCost_ColumnNames = { "OPT GRANTED ID", "AGRMID", "EMPID", "Employee Id", "Employee Name", "Scheme Name", "Grant Date", "Grant Registration ID", "Grant Option ID", "Outstanding", "Outstanding Options Post Modification", "COST AS PER SYSTEM BY IV", "Iv Post Modification Cost", "Iv Incremental Cost", "IV / Options", "COST AS PER SYSTEM BY FV", "Fv Post Modification Cost", "Fv Incremental Cost", "FV / Options" };

            /// <summary>
            /// Compensation cost Common columns.
            /// </summary>
            public string[] s_CCost__Common = { "AGRMID", "EMPID", "Employee Id", "Employee Name", "Vesting Schedule", "Scheme Name", "Grant Date", "Grant Registration ID", "Grant Option ID" };

            /// <summary>
            /// Compensation cost grantwise
            /// </summary>
            public string[] s_CCost__GrantWise = { "OPT GRANTED ID", "AGRMID", "EMPID", "Employee Id", "Employee Name", "Scheme Name", "Grant Date", "Grant Registration ID", "Grant Option ID", "INTRINSIC VALUE", "FAIR VALUE" };

            /// <summary>
            /// Compensation cost vestwise
            /// </summary>
            public string[] s_CCost__VestWise = { "OPT_VEST_ID", "OPT GRANTED ID", "AGRMID", "EMPID", "Employee Id", "Employee Name", "Scheme Name", "Grant Date", "Grant Registration ID", "Vesting Period Number", "Grant Option ID", "Outstanding", "COST AS PER SYSTEM BY IV", "COST AS PER SYSTEM BY FV", "INTRINSIC VALUE", "FAIR VALUE", "Granted" };

            /// <summary>
            /// This string contails all the AGMID whose data has been modified by grant level modification.
            /// </summary>
            public string s_AGMID = string.Empty;

            /// <summary>
            /// This string contails all the AGMID whose data has been modified by grant level modification.
            /// </summary>
            public bool b_Valdation_Status = false;

            /// <summary>
            /// This string contails all the AGMID whose data has been modified by grant level modification.
            /// </summary>
            public bool b_IsFirst_Entry = true;

            /// <summary>
            /// This string contails error message of invalid inputs.
            /// </summary>
            public string s_ListofInvalidInputs = string.Empty;

            /// <summary>
            /// This bit contains the status whether there is any modification in the current details.
            /// </summary>
            public bool b_IsModification = false;

            /// <summary>
            /// This variable is used to set the Enable property of imagebuttons like "edit image button"
            /// </summary>
            public bool b_IsEnabled = false;

            /// <summary>
            /// This variable is used to set the Enable property of imagebuttons like "edit image button"
            /// </summary>
            public string s_IsGrantModified = string.Empty;

            /// <summary>
            /// This variable is used to store the modification date for combined modification."
            /// </summary>
            public DateTime s_ModificationDate_Combined = DateTime.Now;

            /// <summary>
            /// Data table for Joint Modification grantwise.
            /// </summary>
            public System.Data.DataTable dt_Populate_Joint_Modification_Grantwise = new System.Data.DataTable();

        }

        /// <summary>
        /// Abstract class of Tracking Details page.
        /// </summary>
        public abstract class AC_TrackingDetails
        {
            /// <summary>
            /// Data table for Tracking Details UI.
            /// </summary>
            public System.Data.DataTable dt_Tracking_detailsUIText = new System.Data.DataTable();

            /// <summary>
            /// Data table for Tracking Master details data.
            /// </summary>
            public System.Data.DataTable dt_Get_Tracking_details = new System.Data.DataTable();

            /// <summary>
            /// Data table for Filterd tracking data.
            /// </summary>
            public System.Data.DataTable dt_FilteredDataTable = new System.Data.DataTable();
        }

        /// <summary>
        /// 
        /// </summary>
        public abstract class AC_SummaryWorkings
        {
            /// <summary>
            /// DataTable is used to store Page UI  text
            /// </summary>
            public System.Data.DataTable dt_SummaryWorkingsUI = new System.Data.DataTable();

            /// <summary>
            /// DataSet is used to store Historcial Cost deatils
            /// </summary>
            public System.Data.DataSet ds_SummaryWorkings = new System.Data.DataSet();

            /// <summary>
            /// DataTable is used to store Page UI  text
            /// </summary>
            public System.Data.DataTable dt_MainReport = new System.Data.DataTable();

            /// <summary>
            /// DataTable is used to store SchemeWise details
            /// </summary>
            public System.Data.DataTable dt_MainReportDetails = new System.Data.DataTable();

            /// <summary>
            /// DataSet is used to store Schemewise deatils
            /// </summary>
            public System.Data.DataSet ds_ReportDetails = new System.Data.DataSet();

            /// <summary>
            /// int variable is used to store row Count
            /// </summary>
            public int n_RowCount = 0;

            /// <summary>
            /// DataTable is used to store Page UI  text
            /// </summary>
            public string s_Scheme = string.Empty;
        }

        /// <summary>
        /// Mass upload variable declaration
        /// </summary>
        public abstract class AC_MassUpload
        {
            /// <summary>
            ///  Data table for Mass upload UI.
            /// </summary>
            public System.Data.DataTable dt_MassUploadUI = new System.Data.DataTable();
        }

        /// <summary>
        /// Abstract Class of AccountingScheduledReports
        /// </summary>
        public abstract class AC_AccountingScheduledReports
        {
            /// <summary>
            ///  Data table for Mass upload UI.
            /// </summary>
            public System.Data.DataTable dt_AccountingScheduledReportsUI = new System.Data.DataTable();

            /// <summary>
            ///  Data table for Mass upload UI.
            /// </summary>
            public System.Data.DataTable dt_AccountingScheduledReports = new System.Data.DataTable();
        }
        #endregion

        #region Common Method
        /// <summary>
        /// Method is used to send exception message to team
        /// </summary>
        /// <param name="s_ErrorMessage">Provide Error message</param>
        public static void SendExceptionMail(string s_ErrorMessage)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                // Write error in Event Viewer
                CaughtExeptionInEventViewer(s_ErrorMessage);

                genericServiceClient.SendExceptionMail(s_ErrorMessage);
            }
        }

        /// <summary>
        /// Method is used to write exception in Event Viewer
        /// </summary>
        /// <param name="s_ErrorMessage"></param>
        public static void CaughtExeptionInEventViewer(string s_ErrorMessage)
        {
            //var cs = "EDFinancials";
            //var elog = new EventLog();

            //if (!EventLog.SourceExists(cs))
            //{
            //    EventLog.CreateEventSource(cs, cs);
            //}

            //elog.Source = cs;
            //elog.EnableRaisingEvents = true;
            //elog.WriteEntry(s_ErrorMessage, EventLogEntryType.Error, 1);
        }

        /// <summary>
        /// Replaces single quote (') with two (2) single quotes ('')
        /// solves the problem of inserting, updating or selecting a text with single quote (')
        /// </summary>
        /// <param name="s_Parameter">Any String Parameter</param>
        /// <returns>Return update string Parameter</returns>
        public static string ReplaceApostrophe(string s_Parameter)
        {
            // If the string is null or Empty
            if (string.IsNullOrEmpty(s_Parameter))
                return s_Parameter;

            s_Parameter = s_Parameter.Replace("'", "''").Replace("“", "\"").Replace("”", "\"").Replace("-", "-").Replace("—", "-").Replace("’", "''").Replace("‘", "''");
            return s_Parameter;
        }

        /// <summary>
        /// This method is used to Generate Random Password
        /// </summary>
        /// <returns>Return string as New Password</returns>
        public static string GenerateRandomPassword()
        {
            string s_randomString = "GhYZjiFoEt";
            string s_randomPassword = "";
            Random random = new Random();

            for (int i = 0; i < 3; i++)
            {
                s_randomPassword = s_randomPassword + random.Next(0, 9).ToString();
                s_randomPassword = s_randomPassword + s_randomString.ToCharArray()[random.Next(0, 9)];

            }

            return s_randomPassword;
        }

        /// <summary>
        /// Return true if session expired or user gets logged out
        /// </summary>
        public static bool IsSessionExpired()
        {
            using (MenuMasterModel menuMasterModel = new MenuMasterModel())
            {
                if (menuMasterModel.IsSessionInvalid())
                {
                    HttpContext.Current.Response.Redirect("~/View/Login.aspx", false);
                    return true;
                }
                return false;
            }
        }

        /// <summary>
        /// Method is used to get employee role priviledges for the screen
        /// </summary>
        /// <param name="genericProperties">this is  Page object</param>
        /// <returns>Retrun type Date Table</returns>
        public static System.Data.DataTable GetEmployeeRolePriviledges(GenericProperties genericProperties)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                return (System.Data.DataTable)genericServiceClient.GetEmployeeRolPriviledges(genericProperties);
            }
        }

        /// <summary>
        /// This method checks for whether the given paasword is according to standard or not.
        /// </summary>
        /// <param name="s_NewPassword">new password input</param>
        /// <returns>returns string error text to be printed</returns>
        public static string[] ValidatePasswordPattern(string s_NewPassword)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                string[] IsPasswordValid = new string[3];
                SuperAdminProperties superAdminProperties = new SuperAdminProperties();
                SessionContext.UserSessionInfo userSessionInfo;
                userSessionInfo = SessionContext.GetUserSessionInfoValues();
                superAdminProperties.Action = "PASSWORD_PATTERN";
                superAdminProperties.PageName = "ChangePassword";
                superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (System.Data.DataTable dt_PasswordConfig = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties).dt_Result)
                {
                    int iMinLength = Convert.ToInt32(dt_PasswordConfig.Rows[0]["MinLength"].ToString());
                    int iMaxLength = Convert.ToInt32(dt_PasswordConfig.Rows[0]["MaxLength"].ToString());
                    int iUppercase = Convert.ToInt32(dt_PasswordConfig.Rows[0]["MinUppercaseChar"].ToString());
                    int iNumber = Convert.ToInt32(dt_PasswordConfig.Rows[0]["MinNumbers"].ToString());
                    int iAlphabets = Convert.ToInt32(dt_PasswordConfig.Rows[0]["MinAlphabets"].ToString());
                    int iSpecialChar = Convert.ToInt32(dt_PasswordConfig.Rows[0]["MinSplChar"].ToString());
                    int iPassHistory = Convert.ToInt32(dt_PasswordConfig.Rows[0]["CountOfPassHistory"].ToString());


                    ////For Minimum & Maximum password length
                    if (s_NewPassword != "" && s_NewPassword.Length < iMinLength && iMinLength > 0)
                    {
                        IsPasswordValid[0] = "PasswordMinLengthStart";
                        IsPasswordValid[1] = iMinLength.ToString();
                        IsPasswordValid[2] = "PasswordMinLengthEnd";
                        return IsPasswordValid;
                    }

                    if (s_NewPassword != "" && s_NewPassword.Length > iMaxLength && iMaxLength > 0)
                    {
                        IsPasswordValid[0] = "PasswordMaxLengthStart";
                        IsPasswordValid[1] = iMaxLength.ToString();
                        IsPasswordValid[2] = "PasswordMaxLengthEnd";
                        return IsPasswordValid;
                    }

                    //For Uppercase
                    if (s_NewPassword != "" && (CommonModel.CountUpperCaseChars(s_NewPassword) < iUppercase) && iUppercase > 0)
                    {
                        IsPasswordValid[0] = "PasswordMustHave";
                        IsPasswordValid[1] = iUppercase.ToString();
                        IsPasswordValid[2] = "PasswordUpperCase";
                        return IsPasswordValid;
                    }

                    //For Numbers
                    if (s_NewPassword != "" && (CommonModel.CountNumbers(s_NewPassword) < iNumber) && iNumber > 0)
                    {
                        IsPasswordValid[0] = "PasswordMustHave";
                        IsPasswordValid[1] = iNumber.ToString();
                        IsPasswordValid[2] = "PasswordNumbers";
                        return IsPasswordValid;
                    }

                    //For Alphabets
                    if (s_NewPassword != "" && (CommonModel.CountAlphabets(s_NewPassword) < iAlphabets) && iAlphabets > 0)
                    {
                        IsPasswordValid[0] = "PasswordMustHave";
                        IsPasswordValid[1] = iAlphabets.ToString();
                        IsPasswordValid[2] = "PasswordAlphabets";
                        return IsPasswordValid;
                    }

                    //For Special Characters
                    if (s_NewPassword != "" && (CommonModel.CountSpecialChars(s_NewPassword) < iSpecialChar) && iSpecialChar > 0)
                    {
                        IsPasswordValid[0] = "PasswordMustHave";
                        IsPasswordValid[1] = iSpecialChar.ToString();
                        IsPasswordValid[2] = "PasswordSpecialChars";
                        return IsPasswordValid;
                    }
                    return IsPasswordValid;
                }
            }
        }

        /// For Uppercase
        /// <summary>
        /// This method Counts number of uppercase letter in password
        /// </summary>
        /// <param name="strToCheck"></param>
        /// <returns>password string to be checked</returns>
        public static int CountUpperCaseChars(string strToCheck)
        {
            int iCountUpper = 0;
            for (int i = 0; i < strToCheck.Length; i++)
            {
                string sr = Convert.ToString(strToCheck[i]);
                Match m = Regex.Match(sr, "^[A-Z]*$");
                if (m.Success)
                {
                    iCountUpper = iCountUpper + 1;
                }
            }
            return iCountUpper;
        }

        /// For Numbers
        /// <summary>
        /// This method Counts numbers in password
        /// </summary>
        /// <param name="strToCheck"></param>
        /// <returns>password string to be checked</returns>
        public static int CountNumbers(string strToCheck)
        {
            int iCountNum = 0;
            for (int i = 0; i < strToCheck.Length; i++)
            {
                string sr = Convert.ToString(strToCheck[i]);
                Match m = Regex.Match(sr, "^[1-9]*$");
                if (m.Success)
                {
                    iCountNum = iCountNum + 1;
                }
            }
            return iCountNum;
        }

        /// For Alphabets
        /// <summary>
        /// This method Counts number of alphabets in password
        /// </summary>
        /// <param name="strToCheck"></param>
        /// <returns>password string to be checked</returns>
        public static int CountAlphabets(string strToCheck)
        {
            int iCountAlpha = 0;
            for (int i = 0; i < strToCheck.Length; i++)
            {
                string sr = Convert.ToString(strToCheck[i]);
                Match m = Regex.Match(sr, "[^a-zA-Z]");
                if (!m.Success)
                {
                    iCountAlpha = iCountAlpha + 1;
                }
            }
            return iCountAlpha;
        }

        /// For Special Characters
        /// <summary>
        /// This method Counts number of special characters in password
        /// </summary>
        /// <param name="strToCheck"></param>
        /// <returns>password string to be checked</returns>
        public static int CountSpecialChars(string strToCheck)
        {
            int iCountSplChars = 0;
            for (int i = 0; i < strToCheck.Length; i++)
            {
                string sr = Convert.ToString(strToCheck[i]);
                Match m = Regex.Match(sr, "^[!@#$%^&*_()-/.,<>|?;:]$");
                if (m.Success)
                {
                    iCountSplChars = iCountSplChars + 1;
                }
            }
            return iCountSplChars;
        }

        /// <summary>
        /// This method is used to clear All logged session
        /// </summary>
        public void ClearAllSession()
        {
            SessionContext.UserSessionInfo userSessionInfo;
            userSessionInfo = SessionContext.GetUserSessionInfoValues();
            userSessionInfo.ACC_UserID = 0;
            userSessionInfo.ACC_UerTypeID = 0;
            userSessionInfo.ACC_UserName = string.Empty;
            userSessionInfo.ACC_CompanyName = string.Empty;
        }

        /// <summary>
        /// This method takes a numeric value in string format and returns a thousand rounding comma separated numeric figure in string format.
        /// </summary>
        /// <param name="s_Number">Number to be processed for  thousand formatting</param>
        /// <param name="n_RoundingLimit">Rounding limits</param>
        /// <returns>returns formated value in string format</returns>
        public static string ThousandFormating(string s_Number, string n_RoundingLimit)
        {
            try
            {
                string s_FormatedString = string.Empty;
                string s_DecimalFormat = "N" + n_RoundingLimit;
                if (Convert.ToDouble(s_Number) > 999.99)
                {
                    if (!(string.IsNullOrEmpty(s_Number)))
                    {
                        s_FormatedString = String.Format("{0:#,#.######}", Convert.ToDouble(s_Number));
                        s_FormatedString = Convert.ToDouble(s_FormatedString).ToString(s_DecimalFormat);
                    }
                }
                return (string.IsNullOrEmpty(s_FormatedString) ? s_Number : s_FormatedString);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method gets all the decimal rounding limits from the respective sql table.
        /// </summary>
        /// <param name="adminProperties">Admin Properties for reading data</param>
        /// <param name="ACC_CompanyName">Login company / database name</param>
        /// <param name="adminCRUDProperties">Admin CRUD parameters</param>
        /// <returns>returns DataTable having rounding limits</returns>
        public static System.Data.DataTable GetRoundingLimit(AdminProperties adminProperties, string ACC_CompanyName, AdminCRUDProperties adminCRUDProperties)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.SEN_CompanyName = ACC_CompanyName;
                    adminProperties.PopulateControl = "BindDefaultDataToPage";
                    adminProperties.Action = "BindDefaultData";
                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_DecimalValueSettings, CommonConstantModel.s_AdminRead, adminProperties);

                    return adminCRUDProperties.dt_Result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method gives a decimal rounded value according to decimal limit defined by Admin.
        /// </summary>
        /// <param name="s_RoundingValue">Value to be rounded</param>
        /// <param name="n_RoundingLimit">Rounding limits</param>
        /// <returns>returns rounded string value</returns>
        public static string GetRoundedValue(string s_RoundingValue, string n_RoundingLimit)
        {
            try
            {
                string s_DecimalFormat = "N" + n_RoundingLimit.ToString();
                return Convert.ToDouble(s_RoundingValue).ToString(s_DecimalFormat);

            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="label">The label control object</param>
        /// <param name="textBox">The text-box control object</param>
        /// <param name="button">The button control object</param>
        /// <param name="checkBox">The CheckBox control object</param>
        /// <param name="radioButton">radiobutton control object</param>
        /// <param name="ReqValidator">validator control object</param>
        /// <param name="RegExpValidator">validator control object</param>
        /// <param name="RangeValidator">validator control object</param>
        /// <param name="gridView">grid-view control object</param>
        /// <param name="hyperLink">hyperLink control object</param>
        public static void BindPropertiesToControl(string s_cntrlType, System.Data.DataTable Dt_Get_L10N_UI, Label label, TextBox textBox, Button button, System.Web.UI.WebControls.CheckBox checkBox, RadioButton radioButton, BaseValidator ReqValidator, BaseValidator RegExpValidator, BaseValidator RangeValidator, GridView gridView, HyperLink hyperLink)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeCheckBox:
                    checkBox.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelName"]);
                    checkBox.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRadioButton:
                    radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                    radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRangeValidator:
                    RangeValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RangeValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    gridView.EmptyDataText = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + gridView.ID + "'"))[0]["LabelName"]);
                    break;

                case CommonConstantModel.s_cntrlTypeHyperLink:
                    hyperLink.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + hyperLink.ID + "'"))[0]["LabelName"]);
                    hyperLink.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + hyperLink.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeTextBox:
                    break;
            }
        }

        /// <summary>
        /// This method is used to get default view
        /// </summary>
        /// <param name="userSessionInfo">UserSessionInfo object</param>
        /// <param name="PageName">Page Name</param>
        /// <param name="s_ViewPageName">View page name</param>
        /// <returns>DataTable</returns>
        public static DataTable GetDefaultViewList(EDFinancials.Model.SessionContext.UserSessionInfo userSessionInfo, string PageName, string s_ViewPageName)
        {
            try
            {
                AccountingProperties accountingProperties = new AccountingProperties();
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "LOAD_DEFAULT_VIEW";
                    accountingProperties.PageName = PageName;
                    accountingProperties.s_CustomizeViewPageName = s_ViewPageName;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;

                    using (DataTable dt_LoadMasterDataToDropDown = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result)
                    {
                        return dt_LoadMasterDataToDropDown;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method will check Adding / Editing Any Data (Accounting Parmaters,Forfieture Rate eg.) against Locked Accounting Report 
        /// case 1:- if Accounting Report is Locked and user 
        ///          is trying to add a data which Apllicable Date entered is before the Locked Reporting Date
        /// case 2:- if Report is locked and user is editing the parametrs
        ///          which falls under Locked Accounting Report.
        /// Then the User is not allowed to add/edit the respective Data
        /// </summary>
        /// <param name="s_Date">string Applicable Date</param>
        /// <param name="userSessionInfo">userSessionInfo data</param>
        /// <returns>bool Count of Locked Reporting Date(s) Greater than Resp. Date</returns>
        public static bool CheckAgainstLockedAccountingReport(string s_Date, EDFinancials.Model.SessionContext.UserSessionInfo userSessionInfo)
        {
            try
            {
                bool b_chkGrantIsLocked = false;
                AccountingProperties accountingProperties = new AccountingProperties();
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_ReportFilters;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.Type = "REPORT_DATA";

                    using (DataTable dt_ReportData = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[0].Copy())
                    {
                        if (dt_ReportData != null && dt_ReportData.Rows.Count > 0 && dt_ReportData.Select("IS_LOCKED = 1").Count() > 0)
                        {
                            b_chkGrantIsLocked = (!string.IsNullOrEmpty(s_Date)) ? Convert.ToDateTime(s_Date) <= dt_ReportData.AsEnumerable()
                                                                                    .Where(b => b.Field<string>("IS_LOCKED") == "1")
                                                                                    .Max(c => c.Field<DateTime>("Accounting Report Date")) : false;
                        }
                    }
                }

                return b_chkGrantIsLocked;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to check pending parameters in Locking case of report.
        /// </summary>
        /// <param name="s_Date">Date object which needs to check</param>
        /// <param name="userSessionInfo">userSessionInfo object</param>
        /// <returns></returns>
        public static int CheckPendingAccParmsAccountingReport(string s_Date, EDFinancials.Model.SessionContext.UserSessionInfo userSessionInfo)
        {
            try
            {
                int n_chkParms = 0;
                AccountingProperties accountingProperties = new AccountingProperties();
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_Get_Pending_ACCParms;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.REPORTING_DATE = s_Date;

                    using (DataTable dt_ReportData = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[0].Copy())
                    {
                        if (dt_ReportData != null && dt_ReportData.Rows.Count > 0)
                        {
                            n_chkParms = Convert.ToInt32(dt_ReportData.Rows[0]["IS_APPROVED"].ToString());
                        }
                    }
                }

                return n_chkParms;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to get missing market prices for Volatility
        /// </summary>
        /// <param name="s_GrantDate">GrantDate</param>
        /// <param name="VestingPeriodID">VestingPeriodID</param>
        /// <param name="s_CompanyName">CompanyName</param>
        /// <param name="valuationServiceClient">ValuationServiceClient</param>
        /// <param name="valuationProperties">ValuationProperties</param>
        /// <returns>DataTable</returns>
        public static System.Data.DataTable GetMissingVolatilityDates(string s_GrantDate, int VestingPeriodID, string s_CompanyName, ValuationServiceClient valuationServiceClient, ValuationProperties valuationProperties)
        {
            valuationProperties.SEN_CompanyName = s_CompanyName;
            valuationProperties.PageName = CommonConstantModel.s_MissingVolatility;
            valuationProperties.Operation = CommonConstantModel.s_OperationRead;
            valuationProperties.Grant_ID = s_GrantDate;
            valuationProperties.VPD_Vest_ID = VestingPeriodID;
            return valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result;
        }

        /// <summary>
        ///  This method is used to check Parameter changne or not. 
        /// </summary>
        /// <param name="s_considerFor"></param>
        /// <param name="userSessionInfo"></param>
        /// <returns></returns>
        public static int IsParamChange(string s_considerFor, EDFinancials.Model.SessionContext.UserSessionInfo userSessionInfo)
        {
            int val = 0;
            ValuationProperties valuationProperties = new ValuationProperties();
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                valuationProperties.PageName = CommonConstantModel.s_CheckParamChange;
                valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                valuationProperties.s_ConsiderFor = s_considerFor;
                valuationProperties.SEN_UserID = userSessionInfo.ACC_UserID;

                val = valuationServiceClient.CRUDValuationOperations(valuationProperties).a_result;
            }

            return val;
        }

        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CommonModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion

        #endregion
    }
}
