﻿using System;
using System.Web;

namespace EDFinancials.Model.Generic
{
    /// <summary>
    /// 
    /// </summary>
    public class CommonConstantModel : IDisposable
    {
        #region Common Constants
        /// <summary>
        /// 
        /// </summary>
        public const string s_OperationRead = "READ";

        /// <summary>
        /// 
        /// </summary>
        public const string s_OperationCUD = "CUD";

        /// <summary>
        /// 
        /// </summary>
        public const string s_IntrinsicValue = "INV";

        /// <summary>
        /// 
        /// </summary>
        public const string s_FairValue = "FRV";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MarketPrice = "MKP";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ExercisePrice = "EXP";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ExpectedLife = "EXL";

        /// <summary>
        /// 
        /// </summary>
        public const string s_Volatility = "VOL";

        /// <summary>
        /// 
        /// </summary>
        public const string s_RiskFreeInterestRate = "RFIR";

        /// <summary>
        /// 
        /// </summary>
        public const string s_DividendYield = "DVY";

        /// <summary>
        /// 
        /// </summary>
        public static string s_ServerName = HttpContext.Current.Request.Url.Host.ToString() + ":" + HttpContext.Current.Request.Url.Port.ToString();

        /// <summary>
        /// 
        /// </summary>
        public static string s_VirtualDirName = HttpRuntime.AppDomainAppVirtualPath.ToString();

        /// <summary>
        /// 
        /// </summary>
        public static string s_ReportsURL = HttpContext.Current.Request.Url.Scheme.ToString() + "://" + s_ServerName + "/" + s_VirtualDirName + "/View/Reports/Reports.aspx?";

        /// <summary>
        /// common constatnt used to perform view operation
        /// </summary>
        public const string s_VIEW = "VIEW";

        /// <summary>
        /// common constatnt used to perform ADD operation
        /// </summary>
        public const string s_ADD = "ADD";

        /// <summary>
        /// common constatnt used to perform EDIT operation
        /// </summary>
        public const string s_EDIT = "EDIT";

        /// <summary>
        /// common constant used to perform DELETE operation
        /// </summary>
        public const string s_DELETE = "DELETE";

        /// <summary>
        /// common constant used to perform DELETE operation
        /// </summary>
        public const string s_PageName = "DELETE";

        /// <summary>
        /// This string is used to store Company Name and User Name in the Exception Mail Alert
        /// </summary>
        public static string s_ExceptCompUserName = "Company : @" + "\n" + "User : *";
        #endregion

        #region SuperAdmin Constants
        /// <summary>
        /// 
        /// </summary>
        public const string s_CompanyCreation = "CompanyCreation";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ChangePassword = "ChangePassword";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ManageCountries = "ManageCountries";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ManageCurrencies = "ManageCurrencies";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ManageForfeitureGroup = "ManageForfeitureGroup";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ManageModule = "ManageModule";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ManageRFIR = "ManageRFIR";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ManageStockExchange = "ManageStockExchange";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ManageSubModule = "ManageSubModule";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ManageAdminUsers = "ManageAdminUsers";

        /// <summary>
        /// 
        /// </summary>
        public const string s_StatusReport = "StatusReport";

        /// <summary>
        /// 
        /// </summary>
        public const string s_LoadL10N_UI = "SAP_L10N_UI.xml";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AssociateModule = "AssociateModule";

        /// <summary>
        /// Help Page Constant
        /// </summary>
        public const string s_Help = "Help";

        #endregion

        #region Admin Constants
        /// <summary>
        /// 
        /// </summary>
        public const string s_AdminRead = "Read";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AdminCUD = "CUD";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AdminL10_UI = "AP_L10N_UI.xml";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AdminL10 = "AP_L10N.xml";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AdManageCountries = "ManageCountries";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AdResetPassword = "ResetPassword";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ManageUsers = "ManageUsers";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AdManageCurrencies = "ManageCurrencies";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AdCompanySetup = "CompanySetup";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AdManageRoles = "ManageRoles";

        /// <summary>
        /// 
        /// </summary>
        public const string s_DecimalValueSettings = "DecimalValueSettings";

        #endregion

        #region Valuation Constants
        /// <summary>
        /// 
        /// </summary>
        public const string s_ValuationL10_UI = "VALUATION_L10N_UI.xml";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ValuationL10 = "VALUATION_L10N.xml";

        /// <summary>
        /// 
        /// </summary>
        public const string s_CompanyInformation = "CompanyInformation";

        /// <summary>
        /// 
        /// </summary>
        public const string s_CorporateAction = "CorporateAction";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MarketPriceSetup = "MarketPriceSetup";

        /// <summary>
        /// 
        /// </summary>
        public const string s_DividendSetup = "DividendSetup";

        /// <summary>
        /// 
        /// </summary>
        public const string s_RiskFreeInterestRateSetup = "RiskFreeInterestRateSetup";

        /// <summary>
        /// 
        /// </summary>
        public const string s_PeerCompanySetup = "PeerCompanySetup";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ValuationParameter = "ValuationParameter";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ReportFormat = "ReportFormat";

        /// <summary>
        /// 
        /// </summary>
        public const string s_GrantDetails = "GrantDetails";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ValuationReport = "ValuationReport";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ValuationParameters = "ValuationParameters";

        /// <summary>
        /// 
        /// </summary>
        public const string s_CommentDetails = "CommentDetails";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MaintainVersion = "MAINTAINVERSION";

        /// <summary>
        /// 
        /// </summary>
        public const string s_WorkflowStatus = "WorkflowStatus";

        /// <summary>
        /// 
        /// </summary>
        public const string s_GrantLevelSettings = "GrantLevelSettings";

        /// <summary>
        /// 
        /// </summary>
        public const string s_GetReportParams = "GetReportParams";

        /// <summary>
        /// 
        /// </summary>
        public const string s_GetFinancialYear = "GET_FINANCIAL_YEAR";

        /// <summary>
        /// 
        /// </summary>
        public const string s_ReportParamaters = "ReportParameters";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuCompanyInformation = "Company Information";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuCorporateAction = "Corporate Action";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuMarketPriceSetup = "Market Price";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuDividendSetup = "Dividend";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuRiskFreeInterestRateSetup = "Risk Free Interest Rate";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuPeerCompanySetup = "Peer Company Setup";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuValuationParameter = "Valuation Parameters";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuReportFormat = "Report Format";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuReportParameters = "Report Parameters";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuGrantDetails = "Grant Details";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuValuationReport = "Valuation";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuChangePassword = "Change Password";

        /// <summary>
        /// 
        /// </summary>
        public const string s_MnuAcceleratedVesting = "Accelerated Vesting";

        /// <summary>
        /// 
        /// </summary>
        public const string s_OperationRead_Values = "READ_CALCULATED_VALUES";

        /// <summary>
        /// 
        /// </summary>
        public const string s_DownloadAddins = "DownloadAddins";

        /// <summary>
        /// 
        /// </summary>
        public const string s_SaveCompareComments = "SAVECOMPARECOMMENTS";

        /// <summary>
        /// This constant is used to Unlock Grants
        /// </summary>
        public const string s_UnlockGrants = "UNLOCKGRANTS";

        /// <summary>
        /// _ApproveValuationParams constatnt declaration
        /// </summary>
        public const string s_ApproveValuationParams = "ApproveValuationParams";

        /// <summary>
        /// s_ApproveStatus constatnt declaration
        /// </summary>
        public const string s_ApproveStatus = "APPROVALSTATUS";

        /// <summary>
        /// s_ModEDL constant for Modification and EDL
        /// </summary>
        public const string s_ModEDL = "MOD_EDL";

		/// <summary>
        /// 
        /// </summary>
        public const string s_MissingVolatility = "MISSINGVOLATILITY";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AccCancellationReport = "Accounting - Cancellation Report";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AccSummaryReport = "Accounting - Summary Report";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AccReconciliationReport = "Accounting - Reconciliation Report";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AccountingDefaultView = "Accounting - Default View";

        #endregion

        #region Accounting Constants
        /// <summary>
        /// To save name of ACC_L10N_UI xml file
        /// </summary>
        public const string s_AccountingL10_UI = "ACC_L10N_UI.xml";

        /// <summary>
        /// To save name of ACC_L10N xml file
        /// </summary>
        public const string s_AccountingL10 = "ACC_L10N.xml";

        /// <summary>
        /// To save name of AccountingParameter
        /// </summary>
        public const string s_AccountingParameter = "AccountingParameter";

        /// <summary>
        /// To save the name of AccountingParameter for role purpose
        /// </summary>
        public const string s_MnuAccountingParameter = "Accounting Parameters";

        /// <summary>
        /// To save the name of AccountingParameter for role purpose
        /// </summary>
        public const string s_GetOptionsDetails = "GETOPTIONSDETAILS";

        /// <summary>
        /// To perform CUD operation to Accociate Employees
        /// </summary>
        public const string s_CUDAssociateEmployees = "ASSOCIATEEMPLOYEE";

        /// <summary>
        /// The Financial Year Page Name Constant
        /// </summary>
        public const string s_FinancialYearSetUp = "FinancialYearSetUp";

        /// <summary>
        /// To save the name of FinancialYearSetUp for role purpose
        /// </summary>
        public const string s_MnuFinancialYearSetUp = "Financial Year SetUp";

        /// <summary>
        /// To save name of Historical Cost
        /// </summary>
        public const string s_HistoricalCost = "HistoricalCost";

        /// <summary>
        /// Historical Cost Page Menu Name Contstant.
        /// </summary>
        public const string s_MnuHistoricalCost = "Historical Cost";

        /// <summary>
        /// Employee Master Page Name Contstant.
        /// </summary>
        public const string s_EmployeeMaster = "EmployeeMaster";

        /// <summary>
        /// Employee Master Page Menu Name Contstant.
        /// </summary>
        public const string s_MnuEmployeeMaster = "Employee Master";

        /// <summary>
        /// The Customizable view Page Name Constant
        /// </summary>
        public const string s_CustomizeView = "CustomizeView";

        /// <summary>
        /// Constant is use for check role and rights for the page.
        /// </summary>
        public const string s_MnuCustomizeView = "Customize View";

        /// <summary>
        /// ForfeitureSetup constant declaration
        /// </summary>
        public const string s_ForfeitureSetup = "ForfeitureSetup";

        /// <summary>
        /// ApproveForfeitureGroup constant declaration
        /// </summary>
        public const string s_ApproveForfeitureGroup = "ApproveForfeitureGroup";

        /// <summary>
        /// ForfeitureGroupCreation constant declaration
        /// </summary>
        public const string s_ForfeitureGroupCreation = "FORFEITUREGROUPCREATION";

        /// <summary>
        /// UpdateStatus constant declaration
        /// </summary>
        public const string s_FGCUpdateStatus = "FGC_UPDATE_STATUS";

        /// <summary>
        /// Forfeiture Group Creation constant declaration to retrieve data
        /// </summary>
        public const string s_FGCRead = "FGC_READ";

        /// <summary>
        /// HistoryData constant declaration
        /// </summary>
        public const string s_FGCHistoryData = "FGC_HISTORY_DATA";

        /// <summary>
        ///  Forfeiture Group Creation constant declaration to retrieve history data
        /// </summary>
        public const string s_FGHistoryType = "GROUP_HISTORY";

        /// <summary>
        ///  Forfeiture Rate Settings constant declaration to retrieve data
        /// </summary>
        public const string s_FRSRead = "FRS_READ";

        /// <summary>
        ///  Forfeiture Rate Settings constant declaration to retrieve approval data
        /// </summary>
        public const string s_FRSApprovalData = "FRS_APPROVALDATA";

        /// <summary>
        /// ForfeitureGroupCreation constant declaration
        /// </summary>
        public const string s_ForfeitureRateSettings = "FORFEITURERATESETTINGS";

        /// <summary>
        /// OptionDetails constant declaration
        /// </summary>
        public const string s_GetUpdatedAsOnData = "GET_UPDATED_AS_ON_DATA";

        /// <summary>
        /// OptionDetails constant declaration
        /// </summary>
        public const string s_AddOptionsDocument = "ADD_OPTIONS_DOCUMENT";

        /// <summary>
        /// OptionDetails constant declaration
        /// </summary>
        public const string s_AddOptionsComments = "ADD_OPTIONS_COMMENTS";

        /// <summary>
        /// OptionDetails constant declaration
        /// </summary>
        public const string s_GetOptionsDataOnDate = "GET_OPTIONS_DATA_ON_DATE";

        /// <summary>
        /// OptionDetails constant declaration
        /// </summary>
        public const string s_GetODDocNames = "GET_UPLOADED_DOC_NAMES_OD";

        /// <summary>
        /// OptionDetails constant declaration
        /// </summary>
        public const string s_DeleteOptionsDataOnDate = "DELETE_OPTIONS_DATA_ON_DATE";

        /// <summary>
        /// To save name of AccountingParameter
        /// </summary>
        public const string s_OptionDetails = "OptionDetails";
        
        /// <summary>
        /// To save name of AccountingParameter
        /// </summary>
        public const string s_UpdateAllFlage = "UPDATE_ALL_FUNCTIONALITY";

        /// <summary>
        /// OptionDetails constant declaration
        /// </summary>
        public const string s_GetGrantsWithNoEmp = "GET_GRANTS_WITH_NO_EMP";

        /// <summary>
        /// To save name of AccountingParameter
        /// </summary>
        public const string s_EmpForfeitutreRate = "GET_EMP_FORFEITUTRE_RATE";

        /// <summary>
        /// To save name of AcceleratedVesting
        /// </summary>
        public const string s_AcceleratedVesting = "AcceleratedVesting";

        /// <summary>
        /// Forfeiture Group Creation constant declaration to retrieve data
        /// </summary>
        public const string s_FRCRead = "FRC_READ";

        /// <summary>
        /// The Corporate Action Adjustment Page Name Constant
        /// </summary>
        public const string s_CorporateActionAdjustment = "CorporateActionAdjustment";

        /// <summary>
        /// To save the name of CorporateActionAdjustment for role purpose
        /// </summary>
        public const string s_MnuCorporateActionAdjustment = "Corporate Action Adjustment";

        /// <summary>
        /// Accounting Report constant declaration to retrieve data
        /// </summary>
        public const string s_AccountingReport = "AccountingReport";

        /// <summary>
        /// Accounting Report Page Menu Name Contstant.
        /// </summary>
        public const string s_MnuAccountingReport = "Accounting Report";

        /// <summary>
        /// Accounting Report constant declaration to retrieve data
        /// </summary>
        public const string s_MainReport = "MAIN_REPORT";

        /// <summary>
        /// Accounting Report declaration to retrieve data
        /// </summary>
        public const string s_ReportFilters = "GET_REPORT_FILTERS";

        /// <summary>
        /// Accounting Report declaration to retrieve data
        /// </summary>
        public const string s_ReportValuationParams = "VALUATION_PARAMETERS";

        /// <summary>
        /// Accounting Report constant declaration to retrieve data
        /// </summary>
        public const string s_CUDReportData = "CUD_REPORT_DATA";

        /// <summary>
        /// Accounting Report constant declaration to retrieve data
        /// </summary>
        public const string s_CUDReportDocuments = "CUD_REPORT_DOCUMENTS";

        /// <summary>
        /// Employee Master Page Name Contstant.
        /// </summary>
        public const string s_Modifications = "Modifications";

        /// <summary>
        /// Modifications Page Name Contstant.
        /// </summary>
        public const string s_MnuModifications = "Modifications";

        /// <summary>
        /// TrackingDetails Page Name Contstant.
        /// </summary>
        public const string s_TrackingDetails = "TrackingDetails";

        /// <summary>
        /// TrackingDetails Page Name Contstant.
        /// </summary>
        public const string s_MnutrackingDetails = "Tracking Details";

        /// <summary>
        /// Get Vesting Schedule.
        /// </summary>
        public const string s_Get_Vesting_Schedule = "GET_VESTING_SCHEDULE";


        /// <summary>
        /// Get Vesting Schedule.
        /// </summary>
        public const string s_Restrict_Corp_Action_Apply = "RESTRICT_USER_CORP_ACTION_APPLIED";

        /// <summary>
        /// Get Vesting Schedule.
        /// </summary>
        public const string s_Get_Default_View = "GET_DEFAULT_VIEW";

        /// <summary>
        /// Get Vesting Schedule.
        /// </summary>
        public const string s_EM_ViewPageName = "Employee Master";

        /// <summary>
        /// Accounting Report declaration to retrieve data
        /// </summary>
        public const string s_Get_Pending_ACCParms = "GET_PENDING_ACC_PARAMS";

        /// <summary>
        /// Get Vesting Schedule.
        /// </summary>
        public const string s_AR_ViewPageName = "Accounting Report";

		/// <summary>
        /// Accounting Report Parameters
        /// </summary>
        public const string s_Get_Accounting_Parameters = "GET_ACCOUNTING_PARAMETERS";

        /// <summary>
        /// To save name of MassUpload
        /// </summary>
        public const string s_MassUpload = "MassUpload";

        /// <summary>
        /// To check changes in Parameter.
        /// </summary>       
        public const string s_CheckParamChange = "CHECK_PARAM_CHANGE";

        /// <summary>
        /// Accounting Report Subscription
        /// </summary>
        public const string s_ReportSubscription = "SSRSSUBSCRIPTION";

        /// <summary>
        /// Accounting Report Subscription
        /// </summary>
        public const string s_AccountingScheduledReports = "AccountingScheduledReports";
        #endregion

        #region Accounting Controls Constants
        /// <summary>
        /// used to save LABEL control
        /// </summary>
        public const string s_cntrlTypeLabel = "LABEL";
        /// <summary>
        ///  used to save TEXTBOX control
        /// </summary>
        public const string s_cntrlTypeTextbox = "TEXTBOX";

        /// <summary>
        ///  used to save BUTTON control
        /// </summary>
        public const string s_cntrlTypeButton = "BUTTON";
        /// <summary>
        /// used to save DROPDOWN control
        /// </summary>
        public const string s_cntrlTypeDropDown = "DROPDOWN";
        /// <summary>
        ///  used to save CheckBox control
        /// </summary>
        public const string s_cntrlTypeCheckBox = "CheckBox";
        /// <summary>
        ///  used to save RadioButton control
        /// </summary>
        public const string s_cntrlTypeRadioButton = "RadioButton";
        /// <summary>
        ///  used to save REQUIREDFIELDVALIDATOR control
        /// </summary>
        public const string s_cntrlTypeRFValidator = "REQUIREDFIELDVALIDATOR";
        /// <summary>
        ///  used to save RegularExpressionValidator control
        /// </summary>
        public const string s_cntrlTypeRExprValidator = "RegularExpressionValidator";
        /// <summary>
        ///  used to save RRangeValidator control
        /// </summary>
        public const string s_cntrlTypeRangeValidator = "RangeValidator";
        /// <summary>
        /// used to save GRIDVIEW control
        /// </summary>
        public const string s_cntrlTypeGridView = "GRIDVIEW";
        /// <summary>
        /// used to save HYPERLINK control
        /// </summary>
        public const string s_cntrlTypeHyperLink = "HYPERLINK";

        /// <summary>
        ///  used to save TEXTBOX control
        /// </summary>
        public const string s_cntrlTypeTextBox = "TEXTBOX";

        /// <summary>
        ///  used to save web form label control
        /// </summary>
        public const string s_wcLabel = "SYSTEM.WEB.UI.WEBCONTROLS.LABEL";
        /// <summary>
        ///  used to save web form textbox control
        /// </summary>
        public const string s_wcTextbox = "SYSTEM.WEB.UI.WEBCONTROLS.TEXTBOX";
        /// <summary>
        ///  used to save web form button control
        /// </summary>
        public const string s_wcButton = "SYSTEM.WEB.UI.WEBCONTROLS.BUTTON";
        /// <summary>
        ///  used to save web form checkbox control
        /// </summary>
        public const string s_wcCheckbox = "SYSTEM.WEB.UI.WEBCONTROLS.CHECKBOX";
        /// <summary>
        ///  used to save  web form readiobutton  control
        /// </summary>
        public const string s_wcRadiobutton = "SYSTEM.WEB.UI.WEBCONTROLS.RADIOBUTTON";
        /// <summary>
        ///  used to save  web form validator  control
        /// </summary>
        public const string s_wcRequiredFieldValidator = "SYSTEM.WEB.UI.WEBCONTROLS.REQUIREDFIELDVALIDATOR";
        /// <summary>
        ///  used to save  web form validator control
        /// </summary>
        public const string s_wcRugularExpressionValidator = "SYSTEM.WEB.UI.WEBCONTROLS.REGULAREXPRESSIONVALIDATOR";
        /// <summary>
        ///  used to save  web form validator control
        /// </summary>
        public const string s_wcRangeValidator = "SYSTEM.WEB.UI.WEBCONTROLS.RANGEVALIDATOR";
        /// <summary>
        ///  used to save  web form gridview control
        /// </summary>
        public const string s_wcGridview = "SYSTEM.WEB.UI.WEBCONTROLS.GRIDVIEW";
        /// <summary>
        ///  used to save  web form HyperLink control
        /// </summary>
        public const string s_wcHyperLink = "SYSTEM.WEB.UI.WEBCONTROLS.HYPERLINK";
        /// <summary>
        ///  used to save value of seprator 
        /// </summary>
        public const string s_seperator = "|";

        /// <summary>
        /// used to get AccosiateEmployees messages
        /// </summary>
        public const string s_EmployeeAccosiation = "AccosiateEmployeesGD";
        #endregion

        #region Disclosures Constants

        #endregion

        #region SuperAdmin Abstract Class constants

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_CompanyCreation = "AC_CompanyCreation";

        /// <summary>
        /// 
        /// </summary>        
        public const string s_AC_MenuMaster = "AC_MenuMaster";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ManageAdminUsers = "AC_ManageAdminUsers";        

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_StatusReport = "AC_StatusReport";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ManageModule = "AC_ManageModule";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ManageStockExchange = "AC_ManageStockExchange";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ManageCurrency = "AC_ManageCurrency";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ManageCountry = "AC_ManageCountry";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ManageForefeiture = "AC_ManageForefeiture";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ManageRFIR = "AC_ManageRFIR";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ConfigureUI = "AC_ConfigureUI";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ChangeForgetPassword = "AC_ChangeForgetPassword";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_Help = "AC_Help";

        #endregion

        #region Admin Abstract Class constants
        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_CompanySetup = "AC_CompanySetup";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ManageRoles = "AC_ManageRoles";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ManageUser = "AC_ManageUser";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ResetPassword = "AC_ResetPassword";

        #endregion

        #region Valuation Abstract Class Constants

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_CompanyInformation = "AC_CompanyInformation";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_CorporateAction = "AC_CorporateAction";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_DividendSetUp = "AC_DividendSetUp";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_PeerCompanySetup = "AC_PeerCompanySetup";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ValuationParameter = "AC_ValuationParameter";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ReportPamameter = "AC_ReportPamameter";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ReportFormat = "AC_ReportFormat";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_GrantDetails = "AC_GrantDetails";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_ValuationReport = "AC_ValuationReport";

        /// <summary>
        /// 
        /// </summary>
        public const string s_AC_SearchGrantDetails = "AC_SearchGrantDetails";

        /// <summary>
        /// The Help Page Abstract Class Constant
        /// </summary>
        public const string s_AC_ValHelp = "AC_ValHelp";

        /// <summary>
        /// The Approve Valuation Parameters Page Abstract Class Constant
        /// </summary>
        public const string s_AC_ApproveValuationParams = "AC_ApproveValuationParams";
        #endregion

        #region Accounting Abstract Class Constants

        /// <summary>
        /// The Accounting Parameters Page Abstract Class Constant
        /// </summary>
        public const string s_AC_AccountingParameter = "AC_AccountingParameter";

        /// <summary>
        /// The Approve Accounting Parameters Page Abstract Class Constant
        /// </summary>
        public const string s_AC_ApproveAccountingParams = "AC_ApproveAccountingParams";

        /// <summary>
        /// Abstract class constant of FinancialYearSetUp
        /// </summary>
        public const string s_AC_FinancialYearSetUp = "AC_FinancialYearSetUp";

        /// <summary>
        /// The Historical Cost Page Abstract Class Constant
        /// </summary>
        public const string s_AC_HistoricalCost = "AC_HistoricalCost";

        /// <summary>
        /// Employee Master page's Abstract constent.
        /// </summary>
        public const string s_AC_EmployeeMaster = "AC_EmployeeMaster";

        /// <summary>
        /// Constant is used for Customze view abstract class
        /// </summary>
        public const string s_AC_CustomizeView = "AC_CustomizeView";

        /// <summary>
        /// The ForfeitureSetup Page Abstract Class Constant
        /// </summary>
        public const string s_AC_ForfeitureSetup = "AC_ForfeitureSetup";

        /// <summary>
        /// The AcceleratedVesting Page Abstract Class Constant
        /// </summary>
        public const string s_AC_AcceleratedVesting = "AC_AcceleratedVesting";

        /// <summary>
        /// Abstract class constant of CorporateActionAdjustment
        /// </summary>
        public const string s_AC_CorporateActionAdjustment = "AC_CorporateActionAdjustment";

        /// <summary>
        /// The Accounting Report Page Abstract Class Constant
        /// </summary>
        public const string s_AC_AccountingReport = "AC_AccountingReport";

        /// <summary>
        /// Employee Master page's Abstract constent.
        /// </summary>
        public const string s_AC_Modifications = "AC_Modifications";

        /// <summary>
        /// Tracking Details page's Abstract constent.
        /// </summary>
        public const string s_AC_TrackingDetails = "AC_TrackingDetails";

        /// <summary>
        /// The ACC Summary Workings report Page Abstract Class Constant
        /// </summary>
        public const string s_AC_AccSummaryWorkings = "AC_AccSummaryWorkings";

         /// <summary>
        /// The Mass Upload Page Abstract Class Constant
        /// </summary>
        public const string s_AC_MassUpload = "AC_MassUpload";

        /// <summary>
        /// The Mass Upload Page Abstract Class Constant
        /// </summary>
        public const string s_AC_AccountingScheduledReportsWrapper = "AC_AccountingScheduledReportsWrapper";
        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CommonConstantModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}