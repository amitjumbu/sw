﻿using EDFinancials.Model.Generic;

namespace EDFinancials.Model.Masters
{
    /// <summary>
    /// Base model for Masters
    /// </summary>
    public class BaseModel : EDFinancials.Model.BaseModel
    {
        /// <summary>
        /// DEFAULT CONSTRUCTOR
        /// </summary>
        public BaseModel()
        {
            
        }        
    }
}