﻿using EDFinancials.Model.Generic;
using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;
using System.Text;
using System.Linq;

namespace EDFinancials.Model.Masters
{
    /// <summary>
    /// This class Model is used to ManageMenuMaster
    /// </summary>
    public class MenuMasterModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public MenuMasterModel()
        {
            if (ac_MenuMaster == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_MenuMaster);
                ac_MenuMaster = (CommonModel.AC_MenuMaster)HttpContext.Current.Session[CommonConstantModel.s_AC_MenuMaster];
            }
        }

        private bool b_ApplySelectedCSS = false;

        /// <summary>
        /// This method is used to bind the MainMenus
        /// </summary>
        /// <param name="menuMaster">This is menuMaster page object</param>
        internal void BindMainMenus(View.Masters.MenuMaster menuMaster)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.SEN_UerTypeID = userSessionInfo.ACC_UerTypeID;
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;

                    ac_MenuMaster.dt_GetMenus = GetMenus(genericProperties);

                    if ((!userSessionInfo.ACC_IsEmpAccess) && (userSessionInfo.ACC_UerTypeID > 2))
                    {
                        string s_Filters = userSessionInfo.ACC_UerTypeID.Equals(5) ? " MENU_NAME NOT IN ('Employee Master', 'Financial Year SetUp', 'Tracking Details', 'Accounting Parameters','Grant Details - Accounting', 'Accelerated Vesting', 'Corporate Action Adjustment', 'Historical Cost', 'Modifications', 'IGAAP - Data')"
                            : " MENU_NAME NOT IN ('Employee Master', 'Financial Year SetUp', 'Tracking Details', 'Accounting Parameters','Forfeiture Group Setup','Grant Details - Accounting', 'Accelerated Vesting', 'Corporate Action Adjustment', 'Historical Cost', 'Modifications', 'IGAAP - Data')";
                        ac_MenuMaster.dt_GetMenus.DefaultView.RowFilter = s_Filters;
                        ac_MenuMaster.dt_GetMenus = ac_MenuMaster.dt_GetMenus.DefaultView.ToTable();
                    }
                    menuMaster.Accordion_Menu.DataSource = ac_MenuMaster.dt_GetMenus.Select("PARENT_MMID=0").CopyToDataTable().DefaultView;
                    menuMaster.Accordion_Menu.DataBind();
                    menuMaster.lblUserName.Text = userSessionInfo.ACC_UserName + " [Company Name : " + userSessionInfo.ACC_CompanyTitle.ToUpper() + "]";
                    if (ac_MenuMaster.s_LastLoginDetails.Contains("Current Login"))
                    {
                        menuMaster.lblCurrentDateTime.Text = string.IsNullOrEmpty(ac_MenuMaster.s_LastLoginDetails) ? "" : ac_MenuMaster.s_LastLoginDetails + " IST";
                    }
                    else
                    {
                        menuMaster.lblCurrentDateTime.Text = string.IsNullOrEmpty(ac_MenuMaster.s_LastLoginDetails) ? "" : "Last Login : " + ac_MenuMaster.s_LastLoginDetails + " IST";
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind the sub menus for each main menu
        /// </summary>
        /// <param name="e">event args of Accordian control</param>
        internal void ItemDataBound(AjaxControlToolkit.AccordionItemEventArgs e)
        {
            try
            {
                if (e.ItemType == AjaxControlToolkit.AccordionItemType.Content)
                {
                    using (MenuMasterModel menuMasterModel = new MenuMasterModel())
                    {
                        GridView gridView = new GridView();
                        gridView = (GridView)e.AccordionItem.FindControl("gv");
                        gridView.DataSource = (ac_MenuMaster.dt_GetMenus.Select("MENU_NAME <> 'HelpDoc' AND PARENT_MMID=" + ((HiddenField)e.AccordionItem.FindControl("txt_MMID")).Value).Length.Equals(0) ? new DataTable().DefaultView : ac_MenuMaster.dt_GetMenus.Select("MENU_NAME <> 'HelpDoc' AND PARENT_MMID=" + ((HiddenField)e.AccordionItem.FindControl("txt_MMID")).Value).CopyToDataTable().DefaultView).ToTable();
                        DataTable dt_GetMenus = (ac_MenuMaster.dt_GetMenus.Select("MENU_NAME <> 'HelpDoc' AND PARENT_MMID=" + ((HiddenField)e.AccordionItem.FindControl("txt_MMID")).Value).Length.Equals(0) ? new DataTable().DefaultView : ac_MenuMaster.dt_GetMenus.Select("MENU_NAME <> 'HelpDoc' AND PARENT_MMID=" + ((HiddenField)e.AccordionItem.FindControl("txt_MMID")).Value).CopyToDataTable().DefaultView).ToTable();
                        if (dt_GetMenus != null && dt_GetMenus.Rows.Count > 0)
                        {
                            gridView.DataSource = userSessionInfo.ACC_UerTypeID == 3 ? (dt_GetMenus.Select("MMID = ROLE_MMID OR MENU_NAME = 'Help' OR MENU_NAME = 'Logout'").Count() > 0 ? dt_GetMenus.Select("MMID = ROLE_MMID OR MENU_NAME = 'Help' OR MENU_NAME = 'Logout'").CopyToDataTable() : new DataTable()) : dt_GetMenus;
                            gridView.DataBind();
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind the link to the sub menus and set the active mode on the same.
        /// </summary>
        /// <param name="e">event args of Accordian control</param>
        /// <param name="menuMaster">this is menuMaster page object</param>
        internal void RowDataBound(GridViewRowEventArgs e, View.Masters.MenuMaster menuMaster)
        {
            try
            {
                //This is the MENUID and MENU_URL that we need to hide
                e.Row.Cells[0].Visible = false;
                e.Row.Cells[2].Visible = false;
                e.Row.Cells[3].Visible = false;
                e.Row.Cells[4].Visible = false;
                e.Row.Cells[6].Visible = false;

                if (userSessionInfo.ACC_UerTypeID == 3)
                    e.Row.Cells[5].Visible = false;

                #region if the current URL in the browser is mathing with the current row URL then mark the CSS as selected.
                b_ApplySelectedCSS = false;
                if (HttpContext.Current.Request.Url.AbsolutePath.Replace(HttpRuntime.AppDomainAppVirtualPath.ToString().Equals("/") ? "DoNothing" : HttpRuntime.AppDomainAppVirtualPath.ToString(), string.Empty).Equals(e.Row.Cells[2].Text.Replace("~", string.Empty)))
                {
                    menuMaster.Accordion_Menu.SelectedIndex = Convert.ToInt32(ac_MenuMaster.dt_GetMenus.Select("MMID=" + e.Row.Cells[3].Text)[0]["MENU_INDEX"]);

                    if (!(e.Row.Cells[2].Text.Contains(CommonConstantModel.s_ReportParamaters)))
                    {
                        if (!Convert.ToString(HttpContext.Current.Request.Url).Contains("PgName=ReportParameters"))
                            b_ApplySelectedCSS = true;
                    }
                }
                if (Convert.ToString(HttpContext.Current.Request.Url).Contains("PgName=" + CommonConstantModel.s_ReportParamaters) && e.Row.Cells[2].Text.Contains(CommonConstantModel.s_ReportParamaters))
                {
                    b_ApplySelectedCSS = true;
                }
                if (Convert.ToString(HttpContext.Current.Request.Url).Contains("PgName=" + CommonConstantModel.s_ApproveForfeitureGroup) && e.Row.Cells[2].Text.Contains(CommonConstantModel.s_ApproveForfeitureGroup))
                {
                    b_ApplySelectedCSS = true;
                }
                if (Convert.ToString(HttpContext.Current.Request.Url).Contains("PgName=" + CommonConstantModel.s_ApproveForfeitureGroup) && e.Row.Cells[2].Text.Contains(CommonConstantModel.s_ForfeitureSetup))
                {
                    b_ApplySelectedCSS = false;
                }
                #endregion

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    e.Row.Cells[1].Controls.Add(CreateLink(e.Row.Cells[1].Text, e.Row.Cells[2].Text));
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to create a link to the sub menus and set the active/inactive mode on the same.
        /// </summary>
        /// <param name="strText"></param>
        /// <param name="strUrl"></param>
        /// <returns></returns>
        internal HyperLink CreateLink(string strText, string strUrl)
        {
            using (HyperLink hyperLink = new HyperLink())
            {
                hyperLink.Text = strText;
                hyperLink.NavigateUrl = strUrl;
                hyperLink.CssClass = (b_ApplySelectedCSS ? "subMenuActive" : "subMenu");
                return hyperLink;
            }
        }

        /// <summary>
        /// This method is used to fetch the menu of a selected UserTypeID.
        /// </summary>
        /// <param name="genericProperties">this is genericProperties page object</param>
        /// <returns>Returns the list of MainMenu and SubMenu along with URL in DataTable</returns>
        private DataTable GetMenus(GenericProperties genericProperties)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                return genericServiceClient.GetMenus(genericProperties);
            }
        }

        /// <summary>
        /// This method is used to check if the session is a valid session.
        /// </summary>
        /// <returns>Returns True for a valid session.</returns>
        internal bool IsSessionInvalid()
        {
            return userSessionInfo.ACC_UerTypeID.Equals(0);
        }

        /// <summary>
        /// Security Fixes : Broken Access Control. This method validates user to keep only in its own scope of folder. 
        /// Ex -  If a Admin trys to hit a SuperAdmin page link, then system will log him out.
        /// </summary>
        /// <param name="menuMaster">object of menu master page</param>
        internal void CheckaValidUser(View.Masters.MenuMaster menuMaster)
        {
            StringBuilder stringBuilder = new StringBuilder();
            bool b_currentPath = false;
            try
            {
                if (!(HttpContext.Current.Request.Url.AbsolutePath.Equals(CommonModel.AC_MenuMaster.s_PageName)))
                {
                    string[] Virtual_Splited_Path = HttpContext.Current.Request.Url.AbsolutePath.Split('/');

                    for (int i = 0; i < Virtual_Splited_Path.Length; i++)
                    {
                        if (Convert.ToString(Virtual_Splited_Path[i]).Equals("View"))
                        {
                            for (int j = i; j < Virtual_Splited_Path.Length; j++)
                            {
                                 stringBuilder.Append("/");
                                stringBuilder.Append(Convert.ToString(Virtual_Splited_Path[j]));
                            }
                        }
                    }

                    b_currentPath = Convert.ToBoolean(ac_MenuMaster.dt_GetMenus.Select("MENU_URL = '~" + stringBuilder.ToString() + "'")[0]["MMID"]);
                }
            }
            catch (Exception)
            {
                // Invalid user for this scope of folder
                System.Web.HttpContext.Current.Response.Redirect("~/View/Logout.aspx");
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~MenuMasterModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}