﻿using EDFinancials.Model.Generic;
using EDFinancials.View;
using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace EDFinancials.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class ForgetPasswordModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Method is used to bind UI 
        /// </summary>
        /// <param name="forgetPassword">Login Page object</param>
        internal void BindForgotPasswordPageUI(ForgetPassword forgetPassword)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    using (DataSet dataSetLoginUI = genericServiceClient.COMMON_LoadL10N_UI())
                    {
                        if ((dataSetLoginUI != null) && (dataSetLoginUI.Tables.Count > 0) && (dataSetLoginUI.Tables[0].Rows.Count > 0))
                        {
                            forgetPassword.lblFPUserName.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblFPUserName'"))[0]["LabelName"]);
                            forgetPassword.lblFPUserName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblFPUserName'"))[0]["LabelToolTip"]);
                            forgetPassword.valFPUserName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblFPUserName'"))[0]["ErrorText"]);
                            forgetPassword.valFPUserName.SetFocusOnError = true;

                            forgetPassword.lblFPCompanyName.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCompanyName'"))[0]["LabelName"]);
                            forgetPassword.lblFPCompanyName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCompanyName'"))[0]["LabelToolTip"]);
                            forgetPassword.valFPCompanyName.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lblCompanyName'"))[0]["ErrorText"]);
                            forgetPassword.valFPCompanyName.SetFocusOnError = true;

                            forgetPassword.btnFPSubmit.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'btnFPSubmit'"))[0]["LabelName"]);
                            forgetPassword.btnFPSubmit.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'btnFPSubmit'"))[0]["LabelToolTip"]);

                            forgetPassword.lbtnLoginPage.Text = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lbtnLoginPage'"))[0]["LabelName"]);
                            forgetPassword.lbtnLoginPage.ToolTip = Convert.ToString((dataSetLoginUI.Tables[0].Select("LabelID = 'lbtnLoginPage'"))[0]["LabelToolTip"]);

                            forgetPassword.txtFPUserName.Focus();
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used check login user is valid or not
        /// </summary>
        /// <param name="forgetPassword">Login Page object</param>
        /// <returns>return string as Redirect page name for respective user type</returns>
        internal string ValidateLoginUser(ForgetPassword forgetPassword)
        {
            using(GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                try
                {
                    string s_RedirectMessage = string.Empty;

                    using(DataTable dt_LoginInformation = genericServiceClient.ValiadateUserID(forgetPassword.txtFPCompanyName.Text, forgetPassword.txtFPUserName.Text))
                    {
                        if(dt_LoginInformation.Rows.Count > 0)
                        {
                            StringBuilder s_MailBody = new StringBuilder();
                            s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\ForgetPasswordEmail.html"));
                            string n_UsedID = Convert.ToString(dt_LoginInformation.Rows[0]["LOGIN_ID"]);

                            emailProperties.s_MailTo = Convert.ToString(dt_LoginInformation.Rows[0]["EMAIL_ID"]);
                            emailProperties.s_MailFrom = ConfigurationManager.AppSettings["MailFrom"];
                            emailProperties.s_MailSubject = Regex.Match(s_MailBody.ToString(), @"<Title>\s*(.+?)\s*</Title>").Value.
                                                            Replace("\r", "").Replace("<Title>", "").Replace("</Title>", "").Replace("\n", "").Replace("\t", "");
                            emailProperties.s_MailBCC = ConfigurationManager.AppSettings["MailBCC"];
                            emailProperties.s_MailCC = ConfigurationManager.AppSettings["MailCC"];
                            emailProperties.s_MailBody = MailBody(forgetPassword, s_MailBody);
                            emailProperties.b_IsBodyHtml = true;

                            genericServiceClient.SaveSendMail(emailProperties);

                            forgetPassword.main.Visible = true;
                            forgetPassword.Success.Visible = true;
                            forgetPassword.tdErrorMessage.Visible = false;
                            forgetPassword.lblSuccessMsg.Text = new GenericServiceClient().COMMON_LoadL10N("lblSuccessMsg");

                        }
                        else
                        {
                            forgetPassword.tdErrorMessage.Visible = true;
                            forgetPassword.lblFPMessage.ForeColor = System.Drawing.Color.Red;
                            forgetPassword.lblFPMessage.Text = genericServiceClient.COMMON_LoadL10N("LGN_InvalidLogin").Replace("Password", "Company Name");
                        }

                    }


                    return s_RedirectMessage;
                }
                catch
                {
                    forgetPassword.tdErrorMessage.Visible = true;
                    forgetPassword.lblFPMessage.ForeColor = System.Drawing.Color.Red;
                    forgetPassword.lblFPMessage.Text = genericServiceClient.COMMON_LoadL10N("LGN_InvalidLogin").Replace("Password", "Company Name");
                    throw;
                }
            }
        }

        /// <summary>
        /// Append parameters in MailBody
        /// </summary>
        /// <param name="forgetPassword">UI object</param>
        /// <param name="s_MailBody">This is Mail body text.</param>
        /// <returns>Mailbody in for of string</returns>
        public string MailBody(ForgetPassword forgetPassword, StringBuilder s_MailBody)
        {
            try
            {
                string s_EncryptedUserName = new GenericServiceClient().EncryptString(forgetPassword.txtFPUserName.Text);
                string s_EncryptedCompanyName = new GenericServiceClient().EncryptString(forgetPassword.txtFPCompanyName.Text);
                string s_EncryptedDate = new GenericServiceClient().EncryptString(DateTime.Now.ToString("dd-MMM-yyyy"));
                s_MailBody.Replace("@UserName", forgetPassword.txtFPUserName.Text);
                s_MailBody.Replace("@URL", (string.Format(ConfigurationManager.AppSettings["ChangePassword"], forgetPassword.Server.UrlEncode(s_EncryptedCompanyName.Replace("+", "%2B")), forgetPassword.Server.UrlEncode(s_EncryptedUserName.Replace("+", "%2B")), forgetPassword.Server.UrlEncode(s_EncryptedDate.Replace("+", "%2B"))) + "|"));
                s_MailBody.Replace("@EDMail", ConfigurationManager.AppSettings["ValCustSupport"]);
                return s_MailBody.ToString();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ForgetPasswordModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}