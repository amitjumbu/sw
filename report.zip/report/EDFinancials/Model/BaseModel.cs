﻿using EDFinancials.Model.Generic;

namespace EDFinancials.Model
{
    /// <summary>
    /// Base mode for global level
    /// </summary>
    public class BaseModel
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public BaseModel()
        {
            userSessionInfo = SessionContext.GetUserSessionInfoValues();
            emailProperties = new EmailProperties();
            genericProperties = new GenericProperties();
        }

        /// <summary>
        /// PRIVATE DECLARTION FOR USER SESSION INFORMATION
        /// </summary>
        private EDFinancials.Model.SessionContext.UserSessionInfo _userSessionInfo;

        /// <summary>
        /// PUBLIC DECLARTION FOR USER SESSION INFORMATION
        /// </summary>
        public EDFinancials.Model.SessionContext.UserSessionInfo userSessionInfo
        {
            get { return _userSessionInfo; }
            set { _userSessionInfo = value; }
        }

        /// <summary>
        /// PRIVATE DECLARATION FOR GENERIC PROPERTY
        /// </summary>
        private GenericProperties _genericProperties;

        /// <summary>
        /// PUBLIC DECLARATION FOR GENERIC PROPERTY
        /// </summary>        
        public GenericProperties genericProperties
        {
            get { return _genericProperties; }
            set { _genericProperties = value; }
        }       

        /// <summary>
        /// PRIVATE DECLARATION FOR EMAIL PROPERTY
        /// </summary>
        private EmailProperties _emailProperties;

        /// <summary>
        /// PUBLIC DECLARATION FOR EMAIL PROPERTY
        /// </summary>
        public EmailProperties emailProperties
        {
            get { return _emailProperties; }
            set { _emailProperties = value; }
        }

        /// <summary>
        /// OBJECT OF COMPANY CREATION ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_MenuMaster ac_MenuMaster;        

        /// <summary>
        /// OBJECT OF UI CONFIGURATION ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ChangeForgetPassword ac_ChangeForgetPassword;
    }
}