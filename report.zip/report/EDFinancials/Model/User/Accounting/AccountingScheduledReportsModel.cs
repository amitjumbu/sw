﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using Ionic.Zip;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// AccountingScheduledReports Model
    /// </summary>
    public class AccountingScheduledReportsModel : BaseModel, IDisposable
    {
        #region Default constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public AccountingScheduledReportsModel()
        {
            if (ac_AccountingScheduledReports == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_AccountingScheduledReportsWrapper);
                ac_AccountingScheduledReports = (CommonModel.AC_AccountingScheduledReports)HttpContext.Current.Session[CommonConstantModel.s_AC_AccountingScheduledReportsWrapper];
            }
        }
        #endregion

        #region Common Bind Methods
        /// <summary>
        /// This method is used to Bind the all controls
        /// </summary>
        /// <param name="accountingScheduledReports">AccountingScheduledReports page object</param>
        internal void PopulateAllControls(AccountingScheduledReports accountingScheduledReports)
        {
            try
            {
                BindUI(accountingScheduledReports);
            }
            catch
            {
                throw;
            }
        }



        /// <summary>
        /// This method is used to Bind UI controls
        /// </summary>
        /// <param name="accountingScheduledReports">AccountingScheduledReports page object</param>
        internal void BindUI(AccountingScheduledReports accountingScheduledReports)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI == null || ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI.Rows.Count.Equals(0))
                    {
                        ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_AccountingScheduledReports, CommonConstantModel.s_AccountingL10_UI);
                    }

                    if ((ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI != null) && (ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI.Rows.Count > 0))
                    {
                        foreach (Control control in accountingScheduledReports.dvMain.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI, (Label)control);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI, (TextBox)control);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI, (Button)control);
                                    break;

                                case CommonConstantModel.s_wcCheckbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeCheckBox, ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI, (CheckBox)control);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI, (RadioButton)control);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI, (BaseValidator)control);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI, (BaseValidator)control);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_AccountingScheduledReports.dt_AccountingScheduledReportsUI, (GridView)control);
                                    break;
                            }

                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="control">control</param>
        private void BindPropertiesToControl(string s_cntrlType, DataTable Dt_Get_L10N_UI, Control control)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    Label label = (Label)control;
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    Button button = (Button)control;
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeCheckBox:
                    CheckBox checkBox = (CheckBox)control;
                    checkBox.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelName"]);
                    checkBox.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRadioButton:
                    RadioButton radioButton = (RadioButton)control;
                    radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                    radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    RequiredFieldValidator ReqValidator = (RequiredFieldValidator)control;
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegularExpressionValidator RegExpValidator = (RegularExpressionValidator)control;
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    break;

                case CommonConstantModel.s_cntrlTypeTextBox:
                    break;
            }
        }

        #endregion

        #region Bind grid view and grid view events
        /// <summary>
        /// this method is used to get data of AccountingScheduledReports
        /// </summary>
        public void BindGridView(AccountingScheduledReports accountingScheduledReports)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.PageName = CommonConstantModel.s_AccountingScheduledReports;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;

                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                ac_AccountingScheduledReports.dt_AccountingScheduledReports = accountingCRUDProperties.dt_Result;

                accountingScheduledReports.gv.DataSource = ac_AccountingScheduledReports.dt_AccountingScheduledReports;
                accountingScheduledReports.gv.DataBind();
            }
        }

        /// <summary>
        /// This method is used to bind controls to gridview
        /// </summary>
        /// <param name="accountingScheduledReports">AccountingScheduledReports page object</param>
        /// <param name="e">GridViewRowEventArgs for gvSearch</param>
        /// <param name="dictionary">Dictionary contains rows and index</param>
        /// <param name="sender">has some action perform on control</param>
        public void gv_RowDataBound(AccountingScheduledReports accountingScheduledReports, GridViewRowEventArgs e, ref Dictionary<string, int> dictionary, object sender)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    dictionary["n_ID"] = dictionary["n_Index"];
                                    perColumn.Visible = false;
                                    break;

                                case "REPORT AS ON":
                                    dictionary["n_ReportAsOn"] = dictionary["n_Index"];
                                    break;

                                case "SCHEDULE DATE":
                                    dictionary["n_ScheduleDate"] = dictionary["n_Index"];
                                    break;

                                case "REPORT STATUS":
                                    dictionary["n_ReportStatus"] = dictionary["n_Index"];
                                    break;

                                case "MAIL STATUS":
                                    dictionary["n_MailStatus"] = dictionary["n_Index"];
                                    break;

                                case "MAIL ID":
                                    dictionary["n_MailID"] = dictionary["n_Index"];
                                    break;

                                case "REPORT NAME":
                                    dictionary["n_ReportName"] = dictionary["n_Index"];
                                    break;

                                case "DOWNLOAD":
                                    dictionary["n_Download"] = dictionary["n_Index"];
                                    break;

                            }
                            dictionary["n_Index"] = dictionary["n_Index"] + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[Convert.ToInt32(dictionary["n_Download"])].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[Convert.ToInt32(dictionary["n_Download"])].Controls.Add(AddImageLink(e.Row.Cells[Convert.ToInt32(dictionary["n_ReportName"])].Text.Replace(" ", "|"), e.Row.Cells[Convert.ToInt32(dictionary["n_ReportStatus"])].Text));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="ReportName">Report Name</param>
        /// <param name="s_ReportStatus">Report Status</param>
        /// <returns>returns image object</returns>
        private ImageButton AddImageLink(string ReportName, string s_ReportStatus)
        {
            ImageButton img = new ImageButton();

            img.ImageUrl = "~/View/App_Themes/images/download.png";
            img.ToolTip = s_ReportStatus.Equals("Not Generated") ? "Report is not generated" : "Click here to download report";
            img.Enabled = !s_ReportStatus.Equals("Not Generated");
            img.Style.Add("cursor", "pointer");
            img.TabIndex = 8;
            img.Attributes.Add("onclick", "return DownloadFile('" + ReportName + "')");
            return img;

        }

        /// <summary>
        /// The Page Index Change Event
        /// </summary>
        /// <param name="NewPageIndex">NewPageIndex</param>
        /// <param name="accountingScheduledReports">accountingScheduledReports</param>
        internal void PageIndexChanging(int NewPageIndex, AccountingScheduledReports accountingScheduledReports)
        {
            try
            {
                accountingScheduledReports.gv.PageIndex = NewPageIndex;
                accountingScheduledReports.gv.DataSource = ac_AccountingScheduledReports.dt_AccountingScheduledReports;
                accountingScheduledReports.gv.DataBind();
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Download File
        /// <summary>
        /// This method is used to download file from server folder
        /// </summary>
        /// <param name="accountingScheduledReports">AccountingScheduledReports page object</param>
        public void DownloadFile(AccountingScheduledReports accountingScheduledReports)
        {
            try
            {
                if (File.Exists((Convert.ToString(ConfigurationManager.AppSettings["PhysicalFilePath"]) + userSessionInfo.ACC_CompanyTitle + @"\" + Convert.ToString(accountingScheduledReports.hdnFileName.Value.Replace("|", " ")) + ".xlsx")))
                {
                    using (ZipFile zip = new ZipFile())
                    {
                        zip.AddFile((Convert.ToString(ConfigurationManager.AppSettings["PhysicalFilePath"]) + userSessionInfo.ACC_CompanyTitle + @"\" + Convert.ToString(accountingScheduledReports.hdnFileName.Value.Replace("|", " ")) + ".xlsx"), "Excel");

                        HttpContext.Current.Response.Clear();
                        HttpContext.Current.Response.ClearContent();
                        HttpContext.Current.Response.ClearHeaders();
                        HttpContext.Current.Response.Buffer = true;
                        HttpContext.Current.Response.BufferOutput = false;
                        HttpContext.Current.Response.ContentType = "application/zip";

                        HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=AccountingReport.zip");
                        zip.Save(HttpContext.Current.Response.OutputStream);
                        HttpContext.Current.Response.Flush();
                        //Gets or sets a value indicating whether to send HTTP content to the client.
                        HttpContext.Current.Response.SuppressContent = true;
                        // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.  
                        HttpContext.Current.ApplicationInstance.CompleteRequest();
                    }
                }
                else
                {
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        ScriptManager.RegisterStartupScript(accountingScheduledReports, GetType(), "alertMessage", "alert('" + accountingServiceClient.GetAccounting_L10N("lblASRFileNotFound", CommonConstantModel.s_AccountingScheduledReports, CommonConstantModel.s_AccountingL10) + "');", true);
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~AccountingScheduledReportsModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}