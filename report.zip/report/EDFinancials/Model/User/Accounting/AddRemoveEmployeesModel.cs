﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Add Remove Employees Model class
    /// </summary>
    public class AddRemoveEmployeesModel : BaseModel, IDisposable
    {
        #region Default Constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public AddRemoveEmployeesModel()
        {
            if (ac_ForfeitureSetup == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ForfeitureSetup);
                ac_ForfeitureSetup = (CommonModel.AC_ForfeitureSetup)HttpContext.Current.Session[CommonConstantModel.s_AC_ForfeitureSetup];
            }
        }

        #endregion

        #region Page Load Event

        /// <summary>
        /// Page Load Event
        /// </summary>
        /// <param name="addRemoveEmployees">AddRemoveEmployees page object</param>
        /// <param name="s_FGID">s_FGID</param>
        internal void Page_Load(AddRemoveEmployees addRemoveEmployees, string s_FGID)
        {
            try
            {
                BindUI(addRemoveEmployees);
                SetCSS(addRemoveEmployees);
                BindGrids(addRemoveEmployees, true, s_FGID);
                PopulatePagerForGridView(addRemoveEmployees, ac_ForfeitureSetup.n_GridViewRecordsCount, 1, 1);
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Control Events

        /// <summary>
        /// This method is used to bind UI
        /// </summary>
        /// <param name="addRemoveEmployees">AddRemoveEmployees page object</param>
        private void BindUI(AddRemoveEmployees addRemoveEmployees)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_ForfeitureSetup.dt_ForfeitureSetupUI == null || ac_ForfeitureSetup.dt_ForfeitureSetupUI.Rows.Count.Equals(0))
                    {
                        ac_ForfeitureSetup.dt_ForfeitureSetupUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10_UI);
                    }
                    if ((ac_ForfeitureSetup.dt_ForfeitureSetupUI != null) && (ac_ForfeitureSetup.dt_ForfeitureSetupUI.Rows.Count > 0))
                    {
                        foreach (Control control in addRemoveEmployees.divFGCSelectEmployees.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_ForfeitureSetup.dt_ForfeitureSetupUI, (Label)control, null, null, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, (TextBox)control, null, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, (Button)control, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcCheckbox:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeCheckBox, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, (CheckBox)control, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, (RadioButton)control, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, (BaseValidator)control, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, (BaseValidator)control, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, null, null, (GridView)control, null);
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to set CSS styles
        /// </summary>
        /// <param name="addRemoveEmployees">AddRemoveEmployees page object</param>
        private void SetCSS(AddRemoveEmployees addRemoveEmployees)
        {
            try
            {
                addRemoveEmployees.mddlAREEmployeeID.pnlMultiselect.CssClass = addRemoveEmployees.mddlAREDepartmentWise.pnlMultiselect.CssClass = addRemoveEmployees.mddlAREForfeitureGrpName.pnlMultiselect.CssClass = addRemoveEmployees.mddlAREDesignationWise.pnlMultiselect.CssClass = addRemoveEmployees.mddlAREGradeWise.pnlMultiselect.CssClass = "PnlDesignPopup";
                addRemoveEmployees.mddlAREDesignationWise.txtMultiselect.Style.Add("width", "27%");
                addRemoveEmployees.mddlAREDesignationWise.pnlMultiselect.Style.Add("width", "27%");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind grids
        /// </summary>
        /// <param name="addRemoveEmployees">AddRemoveEmployees page object</param>
        /// <param name="b_IsPageLoad">b_IsPageLoad</param>
        /// <param name="s_FGID">s_FGID</param>
        private void BindGrids(AddRemoveEmployees addRemoveEmployees, bool b_IsPageLoad, string s_FGID)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PAGE_SIZE = ac_ForfeitureSetup.n_PageSize.Equals(0) ? 10 : ac_ForfeitureSetup.n_PageSize;
                    accountingProperties.PAGE_INDEX = ac_ForfeitureSetup.n_PageIndex.Equals(0) ? 1 : ac_ForfeitureSetup.n_PageIndex;
                    accountingProperties.PopulateControls = CommonConstantModel.s_FGCRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.FGAID = string.IsNullOrEmpty(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit) ? 0 : (string.IsNullOrEmpty(s_FGID) && ! (string.IsNullOrEmpty(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit)))? 0 : Convert.ToInt32(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit);

                    ac_ForfeitureSetup.ds_ForfeitureSetupDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;

                    if (b_IsPageLoad)
                    {
                        if (!string.IsNullOrEmpty(s_FGID) && Convert.ToInt32(s_FGID) > 0)
                        {
                            ac_ForfeitureSetup.dt_AllEmployeesList = ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[2].Copy();
                            ac_ForfeitureSetup.dt_AssociatedEmployeesList = ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[3].Copy();
                            ac_ForfeitureSetup.dt_SelectedEmployeesList = ac_ForfeitureSetup.dt_SelectedEmployeesList != null && ac_ForfeitureSetup.dt_SelectedEmployeesList.Rows.Count.Equals(0) 
                                                                          ? ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[3].Copy() 
                                                                          :!string.IsNullOrEmpty(s_FGID) ? ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[3].Copy() 
                                                                          :ac_ForfeitureSetup.dt_SelectedEmployeesList;

                        }
                        else
                        {
                            ac_ForfeitureSetup.dt_AllEmployeesList = ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[2].Copy();
                            ac_ForfeitureSetup.dt_AssociatedEmployeesList = ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[3].Copy();
                            ac_ForfeitureSetup.dt_SelectedEmployeesList = ac_ForfeitureSetup.dt_SelectedEmployeesList != null && ac_ForfeitureSetup.dt_SelectedEmployeesList.Rows.Count.Equals(0) ? ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[3].Copy() : ac_ForfeitureSetup.dt_SelectedEmployeesList;
                        }
                    }

                    foreach (DataRow perRow_SelectedEmp in ac_ForfeitureSetup.dt_SelectedEmployeesList.Rows)
                    {
                        foreach (DataRow perRow_AllEmp in ac_ForfeitureSetup.dt_AllEmployeesList.Select("EMPID = '" + perRow_SelectedEmp["EMPID"] + "'"))
                        {
                            perRow_AllEmp.Delete();
                        }
                    }

                    foreach (string perItem in addRemoveEmployees.hdnARECheckedEmpToAdd.Value.Split(','))
                    {
                        if (!string.IsNullOrEmpty(perItem) && ac_ForfeitureSetup.dt_AllEmployeesList.Select("EMPID = '" + perItem + "'").Count() > 0)
                        {
                            ac_ForfeitureSetup.dt_AllEmployeesList.Select("EMPID = '" + perItem + "'")[0]["Select"] = "Delete";
                        }
                    }

                    ac_ForfeitureSetup.n_GridViewRecordsCount = Convert.ToInt32(ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[4].Rows[0]["TOTAL_COUNT"]);
                    addRemoveEmployees.gvAREAllEmployees.DataSource = ac_ForfeitureSetup.dt_AllEmployeesList;
                    addRemoveEmployees.gvAREAllEmployees.DataBind();
                    addRemoveEmployees.gvARESelectedEmployees.DataSource = ac_ForfeitureSetup.dt_SelectedEmployeesList;
                    addRemoveEmployees.gvARESelectedEmployees.DataBind();
                    BindFilters(addRemoveEmployees);

                    if (!b_IsPageLoad)
                        btnAREFilterEmp_Click(addRemoveEmployees, false);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind filters
        /// </summary>
        /// <param name="addRemoveEmployees">AddRemoveEmployees page object</param>
        private void BindFilters(AddRemoveEmployees addRemoveEmployees)
        {
            try
            {
                //addRemoveEmployees.mddlAREDepartmentWise.chkMultiselect.DataSource = (from b in ac_ForfeitureSetup.dt_AllEmployeesList.AsEnumerable()
                //                                                                      where b.Field<string>("DEPARTMENT") != null
                //                                                                      select b.Field<string>("DEPARTMENT")).Distinct();
                //addRemoveEmployees.mddlAREDepartmentWise.chkMultiselect.DataBind();

                //addRemoveEmployees.mddlAREDesignationWise.chkMultiselect.DataSource = (from b in ac_ForfeitureSetup.dt_AllEmployeesList.AsEnumerable()
                //                                                                       where b.Field<string>("DESIGNATION") != null
                //                                                                       select b.Field<string>("DESIGNATION")).Distinct();
                //addRemoveEmployees.mddlAREDesignationWise.chkMultiselect.DataBind();

                //addRemoveEmployees.mddlAREEmployeeID.chkMultiselect.DataSource = (from b in ac_ForfeitureSetup.dt_AllEmployeesList.AsEnumerable()
                //                                                                  where b.Field<string>("Employee ID") != null
                //                                                                  select b.Field<string>("Employee ID")).Distinct();
                //addRemoveEmployees.mddlAREEmployeeID.chkMultiselect.DataBind();

                //addRemoveEmployees.mddlAREForfeitureGrpName.chkMultiselect.DataSource = (from b in ac_ForfeitureSetup.dt_AllEmployeesList.AsEnumerable()
                //                                                                         where b.Field<string>("Group Name") != null
                //                                                                         select b.Field<string>("Group Name")).Distinct();
                //addRemoveEmployees.mddlAREForfeitureGrpName.chkMultiselect.DataBind();

                //addRemoveEmployees.mddlAREGradeWise.chkMultiselect.DataSource = (from b in ac_ForfeitureSetup.dt_AllEmployeesList.AsEnumerable()
                //                                                                 where b.Field<string>("GRADE") != null
                //                                                                 select b.Field<string>("GRADE")).Distinct();
                //addRemoveEmployees.mddlAREGradeWise.chkMultiselect.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add employee(s) button click event
        /// </summary>
        /// <param name="addRemoveEmployees">AddRemoveEmployees page object</param>
        public void imgAREAddEmp_Click(AddRemoveEmployees addRemoveEmployees)
        {
            try
            {
                if (!string.IsNullOrEmpty(addRemoveEmployees.hdnARECheckedEmpToAdd.Value))
                {
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PAGE_SIZE = ac_ForfeitureSetup.n_PageSize.Equals(0) ? 10 : ac_ForfeitureSetup.n_PageSize;
                        accountingProperties.PAGE_INDEX = ac_ForfeitureSetup.n_PageIndex.Equals(0) ? 1 : ac_ForfeitureSetup.n_PageIndex;
                        accountingProperties.PopulateControls = CommonConstantModel.s_FGCRead;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.Employee_Id = addRemoveEmployees.hdnARECheckedEmpToAdd.Value.TrimStart(',');
                        accountingProperties.FGAID = string.IsNullOrEmpty(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit) ? 0 : Convert.ToInt32(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit);
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                        foreach (string item in addRemoveEmployees.hdnARECheckedEmpToAdd.Value.Split(','))
                        {
                            foreach (DataRow row1 in accountingCRUDProperties.ds_Result.Tables[5].Rows)
                            {
                                if (Convert.ToInt32(item) == Convert.ToInt32(row1["EMPID"]))
                                {
                                    ac_ForfeitureSetup.dt_SelectedEmployeesList.Rows.Add(row1.ItemArray);
                                }
                                foreach (DataRow perRowAllEmp in ac_ForfeitureSetup.dt_AllEmployeesList.Select("EMPID = '" +row1["EMPID"]+  "'"))
                                {
                                    perRowAllEmp.Delete();
                                }
                            }
                            ac_ForfeitureSetup.dt_AllEmployeesList.AcceptChanges();
                            ac_ForfeitureSetup.dt_SelectedEmployeesList.AcceptChanges();
                        }
                        addRemoveEmployees.hdnARECheckedEmpToAdd.Value = addRemoveEmployees.hdnARECheckedEmpToRemove.Value = string.Empty;
                    }
                }
                BindGrids(addRemoveEmployees, false, string.Empty);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// remove Employee(s) button click event
        /// </summary>
        /// <param name="addRemoveEmployees">AddRemoveEmployees page object</param>
        public void imgARERemoveEmp_Click(AddRemoveEmployees addRemoveEmployees)
        {
            try
            {
                if (!string.IsNullOrEmpty(addRemoveEmployees.hdnARECheckedEmpToRemove.Value))
                {
                    foreach (string item in addRemoveEmployees.hdnARECheckedEmpToRemove.Value.Split(','))
                    {
                        foreach (DataRow row1 in ac_ForfeitureSetup.dt_SelectedEmployeesList.Rows)
                        {
                            if (Convert.ToInt32(item) == Convert.ToInt32(row1["EMPID"]))
                            {
                                ac_ForfeitureSetup.dt_AllEmployeesList.Rows.Add(row1.ItemArray);
                                row1.Delete();
                            }
                        }
                        ac_ForfeitureSetup.dt_SelectedEmployeesList.AcceptChanges();
                        ac_ForfeitureSetup.dt_AllEmployeesList.AcceptChanges();
                    }
                    addRemoveEmployees.hdnARECheckedEmpToAdd.Value = addRemoveEmployees.hdnARECheckedEmpToRemove.Value = string.Empty;
                }
                BindGrids(addRemoveEmployees, false, string.Empty);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid-view row data bound event
        /// </summary>
        /// <param name="e">event args</param>
        /// <param name="n_EmpIndex">n_EmpIndex</param>
        /// <param name="n_EmpSelect">n_EmpSelect</param>
        /// <param name="n_EMPID">n_EMPID</param>
        /// <param name="n_Employee_ID">n_Employee_ID</param>
        /// <param name="n_Employee_Name">n_Employee_Name</param>
        /// <param name="n_Emp_Group_Name">n_Emp_Group_Name</param>
        /// <param name="n_Emp_Deartment">n_Emp_Deartment</param>
        /// <param name="n_Emp_Grade">n_Emp_Grade</param>
        /// <param name="n_Emp_Designation">n_Emp_Designation</param>
        /// <param name="n_Emp_IS_APPROVAL_PENDING">n_Emp_IS_APPROVAL_PENDING</param>
        public void gvAREAllEmployees_RowDataBound(GridViewRowEventArgs e, ref int n_EmpIndex, ref int n_EmpSelect, ref int n_EMPID, ref int n_Employee_ID, ref int n_Employee_Name, ref int n_Emp_Group_Name, ref int n_Emp_Deartment, ref int n_Emp_Grade, ref int n_Emp_Designation, ref int n_Emp_IS_APPROVAL_PENDING)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SELECT":
                                    perColumn.Text = string.Empty;
                                    perColumn.Controls.Add((Control)AddEmpCheckBox("ALL", "0", "", string.Empty));
                                    n_EmpSelect = n_EmpIndex;
                                    break;
                                case "EMPID":
                                    n_EMPID = n_EmpIndex;
                                    perColumn.Visible = false;
                                    break;
                                case "EMPLOYEE ID":
                                    n_Employee_ID = n_EmpIndex;
                                    break;
                                case "EMPLOYEE NAME":
                                    n_Employee_Name = n_EmpIndex;
                                    break;
                                case "GROUP NAME":
                                    n_Emp_Group_Name = n_EmpIndex;
                                    break;
                                case "DEPARTMENT":
                                    perColumn.Visible = false;
                                    n_Emp_Deartment = n_EmpIndex;
                                    break;
                                case "GRADE":
                                    perColumn.Visible = false;
                                    n_Emp_Grade = n_EmpIndex;
                                    break;
                                case "DESIGNATION":
                                    perColumn.Visible = false;
                                    n_Emp_Designation = n_EmpIndex;
                                    break;
                                case "IS_APPROVAL_PENDING":
                                    perColumn.Visible = false;
                                    n_Emp_IS_APPROVAL_PENDING = n_EmpIndex;
                                    break;
                            }
                            n_EmpIndex++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_EMPID].Visible = e.Row.Cells[n_Emp_IS_APPROVAL_PENDING].Visible = e.Row.Cells[n_Emp_Deartment].Visible = e.Row.Cells[n_Emp_Grade].Visible = e.Row.Cells[n_Emp_Designation].Visible = false;
                        e.Row.Cells[n_EmpSelect].HorizontalAlign = e.Row.Cells[n_Employee_ID].HorizontalAlign = HorizontalAlign.Left;
                        if (e.Row.Cells[n_Emp_IS_APPROVAL_PENDING].Text.Equals("1"))
                            e.Row.Cells[n_EmpSelect].ToolTip = string.Format("You can not associate/assign this employee to the selected group as this employee has already been associated to the pending group ( {0} ) which is not yet approved by the reviewer.", e.Row.Cells[n_Emp_Group_Name].Text.Trim());
                        else e.Row.Cells[n_EmpSelect].Controls.Add((Control)AddEmpCheckBox("ALL", e.Row.Cells[n_EMPID].Text.Trim(), "", e.Row.Cells[n_EmpSelect].Text));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// this method is used to add checkbox control to the grid row
        /// </summary>
        /// <returns>returns CheckBox control object</returns>
        private CheckBox AddEmpCheckBox(string s_Type, string s_EMPID, string s_GroupName, string s_IsDelete)
        {
            try
            {
                using (CheckBox o_CheckBox = new CheckBox())
                {
                    if (!string.IsNullOrEmpty(s_EMPID) && Convert.ToInt32(s_EMPID) > 0)
                    {
                        switch (s_Type.ToUpper())
                        {
                            case "ALL": o_CheckBox.Attributes.Add("onclick", "CheckBoxChk_AllEmp('" + s_EMPID + "',this)"); break;
                            case "SELECTED": o_CheckBox.Attributes.Add("onclick", "CheckBoxChk_SelectedEmp('" + s_EMPID + "',this)"); break;
                            case "APPROVAL_PENDING": o_CheckBox.ToolTip = string.Format("You can not associate/assign this employee to the selected group as this employee has already been associated to the pending group ( {0} ) which is not yet approved by the reviewer.", s_GroupName); o_CheckBox.Enabled = false; break;
                        }
                    }
                    else
                    {
                        switch (s_Type.ToUpper())
                        {
                            case "ALL": o_CheckBox.Attributes.Add("onclick", "AllCheckBoxChk_AllEmp(this)"); break;
                            case "SELECTED": o_CheckBox.Attributes.Add("onclick", "AllCheckBoxChk_SelectedEmp(this)"); break;
                        }
                    }
                    o_CheckBox.InputAttributes.Add("Value", s_EMPID);
                    o_CheckBox.ID = "chk";
                    o_CheckBox.Checked = s_IsDelete.Equals("Delete");
                    o_CheckBox.ClientIDMode = ClientIDMode.Static;
                    o_CheckBox.Style.Add("cursor", "pointer");
                    o_CheckBox.TabIndex = 7;
                    return o_CheckBox;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid-view selected employees row data bound event
        /// </summary>
        /// <param name="e">event args</param>
        /// <param name="n_Ass_EmpIndex">n_Ass_EmpIndex</param>
        /// <param name="n_Ass_EmpSelect">n_Ass_EmpSelect</param>
        /// <param name="n_Ass_EMPID">n_Ass_EMPID</param>
        /// <param name="n_Ass_Employee_ID">n_Ass_Employee_ID</param>
        /// <param name="n_Ass_Employee_Name">n_Ass_Employee_Name</param>
        /// <param name="n_Ass_Emp_Group_Name">n_Ass_Emp_Group_Name</param>
        /// <param name="n_Ass_Emp_Deartment">n_Ass_Emp_Deartment</param>
        /// <param name="n_Ass_Emp_Grade">n_Ass_Emp_Grade</param>
        /// <param name="n_Ass_Emp_Designation">n_Ass_Emp_Designation</param>
        /// <param name="n_Ass_IS_APPROVAL_PENDING">n_Ass_IS_APPROVAL_PENDING</param>
        public void gvARESelectedEmployees_RowDataBound(GridViewRowEventArgs e, ref int n_Ass_EmpIndex, ref int n_Ass_EmpSelect, ref int n_Ass_EMPID, ref int n_Ass_Employee_ID, ref int n_Ass_Employee_Name, ref int n_Ass_Emp_Group_Name, ref int n_Ass_Emp_Deartment, ref int n_Ass_Emp_Grade, ref int n_Ass_Emp_Designation, ref int n_Ass_IS_APPROVAL_PENDING)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SELECT":
                                    perColumn.Text = string.Empty;
                                    perColumn.Controls.Add((Control)AddEmpCheckBox("SELECTED", "0", "", string.Empty));
                                    n_Ass_EmpSelect = n_Ass_EmpIndex;
                                    break;
                                case "EMPID":
                                    n_Ass_EMPID = n_Ass_EmpIndex;
                                    perColumn.Visible = false;
                                    break;
                                case "EMPLOYEE ID":
                                    n_Ass_Employee_ID = n_Ass_EmpIndex;
                                    break;
                                case "EMPLOYEE NAME":
                                    n_Ass_Employee_Name = n_Ass_EmpIndex;
                                    break;
                                case "GROUP NAME":
                                    n_Ass_Emp_Group_Name = n_Ass_EmpIndex;
                                    break;
                                case "DEPARTMENT":
                                    perColumn.Visible = false;
                                    n_Ass_Emp_Deartment = n_Ass_EmpIndex;
                                    break;
                                case "GRADE":
                                    perColumn.Visible = false;
                                    n_Ass_Emp_Grade = n_Ass_EmpIndex;
                                    break;
                                case "DESIGNATION":
                                    perColumn.Visible = false;
                                    n_Ass_Emp_Designation = n_Ass_EmpIndex;
                                    break;
                                case "IS_APPROVAL_PENDING":
                                    perColumn.Visible = false;
                                    n_Ass_IS_APPROVAL_PENDING = n_Ass_EmpIndex;
                                    break;
                            }
                            n_Ass_EmpIndex++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_Ass_EMPID].Visible = e.Row.Cells[n_Ass_IS_APPROVAL_PENDING].Visible = e.Row.Cells[n_Ass_Emp_Deartment].Visible = e.Row.Cells[n_Ass_Emp_Grade].Visible = e.Row.Cells[n_Ass_Emp_Designation].Visible = false;
                        e.Row.Cells[n_Ass_EmpSelect].HorizontalAlign = e.Row.Cells[n_Ass_Employee_ID].HorizontalAlign = HorizontalAlign.Left;
                        e.Row.Cells[n_Ass_EmpSelect].Controls.Add((Control)AddEmpCheckBox("SELECTED", e.Row.Cells[n_Ass_EMPID].Text.Trim(), "", string.Empty));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Employee list search button click event
        /// </summary>
        /// <param name="addRemoveEmployees">AddRemoveEmployees page object</param>
        /// <param name="b_IsClickEvent">b_IsClickEvent</param>
        public void btnAREFilterEmp_Click(AddRemoveEmployees addRemoveEmployees, bool b_IsClickEvent)
        {
            try
            {
                DataTable dt_FilterEmployeeData = ac_ForfeitureSetup.dt_AllEmployeesList.Copy();
                dt_FilterEmployeeData.Clear();
                string s_CheckedFilters = string.Empty;
                string s_EmployeeIDs = SearchEmployeeData(addRemoveEmployees.mddlAREEmployeeID.chkMultiselect, "[Employee ID]", addRemoveEmployees.mddlAREEmployeeID.txtMultiselect);
                string s_ForfeitureGrpNames = SearchEmployeeData(addRemoveEmployees.mddlAREForfeitureGrpName.chkMultiselect, "[Group Name]", addRemoveEmployees.mddlAREForfeitureGrpName.txtMultiselect);
                string s_Departments = SearchEmployeeData(addRemoveEmployees.mddlAREDepartmentWise.chkMultiselect, "[DEPARTMENT]", addRemoveEmployees.mddlAREDepartmentWise.txtMultiselect);
                string s_Grades = SearchEmployeeData(addRemoveEmployees.mddlAREGradeWise.chkMultiselect, "[GRADE]", addRemoveEmployees.mddlAREGradeWise.txtMultiselect);
                string s_Designations = SearchEmployeeData(addRemoveEmployees.mddlAREDesignationWise.chkMultiselect, "[DESIGNATION]", addRemoveEmployees.mddlAREDesignationWise.txtMultiselect);
                if (!string.IsNullOrEmpty(s_EmployeeIDs))
                {
                    if (string.IsNullOrEmpty(s_CheckedFilters))
                        s_CheckedFilters = " ( " + s_EmployeeIDs;
                    else s_CheckedFilters += " AND " + s_EmployeeIDs;
                }
                if (!string.IsNullOrEmpty(s_ForfeitureGrpNames))
                {
                    if (string.IsNullOrEmpty(s_CheckedFilters))
                        s_CheckedFilters = " ( " + s_ForfeitureGrpNames;
                    else s_CheckedFilters += " AND " + s_ForfeitureGrpNames;
                }
                if (!string.IsNullOrEmpty(s_Departments))
                {
                    if (string.IsNullOrEmpty(s_CheckedFilters))
                        s_CheckedFilters = " ( " + s_Departments;
                    else s_CheckedFilters += " AND " + s_Departments;
                }
                if (!string.IsNullOrEmpty(s_Grades))
                {
                    if (string.IsNullOrEmpty(s_CheckedFilters))
                        s_CheckedFilters = " ( " + s_Grades;
                    else s_CheckedFilters += " AND " + s_Grades;
                }

                if (!string.IsNullOrEmpty(s_Designations))
                {
                    if (string.IsNullOrEmpty(s_CheckedFilters))
                        s_CheckedFilters = " ( " + s_Designations;
                    else s_CheckedFilters += " AND " + s_Designations;
                }
                if (!string.IsNullOrEmpty(s_CheckedFilters))
                    s_CheckedFilters += " ) ";
                if (!string.IsNullOrEmpty(s_CheckedFilters))
                {
                    dt_FilterEmployeeData = ac_ForfeitureSetup.dt_AllEmployeesList.Select(s_CheckedFilters).CopyToDataTable();
                    addRemoveEmployees.gvAREAllEmployees.DataSource = dt_FilterEmployeeData;
                    addRemoveEmployees.gvAREAllEmployees.DataBind();
                }
                else if (string.IsNullOrEmpty(s_CheckedFilters) && b_IsClickEvent)
                {
                    addRemoveEmployees.gvAREAllEmployees.DataSource = ac_ForfeitureSetup.dt_AllEmployeesList;
                    addRemoveEmployees.gvAREAllEmployees.DataBind();
                }
                if (b_IsClickEvent)
                {
                    addRemoveEmployees.gvARESelectedEmployees.DataSource = ac_ForfeitureSetup.dt_SelectedEmployeesList;
                    addRemoveEmployees.gvARESelectedEmployees.DataBind();
                }
                dt_FilterEmployeeData.Dispose();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Clear filter button click event
        /// </summary>
        /// <param name="addRemoveEmployees">AddRemoveEmployees page object</param>
        public void btnAREClearFilter_Click(AddRemoveEmployees addRemoveEmployees)
        {
            try
            {
                ClearEmployeeFilters(addRemoveEmployees.mddlAREEmployeeID.chkMultiselect, addRemoveEmployees.mddlAREEmployeeID.txtMultiselect);
                ClearEmployeeFilters(addRemoveEmployees.mddlAREForfeitureGrpName.chkMultiselect, addRemoveEmployees.mddlAREForfeitureGrpName.txtMultiselect);
                ClearEmployeeFilters(addRemoveEmployees.mddlAREDepartmentWise.chkMultiselect, addRemoveEmployees.mddlAREDepartmentWise.txtMultiselect);
                ClearEmployeeFilters(addRemoveEmployees.mddlAREGradeWise.chkMultiselect, addRemoveEmployees.mddlAREGradeWise.txtMultiselect);
                ClearEmployeeFilters(addRemoveEmployees.mddlAREDesignationWise.chkMultiselect, addRemoveEmployees.mddlAREDesignationWise.txtMultiselect);
                addRemoveEmployees.gvARESelectedEmployees.DataSource = ac_ForfeitureSetup.dt_SelectedEmployeesList;
                addRemoveEmployees.gvARESelectedEmployees.DataBind();
                addRemoveEmployees.gvAREAllEmployees.DataSource = ac_ForfeitureSetup.dt_AllEmployeesList;
                addRemoveEmployees.gvAREAllEmployees.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to search employee(s)
        /// </summary>
        /// <param name="checkBoxList">checkBoxList</param>
        /// <param name="s_columnName">s_columnName</param>
        /// <param name="textBox">textBox</param>
        /// <returns>returns selected/checked employee(s)</returns>
        private string SearchEmployeeData(CheckBoxList checkBoxList, string s_columnName, TextBox textBox)
        {
            try
            {
                string s_CheckedItems = string.Empty, s_SetTextBoxVal = string.Empty;
                foreach (ListItem CurrentItem in checkBoxList.Items)
                {
                    if (CurrentItem.Selected)
                    {
                        if (string.IsNullOrEmpty(s_CheckedItems))
                        {
                            s_CheckedItems = "(" + s_columnName + " = '" + CurrentItem.Text.Trim() + "'";
                            s_SetTextBoxVal = CurrentItem.Text.Trim();
                        }
                        else
                        {
                            s_CheckedItems += " OR " + s_columnName + " = '" + CurrentItem.Text.Trim() + "'";
                            s_SetTextBoxVal += "," + CurrentItem.Text.Trim();
                        }
                    }
                }
                if (!string.IsNullOrEmpty(s_CheckedItems))
                {
                    s_CheckedItems += " ) ";
                    textBox.Text = s_SetTextBoxVal;
                }
                else textBox.Text = "--- Please Select ---";
                return s_CheckedItems;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to clear employee filters
        /// </summary>
        /// <param name="checkBoxList">checkBoxList</param>
        /// <param name="textBox">textBox</param>
        private void ClearEmployeeFilters(CheckBoxList checkBoxList, TextBox textBox)
        {
            try
            {
                foreach (ListItem CurrentItem in checkBoxList.Items)
                {
                    CurrentItem.Selected = false;
                }
                textBox.Text = "--- Please Select ---";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to process DataTable
        /// </summary>
        /// <param name="dt_temp">dt_temp</param>
        /// <param name="dt_CopyEmployeeRow">dt_CopyEmployeeRow</param>
        /// <returns>returns DataTable</returns>
        private DataTable ProcessDataTable(DataTable dt_temp, DataTable dt_CopyEmployeeRow)
        {
            try
            {
                foreach (DataRow dr in dt_temp.Rows)
                {
                    DataRow newDataRow = dt_CopyEmployeeRow.NewRow();
                    newDataRow.ItemArray = dr.ItemArray;
                    dt_CopyEmployeeRow.Rows.Add(newDataRow);
                }
                return dt_CopyEmployeeRow;
            }
            catch
            {
                throw;
            }
        }

        #endregion

        /// <summary>
        /// This method is used to move to next page
        /// </summary>
        /// <param name="addRemoveEmployees">UCGrantDetails page object</param>
        /// <param name="pageIndex">PageIndex</param>
        internal void Page_IndexChangeing(AddRemoveEmployees addRemoveEmployees, string pageIndex)
        {
            ac_ForfeitureSetup.s_FromAndToSelected = pageIndex.Split('-').Length > 1 ? "Selected" : string.Empty;
            ac_ForfeitureSetup.n_PageIndex = Convert.ToInt32(pageIndex.Split('-').First().Split('|').First());
            ac_ForfeitureSetup.n_PageSize = 10;
            BindGrids(addRemoveEmployees, true, string.Empty);
            PopulatePagerForGridView(addRemoveEmployees, ac_ForfeitureSetup.n_GridViewRecordsCount, Convert.ToInt32(pageIndex.Split('-').First().Split('|').First()), Convert.ToInt32(pageIndex.Split('-').First().Split('|').Last()));
        }

        /// <summary>
        /// This method is used to add pager for gridview
        /// </summary>
        /// <param name="addRemoveEmployees">Page object</param>
        /// <param name="recordCount">RecordCount</param>
        /// <param name="currentPage">CurrentPage</param>
        /// <param name="n_pageIndex">n_pageIndex</param>
        private void PopulatePagerForGridView(AddRemoveEmployees addRemoveEmployees, int recordCount, int currentPage, int n_pageIndex)
        {
            if (!recordCount.Equals(0))
            {
                double dblPageCount = (double)((decimal)recordCount / decimal.Parse("10"));
                int pageCount = (int)Math.Ceiling(dblPageCount);
                int n_TempCurrentPage = currentPage.Equals(1) ? 1 : Convert.ToInt32(Convert.ToInt32(currentPage / 10) + 9);

                int n_pageCount = 1, n_loopCount = 1;

                List<ListItem> pages = new List<ListItem>();
                if (pageCount > 0)
                {
                    for (int i = 1; i <= pageCount; i++)
                    {
                        pages.Add(new ListItem(i.ToString(), i.ToString() + "|" + n_pageCount, i != currentPage));

                        if (n_loopCount.Equals(10))
                        {
                            n_loopCount = 1;
                            n_pageCount = n_pageCount + 1;
                        }
                        else
                        {
                            n_loopCount++;
                        }
                    }
                }

                //Paging logic goes here  
                var v_Get10Records = pages.Skip((n_pageIndex - 1) * 10).Take(10).ToList();

                var NextFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 1;
                var NextLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 10;

                var PreviousFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 10;
                var PreviousLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 1;

                v_Get10Records.Insert(0, new ListItem("First", "1", currentPage > 1));

                if (currentPage > 10)
                {
                    v_Get10Records.Insert(1, new ListItem("....", PreviousFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1) + "-" + PreviousLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1), currentPage > 10));
                }

                if (pageCount > 10)
                {
                    v_Get10Records.Add(new ListItem("....", NextFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1) + "-" + NextLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1), currentPage < pageCount));
                }

                v_Get10Records.Add(new ListItem("Last", pageCount.ToString() + "|" + n_pageCount, currentPage < pageCount));

                addRemoveEmployees.rptPager.DataSource = v_Get10Records;
                addRemoveEmployees.rptPager.DataBind();
            }
        }
        #region Destructor
        /// <summary>
        /// Default Destructor
        /// </summary>
        ~AddRemoveEmployeesModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}