﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Model Class AccReportingReconPopUpModel of AccReportingReconPopUp Page
    /// </summary>
    public class AccReportingReconPopUpModel : BaseModel, IDisposable
    {
        #region Default constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public AccReportingReconPopUpModel()
        {
            if (ac_AccountingReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_AccountingReport);
                ac_AccountingReport = (CommonModel.AC_AccountingReport)HttpContext.Current.Session[CommonConstantModel.s_AC_AccountingReport];
            }
        }
        #endregion

        /// <summary>
        /// This method is used to Bind data to gvAccReportingReconGrid GridView
        /// </summary>
        /// <param name="accReportingReconPopUp">accReportingReconPopUp object</param>
        /// <param name="s_ReportingDate">string Reporting Date</param>
        /// <param name="s_DispCostBefore">string s_DispCostBefore</param>
        /// <param name="s_DispCostAfter">string s_DispCostAfter</param>
        internal void BindgvAccReportingReconGrid(AccReportingReconPopUp accReportingReconPopUp, string s_ReportingDate, string s_DispCostBefore, string s_DispCostAfter)
        {
            try
            {
                string s_PrevLockedRptGrpID = ac_AccountingReport.ds_ReportDetails.Tables[8] != null && ac_AccountingReport.ds_ReportDetails.Tables[8].Rows.Count > 0 ? Convert.ToString(ac_AccountingReport.ds_ReportDetails.Tables[8].Copy().Rows[0]["ACC_RPT_GROUP_ID"]) : string.Empty;

                if (!string.IsNullOrEmpty(s_PrevLockedRptGrpID))
                {
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PopulateControls = CommonConstantModel.s_MainReport;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.DISPLAY_COST_BEFORE = s_DispCostBefore;
                        accountingProperties.DISPLAY_COST_AFTER = s_DispCostAfter;
                        accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(s_PrevLockedRptGrpID);
                        accountingProperties.CALCULATION_METHOD = userSessionInfo.ACC_CalculationMethod;
                        accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;

                        using (ac_AccountingReport.ds_PrevLockedReport = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result)
                        {
                            accountingProperties.REPORTING_DATE = string.IsNullOrEmpty(s_ReportingDate) ? Convert.ToString(accReportingReconPopUp.hdnARReportDate.Value) : s_ReportingDate;

                            accountingProperties.dt_PrevLockRptMaster = AddRenameColumns(ac_AccountingReport.ds_PrevLockedReport.Tables[0].Copy(), "MasterTable", ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0 ? Convert.ToInt32(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["IS_PREV_FYQ1_RPT_DATE"]) : 0, ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0 ? Convert.ToInt32(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["IS_PREV_FYQ4_RPT_DATE"]) : 0, s_DispCostBefore, s_DispCostAfter, ac_AccountingReport.ds_ReportDetails.Tables[8] != null && ac_AccountingReport.ds_ReportDetails.Tables[8].Rows.Count > 0 ? Convert.ToString(ac_AccountingReport.ds_ReportDetails.Tables[8].Copy().Rows[0]["PREV_LOCKED_REPORTING_DATE"]) : string.Empty, null);
                            accountingProperties.dt_PrevLockRptMaster.TableName = "DT";

                            accountingProperties.dt_PrevLockRptDetails = AddRenameColumns(ac_AccountingReport.ds_PrevLockedReport.Tables[1].Copy().Select("[Scheme Name] <> 'AdjustMent Entry' AND [Scheme Name] <> 'Reversal Cost'").CopyToDataTable().DefaultView.ToTable(true, "Scheme Name", "OPT_GRANTED_ID", "OPT_VEST_ID", "Grant Date", "Grant Registration ID", "Employee ID", "Employee Name",
                                                                              "Grant Option ID", "Vest ID", "Vest Date", "Vest %", "Options Granted",
                                                                              "Options Vested Cancelled", "Options Unvested Cancelled", "Options Lapsed", "Vested and Exercisable Options", "Unvested Options",
                                                                              "Outstanding Options", "Exercised Options", "Live Options for Compensation Cost", "Acclelarated Options", "Accelerated Vesting Date",
                                                                              "Forfeiture Group", "Rate Applied", "Forfeiture Rate", "Options likely to be forfeited", "Net options for compensation cost",
                                                                              "Currency", "Exercise Price", "Exercise price post Corporate Action / Modification", "IV_FV", "IV_FV post Corporate Action / Modification / Change in estimated date of listing",
                                                                              "Total Compensation Cost"
                                                                            ),
                                                                            "DetailsTable", ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0 ? Convert.ToInt32(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["IS_PREV_FYQ1_RPT_DATE"]) : 0, ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0 ? Convert.ToInt32(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["IS_PREV_FYQ4_RPT_DATE"]) : 0, s_DispCostBefore, s_DispCostAfter, ac_AccountingReport.ds_ReportDetails.Tables[8] != null && ac_AccountingReport.ds_ReportDetails.Tables[8].Rows.Count > 0 ? Convert.ToString(ac_AccountingReport.ds_ReportDetails.Tables[8].Copy().Rows[0]["PREV_LOCKED_REPORTING_DATE"]) : string.Empty, ac_AccountingReport.ds_PrevLockedReport.Tables[1].Copy());
                            accountingProperties.dt_PrevLockRptDetails.TableName = "DT";

                            accountingProperties.dt_CurrentRptMaster = AddRenameColumns(ac_AccountingReport.ds_ReportDetails.Tables[0].Copy(), "MasterTable", ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0 ? Convert.ToInt32(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["IS_CURRENT_FYQ1_RPT_DATE"]) : 0, ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0 ? Convert.ToInt32(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["IS_CURRENT_FYQ4_RPT_DATE"]) : 0, s_DispCostBefore, s_DispCostAfter, s_ReportingDate, null);
                            accountingProperties.dt_CurrentRptMaster.TableName = "DT";

                            accountingProperties.dt_CurrentRptDetails = AddRenameColumns(ac_AccountingReport.ds_ReportDetails.Tables[1].Copy().Select("[Scheme Name] <> 'AdjustMent Entry' AND [Scheme Name] <> 'Reversal Cost'").CopyToDataTable().DefaultView.ToTable(true, "Scheme Name", "OPT_GRANTED_ID", "OPT_VEST_ID", "Grant Date", "Grant Registration ID", "Employee ID", "Employee Name",
                                                                              "Grant Option ID", "Vest ID", "Vest Date", "Vest %", "Options Granted",
                                                                              "Options Vested Cancelled", "Options Unvested Cancelled", "Options Lapsed", "Vested and Exercisable Options", "Unvested Options",
                                                                              "Outstanding Options", "Exercised Options", "Live Options for Compensation Cost", "Acclelarated Options", "Accelerated Vesting Date",
                                                                              "Forfeiture Group", "Rate Applied", "Forfeiture Rate", "Options likely to be forfeited", "Net options for compensation cost",
                                                                              "Currency", "Exercise Price", "Exercise price post Corporate Action / Modification", "IV_FV", "IV_FV post Corporate Action / Modification / Change in estimated date of listing",
                                                                              "Total Compensation Cost"
                                                                            ), "DetailsTable", ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0 ? Convert.ToInt32(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["IS_CURRENT_FYQ1_RPT_DATE"]) : 0, ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0 ? Convert.ToInt32(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["IS_CURRENT_FYQ4_RPT_DATE"]) : 0, s_DispCostBefore, s_DispCostAfter, s_ReportingDate, ac_AccountingReport.ds_ReportDetails.Tables[1].Copy());
                        }
                        accountingProperties.dt_CurrentRptDetails.TableName = "DT";

                        accountingProperties.MARKET_PRICE_TYPE = ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0 ? Convert.ToString(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["MARKET_PRICE_TYPE"]) : "IV";
                        accountingProperties.PopulateControls = "GET_RECONCILIATION_REPORT_DATA";
                        ac_AccountingReport.ds_ReconReport = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                        accReportingReconPopUp.gvAccReportingRecon.DataSource = ac_AccountingReport.ds_ReconReport.Tables[0].Copy();
                        accReportingReconPopUp.gvAccReportingRecon.DataBind();
                    }
                }
                else
                {
                    accReportingReconPopUp.gvAccReportingRecon.DataSource = new DataTable();
                    accReportingReconPopUp.gvAccReportingRecon.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add and rename the row data for Master and Details tables of Previous Locked Report and Current Report
        /// </summary>
        /// <param name="dt_DataTable">Datatable dt_DataTable</param>
        /// <param name="s_TableName">string Table Name</param>
        /// <param name="n_IsFYQ1RptDate">int n_IsFYQ1RptDate</param>
        /// <param name="n_IsFYQ4RptDate">int n_IsFYQ4RptDate</param>
        /// <param name="s_DispCostBefore">string s_DispCostBefore </param>
        /// <param name="s_DispCostAfter">string s_DispCostAfter</param>
        /// <param name="s_ReportingDate">string Reporting Date</param>
        /// <param name="dt_PrevLockOrCurrent">Datatable dt_PrevLockOrCurrent previous locked report</param>
        /// <returns>Datatble dt_DataTable</returns>
        private DataTable AddRenameColumns(DataTable dt_DataTable, string s_TableName, int n_IsFYQ1RptDate, int n_IsFYQ4RptDate, string s_DispCostBefore, string s_DispCostAfter, string s_ReportingDate, DataTable dt_PrevLockOrCurrent)
        {
            try
            {
                switch (s_TableName)
                {
                    case "MasterTable":
                        if (s_DispCostBefore.Equals("N"))
                        {
                            dt_DataTable.Columns.Add("Cost Before FY", typeof(decimal));
                            dt_DataTable.Columns["Cost Before FY"].SetOrdinal(1);
                        }

                        if (n_IsFYQ4RptDate > 0 || n_IsFYQ1RptDate > 0)
                        {
                            dt_DataTable.Columns.Add("Cost After Current FY", typeof(decimal));
                            dt_DataTable.Columns["Cost After Current FY"].SetOrdinal(5);
                        }

                        if (s_DispCostAfter.Equals("N"))
                            dt_DataTable.Columns.Add("Cost After FY", typeof(decimal));

                        dt_DataTable.Columns[1].ColumnName = "Cost Before FY";
                        dt_DataTable.Columns[2].ColumnName = "Cost Before Two FY";
                        dt_DataTable.Columns[3].ColumnName = "Cost Before One FY";
                        dt_DataTable.Columns[4].ColumnName = "Cost Till Current FY";
                        dt_DataTable.Columns[5].ColumnName = "Cost After Current FY";
                        dt_DataTable.Columns[6].ColumnName = "Cost After One FY";
                        dt_DataTable.Columns[7].ColumnName = "Cost After Two FY";
                        dt_DataTable.Columns[8].ColumnName = "Cost After FY";
                        break;

                    case "DetailsTable":
                        int n_ReptYr = !string.IsNullOrEmpty(s_ReportingDate) ? Convert.ToInt32(s_ReportingDate.Substring(1 + s_ReportingDate.LastIndexOf('/'))) : 0;

                        if (s_DispCostBefore.Equals("N"))
                            dt_DataTable.Columns.Add("Cost Before FY", typeof(decimal));
                        else
                        {
                            dt_DataTable.Columns.Add("Cost Before FY " + Convert.ToString(n_IsFYQ4RptDate > 0 ? (n_ReptYr - 3) : (n_ReptYr - 2)), typeof(decimal));
                            dt_DataTable = n_IsFYQ4RptDate > 0 ? AddUpdateRowData(dt_DataTable, "Cost Before FY " + (n_ReptYr - 3), dt_PrevLockOrCurrent) : AddUpdateRowData(dt_DataTable, "Cost Before FY " + (n_ReptYr - 2), dt_PrevLockOrCurrent);
                        }

                        dt_DataTable.Columns.Add(Convert.ToString(n_IsFYQ4RptDate > 0 ? "" + (n_ReptYr - 3) + " - " + (n_ReptYr - 2) : "" + (n_ReptYr - 2) + " - " + (n_ReptYr - 1)), typeof(decimal));
                        dt_DataTable = n_IsFYQ4RptDate > 0 ? AddUpdateRowData(dt_DataTable, "" + (n_ReptYr - 3) + " - " + (n_ReptYr - 2), dt_PrevLockOrCurrent) : AddUpdateRowData(dt_DataTable, "" + (n_ReptYr - 2) + " - " + (n_ReptYr - 1), dt_PrevLockOrCurrent);

                        dt_DataTable.Columns.Add(Convert.ToString(n_IsFYQ4RptDate > 0 ? "" + (n_ReptYr - 2) + " - " + (n_ReptYr - 1) : "" + (n_ReptYr - 1) + " - " + (n_ReptYr)), typeof(decimal));
                        dt_DataTable = n_IsFYQ4RptDate > 0 ? AddUpdateRowData(dt_DataTable, "" + (n_ReptYr - 2) + " - " + (n_ReptYr - 1), dt_PrevLockOrCurrent) : AddUpdateRowData(dt_DataTable, "" + (n_ReptYr - 1) + " - " + (n_ReptYr), dt_PrevLockOrCurrent);

                        if (n_IsFYQ1RptDate > 0 || n_IsFYQ4RptDate > 0)
                        {
                            dt_DataTable.Columns.Add(n_IsFYQ1RptDate > 0 ? (n_ReptYr) + " - " + (n_ReptYr + 1) : (n_ReptYr - 1) + " - " + (n_ReptYr), typeof(decimal));
                            dt_DataTable = AddUpdateRowData(dt_DataTable, n_IsFYQ1RptDate > 0 ? (n_ReptYr) + " - " + (n_ReptYr + 1) : (n_ReptYr - 1) + " - " + (n_ReptYr), dt_PrevLockOrCurrent);

                            dt_DataTable.Columns.Add("Cost After Current FY", typeof(decimal));
                        }
                        else
                        {
                            dt_DataTable.Columns.Add("" + (n_ReptYr) + " - " + (n_ReptYr + 1) + " split | till " + s_ReportingDate, typeof(decimal));
                            dt_DataTable = AddUpdateRowData(dt_DataTable, "" + (n_ReptYr) + " - " + (n_ReptYr + 1) + " split | till " + s_ReportingDate, dt_PrevLockOrCurrent);

                            dt_DataTable.Columns.Add("" + (n_ReptYr) + " - " + (n_ReptYr + 1) + " split | after " + s_ReportingDate, typeof(decimal));
                            dt_DataTable = AddUpdateRowData(dt_DataTable, "" + (n_ReptYr) + " - " + (n_ReptYr + 1) + " split | after " + s_ReportingDate, dt_PrevLockOrCurrent);
                        }

                        dt_DataTable.Columns.Add(Convert.ToString(n_IsFYQ4RptDate > 0 ? "" + (n_ReptYr) + " - " + (n_ReptYr + 1) : "" + (n_ReptYr + 1) + " - " + (n_ReptYr + 2)), typeof(decimal));
                        dt_DataTable = AddUpdateRowData(dt_DataTable, Convert.ToString(n_IsFYQ4RptDate > 0 ? "" + (n_ReptYr) + " - " + (n_ReptYr + 1) : "" + (n_ReptYr + 1) + " - " + (n_ReptYr + 2)), dt_PrevLockOrCurrent);

                        dt_DataTable.Columns.Add(Convert.ToString(n_IsFYQ4RptDate > 0 ? "" + (n_ReptYr + 1) + " - " + (n_ReptYr + 2) : "" + (n_ReptYr + 2) + " - " + (n_ReptYr + 3)), typeof(decimal));
                        dt_DataTable = AddUpdateRowData(dt_DataTable, Convert.ToString(n_IsFYQ4RptDate > 0 ? "" + (n_ReptYr + 1) + " - " + (n_ReptYr + 2) : "" + (n_ReptYr + 2) + " - " + (n_ReptYr + 3)), dt_PrevLockOrCurrent);

                        if (s_DispCostAfter.Equals("N"))
                            dt_DataTable.Columns.Add("Cost After FY", typeof(decimal));
                        else
                        {
                            dt_DataTable.Columns.Add("Cost After FY " + Convert.ToString(n_IsFYQ4RptDate > 0 ? (n_ReptYr + 2) : (n_ReptYr + 3)), typeof(decimal));
                            dt_DataTable = AddUpdateRowData(dt_DataTable, "Cost After FY " + Convert.ToString(n_IsFYQ4RptDate > 0 ? (n_ReptYr + 2) : (n_ReptYr + 3)), dt_PrevLockOrCurrent);
                        }

                        dt_DataTable.Columns[28].ColumnName = "Exercise price post CorpAct/Modif";
                        dt_DataTable.Columns[30].ColumnName = "IV_FV post CorpAct/Modif/EDL";
                        dt_DataTable.Columns[33].ColumnName = "Cost Before FY";
                        dt_DataTable.Columns[34].ColumnName = "Cost Before Two FY";
                        dt_DataTable.Columns[35].ColumnName = "Cost Before One FY";
                        dt_DataTable.Columns[36].ColumnName = "Cost Till Current FY";
                        dt_DataTable.Columns[37].ColumnName = "Cost After Current FY";
                        dt_DataTable.Columns[38].ColumnName = "Cost After One FY";
                        dt_DataTable.Columns[39].ColumnName = "Cost After Two FY";
                        dt_DataTable.Columns[40].ColumnName = "Cost After FY";
                        break;
                }

                return dt_DataTable;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add and update the row data for Master and Details tables of Previous Locked Report and Current Report
        /// </summary>
        /// <param name="dt_DataTable">Datatable dt_DataTable</param>
        /// <param name="s_ColumName">string Column Name</param>
        /// <param name="dt_PrevLockOrCurrent">Datatable dt_PrevLockOrCurrent of previous locked datatable</param>
        /// <returns>Datatable dt_DataTable</returns>
        private DataTable AddUpdateRowData(DataTable dt_DataTable, string s_ColumName, DataTable dt_PrevLockOrCurrent)
        {
            try
            {
                for (int n_RowNum = 0; n_RowNum < dt_DataTable.Rows.Count; n_RowNum++)
                {
                    dt_DataTable.Rows[n_RowNum][s_ColumName] = !string.IsNullOrEmpty(Convert.ToString(dt_PrevLockOrCurrent.Rows[n_RowNum][s_ColumName])) ? Convert.ToString(dt_PrevLockOrCurrent.Rows[n_RowNum][s_ColumName]) : "0.00";
                }

                return dt_DataTable;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The RowDataBound Event of gvAccReportingRecon GridView
        /// </summary>
        /// <param name="accReportingReconPopUp">accReportingReconPopUp object</param>
        /// <param name="e">e</param>
        /// <param name="s_RptDate">string Reporting Date</param>
        /// <param name="n_index">int n_index</param>
        /// <param name="ht_ReconGridView">Hashtable ht_ReconGridView of ref int parameters</param>
        internal void gvAccReportingRecon_RowDataBound(AccReportingReconPopUp accReportingReconPopUp, GridViewRowEventArgs e, string s_RptDate, ref int n_index, ref Hashtable ht_ReconGridView)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SCHEME NAME":
                                    ht_ReconGridView["SCHEME_NAME"] = n_index;
                                    break;

                                case "COST FOR PERIOD | AS PER REPORT AS ON ~":
                                    ht_ReconGridView["COST_FOR_PERIOD_AS_PER_RPT_AS_ON"] = n_index;
                                    perColumn.Text = perColumn.Text.Replace("|", s_RptDate).Replace("~", Convert.ToString(ac_AccountingReport.ds_ReportDetails.Tables[8].Copy().Rows[0]["PREV_LOCKED_REPORTING_DATE"]));
                                    break;

                                case "COST FOR OPTIONS GRANTED":
                                    ht_ReconGridView["COST_FOR_OPT_GRANTED"] = n_index;
                                    break;

                                case "COST DUE TO CHANGE IN FORFEITURE RATE/FORFEITED OPTIONS":
                                    ht_ReconGridView["COST_DUE_TO_CHNG_FORFT_RATE_OPT"] = n_index;
                                    break;

                                case "COST OF ACCELERATED OPTIONS":
                                    ht_ReconGridView["COST_OF_ACCELERATED_OPT"] = n_index;
                                    break;

                                case "COST FOR MODIFICATION":
                                    ht_ReconGridView["COST_FOR_MODIFICATION"] = n_index;
                                    break;

                                case "COST DUE TO CHANGE IN ESTIMATED LISTING PERIOD":
                                    ht_ReconGridView["COST_DUE_TO_CHNG_EST_DATE_OF_LST"] = n_index;
                                    break;

                                case "COST DUE TO EDITING OF ACCOUNTING PARAMETERS":
                                    ht_ReconGridView["COST_DUE_TO_EDITING_OF_ACC_PARAMS"] = n_index;
                                    break;

                                case "COST DUE TO REVERSAL OF OPTIONS CANCELLED AFTER ~":
                                    ht_ReconGridView["COST_DUE_TO_REVERSAL_OF_OPT_CANCELLED"] = n_index;
                                    perColumn.Text = perColumn.Text.Replace("~", s_RptDate);
                                    break;

                                case "COST FOR FY (A)":
                                    ht_ReconGridView["COST_FOR_FY_(A)"] = n_index;
                                    break;

                                case "COST AS PER CURRENT REPORT (B)":
                                    ht_ReconGridView["COST_AS_PER_CURRENT_RPT_(B)"] = n_index;
                                    break;

                                case "DIFFERENCE (A)-(B)":
                                    ht_ReconGridView["DIFFERENCE_(A)_(B)"] = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["SCHEME_NAME"])].HorizontalAlign = HorizontalAlign.Left;

                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_FOR_PERIOD_AS_PER_RPT_AS_ON"])].HorizontalAlign =
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_FOR_OPT_GRANTED"])].HorizontalAlign =
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_DUE_TO_CHNG_FORFT_RATE_OPT"])].HorizontalAlign =
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_OF_ACCELERATED_OPT"])].HorizontalAlign =
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_FOR_MODIFICATION"])].HorizontalAlign =
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_DUE_TO_CHNG_EST_DATE_OF_LST"])].HorizontalAlign =
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_DUE_TO_EDITING_OF_ACC_PARAMS"])].HorizontalAlign =
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_DUE_TO_REVERSAL_OF_OPT_CANCELLED"])].HorizontalAlign =
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_FOR_FY_(A)"])].HorizontalAlign =
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_AS_PER_CURRENT_RPT_(B)"])].HorizontalAlign =
                        e.Row.Cells[Convert.ToInt32(ht_ReconGridView["DIFFERENCE_(A)_(B)"])].HorizontalAlign = HorizontalAlign.Right;

                        if (e.Row.Cells[Convert.ToInt32(ht_ReconGridView["SCHEME_NAME"])].Text != "Total")
                        {
                            e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_FOR_PERIOD_AS_PER_RPT_AS_ON"])].Controls.Add(AddControl(accReportingReconPopUp, "LinkButton", "lnkBtn_ForColumnCell_a_" + e.Row.RowIndex, e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_FOR_PERIOD_AS_PER_RPT_AS_ON"])].Text, "Click to View Details", "ViewReconColumnCell", string.Empty, "gvReconChildGridView_ColumnCell_a", string.Empty, string.Empty, string.Empty));
                            e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_DUE_TO_REVERSAL_OF_OPT_CANCELLED"])].Controls.Add(AddControl(accReportingReconPopUp, "LinkButton", "lnkBtn_ForColumnCell_c_" + e.Row.RowIndex, e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_DUE_TO_REVERSAL_OF_OPT_CANCELLED"])].Text, "Click to View Details", "ViewReconColumnCell", string.Empty, "gvReconChildGridView_ColumnCell_c", string.Empty, string.Empty, string.Empty));
                            e.Row.Cells[Convert.ToInt32(ht_ReconGridView["DIFFERENCE_(A)_(B)"])].Controls.Add(AddControl(accReportingReconPopUp, "LinkButton", "lnkBtn_ForColumnCell_c_" + e.Row.RowIndex, e.Row.Cells[Convert.ToInt32(ht_ReconGridView["DIFFERENCE_(A)_(B)"])].Text, "Click to View Details", "ViewReconColumnCell", string.Empty, "gvReconChildGridView_ColumnCell_f", string.Empty, string.Empty, string.Empty));
                        }

                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add control to the column cell of gridview
        /// </summary>
        /// <param name="accReportingReconPopUp">accReportingReconPopUp object</param>
        /// <param name="s_ControlName">string Name of the Control</param>
        /// <param name="s_ControlID">string ID of the Control</param>
        /// <param name="s_ControlText">string Text of the Control</param>
        /// <param name="s_Tooltip">string Tooltip of the Control</param>
        /// <param name="s_JavascriptMethodName">string Name of the JavaScript Method</param>
        /// <param name="s_EventName">string Name of Event</param>
        /// <param name="s_ParameterOne">string Parameter One</param>
        /// <param name="s_ParameterTwo">string Parameter Two</param>
        /// <param name="s_ParameterThree">string Parameter Three</param>
        /// <param name="s_ParameterFour">string Parameter Four</param>
        /// <returns>Control</returns>
        private Control AddControl(AccReportingReconPopUp accReportingReconPopUp, string s_ControlName, string s_ControlID, string s_ControlText, string s_Tooltip, string s_JavascriptMethodName, string s_EventName, string s_ParameterOne, string s_ParameterTwo, string s_ParameterThree, string s_ParameterFour)
        {
            try
            {
                switch (s_ControlName)
                {
                    case "LinkButton":
                        LinkButton lnkButton = new LinkButton();
                        lnkButton.ID = s_ControlID;
                        lnkButton.Text = s_ControlText;
                        lnkButton.ToolTip = s_Tooltip;
                        lnkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        lnkButton.Style.Add("cursor", "pointer");

                        switch (s_JavascriptMethodName)
                        {
                            case "ViewReconColumnCell":
                                lnkButton.Attributes.Add("onclick", "return ViewReconColumnCell('" + s_ParameterOne + "', this)");
                                return lnkButton;
                        }
                        break;
                }
                return new Control();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Add Child GridView to the Parent GridView
        /// </summary>
        /// <param name="sender">gvAccReportingRecon GridView</param>
        /// <param name="e">e</param>
        /// <param name="accReportingReconPopUp">accReportingReconPopUp object</param>
        /// <param name="n_RowIndex">int n_RowIndex</param>
        /// <param name="s_ShemeName">string Scheme Name</param>
        /// <param name="ht_ReconGridView">Hashtable ht_ReconGridView of ref int parameters</param>
        internal void AddChildGriView(object sender, GridViewRowEventArgs e, AccReportingReconPopUp accReportingReconPopUp, ref int n_RowIndex, string s_ShemeName, ref Hashtable ht_ReconGridView)
        {
            try
            {
                GridView grdView_Parent = (GridView)sender;

                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                {
                    NewTotalRow.Font.Bold = true;
                    NewTotalRow.CssClass = "gridItems  gvReconChildGridView_ColumnCell_a";
                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                    using (TableCell tblCell = new TableCell())
                    {
                        tblCell.Attributes.Add("Class", "gvReconChildGridView_ColumnCell_a");
                        tblCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        tblCell.Height = 10;
                        tblCell.HorizontalAlign = HorizontalAlign.Center;
                        tblCell.ColumnSpan = 12;

                        using (GridView grdView_Child_a = new GridView())
                        {
                            grdView_Child_a.ID = "grdView_Child_ColumnCell_a_" + e.Row.RowIndex;
                            grdView_Child_a.CssClass = "Grid";
                            grdView_Child_a.HeaderStyle.CssClass = "HeaderStyle";
                            grdView_Child_a.RowStyle.CssClass = "gridItems";
                            grdView_Child_a.CellPadding = 3;
                            grdView_Child_a.CellSpacing = 0;
                            grdView_Child_a.EmptyDataText = grdView_Parent.EmptyDataText;
                            grdView_Child_a.EmptyDataRowStyle.HorizontalAlign = HorizontalAlign.Left;

                            grdView_Child_a.RowDataBound += accReportingReconPopUp.grdView_Child_a_RowDataBound;
                            grdView_Child_a.DataSource = ac_AccountingReport.ds_ReconReport.Tables[1].DefaultView.ToTable("DT", true, new string[] { "Scheme Name", "Grant Date", "Grant Registration ID", "Employee ID", "Employee Name", 
                                                                                "Grant Option ID", "Vest ID", "Vest Date", "Vest %", "Options Granted", 
                                                                                "Options Vested Cancelled", "Options Unvested Cancelled", "Options Lapsed", "Vested and Exercisable Options", "Unvested Options",
                                                                                "Outstanding Options", "Exercised Options", "Options Cancelled during the period", "Options Cancelled during the period for which cost is reversed",
                                                                                "Live Options for Compensation Cost", "Acclelarated Options", "Accelerated Vesting Date",
                                                                                "Forfeiture Group", "Rate Applied", "Forfeiture Rate", "Options likely to be forfeited", "Net options for compensation cost",
                                                                                "Currency", "Exercise Price", "Exercise price post CorpAct/Modif", "IV_FV", "IV_FV post CorpAct/Modif/EDL",
                                                                                "Total Compensation Cost", "Cost for period | as per report as on ~"
                                                                                }).Copy().Select("[Scheme Name] = '" + s_ShemeName + "'").Count() > 0
                                                            ? ac_AccountingReport.ds_ReconReport.Tables[1].DefaultView.ToTable("DT", true, new string[] { "Scheme Name", "Grant Date", "Grant Registration ID", "Employee ID", "Employee Name", 
                                                                                "Grant Option ID", "Vest ID", "Vest Date", "Vest %", "Options Granted", 
                                                                                "Options Vested Cancelled", "Options Unvested Cancelled", "Options Lapsed", "Vested and Exercisable Options", "Unvested Options",
                                                                                "Outstanding Options", "Exercised Options", "Options Cancelled during the period", "Options Cancelled during the period for which cost is reversed",
                                                                                "Live Options for Compensation Cost", "Acclelarated Options", "Accelerated Vesting Date",
                                                                                "Forfeiture Group", "Rate Applied", "Forfeiture Rate", "Options likely to be forfeited", "Net options for compensation cost",
                                                                                "Currency", "Exercise Price", "Exercise price post CorpAct/Modif", "IV_FV", "IV_FV post CorpAct/Modif/EDL",
                                                                                "Total Compensation Cost", "Cost for period | as per report as on ~"
                                                                                }).Copy().Select("[Scheme Name] = '" + s_ShemeName + "'").CopyToDataTable() : null;
                            grdView_Child_a.DataBind();

                            tblCell.Controls.Add(grdView_Child_a);
                            NewTotalRow.Cells.Add(tblCell);
                            grdView_Parent.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + n_RowIndex, NewTotalRow);
                            n_RowIndex++;

                            MergeRows(grdView_Child_a);
                        }
                    }
                }

                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                {
                    NewTotalRow.Font.Bold = true;
                    NewTotalRow.CssClass = "gridItems  gvReconChildGridView_ColumnCell_b";
                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                    using (TableCell tblCell = new TableCell())
                    {
                        tblCell.Attributes.Add("Class", "gvReconChildGridView_ColumnCell_b");
                        tblCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        tblCell.Height = 10;
                        tblCell.HorizontalAlign = HorizontalAlign.Center;
                        tblCell.ColumnSpan = 12;

                        using (GridView grdView_Child_b = new GridView())
                        {
                            grdView_Child_b.ID = "grdView_Child_ColumnCell_b_" + e.Row.RowIndex;
                            grdView_Child_b.CssClass = "Grid";
                            grdView_Child_b.HeaderStyle.CssClass = "HeaderStyle";
                            grdView_Child_b.RowStyle.CssClass = "gridItems";
                            grdView_Child_b.CellPadding = 3;
                            grdView_Child_b.CellSpacing = 0;
                            grdView_Child_b.EmptyDataText = grdView_Parent.EmptyDataText;
                            grdView_Child_b.EmptyDataRowStyle.HorizontalAlign = HorizontalAlign.Left;

                            grdView_Child_b.RowDataBound += accReportingReconPopUp.grdView_Child_b_RowDataBound;
                            grdView_Child_b.DataSource = ac_AccountingReport.ds_ReconReport.Tables[2].Copy().Select("[Scheme Name] = '" + s_ShemeName + "'").Count() > 0 ? ac_AccountingReport.ds_ReconReport.Tables[2].Copy().Select("[Scheme Name] = '" + s_ShemeName + "'").CopyToDataTable() : null;
                            grdView_Child_b.DataBind();

                            tblCell.Controls.Add(grdView_Child_b);
                            NewTotalRow.Cells.Add(tblCell);
                            grdView_Parent.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + n_RowIndex, NewTotalRow);
                            n_RowIndex++;

                            MergeRows(grdView_Child_b);

                            e.Row.Cells[Convert.ToInt32(ht_ReconGridView["COST_FOR_OPT_GRANTED"])].Controls.Add(AddControl(accReportingReconPopUp, "LinkButton", "lnkBtn_ForColumnCell_b_" + e.Row.RowIndex, grdView_Child_b.Rows.Count > 0 ? Convert.ToString(ac_AccountingReport.ds_ReconReport.Tables[2].Copy().Select("[Scheme Name] = '" + s_ShemeName + "'").CopyToDataTable().Compute("sum([Cost of Grants during the period])", string.Empty)) : "0", "Click to View Details", "ViewReconColumnCell", string.Empty, "gvReconChildGridView_ColumnCell_b", string.Empty, string.Empty, string.Empty));
                        }
                    }
                }

                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                {
                    NewTotalRow.Font.Bold = true;
                    NewTotalRow.CssClass = "gridItems  gvReconChildGridView_ColumnCell_c";
                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                    using (TableCell tblCell = new TableCell())
                    {
                        tblCell.Attributes.Add("Class", "gvReconChildGridView_ColumnCell_c");
                        tblCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        tblCell.Height = 10;
                        tblCell.HorizontalAlign = HorizontalAlign.Center;
                        tblCell.ColumnSpan = 12;

                        using (GridView grdView_Child_c = new GridView())
                        {
                            grdView_Child_c.ID = "grdView_Child_ColumnCell_c_" + e.Row.RowIndex;
                            grdView_Child_c.CssClass = "Grid";
                            grdView_Child_c.HeaderStyle.CssClass = "HeaderStyle";
                            grdView_Child_c.RowStyle.CssClass = "gridItems";
                            grdView_Child_c.CellPadding = 3;
                            grdView_Child_c.CellSpacing = 0;
                            grdView_Child_c.EmptyDataText = grdView_Parent.EmptyDataText;
                            grdView_Child_c.EmptyDataRowStyle.HorizontalAlign = HorizontalAlign.Left;

                            grdView_Child_c.RowDataBound += accReportingReconPopUp.grdView_Child_c_RowDataBound;
                            grdView_Child_c.DataSource = ac_AccountingReport.ds_ReconReport.Tables[3].Copy().Select("[Scheme Name] = '" + s_ShemeName + "'").Count() > 0 ? ac_AccountingReport.ds_ReconReport.Tables[3].Copy().Select("[Scheme Name] = '" + s_ShemeName + "'").CopyToDataTable() : null;
                            grdView_Child_c.DataBind();

                            tblCell.Controls.Add(grdView_Child_c);
                            NewTotalRow.Cells.Add(tblCell);
                            grdView_Parent.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + n_RowIndex, NewTotalRow);
                            n_RowIndex++;

                            MergeRows(grdView_Child_c);
                        }
                    }
                }

                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                {
                    NewTotalRow.Font.Bold = true;
                    NewTotalRow.CssClass = "gridItems  gvReconChildGridView_ColumnCell_f";
                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                    using (TableCell tblCell = new TableCell())
                    {
                        tblCell.Attributes.Add("Class", "gvReconChildGridView_ColumnCell_f");
                        tblCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        tblCell.Height = 10;
                        tblCell.HorizontalAlign = HorizontalAlign.Center;
                        tblCell.ColumnSpan = 12;

                        using (GridView grdView_Child_f = new GridView())
                        {
                            grdView_Child_f.ID = "grdView_Child_ColumnCell_f_" + e.Row.RowIndex;
                            grdView_Child_f.CssClass = "Grid";
                            grdView_Child_f.HeaderStyle.CssClass = "HeaderStyle";
                            grdView_Child_f.RowStyle.CssClass = "gridItems";
                            grdView_Child_f.CellPadding = 3;
                            grdView_Child_f.CellSpacing = 0;
                            grdView_Child_f.EmptyDataText = grdView_Parent.EmptyDataText;
                            grdView_Child_f.EmptyDataRowStyle.HorizontalAlign = HorizontalAlign.Left;

                            grdView_Child_f.RowDataBound += accReportingReconPopUp.grdView_Child_f_RowDataBound;
                            grdView_Child_f.DataSource = ac_AccountingReport.ds_ReconReport.Tables[4].Copy().Select("[Scheme Name] = '" + s_ShemeName + "'").Count() > 0 ? ac_AccountingReport.ds_ReconReport.Tables[4].Copy().Select("[Scheme Name] = '" + s_ShemeName + "'").CopyToDataTable() : null;
                            grdView_Child_f.DataBind();

                            tblCell.Controls.Add(grdView_Child_f);
                            NewTotalRow.Cells.Add(tblCell);
                            grdView_Parent.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + n_RowIndex, NewTotalRow);
                            n_RowIndex++;

                            MergeRows(grdView_Child_f);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Row Data Bound Event of grdView_Child GridView
        /// </summary>
        /// <param name="accReportingReconPopUp">accReportingReconPopUp object</param>
        /// <param name="s_GridViewID">string GridView ID</param>
        /// <param name="e">e</param>
        /// <param name="n_childIndex_a">int n_childIndex_a</param>
        /// <param name="n_childIndex_b">int n_childIndex_b</param>
        /// <param name="n_childIndex_c">int n_childIndex_c</param>
        /// <param name="n_childIndex_f">int n_childIndex_f</param>
        /// <param name="s_RptDate">string Reporting Date</param>
        /// <param name="ht_ReconChildGridView_a">Hashtable ht_ReconChildGridView_a of ref int parameters</param>
        /// <param name="ht_ReconChildGridView_b">Hashtable ht_ReconChildGridView_b of ref int parameters</param>
        /// <param name="ht_ReconChildGridView_c">Hashtable ht_ReconChildGridView_c of ref int parameters</param>
        /// <param name="ht_ReconChildGridView_f">Hashtable ht_ReconChildGridView_f of ref int parameters</param>
        internal void grdView_Child_RowDataBound(AccReportingReconPopUp accReportingReconPopUp, string s_GridViewID, GridViewRowEventArgs e, ref int n_childIndex_a, ref int n_childIndex_b, ref int n_childIndex_c, ref int n_childIndex_f, string s_RptDate, ref Hashtable ht_ReconChildGridView_a, ref Hashtable ht_ReconChildGridView_b, ref Hashtable ht_ReconChildGridView_c, ref Hashtable ht_ReconChildGridView_f)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SCHEME NAME":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["SCH_NAME"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["SCH_NAME"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["SCH_NAME"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["SCH_NAME"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "GRANT DATE":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["GRANT_DATE"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["GRANT_DATE"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["GRANT_DATE"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["GRANT_DATE"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "GRANT REGISTRATION ID":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["GRANT_REG_ID"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["GRANT_REG_ID"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["GRANT_REG_ID"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["GRANT_REG_ID"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "EMPLOYEE ID":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["EMP_ID"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["EMP_ID"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["EMP_ID"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["EMP_ID"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "EMPLOYEE NAME":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["EMP_NAME"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["EMP_NAME"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["EMP_NAME"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["EMP_NAME"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "GRANT OPTION ID":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["GRANT_OPT_ID"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["GRANT_OPT_ID"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["GRANT_OPT_ID"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["GRANT_OPT_ID"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "VEST ID":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["VEST_ID"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["VEST_ID"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["VEST_ID"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["VEST_ID"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "VEST DATE":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["VEST_DATE"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["VEST_DATE"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["VEST_DATE"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["VEST_DATE"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "VEST %":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["VEST_PERCENT"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["VEST_PERCENT"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["VEST_PERCENT"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["VEST_PERCENT"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "OPTIONS GRANTED":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["OPT_GRANTED"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["OPT_GRANTED"] = n_childIndex_b;
                                            perColumn.Visible = false;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["OPT_GRANTED"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "OPTIONS VESTED CANCELLED":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["OPT_VESTED_CANCELLED"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["OPT_VESTED_CANCELLED"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "OPTIONS UNVESTED CANCELLED":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["OPT_UNVESTED_CANCELLED"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["OPT_UNVESTED_CANCELLED"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "OPTIONS LAPSED":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["OPT_LAPSED"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["OPT_LAPSED"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "VESTED AND EXERCISABLE OPTIONS":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["VESTED_AND_EXERCISABLE_OPT"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["VESTED_AND_EXERCISABLE_OPT"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "UNVESTED OPTIONS":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["UNVESTED_OPT"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["UNVESTED_OPT"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "OUTSTANDING OPTIONS":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["OUTSTANDING_OPT"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["OUTSTANDING_OPT"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "EXERCISED OPTIONS":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["EXERCISED_OPT"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["EXERCISED_OPT"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "OPTIONS CANCELLED DURING THE PERIOD":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["OPT_CANC_DURING_PERIOD"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["OPT_CANC_DURING_PERIOD"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["OPT_CANC_DURING_PERIOD"] = n_childIndex_f;
                                            break;
                                    }
                                    break;

                                case "OPTIONS CANCELLED DURING THE PERIOD FOR WHICH COST IS REVERSED":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["OPT_CANC_DURING_PERIOD_COST_REVERSED"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["OPT_CANC_DURING_PERIOD_COST_REVERSED"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["OPT_CANC_DURING_PERIOD_COST_REVERSED"] = n_childIndex_f;
                                            break;
                                    }
                                    break;

                                case "LIVE OPTIONS FOR COMPENSATION COST":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["LIVE_OPT_FOR_COMP_COST"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["LIVE_OPT_FOR_COMP_COST"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "ACCLELARATED OPTIONS":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["ACCR_OPT"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["ACCR_OPT"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "ACCELERATED VESTING DATE":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["ACCR_VEST_DATE"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["ACCR_VEST_DATE"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "FORFEITURE GROUP":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["FORFT_GRP"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["FORFT_GRP"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "RATE APPLIED":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["RATE_APPLIED"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["RATE_APPLIED"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "FORFEITURE RATE":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["FORFT_RATE"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["FORFT_RATE"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "OPTIONS LIKELY TO BE FORFEITED":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["OPT_LIKLY_TO_BE_FORFITED"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["OPT_LIKLY_TO_BE_FORFITED"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "NET OPTIONS FOR COMPENSATION COST":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["NET_OPT_FOR_COMP_COST"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["NET_OPT_FOR_COMP_COST"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["NET_OPT_FOR_COMP_COST"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["NET_OPT_FOR_COMP_COST"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "CURRENCY":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["CURRENCY"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["CURRENCY"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "EXERCISE PRICE":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["EX_PRC"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["EX_PRC"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "EXERCISE PRICE POST CORPACT/MODIF":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["EX_PRC_POST_CORP_ACT_MODF"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["EX_PRC_POST_CORP_ACT_MODF"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "IV_FV":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["IV_FV"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["IV_FV"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["IV_FV"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["IV_FV"] = n_childIndex_f;
                                            break;
                                    }

                                    perColumn.Text = ac_AccountingReport.ds_PrevLockedReport.Tables[9] != null && ac_AccountingReport.ds_PrevLockedReport.Tables[9].Rows.Count > 0 ? Convert.ToString(ac_AccountingReport.ds_PrevLockedReport.Tables[9].Rows[0]["MARKET_PRICE_TYPE"]).Equals("FV") ? "Fair Value" : "Intrinsic Value" : string.Empty;
                                    break;

                                case "IV_FV POST CORPACT/MODIF/EDL":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["IV_FV_POST_CORP_ACT_MODF_EDL"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["IV_FV_POST_CORP_ACT_MODF_EDL"] = n_childIndex_f;
                                            break;
                                    }

                                    perColumn.Text = ac_AccountingReport.ds_PrevLockedReport.Tables[9] != null && ac_AccountingReport.ds_PrevLockedReport.Tables[9].Rows.Count > 0 ? Convert.ToString(ac_AccountingReport.ds_PrevLockedReport.Tables[9].Rows[0]["MARKET_PRICE_TYPE"]).Equals("FV") ? perColumn.Text.Replace("IV_FV", "Fair Value") : perColumn.Text.Replace("IV_FV", "Intrinsic Value") : string.Empty;
                                    break;

                                case "TOTAL COMPENSATION COST":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_a":
                                            ht_ReconChildGridView_a["TOTAL_COMP_COST"] = n_childIndex_a;
                                            break;

                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["TOTAL_COMP_COST"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["TOTAL_COMP_COST"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["TOTAL_COMP_COST"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "COST FOR PERIOD | AS PER REPORT AS ON ~":
                                    ht_ReconChildGridView_a["COST_FOR_PERIOD_AS_PER_RPT_AS_ON"] = n_childIndex_a;
                                    perColumn.Text = perColumn.Text.Replace("|", s_RptDate).Replace("~", Convert.ToString(ac_AccountingReport.ds_ReportDetails.Tables[8].Copy().Rows[0]["PREV_LOCKED_REPORTING_DATE"]));
                                    break;

                                case "COST OF GRANTS DURING THE PERIOD":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_b":
                                            ht_ReconChildGridView_b["COST_OF_GRANTS_DURING_PERIOD"] = n_childIndex_b;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["COST_OF_GRANTS_DURING_PERIOD"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "REVERSAL OF COST DUE TO CANCELLATION":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_c":
                                            ht_ReconChildGridView_c["REV_COST_DUE_CANC"] = n_childIndex_c;
                                            break;

                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["REV_COST_DUE_CANC"] = n_childIndex_f;
                                            break;
                                    }

                                    break;

                                case "COMPENSATION COST FOR FY @ BASED ON LAST YEAR NUMBERS":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["COMP_COST_FOR_FY_BY_PREV"] = n_childIndex_f;
                                            break;
                                    }

                                    perColumn.Text = ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0
                                                    ? perColumn.Text.Replace("@", Convert.ToString(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["FY"]))
                                                    : perColumn.Text;
                                    break;

                                case "COMPENSATION COST FOR FY @ BASED ON CURRENT REPORT":
                                    switch (s_GridViewID)
                                    {
                                        case "grdView_Child_f":
                                            ht_ReconChildGridView_f["COMP_COST_FOR_FY_BY_CURRENT"] = n_childIndex_f;
                                            break;
                                    }

                                    perColumn.Text = ac_AccountingReport.ds_ReportDetails.Tables[9] != null && ac_AccountingReport.ds_ReportDetails.Tables[9].Rows.Count > 0
                                                    ? perColumn.Text.Replace("@", Convert.ToString(ac_AccountingReport.ds_ReportDetails.Tables[9].Rows[0]["FY"]))
                                                    : perColumn.Text;
                                    break;
                            }

                            switch (s_GridViewID)
                            {
                                case "grdView_Child_a":
                                    n_childIndex_a = n_childIndex_a + 1;
                                    break;

                                case "grdView_Child_b":
                                    n_childIndex_b = n_childIndex_b + 1;
                                    break;

                                case "grdView_Child_c":
                                    n_childIndex_c = n_childIndex_c + 1;
                                    break;

                                case "grdView_Child_f":
                                    n_childIndex_f = n_childIndex_f + 1;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:


                        switch (s_GridViewID)
                        {
                            case "grdView_Child_a":
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["GRANT_DATE"])].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["GRANT_DATE"])].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["VEST_DATE"])].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["VEST_DATE"])].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["ACCR_VEST_DATE"])].Text = !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["ACCR_VEST_DATE"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["ACCR_VEST_DATE"])].Text.Equals("&nbsp;") ? Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["ACCR_VEST_DATE"])].Text).ToString("dd/MMM/yyyy") : e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["ACCR_VEST_DATE"])].Text;

                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["SCH_NAME"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["GRANT_REG_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["EMP_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["EMP_NAME"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["GRANT_OPT_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["FORFT_GRP"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["RATE_APPLIED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["CURRENCY"])].HorizontalAlign = HorizontalAlign.Left;

                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["OPT_GRANTED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["OPT_VESTED_CANCELLED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["OPT_UNVESTED_CANCELLED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["OPT_LAPSED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["VESTED_AND_EXERCISABLE_OPT"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["UNVESTED_OPT"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["OUTSTANDING_OPT"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["EXERCISED_OPT"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["OPT_CANC_DURING_PERIOD"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["OPT_CANC_DURING_PERIOD_COST_REVERSED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["LIVE_OPT_FOR_COMP_COST"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["ACCR_OPT"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["FORFT_RATE"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["OPT_LIKLY_TO_BE_FORFITED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["NET_OPT_FOR_COMP_COST"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["EX_PRC"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["EX_PRC_POST_CORP_ACT_MODF"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["IV_FV"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["IV_FV_POST_CORP_ACT_MODF_EDL"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["TOTAL_COMP_COST"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_a["COST_FOR_PERIOD_AS_PER_RPT_AS_ON"])].HorizontalAlign = HorizontalAlign.Right;

                                break;

                            case "grdView_Child_b":
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["GRANT_DATE"])].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["GRANT_DATE"])].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["VEST_DATE"])].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["VEST_DATE"])].Text).ToString("dd/MMM/yyyy");

                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["SCH_NAME"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["GRANT_REG_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["EMP_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["EMP_NAME"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["GRANT_OPT_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["VEST_ID"])].HorizontalAlign = HorizontalAlign.Left;

                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["NET_OPT_FOR_COMP_COST"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["IV_FV"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["TOTAL_COMP_COST"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["COST_OF_GRANTS_DURING_PERIOD"])].HorizontalAlign = HorizontalAlign.Right;

                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_b["OPT_GRANTED"])].Visible = false;
                                break;

                            case "grdView_Child_c":
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["GRANT_DATE"])].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["GRANT_DATE"])].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["VEST_DATE"])].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["VEST_DATE"])].Text).ToString("dd/MMM/yyyy");

                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["SCH_NAME"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["GRANT_REG_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["EMP_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["EMP_NAME"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["GRANT_OPT_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["VEST_ID"])].HorizontalAlign = HorizontalAlign.Left;

                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["OPT_CANC_DURING_PERIOD"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["OPT_CANC_DURING_PERIOD_COST_REVERSED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["NET_OPT_FOR_COMP_COST"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["IV_FV"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["TOTAL_COMP_COST"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_c["REV_COST_DUE_CANC"])].HorizontalAlign = HorizontalAlign.Right;

                                break;

                            case "grdView_Child_f":
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["GRANT_DATE"])].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["GRANT_DATE"])].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["VEST_DATE"])].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["VEST_DATE"])].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["ACCR_VEST_DATE"])].Text = !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["ACCR_VEST_DATE"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["ACCR_VEST_DATE"])].Text.Equals("&nbsp;") ? Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["ACCR_VEST_DATE"])].Text).ToString("dd/MMM/yyyy") : e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["ACCR_VEST_DATE"])].Text;

                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["SCH_NAME"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["GRANT_REG_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["EMP_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["EMP_NAME"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["GRANT_OPT_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["VEST_ID"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["FORFT_GRP"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["RATE_APPLIED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["CURRENCY"])].HorizontalAlign = HorizontalAlign.Left;

                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["OPT_GRANTED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["OPT_VESTED_CANCELLED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["OPT_UNVESTED_CANCELLED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["OPT_LAPSED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["VESTED_AND_EXERCISABLE_OPT"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["UNVESTED_OPT"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["OUTSTANDING_OPT"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["EXERCISED_OPT"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["OPT_CANC_DURING_PERIOD"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["OPT_CANC_DURING_PERIOD_COST_REVERSED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["LIVE_OPT_FOR_COMP_COST"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["ACCR_OPT"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["FORFT_RATE"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["OPT_LIKLY_TO_BE_FORFITED"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["NET_OPT_FOR_COMP_COST"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["EX_PRC"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["EX_PRC_POST_CORP_ACT_MODF"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["IV_FV"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["IV_FV_POST_CORP_ACT_MODF_EDL"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["TOTAL_COMP_COST"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["COST_OF_GRANTS_DURING_PERIOD"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["REV_COST_DUE_CANC"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["COMP_COST_FOR_FY_BY_PREV"])].HorizontalAlign =
                                e.Row.Cells[Convert.ToInt32(ht_ReconChildGridView_f["COMP_COST_FOR_FY_BY_CURRENT"])].HorizontalAlign = HorizontalAlign.Right;

                                break;
                        }

                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Merge the Rows as per Grant Option ID
        /// </summary>
        /// <param name="grdView_Child">grdView_Child GridView</param>
        private void MergeRows(GridView grdView_Child)
        {
            try
            {
                for (int n_rowIndex = grdView_Child.Rows.Count - 2; n_rowIndex >= 0; n_rowIndex--)
                {
                    GridViewRow perRow = grdView_Child.Rows[n_rowIndex];
                    GridViewRow previousRow = grdView_Child.Rows[n_rowIndex + 1];

                    if (perRow.Cells[5].Text == previousRow.Cells[5].Text)
                    {
                        perRow.Cells[5].RowSpan = previousRow.Cells[5].RowSpan < 2 ? 2 :
                                               previousRow.Cells[5].RowSpan + 1;

                        previousRow.Cells[5].Visible = false;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The PreRender Event Of gvAccReportingRecon GridView
        /// </summary>
        /// <param name="sender">gvAccReportingRecon GridView</param>
        /// <param name="e">e</param>
        internal void gvAccReportingRecon_PreRender(object sender, EventArgs e)
        {
            try
            {
                if (((GridView)sender) != null && ((GridView)sender).Rows.Count > 0)
                {
                    GridViewRow gv_Row = ((GridView)sender).Rows[((GridView)sender).Rows.Count - 1];
                    gv_Row.Cells[2].Text = ac_AccountingReport.ds_ReconReport.Tables[2].Copy() != null && ac_AccountingReport.ds_ReconReport.Tables[2].Copy().Rows.Count > 0 ? Convert.ToString(ac_AccountingReport.ds_ReconReport.Tables[2].Copy().Compute("sum([Cost of Grants during the period])", string.Empty)) : "0";
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accReportingReconPopUp"></param>
        public void ExportToExcel(AccReportingReconPopUp accReportingReconPopUp)
        {
            HttpResponse response = HttpContext.Current.Response;
            HttpContext.Current.Response.ClearHeaders();
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
            HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "Test"));
            HttpContext.Current.Response.Charset = string.Empty;

            // create a string writer
            using (StringWriter sw = new StringWriter())
            {
                using (HtmlTextWriter htw = new HtmlTextWriter(sw))
                {

                    // instantiate a datagrid                    

                    accReportingReconPopUp.gvAccReportingRecon.RenderControl(htw);
                    response.Write(sw.ToString());
                    HttpContext.Current.ApplicationInstance.CompleteRequest();

                }
            }

        }

        #region Destructor
        /// <summary>
        /// Default Destructor
        /// </summary>
        ~AccReportingReconPopUpModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}