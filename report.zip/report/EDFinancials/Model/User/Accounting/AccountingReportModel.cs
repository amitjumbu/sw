﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using Ionic.Zip;
using excel = Microsoft.Office.Interop.Word;
using Excel = Microsoft.Office.Interop.Excel;
using SSRSReportSubscriptionLibrary.DTO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text.html;
using Microsoft.Office.Interop.Word;






namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Accounting Report Model class
    /// </summary>
    public class AccountingReportModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Datetime Object
        /// </summary>
        DateTime? dt = null;
        string s_Val = string.Empty;
        #region Default constructor

        /// <summary>
        /// Default Constructor
        /// </summary>
        public AccountingReportModel()
        {
            if (ac_AccountingReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_AccountingReport);
                ac_AccountingReport = (CommonModel.AC_AccountingReport)HttpContext.Current.Session[CommonConstantModel.s_AC_AccountingReport];
            }
        }

        #endregion

        #region Page Load Event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        internal void Page_Load(AccountingReport accountingReport)
        {
            try
            {
                CheckEmployeeRolePriviledges(accountingReport);

                BindUI(accountingReport);

                BindAllReports(accountingReport, "Page_Load");

                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.PageName = CommonConstantModel.s_MnuAccountingReport;

                    ac_AccountingReport.dt_CustmizedViewAccounting = (System.Data.DataTable)genericServiceClient.GetCustomizedViewTable(genericProperties);
                }
                DefineRoleRights(accountingReport);
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        internal void DefineRoleRights(AccountingReport accountingReport)
        {
            try
            {
                accountingReport.btnARViewCancellationWorking.Enabled = GetRolesFormDb(CommonConstantModel.s_AccCancellationReport);
                accountingReport.btnARViewSummaryWorking.Enabled = GetRolesFormDb(CommonConstantModel.s_AccSummaryReport);
                accountingReport.btnARViewReconciliation.Enabled = GetRolesFormDb(CommonConstantModel.s_AccReconciliationReport);
            }
            catch
            {

            }
        }

        /// <summary>
        /// Get role and rights from database
        /// </summary>
        private bool GetRolesFormDb(string s_PageName)
        {
            genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
            genericProperties.PageName = s_PageName;
            genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

            using (System.Data.DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
            {
                if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                {
                    return dt_RolePerviledges.Select("PRIVILEDGES = 'VIEW'").Count() > 0;
                }
            }
            return false;
        }

        #region Control Events
        /// <summary>
        /// Date text change event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="s_ReportingDate">s_ReportingDate</param>
        /// <param name="s_GroupID">Accounting Report Group ID object</param>
        internal void txtARDate_TextChanged(AccountingReport accountingReport, string s_ReportingDate, string s_GroupID)
        {
            try
            {
                if (!string.IsNullOrEmpty(s_ReportingDate) && !s_ReportingDate.Equals("dd/mmm/yyyy"))
                {
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PopulateControls = CommonConstantModel.s_ReportFilters;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.REPORTING_DATE = s_ReportingDate;
                        ac_AccountingReport.s_Reporting_Date = s_ReportingDate;
                        accountingProperties.Type = "FILTERS";
                        ac_AccountingReport.ds_ReportFilters = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                        //accountingReport.mddlARSchemeName.chkMultiselect.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[0].AsEnumerable()
                        //                                                               select b.Field<string>("SCH_SCHEME_TITLE"));
                        //accountingReport.mddlARSchemeName.chkMultiselect.DataBind();						

                        //accountingReport.mddlAREmployeeID.chkMultiselect.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[1].AsEnumerable()
                        //                                                               where b.Field<string>("EMPLOYEE_ID") != null
                        //                                                               select b.Field<string>("EMPLOYEE_ID"));
                        //accountingReport.mddlAREmployeeID.chkMultiselect.DataBind();

                        //accountingReport.mddlAREmployeeName.chkMultiselect.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[2].AsEnumerable()
                        //                                                                 where b.Field<string>("EMPLOYEE_NAME") != null
                        //                                                                 select b.Field<string>("EMPLOYEE_NAME"));
                        //accountingReport.mddlAREmployeeName.chkMultiselect.DataBind();

                        //accountingReport.mddlARGrantRegID.chkMultiselect.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[3].AsEnumerable()
                        //                                                               where b.Field<string>("GRS_GRANT_REGISTRATION_ID") != null
                        //                                                               select b.Field<string>("GRS_GRANT_REGISTRATION_ID"));
                        //accountingReport.mddlARGrantRegID.chkMultiselect.DataBind();

                        //accountingReport.mddlARGrantOptID.chkMultiselect.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[4].AsEnumerable()
                        //                                                               where b.Field<string>("GRANT_OPTION_ID") != null
                        //                                                               select b.Field<string>("GRANT_OPTION_ID"));
                        //accountingReport.mddlARGrantOptID.chkMultiselect.DataBind();

                        accountingReport.ddlARFinancialYrFrom.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[5].AsEnumerable()
                                                                            where b.Field<string>("FINC_YEAR") != null
                                                                            select b.Field<string>("FINC_YEAR")).Distinct();
                        accountingReport.ddlARFinancialYrFrom.DataBind();
                        accountingReport.ddlARFinancialYrFrom.Items.Insert(0, "--- Please Select ---");

                        accountingReport.ddlARFinancialYrTo.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[5].AsEnumerable()
                                                                          where b.Field<string>("FINC_YEAR") != null
                                                                          select b.Field<string>("FINC_YEAR")).Distinct();
                        accountingReport.ddlARFinancialYrTo.DataBind();
                        accountingReport.ddlARFinancialYrTo.Items.Insert(0, "--- Please Select ---");

                        accountingReport.ddlARFinancialQrFrom.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[5].AsEnumerable()
                                                                            where b.Field<string>("FINC_QUARTER") != null
                                                                            select b.Field<string>("FINC_QUARTER")).Distinct();
                        accountingReport.ddlARFinancialQrFrom.DataBind();
                        accountingReport.ddlARFinancialQrFrom.Items.Insert(0, "--- Please Select ---");

                        accountingReport.ddlARFinancialQrTo.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[5].AsEnumerable()
                                                                          where b.Field<string>("FINC_QUARTER") != null
                                                                          select b.Field<string>("FINC_QUARTER")).Distinct();
                        accountingReport.ddlARFinancialQrTo.DataBind();
                        accountingReport.ddlARFinancialQrTo.Items.Insert(0, "--- Please Select ---");

                        accountingReport.ddlARFinancialMonthFrom.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[6].AsEnumerable()
                                                                               where b.Field<string>("PARAM") != null
                                                                               select b.Field<string>("PARAM")).Distinct();
                        accountingReport.ddlARFinancialMonthFrom.DataBind();
                        accountingReport.ddlARFinancialMonthFrom.Items.Insert(0, "--- Please Select ---");

                        accountingReport.ddlARFinancialMonthTo.DataSource = (from b in ac_AccountingReport.ds_ReportFilters.Tables[6].AsEnumerable()
                                                                             where b.Field<string>("PARAM") != null
                                                                             select b.Field<string>("PARAM")).Distinct();
                        accountingReport.ddlARFinancialMonthTo.DataBind();
                        accountingReport.ddlARFinancialMonthTo.Items.Insert(0, "--- Please Select ---");

                        accountingReport.hdnARCompanyName.Value = userSessionInfo.ACC_CompanyName;
                        accountingReport.hdnARAccordionIndex.Value = "1";
                        accountingReport.h4ARAddEditPanel.Style.Add("display", "");
                        accountingReport.divARReportSection.Style.Add("display", "none");
                        accountingReport.divAREmptyRow.Style.Add("display", "none");
                        accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "none");

                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.OPERATION_DATE = (!string.IsNullOrEmpty(accountingReport.txtARDate.Text) || accountingReport.txtARDate.Text.Equals("dd/mmm/yyyy")) ? Convert.ToDateTime(accountingReport.txtARDate.Text.ToString()) : dt;
                        accountingProperties.ACTION_TYPE = "ACCOUNTING_REPORTS";
                        accountingProperties.PopulateControls = "GET_ACCOUNTING_PARAMS";

                        ac_AccountingReport.ds_AccountingParams = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                        if (string.IsNullOrEmpty(s_GroupID))
                        {
                            accountingReport.rdoARMarketPriceType.Items.FindByValue("FV").Selected = ac_AccountingReport.ds_AccountingParams != null && ac_AccountingReport.ds_AccountingParams.Tables[0] != null && ac_AccountingReport.ds_AccountingParams.Tables[0].Rows.Count > 0 && (ac_AccountingReport.ds_AccountingParams.Tables[0].Rows[0]["Valuation Method"].ToString().Equals("rdbVMCC03") || ac_AccountingReport.ds_AccountingParams.Tables[0].Rows[0]["Valuation Method"].ToString().Equals("rdbVMCC02"));
                            accountingReport.rdoARMarketPriceType.Items.FindByValue("IV").Selected = !accountingReport.rdoARMarketPriceType.Items.FindByValue("FV").Selected;
                        }
                    }
                }
                else
                {
                    ClearControls(accountingReport, "1", s_ReportingDate, "TextChanged");
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// View report button click event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="s_Type">Type which is used to call particular block</param>
        internal void btnARViewReport_Click(AccountingReport accountingReport, string s_Type)
        {
            try
            {
                using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
                {
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PopulateControls = CommonConstantModel.s_MainReport;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.REPORTING_DATE = accountingReport.txtARDate.Text;
                        accountingProperties.MARKET_PRICE_TYPE = accountingReport.rdoARMarketPriceType.SelectedItem.Text;
                        accountingProperties.SCHEME_NAME = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlARSchemeName.chkMultiselect, accountingReport.mddlARSchemeName.txtMultiselect);
                        accountingProperties.EMPLOYEE_ID = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlAREmployeeID.chkMultiselect, accountingReport.mddlAREmployeeID.txtMultiselect);
                        accountingProperties.EMPLOYEE_NAME = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlAREmployeeName.chkMultiselect, accountingReport.mddlAREmployeeName.txtMultiselect);
                        accountingProperties.GRANT_REGISTRATION_ID = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlARGrantRegID.chkMultiselect, accountingReport.mddlARGrantRegID.txtMultiselect);
                        accountingProperties.GRANT_OPTION_ID = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlARGrantOptID.chkMultiselect, accountingReport.mddlARGrantOptID.txtMultiselect);
                        accountingProperties.IS_SENIOR_MANAGEMENT_CHECKED = accountingReport.chkARSeniorManagement.Checked;
                        if (!accountingReport.txtARGrantFromDate.Text.Equals("dd/mmm/yyyy") && !string.IsNullOrEmpty(accountingReport.txtARGrantFromDate.Text))
                            accountingProperties.GRANT_FROM_DATE = accountingReport.txtARGrantFromDate.Text;
                        if (!accountingReport.txtARGrantToDate.Text.Equals("dd/mmm/yyyy") && !string.IsNullOrEmpty(accountingReport.txtARGrantToDate.Text))
                            accountingProperties.GRANT_TO_DATE = accountingReport.txtARGrantToDate.Text;
                        accountingProperties.DISPLAY_COST_FOR = accountingReport.rdoARDisplayCostFor.SelectedItem.Value;
                        switch (accountingReport.rdoARDisplayCostFor.SelectedItem.Value.Trim())
                        {
                            case "Y":
                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                break;
                            case "Q":
                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_QTR_FROM = accountingReport.ddlARFinancialQrFrom.SelectedItem.Text;
                                }
                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_QTR_TO = accountingReport.ddlARFinancialQrTo.SelectedItem.Text;
                                }
                                break;
                            case "M":
                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialMonthFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialMonthFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_MONTH_FROM = accountingReport.ddlARFinancialMonthFrom.SelectedItem.Text;
                                }
                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialMonthTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialMonthTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_MONTH_TO = accountingReport.ddlARFinancialMonthTo.SelectedItem.Text;
                                }
                                break;
                        }

                        accountingProperties.DISPLAY_COST_BEFORE = accountingReport.rdoARDisplayCostBefore.SelectedItem.Value;
                        accountingProperties.DISPLAY_COST_AFTER = accountingReport.rdoARDisplayCostAfter.SelectedItem.Value;
                        accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                        accountingProperties.CALCULATION_METHOD = userSessionInfo.ACC_CalculationMethod;
                        accountingProperties.Type = s_Type;
                        ac_AccountingReport.ds_ReportDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;

                        if (ac_AccountingReport.ds_ReportDetails.Tables.Count > 0 && ac_AccountingReport.ds_ReportDetails.Tables[0].Rows[0][1].ToString() != "")
                        {
                            // ac_AccountingReport.dt_VestingDetails = ac_AccountingReport.ds_ReportDetails.Tables[2];

                            //System.Data.DataTable dt_TMDFiltered = new System.Data.DataTable();
                            //dt_TMDFiltered = ac_AccountingReport.ds_ReportDetails.Tables[1];
                            //ac_AccountingReport.dt_SummaryReport = dt_TMDFiltered.DefaultView.ToTable();
                            //ac_AccountingReport.dt_SummaryReport.AcceptChanges();

                            ac_AccountingReport.dt_MainReport = ac_AccountingReport.ds_ReportDetails.Tables[0];
                            if (ac_AccountingReport.ds_ReportDetails.Tables[0].Rows.Count > 0)
                            {
                                accountingReport.divARReportSection.Style.Add("display", "");
                                accountingReport.divAREmptyRow.Style.Add("display", "none");
                            }
                            else
                            {
                                accountingReport.divARReportSection.Style.Add("display", "none");
                                accountingReport.divAREmptyRow.Style.Add("display", "");
                            }
                            accountingReport.gvARMainReport.DataSource = ac_AccountingReport.dt_MainReport;
                            accountingReport.gvARMainReport.DataBind();
                            accountingReport.hdnARAccordionIndex.Value = "1";
                            accountingReport.h4ARAddEditPanel.Style.Add("display", "");
                            accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "none");

                            int CustomizeView_ID = 0;
                            int.TryParse(accountingReport.ddlDefaultView.SelectedValue, out CustomizeView_ID);
                            accountingProperties.s_Customize_ViewName_ID = CustomizeView_ID;
                            if (accountingProperties.Type.Equals("SUMMARY"))
                                ac_AccountingReport.dt_SummaryDReport = ac_AccountingReport.dt_MainReport;
                            //accountingReport.gvARSummaryReport.PageSize = ac_AccountingReport.dt_CustmizedViewAccounting != null && ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count > 0 ? Convert.ToInt32(ac_AccountingReport.dt_CustmizedViewAccounting.Rows[0]["NO_OF_ROWS"].ToString()) : accountingReport.gvARDetails.PageSize;
                            //accountingReport.gvARSummaryReport.DataSource = ac_AccountingReport.dt_SummaryReport;
                            //accountingReport.gvARSummaryReport.DataBind();

                            //ac_AccountingReport.s_GOPIDList = string.Join(",", ac_AccountingReport.dt_SummaryReport.AsEnumerable()
                            //               .Where(b => string.IsNullOrEmpty(b["OPID"].ToString()))
                            //               .Select(b => b["GRANT_OPTION_ID"])
                            //               .ToArray().Distinct());
                            //accountingReport.hdnOPList.Value = ac_AccountingReport.s_GOPIDList.ToString().TrimEnd(',');
                            accountingReport.lblARReportAsOnDate.Text = "Report as on Date - " + accountingReport.txtARDate.Text;
                            accReportingCommonModel.EncryptData(accountingReport, accountingProperties);
                            ac_AccountingReport.s_Selected_Opt_GrantIDs = ac_AccountingReport.ds_ReportDetails.Tables[3].Rows.Count > 0 ? Convert.ToString(ac_AccountingReport.ds_ReportDetails.Tables[3].Rows[0]["OPT_GRANT_IDs"]) : string.Empty;
                            accountingReport.hdnCAAppliedOnDate.Value = Convert.ToString(CheckCActionApplyOnRptDate(accountingReport.txtARDate.Text, userSessionInfo));
                        }
                        else
                        {
                            //accountingReport.ctrSuccessErrorMessage.Visible = true;
                            //accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            //accountingReport.ctrSuccessErrorMessage.lblMessage.Text = accountingServiceClient.GetAccounting_L10N("CantViewReport", CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10);
                            //accountingReport.ctrSuccessErrorMessage.lblMessage.ForeColor = Color.Red;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountingReport"></param>
        /// <param name="s_Type"></param>
        internal void btnDwnldReport_Click(AccountingReport accountingReport, string s_Type)
        {
            try
            {
                using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
                {
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PopulateControls = CommonConstantModel.s_MainReport;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.REPORTING_DATE = accountingReport.txtARDate.Text;
                        accountingProperties.MARKET_PRICE_TYPE = accountingReport.rdoARMarketPriceType.SelectedItem.Text;
                        accountingProperties.SCHEME_NAME = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlARSchemeName.chkMultiselect, accountingReport.mddlARSchemeName.txtMultiselect);
                        accountingProperties.EMPLOYEE_ID = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlAREmployeeID.chkMultiselect, accountingReport.mddlAREmployeeID.txtMultiselect);
                        accountingProperties.EMPLOYEE_NAME = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlAREmployeeName.chkMultiselect, accountingReport.mddlAREmployeeName.txtMultiselect);
                        accountingProperties.GRANT_REGISTRATION_ID = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlARGrantRegID.chkMultiselect, accountingReport.mddlARGrantRegID.txtMultiselect);
                        accountingProperties.GRANT_OPTION_ID = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlARGrantOptID.chkMultiselect, accountingReport.mddlARGrantOptID.txtMultiselect);
                        accountingProperties.IS_SENIOR_MANAGEMENT_CHECKED = accountingReport.chkARSeniorManagement.Checked;
                        if (!accountingReport.txtARGrantFromDate.Text.Equals("dd/mmm/yyyy") && !string.IsNullOrEmpty(accountingReport.txtARGrantFromDate.Text))
                            accountingProperties.GRANT_FROM_DATE = accountingReport.txtARGrantFromDate.Text;
                        if (!accountingReport.txtARGrantToDate.Text.Equals("dd/mmm/yyyy") && !string.IsNullOrEmpty(accountingReport.txtARGrantToDate.Text))
                            accountingProperties.GRANT_TO_DATE = accountingReport.txtARGrantToDate.Text;
                        accountingProperties.DISPLAY_COST_FOR = accountingReport.rdoARDisplayCostFor.SelectedItem.Value;
                        switch (accountingReport.rdoARDisplayCostFor.SelectedItem.Value.Trim())
                        {
                            case "Y":
                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                break;
                            case "Q":
                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_QTR_FROM = accountingReport.ddlARFinancialQrFrom.SelectedItem.Text;
                                }
                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_QTR_TO = accountingReport.ddlARFinancialQrTo.SelectedItem.Text;
                                }
                                break;
                            case "M":
                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialMonthFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialMonthFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_MONTH_FROM = accountingReport.ddlARFinancialMonthFrom.SelectedItem.Text;
                                }
                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialMonthTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialMonthTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_MONTH_TO = accountingReport.ddlARFinancialMonthTo.SelectedItem.Text;
                                }
                                break;
                        }

                        accountingProperties.DISPLAY_COST_BEFORE = accountingReport.rdoARDisplayCostBefore.SelectedItem.Value;
                        accountingProperties.DISPLAY_COST_AFTER = accountingReport.rdoARDisplayCostAfter.SelectedItem.Value;
                        accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                        accountingProperties.CALCULATION_METHOD = userSessionInfo.ACC_CalculationMethod;
                        accountingProperties.Type = s_Type;
                        ac_AccountingReport.ds_ReportDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;

                        if (ac_AccountingReport.ds_ReportDetails.Tables.Count > 0 && ac_AccountingReport.ds_ReportDetails.Tables[0].Rows[0][1].ToString() != "")
                        {
                            System.Data.DataTable dt_Result = new System.Data.DataTable();
                            dt_Result = ac_AccountingReport.ds_ReportDetails.Tables[0];

                                    var excelRepo = new Excel.Application();
                                    string excelFilePath = null;
                                    excelRepo.Workbooks.Add();

                                    Excel._Worksheet sheet = excelRepo.ActiveSheet;


                                  int firstrow = 0; int firstCol = 0; int lastRow = 0 ; int lastCol = 0;

                                   Excel.Range top = sheet.Cells[firstrow, firstCol];
                                   Excel.Range bottom = sheet.Cells[lastRow, lastCol];
                                   Excel.Range all = (Excel.Range)sheet.get_Range(top, bottom);

                                    string[,] arrayDT = new string[dt_Result.Rows.Count, dt_Result.Columns.Count];

                                    for (int i = 0; i < dt_Result.Rows.Count; i++)

                                        for (int j = 0; j < dt_Result.Columns.Count; j++)

                                            arrayDT[i, j] = dt_Result.Rows[i][j].ToString();
                                    all.Value2= arrayDT;

                                    if (!string.IsNullOrEmpty(excelFilePath))
                                    {
                                        try
                                        {
                                            sheet.SaveAs(excelFilePath);
                                            excelRepo.Quit();
                                        }
                                        catch (Exception ex)
                                        {
                                            throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"
                                                                + ex.Message);
                                        }
                                    }
                                    else
                                    { // no file path is given
                                        excelRepo.Visible = true;
                                    }

                                    


                        }
                    }
                }
            }

            catch (Exception ex)
            {
                string message = ex.Message;
                HttpContext.Current.Response.Flush();
            }
        }


        /// <summary>
        ///  This method is used to get Details report(Currently it's nt used)
        /// </summary>
        /// <param name="accountingReport">accountingReport object</param>
        internal void ViewDetailsReport(AccountingReport accountingReport)
        {
            System.Data.DataTable dt_TMDFiltered = new System.Data.DataTable();
            dt_TMDFiltered = ac_AccountingReport.ds_ReportDetails.Tables[0];
            ac_AccountingReport.dt_SummaryReport = dt_TMDFiltered.DefaultView.ToTable();
            ac_AccountingReport.dt_SummaryReport.AcceptChanges();
            accountingReport.gvARMainReport.DataSource = ac_AccountingReport.dt_SummaryDReport != null && ac_AccountingReport.dt_SummaryDReport.Rows.Count > 0 ? ac_AccountingReport.dt_SummaryDReport : new System.Data.DataTable();
            accountingReport.gvARMainReport.DataBind();
            accountingReport.hdnARAccordionIndex.Value = "2";
            accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "block");
            int CustomizeView_ID = 0;
            int.TryParse(accountingReport.ddlDefaultView.SelectedValue, out CustomizeView_ID);
            accountingProperties.s_Customize_ViewName_ID = CustomizeView_ID;
            //accountingReport.gvARSummaryReport.PageSize = ac_AccountingReport.dt_CustmizedViewAccounting != null && ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count > 0 ? Convert.ToInt32(ac_AccountingReport.dt_CustmizedViewAccounting.Rows[0]["NO_OF_ROWS"].ToString()) : accountingReport.gvARDetails.PageSize;
            //accountingReport.gvARSummaryReport.DataSource = ac_AccountingReport.dt_SummaryReport;
            //accountingReport.gvARSummaryReport.DataBind();

            ac_AccountingReport.s_GOPIDList = string.Join(",", ac_AccountingReport.dt_SummaryReport.AsEnumerable()
                           .Where(b => string.IsNullOrEmpty(b["OPID"].ToString()))
                           .Select(b => b["GRANT_OPTION_ID"])
                           .ToArray().Distinct());
            accountingReport.hdnOPList.Value = ac_AccountingReport.s_GOPIDList.ToString().TrimEnd(',');
        }

        /// <summary>
        /// This method is used to check Corporate Action is apply on Reporting date or not
        /// </summary>
        /// <param name="s_Date">s_Date Object</param>
        /// <param name="userSessionInfo">userSessionInfo object</param>
        /// <returns></returns>
        public static bool CheckCActionApplyOnRptDate(string s_Date, EDFinancials.Model.SessionContext.UserSessionInfo userSessionInfo)
        {
            try
            {
                bool b_chkApplied = false;
                AccountingProperties accountingProperties = new AccountingProperties();
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_ReportFilters;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.Type = "CORP_ACTION_APPLIED_OR_NOT";

                    using (System.Data.DataTable dt_ReportData = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[0].Copy())
                    {
                        if (dt_ReportData != null && dt_ReportData.Rows.Count > 0 && dt_ReportData.Select("APPLIED = 0").Count() > 0)
                        {
                            b_chkApplied = (!string.IsNullOrEmpty(s_Date)) ? Convert.ToDateTime(s_Date) >= dt_ReportData.AsEnumerable()
                                                                                    .Where(b => b.Field<string>("APPLIED") == "0")
                                                                                    .Max(c => c.Field<DateTime>("EFFECTIVE_DATE")) : false;
                        }
                    }
                }
                return b_chkApplied;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Template Send for Review button click event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        public void btnARTemplateSendForReview_Click(AccountingReport accountingReport)
        {
            try
            {
                if (ac_AccountingReport.n_ClientApprovalStatus.Equals(3) || (Convert.ToInt32(ac_AccountingReport.s_GroupID).Equals(0) && !File.Exists(Path.Combine(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + ac_AccountingReport.s_GroupID + "/"), accountingReport.ddlARSelectTemplate.SelectedItem.Text.Trim() + "_" + Convert.ToDateTime(accountingReport.txtARDate.Text).ToString("dd-MMM-yyyy") + "_Version-1.0" + ".pdf"))))
                {
                    if (ac_AccountingReport.n_ClientApprovalStatus.Equals(3))
                        ShowHideMessageDiv(accountingReport, "GenerateNewVersionErrorMsg", true, string.Empty);
                    else ShowHideMessageDiv(accountingReport, "GenerateFileErrorMsg", true, string.Empty);
                    accountingReport.divARReportStatusSection.Style.Add("display", "none");
                    accountingReport.divARSelectTemplate.Style.Add("display", "");
                    accountingReport.hdnARAccordionIndex.Value = "2";
                    accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "");
                    RebindGridData(accountingReport);
                }
                else
                {
                    using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
                    {
                        using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                        {
                            accountingProperties = new AccountingProperties();
                            accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                            accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                            accountingProperties.PopulateControls = "VALIDATE_ACCOUNTING_REPORT";
                            accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            accountingProperties.OPT_GRANT_IDs = ac_AccountingReport.s_Selected_Opt_GrantIDs;
                            accountingProperties.ACC_RPT_GROUP_ID = 0;
                            accountingProperties.REPORTING_DATE = accountingReport.txtARDate.Text;

                            using (System.Data.DataTable dt_RetValue = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[0].Copy())
                            {
                                if (Convert.ToInt32(dt_RetValue.Rows[0]["RESULT"]).Equals(1))
                                {
                                    accountingProperties = new AccountingProperties();
                                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                                    accountingProperties.PopulateControls = CommonConstantModel.s_CUDReportData;
                                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                    accountingProperties.OPT_GRANT_IDs = ac_AccountingReport.s_Selected_Opt_GrantIDs;
                                    accountingProperties.REPORTING_DATE = accountingReport.txtARDate.Text;
                                    accountingProperties.DISPLAY_COST_FOR = accountingReport.rdoARDisplayCostFor.SelectedItem.Value;
                                    accountingProperties.REPORT_NAME = accountingReport.ddlARSelectTemplate.SelectedItem.Text.Trim() + "_" + Convert.ToDateTime(accountingReport.txtARDate.Text).ToString("dd-MMM-yyyy") + "_Version-1";
                                    accountingProperties.SELECTED_TEMPLATE_NAME = accountingReport.ddlARSelectTemplate.SelectedItem.Text;
                                    accountingProperties.IS_SENT_FOR_REVIEW = true;
                                    accountingProperties.SENT_FOR_REVIEW_DATE = Convert.ToDateTime(DateTime.Now).ToString("dd/MMM/yyyy");
                                    accountingProperties.REVIEWER_APPROVAL_STATUS = 1;
                                    accountingProperties.COMMENTS = accountingReport.txtARTemplateComment.Text;
                                    accountingProperties.COMMENTS_ADDED_BY = "User";
                                    accountingProperties.VERSION_NUMBER = ac_AccountingReport.n_VersionNo;
                                    accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                                    accountingProperties.Action = "U";
                                    accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(ac_AccountingReport.s_GroupID);
                                    switch (Convert.ToString(accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result.Rows[0]["Result"]))
                                    {
                                        case "1": ShowHideMessageDiv(accountingReport, "ReportCreatedSuccessMsg", false, string.Empty); break;
                                        case "2":
                                            {
                                                ShowHideMessageDiv(accountingReport, "ReportCreatedSuccessMsg", false, string.Empty);
                                                if (Convert.ToUInt32(ac_AccountingReport.n_VersionNo) > 1)
                                                    accReportingCommonModel.SendMail("AccountingCompletedChanges", accountingReport, "REVIEWER", ac_AccountingReport.s_GroupID, ac_AccountingReport.n_VersionNo);
                                                else accReportingCommonModel.SendMail("AccountingReportSentForReview", accountingReport, "REVIEWER", ac_AccountingReport.s_GroupID, ac_AccountingReport.n_VersionNo);
                                            }
                                            break;
                                        case "3": ShowHideMessageDiv(accountingReport, "ReportDeletedSuccessMsg", false, string.Empty); break;
                                        case "4": ShowHideMessageDiv(accountingReport, "ReportGrantAlreadyExistsErrorMsg", true, string.Empty); break;
                                        case "6": ShowHideMessageDiv(accountingReport, "SendValuationReportToReview", true, string.Empty); break;
                                    }
                                    accountingReport.hdnARAccordionIndex.Value = "2";
                                    accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "");
                                    accountingProperties = new AccountingProperties();
                                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                                    accountingProperties.PopulateControls = CommonConstantModel.s_MainReport;
                                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                    accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(ac_AccountingReport.s_GroupID);
                                    accountingProperties.CALCULATION_METHOD = userSessionInfo.ACC_CalculationMethod;
                                    accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                                    ac_AccountingReport.ds_ReportDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                                    BindStatusSection(accountingReport, ac_AccountingReport.ds_ReportDetails.Tables[1], string.Empty);
                                    accountingProperties = new AccountingProperties();
                                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                                    accountingProperties.PopulateControls = "GET_REPORT_BY_GROUP_ID";
                                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                    accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(ac_AccountingReport.s_GroupID);
                                    ac_AccountingReport.dt_CommentsHistory = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[3];
                                    accountingReport.gvARCommentsHistory.DataSource = ac_AccountingReport.dt_CommentsHistory;
                                    accountingReport.gvARCommentsHistory.DataBind();
                                    RebindGridData(accountingReport);
                                }
                                else if (Convert.ToInt32(dt_RetValue.Rows[0]["RESULT"]).Equals(2))
                                {
                                    accountingReport.ctrSuccessErrorMessage.s_MessageText = string.Format(accountingServiceClient.GetAccounting_L10N("GrantsUnlockedErrorMsg", CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10), Convert.ToString(dt_RetValue.Rows[0]["GRANT_REG_IDS"])).Replace("~", "</br>");
                                    accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    accountingReport.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    accountingReport.ctrSuccessErrorMessage.lblMessage.Focus();
                                    accountingReport.divARReportStatusSection.Style.Add("display", "none");
                                    accountingReport.divARSelectTemplate.Style.Add("display", "");
                                    accountingReport.hdnARAccordionIndex.Value = "2";
                                    accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "");
                                    RebindGridData(accountingReport);
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Reviewer approve button click event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="s_ControlID">accountingReport</param>
        public void btnARReviewerApprove_Click(AccountingReport accountingReport, string s_ControlID)
        {
            try
            {
                using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
                {
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                        accountingProperties.PopulateControls = CommonConstantModel.s_CUDReportData;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                        accountingProperties.Action = "U";
                        accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(ac_AccountingReport.s_GroupID);
                        accountingProperties.VERSION_NUMBER = ac_AccountingReport.n_VersionNo;
                        accountingProperties.ACTION_TYPE = "APPROVE_DATA";
                        switch (s_ControlID)
                        {
                            case "btnARReviewerApprove":
                                accountingProperties.REVIEWER_APPROVAL_DATE = Convert.ToDateTime(DateTime.Now).ToString("dd/MMM/yyyy");
                                accountingProperties.REVIEWER_APPROVAL_STATUS = 2;
                                accountingProperties.CLIENT_APPROVAL_STATUS = 1;
                                accountingProperties.IS_SENT_TO_CLIENT = true;
                                accountingProperties.IS_SENT_FOR_REVIEW = true;
                                accountingProperties.COMMENTS = accountingReport.txtARReviewerComment.Text;
                                accountingProperties.COMMENTS_ADDED_BY = "Reviewer";

                                if (Convert.ToString(accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result.Rows[0]["Result"]).Equals("2"))
                                {
                                    ShowHideMessageDiv(accountingReport, "ReviewerApproveSuccessMsg", false, string.Empty);
                                    accReportingCommonModel.SendMail("AccountingApprovedReport", accountingReport, "USER", ac_AccountingReport.s_GroupID, ac_AccountingReport.n_VersionNo);
                                }
                                break;
                            case "btnARReviewerDisApprove":
                                accountingProperties.REVIEWER_APPROVAL_DATE = Convert.ToDateTime(DateTime.Now).ToString("dd/MMM/yyyy");
                                accountingProperties.REVIEWER_APPROVAL_STATUS = 3;
                                accountingProperties.IS_SENT_FOR_REVIEW = false;
                                accountingProperties.CLIENT_APPROVAL_STATUS = 0;
                                accountingProperties.IS_SENT_TO_CLIENT = false;
                                accountingProperties.COMMENTS = accountingReport.txtARReviewerComment.Text;
                                accountingProperties.COMMENTS_ADDED_BY = "Reviewer";
                                if (Convert.ToString(accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result.Rows[0]["Result"]).Equals("2"))
                                {
                                    ShowHideMessageDiv(accountingReport, "ReviewerRejectSuccessMsg", false, string.Empty);
                                    accReportingCommonModel.SendMail("AccountingDisapprovedReport", accountingReport, "USER", ac_AccountingReport.s_GroupID, ac_AccountingReport.n_VersionNo);
                                }
                                break;
                            case "btnARClientApprove":
                                accountingProperties.REVIEWER_APPROVAL_STATUS = 2;
                                accountingProperties.IS_SENT_FOR_REVIEW = true;
                                accountingProperties.IS_SENT_TO_CLIENT = true;
                                accountingProperties.CLIENT_APPROVAL_STATUS = 2;
                                accountingProperties.CLIENT_APPROVAL_DATE = Convert.ToDateTime(DateTime.Now).ToString("dd/MMM/yyyy");
                                accountingProperties.COMMENTS = accountingReport.txtARReviewerComment.Text;
                                accountingProperties.COMMENTS_ADDED_BY = "Client";
                                if (Convert.ToString(accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result.Rows[0]["Result"]).Equals("2"))
                                {
                                    ShowHideMessageDiv(accountingReport, "ClientApproveSuccessMsg", false, string.Empty);
                                    accReportingCommonModel.SendMail("AccountingApprovedReportByClient", accountingReport, "USER", ac_AccountingReport.s_GroupID, ac_AccountingReport.n_VersionNo);
                                }
                                break;
                            case "btnARClientDisApprove":
                                accountingProperties.IS_SENT_FOR_REVIEW = false;
                                accountingProperties.IS_SENT_TO_CLIENT = false;
                                accountingProperties.CLIENT_APPROVAL_STATUS = 3;
                                accountingProperties.CLIENT_APPROVAL_DATE = Convert.ToDateTime(DateTime.Now).ToString("dd/MMM/yyyy");
                                accountingProperties.REVIEWER_APPROVAL_STATUS = 0;
                                accountingProperties.COMMENTS = accountingReport.txtARReviewerComment.Text;
                                accountingProperties.COMMENTS_ADDED_BY = "Client";
                                if (Convert.ToString(accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result.Rows[0]["Result"]).Equals("2"))
                                {
                                    ShowHideMessageDiv(accountingReport, "ClientRejectSuccessMsg", false, string.Empty);
                                    accReportingCommonModel.SendMail("AccountingDisapprovedReportByClient", accountingReport, "USER", ac_AccountingReport.s_GroupID, ac_AccountingReport.n_VersionNo);
                                }
                                break;
                        }
                        ac_AccountingReport.n_ClientApprovalStatus = accountingProperties.CLIENT_APPROVAL_STATUS;
                        accountingReport.hdnARAccordionIndex.Value = "2";
                        accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "");
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PopulateControls = CommonConstantModel.s_MainReport;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(ac_AccountingReport.s_GroupID);
                        accountingProperties.CALCULATION_METHOD = userSessionInfo.ACC_CalculationMethod;
                        accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                        ac_AccountingReport.ds_ReportDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                        BindStatusSection(accountingReport, ac_AccountingReport.ds_ReportDetails.Tables[1], s_ControlID);
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PopulateControls = "GET_REPORT_BY_GROUP_ID";
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(ac_AccountingReport.s_GroupID);
                        ac_AccountingReport.dt_CommentsHistory = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[3];
                        accountingReport.gvARCommentsHistory.DataSource = ac_AccountingReport.dt_CommentsHistory;
                        accountingReport.gvARCommentsHistory.DataBind();
                        RebindGridData(accountingReport);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Lock and delete button click event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        public void btnARLockAndDelete_Click(AccountingReport accountingReport)
        {
            try
            {
                using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
                {
                    string s_UnlockedValGrants = string.Empty;
                    int n_IsInvoiveUploads = 0;
                    var result = string.Empty;
                    var result_Unlocked = string.Empty;
                    if (accountingReport.hdnARActionButtionID.Value.ToUpper().Equals("LBTNARLOCKS") && accountingReport.hdnARSelectedTemplteNme.Value.ToUpper().Equals("LOCK"))
                    {
                        accReportingCommonModel.GetDataForLockedCondition(Convert.ToInt32(accountingReport.hdnARACC_RPT_GRP_ID.Value));
                        result = string.Join(",", (from row in ac_AccountingReport.dt_MainReportDetails.AsEnumerable()
                                                   where (row.Field<DateTime?>("Accounting Report Date") < Convert.ToDateTime(accountingReport.hdnAccReportDate.Value)
                                                   && row.Field<string>("IS_LOCKED") == "0")
                                                   select (Convert.ToDateTime(row.Field<DateTime?>("Accounting Report Date")).ToString("dd/MMM/yyyy"))).ToList());
                        string sval = result.ToString();
                        s_UnlockedValGrants = ValidateGrantsForValuationLocked();
                    }

                    if (accountingReport.hdnARActionButtionID.Value.ToUpper().Equals("LBTNARLOCKS") && accountingReport.hdnARSelectedTemplteNme.Value.ToUpper().Equals("LOCKED") && accountingReport.hdnIsLocked.Value.ToUpper().Equals("LOCKED"))
                    {
                        accReportingCommonModel.GetDataForLockedCondition(Convert.ToInt32(accountingReport.hdnARACC_RPT_GRP_ID.Value));
                        result_Unlocked = string.Join(",", (from row in ac_AccountingReport.dt_MainReportDetails.AsEnumerable()
                                                            where (row.Field<DateTime?>("Accounting Report Date") > Convert.ToDateTime(accountingReport.hdnAccReportDate.Value)
                                                            && row.Field<string>("IS_LOCKED") == "1")
                                                            select (Convert.ToDateTime(row.Field<DateTime?>("Accounting Report Date")).ToString("dd/MMM/yyyy"))).ToList());
                    }
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        if (!string.IsNullOrEmpty(result_Unlocked))
                        {
                            accountingReport.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(accountingServiceClient.GetAccounting_L10N("CantlockUnlessPostLock", CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10)).Replace("~", result_Unlocked);
                            accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                            accountingReport.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            accountingReport.ctrSuccessErrorMessage.lblMessage.Focus();
                            accountingReport.hdnARAccordionIndex.Value = "0";

                            BindAllReports(accountingReport, "LockAndDelete");
                            return;
                        }

                        if (string.IsNullOrEmpty(result))
                        {
                            if (string.IsNullOrEmpty(s_UnlockedValGrants))
                            {
                                if (accountingReport.hdnARActionButtionID.Value.ToUpper().Equals("LBTNARLOCKS") && accountingReport.hdnARSelectedTemplteNme.Value.ToUpper().Equals("LOCK"))
                                    n_IsInvoiveUploads = ValidateReportForInvoiceUploads(accountingReport);

                                if (n_IsInvoiveUploads == 0)
                                {
                                    accountingProperties = new AccountingProperties();
                                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                                    accountingProperties.PopulateControls = CommonConstantModel.s_CUDReportData;
                                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                    accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;

                                    accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(accountingReport.hdnARACC_RPT_GRP_ID.Value);

                                    switch (accountingReport.hdnARActionButtionID.Value.ToUpper())
                                    {
                                        case "LBTNARLOCKS":
                                            accountingProperties.Action = "L";
                                            if (accountingReport.hdnARSelectedTemplteNme.Value.ToUpper().Equals("LOCK"))
                                                accountingProperties.IS_LOCKED = true;
                                            else accountingProperties.IS_LOCKED = false;
                                            if (Convert.ToString(accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result.Rows[0]["Result"]).Equals("5"))
                                            {
                                                ShowHideMessageDiv(accountingReport, (accountingReport.hdnARSelectedTemplteNme.Value.ToUpper().Equals("LOCK")) ? "ReportLockedSuccessMsg" : "ReportUnLockedSuccessMsg", false, string.Empty);
                                            }
                                            break;
                                        case "LBTNARDELETE":
                                            accountingProperties.Action = "D";
                                            accountingProperties.IS_DELETED = true;
                                            if (Convert.ToString(accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result.Rows[0]["Result"]).Equals("3"))
                                            {
                                                ShowHideMessageDiv(accountingReport, "ReportDeletedSuccessMsg", false, string.Empty);
                                            }
                                            break;
                                    }
                                }
                                else
                                {
                                    accountingReport.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(accountingServiceClient.GetAccounting_L10N("CantlockUnlessInvoiceUploads", CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10));
                                    accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    accountingReport.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    accountingReport.ctrSuccessErrorMessage.lblMessage.Focus();
                                }
                            }
                            else
                            {
                                accountingReport.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(accountingServiceClient.GetAccounting_L10N("CantlockUnlessValuationLocked", CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10)).Replace("~", s_UnlockedValGrants);
                                accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                accountingReport.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                accountingReport.ctrSuccessErrorMessage.lblMessage.Focus();
                            }
                        }
                        else
                        {
                            accountingReport.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(accountingServiceClient.GetAccounting_L10N("CantlockUnlessPriorLock", CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10)).Replace("~", result);
                            accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                            accountingReport.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            accountingReport.ctrSuccessErrorMessage.lblMessage.Focus();
                        }
                        accountingReport.hdnARAccordionIndex.Value = "0";

                        BindAllReports(accountingReport, "LockAndDelete");
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method will check whether the Valuation Report is locked or not for Grant(s) before locking Accounting Report
        /// </summary>
        /// <returns>string of Grant(s) for which Valuation is not locked</returns>
        private string ValidateGrantsForValuationLocked()
        {
            try
            {
                string s_UnlockedValGrants = string.Empty;

                if (ac_AccountingReport.ds_ValidateLockGrant.Tables[1] != null && ac_AccountingReport.ds_ValidateLockGrant.Tables[1].Rows.Count > 0)
                {
                    List<string> lst_AccGrants = (from r in ac_AccountingReport.ds_ValidateLockGrant.Tables[0].AsEnumerable()
                                                  select r.Field<string>("GRANTS")).SingleOrDefault().Contains(',')
                                                   ? (from r in ac_AccountingReport.ds_ValidateLockGrant.Tables[0].AsEnumerable()
                                                      select r.Field<string>("GRANTS")).SingleOrDefault().Replace(" ", "").Split(',').ToList()
                                                   : (from r in ac_AccountingReport.ds_ValidateLockGrant.Tables[0].AsEnumerable()
                                                      select r.Field<string>("GRANTS")).ToList();

                    List<string> lst_ValGrants = !string.IsNullOrEmpty(ac_AccountingReport.ds_ValidateLockGrant.Tables[1].Rows[0][0].ToString()) && ac_AccountingReport.ds_ValidateLockGrant.Tables[1].Rows[0][0].ToString().Contains(',')
                                                ? ac_AccountingReport.ds_ValidateLockGrant.Tables[1].Rows[0][0].ToString().Replace(" ", "").Split(',').ToList()
                                                : (from r in ac_AccountingReport.ds_ValidateLockGrant.Tables[1].AsEnumerable()
                                                   select r.Field<string>("LOCKED_VAL_GRANTS")).ToList();

                    List<string> lst_UnlockedValGrants = lst_AccGrants.Except(lst_ValGrants).ToList();

                    s_UnlockedValGrants = lst_UnlockedValGrants.Count() > 0 ? string.Join(", ", lst_UnlockedValGrants) : s_UnlockedValGrants;
                }

                return s_UnlockedValGrants;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Validate Accounting Report
        /// </summary>
        /// <param name="accountingReport">accountingReport</param>
        /// <returns>n_IsValid Before Lock the Report</returns>
        private int ValidateReportForInvoiceUploads(AccountingReport accountingReport)
        {
            try
            {
                int n_IsInvoiveUploads = 0;

                if (ac_AccountingReport.dt_MainReportDetails != null && ac_AccountingReport.dt_MainReportDetails.Rows.Count > 0)
                {
                    DataRow[] dr_row = ac_AccountingReport.dt_MainReportDetails.Select("ACC_RPT_GROUP_ID = '" + Convert.ToInt32(accountingReport.hdnARACC_RPT_GRP_ID.Value) + "'");

                    string s_InvoiceNumber = Convert.ToString(dr_row[0]["INVOICE_NUMBER"]);

                    if (string.IsNullOrEmpty(s_InvoiceNumber))
                        n_IsInvoiveUploads = 1;
                    else
                    {
                        using (System.Data.DataTable dt_RetValue = ac_AccountingReport.ds_ValidateLockGrant.Tables[2].Copy())
                        {
                            n_IsInvoiveUploads = dt_RetValue != null && dt_RetValue.Rows.Count > 0 ? (Convert.ToInt32(dt_RetValue.Rows[0]["NUM_OF_DOCS_UPLOADED"].ToString()).Equals(0) ? 2 : 0) : 0;
                        }
                    }
                }

                return n_IsInvoiveUploads;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Edit and View button click event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="s_GroupID">s_GroupID</param>
        /// <param name="s_ControlID">s_ControlID</param>
        public void btnAREditAndView_Click(AccountingReport accountingReport, string s_GroupID, string s_ControlID)
        {
            try
            {
                using (AccReportingCommonModel AccReportingCommonModel = new AccReportingCommonModel())
                {
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PopulateControls = CommonConstantModel.s_MainReport;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(s_GroupID);
                        accountingProperties.CALCULATION_METHOD = userSessionInfo.ACC_CalculationMethod;
                        accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                        accountingProperties.Type = "SUMMARY";
                        ac_AccountingReport.ds_ReportDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                        ac_AccountingReport.dt_MainReport = ac_AccountingReport.ds_ReportDetails.Tables[0];
                        //ac_AccountingReport.dt_SummaryReport = ac_AccountingReport.ds_ReportDetails.Tables[1];
                        //ac_AccountingReport.dt_VestingDetails = ac_AccountingReport.ds_ReportDetails.Tables[2];
                        // ac_AccountingReport.dt_CompensationCostDetails = ac_AccountingReport.ds_ReportDetails.Tables[4];
                        ac_AccountingReport.dt_CommentsHistory = ac_AccountingReport.ds_ReportDetails.Tables[1];
                        if (ac_AccountingReport.ds_ReportDetails.Tables[0].Rows.Count > 0)
                        {
                            accountingReport.divARReportSection.Style.Add("display", "");
                            accountingReport.divAREmptyRow.Style.Add("display", "none");
                        }
                        else
                        {
                            accountingReport.divARReportSection.Style.Add("display", "none");
                            accountingReport.divAREmptyRow.Style.Add("display", "");
                        }
                        PopulateControlsToEdit(accountingReport, ac_AccountingReport.ds_ReportDetails.Tables[2], s_GroupID);
                        accountingReport.gvARMainReport.DataSource = ac_AccountingReport.dt_MainReport;
                        accountingReport.gvARMainReport.DataBind();
                        accountingReport.gvARCommentsHistory.DataSource = ac_AccountingReport.dt_CommentsHistory;
                        accountingReport.gvARCommentsHistory.DataBind();
                        //accountingReport.gvARSummaryReport.DataSource = ac_AccountingReport.dt_SummaryReport;
                        //accountingReport.gvARSummaryReport.DataBind();
                        if (s_ControlID.Equals("btnARReviewerApproval"))
                        {
                            ac_AccountingReport.s_GroupID = s_GroupID;
                            ac_AccountingReport.s_FileNameToDownload = accountingReport.hdnARSelectedTemplteNme.Value;
                            accountingReport.hdnARAccordionIndex.Value = "2";
                            accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "");
                        }
                        else if (s_ControlID.Equals("btnAREditAndView"))
                        {
                            ac_AccountingReport.s_GroupID = s_GroupID;
                            ac_AccountingReport.s_FileNameToDownload = accountingReport.hdnARSelectedTemplteNme.Value;
                            accountingReport.hdnARAccordionIndex.Value = "1";
                            accountingReport.h4ARAddEditPanel.Style.Add("display", "");
                        }
                        else
                        {
                            accountingReport.hdnARAccordionIndex.Value = "1";
                            accountingReport.h4ARAddEditPanel.Style.Add("display", "");
                        }
                        if (s_ControlID.Equals("btnARReviewerApproval") || s_ControlID.Equals("btnAREditAndView"))
                        {

                            if (ac_AccountingReport.n_VersionNo > 0)
                            {
                                accountingProperties = new AccountingProperties();
                                accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                                accountingProperties.PopulateControls = "GET_REPORT_BY_GROUP_ID";
                                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(ac_AccountingReport.s_GroupID);
                                using (System.Data.DataTable dt_Comments = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[3])
                                {
                                    if (dt_Comments.Rows.Count > 0)
                                    {
                                        accountingReport.gvARSelectTemplCommHistory.DataSource = dt_Comments;
                                        accountingReport.gvARSelectTemplCommHistory.DataBind();
                                        accountingReport.trARSelectTemplCommHistory.Style.Add("display", "");
                                        if (ac_AccountingReport.n_ReviewerApprovalStatus.Equals(3))
                                        {
                                            accountingReport.trARSelectTemplReportStatus.Style.Add("display", "");
                                            accountingReport.lblARSelectTemplRStatusText.Text = "Rejected by Reviewer";
                                        }
                                        else if (ac_AccountingReport.n_ClientApprovalStatus.Equals(3))
                                        {
                                            accountingReport.trARSelectTemplReportStatus.Style.Add("display", "");
                                            accountingReport.lblARSelectTemplRStatusText.Text = "Rejected by Client";
                                        }
                                    }
                                    else accountingReport.txtARTemplateComment.Text = string.Empty;
                                }
                            }
                        }
                        AccReportingCommonModel.EncryptData_Edit(accountingReport, ac_AccountingReport.ds_ReportDetails.Tables[2]);
                        ac_AccountingReport.s_Selected_Opt_GrantIDs = Convert.ToString(ac_AccountingReport.ds_ReportDetails.Tables[3].Rows[0]["OPT_GRANT_IDs"]);
                        accountingReport.divARReportSection.Style.Add("display", "");
                        accountingReport.divAREmptyRow.Style.Add("display", "none");
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Create report button click event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        public void btnARCreateAccReport_Click(AccountingReport accountingReport)
        {
            try
            {
                ClearControls(accountingReport, "1", Convert.ToDateTime(DateTime.Now).ToString("dd/MMM/yyyy"), string.Empty);
            }
            catch
            {
                throw;
            }
        }

        /* commenting it for now as it's not required 
        /// <summary>
        /// Reset button click event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        public void btnARReset_Click(AccountingReport accountingReport)
        {
            try
            {
                ClearControls(accountingReport, "1", Convert.ToDateTime(DateTime.Now).ToString("dd/MMM/yyyy"), "Reset");
            }
            catch
            {
                throw;
            }
        } */

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="e">e</param>
        /// <param name="n_MG_Index">n_MG_Index</param>
        /// <param name="ht_MainGrid">ht_MainGrid</param>
        internal void gvARDetails_RowDataBound(GridViewRowEventArgs e, ref int n_MG_Index, ref Hashtable ht_MainGrid)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ACC_RPT_GROUP_ID":
                                    ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"] = n_MG_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACCOUNTING REPORT DATE":
                                    ht_MainGrid["n_MG_AccountingReportDate"] = n_MG_Index;
                                    break;

                                case "SELECTED TEMPLATE":
                                    ht_MainGrid["n_MG_SelectedTemplate"] = n_MG_Index;
                                    break;

                                case "DOWNLOAD AND SEND FOR REVIEW":
                                    ht_MainGrid["n_MG_DownloadAndSendForReview"] = n_MG_Index;
                                    break;

                                case "VERSION_NUMBER":
                                    ht_MainGrid["n_MG_VersionNumber"] = n_MG_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IS_SENT_FOR_REVIEW":
                                    ht_MainGrid["n_MG_IS_SENT_FOR_REVIEW"] = n_MG_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "REVIEWER FEEDBACK":
                                    ht_MainGrid["n_MG_ReviewersFeedback"] = n_MG_Index;
                                    perColumn.Text = "Reviewer's Feedback";
                                    break;

                                case "CLIENT FEEDBACK":
                                    ht_MainGrid["n_MG_ClientsFeedback"] = n_MG_Index;
                                    perColumn.Text = "Client's Feedback";
                                    break;

                                case "IS_LOCKED":
                                    ht_MainGrid["n_MG_IS_LOCKED"] = n_MG_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTIONS":
                                    ht_MainGrid["n_MG_Actions"] = n_MG_Index;
                                    break;

                                case "GRANTS":
                                    ht_MainGrid["n_MG_GRANTS"] = n_MG_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "INVOICE_NUMBER":
                                    ht_MainGrid["n_MG_INVOICE_NUMBER"] = n_MG_Index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_MG_Index++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Visible = e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_SENT_FOR_REVIEW"]))].Visible =
                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Visible = e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Visible =
                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_GRANTS"]))].Visible = e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_INVOICE_NUMBER"]))].Visible = false;

                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_AccountingReportDate"]))].HorizontalAlign = e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_Actions"]))].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_AccountingReportDate"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_AccountingReportDate"]))].Text.Equals("&nbsp;"))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_AccountingReportDate"]))].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_AccountingReportDate"]))].Text).ToString("dd/MMM/yyyy");
                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_Actions"]))].Controls.Add(AddLinkButton("View Versions", "Click here to view versions", "lbtnARViewVersions", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, string.Empty, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, string.Empty, string.Empty));

                        if (e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ClientsFeedback"]))].Text.Trim().ToUpper().Equals("APPROVED"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_Actions"]))].Controls.Add(AddLinkButton("Invoice", "Invoice", "lbtnARInvoice", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, string.Empty, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, string.Empty, string.Empty));
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_Actions"]))].Controls.Add(AddLinkButton("Uploads", "Click here to view/upload documents", "lbtnARUploads", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, string.Empty, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, string.Empty, string.Empty));
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_Actions"]))].Controls.Add(AddLinkButton(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text.Equals("1") ? "Locked" : "Lock", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text.Equals("1") ? "Click here to unlock the report" : "Click here to lock the report", "lbtnARLocks", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, string.Empty, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, Convert.ToString(CommonModel.CheckPendingAccParmsAccountingReport(e.Row.Cells[Convert.ToInt32(ht_MainGrid["n_MG_AccountingReportDate"].ToString())].Text, userSessionInfo)), e.Row.Cells[Convert.ToInt32(ht_MainGrid["n_MG_AccountingReportDate"].ToString())].Text));
                        }
                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_Actions"]))].Controls.Add(AddLinkButton("Delete", "Click here to delete", "lbtnARDelete", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, string.Empty, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, string.Empty, string.Empty));

                        if (e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_SENT_FOR_REVIEW"]))].Text.Trim().Equals("FALSE"))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_DownloadAndSendForReview"]))].Controls.Add(AddLinkButton("Pending", "Click here to Edit", "lbtnARReviewerApproval", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, string.Empty, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, string.Empty, string.Empty));
                        else
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_DownloadAndSendForReview"]))].Controls.Add(AddLinkButton(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_DownloadAndSendForReview"]))].Text, "Click here to download report", "lbtnARDownloadReport", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_DownloadAndSendForReview"]))].Text, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, string.Empty, string.Empty));

                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_AccountingReportDate"]))].Controls.Add(AddLinkButton(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_AccountingReportDate"]))].Text, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_GRANTS"]))].Text, "lbtnAREditAndView", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_DownloadAndSendForReview"]))].Text, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, string.Empty, string.Empty));
                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_SelectedTemplate"]))].Controls.Add(AddLinkButton(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_SelectedTemplate"]))].Text, "Click here to download template", "lbtnARDownloadTemplate", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, string.Empty, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, string.Empty, string.Empty));

                        if (e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ReviewersFeedback"]))].Text.Trim().ToUpper().Equals("PENDING") && userSessionInfo.ACC_UerTypeID.Equals(5))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ReviewersFeedback"]))].Controls.Add(AddLinkButton(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ReviewersFeedback"]))].Text, "Click here to approve", "lbtnARApproveByReviewer", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_DownloadAndSendForReview"]))].Text, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, string.Empty, string.Empty));
                        if (e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ClientsFeedback"]))].Text.Trim().ToUpper().Equals("PENDING"))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ClientsFeedback"]))].Controls.Add(AddLinkButton(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ClientsFeedback"]))].Text, "Click here to approve", "lbtnARApproveByClient", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_ACC_RPT_GROUP_ID"]))].Text, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_DownloadAndSendForReview"]))].Text, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_VersionNumber"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_MainGrid["n_MG_IS_LOCKED"]))].Text, string.Empty, string.Empty));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="e">e</param>
        internal void gvARDetails_PageIndexChanging(AccountingReport accountingReport, GridViewPageEventArgs e)
        {
            try
            {
                accountingReport.gvARDetails.PageIndex = e.NewPageIndex;
                accountingReport.gvARDetails.DataSource = ac_AccountingReport.dt_MainReportDetails;
                accountingReport.gvARDetails.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="accountingReport">accountingReport class object</param>
        /// <param name="e">e</param>
        internal void gvARMainReport_PageIndexChanging(AccountingReport accountingReport, GridViewPageEventArgs e)
        {
            try
            {

                accountingReport.gvARMainReport.PageIndex = e.NewPageIndex;
                accountingReport.gvARMainReport.DataSource = ac_AccountingReport.dt_MainReport;
                accountingReport.gvARMainReport.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="e">e</param>
        internal void gvARSummaryReport_PageIndexChanging(AccountingReport accountingReport, GridViewPageEventArgs e)
        {
            try
            {
                accountingReport.gvARSummaryReport.PageIndex = e.NewPageIndex;
                accountingReport.gvARSummaryReport.DataSource = ac_AccountingReport.dt_SummaryReport;
                accountingReport.gvARSummaryReport.DataBind();

                accountingReport.gvARMainReport.DataSource = ac_AccountingReport.dt_MainReport;
                accountingReport.gvARMainReport.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="e">e</param>
        internal void gvARCommentsHistory_PageIndexChanging(AccountingReport accountingReport, GridViewPageEventArgs e)
        {
            try
            {
                accountingReport.gvARCommentsHistory.PageIndex = e.NewPageIndex;
                accountingReport.gvARCommentsHistory.DataSource = ac_AccountingReport.dt_CommentsHistory;
                accountingReport.gvARCommentsHistory.DataBind();

                accountingReport.gvARMainReport.DataSource = ac_AccountingReport.dt_MainReport;
                accountingReport.gvARMainReport.DataBind();

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view data bound event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        public void gv2_DataBound(AccountingReport accountingReport)
        {
            using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
            {
                TableCell cell = new TableCell();
                cell.Text = ac_AccountingReport.s_FinalValue;
                cell.ColumnSpan = 1;
                cell.Font.Bold = true;
                cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                cell.HorizontalAlign = HorizontalAlign.Left;
                row.Controls.Add(cell);
                cell = new TableCell();

                cell.ColumnSpan = ac_AccountingReport.n_VestCount - 1;
                cell.Font.Bold = true;
                cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                cell.HorizontalAlign = HorizontalAlign.Right;
                cell.Text = ac_AccountingReport.s_FairValue;
                row.Controls.Add(cell);

                accountingReport.gv2.HeaderRow.Parent.Controls.AddAt(ac_AccountingReport.n_RowCount + 3, row);
                cell.Dispose();
            }
        }

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="e">event args</param>
        /// <param name="n_SR_Index">row index</param>
        /// <param name="ht_SchemeWIse">hashTable key values</param>
        public void gvARSummaryReport_RowDataBound(object sender, AccountingReport accountingReport, GridViewRowEventArgs e, ref int n_SR_Index, ref Hashtable ht_SchemeWIse)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SCHEME NAME":
                                    ht_SchemeWIse["n_SR_Scheme_Name"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "AGRMID":
                                    ht_SchemeWIse["n_SR_AGRMID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPT_VEST_ID":
                                    ht_SchemeWIse["n_SR_OPT_VEST_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPT_GRANTED_ID":
                                    ht_SchemeWIse["n_SR_OPT_GRANTED_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPTION_ID":
                                    ht_SchemeWIse["n_SR_OPTION_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OP_OPTION_ID":
                                    ht_SchemeWIse["n_SR_OP_OPTION_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "EMPLOYEE ID":
                                    ht_SchemeWIse["n_SR_Employee_ID"] = n_SR_Index;
                                    break;

                                case "EMPLOYEE NAME":
                                    ht_SchemeWIse["n_SR_Employee_Name"] = n_SR_Index;
                                    break;

                                case "CURRENCY":
                                    ht_SchemeWIse["n_SR_Currency"] = n_SR_Index;
                                    break;

                                case "RATE APPLIED":
                                    ht_SchemeWIse["n_SR_RATE_APPLIED"] = n_SR_Index;
                                    break;

                                case "FORFEITURE GROUP":
                                    ht_SchemeWIse["n_SR_FORFEITURE_GROUP"] = n_SR_Index;
                                    break;

                                case "GRANT REGISTRATION ID":
                                    ht_SchemeWIse["n_SR_Grant_Reg_ID"] = n_SR_Index;
                                    break;

                                case "GRANT OPTION ID":
                                    ht_SchemeWIse["n_SR_GrantOptionID"] = n_SR_Index;
                                    break;

                                case "GRANT DATE":
                                    ht_SchemeWIse["n_SR_Grant_Date"] = n_SR_Index;
                                    break;

                                case "GRADE":
                                    ht_SchemeWIse["n_SR_Grade"] = n_SR_Index;
                                    break;

                                case "DESIGNATION":
                                    ht_SchemeWIse["n_SR_Designation"] = n_SR_Index;
                                    break;

                                case "SENIOR MANAGEMENT":
                                    ht_SchemeWIse["n_SR_Senior_Management"] = n_SR_Index;
                                    break;

                                case "IV_FV":
                                    ht_SchemeWIse["n_SR_IV_FV"] = n_SR_Index;
                                    break;

                                case "IV_FV POST CORPORATE ACTION / MODIFICATION / CHANGE IN ESTIMATED DATE OF LISTING":
                                    ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS SPLIT |MARKET PRICE":
                                    ht_SchemeWIse["n_SR_IVP_MP"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS SPLIT |EXPECTED LIFE":
                                    ht_SchemeWIse["n_SR_IVP_EL"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS SPLIT |VOLATILITY":
                                    ht_SchemeWIse["n_SR_IVP_VOL"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS SPLIT |DIVIDEND":
                                    ht_SchemeWIse["n_SR_IVP_DIV"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS SPLIT |RFIR":
                                    ht_SchemeWIse["n_SR_IVP_RFIR"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS VALUES SPLIT |MARKET PRICE":
                                    ht_SchemeWIse["n_SR_IVPV_MP"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS VALUES SPLIT |EXPECTED LIFE":
                                    ht_SchemeWIse["n_SR_IVPV_EL"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS VALUES SPLIT |VOLATILITY (%)":
                                    ht_SchemeWIse["n_SR_IVPV_VOL"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS VALUES SPLIT |DIVIDEND (%)":
                                    ht_SchemeWIse["n_SR_IVPV_DIV"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS VALUES SPLIT |RFIR (%)":
                                    ht_SchemeWIse["n_SR_IVPV_RFIR"] = n_SR_Index;
                                    break;

                                case "DATE OF JOINING":
                                    ht_SchemeWIse["n_SR_DATE_OF_JOINING"] = n_SR_Index;
                                    break;

                                case "VEST ID":
                                    ht_SchemeWIse["n_SR_VestID"] = n_SR_Index;
                                    break;

                                case "VEST DATE":
                                    ht_SchemeWIse["n_SR_VEST_DATE"] = n_SR_Index;
                                    break;

                                case "EXPIRY DATE":
                                    ht_SchemeWIse["n_SR_EXP_DATE"] = n_SR_Index;
                                    break;

                                case "VEST %":
                                    ht_SchemeWIse["n_SR_VEST_PERC"] = n_SR_Index;
                                    break;

                                case "OPTIONS GRANTED":
                                    ht_SchemeWIse["n_SR_OPTIONS_GRANTED"] = n_SR_Index;
                                    break;

                                case "OPTIONS VESTED CANCELLED":
                                    ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"] = n_SR_Index;
                                    break;

                                case "OPTIONS UNVESTED CANCELLED":
                                    ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"] = n_SR_Index;
                                    break;

                                case "OPTIONS LAPSED":
                                    ht_SchemeWIse["n_SR_OPTIONS_LAPSED"] = n_SR_Index;
                                    break;

                                case "VESTED AND EXERCISABLE OPTIONS":
                                    ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"] = n_SR_Index;
                                    break;

                                case "UNVESTED OPTIONS":
                                    ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"] = n_SR_Index;
                                    break;

                                case "OUTSTANDING OPTIONS":
                                    ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"] = n_SR_Index;
                                    break;

                                case "EXERCISED OPTIONS":
                                    ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"] = n_SR_Index;
                                    break;

                                case "LIVE OPTIONS FOR COMPENSATION COST":
                                    ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"] = n_SR_Index;
                                    break;

                                case "ACCLELARATED OPTIONS":
                                    ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"] = n_SR_Index;
                                    break;

                                case "ACCELERATED VESTING DATE":
                                    ht_SchemeWIse["n_SR_ACCELERATED_VESTING_DATE"] = n_SR_Index;
                                    break;

                                case "FORFEITURE RATE":
                                    ht_SchemeWIse["n_SR_FORFEITURE_RATE"] = n_SR_Index;
                                    break;

                                case "OPTIONS LIKELY TO BE FORFEITED":
                                    ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"] = n_SR_Index;
                                    break;

                                case "NET OPTIONS FOR COMPENSATION COST":
                                    ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"] = n_SR_Index;
                                    break;

                                case "EXERCISE PRICE":
                                    ht_SchemeWIse["n_SR_EXERCISE_PRICE"] = n_SR_Index;
                                    break;

                                case "EXERCISE PRICE POST CORPORATE ACTION / MODIFICATION":
                                    ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"] = n_SR_Index;
                                    break;

                                case "TOTAL COMPENSATION COST":
                                    ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"] = n_SR_Index;
                                    break;

                                case "COST_SUM":
                                    ht_SchemeWIse["n_SR_COST_SUM"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "TOTAL_COST":
                                    ht_SchemeWIse["n_SR_TOTAL_COST"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "GRANT_OPTION_ID":
                                    ht_SchemeWIse["n_SR_GRANT_OPTION_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "SCH_SCHEME_TITLE1":
                                    ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE1"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "SCH_SCHEME_TITLE":
                                    ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "VPD_VESTING_PERIOD_ID":
                                    ht_SchemeWIse["n_SR_VPD_VESTING_PERIOD_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OP_VESTING_PERIOD_ID":
                                    ht_SchemeWIse["n_SR_OP_VESTING_PERIOD_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OP_VAL_METHOD":
                                    ht_SchemeWIse["n_SR_OP_VAL_METHOD"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "VAL_METHOD":
                                    ht_SchemeWIse["n_SR_VAL_METHOD"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "VESTING_PERIOD_ID":
                                    ht_SchemeWIse["n_SR_VESTING_PERIOD_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    ht_SchemeWIse["n_SR_ViewWorkings"] = n_SR_Index;
                                    break;

                                case "OP_GRANT_OPTION_ID":
                                    ht_SchemeWIse["n_SR_OP_GRANT_OPTION_ID"] = n_SR_Index;
                                    break;

                                case "HCOST":
                                    ht_SchemeWIse["n_HCOST"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "VALUATION_METHOD":
                                    ht_SchemeWIse["n_VALUATION_METHOD"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPID":
                                    ht_SchemeWIse["n_OPID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_SR_Index = n_SR_Index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPT_VEST_ID"])))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPT_VEST_ID"]))].Visible = false;

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_VAL_METHOD"])))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VAL_METHOD"]))].Visible = false;

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_VALUATION_METHOD"])))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_VALUATION_METHOD"]))].Visible = false;

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OP_VAL_METHOD"])))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OP_VAL_METHOD"]))].Visible = false;

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_VAL_METHOD"])))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VAL_METHOD"]))].Visible = false;

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OP_VAL_METHOD"])))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OP_VAL_METHOD"]))].Visible = false;

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_VALUATION_METHOD"])))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_VALUATION_METHOD"]))].Visible = false;

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_HCOST"])))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_HCOST"]))].Visible = false;

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_OPID"])))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_OPID"]))].Visible = false;

                        if (e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme_Name"]))].Text.Trim().ToUpper().Equals("TOTAL COST")
                            || e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme_Name"]))].Text.Trim().ToUpper().Equals("HISTORICAL COST")
                            || e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme_Name"]))].Text.Trim().ToUpper().Equals("ADJUSTMENT ENTRY")
                            || e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme_Name"]))].Text.Trim().ToUpper().Equals("REVERSAL COST"))
                        {
                            HideColumns(e, ht_SchemeWIse, accountingReport);
                        }
                        else
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_AGRMID"]))].Visible = e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OP_OPTION_ID"]))].Visible = e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTION_ID"]))].Visible = e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPT_GRANTED_ID"]))].Visible = false;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_COST_SUM"]))].Visible =
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COST"]))].Visible =
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_GRANT_OPTION_ID"]))].Visible =
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE"]))].Visible =
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE1"]))].Visible =
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OP_GRANT_OPTION_ID"]))].Visible =
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OP_VESTING_PERIOD_ID"]))].Visible =
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VPD_VESTING_PERIOD_ID"]))].Visible = false;

                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme_Name"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SCHEME_NAME'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_DATE'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Reg_ID"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Employee_ID"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Employee_Name"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grade"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRADE'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Designation"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DESIGNATION'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_DATE_OF_JOINING"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DATE_OF_JOINING'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Senior_Management"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SENIOR_MANAGEMENT'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_GrantOptionID"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANT_OPTION_ID'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV_POST_CORP_ACT_MODF_EDL'").Count() > 0;

                            if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VestID"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_PERIOD_NO'").Count() > 0;
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VEST_DATE"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_DATE'").Count() > 0;
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VEST_PERC"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VEST_PERCENT'").Count() > 0;
                            }

                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANTED_OPTIONS'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LAPSED_OPTIONS'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_AND_EXERCISABLE'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_OPTIONS'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXP_DATE"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'Expiry Date'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"]))].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : accountingReport.rdoARMarketPriceType.SelectedItem.Value.Equals("IV") ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'Intrinsic Value'").Count() > 0 : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'Fair Value'").Count() > 0;

                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LIVE_OPTIONS_FOR_COMPENSATION_COST'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_QUANTITY'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCELERATED_VESTING_DATE"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_DATE'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_FORFEITURE_GROUP"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_RATE_APPLIED"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'RATE_APPLIED'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_FORFEITURE_RATE"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_RATE'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OPTIONS_LIKELY_TO_BE_FORFEITED'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'NET_OPTIONS_FOR_COMPENSATION_COST'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_Currency"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'CURRENCY_NAME'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISE_PRICE"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_EXERCISE_PRICE'").Count() > 0;
                            e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"].ToString())].Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISE_PRICE_POST_CORPORATE_ACTION_MODIFICATION'").Count() > 0;

                            using (System.Data.DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                            {
                                if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text.Equals("&nbsp;"))
                                {
                                    e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text = accountingReport.rdoARMarketPriceType.SelectedItem.Value.Equals("IV") ? Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString())
                                                                                                       : Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                }

                                if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"])].Text.Equals("&nbsp;"))
                                {
                                    e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"])].Text = accountingReport.rdoARMarketPriceType.SelectedItem.Value.Equals("IV") ? Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"])].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"])].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString())
                                                                                                       : Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"])].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"])].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                }
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].Text.Trim()) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].Text.Trim().Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Reg_ID"]))].Controls.Add(AddControl("LinkButton", "lbtnGrantRegID", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Reg_ID"]))].Text, "Click here to view valuation parameters", "ViewValuationParas", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Reg_ID"]))].Text.Trim(), "", "", accountingReport.txtARDate.Text, "", "", "", ""));
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ViewWorkings"]))].Controls.Add(AddControl("LinkButton", "lbtnARViewWorkings", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Reg_ID"]))].Text, "Click here to view workings", "ViewWorkings", "View Workings", accountingReport.rdoARMarketPriceType.SelectedItem.Value, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPT_GRANTED_ID"]))].Text.Trim(), accountingReport.txtARDate.Text, e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Employee_ID"]))].Text.Trim(), e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Employee_Name"]))].Text.Trim(), Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].Text.Trim()).ToString("dd/MMM/yyyy"), ""));
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].Controls.Add(AddControl("LinkButton", "lbtnARViewGrantDetails", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_AGRMID"]))].Text, "Click here to view grant details", "ViewGrantDetails", Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].Text.Trim()).ToString("dd/MMM/yyyy"), "", "", accountingReport.txtARDate.Text, "", "", "", ""));
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"]))].Controls.Add(AddControl("LinkButton", "lbtnARIVFVCalculations", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Reg_ID"]))].Text, "Click here to view details", "ViewIVFVCalculations", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"]))].Text, "", "", "", "", "", "", accountingReport.rdoARMarketPriceType.SelectedItem.Value));
                            }
                            if (!e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_MP"]))].Text.Equals("&nbsp;") && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_MP"]))].Text))
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_MP"]))].Controls.Add(AddBulletedList(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_MP"]))].Text));
                            if (!e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_EL"]))].Text.Equals("&nbsp;") && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_EL"]))].Text))
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_EL"]))].Controls.Add(AddBulletedList(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_EL"]))].Text));
                            if (!e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_VOL"]))].Text.Equals("&nbsp;") && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_VOL"]))].Text))
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_VOL"]))].Controls.Add(AddBulletedList(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_VOL"]))].Text));
                            if (!e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_DIV"]))].Text.Equals("&nbsp;") && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_DIV"]))].Text))
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_DIV"]))].Controls.Add(AddBulletedList(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_DIV"]))].Text));
                            if (!e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_RFIR"]))].Text.Equals("&nbsp;") && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_RFIR"]))].Text))
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_RFIR"]))].Controls.Add(AddBulletedList(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_RFIR"]))].Text));

                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_MP"]))].Width = 210;
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ViewWorkings"]))].Width = 80;

                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].HorizontalAlign =
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ViewWorkings"]))].HorizontalAlign = HorizontalAlign.Center;

                            if ((!userSessionInfo.ACC_IsEmpAccess))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Employee_ID"]))].Text = "";
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Employee_Name"]))].Text = "";
                            }

                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_DATE_OF_JOINING"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_DATE_OF_JOINING"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_DATE_OF_JOINING"]))].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_DATE_OF_JOINING"]))].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_DATE_OF_JOINING"]))].HorizontalAlign = HorizontalAlign.Center;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].HorizontalAlign = HorizontalAlign.Center;
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_EXP_DATE"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXP_DATE"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXP_DATE"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXP_DATE"]))].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXP_DATE"]))].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXP_DATE"]))].HorizontalAlign = HorizontalAlign.Center;
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_VEST_PERC"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_PERC"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_PERC"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_PERC"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"]))].HorizontalAlign = HorizontalAlign.Right;
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"]))].HorizontalAlign = HorizontalAlign.Center;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_ACCELERATED_VESTING_DATE"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ACCELERATED_VESTING_DATE"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ACCELERATED_VESTING_DATE"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCELERATED_VESTING_DATE"])].Controls.Add(AddControl("LinkButton", "lbtn", string.Empty, "Click here to view Accelerated Vesting", "ViewAcceleratedVesting", "View", e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VPD_VESTING_PERIOD_ID"])].Text, string.Empty, Convert.ToString(accountingReport.txtARDate.Text), string.Empty, string.Empty, string.Empty, string.Empty));
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ACCELERATED_VESTING_DATE"]))].HorizontalAlign = HorizontalAlign.Center;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_FORFEITURE_RATE"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_FORFEITURE_RATE"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_FORFEITURE_RATE"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_FORFEITURE_RATE"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"]))].HorizontalAlign = HorizontalAlign.Right;
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISE_PRICE"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISE_PRICE"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISE_PRICE"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISE_PRICE"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"]))].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"]))].HorizontalAlign = HorizontalAlign.Right;
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"]))].Controls.Add(AddControl("LinkButton", "lbtnARIVFVCORPACT", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPT_VEST_ID"]))].Text, "Click here to view details", "ViewIVFVCOPRPACT", e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"]))].Text, "", "", "", "", "", "", accountingReport.rdoARMarketPriceType.SelectedItem.Value));
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"]))].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"]))].HorizontalAlign = HorizontalAlign.Right;
                            }

                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].Text.Trim()) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].Text.Trim().Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVPV_MP"]))].HorizontalAlign = HorizontalAlign.Right;
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVPV_EL"]))].HorizontalAlign = HorizontalAlign.Right;
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVPV_VOL"]))].HorizontalAlign = HorizontalAlign.Right;
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVPV_DIV"]))].HorizontalAlign = HorizontalAlign.Right;
                                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVPV_RFIR"]))].HorizontalAlign = HorizontalAlign.Right;

                                if (e.Row.RowIndex > 0)
                                {
                                    int RowIndex = 1, Count = 1, n_SR_ViewWorkings = Convert.ToInt32(ht_SchemeWIse["n_SR_ViewWorkings"]);
                                    MergeCells(accountingReport.gvARSummaryReport, e, Convert.ToInt32(ht_SchemeWIse["n_SR_GrantOptionID"]),
                                                Convert.ToInt32(ht_SchemeWIse["n_SR_IVP_MP"]), Convert.ToInt32(ht_SchemeWIse["n_SR_IVP_EL"]),
                                                Convert.ToInt32(ht_SchemeWIse["n_SR_IVP_VOL"]), Convert.ToInt32(ht_SchemeWIse["n_SR_IVP_DIV"]),
                                                Convert.ToInt32(ht_SchemeWIse["n_SR_IVP_RFIR"]), Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"]),
                                                Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"]), Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"]),
                                                Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"]), Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"]),
                                                ref RowIndex, ref Count, ref n_SR_ViewWorkings);
                                    ht_SchemeWIse["n_SR_ViewWorkings"] = n_SR_ViewWorkings;
                                }
                            }
                        }
                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (System.Data.DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"])].Controls.Add(AddControl("LinkButton", "lbtn", string.Empty, "Click here to view Accelerated Vesting", "ViewAcceleratedVesting", "View", e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VPD_VESTING_PERIOD_ID"])].Text, string.Empty, Convert.ToString(accountingReport.txtARDate.Text), string.Empty, string.Empty, string.Empty, string.Empty));
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text, "0");
                            }
                            for (int n_Index = Convert.ToInt32(ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE1"]) + 1; n_Index < Convert.ToInt32(ht_SchemeWIse["n_SR_ViewWorkings"]); n_Index++)
                            {
                                if (!string.IsNullOrEmpty(e.Row.Cells[n_Index].Text) && !e.Row.Cells[n_Index].Text.Equals("&nbsp;") && !e.Row.Cells[n_Index].Text.Equals("rdbVMCC01") && !e.Row.Cells[n_Index].Text.Equals("rdbVMCC02"))
                                {
                                    e.Row.Cells[n_Index].Text = Convert.ToDouble(e.Row.Cells[n_Index].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Index].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[n_Index].Text, "0");
                                }
                            }

                            /* FV, IV, Exercise Price decimal rounding , Thousand separating */
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISE_PRICE"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISE_PRICE"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISE_PRICE"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISE_PRICE"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISE_PRICE"])].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISE_PRICE"])].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"])].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"])].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            /* Forfeiture Rate decimal rounding , Thousand separating */
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_FORFEITURE_RATE"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_FORFEITURE_RATE"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_FORFEITURE_RATE"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_FORFEITURE_RATE"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_FORFEITURE_RATE"])].Text, DecimalLimitTable.Select("ADVSID = 13")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 13")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_FORFEITURE_RATE"])].Text, DecimalLimitTable.Select("ADVSID = 13")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            /* Market Price, Expected Life, Volatility, Dividend, RFIR decimal rounding , Thousand separating */
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text, DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text, DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text, DecimalLimitTable.Select("ADVSID = 5")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 5")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text, DecimalLimitTable.Select("ADVSID = 5")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text, DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text, DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text, DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text, DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text, DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text, DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            /* Compensation Cost decimal rounding , Thousand separating */
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            for (int n_Index = Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COST"]) + 1; n_Index < Convert.ToInt32(ht_SchemeWIse["n_SR_OP_OPTION_ID"]); n_Index++)
                            {
                                if (!string.IsNullOrEmpty(e.Row.Cells[n_Index].Text) && !e.Row.Cells[n_Index].Text.Equals("&nbsp;"))
                                {
                                    if (e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_HCOST"])].Text.Equals(e.Row.Cells[n_Index].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_HCOST"])].Text.Equals("0.000000"))
                                    {
                                        e.Row.Cells[n_Index].ForeColor = System.Drawing.Color.Green;
                                    }
                                    e.Row.Cells[n_Index].Text = Convert.ToDouble(e.Row.Cells[n_Index].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Index].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Index].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                }
                            }
                        }
                        #endregion
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to hide columns
        /// </summary>
        /// <param name="e">event args</param>
        /// <param name="ht_SchemeWIse">ht_SchemeWIse hashtable</param>
        /// <param name="accountingReport">accountingReport Page Object</param>
        private void HideColumns(GridViewRowEventArgs e, Hashtable ht_SchemeWIse, AccountingReport accountingReport)
        {
            int n_ColumSpan = 0;

            n_ColumSpan = n_ColumSpan + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DATE_OF_JOINING'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DESIGNATION'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRADE'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SENIOR_MANAGEMENT'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_DATE'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANT_OPTION_ID'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_PERIOD_NO'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_DATE'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VEST_PERCENT'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANTED_OPTIONS'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LAPSED_OPTIONS'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_AND_EXERCISABLE'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_OPTIONS'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LIVE_OPTIONS_FOR_COMPENSATION_COST'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_QUANTITY'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_DATE'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'RATE_APPLIED'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_RATE'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OPTIONS_LIKELY_TO_BE_FORFEITED'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'NET_OPTIONS_FOR_COMPENSATION_COST'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'CURRENCY_NAME'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_EXERCISE_PRICE'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISE_PRICE_POST_CORPORATE_ACTION_MODIFICATION'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SCHEME_NAME'").Count() > 0).Equals(false))
                + Convert.ToInt32((ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV_POST_CORP_ACT_MODF_EDL'").Count() > 0).Equals(false));

            n_ColumSpan = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count > 0 ? (n_ColumSpan + 2) : n_ColumSpan;

            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme_Name"]))].ColumnSpan = ac_AccountingReport.dt_CustmizedViewAccounting != null && ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count > 0 && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SCHEME_NAME'").Count().Equals(0)
                ? (accountingReport.rdoARMarketPriceType.SelectedItem.Text.Equals("IV") ? 36 : 44) - n_ColumSpan
                : (accountingReport.rdoARMarketPriceType.SelectedItem.Text.Equals("IV") ? 37 : 45) - n_ColumSpan;
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme_Name"]))].BackColor = Color.LightGray;

            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Reg_ID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPT_VEST_ID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VAL_METHOD"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OP_GRANT_OPTION_ID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OP_VAL_METHOD"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_VALUATION_METHOD"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ViewWorkings"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_MP"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_EL"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_VOL"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_DIV"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVP_RFIR"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_DATE_OF_JOINING"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_ACCELERATED_VESTING_DATE"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_FORFEITURE_RATE"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISE_PRICE"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION_MODF"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grade"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Designation"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Senior_Management"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVPV_MP"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVPV_EL"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVPV_VOL"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVPV_DIV"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IVPV_RFIR"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_COST_SUM"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COST"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_GRANT_OPTION_ID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE1"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VPD_VESTING_PERIOD_ID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OP_VESTING_PERIOD_ID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_AGRMID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OP_OPTION_ID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTION_ID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPT_GRANTED_ID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Grant_Date"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_GrantOptionID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Employee_ID"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Employee_Name"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_RATE_APPLIED"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_FORFEITURE_GROUP"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Currency"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV_POST_CORP_ACT_MODF_EDL"]))].Visible =
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_HCOST"]))].Visible = false;
            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_OPID"]))].Visible = false;

            if (userSessionInfo.ACC_CalculationMethod.Equals(2))
            {
                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VestID"]))].Visible = false;
                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].Visible = false;
                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_PERC"]))].Visible = false;
                e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXP_DATE"]))].Visible = false;
            }
        }

        /// <summary>
        /// This method is used to merge cells
        /// </summary>
        /// <param name="gridView">gridView</param>
        /// <param name="e">e</param>
        /// <param name="n_SR_GrantOptionID">n_SR_GrantOptionID</param>
        /// <param name="n_SR_IVP_MP">n_SR_IVP_MP</param>
        /// <param name="n_SR_IVP_EL">n_SR_IVP_EL</param>
        /// <param name="n_SR_IVP_VOL">n_SR_IVP_VOL</param>
        /// <param name="n_SR_IVP_DIV">n_SR_IVP_DIV</param>
        /// <param name="n_SR_IVP_RFIR">n_SR_IVP_RFIR</param>
        /// <param name="n_SR_IVPV_MP">n_SR_IVPV_MP</param>
        /// <param name="n_SR_IVPV_EL">n_SR_IVPV_EL</param>
        /// <param name="n_SR_IVPV_VOL">n_SR_IVPV_VOL</param>
        /// <param name="n_SR_IVPV_DIV">n_SR_IVPV_DIV</param>
        /// <param name="n_SR_IVPV_RFIR">n_SR_IVPV_RFIR</param>
        /// <param name="RowIndex">RowIndex</param>
        /// <param name="Count">Count</param>
        /// <param name="n_Action">n_Action</param>
        private void MergeCells(GridView gridView, GridViewRowEventArgs e, int n_SR_GrantOptionID, int n_SR_IVP_MP, int n_SR_IVP_EL, int n_SR_IVP_VOL, int n_SR_IVP_DIV, int n_SR_IVP_RFIR,
            int n_SR_IVPV_MP, int n_SR_IVPV_EL, int n_SR_IVPV_VOL, int n_SR_IVPV_DIV, int n_SR_IVPV_RFIR, ref int RowIndex, ref int Count, ref int n_Action)
        {
            for (int intLoop = 1; intLoop <= e.Row.RowIndex; intLoop++)
            {
                Count++;
                if ((!gridView.Rows[e.Row.RowIndex - intLoop].Cells[n_SR_GrantOptionID].Text.Equals(string.Empty)) && (e.Row.Cells[n_SR_GrantOptionID].Text == gridView.Rows[e.Row.RowIndex - intLoop].Cells[n_SR_GrantOptionID].Text))
                {
                    RowIndex = intLoop;
                    break;
                }
            }

            if (e.Row.Cells[n_SR_GrantOptionID].Text == gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_GrantOptionID].Text)
            {
                e.Row.Cells[n_SR_GrantOptionID].Text = e.Row.Cells[n_Action].Text = "";
                e.Row.Cells[n_SR_IVP_MP].Text = e.Row.Cells[n_SR_IVP_EL].Text = e.Row.Cells[n_SR_IVP_VOL].Text = e.Row.Cells[n_SR_IVP_DIV].Text = e.Row.Cells[n_SR_IVP_RFIR].Text = "";
                e.Row.Cells[n_SR_IVPV_MP].Text = e.Row.Cells[n_SR_IVPV_EL].Text = e.Row.Cells[n_SR_IVPV_VOL].Text = e.Row.Cells[n_SR_IVPV_DIV].Text = e.Row.Cells[n_SR_IVPV_RFIR].Text = "";
                e.Row.Cells[n_SR_GrantOptionID].Visible = e.Row.Cells[n_Action].Visible = false;
                e.Row.Cells[n_SR_IVP_MP].Visible = false;
                e.Row.Cells[n_SR_IVP_EL].Visible = e.Row.Cells[n_SR_IVP_VOL].Visible = e.Row.Cells[n_SR_IVP_DIV].Visible = e.Row.Cells[n_SR_IVP_RFIR].Visible = false;
                e.Row.Cells[n_SR_IVPV_MP].Visible = false;
                e.Row.Cells[n_SR_IVPV_EL].Visible = e.Row.Cells[n_SR_IVPV_VOL].Visible = e.Row.Cells[n_SR_IVPV_DIV].Visible = e.Row.Cells[n_SR_IVPV_RFIR].Visible = false;
                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_GrantOptionID].RowSpan = gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_Action].RowSpan = Count;
                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_IVP_MP].RowSpan = gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_IVP_EL].RowSpan = Count;
                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_IVP_VOL].RowSpan = gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_IVP_DIV].RowSpan = Count;
                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_IVP_RFIR].RowSpan = Count;
                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_IVPV_MP].RowSpan = gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_IVPV_EL].RowSpan = Count;
                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_IVPV_VOL].RowSpan = gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_IVPV_DIV].RowSpan = Count;
                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_IVPV_RFIR].RowSpan = Count;
            }
        }

        #endregion

        #region Support Methods

        /// <summary>
        /// This method loads the initial settings and data required for the page.
        /// </summary>
        /// <param name="accountingReport">accountingReport Page Object</param>
        private void CheckEmployeeRolePriviledges(AccountingReport accountingReport)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuAccountingReport;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (System.Data.DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    break;

                                case "ADD":

                                    break;

                                case "EDIT":

                                    break;

                                case "DELETE":

                                    break;

                                case "APPROVE":

                                    break;

                                case "DISAPPROVE":

                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind UI from xml file
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        private void BindUI(AccountingReport accountingReport)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_AccountingReport.dt_AccountingReportUI == null || ac_AccountingReport.dt_AccountingReportUI.Rows.Count.Equals(0))
                    {
                        ac_AccountingReport.dt_AccountingReportUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10_UI);
                    }
                    if ((ac_AccountingReport.dt_AccountingReportUI != null) && (ac_AccountingReport.dt_AccountingReportUI.Rows.Count > 0))
                    {
                        foreach (Control control in accountingReport.divAccountingReport.Controls)
                        {
                            BindUISwitchCase(control);
                        }
                        foreach (Control ctr in accountingReport.divARHideShowAdvSearch.Controls)
                        {
                            BindUISwitchCase(ctr);
                        }
                        foreach (Control o_Control in accountingReport.divARReportSection.Controls)
                        {
                            BindUISwitchCase(o_Control);
                        }
                        foreach (Control o_Ctr in accountingReport.divARSelectTemplate.Controls)
                        {
                            BindUISwitchCase(o_Ctr);
                        }
                        foreach (Control o_Ctrr in accountingReport.divARReportStatusSection.Controls)
                        {
                            BindUISwitchCase(o_Ctrr);
                        }
                        foreach (Control o_Contrrols in accountingReport.divAREmptyRow.Controls)
                        {
                            BindUISwitchCase(o_Contrrols);
                        }
                        foreach (Control o_Contrrols in accountingReport.divARViewReconNote.Controls)
                        {
                            BindUISwitchCase(o_Contrrols);
                        }
                    }
                    accountingReport.lblARCreateReport.Text = Convert.ToString((ac_AccountingReport.dt_AccountingReportUI.Select("LabelID = 'lblARCreateReport'"))[0]["LabelName"]);
                    accountingReport.lblARCreateReport.ToolTip = Convert.ToString((ac_AccountingReport.dt_AccountingReportUI.Select("LabelID = 'lblARCreateReport'"))[0]["LabelToolTip"]);
                    accountingReport.lblARViewWorkings.Text = Convert.ToString((ac_AccountingReport.dt_AccountingReportUI.Select("LabelID = 'lblARViewWorkings'"))[0]["LabelName"]);
                    accountingReport.lblARViewWorkings.ToolTip = Convert.ToString((ac_AccountingReport.dt_AccountingReportUI.Select("LabelID = 'lblARViewWorkings'"))[0]["LabelToolTip"]);
                    accountingReport.hdnARCantCreateRptForSameDate.Value = accountingServiceClient.GetAccounting_L10N("lblARCantCreateRptForSameDate", CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10);
                    accountingReport.hdnARCantDelAsRptLocked.Value = accountingServiceClient.GetAccounting_L10N("lblARCantDelAsRptLocked", CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// this method is used  to bind control UI
        /// </summary>
        /// <param name="control">control</param>
        private void BindUISwitchCase(Control control)
        {
            switch (control.GetType().FullName.ToUpper())
            {
                case CommonConstantModel.s_wcLabel:
                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_AccountingReport.dt_AccountingReportUI, (Label)control, null, null, null, null, null, null, null, null, null);
                    break;

                case CommonConstantModel.s_wcButton:
                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_AccountingReport.dt_AccountingReportUI, null, null, (Button)control, null, null, null, null, null, null, null);
                    break;

                case CommonConstantModel.s_wcGridview:
                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_AccountingReport.dt_AccountingReportUI, null, null, null, null, null, null, null, null, (GridView)control, null);
                    break;

                case CommonConstantModel.s_wcRequiredFieldValidator:
                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, ac_AccountingReport.dt_AccountingReportUI, null, null, null, null, null, (BaseValidator)control, null, null, null, null);
                    break;

                case CommonConstantModel.s_wcRugularExpressionValidator:
                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, ac_AccountingReport.dt_AccountingReportUI, null, null, null, null, null, null, (BaseValidator)control, null, null, null);
                    break;

            }
        }

        /// <summary>
        /// This method is used to bind all the reports
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="s_EventName">s_EventName</param>
        public void BindAllReports(AccountingReport accountingReport, string s_EventName)
        {
            try
            {
                if (!s_EventName.Equals("LockAndDelete"))
                {
                    LoadDefault_ViewDropDowns(accountingReport);

                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        genericProperties.PageName = CommonConstantModel.s_MnuAccountingReport;
                        genericProperties.CustomizeView_ID = Convert.ToString(accountingReport.ddlDefaultView.SelectedValue);
                        ac_AccountingReport.dt_CustmizedViewAccounting = (System.Data.DataTable)genericServiceClient.GetCustomizedViewTable(genericProperties);
                    }
                }
                using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
                {
                    accReportingCommonModel.GetAllReportsData();
                }

                accountingReport.gvARDetails.DataSource = ac_AccountingReport.dt_MainReportDetails;
                accountingReport.gvARDetails.DataBind();

                if (s_EventName.Equals("Page_Load"))
                    BindTemplateDropdown(accountingReport);
                else
                {
                    accountingReport.hdnARAccordionIndex.Value = "0";
                    accountingReport.h4ARAddEditPanel.Style.Add("display", "none");
                    accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "none");
                }

                if (!s_EventName.Equals("LockAndDelete"))
                    accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                if ((!userSessionInfo.ACC_IsEmpAccess))
                {
                    accountingReport.mddlAREmployeeID.chkMultiselect.Enabled = false;
                    accountingReport.mddlAREmployeeID.txtMultiselect.Enabled = false;
                    accountingReport.mddlAREmployeeName.txtMultiselect.Enabled = false;
                    accountingReport.mddlAREmployeeName.chkMultiselect.Enabled = false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind template dropdown
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        public void BindTemplateDropdown(AccountingReport accountingReport)
        {
            try
            {
                using (DataSet ds_TemplateList = new DataSet())
                {
                    System.Data.DataTable dt_TemplateList = new System.Data.DataTable();
                    if (!System.IO.File.Exists(Convert.ToString(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"]) + userSessionInfo.ACC_CompanyName + @"\TemplateList.xml")))
                    {
                        using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                        {
                            accountingServiceClient.GetAccWordTemplateList(userSessionInfo.ACC_CompanyName);
                        }
                    }
                    ds_TemplateList.ReadXml(Convert.ToString(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"]) + userSessionInfo.ACC_CompanyName + @"\TemplateList.xml"));
                    dt_TemplateList = ds_TemplateList.Tables["Template"];

                    accountingReport.ddlARSelectTemplate.DataSource = dt_TemplateList;
                    accountingReport.ddlARSelectTemplate.DataTextField = "ID";
                    accountingReport.ddlARSelectTemplate.DataValueField = "Name";
                    accountingReport.ddlARSelectTemplate.DataBind();
                    dt_TemplateList.Dispose();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind status data
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="s_Grp_ID">s_Grp_ID</param>
        public void BindStatusData(AccountingReport accountingReport, string s_Grp_ID)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_MainReport;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(s_Grp_ID);
                    accountingProperties.CALCULATION_METHOD = userSessionInfo.ACC_CalculationMethod;
                    accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                    BindStatusSection(accountingReport, accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[5], string.Empty);
                    accountingReport.hdnARAccordionIndex.Value = "2";
                    accountingReport.h4ARAddEditPanel.Style.Add("display", "");
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// this method is used to bind controls in edit case
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="dt_Filters">dt_Filters</param>
        /// <param name="s_GroupID">Accounting Reprting Group Id</param>
        private void PopulateControlsToEdit(AccountingReport accountingReport, System.Data.DataTable dt_Filters, string s_GroupID)
        {
            using (AccReportingCommonModel AccReportingCommonModel = new AccReportingCommonModel())
            {
                ac_AccountingReport.s_Reporting_Date = Convert.ToDateTime(dt_Filters.Rows[0]["REPORTING_DATE"]).ToString("dd/MMM/yyyy");
                accountingReport.lblARReportAsOnDate.Text =  "Report as on Date - " + Convert.ToDateTime(dt_Filters.Rows[0]["REPORTING_DATE"]).ToString("dd/MMM/yyyy");
                accountingReport.txtARDate.Text = ac_AccountingReport.s_ReportDate = Convert.ToDateTime(dt_Filters.Rows[0]["REPORTING_DATE"]).ToString("dd/MMM/yyyy");
                accountingReport.rdoARDisplayCostFor.ClearSelection();
                accountingReport.rdoARDisplayCostFor.Items.FindByValue(Convert.ToString(dt_Filters.Rows[0]["DISPLAY_COST_FOR"])).Selected = true;
                accountingReport.txtARGrantFromDate.Text = !string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["GRANT_FROM_DATE"])) ? Convert.ToDateTime(dt_Filters.Rows[0]["GRANT_FROM_DATE"]).ToString("dd/MMM/yyyy") : string.Empty;
                accountingReport.txtARGrantToDate.Text = !string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["GRANT_TO_DATE"])) ? Convert.ToDateTime(dt_Filters.Rows[0]["GRANT_TO_DATE"]).ToString("dd/MMM/yyyy") : string.Empty;
                accountingReport.rdoARDisplayCostAfter.ClearSelection();
                accountingReport.rdoARDisplayCostAfter.Items.FindByValue(Convert.ToString(dt_Filters.Rows[0]["DISPLAY_COST_AFTER"])).Selected = true;
                accountingReport.rdoARDisplayCostBefore.ClearSelection();
                accountingReport.rdoARDisplayCostBefore.Items.FindByValue(Convert.ToString(dt_Filters.Rows[0]["DISPLAY_COST_BEFORE"])).Selected = true;
                accountingReport.chkARSeniorManagement.Checked = Convert.ToString(dt_Filters.Rows[0]["IS_SENIOR_MANAGEMENT"]).Equals("1") ? true : false;
                accountingReport.rdoARMarketPriceType.ClearSelection();
                accountingReport.rdoARMarketPriceType.Items.FindByValue(Convert.ToString(dt_Filters.Rows[0]["MARKET_PRICE_TYPE"])).Selected = true;
                txtARDate_TextChanged(accountingReport, Convert.ToDateTime(dt_Filters.Rows[0]["REPORTING_DATE"]).ToString("dd/MMM/yyyy"), s_GroupID);
                switch (accountingReport.rdoARDisplayCostFor.SelectedItem.Value.Trim())
                {
                    case "Y":
                        if (!string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_FROM"])))
                            accountingReport.ddlARFinancialYrFrom.SelectedItem.Text = Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_FROM"]);
                        if (!string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_TO"])))
                            accountingReport.ddlARFinancialYrTo.SelectedItem.Text = Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_TO"]);
                        break;
                    case "Q":
                        if (!string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_FROM"])))
                        {
                            accountingReport.ddlARFinancialYrFrom.SelectedItem.Text = Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_FROM"]);
                            if (!string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_QTR_FROM"])))
                                accountingReport.ddlARFinancialQrFrom.SelectedItem.Text = Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_QTR_FROM"]);
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_TO"])))
                        {
                            accountingReport.ddlARFinancialYrTo.SelectedItem.Text = Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_TO"]);
                            if (!string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_QTR_TO"])))
                                accountingReport.ddlARFinancialQrTo.SelectedItem.Text = Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_QTR_TO"]);
                        }
                        break;
                    case "M":
                        if (!string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_FROM"])))
                        {
                            accountingReport.ddlARFinancialYrFrom.SelectedItem.Text = Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_FROM"]);
                            if (!string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_MONTH_FROM"])))
                                accountingReport.ddlARFinancialMonthFrom.SelectedItem.Text = Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_MONTH_FROM"]);
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_TO"])))
                        {
                            accountingReport.ddlARFinancialYrTo.SelectedItem.Text = Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_YR_TO"]);
                            if (!string.IsNullOrEmpty(Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_MONTH_TO"])))
                                accountingReport.ddlARFinancialMonthTo.SelectedItem.Text = Convert.ToString(dt_Filters.Rows[0]["COST_FOR_FYNC_MONTH_TO"]);
                        }
                        break;
                }
                //AccReportingCommonModel.SetSelectedItems(accountingReport.mddlARSchemeName.chkMultiselect, accountingReport.mddlARSchemeName.txtMultiselect, Convert.ToString(dt_Filters.Rows[0]["SCHEME_NAME"]));
                //AccReportingCommonModel.SetSelectedItems(accountingReport.mddlAREmployeeID.chkMultiselect, accountingReport.mddlAREmployeeID.txtMultiselect, Convert.ToString(dt_Filters.Rows[0]["EMPLOYEE_ID"]));
                //AccReportingCommonModel.SetSelectedItems(accountingReport.mddlAREmployeeName.chkMultiselect, accountingReport.mddlAREmployeeName.txtMultiselect, Convert.ToString(dt_Filters.Rows[0]["EMPLOYEE_NAME"]));
                //AccReportingCommonModel.SetSelectedItems(accountingReport.mddlARGrantOptID.chkMultiselect, accountingReport.mddlARGrantOptID.txtMultiselect, Convert.ToString(dt_Filters.Rows[0]["GRANT_OPTION_ID"]));
                //AccReportingCommonModel.SetSelectedItems(accountingReport.mddlARGrantRegID.chkMultiselect, accountingReport.mddlARGrantRegID.txtMultiselect, Convert.ToString(dt_Filters.Rows[0]["GRANT_REGISTRATION_ID"]));
                ac_AccountingReport.s_FileNameToDownload = Convert.ToString(dt_Filters.Rows[0]["REPORT_NAME"]);
                ac_AccountingReport.s_GroupID = Convert.ToString(dt_Filters.Rows[0]["ACC_RPT_GROUP_ID"]);
                ac_AccountingReport.n_VersionNo = Convert.ToInt32(dt_Filters.Rows[0]["VERSION_NUMBER"]);
                ac_AccountingReport.n_ClientApprovalStatus = Convert.ToInt32(dt_Filters.Rows[0]["CLIENT_APPROVAL_STATUS"]);
                ac_AccountingReport.n_ReviewerApprovalStatus = Convert.ToInt32(dt_Filters.Rows[0]["REVIEWER_APPROVAL_STATUS"]);
                BindStatusSection(accountingReport, dt_Filters, string.Empty);
            }
        }

        /// <summary>
        /// this method is used to bind status section
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="dt_Filters">dt_Filters</param>
        /// <param name="s_ControlID">s_ControlID</param>
        private void BindStatusSection(AccountingReport accountingReport, System.Data.DataTable dt_Filters, string s_ControlID)
        {
            accountingReport.trARSelectTemplCommHistory.Style.Add("display", "none");
            accountingReport.trARSelectTemplReportStatus.Style.Add("display", "none");
            if (Convert.ToString(dt_Filters.Rows[0]["IS_SENT_FOR_REVIEW"]).Equals("0") && !Convert.ToString(dt_Filters.Rows[0]["REVIEWER_APPROVAL_STATUS"]).Equals("3") && !Convert.ToString(dt_Filters.Rows[0]["CLIENT_APPROVAL_STATUS"]).Equals("3"))
            {
                accountingReport.btnARCreateReport.Style.Add("display", "none");
                accountingReport.divARSelectTemplate.Style.Add("display", "");
                accountingReport.divARReportStatusSection.Style.Add("display", "none");
                accountingReport.txtARTemplateComment.Text = Convert.ToString(dt_Filters.Rows[0]["COMMENTS"]);
                accountingReport.ddlARSelectTemplate.Items.FindByText(Convert.ToString(dt_Filters.Rows[0]["SELECTED_TEMPLATE_NAME"]).Trim()).Selected = true;
            }
            else if (Convert.ToString(dt_Filters.Rows[0]["IS_SENT_FOR_REVIEW"]).Equals("1") && Convert.ToString(dt_Filters.Rows[0]["REVIEWER_APPROVAL_STATUS"]).Equals("1"))
            {
                accountingReport.lblARReportSatusText.Text = "Pending for Reviewer Approval";
                accountingReport.btnARCreateReport.Style.Add("display", "none");
                accountingReport.divARSelectTemplate.Style.Add("display", "none");
                accountingReport.divARReportStatusSection.Style.Add("display", "");
                accountingReport.lblARSelectedTemplateNameTxt.Text = Convert.ToString(dt_Filters.Rows[0]["SELECTED_TEMPLATE_NAME"]);
                if (userSessionInfo.ACC_UerTypeID.Equals(5) && accountingReport.hdnARActionButtionID.Value.Equals("lbtnARApproveByReviewer"))
                {
                    accountingReport.trARReviewerComment.Style.Add("display", "");
                    accountingReport.btnARReviewerApprove.Style.Add("display", "");
                    accountingReport.btnARReviewerDisApprove.Style.Add("display", "");
                }
                else
                {
                    accountingReport.trARReviewerComment.Style.Add("display", "none");
                    accountingReport.btnARReviewerApprove.Style.Add("display", "none");
                    accountingReport.btnARReviewerDisApprove.Style.Add("display", "none");
                }
            }
            else if (Convert.ToString(dt_Filters.Rows[0]["IS_SENT_FOR_REVIEW"]).Equals("1") && Convert.ToString(dt_Filters.Rows[0]["REVIEWER_APPROVAL_STATUS"]).Equals("2") && Convert.ToString(dt_Filters.Rows[0]["CLIENT_APPROVAL_STATUS"]).Equals("1"))
            {
                accountingReport.lblARReportSatusText.Text = "Pending for Client Approval";
                accountingReport.btnARCreateReport.Style.Add("display", "none");
                accountingReport.divARSelectTemplate.Style.Add("display", "none");
                accountingReport.divARReportStatusSection.Style.Add("display", "");
                accountingReport.lblARSelectedTemplateNameTxt.Text = Convert.ToString(dt_Filters.Rows[0]["SELECTED_TEMPLATE_NAME"]);
                accountingReport.btnARReviewerApprove.Style.Add("display", "none");
                accountingReport.btnARReviewerDisApprove.Style.Add("display", "none");
                if (accountingReport.hdnARActionButtionID.Value.Equals("lbtnARApproveByClient"))
                {
                    accountingReport.trARReviewerComment.Style.Add("display", "");
                    accountingReport.lblARReviewerComment.Text = "Client Comment";
                    accountingReport.txtARReviewerComment.Text = string.Empty;
                    accountingReport.btnARClientApprove.Style.Add("display", "");
                    accountingReport.btnARClientDisApprove.Style.Add("display", "");
                }
                else
                {
                    accountingReport.trARReviewerComment.Style.Add("display", "none");
                    accountingReport.btnARClientApprove.Style.Add("display", "none");
                    accountingReport.btnARClientDisApprove.Style.Add("display", "none");
                }
            }
            else if (Convert.ToString(dt_Filters.Rows[0]["IS_SENT_FOR_REVIEW"]).Equals("1") && Convert.ToString(dt_Filters.Rows[0]["REVIEWER_APPROVAL_STATUS"]).Equals("2") && Convert.ToString(dt_Filters.Rows[0]["CLIENT_APPROVAL_STATUS"]).Equals("2") && Convert.ToString(dt_Filters.Rows[0]["IS_LOCKED"]).Equals("0"))
            {
                accountingReport.lblARReportSatusText.Text = "Approved";
                accountingReport.btnARCreateReport.Style.Add("display", "none");
                accountingReport.divARSelectTemplate.Style.Add("display", "none");
                accountingReport.divARReportStatusSection.Style.Add("display", "");
                accountingReport.lblARSelectedTemplateNameTxt.Text = Convert.ToString(dt_Filters.Rows[0]["SELECTED_TEMPLATE_NAME"]);
                accountingReport.trARReviewerComment.Style.Add("display", "none");
                accountingReport.btnARReviewerApprove.Style.Add("display", "none");
                accountingReport.btnARReviewerDisApprove.Style.Add("display", "none");
                accountingReport.trARReviewerComment.Style.Add("display", "none");
                accountingReport.txtARReviewerComment.Text = string.Empty;
                accountingReport.btnARClientApprove.Style.Add("display", "none");
                accountingReport.btnARClientDisApprove.Style.Add("display", "none");
            }
            else if (Convert.ToString(dt_Filters.Rows[0]["IS_SENT_FOR_REVIEW"]).Equals("1") && Convert.ToString(dt_Filters.Rows[0]["REVIEWER_APPROVAL_STATUS"]).Equals("2") && Convert.ToString(dt_Filters.Rows[0]["CLIENT_APPROVAL_STATUS"]).Equals("2") && Convert.ToString(dt_Filters.Rows[0]["IS_LOCKED"]).Equals("1"))
            {
                accountingReport.lblARReportSatusText.Text = "Locked";
                accountingReport.btnARCreateReport.Style.Add("display", "none");
                accountingReport.divARSelectTemplate.Style.Add("display", "none");
                accountingReport.divARReportStatusSection.Style.Add("display", "");
                accountingReport.trARReviewerComment.Style.Add("display", "none");
                accountingReport.btnARReviewerApprove.Style.Add("display", "none");
                accountingReport.btnARReviewerDisApprove.Style.Add("display", "none");
                accountingReport.trARReviewerComment.Style.Add("display", "none");
                accountingReport.txtARReviewerComment.Text = string.Empty;
                accountingReport.btnARClientApprove.Style.Add("display", "none");
                accountingReport.btnARClientDisApprove.Style.Add("display", "none");
            }
            else if (Convert.ToString(dt_Filters.Rows[0]["REVIEWER_APPROVAL_STATUS"]).Equals("3"))
            {
                accountingReport.lblARReportSatusText.Text = "Rejected by Reviewer";
                if (s_ControlID.Equals("btnARReviewerDisApprove"))
                {
                    accountingReport.btnARCreateReport.Style.Add("display", "none");
                    accountingReport.divARSelectTemplate.Style.Add("display", "none");
                    accountingReport.divARReportStatusSection.Style.Add("display", "");
                    accountingReport.trARReviewerComment.Style.Add("display", "none");
                    accountingReport.btnARReviewerApprove.Style.Add("display", "none");
                    accountingReport.btnARReviewerDisApprove.Style.Add("display", "none");
                }
                else
                {
                    accountingReport.btnARCreateReport.Style.Add("display", "");
                    accountingReport.divARSelectTemplate.Style.Add("display", "");
                    accountingReport.divARReportStatusSection.Style.Add("display", "none");
                    accountingReport.trARReviewerComment.Style.Add("display", "");
                }
            }
            else if (Convert.ToString(dt_Filters.Rows[0]["CLIENT_APPROVAL_STATUS"]).Equals("3"))
            {
                accountingReport.lblARReportSatusText.Text = "Rejected by Client";
                if (s_ControlID.Equals("btnARClientDisApprove"))
                {
                    accountingReport.btnARCreateReport.Style.Add("display", "none");
                    accountingReport.divARSelectTemplate.Style.Add("display", "none");
                    accountingReport.divARReportStatusSection.Style.Add("display", "");
                    accountingReport.trARReviewerComment.Style.Add("display", "none");
                    accountingReport.btnARClientApprove.Style.Add("display", "none");
                    accountingReport.btnARClientDisApprove.Style.Add("display", "none");
                }
                else
                {
                    accountingReport.btnARCreateReport.Style.Add("display", "");
                    accountingReport.divARSelectTemplate.Style.Add("display", "");
                    accountingReport.divARReportStatusSection.Style.Add("display", "none");
                    accountingReport.trARReviewerComment.Style.Add("display", "");
                }
            }
        }

        /// <summary>
        /// This method is used to show/hide message div
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="s_Msg">s_Msg</param>
        /// <param name="b_IsError">b_IsError</param>
        /// <param name="is_Visible">is_Visible</param>
        public void ShowHideMessageDiv(AccountingReport accountingReport, string s_Msg, bool b_IsError, string is_Visible)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                if (!string.IsNullOrEmpty(s_Msg))
                    accountingReport.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N(s_Msg, CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10);
                accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = is_Visible;
                accountingReport.ctrSuccessErrorMessage.s_MsgForeColor = b_IsError ? Color.Red : Color.Blue;
                accountingReport.ctrSuccessErrorMessage.lblMessage.Focus();
            }
        }

        /// <summary>
        /// This is used to rebind grid data
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        private void RebindGridData(AccountingReport accountingReport)
        {
            accountingReport.gvARMainReport.DataSource = ac_AccountingReport.dt_MainReport;
            accountingReport.gvARMainReport.DataBind();
            // accountingReport.gvARSummaryReport.DataSource = ac_AccountingReport.dt_SummaryReport;
            //accountingReport.gvARSummaryReport.DataBind();
        }

        /// <summary>
        /// this is used to clear the controls
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="s_AccordionIndex">s_AccordionIndex</param>
        /// <param name="s_ReportingDate">s_ReportingDate</param>
        /// <param name="s_Event">s_Event</param>
        private void ClearControls(AccountingReport accountingReport, string s_AccordionIndex, string s_ReportingDate, string s_Event)
        {
            try
            {
                using (AccReportingCommonModel AccReportingCommonModel = new AccReportingCommonModel())
                {
                    if (s_Event.Equals("Reset") && !string.IsNullOrEmpty(ac_AccountingReport.s_GroupID) && Convert.ToInt32(ac_AccountingReport.s_GroupID) > 0)
                    {
                        btnAREditAndView_Click(accountingReport, ac_AccountingReport.s_GroupID, string.Empty);
                    }
                    else
                    {
                        accountingReport.hdnARActionButtionID.Value = accountingReport.hdnARCompanyName.Value = accountingReport.hdnARSelectedTemplteNme.Value = string.Empty;
                        ac_AccountingReport.s_FileNameToDownload = ac_AccountingReport.s_GroupID = accountingReport.hdnARCalcGrantRegID.Value = accountingReport.hdnARACC_RPT_GRP_ID.Value = accountingReport.hdnOPList.Value = "0";
                        ac_AccountingReport.n_ClientApprovalStatus = 0;
                        ac_AccountingReport.n_VersionNo = 1;
                        accountingReport.btnARCreateReport.Style.Add("display", "");
                        accountingReport.hdnARGrantRegID.Value = accountingReport.hdnAR_SSRSStrForCancellation.Value = accountingReport.hdnAR_SSRSQueryString.Value = accountingReport.hdnAR_SSRSStrForSummary.Value =
                        accountingReport.hdnARCalcMP_Type.Value = ac_AccountingReport.s_FileNameToDownload = ac_AccountingReport.s_Selected_Opt_GrantIDs = string.Empty;
                        AccReportingCommonModel.ClearSelectedItems(accountingReport.mddlARSchemeName.chkMultiselect, accountingReport.mddlARSchemeName.txtMultiselect);
                        AccReportingCommonModel.ClearSelectedItems(accountingReport.mddlAREmployeeID.chkMultiselect, accountingReport.mddlAREmployeeID.txtMultiselect);
                        AccReportingCommonModel.ClearSelectedItems(accountingReport.mddlAREmployeeName.chkMultiselect, accountingReport.mddlAREmployeeName.txtMultiselect);
                        AccReportingCommonModel.ClearSelectedItems(accountingReport.mddlARGrantOptID.chkMultiselect, accountingReport.mddlARGrantOptID.txtMultiselect);
                        AccReportingCommonModel.ClearSelectedItems(accountingReport.mddlARGrantRegID.chkMultiselect, accountingReport.mddlARGrantRegID.txtMultiselect);
                        accountingReport.rdoARDisplayCostAfter.Items.FindByValue("Y").Selected = true;
                        accountingReport.rdoARDisplayCostBefore.Items.FindByValue("Y").Selected = true;
                        accountingReport.rdoARDisplayCostFor.Items.FindByValue("Y").Selected = true;

                        accountingReport.chkARSeniorManagement.Checked = false;
                        accountingReport.txtARDate.Text = s_ReportingDate;

                        if (!s_Event.Equals("TextChanged"))
                            txtARDate_TextChanged(accountingReport, accountingReport.txtARDate.Text, string.Empty);

                        accountingReport.ddlARFinancialYrFrom.SelectedItem.Value = accountingReport.ddlARFinancialYrTo.SelectedItem.Value = "0";
                        accountingReport.txtARGrantFromDate.Text = accountingReport.txtARGrantToDate.Text = accountingReport.txtARTemplateComment.Text = string.Empty;
                        accountingReport.btnARViewReport.Enabled = true;
                        accountingReport.btnARViewReport.ToolTip = "View";
                        accountingReport.divARReportStatusSection.Style.Add("display", "none");
                        accountingReport.trARSelectTemplCommHistory.Style.Add("display", "none");
                        accountingReport.divARSelectTemplate.Style.Add("display", "none");
                        accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                        accountingReport.ctrSuccessErrorMessage.lblMessage.Text = string.Empty;
                    }
                    switch (s_AccordionIndex)
                    {
                        case "1":
                            accountingReport.hdnARAccordionIndex.Value = "1";
                            accountingReport.h4ARAddEditPanel.Style.Add("display", "");
                            accountingReport.divARReportSection.Style.Add("display", "none");
                            accountingReport.divAREmptyRow.Style.Add("display", "none");
                            accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "none");
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Generate Report

        /// <summary>
        /// Download rEport button click event
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        public void btnARDownloadReport_Click(AccountingReport accountingReport)
        {
            Microsoft.Office.Interop.Word.Application oMSWord = new Microsoft.Office.Interop.Word.Application();
            Microsoft.Office.Interop.Word.Document oDoc = new Microsoft.Office.Interop.Word.Document();
            string s_SelectedTemplateName = accountingReport.ddlARSelectTemplate.SelectedItem.Text + ".xml";
            object s_TemplatePath_XML = null;
            object missing = System.Type.Missing;

            try
            {
                GetIVFVCostDetail(accountingReport);
                using (System.Data.DataTable dt_Result = GetCUDReturnValue(accountingReport))
                {
                    if (Convert.ToInt32(dt_Result.Rows[0]["Result"]).Equals(1) || Convert.ToInt32(dt_Result.Rows[0]["Result"]).Equals(2))
                    {
                        ac_AccountingReport.s_GroupID = !string.IsNullOrEmpty(Convert.ToString(dt_Result.Rows[0]["Group_ID"])) ? Convert.ToString(dt_Result.Rows[0]["Group_ID"]) : "0";
                        ac_AccountingReport.n_VersionNo = Convert.ToInt32(dt_Result.Rows[0]["VERSION_NUMBER"]) > 0 ? Convert.ToInt32(dt_Result.Rows[0]["VERSION_NUMBER"]) : 1;

                        s_TemplatePath_XML = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/");
                        if (!Directory.Exists(s_TemplatePath_XML + @"\Temp"))
                            Directory.CreateDirectory(s_TemplatePath_XML + @"\Temp");

                        s_TemplatePath_XML = s_TemplatePath_XML + @"\Temp\" + s_SelectedTemplateName;
                        switch (accountingReport.ddlARSelectTemplate.SelectedItem.Text)
                        {
                            case "Default":
                                File.Copy(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "Default.xml"), Convert.ToString(s_TemplatePath_XML), true);
                                break;

                            default:
                                File.Copy(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/" + s_SelectedTemplateName), Convert.ToString(s_TemplatePath_XML), true);
                                break;
                        }
                        try
                        {
                            oDoc = oMSWord.Documents.Open(ref s_TemplatePath_XML, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
                            oDoc.Activate();

                            ReplaceParameters(ref oDoc, "@NAME_OF_COMPANY", userSessionInfo.ACC_CompanyTitle);
                            ReplaceParameters(ref oDoc, "@REPORTING_DATE", Convert.ToDateTime(ac_AccountingReport.s_Reporting_Date).ToString("dd-MMM-yyyy"));
                            ReplaceParameters(ref oDoc, "@COST_IV", Convert.ToString(ac_AccountingReport.ds_CompCostReportDetails.Tables[0].Rows[0]["Cost"]));
                            ReplaceParameters(ref oDoc, "@COST_FV", Convert.ToString(ac_AccountingReport.ds_CompCostReportDetails.Tables[1].Rows[0]["Cost"]));


                            if (!Directory.Exists(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/" + "FinalReport")))
                            {
                                Directory.CreateDirectory(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + userSessionInfo.ACC_CompanyName + "/" + "FinalReport"));
                                Directory.CreateDirectory(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + userSessionInfo.ACC_CompanyName + "/" + "TempReport"));
                            }
                            string s_FileName = GetReportNameToSave(s_SelectedTemplateName, oDoc);

                            ac_AccountingReport.s_ReportDate = string.IsNullOrEmpty(Convert.ToString(ac_AccountingReport.s_ReportDate)) ? accountingReport.txtARDate.Text : ac_AccountingReport.s_ReportDate;
                            //missing = GetAccountingPrameters(missing, s_FileName);

                            if (!string.IsNullOrEmpty(s_FileName))
                                DownloadDocument(accountingReport, string.Empty);
                            accountingReport.divARReportStatusSection.Style.Add("display", "");
                            accountingReport.divARSelectTemplate.Style.Add("display", "none");
                        }
                        catch
                        {
                            ((Microsoft.Office.Interop.Word._Document)oDoc).Close(ref missing, ref missing, ref missing);
                            ((Microsoft.Office.Interop.Word._Application)oMSWord).Quit(ref missing, ref missing, ref missing);
                            File.Delete(Convert.ToString(s_TemplatePath_XML));
                        }
                    }
                    else
                    {
                        accountingReport.h4ARViewWorkingsPanel.Style.Add("display", "");
                        accountingReport.divARReportStatusSection.Style.Add("display", "none");
                        accountingReport.divARSelectTemplate.Style.Add("display", "");
                        RebindGridData(accountingReport);
                    }
                }
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                HttpContext.Current.Response.Flush();
            }
            finally
            {
                ((Microsoft.Office.Interop.Word._Document)oDoc).Close(ref missing, ref missing, ref missing);
                ((Microsoft.Office.Interop.Word._Application)oMSWord).Quit(ref missing, ref missing, ref missing);
                File.Delete(Convert.ToString(s_TemplatePath_XML));
            }
        }

        /// <summary>
        /// This method is used to get Compensation Cost By IV/FV
        /// </summary>
        /// <param name="accountingReport">accountingReport object</param>
        internal void GetIVFVCostDetail(AccountingReport accountingReport)
        {
            using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_MainReport;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.REPORTING_DATE = string.IsNullOrEmpty(accountingReport.txtARDate.Text) ? ac_AccountingReport.s_Reporting_Date : accountingReport.txtARDate.Text;
                    accountingProperties.MARKET_PRICE_TYPE = accountingReport.rdoARMarketPriceType.SelectedItem.Text;
                    accountingProperties.SCHEME_NAME = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlARSchemeName.chkMultiselect, accountingReport.mddlARSchemeName.txtMultiselect);
                    accountingProperties.EMPLOYEE_ID = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlAREmployeeID.chkMultiselect, accountingReport.mddlAREmployeeID.txtMultiselect);
                    accountingProperties.EMPLOYEE_NAME = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlAREmployeeName.chkMultiselect, accountingReport.mddlAREmployeeName.txtMultiselect);
                    accountingProperties.GRANT_REGISTRATION_ID = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlARGrantRegID.chkMultiselect, accountingReport.mddlARGrantRegID.txtMultiselect);
                    accountingProperties.GRANT_OPTION_ID = accReportingCommonModel.SearchEmployeeData(accountingReport.mddlARGrantOptID.chkMultiselect, accountingReport.mddlARGrantOptID.txtMultiselect);
                    accountingProperties.IS_SENIOR_MANAGEMENT_CHECKED = accountingReport.chkARSeniorManagement.Checked;
                    if (!accountingReport.txtARGrantFromDate.Text.Equals("dd/mmm/yyyy") && !string.IsNullOrEmpty(accountingReport.txtARGrantFromDate.Text))
                        accountingProperties.GRANT_FROM_DATE = accountingReport.txtARGrantFromDate.Text;
                    if (!accountingReport.txtARGrantToDate.Text.Equals("dd/mmm/yyyy") && !string.IsNullOrEmpty(accountingReport.txtARGrantToDate.Text))
                        accountingProperties.GRANT_TO_DATE = accountingReport.txtARGrantToDate.Text;
                    accountingProperties.DISPLAY_COST_FOR = accountingReport.rdoARDisplayCostFor.SelectedItem.Value;
                    switch (accountingReport.rdoARDisplayCostFor.SelectedItem.Value.Trim())
                    {
                        case "Y":
                            if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                            if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                            break;
                        case "Q":
                            if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                            {
                                accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                if (!accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_QTR_FROM = accountingReport.ddlARFinancialQrFrom.SelectedItem.Text;
                            }
                            if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                            {
                                accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                if (!accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_QTR_TO = accountingReport.ddlARFinancialQrTo.SelectedItem.Text;
                            }
                            break;
                        case "M":
                            if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                            {
                                accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                if (!accountingReport.ddlARFinancialMonthFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialMonthFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_MONTH_FROM = accountingReport.ddlARFinancialMonthFrom.SelectedItem.Text;
                            }
                            if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                            {
                                accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                if (!accountingReport.ddlARFinancialMonthTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialMonthTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_MONTH_TO = accountingReport.ddlARFinancialMonthTo.SelectedItem.Text;
                            }
                            break;
                    }

                    accountingProperties.DISPLAY_COST_BEFORE = accountingReport.rdoARDisplayCostBefore.SelectedItem.Value;
                    accountingProperties.DISPLAY_COST_AFTER = accountingReport.rdoARDisplayCostAfter.SelectedItem.Value;
                    accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                    accountingProperties.CALCULATION_METHOD = userSessionInfo.ACC_CalculationMethod;
                    accountingProperties.Type = "PDFDATABYTYPE";
                    ac_AccountingReport.ds_CompCostReportDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                    accountingReport.gvARMainReport.DataSource = ac_AccountingReport.dt_SummaryDReport != null && ac_AccountingReport.dt_SummaryDReport.Rows.Count > 0 ? ac_AccountingReport.dt_SummaryDReport : new System.Data.DataTable();
                    accountingReport.gvARMainReport.DataBind();
                }
            }
        }
        /// <summary>
        /// This method is used to get acconting parameters and show it in seperate word/pdf document
        /// </summary>
        /// <param name="missing">missing</param>
        /// <param name="s_FilePathToSave">FilePathToSave</param>
        /// <param name="b_IsErrorOccured">IsErrorOccured</param>
        /// <returns>object</returns>
        private object GetAccountingPrameters(object missing, string s_FilePathToSave, out bool b_IsErrorOccured)
        {
            //to download accounting parameters
            Microsoft.Office.Interop.Word.Application oMSWord_Acc = new Microsoft.Office.Interop.Word.Application();
            Microsoft.Office.Interop.Word.Document oDoc_Acc = oMSWord_Acc.Documents.Add(ref missing, ref missing, ref missing, ref missing);

            try
            {
                //Add header into the document
                foreach (Microsoft.Office.Interop.Word.Section section in oDoc_Acc.Sections)
                {
                    //Get the header range and add the header details.
                    Microsoft.Office.Interop.Word.Range headerRange = section.Headers[Microsoft.Office.Interop.Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                    headerRange.Fields.Add(headerRange, Microsoft.Office.Interop.Word.WdFieldType.wdFieldPage);
                    headerRange.ParagraphFormat.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphLeft;
                    headerRange.Font.ColorIndex = Microsoft.Office.Interop.Word.WdColorIndex.wdGray50;
                    headerRange.Font.Size = 10;
                    headerRange.Font.Italic = 1;
                    headerRange.Text = "Accounting Parameters for company " + userSessionInfo.ACC_CompanyTitle;
                }

                //Add paragraph with Heading 1 style
                Microsoft.Office.Interop.Word.Paragraph para1 = oDoc_Acc.Content.Paragraphs.Add(ref missing);
                para1.Range.Font.Size = 15;
                para1.Range.Font.Bold = 1;
                para1.Range.Text = "Accounting Parameters for reporting date: " + Convert.ToDateTime(ac_AccountingReport.s_ReportDate).ToString("dd/MMM/yyyy");
                para1.Range.Paragraphs.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                para1.Range.InsertParagraphAfter();
                para1.Range.InsertParagraphAfter();

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.PageName = CommonConstantModel.s_Get_Accounting_Parameters;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.ReportDate = Convert.ToDateTime(ac_AccountingReport.s_ReportDate);

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    System.Data.DataTable dt = Pivot(accountingCRUDProperties.dt_Result);

                    dt.Columns[0].ColumnName = "Accounting Parameter";
                    dt.Columns[1].ColumnName = "Value";

                    using (System.Data.DataTable dt_AccountingPramText = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10_UI))
                    {
                        Microsoft.Office.Interop.Word.Table AccountingPramTable = oDoc_Acc.Tables.Add(para1.Range, (dt.Rows.Count + 1), 2, ref missing, ref missing);

                        AccountingPramTable.Borders.Enable = 1;

                        int n_RowNumber = -1, n_CellNumber = 0;
                        foreach (Row row in AccountingPramTable.Rows)
                        {
                            n_CellNumber = 0;
                            foreach (Cell cell in row.Cells)
                            {
                                try
                                {
                                    //Header row
                                    if (cell.RowIndex == 1)
                                    {
                                        cell.Range.Text = dt.Columns[n_CellNumber].ColumnName.ToString();
                                        cell.Range.Font.Bold = 1;
                                        //other format properties goes here
                                        cell.Range.Font.Name = "verdana";
                                        cell.Range.Font.Size = 10;
                                        //cell.Range.Font.ColorIndex = WdColorIndex.wdGray25;                            
                                        cell.Shading.BackgroundPatternColor = WdColor.wdColorGray25;
                                        //Center alignment for the Header cells
                                        cell.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;

                                    }
                                    //Data row
                                    else
                                    {
                                        cell.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                                        string s_StringValue = string.Empty;
                                        if (Convert.ToString(dt.Rows[n_RowNumber][n_CellNumber]).Split(',').Length > 1)
                                        {
                                            foreach (var item in Convert.ToString(dt.Rows[n_RowNumber][n_CellNumber]).Split(','))
                                            {
                                                s_StringValue = s_StringValue + dt_AccountingPramText.Select("LabelID = '" + item + "'")[0]["LabelName"].ToString() + ",";
                                            }
                                            s_StringValue.TrimEnd(',');
                                        }

                                        cell.Range.Text = n_CellNumber.Equals(0) ? Convert.ToString(dt.Rows[n_RowNumber][n_CellNumber]) : string.IsNullOrEmpty(Convert.ToString(dt.Rows[n_RowNumber][n_CellNumber])) ? string.Empty : string.IsNullOrEmpty(s_StringValue) ? dt_AccountingPramText.Select("LabelID = '" + Convert.ToString(dt.Rows[n_RowNumber][n_CellNumber]) + "'")[0]["LabelName"].ToString() : s_StringValue;
                                    }

                                }
                                catch (Exception ex)
                                {

                                    throw ex;
                                }

                                cell.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;

                                n_CellNumber++;
                            }

                            n_RowNumber++;
                        }
                    }
                    //Save the document
                    object filename = s_FilePathToSave.Replace(".pdf", ".docx");
                    oDoc_Acc.SaveAs2(ref filename);
                    oDoc_Acc.ExportAsFixedFormat(s_FilePathToSave.Replace(".docx", ".pdf"), Microsoft.Office.Interop.Word.WdExportFormat.wdExportFormatPDF);
                }
            }
            catch
            {
                b_IsErrorOccured = true;
            }
            finally
            {
                b_IsErrorOccured = false;
                ((_Document)oDoc_Acc).Close(WdSaveOptions.wdDoNotSaveChanges, ref missing, ref missing);
                ((_Application)oMSWord_Acc).Quit(WdSaveOptions.wdDoNotSaveChanges, ref missing, ref missing);
                ac_AccountingReport.s_ReportDate = string.Empty;
            }
            return missing;
        }

        /// <summary>
        /// This method is used to pivote datatable
        /// </summary>
        /// <param name="inputTable">inputTable</param>
        /// <returns>DataTable</returns>
        public System.Data.DataTable Pivot(System.Data.DataTable inputTable)
        {

            System.Data.DataTable outputTable = new System.Data.DataTable();

            // Add columns by looping rows

            // Header row's first column is same as in inputTable
            outputTable.Columns.Add(inputTable.Columns[0].ColumnName.ToString());

            // Header row's second column onwards, 'inputTable's first column taken
            foreach (DataRow inRow in inputTable.Rows)
            {
                string newColName = inRow[0].ToString();
                outputTable.Columns.Add(newColName);
            }

            // Add rows by looping columns        
            for (int rCount = 1; rCount <= inputTable.Columns.Count - 1; rCount++)
            {
                DataRow newRow = outputTable.NewRow();

                // First column is inputTable's Header row's second column
                newRow[0] = inputTable.Columns[rCount].ColumnName.ToString();
                for (int cCount = 0; cCount <= inputTable.Rows.Count - 1; cCount++)
                {
                    string colValue = inputTable.Rows[cCount][rCount].ToString();
                    newRow[cCount + 1] = colValue;
                }
                outputTable.Rows.Add(newRow);
            }

            return outputTable;
        }
        /// <summary>
        /// This method is used to download the document
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <param name="s_ControlID">s_ControlID</param>
        public void DownloadDocument(AccountingReport accountingReport, string s_ControlID)
        {
            try
            {
                object missing = System.Type.Missing;
                bool b_IsErrorOccured = false;

                using (WebClient o_WebClient = new WebClient())
                {
                    using (ZipFile zip = new ZipFile())
                    {
                        HttpResponse o_HttpResponse = HttpContext.Current.Response;
                        o_HttpResponse.Clear();
                        o_HttpResponse.ClearContent();
                        o_HttpResponse.ClearHeaders();
                        o_HttpResponse.Buffer = true;
                        o_HttpResponse.BufferOutput = false;

                        if (s_ControlID.Equals("btnARDownloadSelectedDoc"))
                        {
                            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + accountingReport.hdnARSelectedTemplteNme.Value.Trim() + ".pdf");
                            if (accountingReport.hdnARSelectedTemplteNme.Value.Trim().ToUpper().Equals("DEFAULT"))
                                o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + accountingReport.hdnARSelectedTemplteNme.Value.Trim() + ".pdf").Replace("/", "\\")));
                            else o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/" + accountingReport.hdnARSelectedTemplteNme.Value.Trim() + ".pdf").Replace("/", "\\")));
                        }
                        else if (s_ControlID.Equals("btnARDownloadSlctedRport"))
                        {
                            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + accountingReport.hdnARSelectedTemplteNme.Value.Trim() + ".pdf");
                            o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/FinalReport/" + "Group_No_" + accountingReport.hdnARACC_RPT_GRP_ID.Value.Trim() + "/" + accountingReport.hdnARSelectedTemplteNme.Value.Trim() + ".pdf").Replace("/", "\\")));
                        }
                        else
                        {
                            HttpContext.Current.Response.ContentType = "application/zip";
                            HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=FinalReport.zip");
                            //HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" + ac_AccountingReport.s_FileNameToDownload.Trim() + ".pdf");

                            missing = GetAccountingPrameters(missing, HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/FinalReport/" + "Group_No_" + ac_AccountingReport.s_GroupID.Trim() + "/" + ac_AccountingReport.s_FileNameToDownload.Trim() + "_Parameters" + ".pdf").Replace("/", "\\"), out b_IsErrorOccured);

                            zip.AddFile(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/FinalReport/" + "Group_No_" + ac_AccountingReport.s_GroupID.Trim() + "/" + ac_AccountingReport.s_FileNameToDownload.Trim() + ".pdf").Replace("/", "\\"), "FinalReportPDF");
                            zip.AddFile(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/FinalReport/" + "Group_No_" + ac_AccountingReport.s_GroupID.Trim() + "/" + ac_AccountingReport.s_FileNameToDownload.Trim() + "_Parameters" + ".pdf").Replace("/", "\\"), "AccountingPrametersPDF");

                            zip.Save(HttpContext.Current.Response.OutputStream);
                        }

                        if (!b_IsErrorOccured)
                        {
                            // Sends all currently buffered output to the client.
                            HttpContext.Current.Response.Flush();
                            //Gets or sets a value indicating whether to send HTTP content to the client.
                            HttpContext.Current.Response.SuppressContent = true;
                            // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.  
                            HttpContext.Current.ApplicationInstance.CompleteRequest();
                        }
                    }

                }
            }
            catch (FileNotFoundException e)
            {
                e.Message.Equals("File Not Found!");
            }
        }

        /// <summary>
        /// This method is used to perform CUD operation
        /// </summary>
        /// <param name="accountingReport">AccountingReport class object</param>
        /// <returns>returns data table</returns>
        private System.Data.DataTable GetCUDReturnValue(AccountingReport accountingReport)
        {
            try
            {
                using (AccReportingCommonModel AccReportingCommonModel = new AccReportingCommonModel())
                {
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                        accountingProperties.PopulateControls = CommonConstantModel.s_CUDReportData;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.OPT_GRANT_IDs = ac_AccountingReport.s_Selected_Opt_GrantIDs;
                        accountingProperties.REPORTING_DATE = ac_AccountingReport.s_Reporting_Date;
                        accountingProperties.SELECTED_TEMPLATE_NAME = accountingReport.ddlARSelectTemplate.SelectedItem.Text;
                        accountingProperties.MARKET_PRICE_TYPE = accountingReport.rdoARMarketPriceType.SelectedItem.Value;
                        accountingProperties.SCHEME_NAME = GetCommaSepratedValues("SCHEME");
                        accountingProperties.EMPLOYEE_ID = GetCommaSepratedValues("EMPID");
                        accountingProperties.EMPLOYEE_NAME = GetCommaSepratedValues("EMPNAME");
                        accountingProperties.GRANT_REGISTRATION_ID = GetCommaSepratedValues("GRANT_REG_ID");
                        accountingProperties.GRANT_OPTION_ID = GetCommaSepratedValues("GRANTOPID");
                        accountingProperties.IS_SENIOR_MANAGEMENT = accountingReport.chkARSeniorManagement.Checked;
                        if (!accountingReport.txtARGrantFromDate.Text.Equals("dd/mmm/yyyy") && !accountingReport.txtARGrantFromDate.Text.Equals(""))
                            accountingProperties.GRANT_FROM_DATE = accountingReport.txtARGrantFromDate.Text;
                        if (!accountingReport.txtARGrantToDate.Text.Equals("dd/mmm/yyyy") && !accountingReport.txtARGrantToDate.Text.Equals(""))
                            accountingProperties.GRANT_TO_DATE = accountingReport.txtARGrantToDate.Text;
                        accountingProperties.DISPLAY_COST_FOR = accountingReport.rdoARDisplayCostFor.SelectedItem.Value;
                        switch (accountingReport.rdoARDisplayCostFor.SelectedItem.Value.Trim())
                        {
                            case "Y":
                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                break;
                            case "Q":
                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_QTR_FROM = accountingReport.ddlARFinancialQrFrom.SelectedItem.Text;
                                }
                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_QTR_TO = accountingReport.ddlARFinancialQrTo.SelectedItem.Text;
                                }
                                break;
                            case "M":
                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_FROM = accountingReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialMonthFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialMonthFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_MONTH_FROM = accountingReport.ddlARFinancialMonthFrom.SelectedItem.Text;
                                }
                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                {
                                    accountingProperties.COST_FOR_FYNC_YR_TO = accountingReport.ddlARFinancialYrTo.SelectedItem.Text;
                                    if (!accountingReport.ddlARFinancialMonthTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialMonthTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                        accountingProperties.COST_FOR_FYNC_MONTH_TO = accountingReport.ddlARFinancialMonthTo.SelectedItem.Text;
                                }
                                break;
                        }
                        accountingProperties.DISPLAY_COST_BEFORE = accountingReport.rdoARDisplayCostBefore.SelectedItem.Value;
                        accountingProperties.DISPLAY_COST_AFTER = accountingReport.rdoARDisplayCostAfter.SelectedItem.Value;
                        accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                        if (ac_AccountingReport.n_VersionNo < 1)
                            ac_AccountingReport.n_VersionNo = 1;
                        if (!string.IsNullOrEmpty(ac_AccountingReport.s_GroupID) && Convert.ToInt32(ac_AccountingReport.s_GroupID) > 0)
                        {
                            if (ac_AccountingReport.n_ClientApprovalStatus.Equals(3))
                            {
                                ac_AccountingReport.n_VersionNo = Convert.ToInt32(ac_AccountingReport.n_VersionNo) + 1;
                                ac_AccountingReport.n_ClientApprovalStatus = 0;
                                accountingProperties.CLIENT_APPROVAL_STATUS = 0;
                                accountingProperties.REVIEWER_APPROVAL_STATUS = 0;
                                accountingProperties.IS_SENT_FOR_REVIEW = false;
                                accountingProperties.IS_SENT_TO_CLIENT = false;
                            }
                            accountingProperties.Action = "U";
                            accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(ac_AccountingReport.s_GroupID);
                        }
                        else accountingProperties.Action = "C";
                        accountingProperties.REPORT_NAME = accountingReport.ddlARSelectTemplate.SelectedItem.Text.Trim() + "_" + Convert.ToDateTime(ac_AccountingReport.s_Reporting_Date).ToString("dd-MMM-yyyy") + "_Version-" + ac_AccountingReport.n_VersionNo;
                        accountingProperties.VERSION_NUMBER = ac_AccountingReport.n_VersionNo;
                        ac_AccountingReport.s_FileNameToDownload = accountingProperties.REPORT_NAME;
                        using (System.Data.DataTable dt_Result = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result)
                        {
                            switch (Convert.ToInt32(dt_Result.Rows[0]["Result"]))
                            {
                                case 1: ShowHideMessageDiv(accountingReport, "ReportCreatedSuccessMsg", false, string.Empty); break;
                                case 2: ShowHideMessageDiv(accountingReport, "ReportUpdatedSuccessMsg", false, string.Empty); break;
                                case 3: ShowHideMessageDiv(accountingReport, "ReportDeletedSuccessMsg", false, string.Empty); break;
                                case 4: ShowHideMessageDiv(accountingReport, "ReportGrantAlreadyExistsErrorMsg", true, string.Empty); break;
                            }
                            return dt_Result;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to get Comma seprated list 
        /// </summary>
        /// <param name="s_ColName">Column name Object</param>
        /// <returns></returns>
        internal string GetCommaSepratedValues(string s_ColName)
        {
            string s_result = string.Empty;
            if (ac_AccountingReport.ds_ReportFilters != null && ac_AccountingReport.ds_ReportFilters.Tables.Count > 0)
            {
                switch (s_ColName)
                {
                    case "SCHEME":
                        s_result = string.Join(",", ac_AccountingReport.ds_ReportFilters.Tables[0].AsEnumerable()
                                 .Select(b => b["SCH_SCHEME_TITLE"])
                                 .ToArray());

                        break;

                    case "EMPID":
                        s_result = string.Join(",", ac_AccountingReport.ds_ReportFilters.Tables[1].AsEnumerable()
                                  .Where(b => b["EMPLOYEE_ID"].ToString() != null)
                                  .Select(b => b["EMPLOYEE_ID"])
                                  .ToArray());

                        break;

                    case "EMPNAME":
                        s_result = string.Join(",", ac_AccountingReport.ds_ReportFilters.Tables[2].AsEnumerable()
                                 .Where(b => b["EMPLOYEE_NAME"].ToString() != null)
                                 .Select(b => b["EMPLOYEE_NAME"])
                                 .ToArray());

                        break;

                    case "GRANT_REG_ID":
                        s_result = string.Join(",", ac_AccountingReport.ds_ReportFilters.Tables[3].AsEnumerable()
                                 .Where(b => b["GRS_GRANT_REGISTRATION_ID"].ToString() != null)
                                 .Select(b => b["GRS_GRANT_REGISTRATION_ID"])
                                 .ToArray());

                        break;

                    case "GRANTOPID":
                        s_result = string.Join(",", ac_AccountingReport.ds_ReportFilters.Tables[4].AsEnumerable()
                                 .Where(b => b["GRANT_OPTION_ID"].ToString() != null)
                                 .Select(b => b["GRANT_OPTION_ID"])
                                 .ToArray());

                        break;
                }
            }

            return s_result.Trim();
        }

        /// <summary>
        /// This method returns report name to save
        /// </summary>
        /// <param name="s_SelectedTemplateName">s_SelectedTemplateName</param>
        /// <param name="oDoc">oDoc</param>
        /// <returns>returns report name to save</returns>
        private string GetReportNameToSave(string s_SelectedTemplateName, Microsoft.Office.Interop.Word.Document oDoc)
        {
            string a_TemplatePath = ConfigurationManager.AppSettings["ACCTemplatePath"];
            string filename = HttpContext.Current.Server.MapPath(a_TemplatePath + userSessionInfo.ACC_CompanyName + "/" + "FinalReport") + "\\" + s_SelectedTemplateName.Replace(".xml", "") + ".pdf";
            //Covert word to pdf
            oDoc.ExportAsFixedFormat(filename, Microsoft.Office.Interop.Word.WdExportFormat.wdExportFormatPDF);

            if (!Directory.Exists(HttpContext.Current.Server.MapPath(a_TemplatePath + userSessionInfo.ACC_CompanyName + "/" + "FinalReport") + "\\" + "Group_No_" + ac_AccountingReport.s_GroupID))
            {
                Directory.CreateDirectory(HttpContext.Current.Server.MapPath(a_TemplatePath + userSessionInfo.ACC_CompanyName + "/" + "FinalReport") + "\\" + "Group_No_" + ac_AccountingReport.s_GroupID);
            }

            if (!File.Exists(Path.Combine(HttpContext.Current.Server.MapPath(a_TemplatePath + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + ac_AccountingReport.s_GroupID + "/"), accountingProperties.REPORT_NAME + ".pdf")))
            {
                File.Move(filename, Path.Combine(HttpContext.Current.Server.MapPath(a_TemplatePath + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + ac_AccountingReport.s_GroupID + "/"), accountingProperties.REPORT_NAME + ".pdf"));
            }
            else
            {
                File.Delete(Path.Combine(HttpContext.Current.Server.MapPath(a_TemplatePath + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + ac_AccountingReport.s_GroupID + "/"), accountingProperties.REPORT_NAME + ".pdf"));
                File.Move(filename, Path.Combine(HttpContext.Current.Server.MapPath(a_TemplatePath + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + ac_AccountingReport.s_GroupID + "/"), accountingProperties.REPORT_NAME + ".pdf"));
            }
            return accountingProperties.REPORT_NAME;
        }

        /// <summary>
        /// This method is used to Replace report place holders
        /// </summary>
        /// <param name="oDoc">oDoc</param>
        /// <param name="s_KeyName">s_KeyName</param>
        /// <param name="s_ReplacementText">s_ReplacementText</param>
        private void ReplaceParameters(ref Microsoft.Office.Interop.Word.Document oDoc, string s_KeyName, string s_ReplacementText)
        {
            object missing = System.Type.Missing;
            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            oDoc.Content.Application.Selection.Find.Text = s_KeyName; oDoc.Content.Application.Selection.Find.Replacement.Text = string.IsNullOrEmpty(s_ReplacementText) ? string.Empty : s_ReplacementText;
            oDoc.Content.Application.Selection.Find.Execute(Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, ref replaceAll, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            foreach (Microsoft.Office.Interop.Word.Section wordSection in oDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter wordFooter in wordSection.Footers)
                {
                    Microsoft.Office.Interop.Word.Range docRange = wordFooter.Range;
                    docRange.Find.ClearFormatting();
                    docRange.Find.Text = s_KeyName;
                    docRange.Find.Replacement.ClearFormatting();
                    docRange.Find.Replacement.Text = s_ReplacementText;
                    docRange.Find.Execute(Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, ref replaceAll, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                }
            }
        }

        /// <summary>
        /// This method is used to get calculations
        /// </summary>
        /// <param name="oDoc">oDoc</param>
        /// <returns>returns calculations</returns>
        public string GetCalculations(Microsoft.Office.Interop.Word.Document oDoc = null)
        {
            object oMissing = System.Reflection.Missing.Value;
            string Calculations = string.Empty;
            object missing = System.Type.Missing;
            Microsoft.Office.Interop.Word.Table tempTable = null;
            try
            {
                GenerateCompensationCostTable(oDoc, ref oMissing, ref missing, ref tempTable);
            }
            catch
            {
                throw;
            }

            return Calculations;
        }

        /// <summary>
        /// this method is used to generate compensation cost table
        /// </summary>
        /// <param name="oDoc">oDoc</param>
        /// <param name="oMissing">oMissing</param>
        /// <param name="missing">missing</param>
        /// <param name="tempTable">tempTable</param>
        private void GenerateCompensationCostTable(Microsoft.Office.Interop.Word.Document oDoc, ref object oMissing, ref object missing, ref Microsoft.Office.Interop.Word.Table tempTable)
        {
            while (true)
            {
                using (GetValuationParameters getValuationParameters = new GetValuationParameters())
                {

                    Microsoft.Office.Interop.Word.Range currentRange = oDoc.Content;
                    Microsoft.Office.Interop.Word.Find find = currentRange.Find;
                    find.Text = "@COMPENSATION_COST_DETAILS";
                    find.ClearFormatting();
                    find.Execute(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);

                    if (find.Found)
                    {
                        using (System.Data.DataTable outputTable = ac_AccountingReport.dt_CompensationCostDetails)
                        {
                            #region Create table
                            Microsoft.Office.Interop.Word.Table MSWTable = oDoc.Content.Tables.Add(currentRange, outputTable.Rows.Count + 1, outputTable.Columns.Count, ref oMissing, ref oMissing);

                            currentRange.InsertParagraphAfter();
                            MSWTable.Range.ParagraphFormat.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;
                            MSWTable.Columns.DistributeWidth();
                            MSWTable.set_Style("Table Grid 5");
                            #endregion

                            int n_Colcount = 1;
                            int n_Rowcount = 2;

                            #region Create header
                            foreach (DataColumn column in outputTable.Columns)
                            {
                                MSWTable.Cell(1, n_Colcount).Range.Cells.Width = n_Colcount.Equals(1) ? 165 : 90;

                                MSWTable.Cell(1, n_Colcount).Range.Text = column.ColumnName;
                                MSWTable.Cell(1, n_Colcount).Range.Font.Size = 11;
                                MSWTable.Cell(1, n_Colcount).Range.Font.Bold = 1;
                                MSWTable.Cell(1, n_Colcount).Range.Font.ColorIndex = Microsoft.Office.Interop.Word.WdColorIndex.wdBlack;
                                MSWTable.Cell(1, n_Colcount).Range.Shading.BackgroundPatternColor = Microsoft.Office.Interop.Word.WdColor.wdColorGray15;
                                n_Colcount++;
                            }
                            #endregion

                            #region Create rows
                            n_Colcount = 1;
                            foreach (DataRow row in outputTable.Rows)
                            {
                                n_Colcount = 1;
                                foreach (DataColumn column in outputTable.Columns)
                                {

                                    MSWTable.Cell(n_Rowcount, n_Colcount).Range.Cells.Width = n_Colcount.Equals(1) ? 165 : 90;
                                    MSWTable.Cell(n_Rowcount, n_Colcount).Range.Text = Convert.ToString(row[column.ColumnName]);
                                    MSWTable.Cell(n_Rowcount, n_Colcount).Range.Font.Size = 11;
                                    MSWTable.Cell(n_Rowcount, n_Colcount).Range.Font.Bold = 0;
                                    MSWTable.Cell(n_Rowcount, n_Colcount).Range.Font.ColorIndex = Microsoft.Office.Interop.Word.WdColorIndex.wdBlack;

                                    n_Colcount++;
                                }
                                n_Rowcount++;
                            }
                            #endregion
                            tempTable = MSWTable;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }

        #endregion

        #region Add Controls

        /// <summary>
        /// this method is used to get Bulleted List object
        /// </summary>
        /// <param name="s_Parameters">s_Parameters</param>
        /// <returns>returns Bulleted List object</returns>
        private BulletedList AddBulletedList(string s_Parameters)
        {
            using (BulletedList bulletedList = new BulletedList())
            {
                string[] Parameters = s_Parameters.Split('~');
                foreach (string item in Parameters)
                {
                    bulletedList.Items.Add(item);
                }
                return bulletedList;
            }
        }

        /// <summary>
        /// This method is used to get control object
        /// </summary>
        /// <param name="s_ControlName">s_ControlName</param>
        /// <param name="s_ControlID">s_ControlID</param>
        /// <param name="s_GrantRegID">s_GrantRegID</param>
        /// <param name="s_Tooltip">s_Tooltip</param>
        /// <param name="s_JavascriptMethodName">s_JavascriptMethodName</param>
        /// <param name="s_ControlText">s_ControlText</param>
        /// <param name="s_MARKET_PRICE_TYPE">s_MARKET_PRICE_TYPE</param>
        /// <param name="s_GrantOptionID">s_GrantOptionID</param>
        /// <param name="s_ReportingDate">s_ReportingDate</param>
        /// <param name="s_EmployeeID">s_EmployeeID</param>
        /// <param name="s_EmployeeName">s_EmployeeName</param>
        /// <param name="s_DateOfGrant">s_DateOfGrant</param>
        /// <param name="s_MP_Type">s_MP_Type</param>
        /// <returns>returns control object</returns>
        private Control AddControl(string s_ControlName, string s_ControlID, string s_GrantRegID, string s_Tooltip, string s_JavascriptMethodName, string s_ControlText, string s_MARKET_PRICE_TYPE, string s_GrantOptionID, string s_ReportingDate, string s_EmployeeID, string s_EmployeeName, string s_DateOfGrant, string s_MP_Type)
        {
            try
            {
                switch (s_ControlName)
                {
                    case "LinkButton":
                        switch (s_JavascriptMethodName)
                        {
                            case "ViewValuationParas":
                                using (LinkButton linkButton = new LinkButton())
                                {
                                    linkButton.ToolTip = s_Tooltip;
                                    linkButton.Text = s_ControlText;
                                    linkButton.ClientIDMode = ClientIDMode.Static;
                                    linkButton.ID = s_ControlID;
                                    linkButton.Attributes.Add("onclick", "return ViewValuationParas('" + s_GrantRegID + "')");
                                    return linkButton;
                                }

                            case "ViewGrantDetails":
                                using (LinkButton linkButton = new LinkButton())
                                {
                                    linkButton.ToolTip = s_Tooltip;
                                    linkButton.Text = s_ControlText;
                                    linkButton.ClientIDMode = ClientIDMode.Static;
                                    linkButton.ID = s_ControlID;
                                    linkButton.Attributes.Add("onclick", "return ViewGrantDetails('" + s_GrantRegID + "')");
                                    return linkButton;
                                }

                            case "ViewIVFVCalculations":
                                using (LinkButton linkButton = new LinkButton())
                                {
                                    linkButton.ToolTip = s_Tooltip;
                                    linkButton.Text = s_ControlText;
                                    linkButton.ClientIDMode = ClientIDMode.Static;
                                    linkButton.ID = s_ControlID;
                                    linkButton.Attributes.Add("onclick", "return ViewIVFVCalculations('" + s_GrantRegID + "','" + s_MP_Type + "')");
                                    return linkButton;
                                }

                            case "ViewIVFVCOPRPACT":
                                using (LinkButton linkButton = new LinkButton())
                                {
                                    linkButton.ToolTip = s_Tooltip;
                                    linkButton.Text = s_ControlText;
                                    linkButton.ClientIDMode = ClientIDMode.Static;
                                    linkButton.ID = s_ControlID;
                                    linkButton.Attributes.Add("onclick", "return ViewIVFVCOPRPACT('" + s_GrantRegID + "','" + s_MP_Type + "')");
                                    return linkButton;
                                }
                            case "ViewWorkings":
                                using (LinkButton linkButton = new LinkButton())
                                {
                                    linkButton.ToolTip = s_Tooltip;
                                    linkButton.Text = s_ControlText;
                                    linkButton.ClientIDMode = ClientIDMode.Static;
                                    linkButton.ID = s_ControlID;
                                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                                    {
                                        string S_QueryStr = Convert.ToString(genericServiceClient.EncryptString("RptID=13").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString(string.Format("MARKET_PRICE_TYPE={0}", s_MARKET_PRICE_TYPE)).Replace("+", "%2B") + "&" + genericServiceClient.EncryptString(string.Format("GRANT_OPTION_ID={0}", s_GrantOptionID)).Replace("+", "%2B") + "&" + genericServiceClient.EncryptString(string.Format("REPORTING_DATE={0}", s_ReportingDate)).Replace("+", "%2B") + "&" + genericServiceClient.EncryptString(string.Format("GRANT_REG_ID={0}", s_GrantRegID)).Replace("+", "%2B") + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_ID={0}", s_EmployeeID)).Replace("+", "%2B") + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_NAME={0}", s_EmployeeName)).Replace("+", "%2B") + "&" + genericServiceClient.EncryptString(string.Format("DATE_OF_GRANT={0}", s_DateOfGrant)).Replace("+", "%2B") + "&" + genericServiceClient.EncryptString(string.Format("IS_EMP_ACCESS={0}", (userSessionInfo.ACC_IsEmpAccess.Equals(true) ? "Y" : "N"))).Replace("+", "%2B"));
                                        linkButton.Attributes.Add("onclick", "return ViewWorkings('" + S_QueryStr + "')");
                                    }
                                    return linkButton;
                                }

                            case "ViewAcceleratedVesting":
                                using (LinkButton linkButton = new LinkButton())
                                {
                                    linkButton.ToolTip = s_Tooltip;
                                    linkButton.Text = s_ControlText;
                                    linkButton.ClientIDMode = ClientIDMode.Static;
                                    linkButton.ID = s_ControlID;

                                    linkButton.Attributes.Add("onclick", "return ViewAcceleratedVesting('" + s_MARKET_PRICE_TYPE + "', '" + s_ReportingDate + "')");
                                    return linkButton;
                                }
                        }
                        break;
                }
                return new Control();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This function is used to get link button object
        /// </summary>
        /// <param name="s_ControlText">s_ControlText</param>
        /// <param name="s_ControlTooltip">s_ControlTooltip</param>
        /// <param name="s_ControlID">s_ControlID</param>
        /// <param name="s_ACC_RPT_GROUP_ID">s_ACC_RPT_GROUP_ID</param>
        /// <param name="s_ReportName">s_ReportName</param>
        /// <param name="s_VersionNumber">s_VersionNumber</param>
        /// <param name="s_IsLocked">string s_IsLocked</param>
        ///  <param name="s_PendingParms">string s_PendingParms</param>
        ///  <param name="s_AccRoportDate">string s_AccRoportDate</param>
        /// <returns>return link button control object</returns>
        private LinkButton AddLinkButton(string s_ControlText, string s_ControlTooltip, string s_ControlID, string s_ACC_RPT_GROUP_ID, string s_ReportName, string s_VersionNumber, string s_IsLocked, string s_PendingParms, string s_AccRoportDate)
        {
            try
            {
                using (LinkButton linkButton = new LinkButton())
                {

                    linkButton.Attributes.Add("style", "cursor:pointer;padding:5px;color: blue; text-decoration: underline;");
                    linkButton.Text = s_ControlText;
                    linkButton.ClientIDMode = ClientIDMode.Static;
                    linkButton.ID = s_ControlID;
                    if (s_ControlID.Equals("lbtnAREditAndView"))
                        linkButton.ToolTip = "Click here to Edit." + Environment.NewLine + "Grant(s) : " + s_ControlTooltip;
                    else linkButton.ToolTip = s_ControlTooltip;
                    linkButton.Attributes.Add("onclick", "return OpenModalDialog('" + s_ControlText + "','" + s_ACC_RPT_GROUP_ID + "','" + s_ControlID + "','" + s_ReportName + "','" + s_VersionNumber + "','" + s_IsLocked + "','" + s_PendingParms + "','" + s_AccRoportDate + "')");
                    return linkButton;
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Row Bound of gv2 GridView

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="e">event args</param>
        internal void gv2_RowDataBound(GridViewRowEventArgs e)
        {
            try
            {
                string s_roundingLimit = string.Empty;
                using (System.Data.DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                {
                    for (int i = 0; i < e.Row.Cells.Count; i++)
                    {
                        s_roundingLimit = e.Row.Cells[0].Text.Contains("Intrinsic Value") ? "1" : e.Row.Cells[0].Text.Contains("Fair Value") ? "2" : e.Row.Cells[0].Text.Contains("Market Price") ? "3" : e.Row.Cells[0].Text.Contains("Exercise Price") ? "4" : e.Row.Cells[0].Text.Contains("Expected Life ") ? "5" : e.Row.Cells[0].Text.Contains("Volatility") ? "6" : e.Row.Cells[0].Text.Contains("Riskfree Rate") ? "7" : e.Row.Cells[0].Text.Contains("Dividend yield") ? "8" : "11";
                        e.Row.Cells[i].Text = e.Row.Cells[i].Text;
                        if (Convert.ToDouble(e.Row.Cells[i].Text) > 999)
                        {

                            e.Row.Cells[i].Text = CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[i].Text, DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Right;
                        }
                        else
                            e.Row.Cells[i].Text = CommonModel.GetRoundedValue(e.Row.Cells[i].Text, DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                        e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Right;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Get multiple accelerated data
        /// <summary>
        /// This method is used to get Accelerated Data
        /// </summary>
        /// <param name="s_VestingPeriodID">VestingPeriodID</param>
        /// <param name="s_ReportingDate">ReportingDate</param>
        public string GetAcceleratedData(string s_VestingPeriodID, string s_ReportingDate)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accountingProperties = new AccountingProperties();
                accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingProperties.PopulateControls = "GET_RPT_ACCELERATED_QTY";
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.ReportDate = Convert.ToDateTime(s_ReportingDate);
                accountingProperties.VPD_Vest_ID = Convert.ToInt32(s_VestingPeriodID);

                return DataTableToJSON(accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result);

            }
        }

        /// <summary>
        /// This method is used to Serialize Json object
        /// </summary>
        /// <param name="dt">Dataset used to </param>
        /// <returns>string</returns>
        private string DataTableToJSON(System.Data.DataTable dt)
        {
            JavaScriptSerializer json = new JavaScriptSerializer();
            Dictionary<string, object> dictionary = new Dictionary<string, object>();

            object[] arr = new object[dt.Rows.Count + 1];

            for (int i = 0; i <= dt.Rows.Count - 1; i++)
            {
                arr[i] = dt.Rows[i].ItemArray;
            }

            dictionary.Add(dt.TableName, arr);

            return json.Serialize(dictionary);
        }


        /// <summary>
        /// This method is used to Serialize Json object
        /// </summary>
        /// <param name="dt">Dataset object </param>
        /// <param name="s_CallFrom">s_CallFrom object</param>
        /// <returns>string</returns>
        private string DataConvertToJSON(System.Data.DataTable dt, string s_CallFrom)
        {
            JavaScriptSerializer json = new JavaScriptSerializer();
            Dictionary<string, object> dictionary = new Dictionary<string, object>();

            object[] arr = new object[dt.Rows.Count + 1];
            object[] Col_arr = new object[dt.Columns.Count + 1];
            switch (s_CallFrom)
            {
                case "IVORFV":
                    for (int j = dt.Columns.Count - 1; j >= 0; j--)
                    {
                        arr[0] = dt.Columns[j].ColumnName + "," + arr[0];
                    }

                    int k = 1;
                    for (int i = 0; i <= dt.Rows.Count - 1; i++)
                    {
                        arr[k] = dt.Rows[i].ItemArray;
                        k++;
                    }
                    break;

                case "CorpACTIVORFV":
                    for (int j = dt.Columns.Count - 1; j >= 0; j--)
                    {
                        arr[0] = dt.Columns[j].ColumnName + ";" + arr[0];
                    }

                    int l = 1;
                    for (int i = 0; i <= dt.Rows.Count - 1; i++)
                    {
                        arr[l] = dt.Rows[i].ItemArray;
                        l++;
                    }
                    break;
            }
            dictionary.Add(dt.TableName, arr);

            return json.Serialize(dictionary);
        }
        #endregion

        #region Get Customize view

        /// <summary>
        /// This method is used to load the default view for login user.
        /// </summary>
        /// <param name="accountingReport">accountingReport page object</param>
        internal void LoadDefault_ViewDropDowns(AccountingReport accountingReport)
        {
            try
            {
                bool is_RightsProvided = GetRolesFormDb(CommonConstantModel.s_AccountingDefaultView);
                System.Data.DataTable dt_TempDefaultView = new System.Data.DataTable();
                using (System.Data.DataTable dtDefaultView = CommonModel.GetDefaultViewList(userSessionInfo, CommonConstantModel.s_Get_Default_View, CommonConstantModel.s_AR_ViewPageName))
                {
                    if (!is_RightsProvided && dtDefaultView != null && dtDefaultView.Rows.Count > 0)
                    {
                        dt_TempDefaultView = dtDefaultView.Select("VIEW_NAME <> 'Default'").Count() > 0 ? dtDefaultView.Select("VIEW_NAME <> 'Default'").CopyToDataTable() : new System.Data.DataTable();
                    }
                    else
                    {
                        dt_TempDefaultView = dtDefaultView;
                    }
                    accountingReport.ddlDefaultView.DataSource = dt_TempDefaultView;
                    accountingReport.ddlDefaultView.DataTextField = "VIEW_NAME";
                    accountingReport.ddlDefaultView.DataValueField = "ID";
                    accountingReport.ddlDefaultView.DataBind();
                    accountingReport.ddlDefaultView.Items.Insert(0, new ListItem("--- Please Select ---", "0"));

                    if (dt_TempDefaultView.Rows.Count > 0)
                    {
                        if (accountingReport.ddlDefaultView.Items.Count > 0)
                        {
                            DataRow[] drr = dt_TempDefaultView.Select("ISDEFAULT_VIEW=1");

                            if (drr.Length > 0)
                            {
                                accountingReport.ddlDefaultView.SelectedValue = Convert.ToString(drr[0]["ID"]);
                                accountingReport.hdnDefaultViewValue.Value = Convert.ToString(drr[0]["ID"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to load the selected view for login user.
        /// </summary>
        /// <param name="accountingReport">accountingReport page object</param>
        internal void LoadSelcted_View(AccountingReport accountingReport)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.PageName = CommonConstantModel.s_MnuAccountingReport;
                    genericProperties.CustomizeView_ID = Convert.ToString(accountingReport.ddlDefaultView.SelectedValue);
                    genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_AccountingReport.dt_CustmizedViewAccounting = (System.Data.DataTable)genericServiceClient.GetCustomizedViewTable(genericProperties);
                }
                if (!accountingReport.hdnIsEdit.Value.Equals("Edit"))
                    btnARViewReport_Click(accountingReport, "SUMMARY");
                else
                    btnAREditAndView_Click(accountingReport, accountingReport.hdnARACC_RPT_GRP_ID.Value, "btnAREditAndView");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// This method is used to load the selected view for login user.
        /// </summary>
        /// <param name="accountingReport">accountingReport page object</param>
        internal void SetDefaultView(AccountingReport accountingReport)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = "SETDEFAULTVIEW";
                    accountingProperties.s_CustomizeViewPageName = CommonConstantModel.s_MnuAccountingReport;
                    accountingProperties.s_ViewID = Convert.ToString(accountingReport.ddlDefaultView.SelectedValue);
                    accountingProperties.IsDefault = true;

                    AccountingCRUDProperties accountingCRUDProperties = new AccountingCRUDProperties();
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            accountingReport.ctrSuccessErrorMessage.lblMessage.Text = accountingServiceClient.GetAccounting_L10N("lblEMError", CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10);
                            accountingReport.ctrSuccessErrorMessage.lblMessage.ForeColor = Color.Red;
                            break;

                        case 1:
                            accountingReport.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            accountingReport.ctrSuccessErrorMessage.lblMessage.Text = accountingServiceClient.GetAccounting_L10N("lblCustViewApplied", CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10);
                            accountingReport.ctrSuccessErrorMessage.lblMessage.ForeColor = Color.Blue;
                            break;
                    }

                }
                btnARViewReport_Click(accountingReport, string.Empty);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion


        /// <summary>
        /// This method is used to get IVFV details
        /// </summary>
        /// <param name="s_GrantRegID">s_GrantRegID object</param>
        /// <param name="s_MP_Type">s_MP_Type object</param>
        /// <returns></returns>
        internal string GetDetails(string s_GrantRegID, string s_MP_Type)
        {

            System.Data.DataTable dataTable = ac_AccountingReport.ds_ReportDetails.Tables[1].Select("[Grant Registration ID] = '" + s_GrantRegID + "'").CopyToDataTable();
            string s_Result = string.Empty;
            using (System.Data.DataTable outputTable = GetCalculationsIVnFV(ref dataTable, s_MP_Type, Convert.ToString(s_GrantRegID)))
            {
                outputTable.TableName = "dt_Price";

                outputTable.Rows.Add(ac_AccountingReport.s_FinalValue, ac_AccountingReport.s_FairValue, ac_AccountingReport.n_VestCount);

                s_Result = DataConvertToJSON(outputTable, "IVORFV");
            }
            return s_Result;
        }

        /// <summary>
        /// Method returns IV FV calculations
        /// </summary>
        /// <param name="dt_Details">dt_Details</param>
        /// <param name="s_Select">s_Select</param>
        /// <param name="o_GrantRegID">o_GrantRegID</param>
        /// <returns>returns IV FV calculations</returns>
        public System.Data.DataTable GetCalculationsIVnFV(ref System.Data.DataTable dt_Details, string s_Select, string o_GrantRegID)
        {
            try
            {
                using (DataView dataView = new DataView())
                {
                    string s_DecimalLimit = string.Empty;
                    string s_Currency = Convert.ToString(dt_Details.Rows[0]["Currency"]);
                    string s_GrantDate = "Date of Grant: " + Convert.ToDateTime(dt_Details.Rows[0]["Grant Date"]).ToString("dd/MMM/yyyy");
                    ac_AccountingReport.s_FairValue = dt_Details.Rows[0]["IV_FV"].ToString();
                    ac_AccountingReport.s_FinalValue = s_Select.Equals("FV") ? " Fair Value Per Option (" + s_Currency + ")" : "Final Intrinsic Value";
                    s_DecimalLimit = ac_AccountingReport.s_FinalValue.Contains("FV") ? "2" : "1";

                    using (System.Data.DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                    {
                        if (userSessionInfo.ACC_IsListed == 1 && Convert.ToDouble(ac_AccountingReport.s_FairValue) > 999)
                            ac_AccountingReport.s_FairValue = CommonModel.ThousandFormating(CommonModel.GetRoundedValue(ac_AccountingReport.s_FairValue, DecimalLimitTable.Select("ADVSID = '" + s_DecimalLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = '" + s_DecimalLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                        else
                            ac_AccountingReport.s_FairValue = CommonModel.GetRoundedValue(ac_AccountingReport.s_FairValue, DecimalLimitTable.Select("ADVSID = '" + s_DecimalLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                    }
                    System.Data.DataTable dataTable = ac_AccountingReport.dt_VestingDetails.Select("[Grant Registration ID] = '" + o_GrantRegID + "'").CopyToDataTable();
                    dt_Details = new DataView(dataTable).ToTable
                                    ("DT", false,
                                        s_Select.Equals("FV") ?
                                            new string[] { "Vesting Date", "Market Price Per Vest", "Expected Life Per Vest", "Volatility Per Vest", "RFIR Per Vest", "Exercise Price", "Dividend Per Vest", "Fair Value per vest", "Vest Percent (%)", "IS_MU_MKT_FV", "IS_MU_EXL", "IS_MU_VOL", "IS_MU_RFIR", "IS_MU_DIVD", "IS_MU_DIVD_MP_DIVD" } :
                                            new string[] { "Vesting Date", "Market Price IV", "Exercise Price", "Intrinsic Value per vest", "IS_MU_MKT_IV" }
                                    ).Copy();

                    using (System.Data.DataTable dt_outputTable = new System.Data.DataTable())
                    {
                        if (!s_Select.Equals("FV"))
                        {
                            dt_Details.Columns["Market Price IV"].ColumnName = "Market Price (A)";
                            dt_Details.Columns["Exercise Price"].ColumnName = "Exercise Price (B)";
                            dt_Details.Columns["Intrinsic Value per vest"].ColumnName = "Intrinsic Value (A-B)";
                        }
                        else
                        {
                            dt_Details.Columns["Market Price Per Vest"].ColumnName = "Market Price (" + s_Currency + ")";
                            dt_Details.Columns["Expected Life Per Vest"].ColumnName = "Expected Life";
                            dt_Details.Columns["Volatility Per Vest"].ColumnName = "Volatility (%)";
                            dt_Details.Columns["RFIR Per Vest"].ColumnName = "Riskfree Rate (%)";
                            dt_Details.Columns["Dividend Per Vest"].ColumnName = "Dividend yield (%)";
                            dt_Details.Columns["Exercise Price"].ColumnName = "Exercise Price (" + s_Currency + ")";
                            dt_Details.Columns["Fair Value per vest"].ColumnName = "Fair Value per vest (" + s_Currency + ")";
                        }

                        // Header row's first column is same as in inputTable
                        dt_outputTable.Columns.Add(dt_Details.Columns[0].ColumnName.ToString());

                        int i = 1;
                        foreach (DataRow perRow in dt_Details.Rows)
                        {
                            DataColumn dataColumn = new DataColumn("Vest " + i + ": " + Convert.ToString(perRow["Vesting Date"]), typeof(string));
                            dt_outputTable.Columns.Add(dataColumn);
                            i++;
                        }
                        dt_outputTable.Columns["Vesting Date"].ColumnName = s_GrantDate;
                        dt_outputTable.Columns.Add("Is_Manually_Updated", typeof(string));

                        for (int rCount = 1; rCount <= dt_Details.Columns.Count - 1; rCount++)
                        {
                            DataRow newRow = dt_outputTable.NewRow();

                            for (int cCount = 0; cCount <= dt_Details.Rows.Count - 1; cCount++)
                            {
                                newRow[0] = dt_Details.Columns[rCount].ColumnName.ToString();
                                newRow[cCount + 1] = (!string.IsNullOrEmpty(dt_Details.Rows[cCount][rCount].ToString())) ? dt_Details.Rows[cCount][rCount].ToString() : "0.00";
                            }
                            if (newRow[0].Equals("Dividend yield (%)") || newRow[0].Equals("Fair Value per vest (" + s_Currency + ")"))
                            {
                                dt_outputTable.Rows.Add(newRow);
                                dt_outputTable.Rows.Add(dt_outputTable.NewRow());
                            }
                            else
                            {
                                dt_outputTable.Rows.Add(newRow);

                                switch (dt_outputTable.Rows[dt_outputTable.Rows.Count - 1][0].ToString())
                                {
                                    case "IS_MU_MKT_FV":
                                        if (dt_Details.Rows[0]["IS_MU_MKT_FV"].ToString() == "True")
                                            dt_outputTable.Rows[0]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_MKT_IV":
                                        if (dt_Details.Rows[0]["IS_MU_MKT_IV"].ToString() == "True")
                                            dt_outputTable.Rows[0]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_EXL":
                                        if (dt_Details.Rows[0]["IS_MU_EXL"].ToString() == "True")
                                            dt_outputTable.Rows[1]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_VOL":
                                        if (dt_Details.Rows[0]["IS_MU_VOL"].ToString() == "True")
                                            dt_outputTable.Rows[2]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_RFIR":
                                        if (dt_Details.Rows[0]["IS_MU_RFIR"].ToString() == "True")
                                            dt_outputTable.Rows[3]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_DIVD":
                                        if (dt_Details.Rows[0]["IS_MU_DIVD"].ToString() == "True")
                                            dt_outputTable.Rows[5]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_DIVD_MP_DIVD":
                                        if (dt_Details.Rows[0]["IS_MU_DIVD_MP_DIVD"].ToString() == "True")
                                            dt_outputTable.Rows[5]["Is_Manually_Updated"] = "1";
                                        break;
                                }
                            }

                        }
                        dt_outputTable.AcceptChanges();
                        ac_AccountingReport.n_VestCount = dt_outputTable.Columns.Count;
                        ac_AccountingReport.n_RowCount = dt_outputTable.Rows.Count;
                        return dt_outputTable;
                    }
                }
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// This method is used to get the IV FV Details against Corporate Action aaplied.
        /// </summary>
        /// <param name="s_OPTVESTID">s_OPTVESTID object</param>
        /// <param name="s_MP_Type">s_MP_Type object</param>
        /// <returns></returns>
        internal string GetIVFVCORPDetails(string s_OPTVESTID, string s_MP_Type)
        {

            DataRow[] dr_Data = ac_AccountingReport.ds_ReportDetails.Tables[1].Select("[OPT_VEST_ID] = '" + s_OPTVESTID + "'");
            string s_Result = string.Empty;
            decimal d_OptionsCancelled = 0;
            using (System.Data.DataTable dt_CorpActFV = new System.Data.DataTable())
            {
                dt_CorpActFV.Columns.Add(" ", typeof(string));
                dt_CorpActFV.Columns.Add("Corporate Action", typeof(string));
                dt_CorpActFV.Columns.Add("Post-Corporate Action", typeof(string));

                d_OptionsCancelled = ((string.IsNullOrEmpty(dr_Data[0]["Options Vested Cancelled"].ToString()) || dr_Data[0]["Options Vested Cancelled"].ToString().Equals("&nbsp;") || (string.IsNullOrEmpty(dr_Data[0]["Options Unvested Cancelled"].ToString()) || dr_Data[0]["Options Unvested Cancelled"].ToString().Equals("&nbsp;"))) ? Convert.ToDecimal("0") : (Convert.ToDecimal(dr_Data[0]["Options Vested Cancelled"].ToString())) + (Convert.ToDecimal(dr_Data[0]["Options Unvested Cancelled"].ToString())));

                dt_CorpActFV.Rows.Add("Options Granted", string.IsNullOrEmpty(dr_Data[0]["Options Granted"].ToString()) || dr_Data[0]["Options Granted"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0").ToString() : Convert.ToDouble(Convert.ToDecimal(dr_Data[0]["Options Granted"].ToString())) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Convert.ToString(dr_Data[0]["Options Granted"].ToString()), "0"), "0") : CommonModel.GetRoundedValue(Convert.ToString(dr_Data[0]["Options Granted"]), "0"));
                dt_CorpActFV.Rows.Add("Options Cancelled", ((Convert.ToDouble(d_OptionsCancelled)) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Convert.ToString(d_OptionsCancelled), "0"), "0") : CommonModel.GetRoundedValue(Convert.ToString(d_OptionsCancelled), "0")));
                dt_CorpActFV.Rows.Add("Options Exercised", string.IsNullOrEmpty(dr_Data[0]["Exercised Options"].ToString()) || dr_Data[0]["Exercised Options"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0").ToString() : Convert.ToDouble(Convert.ToDecimal(dr_Data[0]["Exercised Options"].ToString())) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Convert.ToString(dr_Data[0]["Exercised Options"].ToString()), "0"), "0") : CommonModel.GetRoundedValue(Convert.ToString(dr_Data[0]["Exercised Options"]), "0"));
                dt_CorpActFV.Rows.Add("Options Lapsed", string.IsNullOrEmpty(dr_Data[0]["Options Lapsed"].ToString()) || dr_Data[0]["Options Lapsed"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0").ToString() : Convert.ToDouble(Convert.ToDecimal(dr_Data[0]["Options Lapsed"].ToString())) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Convert.ToString(dr_Data[0]["Options Lapsed"].ToString()), "0"), "0") : CommonModel.GetRoundedValue(Convert.ToString(dr_Data[0]["Options Lapsed"]), "0"));
                dt_CorpActFV.Rows.Add("Live Options for Compensation Cost", string.IsNullOrEmpty(dr_Data[0]["Live Options for Compensation Cost"].ToString()) || dr_Data[0]["Live Options for Compensation Cost"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0").ToString() : Convert.ToDouble(Convert.ToDecimal(dr_Data[0]["Live Options for Compensation Cost"].ToString())) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Convert.ToString(dr_Data[0]["Live Options for Compensation Cost"].ToString()), "0"), "0") : CommonModel.GetRoundedValue(Convert.ToString(dr_Data[0]["Live Options for Compensation Cost"]), "0"));

                using (System.Data.DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                {
                    ac_AccountingReport.s_CorpActFVIV = s_MP_Type.Equals("FV") ? "Fair Value" : "Intrinsic Value";
                    ac_AccountingReport.s_CorpActFVIVVal = string.IsNullOrEmpty(dr_Data[0]["IV_FV post Corporate Action / Modification / Change in estimated date of listing"].ToString()) || dr_Data[0]["IV_FV post Corporate Action / Modification / Change in estimated date of listing"].ToString().Equals("&nbsp;") ? "0" : Convert.ToDouble(Decimal.Round(Convert.ToDecimal(dr_Data[0]["IV_FV post Corporate Action / Modification / Change in estimated date of listing"].ToString()), 2)) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["IV_FV post Corporate Action / Modification / Change in estimated date of listing"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["IV_FV post Corporate Action / Modification / Change in estimated date of listing"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());

                    string s_ComCostPostCorpActByFVIV = s_MP_Type.Equals("FV") ? "Compensation Cost By Fair Value" : "Compensation Cost By Intrinsic Value";
                    string s_ComCostPostCorpActByFVIVVal = "0";

                    dt_CorpActFV.Rows.Add(ac_AccountingReport.s_CorpActFVIV, ac_AccountingReport.s_CorpActFVIVVal);
                    dt_CorpActFV.Rows.Add(s_ComCostPostCorpActByFVIV, s_ComCostPostCorpActByFVIVVal);
                }
                dt_CorpActFV.TableName = "dt_CorpAct";
                s_Result = DataConvertToJSON(dt_CorpActFV, "CorpACTIVORFV");
            }
            return s_Result;
        }

        /// <summary>
        /// SSRSReportScheduling
        /// </summary>
        /// <param name="s_Parameters">s_Parameters</param>
        /// <param name="s_CallFor">s_CallFor</param>
        /// <returns></returns>
        internal string SSRSReportScheduling(string s_Parameters, string s_CallFor)
        {
            string s_ReturnString = string.Empty, s_DisplayCostFor = string.Empty;
            try
            {
                Hashtable ht_ReportParameters = SetParameters(s_Parameters);
                switch (Convert.ToString(ht_ReportParameters["DISPLAY_COST_FOR"]).ToUpper())
                {
                    case "Y":
                        s_DisplayCostFor = "_Yearly";
                        break;

                    case "Q":
                        s_DisplayCostFor = "_Quarterly";
                        break;

                    case "M":
                        s_DisplayCostFor = "_Monthly";
                        break;
                }

                switch (s_CallFor)
                {
                    case "btnARWorkingDownload":
                        if (!File.Exists(ConfigurationManager.AppSettings["PhysicalFilePath"] + userSessionInfo.ACC_CompanyTitle + @"\" + userSessionInfo.ACC_CompanyTitle.Replace(" ", string.Empty) + "_" + Convert.ToDateTime(ht_ReportParameters["REPORTING_DATE"]).ToString("dd MMM yyyy") + s_DisplayCostFor + "_AccountingReport" + ".xlsx"))
                        {
                            using (SSRSReportSubscriptionDTO sSRSReportSubscriptionDTO = new SSRSReportSubscriptionDTO())
                            {
                                sSRSReportSubscriptionDTO.SSRSRdlName = "AccountingReport";
                                sSRSReportSubscriptionDTO.ScheduleDetails = "ONCE";
                                sSRSReportSubscriptionDTO.DownloadReportExcel = "EXCEL";
                                sSRSReportSubscriptionDTO.CompanyID = userSessionInfo.ACC_CompanyTitle;
                                sSRSReportSubscriptionDTO.ScheduleDate = Convert.ToString(DateTime.Now.AddMinutes(2));
                                sSRSReportSubscriptionDTO.ht_ReportParameters = ht_ReportParameters;
                                sSRSReportSubscriptionDTO.ReportName = ac_AccountingReport.s_ReportName = userSessionInfo.ACC_CompanyTitle.Replace(" ", string.Empty) + "_" + Convert.ToDateTime(sSRSReportSubscriptionDTO.ht_ReportParameters["REPORTING_DATE"]).ToString("dd MMM yyyy") + s_DisplayCostFor + "_AccountingReport";

                                SSRSReportSubscriptionLibrary.SSRSReportSubscriptionLibrary sSRSReportSubscriptionLibrary = new SSRSReportSubscriptionLibrary.SSRSReportSubscriptionLibrary();
                                string s_Result = sSRSReportSubscriptionLibrary.ReportSchSubscription(sSRSReportSubscriptionDTO);
                                //s_Result = "Y";
                                s_ReturnString = s_Result.Split('~').First().Equals("Y") ? "Success" : "Failure";

                                SaveSubscriptionID(sSRSReportSubscriptionDTO, s_Result);

                                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                                {
                                    string s_MailBody = MailBody("SSRSReportScheduled");
                                    emailProperties.s_MailFrom = ConfigurationManager.AppSettings["MailFrom"];
                                    emailProperties.b_IsBodyHtml = true;
                                    emailProperties.s_MailTo = userSessionInfo.ACC_EmailID;
                                    emailProperties.s_MailCC = string.Empty;
                                    emailProperties.s_MailBCC = string.Empty;
                                    emailProperties.s_MailSubject = s_Result.Split('~').First().Equals("Y") ? "Report Scheduled successfully" : "Error occurred while Report Scheduling <EOM>";
                                    emailProperties.s_MailBody = s_Result.Split('~').First().Equals("Y") ? s_MailBody : string.Empty;
                                    genericServiceClient.SaveSendMail(emailProperties);
                                }
                            }
                        }
                        else
                        {
                            s_ReturnString = "Exists";
                        }
                        break;
                    
                    case "btnARWDownloadNew":
                        if (File.Exists(ConfigurationManager.AppSettings["PhysicalFilePath"] + userSessionInfo.ACC_CompanyTitle + @"\" + userSessionInfo.ACC_CompanyTitle.Replace(" ", string.Empty) + "_" + Convert.ToDateTime(ht_ReportParameters["REPORTING_DATE"]).ToString("dd MMM yyyy") + s_DisplayCostFor + "_AccountingReport" + ".xlsx"))
                        {
                            File.Delete(((ConfigurationManager.AppSettings["PhysicalFilePath"] + userSessionInfo.ACC_CompanyTitle + @"\" + userSessionInfo.ACC_CompanyTitle.Replace(" ", string.Empty) + "_" + Convert.ToDateTime(ht_ReportParameters["REPORTING_DATE"]).ToString("dd MMM yyyy") + s_DisplayCostFor + "_AccountingReport" + ".xlsx")));
                        }
                        using (SSRSReportSubscriptionDTO sSRSReportSubscriptionDTO = new SSRSReportSubscriptionDTO())
                        {
                            sSRSReportSubscriptionDTO.SSRSRdlName = "AccountingReport";
                            sSRSReportSubscriptionDTO.ScheduleDetails = "ONCE";
                            sSRSReportSubscriptionDTO.DownloadReportExcel = "EXCEL";
                            sSRSReportSubscriptionDTO.CompanyID = userSessionInfo.ACC_CompanyTitle;
                            sSRSReportSubscriptionDTO.ScheduleDate = Convert.ToString(DateTime.Now.AddMinutes(2));
                            sSRSReportSubscriptionDTO.ht_ReportParameters = ht_ReportParameters;
                            sSRSReportSubscriptionDTO.ReportName = ac_AccountingReport.s_ReportName = userSessionInfo.ACC_CompanyTitle.Replace(" ", string.Empty) + "_" + Convert.ToDateTime(sSRSReportSubscriptionDTO.ht_ReportParameters["REPORTING_DATE"]).ToString("dd MMM yyyy") + s_DisplayCostFor + "_AccountingReport";

                            SSRSReportSubscriptionLibrary.SSRSReportSubscriptionLibrary sSRSReportSubscriptionLibrary = new SSRSReportSubscriptionLibrary.SSRSReportSubscriptionLibrary();
                            string s_Result = sSRSReportSubscriptionLibrary.ReportSchSubscription(sSRSReportSubscriptionDTO);

                            s_ReturnString = s_Result.Split('~').First().Equals("Y") ? "Success" : "Failure";

                            SaveSubscriptionID(sSRSReportSubscriptionDTO, s_Result);

                            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                            {
                                string s_MailBody = MailBody("SSRSReportScheduled");
                                emailProperties.s_MailFrom = ConfigurationManager.AppSettings["MailFrom"];
                                emailProperties.b_IsBodyHtml = true;
                                emailProperties.s_MailTo = userSessionInfo.ACC_EmailID;
                                emailProperties.s_MailCC = string.Empty;
                                emailProperties.s_MailBCC = string.Empty;
                                emailProperties.s_MailSubject = s_Result.Split('~').First().Equals("Y") ? "Report Scheduled successfully" : "Error occurred while Report Scheduling <EOM>";
                                emailProperties.s_MailBody = s_Result.Split('~').First().Equals("Y") ? s_MailBody : string.Empty;
                                genericServiceClient.SaveSendMail(emailProperties);
                            }
                        }
                        break;
                }
            }
            catch
            {
                s_ReturnString = "Failure";
            }

            return s_ReturnString;
        }

        /// <summary>
        /// Save SubscriptionID
        /// </summary>
        /// <param name="sSRSReportSubscriptionDTO">SSRSReportSubscriptionDTO</param>
        /// <param name="s_Result">s_Result</param>
        private void SaveSubscriptionID(SSRSReportSubscriptionDTO sSRSReportSubscriptionDTO, string s_Result)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accountingProperties.PageName = CommonConstantModel.s_ReportSubscription;
                accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                accountingProperties.Action = "C";
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.ReportDate = Convert.ToDateTime(sSRSReportSubscriptionDTO.ht_ReportParameters["REPORTING_DATE"]);
                accountingProperties.d_SCHEDULE_DATE = DateTime.Now.AddMinutes(2);
                accountingProperties.s_SCHEDULE_DETAILS = "ONCE";
                accountingProperties.s_SUBSCRIPTION_ID = s_Result.Split('~').Last();
                accountingProperties.s_REPORT_NAME = sSRSReportSubscriptionDTO.ReportName;
                accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                accountingProperties.s_DatabaseName = "Altomcredo";
                accountingServiceClient.CRUDAccountingOperations(accountingProperties);
            }
        }

        /// <summary>
        /// This method is used to replace parameters from template
        /// </summary>
        /// <param name="s_TemplateName">Template name</param>
        private string MailBody(string s_TemplateName)
        {
            StringBuilder s_MailBody = new StringBuilder();
            s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\" + s_TemplateName + ".html"));
            s_MailBody.Replace("@UserName", userSessionInfo.ACC_UserName);
            s_MailBody.Replace("@CompanyName", userSessionInfo.ACC_CompanyName);
            s_MailBody.Replace("@ReportDate", ac_AccountingReport.s_ReportName.Split('_')[1]);
            return s_MailBody.ToString();
        }

        /// <summary>
        /// SetParameters
        /// </summary>
        /// <param name="s_Parameters">s_Parameters</param>
        private Hashtable SetParameters(string s_Parameters)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                Hashtable ht_Paramrters = new Hashtable();
                ht_Paramrters["SERVER_NAME"] = ExtractConnectionStringFor("Data Source=");
                ht_Paramrters["DATABASE_NAME"] = userSessionInfo.ACC_CompanyName.ToString();

                foreach (string perQS in s_Parameters.Split('&'))
                {
                    string s_QueryString = genericServiceClient.DecryptString(perQS.Replace("%2B", "+"));
                    switch (s_QueryString.Split('=')[0].ToString().ToUpper())
                    {
                        case "REPORTING_DATE":
                            ht_Paramrters["REPORTING_DATE"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "MARKET_PRICE_TYPE":
                            ht_Paramrters["MARKET_PRICE_TYPE"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "SENIOR_MANAGEMENT":
                            ht_Paramrters["SENIOR_MANAGEMENT"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "GRANT_FROM_DATE":
                            ht_Paramrters["GRANT_FROM_DATE"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? null : s_QueryString.Split('=')[1];
                            break;

                        case "GRANT_TO_DATE":
                            ht_Paramrters["GRANT_TO_DATE"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? null : s_QueryString.Split('=')[1];
                            break;

                        case "DISPLAY_COST_FOR":
                            ht_Paramrters["DISPLAY_COST_FOR"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "COST_FOR_FYNC_YR_FROM":
                            ht_Paramrters["COST_FOR_FYNC_YR_FROM"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "COST_FOR_FYNC_YR_TO":
                            ht_Paramrters["COST_FOR_FYNC_YR_TO"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "COST_FOR_FYNC_QTR_FROM":
                            ht_Paramrters["COST_FOR_FYNC_QTR_FROM"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "COST_FOR_FYNC_QTR_TO":
                            ht_Paramrters["COST_FOR_FYNC_QTR_TO"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "COST_FOR_FYNC_MONTH_FROM":
                            ht_Paramrters["COST_FOR_FYNC_MONTH_FROM"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "COST_FOR_FYNC_MONTH_TO":
                            ht_Paramrters["COST_FOR_FYNC_MONTH_TO"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "ACC_RPT_GROUP_ID":
                            ht_Paramrters["ACC_RPT_GROUP_ID"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "VERSION_NUMBER":
                            ht_Paramrters["VERSION_NUMBER"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "CALCULATION_METHOD":
                            ht_Paramrters["CALCULATION_METHOD"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "DISPLAY_COST_BEFORE":
                            ht_Paramrters["DISPLAY_COST_BEFORE"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "DISPLAY_COST_AFTER":
                            ht_Paramrters["DISPLAY_COST_AFTER"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;

                        case "IS_EMP_ACCESS":
                            ht_Paramrters["IS_EMP_ACCESS"] = string.IsNullOrEmpty(s_QueryString.Split('=')[1]) ? string.Empty : s_QueryString.Split('=')[1];
                            break;
                    }
                }
                return ht_Paramrters;
            }
        }

        /// <summary>
        /// ExtractConnectionStringFor
        /// </summary>
        /// <param name="param">param</param>
        /// <returns>string</returns>
        private string ExtractConnectionStringFor(string param)
        {
            var result = string.Empty;

            foreach (var value in Convert.ToString(ConfigurationManager.ConnectionStrings[1].ConnectionString).Split(';').Where(value => value.Contains(param)))
            {
                result = value.Replace(param, string.Empty);
            }
            return result;
        }

        /// <summary>
        /// CheckReportGeneratedAndDownload
        /// </summary>
        /// <param name="accountingReport">accountingReport</param>
        internal void CheckReportGeneratedAndDownload(AccountingReport accountingReport)
        {
            try
            {
                if (File.Exists(ConfigurationManager.AppSettings["PhysicalFilePath"] + userSessionInfo.ACC_CompanyTitle + @"\" + userSessionInfo.ACC_CompanyTitle.Replace(" ", string.Empty) + "_" + (string.IsNullOrEmpty(accountingReport.txtARDate.Text) ? Convert.ToDateTime(ac_AccountingReport.s_Reporting_Date).ToString("dd MMM yyyy") : Convert.ToDateTime(accountingReport.txtARDate.Text).ToString("dd MMM yyyy")) + "_" + accountingReport.rdoARDisplayCostFor.SelectedItem.Text + "_AccountingReport" + ".xlsx"))
                {
                    ExportToZip(Convert.ToDateTime((string.IsNullOrEmpty(accountingReport.txtARDate.Text) ? ac_AccountingReport.s_Reporting_Date : accountingReport.txtARDate.Text)).ToString("dd MMM yyyy") + "_" + accountingReport.rdoARDisplayCostFor.SelectedItem.Text);
                    accountingReport.lblFileNotGenerated.Attributes.CssStyle.Add("Display", "none");

                }
                else
                {
                    accountingReport.lblFileNotGenerated.Attributes.CssStyle.Remove("Display");
                    accountingReport.lblReportSchSubscription.Attributes.CssStyle.Remove("Display");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// ExportToZip
        /// </summary>
        private void ExportToZip(string s_Date)
        {
            using (ZipFile zip = new ZipFile())
            {
                zip.AddFile(ConfigurationManager.AppSettings["PhysicalFilePath"] + userSessionInfo.ACC_CompanyTitle + @"\" + userSessionInfo.ACC_CompanyTitle.Replace(" ", string.Empty) + "_" + s_Date + "_AccountingReport" + ".xlsx", "Report");

                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.ClearContent();
                HttpContext.Current.Response.ClearHeaders();
                HttpContext.Current.Response.Buffer = true;
                HttpContext.Current.Response.BufferOutput = false;
                HttpContext.Current.Response.ContentType = "application/zip";

                HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=AccountingReport.zip");
                zip.Save(HttpContext.Current.Response.OutputStream);
                HttpContext.Current.Response.Flush();
                //Gets or sets a value indicating whether to send HTTP content to the client.
                HttpContext.Current.Response.SuppressContent = true;
                // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.  
                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~AccountingReportModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
        
    }
}