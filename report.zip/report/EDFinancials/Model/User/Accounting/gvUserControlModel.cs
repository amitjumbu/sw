﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting.UserControl;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// 
    /// </summary>
    public class gvUserControlModel : BaseModel, IDisposable
    {
        #region Default constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public gvUserControlModel()
        {
            if (ac_SearchGrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_SearchGrantDetails);
                ac_SearchGrantDetails = (CommonModel.AC_SearchGrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_SearchGrantDetails];
            }
        }
        #endregion

        /// <summary>
        /// Enables or disables control according to roles assigned to user.
        /// </summary>
        internal bool CheckEmployeeRolePriviledges()
        {
            try
            {
                bool EmpRoleStatus = false;
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuGrantDetails;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "EDIT":
                                    EmpRoleStatus = true;
                                    break;
                            }
                        }
                    }
                }
                return EmpRoleStatus;
            }
            catch
            {
                throw;
            }

        }

        #region ReSetVariables and ReadValuationReportUI
        /// <summary>
        /// This method is used to reset Variables
        /// </summary>
        /// <param name="uCGrantDetails">uCGrantDetails</param>
        internal void ReSetVariables(UCGrantDetails uCGrantDetails)
        {
            ac_SearchGrantDetails.n_VestCount = 0;
            ac_SearchGrantDetails.s_GrantID = string.Empty;
            ac_SearchGrantDetails.s_SelectedGrants = string.Empty;
            ac_SearchGrantDetails.s_StepNumber = "0";
            ac_SearchGrantDetails.n_RowCount = 0;
            ac_SearchGrantDetails.s_FairValue = string.Empty;
            ac_SearchGrantDetails.s_FinalValue = string.Empty;
            ac_SearchGrantDetails.s_GrantRegID = string.Empty;
            ac_SearchGrantDetails.s_CompareGrantID = string.Empty;
            ac_SearchGrantDetails.s_ChildPageName = string.Empty;
            ac_SearchGrantDetails.s_ModEDLset = string.Empty;

        }

        /// <summary>
        /// This Method is used to read Valuation Report page UI
        /// </summary>
        /// <param name="uCGrantDetails">UCGrantDetails page object</param>
        internal void ReadValuationReportUI(UCGrantDetails uCGrantDetails)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (DataTable dt_valuationL10N_UI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if ((dt_valuationL10N_UI != null) && (dt_valuationL10N_UI.Rows.Count > 0))
                        {
                            ac_SearchGrantDetails.dt_Valuation_Report_UI_Text = dt_valuationL10N_UI;

                            uCGrantDetails.btnVRProceed.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnVRProceed'"))[0]["LabelName"]);
                            uCGrantDetails.btnVRProceed.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnVRProceed'"))[0]["LabelToolTip"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region BindPageUI
        /// <summary>
        /// This method is used to bind UI label/button names
        /// </summary>
        /// <param name="uCGrantDetails">UCGrantDetails page object</param>
        /// <param name="s_PageName"></param>
        internal void BindPageUI(UCGrantDetails uCGrantDetails, string s_PageName)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (DataTable dt_GrantDetailUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if ((dt_GrantDetailUI != null) && (dt_GrantDetailUI.Rows.Count > 0))
                        {
                            uCGrantDetails.lblGDGrantID.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDGrantID'")[0]["LabelName"]);
                            uCGrantDetails.lblGDGrantID.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDGrantID'")[0]["LabelToolTip"]);
                            uCGrantDetails.lblGDSchemeName.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDSchemeName'")[0]["LabelName"]);
                            uCGrantDetails.lblGDSchemeName.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDSchemeName'")[0]["LabelToolTip"]);
                            uCGrantDetails.lblGDGrantFromDate.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDGrantFromDate'")[0]["LabelName"]);
                            uCGrantDetails.lblGDGrantFromDate.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDGrantFromDate'")[0]["LabelToolTip"]);
                            uCGrantDetails.lblGDGrantToDate.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDGrantToDate'")[0]["LabelName"]);
                            uCGrantDetails.lblGDGrantToDate.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDGrantToDate'")[0]["LabelToolTip"]);
                            uCGrantDetails.lblGDCurrency.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDCurrency'")[0]["LabelName"]);
                            uCGrantDetails.lblGDCurrency.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDCurrency'")[0]["LabelToolTip"]);
                            uCGrantDetails.lblGDExPriceRangeFrom.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDExPriceRangeFrom'")[0]["LabelName"]);
                            uCGrantDetails.lblGDExPriceRangeFrom.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDExPriceRangeFrom'")[0]["LabelToolTip"]);
                            uCGrantDetails.lblGDExPriceRangeTo.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDExPriceRangeTo'")[0]["LabelName"]);
                            uCGrantDetails.lblGDExPriceRangeTo.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDExPriceRangeTo'")[0]["LabelToolTip"]);
                            uCGrantDetails.lblVRGrpNumFrom.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblVRGrpNumFrom'")[0]["LabelName"]);
                            uCGrantDetails.lblVRGrpNumFrom.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblVRGrpNumFrom'")[0]["LabelToolTip"]);
                            uCGrantDetails.lblVRGrpNumTo.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblVRGrpNumTo'")[0]["LabelName"]);
                            uCGrantDetails.lblVRGrpNumTo.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblVRGrpNumTo'")[0]["LabelToolTip"]);
                            uCGrantDetails.lblGDFinancialYear.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDFinancialYear'")[0]["LabelName"]); ;
                            uCGrantDetails.ddlGDFinancialYear.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDFinancialYear'")[0]["LabelToolTip"]);

                            uCGrantDetails.lblGDCurrency.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDCurrency'")[0]["LabelName"]);


                            uCGrantDetails.lblGDReportStatus.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDReportStatus'")[0]["LabelName"]);
                            uCGrantDetails.lblGDReportStatus.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDReportStatus'")[0]["LabelToolTip"]);
                            uCGrantDetails.btnGDAddGrant.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnGDAddGrant'")[0]["LabelName"]);
                            uCGrantDetails.btnGDSearch.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnGDSearch'")[0]["LabelName"]);
                            uCGrantDetails.btnGDAddGrant.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnGDAddGrant'")[0]["LabelToolTip"]);
                            uCGrantDetails.btnGDSearch.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnGDSearch'")[0]["LabelToolTip"]);

                            uCGrantDetails.btnGDClearFilter.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnGDClearFilter'")[0]["LabelName"]);

                            uCGrantDetails.btnGDDelete.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnGDDelete'")[0]["LabelName"]);
                            uCGrantDetails.btnGDDelete.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnGDDelete'")[0]["LabelToolTip"]);

                            uCGrantDetails.btnAddOptionDetails.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddOptionDetails'")[0]["LabelName"]);
                            uCGrantDetails.btnAddOptionDetails.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddOptionDetails'")[0]["LabelToolTip"]);

                            uCGrantDetails.lblGrantCreatedOn.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGrantCreatedOn'")[0]["LabelName"]);
                            uCGrantDetails.lblGrantCreatedOn.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGrantCreatedOn'")[0]["LabelToolTip"]);

                            uCGrantDetails.lblSelectView.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblSelectView'")[0]["LabelName"]);
                            uCGrantDetails.lblSelectView.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblSelectView'")[0]["LabelToolTip"]);

                            uCGrantDetails.btnSetDefault.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnSetDefault'")[0]["LabelName"]);
                            uCGrantDetails.btnSetDefault.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnSetDefault'")[0]["LabelToolTip"]);

                            uCGrantDetails.lblLockedNote.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblLockedNote'")[0]["LabelName"]);
                            uCGrantDetails.lblLockedNote.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblLockedNote'")[0]["LabelToolTip"]);

                            uCGrantDetails.lblNote.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblNote'")[0]["LabelName"]);
                        }
                    }
                }
                uCGrantDetails.trExPriceRange.Visible = !s_PageName.Equals("ValuationReport");
                uCGrantDetails.trGroupNumber.Visible = s_PageName.Equals("ValuationReport");
            }
            catch
            {

                throw;
            }
        }
        #endregion

        #region BindGridView

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ucGrantDetails"></param>
        internal void BindPagerForGridView(UCGrantDetails ucGrantDetails)
        {
            //Populate pager for gridview control
            PopulatePagerForGridView(ucGrantDetails, ac_SearchGrantDetails.n_GridViewRecordsCount, 1, 1);
            PopulatePagerForGridView_Locked(ucGrantDetails, ac_SearchGrantDetails.n_GridViewRecordsCount_Locked, 1, 1);
        }

        /// <summary>
        /// Bind GridView
        /// </summary>
        /// <param name="ucGrantDetails">ucGrantDetails Page Object</param>
        /// <param name="s_PageName">Page Name</param>
        internal void BindGridView(UCGrantDetails ucGrantDetails, string s_PageName)
        {
            DataView view = null;
            DataTable dt_unlocked = null, dt_Locked = null;
            ucGrantDetails.btnVRProceed.Visible = false;

            try
            {
                BindGridFromDB(s_PageName, ucGrantDetails);

                GetCustomizeViewData(ucGrantDetails);

                if (ucGrantDetails.chkGDGrantID.Items.Cast<ListItem>().Count(li => li.Selected) <= 0 && ucGrantDetails.chkGDSchemeName.Items.Cast<ListItem>().Count(li => li.Selected) <= 0 && ucGrantDetails.chkGDCurrency.Items.Cast<ListItem>().Count(li => li.Selected) <= 0 && ucGrantDetails.chkGDReportStatus.Items.Cast<ListItem>().Count(li => li.Selected) <= 0)
                {
                    BindControls(ucGrantDetails, accountingCRUDProperties.ds_Result.Tables[0]);
                }

                view = new DataView(ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report);

                if (view.Count > 0)
                {
                    dt_unlocked = view.ToTable("DT", true, new string[] { "Action", "ID", "Grant Registration ID", "Grant Date", "Scheme Title", "Intrinsic Value", "Fair Value", "Currency", "Granted", "Cancelled", "Vested Cancelled", "Unvested Cancelled", "Lapsed", "Exercised", "Unvested", "Vested", "Outstanding", "Vesting Schedule", "Employee Details", "Grant Created on", "Actions", "AGRMID", "IS_MU_FV", "IS_MU_IV", "OPERATION_ID", "Status" }).Copy();
                    dt_unlocked.Columns.Remove("OPERATION_ID");
                    ucGrantDetails.btnVRProceed.Visible = true;
                    ucGrantDetails.gv.DataSource = dt_unlocked;
                    ucGrantDetails.gv.DataBind();
                }
                else
                {
                    ucGrantDetails.btnVRProceed.Visible = false;
                    ucGrantDetails.gv.DataSource = ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report;
                    ucGrantDetails.gv.DataBind();
                }

                view = new DataView(ac_SearchGrantDetails.dt_temp_Locked_Valuation_Report);

                if (view.Count > 0)
                {
                    dt_Locked = view.ToTable("DT", true, new string[] { "Action", "ID", "Grant Registration ID", "Grant Date", "Scheme Title", "Intrinsic Value", "Fair Value", "Currency", "Granted", "Cancelled", "Vested Cancelled", "Unvested Cancelled", "Lapsed", "Exercised", "Unvested", "Vested", "Outstanding", "Vesting Schedule", "Employee Details", "Grant Created on", "Actions", "AGRMID", "IS_MU_FV", "IS_MU_IV", "OPERATION_ID", "Status" }).Copy();
                    dt_Locked.Columns.Remove("OPERATION_ID");
                    ucGrantDetails.gvLockedRecords.DataSource = dt_Locked;
                    ucGrantDetails.gvLockedRecords.DataBind();
                }


                ucGrantDetails.chkGDReportStatus.Items.Clear();

                if (ucGrantDetails.gv.Rows.Count > 0)
                {
                    //Bind Status drop-down 
                    ucGrantDetails.chkGDReportStatus.DataSource = (from b in ac_SearchGrantDetails.dt_ReportStatus.AsEnumerable()
                                                                   where b.Field<string>("Status") != null
                                                                   select b.Field<string>("Status")).Distinct();
                    ucGrantDetails.chkGDReportStatus.DataBind();
                }
                ucGrantDetails.chkGDReportStatus.Items.Insert(0, "--- Select All ---");
                ac_SearchGrantDetails.dt_ReportStatus = null;
            }
            catch
            {
                throw;
            }
            finally
            {
                if (view.Count > 0)
                {
                    view.Dispose();
                }

                if (dt_Locked != null)
                {
                    dt_Locked.Dispose();
                }

                if (dt_unlocked != null)
                {
                    dt_unlocked.Dispose();
                }
            }
        }

        /// <summary>
        /// This method will fetch all grants data from database		
        /// </summary>
        /// <param name="s_PageName">Page Name</param>
        /// <param name="ucGrantDetails">ucGrantDetails</param>
        private void BindGridFromDB(string s_PageName, UCGrantDetails ucGrantDetails = null)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accountingProperties.PageName = CommonConstantModel.s_ValuationReport;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                accountingProperties.PAGE_INDEX = ac_SearchGrantDetails.n_PageIndex.Equals(0) ? 1 : ac_SearchGrantDetails.n_PageIndex;
                accountingProperties.PAGE_SIZE = ac_SearchGrantDetails.n_PageSize.Equals(0) ? 10 : ac_SearchGrantDetails.n_PageSize;
                accountingProperties.PAGE_INDEX_LOCKED = ac_SearchGrantDetails.n_PageIndex_Locked.Equals(0) ? 1 : ac_SearchGrantDetails.n_PageIndex_Locked;
                accountingProperties.PAGE_SIZE_LOCKED = ac_SearchGrantDetails.n_PageSize_Locked.Equals(0) ? 10 : ac_SearchGrantDetails.n_PageSize_Locked;
                accountingProperties.GET_DATA_TYPE = "GRANTWISE";
                accountingProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;
                accountingProperties.SEN_IsMYESOPsClient = userSessionInfo.ACC_IsMYESOPsClient;
                accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.SEN_CompanyTitle = userSessionInfo.ACC_CompanyTitle;
                accountingProperties.Operation_Param = s_PageName.Equals(CommonConstantModel.s_GrantDetails) ? CommonConstantModel.s_GrantDetails : string.Empty;

                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                ac_SearchGrantDetails.n_GridViewRecordsCount = Convert.ToInt16(Convert.ToString(accountingCRUDProperties.ds_Result.Tables[2].Rows[0]["TOTAL_ROW_COUNT"]));
                ac_SearchGrantDetails.n_GridViewRecordsCount_Locked = Convert.ToInt16(Convert.ToString(accountingCRUDProperties.ds_Result.Tables[3].Rows[0]["TOTAL_ROW_COUNT_LOCKED"]));
                ac_SearchGrantDetails.dt_all_Grants = accountingCRUDProperties.ds_Result.Tables[0];
                ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report = ac_SearchGrantDetails.dt_main_Unlocked_Valuation_Report = accountingCRUDProperties.ds_Result.Tables[0];
                ac_SearchGrantDetails.dt_temp_Locked_Valuation_Report = ac_SearchGrantDetails.dt_main_Locked_Valuation_Report = accountingCRUDProperties.ds_Result.Tables[1];
                ac_SearchGrantDetails.s_LatestOperationDate = accountingCRUDProperties.ds_Result.Tables[5] != null && accountingCRUDProperties.ds_Result.Tables[5].Rows.Count > 0 ? Convert.ToString(accountingCRUDProperties.ds_Result.Tables[5].Rows[0]["Latest Operation Date"]) : string.Empty;

                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.ac_GrantDetails.dt_GetGrantDetails = ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report;
                }

                if (!string.IsNullOrEmpty(ucGrantDetails.hdnSelectedGrants.Value))
                {
                    var s_AGRMID = string.Join(",", ucGrantDetails.hdnSelectedGrants.Value.TrimStart(',').Split(',').Select(x => x.Insert(0, "'") + "'").ToArray());
                    foreach (string perItem in ucGrantDetails.hdnSelectedGrants.Value.TrimStart(',').Split(','))
                    {
                        if (ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report.Select("ID = '" + perItem + "'").Count() > 0)
                        {
                            ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report.Select("ID = '" + perItem + "'")[0]["Action"] = "Delete";
                        }
                    }
                }
                else
                {
                    ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report.Columns["Action"].Expression = string.Empty;
                }
            }
        }
        #endregion

        #region Bind Controls
        /// <summary>
        /// This method is used to Bind Data to dropdowns/checkboxlist
        /// </summary>
        /// <param name="ucGrantDetails">ucGrantDetails</param>
        /// <param name="dt_LockedUnlocked">Datatable of Locked and Unlocked Grant(s)</param>
        private void BindControls(UCGrantDetails ucGrantDetails, DataTable dt_LockedUnlocked)
        {            
            try
            {
                using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                {
                    if (dt_LockedUnlocked != null && dt_LockedUnlocked.Rows.Count > 0)
                    {
                        //Bind Scheme Name drop-down 
                        ucGrantDetails.chkGDSchemeName.DataSource = (from b in dt_LockedUnlocked.AsEnumerable()
                                                                     where b.Field<string>("Scheme Title") != null
                                                                     select b.Field<string>("Scheme Title")).Distinct();
                        ucGrantDetails.chkGDSchemeName.DataBind();

                        //Bind GrantID drop-down 
                        ucGrantDetails.chkGDGrantID.DataSource = (from b in dt_LockedUnlocked.AsEnumerable()
                                                                  where b.Field<string>("Grant Registration ID") != null
                                                                  select b.Field<string>("Grant Registration ID")).Distinct();
                        ucGrantDetails.chkGDGrantID.DataBind();

                        //Bind Currency drop-down 
                        ucGrantDetails.chkGDCurrency.DataSource = (from b in dt_LockedUnlocked.AsEnumerable()
                                                                   where b.Field<string>("Currency") != null
                                                                   select b.Field<string>("Currency")).Distinct();
                        ucGrantDetails.chkGDCurrency.DataBind();

                        //Bind Grant Created on drop-down 
                        ucGrantDetails.chkGrantCreatedOn.DataSource = (from b in dt_LockedUnlocked.AsEnumerable()
                                                                       where b.Field<string>("Grant Created On") != null
                                                                       select b.Field<string>("Grant Created On")).Distinct();
                        ucGrantDetails.chkGrantCreatedOn.DataBind();
                    }
                                       
                        ucGrantDetails.chkGDSchemeName.Items.Insert(0, "--- Select All ---");
                        ucGrantDetails.chkGDGrantID.Items.Insert(0, "--- Select All ---");
                        ucGrantDetails.chkGDCurrency.Items.Insert(0, "--- Select All ---");
                        ucGrantDetails.chkGrantCreatedOn.Items.Insert(0, "--- Select All ---");                    
                    
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Download File
        /// <summary>
        /// This Method is used to Download the File
        /// </summary>
        /// <param name="uCGrantDetails">uCGrantDetails</param>
        internal void DownloadFile(UCGrantDetails uCGrantDetails)
        {
            try
            {
                using (WebClient o_WebClient = new WebClient())
                {
                    HttpResponse o_HttpResponse = HttpContext.Current.Response;
                    o_HttpResponse.Clear();
                    o_HttpResponse.ClearContent();
                    o_HttpResponse.ClearHeaders();
                    o_HttpResponse.Buffer = true;
                    uCGrantDetails.Response.AddHeader("Content-Disposition", "attachment;filename='" + uCGrantDetails.hdnFileName.Value + "'");
                    o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(uCGrantDetails.hdnFileServerPath.Value.Replace("~", "\\")));
                    // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.Flush();
                    // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.Response.SuppressContent = true;
                    // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch
            {
                // Do Nothing
            }
        }
        #endregion

        #region Pivot DataTable
        /// <summary>
        /// This method is used to Pivot DataTable
        /// </summary>
        /// <param name="s_Select">string s_Select</param>
        /// <param name="uCGrantDetails">this is uCGrantDetails page object</param>
        public void PivotTable(string s_Select, UCGrantDetails uCGrantDetails)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    if (o_gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0)
                    {
                        using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                        {
                            accountingProperties.PageName = CommonConstantModel.s_ValuationReport;
                            accountingProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                            accountingProperties.Grant_ID = uCGrantDetails.hdnGrantID.Value;
                            accountingProperties.GET_DATA_TYPE = "VESTWISE";

                            accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                            DataTable dataTable = accountingCRUDProperties.ds_Result.Tables[0];

                            using (GetValuationParameters getValuationParameters = new GetValuationParameters())
                            {
                                using (DataTable outputTable = getValuationParameters.GetCalculationsIVnFV(ref dataTable, s_Select))
                                {
                                    uCGrantDetails.lblViewDocument.Text = s_Select.Equals("FairValue") ? Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblFairValueDetails'"))[0]["LabelName"]) :
                                                                                  Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblIntrinsicValueDetails'"))[0]["LabelName"]);


                                    uCGrantDetails.gv2.Visible = true;
                                    uCGrantDetails.gvValuationParameters.Visible = false;
                                    uCGrantDetails.lblNote.Visible = false;
                                    uCGrantDetails.lblManuallyEntered.Visible = false;
                                    uCGrantDetails.lblDiffrentThanCompLevel.Visible = false;

                                    uCGrantDetails.gv2.DataSource = outputTable;
                                    uCGrantDetails.gv2.DataBind();

                                    o_gvUserControlModel.ac_SearchGrantDetails.s_StepNumber = "0";
                                    uCGrantDetails.hdnShowGrid.Value = "1";
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Goto Step on Valuation Report Page
        /// <summary>
        /// Goto Step Number
        /// </summary>
        /// <param name="uCGrantDetails">UCGrantDetails page object</param>
        /// <param name="s_PageName"></param>
        public void GotoStep(UCGrantDetails uCGrantDetails, string s_PageName)
        {
            try
            {
                switch (uCGrantDetails.hdnGDStepNumber.Value)
                {
                    case "Select Grant":
                        ac_SearchGrantDetails.s_StepNumber = "0";
                        break;

                    case "Compare Grant":
                        ac_SearchGrantDetails.s_StepNumber = "1";
                        break;

                    case "Select Template":
                        ac_SearchGrantDetails.s_StepNumber = "2";
                        break;

                    case "Download and Send for Review":
                        ac_SearchGrantDetails.s_StepNumber = "3";
                        break;

                    case "Reviewer Feedback":
                        ac_SearchGrantDetails.s_StepNumber = userSessionInfo.ACC_UerTypeID.Equals(5) ? "4" : "3";
                        break;

                    case "Final Report":
                        ac_SearchGrantDetails.s_StepNumber = "5";
                        break;

                    case "Locked":
                        ac_SearchGrantDetails.s_StepNumber = "5";
                        break;
                }


                Int32[] n_GroupId = ac_SearchGrantDetails.dt_all_Grants.AsEnumerable()
                                    .Where(s => s.Field<string>("Status") == uCGrantDetails.hdnGDStepNumber.Value && s.Field<string>("Grant Registration ID") == uCGrantDetails.hdnGrantID.Value)
                                    .Select(s => s.Field<Int32>("Group Number"))
                                    .ToArray();
                Int32[] n_SelectedGrants = ac_SearchGrantDetails.dt_all_Grants.AsEnumerable()
                                                .Where(s => s.Field<Int32>("Group Number") == n_GroupId[0])
                                                .Select(s => s.Field<Int32>("AGRMID")).Distinct()
                                                .ToArray();
                ac_SearchGrantDetails.s_SelectedGrants = string.Join(",", n_SelectedGrants);



                if (s_PageName.Equals("GrantDetails"))
                    uCGrantDetails.Session["StepNumber"] = "set";
                else
                    uCGrantDetails.Session["StepNumber"] = "";
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Add Grid within Grid
        /// <summary>
        /// this method is used to add child grid
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">evwent arguement</param>
        /// <param name="b_IsLocked">bool lock status</param>
        /// <param name="GrantID">this is grant Id</param>
        /// <param name="n_VestIndex">this is  vest index number</param>
        /// <param name="n_VestID">this is  this vest id</param>
        /// <param name="n_VestDelete">this has vest id to be deleted</param>
        /// <param name="n_VestAction">vesting action to be performed</param>
        /// <param name="n_VestGrantDate">this is vest grant date></param>
        /// <param name="rowIndex">this is row index</param>
        /// <param name="s_PageName"></param>
        /// <param name="ucGrantDetails"></param>
        public void AddChildGrid(object sender, GridViewRowEventArgs e, bool b_IsLocked, string GrantID, ref int n_VestIndex, ref int n_VestID, ref int n_VestDelete, ref int n_VestAction, ref int n_VestGrantDate, ref int rowIndex, UCGrantDetails ucGrantDetails, string s_PageName)
        {
            try
            {
                GridView parentGrid = (GridView)sender;

                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                {
                    NewTotalRow.Font.Bold = true;
                    NewTotalRow.CssClass = "gridItems  gvChildGrid";
                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                    using (TableCell HeaderCell = new TableCell())
                    {
                        HeaderCell.Attributes.Add("Class", "gvChildGrid");
                        HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        HeaderCell.Height = 10;
                        HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                        HeaderCell.ColumnSpan = s_PageName.Equals("ValuationReport") ? 9 : 12;

                        System.Web.UI.HtmlControls.HtmlGenericControl div = new System.Web.UI.HtmlControls.HtmlGenericControl("div");
                        div.ID = "div_" + GrantID.Replace(" ", "").Replace("  ", "").Replace("(", "_00_").Replace(")", "_000_");
                        HeaderCell.Controls.Add(div);
                        NewTotalRow.Cells.Add(HeaderCell);
                        parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + rowIndex, NewTotalRow);
                        rowIndex++;

                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Bind/Hide rows into GridView gv and page index changed event
        /// <summary>
        /// this method binds row to gridview
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="ucGrantDetails">ucGrantDetails user control object</param>
        /// <param name="e">event arguement</param>
        /// <param name="n_index">int index number</param>
        /// <param name="n_ID">int Id</param>
        /// <param name="n_Delete">int Delete column number</param>
        /// <param name="n_Action">Action to be performed</param>
        /// <param name="n_GrantDate">Grant date in string format</param>
        /// <param name="n_FairValue">int Fair value variable</param>
        /// <param name="n_IntrinsicValue">int Intrinsic value variable</param>
        /// <param name="n_DocumentDownload">int DocumnetDownload variable</param>
        /// <param name="n_DocumentName">int n_DocumentName id</param>
        /// <param name="n_DocumentPath">int document path id</param>
        /// <param name="n_Status">int status id</param>
        /// <param name="n_Actions">int Action tio be performed</param>
        /// <param name="n_AGRMID">int AGRMID</param>
        /// <param name="s_PageName">string pageName</param>
        /// <param name="b_IsLocked">bool lock status</param>
        /// <param name="n_GrantID">int grand Id</param>
        /// <param name="n_GrpNum">int n_GrpNum</param>
        /// <param name="n_IsMUFV">int n_IsMUFV</param>
        /// <param name="n_IsMUIV">int n_IsMUIV</param>
        /// <param name="n_ExerPrice">int Exercise price</param>
        /// <param name="n_OptionsGranted">int Granted Options</param>
        /// <param name="n_OptionsCancelled">int Cancelled Options</param>
        /// <param name="n_VestedOptions">int Vested Options</param>
        /// <param name="n_OutstandingOptions">int Outstanding Options</param>
        /// <param name="n_EmployeeDetails">int Employee Details</param>
        /// <param name="n_VestedCancelled">int VestedCancelled</param>
        /// <param name="n_UnestedCancelled">int UnestedCancelled</param>
        /// <param name="n_Lapsed">int Lapsed</param>
        /// <param name="n_Exercised">int Exercised</param>
        /// <param name="n_Unvested">int Unvested</param>
        public void BindRows(object sender, View.User.Accounting.UserControl.UCGrantDetails ucGrantDetails, GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action, ref int n_GrantDate, ref int n_FairValue, ref int n_IntrinsicValue, ref int n_DocumentDownload, ref int n_DocumentName, ref int n_DocumentPath, ref int n_Status, ref int n_Actions, ref int n_AGRMID, string s_PageName, bool b_IsLocked, ref int n_GrantID, ref int n_GrpNum, ref int n_IsMUFV, ref int n_IsMUIV, ref int n_ExerPrice, ref int n_OptionsGranted, ref int n_OptionsCancelled, ref int n_VestedOptions, ref int n_OutstandingOptions, ref int n_EmployeeDetails, ref int n_VestedCancelled, ref int n_UnestedCancelled, ref int n_Lapsed, ref int n_Exercised, ref int n_Unvested)
        {
            try
            {
                bool b_IsRowExists = IsNullOrEmptyDataTable();
                int n_RowCount = 0;
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "GRANT REGISTRATION ID":
                                    n_GrantID = n_index;
                                    n_RowCount = CheckDataTableCount("GRS_GRANT_REGISTRATION_ID");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "GRANT DATE":
                                    n_GrantDate = n_index;
                                    n_RowCount = CheckDataTableCount("GRS_GRANT_DATE");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'GRS_GRANT_DATE'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'GRS_GRANT_DATE'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "VESTING SCHEDULE":
                                    n_Delete = n_index;
                                    break;

                                case "FAIR VALUE":
                                    n_FairValue = n_index;
                                    n_RowCount = CheckDataTableCount("OPTION_FAIR_VALUE");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'OPTION_FAIR_VALUE'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'OPTION_FAIR_VALUE'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "INTRINSIC VALUE":
                                    n_IntrinsicValue = n_index;
                                    n_RowCount = CheckDataTableCount("OPTION_INTRINSIC_VALUE");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'OPTION_INTRINSIC_VALUE'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'OPTION_INTRINSIC_VALUE'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "DOCUMENT UPLOADED":
                                    n_DocumentDownload = n_index;
                                    perColumn.Visible = !s_PageName.Equals("ValuationReport");
                                    break;

                                case "DOCUMENT NAME":
                                    n_DocumentName = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DOCUMENT PATH":
                                    n_DocumentPath = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    perColumn.Visible = b_IsLocked.Equals(false);

                                    if (Convert.ToString(((GridView)sender).ID) == "gv")
                                    {
                                        switch (s_PageName.ToUpper())
                                        {
                                            case "VALUATIONREPORT":
                                                e.Row.Cells[n_Action].Controls.Add(AddControl(ucGrantDetails, "CheckBox", "chk", "", "Click here to check all", "", "SelectAllCheckBoxes", "", "", "", string.Empty, "", string.Empty, string.Empty));
                                                break;

                                            case "GRANTDETAILS":
                                                e.Row.Cells[n_Action].Controls.Add(AddControl(ucGrantDetails, "CheckBox", "chk", "", "Click here to check all", "", "SelectAllCheckBoxesRecords", "", "", "", string.Empty, "", string.Empty, string.Empty));
                                                break;
                                        }
                                    }
                                    else
                                    {
                                        perColumn.Visible = false;
                                    }
                                    break;

                                case "STATUS":
                                    n_Status = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTIONS":
                                    n_Actions = n_index;
                                    perColumn.Visible = !s_PageName.Equals("ValuationReport") && Convert.ToString(((GridView)sender).ID) == "gv" ? true : false;
                                    break;

                                case "AGRMID":
                                    n_AGRMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "GROUP NUMBER":
                                    n_GrpNum = n_index;
                                    perColumn.Visible = s_PageName.Equals("ValuationReport");
                                    break;

                                case "IS_MU_FV":
                                    n_IsMUFV = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "IS_MU_IV":
                                    n_IsMUIV = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "EXERCISE PRICE":
                                    n_ExerPrice = n_index;
                                    break;

                                case "GRANTED":
                                    n_OptionsGranted = n_index;
                                    n_RowCount = CheckDataTableCount("GRANTED_OPTIONS");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'GRANTED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'GRANTED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "VESTED CANCELLED":
                                    n_VestedCancelled = n_index;
                                    n_RowCount = CheckDataTableCount("VESTED_CANCELLED_OPTIONS");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "UNVESTED CANCELLED":
                                    n_UnestedCancelled = n_index;
                                    n_RowCount = CheckDataTableCount("UNVESTED_CANCELLED_OPTIONS");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "LAPSED":
                                    n_Lapsed = n_index;
                                    n_RowCount = CheckDataTableCount("LAPSED_OPTIONS");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'LAPSED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'LAPSED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "EXERCISED":
                                    n_Exercised = n_index;
                                    n_RowCount = CheckDataTableCount("EXERCISED_OPTIONS");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "UNVESTED":
                                    n_Unvested = n_index;
                                    n_RowCount = CheckDataTableCount("UNVESTED_OPTIONS");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'UNVESTED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'UNVESTED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "CANCELLED":
                                    n_OptionsCancelled = n_index;
                                    n_RowCount = CheckDataTableCount("CANCELLED_OPTIONS");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'CANCELLED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'CANCELLED_OPTIONS'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "VESTED":
                                    n_VestedOptions = n_index;
                                    n_RowCount = CheckDataTableCount("VESTED_AND_EXERCISABLE");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'VESTED_AND_EXERCISABLE'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'VESTED_AND_EXERCISABLE'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "OUTSTANDING":
                                    n_OutstandingOptions = n_index;
                                    n_RowCount = CheckDataTableCount("OUTSTANDING_OPTIONS");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "EMPLOYEE DETAILS":
                                    n_EmployeeDetails = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!e.Row.Cells[n_FairValue].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_FairValue].Text = Convert.ToDouble(e.Row.Cells[n_FairValue].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_FairValue].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_FairValue].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_FairValue].HorizontalAlign = HorizontalAlign.Right;
                            }

                            if (!e.Row.Cells[n_IntrinsicValue].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_IntrinsicValue].Text = Convert.ToDouble(e.Row.Cells[n_IntrinsicValue].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_IntrinsicValue].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_IntrinsicValue].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_IntrinsicValue].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_ExerPrice].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_ExerPrice].Text = Convert.ToDouble(e.Row.Cells[n_ExerPrice].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_ExerPrice].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_ExerPrice].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_ExerPrice].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_OptionsGranted].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_OptionsGranted].Text = Convert.ToDouble(e.Row.Cells[n_OptionsGranted].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_OptionsGranted].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_OptionsGranted].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_OptionsGranted].HorizontalAlign = HorizontalAlign.Right;
                            }

                            if (!e.Row.Cells[n_OptionsCancelled].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_OptionsCancelled].Text = Convert.ToDouble(e.Row.Cells[n_OptionsCancelled].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_OptionsCancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_OptionsCancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_OptionsCancelled].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_VestedCancelled].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_VestedCancelled].Text = Convert.ToDouble(e.Row.Cells[n_VestedCancelled].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_VestedCancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_VestedCancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_VestedCancelled].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_UnestedCancelled].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_UnestedCancelled].Text = Convert.ToDouble(e.Row.Cells[n_UnestedCancelled].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_UnestedCancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_UnestedCancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_UnestedCancelled].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_Lapsed].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_Lapsed].Text = Convert.ToDouble(e.Row.Cells[n_Lapsed].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Lapsed].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Lapsed].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_Lapsed].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_Exercised].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_Exercised].Text = Convert.ToDouble(e.Row.Cells[n_Exercised].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Exercised].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Exercised].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_Exercised].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_Unvested].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_Unvested].Text = Convert.ToDouble(e.Row.Cells[n_Unvested].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Unvested].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Unvested].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_Unvested].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_VestedOptions].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_VestedOptions].Text = Convert.ToDouble(e.Row.Cells[n_VestedOptions].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_VestedOptions].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_VestedOptions].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_VestedOptions].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_OutstandingOptions].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_OutstandingOptions].Text = Convert.ToDouble(e.Row.Cells[n_OutstandingOptions].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_OutstandingOptions].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_OutstandingOptions].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_OutstandingOptions].HorizontalAlign = HorizontalAlign.Right;
                            }
                        }
                        #endregion

                        n_RowCount = CheckDataTableCount("GRS_GRANT_REGISTRATION_ID");
                        e.Row.Cells[n_GrantID].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("GRS_GRANT_DATE");
                        e.Row.Cells[n_GrantDate].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("OPTION_FAIR_VALUE");
                        e.Row.Cells[n_FairValue].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("OPTION_INTRINSIC_VALUE");
                        e.Row.Cells[n_IntrinsicValue].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("GRANTED_OPTIONS");
                        e.Row.Cells[n_OptionsGranted].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("VESTED_CANCELLED_OPTIONS");
                        e.Row.Cells[n_VestedCancelled].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("UNVESTED_CANCELLED_OPTIONS");
                        e.Row.Cells[n_UnestedCancelled].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("LAPSED_OPTIONS");
                        e.Row.Cells[n_Lapsed].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("EXERCISED_OPTIONS");
                        e.Row.Cells[n_Exercised].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("UNVESTED_OPTIONS");
                        e.Row.Cells[n_Unvested].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("CANCELLED_OPTIONS");
                        e.Row.Cells[n_OptionsCancelled].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("VESTED_AND_EXERCISABLE");
                        e.Row.Cells[n_VestedOptions].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        n_RowCount = CheckDataTableCount("OUTSTANDING_OPTIONS");
                        e.Row.Cells[n_OutstandingOptions].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        e.Row.Cells[n_Status].Visible = false;
                        if (ac_SearchGrantDetails.dt_ReportStatus == null)
                            ac_SearchGrantDetails.dt_ReportStatus = new DataTable();

                        if (ac_SearchGrantDetails.dt_ReportStatus.Columns.Count == 0)
                            ac_SearchGrantDetails.dt_ReportStatus.Columns.Add("Status", typeof(string));

                        e.Row.Cells[n_ID].Visible = e.Row.Cells[n_DocumentName].Visible = e.Row.Cells[n_DocumentPath].Visible = e.Row.Cells[n_AGRMID].Visible = e.Row.Cells[n_IsMUFV].Visible = e.Row.Cells[n_IsMUIV].Visible = false;

                        if (!e.Row.Cells[n_Status].Text.Equals("&nbsp;") && !e.Row.Cells[n_Status].Text.Equals("Select Grant"))
                        {
                            if (e.Row.Cells[n_Status].Text.Equals("Locked"))
                            {
                                e.Row.Cells[n_Status].Controls.Add(AddControl(ucGrantDetails, "LinkButton", "lbtnStatus", "Locked", "Click here to view Versions or Unlock Grants", e.Row.Cells[2].Text, "ViewDetails", e.Row.Cells[n_Status].Text, "GotoStep", string.Empty, string.Empty, "", string.Empty, string.Empty));
                                ac_SearchGrantDetails.dt_ReportStatus.Rows.Add("Locked");
                            }
                            else
                            {
                                e.Row.Cells[n_Status].Controls.Add(AddControl(ucGrantDetails, "LinkButton", "lbtnStatus", "Pending", "Pending for " + e.Row.Cells[n_Status].Text, e.Row.Cells[2].Text, "ViewDetails", e.Row.Cells[n_Status].Text, "GotoStep", string.Empty, string.Empty, "", string.Empty, string.Empty));
                                ac_SearchGrantDetails.dt_ReportStatus.Rows.Add("Pending");
                            }
                        }
                        else
                        {
                            e.Row.Cells[n_Status].Text = e.Row.Cells[n_Status].Text.Equals("Locked") ? "Locked" : !e.Row.Cells[n_Status].Text.Equals("&nbsp;") && !e.Row.Cells[n_Status].Text.Equals("Select Grant") && !e.Row.Cells[n_Status].Text.Equals("Locked") && !s_PageName.Equals("ValuationReport") ? "Pending" : "Not Processed";
                            ac_SearchGrantDetails.dt_ReportStatus.Rows.Add(e.Row.Cells[n_Status].Text);
                        }
                        e.Row.Cells[n_Delete].Controls.Add(AddLinkButton(ucGrantDetails, e.Row.Cells[2].Text, s_PageName));
                        e.Row.Cells[n_Delete].HorizontalAlign = e.Row.Cells[n_DocumentDownload].HorizontalAlign = e.Row.Cells[n_Actions].HorizontalAlign = HorizontalAlign.Center;

                        switch (s_PageName.ToUpper())
                        {
                            case "VALUATIONREPORT":
                                e.Row.Cells[n_GrantDate].Controls.Add(AddControl(ucGrantDetails, "LinkButton", "lbtnGrantID", e.Row.Cells[n_GrantDate].Text, "Click here to  view grant data", string.Empty, "ViewDetails", e.Row.Cells[2].Text, "GrantDate", string.Empty, string.Empty, "", string.Empty, string.Empty));
                                e.Row.Cells[n_GrantID].Controls.Add(AddControl(ucGrantDetails, "LinkButton", "lbtnGrantDate", e.Row.Cells[n_GrantID].Text, "Click here to view valuation parameters", string.Empty, "ViewDetails", e.Row.Cells[2].Text, "GrantID", string.Empty, string.Empty, "", string.Empty, string.Empty));
                                e.Row.Cells[n_Action].Controls.Add(AddControl(ucGrantDetails, "CheckBox", "chkGrantID", "", "", string.Empty, "DeleteSelectedRecords", e.Row.Cells[n_AGRMID].Text, "", "", "", "", string.Empty, string.Empty));
                                break;

                            case "GRANTDETAILS":
                                if (!e.Row.Cells[n_Status].Text.Equals("Locked"))
                                {
                                    e.Row.Cells[n_Action].Controls.Add(AddControl(ucGrantDetails, "CheckBox", "chkGrantID", "", "", string.Empty, "DeleteRecords", e.Row.Cells[n_AGRMID].Text, "", "", "", "", string.Empty, string.Empty));
                                }
                                break;
                        }

                        e.Row.Cells[n_Action].Visible = b_IsLocked ? false : true;

                        if (!b_IsLocked)
                        {
                            e.Row.Cells[n_GrpNum].Visible = s_PageName.Equals("ValuationReport");
                            e.Row.Cells[n_DocumentDownload].Visible = !s_PageName.Equals("ValuationReport");
                        }
                        
                        e.Row.Cells[n_Action].HorizontalAlign = e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;

                        e.Row.Cells[n_FairValue].Controls.Add(AddControl(ucGrantDetails, "LinkButton", "lblFairValue", e.Row.Cells[n_FairValue].Text, "Click here to view details", s_PageName, "ViewDetails", e.Row.Cells[2].Text, "FairValue", ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[n_IsMUFV].ToString(), "", "", string.Empty, string.Empty));
                        e.Row.Cells[n_FairValue].HorizontalAlign = e.Row.Cells[n_IntrinsicValue].HorizontalAlign = e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_IntrinsicValue].Controls.Add(AddControl(ucGrantDetails, "LinkButton", "lblIntrinsicValue", e.Row.Cells[n_IntrinsicValue].Text, "Click here to view details", s_PageName, "ViewDetails", e.Row.Cells[2].Text, "IntrinsicValue", ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[n_IsMUIV].ToString(), string.Empty, "", string.Empty, string.Empty));


                        e.Row.Cells[n_Actions].Visible = !s_PageName.Equals("ValuationReport") && Convert.ToString(((GridView)sender).ID) == "gv" ? true : false;

                        if (Convert.ToString(((GridView)sender).ID) == "gv")
                        {
                            e.Row.Cells[n_Delete].HorizontalAlign = e.Row.Cells[n_DocumentDownload].HorizontalAlign = e.Row.Cells[n_Actions].HorizontalAlign = HorizontalAlign.Center;
                            e.Row.Cells[n_Actions].Controls.Add(AddControl(ucGrantDetails, "ImageButton", e.Row.Cells[4].Text, s_PageName.Equals("ValuationReport") ? "~/View/App_Themes/images/View.png" : "~/View/App_Themes/images/Edit.png", "Click here to Edit Grant", string.Empty, s_PageName.Equals("ValuationReport") ? "View" : "Edit", e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[5].Text, e.Row.Cells[7].Text, e.Row.Cells[n_AGRMID].Text, Convert.ToString(CheckAgainstLockedAccountingReport(e.Row.Cells[n_GrantDate].Text, "Add") > 0 ? 1 : e.Row.Cells[n_Status].Text.Equals("Locked") ? 1 : 0), Convert.ToString(CheckAgainstLockedAccountingReport(e.Row.Cells[n_GrantDate].Text, "Edit") > 0 ? 1 : e.Row.Cells[n_Status].Text.Equals("Locked") ? 1 : 0)));
                        }

                        if (s_PageName.Equals("ValuationReport"))
                        {

                            if (e.Row.RowIndex > 0)
                            {
                                int RowIndex = 1, Count = 1;

                                switch (Convert.ToString(((GridView)sender).ID))
                                {
                                    case "gv":
                                        MergeCells(ucGrantDetails.gv, e, n_Status, ref RowIndex, ref Count);
                                        break;

                                    case "gvLockedRecords":
                                        MergeCells(ucGrantDetails.gvLockedRecords, e, n_Status, ref RowIndex, ref Count);
                                        break;

                                }

                            }

                            if (e.Row.Cells[10].Text.Equals("0"))
                            {
                                e.Row.Cells[10].Text = "-";
                            }
                        }

                        e.Row.Cells[10].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Status].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_OptionsGranted].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_OptionsCancelled].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_VestedOptions].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_OutstandingOptions].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_VestedCancelled].HorizontalAlign = e.Row.Cells[n_UnestedCancelled].HorizontalAlign = e.Row.Cells[n_Lapsed].HorizontalAlign = e.Row.Cells[n_Exercised].HorizontalAlign = e.Row.Cells[n_Unvested].HorizontalAlign = HorizontalAlign.Right;
                        if (!n_EmployeeDetails.Equals(0))
                        {
                            e.Row.Cells[n_EmployeeDetails].Controls.Add(AddlbtnEmployeeDetails(ucGrantDetails, e.Row.Cells[n_GrantID].Text));
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to check datatable is null 
        /// </summary>
        /// <returns>bool</returns>
        private bool IsNullOrEmptyDataTable()
        {
            return ac_SearchGrantDetails.dt_CustmizedViewGrantDetails == null || ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Rows.Count.Equals(0);
        }

        /// <summary>
        /// This method is used to get filtered column count
        /// </summary>
        /// <param name="s_ColumnName">string column name</param>
        /// <returns>int</returns>
        private int CheckDataTableCount(string s_ColumnName)
        {
            return ac_SearchGrantDetails.dt_CustmizedViewGrantDetails.Select("COLUMN_NAME = '" + s_ColumnName + "'").Count();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="gridView"></param>
        /// <param name="e"></param>
        /// <param name="n_Status"></param>
        /// <param name="RowIndex"></param>
        /// <param name="Count"></param>
        private static void MergeCells(GridView gridView, GridViewRowEventArgs e, int n_Status, ref int RowIndex, ref int Count)
        {
            for (int intLoop = 1; intLoop <= e.Row.RowIndex; intLoop++)
            {
                Count++;
                if ((!gridView.Rows[e.Row.RowIndex - intLoop].Cells[10].Text.Equals(string.Empty)) && (e.Row.Cells[10].Text == gridView.Rows[e.Row.RowIndex - intLoop].Cells[10].Text))
                {
                    RowIndex = intLoop;
                    break;
                }

            }

            if (e.Row.Cells[10].Text == gridView.Rows[e.Row.RowIndex - RowIndex].Cells[10].Text)
            {
                e.Row.Cells[10].Text = e.Row.Cells[n_Status].Text = "";
                e.Row.Cells[10].Visible = e.Row.Cells[n_Status].Visible = false;
                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[10].RowSpan = gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_Status].RowSpan = Count;
            }
        }

        /// <summary>
        /// This method is used to add controls in GRIDVIEW
        /// </summary>
        /// <param name="ucGrantDetails">ucGrantDetails user control object</param>
        /// <param name="s_ControlName">Control Name</param>
        /// <param name="s_ControlID">Control ID</param>
        /// <param name="s_ControlText">Text of control</param>
        /// <param name="s_Tooltip">Tool tip</param>
        /// <param name="s_Paramerter"></param>
        /// <param name="s_JavascriptMethodName">Java-script Method Name</param>
        /// <param name="s_Parameter1">Parameter to add in Java-script function</param>
        ///  <param name="s_EventName">Event Name</param>
        ///  <param name="s_ExPrice">Ex Price</param>
        ///  <param name="s_Currency">Currency</param>
        ///  <param name="s_ARMID">string AGRMID</param>
        ///  <param name="s_IsLocked">string Is Accounting Report Locked</param>
        ///  <param name="s_AccRptCreated">string Is Accounting Report Is Creted for that Grant</param>
        /// <returns>Control</returns> 
        private Control AddControl(UCGrantDetails ucGrantDetails, string s_ControlName, string s_ControlID, string s_ControlText, string s_Tooltip, string s_Paramerter, string s_JavascriptMethodName, string s_Parameter1, string s_EventName, string s_ExPrice, string s_Currency, string s_ARMID, string s_IsLocked, string s_AccRptCreated)
        {
            try
            {
                switch (s_ControlName)
                {
                    case "LinkButton":
                        switch (s_JavascriptMethodName)
                        {
                            case "ViewDetails":
                                LinkButton linkButton = new LinkButton();

                                linkButton.ToolTip = s_Tooltip;
                                linkButton.Text = s_ControlText;
                                linkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                linkButton.ID = s_ControlID;
                                if (!string.IsNullOrEmpty(s_JavascriptMethodName) && !s_EventName.Equals("GotoStep"))
                                {
                                    linkButton.Attributes.Add("onclick", "return ViewDetails('" + s_Parameter1 + "')");
                                }
                                else
                                {
                                    linkButton.Attributes.Add("onclick", "return GotoStep('" + s_Parameter1 + "', '" + s_Paramerter + "')");
                                }

                                switch (s_EventName)
                                {
                                    case "FairValue":
                                        linkButton.Click += new EventHandler(ucGrantDetails.LinkButtonFairValue_Click);
                                        if (s_Paramerter.Equals("GrantDetails"))
                                        {
                                            linkButton.ForeColor = s_ExPrice.ToUpper().Equals("TRUE") ? Color.Green : Color.FromName("0");
                                            linkButton.ToolTip = s_ExPrice.ToUpper().Equals("TRUE") ? "The fair value and/or parameters are manually uploaded" : s_Tooltip;
                                        }
                                        break;

                                    case "IntrinsicValue":
                                        linkButton.Click += new EventHandler(ucGrantDetails.LinkButtonIntrinsicValue_Click);
                                        if (s_Paramerter.Equals("GrantDetails"))
                                        {
                                            linkButton.ForeColor = s_ExPrice.ToUpper().Equals("TRUE") ? Color.Green : Color.FromName("0");
                                            linkButton.ToolTip = s_ExPrice.ToUpper().Equals("TRUE") ? "The intrinsic value and/or parameters are manually uploaded" : s_Tooltip;
                                        }
                                        break;

                                    case "GrantDate":
                                        linkButton.Click += new EventHandler(ucGrantDetails.lbtnGrantDate_Click);
                                        break;

                                    case "GrantID":
                                        linkButton.Click += new EventHandler(ucGrantDetails.imgButton_Click);
                                        break;

                                    case "GotoStep":
                                        linkButton.Click += new EventHandler(ucGrantDetails.lbtnGotoStep_Click);
                                        break;
                                }
                                return linkButton;

                            case "ViewDocument":
                                LinkButton lnkButton = new LinkButton();
                                lnkButton.ToolTip = s_Tooltip;
                                lnkButton.ID = s_ControlID;
                                lnkButton.Text = s_Parameter1.Equals("&nbsp;") ? " " : s_ControlText;
                                lnkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                s_EventName = s_EventName.Replace("\\", "~");
                                if (!string.IsNullOrEmpty(s_JavascriptMethodName))
                                {
                                    lnkButton.Attributes.Add("onclick", "return ViewDocument('" + s_Paramerter + "')");
                                }

                                lnkButton.Click += new EventHandler(ucGrantDetails.LinkButtonViewDocument_Click);

                                return lnkButton;

                        }
                        break;

                    case "CheckBox":
                        CheckBox checkBox = new CheckBox();
                        checkBox.InputAttributes.Add("Value", s_Parameter1);
                        checkBox.Checked = s_ControlText.Equals("Delete");
                        checkBox.ID = "chk";
                        checkBox.Attributes.Add("name", "Types");
                        checkBox.InputAttributes["class"] = "CheckBoxClass";
                        checkBox.EnableViewState = false;
                        checkBox.AutoPostBack = false;

                        if (!string.IsNullOrEmpty(s_Parameter1))
                        {
                            if (s_JavascriptMethodName.Equals("DeleteSelectedRecords"))
                                checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_Parameter1 + "',this)");
                            else
                                checkBox.Attributes.Add("onclick", "return DeleteRecords('" + s_Parameter1 + "',this)");
                        }
                        else
                        {
                            if (s_JavascriptMethodName.Equals("SelectAllCheckBoxes"))
                                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                            else
                                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxesRecords(this);");
                        }
                        return checkBox;

                    case "ImageButton":
                        ImageButton imgButton = new ImageButton();
                        imgButton.ToolTip = s_Tooltip;
                        imgButton.Enabled = CheckEmployeeRolePriviledges();
                        imgButton.ImageUrl = s_ControlText;
                        imgButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        if (s_JavascriptMethodName.Equals("Edit"))
                        {
                            imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_ControlID + "','" + s_Parameter1 + "','" + s_EventName + "','" + s_ExPrice + "','" + s_Currency + "','" + s_ARMID + "','" + s_IsLocked + "','" + s_AccRptCreated + "')");
                        }
                        else
                        {
                            imgButton.Attributes.Add("onclick", "return ShowValuationParameters('" + s_Parameter1 + "')");
                            imgButton.Click += ucGrantDetails.imgButton_Click;
                        }
                        return imgButton;

                    case "HyperLink":
                        using (HyperLink hyperLink = new HyperLink())
                        {
                            hyperLink.Text = s_ControlText;
                            hyperLink.ToolTip = "Click here to download";
                            hyperLink.ID = "hypDownload";
                            hyperLink.ClientIDMode = ClientIDMode.Static;
                            hyperLink.CssClass = "cHyperLinksp";
                            hyperLink.TabIndex = 8;
                            s_Parameter1 = s_Parameter1.Replace("\\", "~");
                            hyperLink.Attributes.Add("onclick", "return DocDownload('" + s_Paramerter + "','" + s_Parameter1 + "')");
                            return hyperLink;
                        }

                }
                return new Control();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind GridView Rows
        /// </summary>
        /// <param name="ucGrantDetails">this is ucGrantDetails page object</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="n_index">index</param>
        /// <param name="n_ID">ID</param>
        /// <param name="n_Action">Action</param>
        /// <param name="n_Delete">int delete column id</param>
        /// <param name="n_GrantDate">n_GrantDate</param>
        /// <param name="n_VestPercent">n_VestPercent</param>
        /// <param name="n_FairValVest">n_FairValVest</param>
        /// <param name="n_IntrsicValVest">n_IntrsicValVest</param>
        public void BindChildGridViewRows(UCGrantDetails ucGrantDetails, GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action, ref int n_GrantDate, ref int n_VestPercent, ref int n_FairValVest, ref int n_IntrsicValVest)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "VEST PERCENT (%)":
                                    n_VestPercent = n_index;
                                    break;

                                case "FAIR VALUE PER VEST":
                                    n_FairValVest = n_index;
                                    break;

                                case "INTRINSIC VALUE PER VEST":
                                    n_IntrsicValVest = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        //e.Row.Cells[n_ID].Visible = false;
                        //e.Row.Cells[n_Delete].Controls.Add(AddLinkButton(ucGrantDetails, e.Row.Cells[2].Text, s_PageName));
                        //e.Row.Cells[n_Delete].HorizontalAlign = HorizontalAlign.Center;
                        //e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        //e.Row.Cells[n_Action].Visible = false;
                        //e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.

                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {

                            e.Row.Cells[n_VestPercent].Text = e.Row.Cells[n_VestPercent].Text.Equals("&nbsp;") ? string.Empty : Convert.ToDouble(e.Row.Cells[n_VestPercent].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_VestPercent].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_VestPercent].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            e.Row.Cells[n_VestPercent].HorizontalAlign = HorizontalAlign.Right;

                            if (!e.Row.Cells[n_FairValVest].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_FairValVest].Text = Convert.ToDouble(e.Row.Cells[n_FairValVest].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_FairValVest].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_FairValVest].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_FairValVest].HorizontalAlign = HorizontalAlign.Right;
                            }


                            if (!e.Row.Cells[n_IntrsicValVest].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_IntrsicValVest].Text = Convert.ToDouble(e.Row.Cells[n_IntrsicValVest].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_IntrsicValVest].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_IntrsicValVest].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_IntrsicValVest].HorizontalAlign = HorizontalAlign.Right;
                            }

                        }
                        #endregion
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add link button
        /// </summary>
        /// <param name="ucGrantDetails">this is ucGrantDetails page object</param>
        /// <param name="s_GRID">GRID</param>
        /// <param name="s_PageName">PageName</param>
        /// <returns></returns>
        private LinkButton AddLinkButton(UCGrantDetails ucGrantDetails, string s_GRID, string s_PageName)
        {
            try
            {
                LinkButton linkButton = new LinkButton();
                linkButton.ToolTip = "Click here to view vestwise details";
                linkButton.Text = "View Details";
                linkButton.ID = "lbtnViewDetails\\|" + s_GRID.Replace("(", "_00_").Replace(")", "_000_");
                linkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                linkButton.Style.Add("cursor", "pointer");

                if (!string.IsNullOrEmpty(s_GRID))
                {
                    linkButton.Attributes.Add("onclick", "return ShowDetails(this, '" + s_PageName + "')");
                }
                return linkButton;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add link button
        /// </summary>
        /// <param name="ucGrantDetails">this is ucGrantDetails page object</param>
        /// <param name="s_GRID"></param>
        /// <returns></returns>
        private LinkButton AddlbtnEmployeeDetails(UCGrantDetails ucGrantDetails, string s_GRID)
        {
            try
            {
                using (LinkButton linkButton = new LinkButton())
                {
                    linkButton.ToolTip = "Click here to view Employee Details";
                    linkButton.Text = "View Employee Details";
                    linkButton.ID = s_GRID.Replace("(", "_00_").Replace(")", "_000_");
                    linkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    linkButton.Style.Add("cursor", "pointer");
                    if (!string.IsNullOrEmpty(s_GRID))
                    {
                        linkButton.Attributes.Add("onclick", "return ShowEmployeeDetails(this, '" + s_GRID + "', '" + userSessionInfo.ACC_CalculationMethod + "')");
                    }
                    //linkButton.Click += new EventHandler(ucGrantDetails.lbtnEmployeeDetails_Click);
                    return linkButton;
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Bind next page data
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        /// <param name="gv">gv</param>
        /// <param name="ucGrantDetails">ucGrantDetails</param>
        /// <param name="s_PageName">Page Name</param>
        internal void PageIndexChangingUnlocked(object sender, GridViewPageEventArgs e, GridView gv, UCGrantDetails ucGrantDetails, string s_PageName)
        {
            try
            {
                gv.PageIndex = e.NewPageIndex;
                BindGridView(ucGrantDetails, s_PageName);
                ucGrantDetails.btnVRProceed.Visible = s_PageName.Equals("ValuationReport");
                ucGrantDetails.btnVRProceed.Text = Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnVRProceed'"))[0]["LabelName"]);
                ucGrantDetails.btnVRProceed.ToolTip = Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnVRProceed'"))[0]["LabelToolTip"]);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  Bind next page data
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        /// <param name="gv">gv</param>
        /// <param name="ucGrantDetails">ucGrantDetails</param>
        /// <param name="s_PageName">Page Name</param>
        internal void PageIndexChangingLocked(object sender, GridViewPageEventArgs e, GridView gv, UCGrantDetails ucGrantDetails, string s_PageName)
        {
            try
            {
                gv.PageIndex = e.NewPageIndex;
                BindGridView(ucGrantDetails, s_PageName);
                ucGrantDetails.btnVRProceed.Visible = s_PageName.Equals("ValuationReport");
                ucGrantDetails.btnVRProceed.Text = Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnVRProceed'"))[0]["LabelName"]);
                ucGrantDetails.btnVRProceed.ToolTip = Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnVRProceed'"))[0]["LabelToolTip"]);
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Read valuation parameters
        /// <summary>
        /// Read Valuation Parameters
        /// </summary>
        /// <param name="ucGrantDetails">ucGrantDetails</param>
        public void GetValuationParameters(UCGrantDetails ucGrantDetails)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.PageName = CommonConstantModel.s_ValuationParameters;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;

                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    ucGrantDetails.lblNote.Visible = false;
                    ucGrantDetails.lblManuallyEntered.Visible = false;
                    ucGrantDetails.lblDiffrentThanCompLevel.Visible = false;

                    using (GetValuationParameters getValuationParameters = new GetValuationParameters())
                    {
                        using (DataTable dt_ValuationParameter = getValuationParameters.CreateDataTable("SelectGrants"))
                        {
                            dt_ValuationParameter.TableName = "dtValuationParameter";

                            ucGrantDetails.gvValuationParameters.DataSource = getValuationParameters.CreateValuationParamDataTable(accountingServiceClient, dt_ValuationParameter, accountingCRUDProperties.ds_Result, ucGrantDetails.hdnGrantID.Value);
                            ucGrantDetails.gvValuationParameters.DataBind();

                            ucGrantDetails.gv2.Visible = false;
                            ucGrantDetails.gvValuationParameters.Visible = true;

                            ucGrantDetails.hdnShowGrid.Value = "1";
                        }
                    }
                    ucGrantDetails.lblViewDocument.Text = Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblValuationParameters'"))[0]["LabelName"]);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind valuation report parameters
        /// </summary>
        /// <param name="ucGrantDetails">ucGrantDetails user control object</param>
        /// <param name="e">Grid View Row Event Arguments</param>
        /// <param name="n_CompanyLevel">Company level parameter row number</param>
        /// <param name="n_GrantLevel">Grant level parameter row number</param>
        /// <param name="n_ValIndex">Index</param>
        /// <param name="n_ManuallyUploaded">This field shows whether file is manually uploaded or not</param>        
        public void BindRowsValuationParam(UCGrantDetails ucGrantDetails, GridViewRowEventArgs e, ref int n_CompanyLevel, ref int n_GrantLevel, ref int n_ValIndex, ref int n_ManuallyUploaded)
        {

            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "COMPANY LEVEL":
                                    n_CompanyLevel = n_ValIndex;
                                    break;

                                case "PRESENT GRANT PARAMETERS":
                                    n_GrantLevel = n_ValIndex;
                                    break;

                                case "IS MANUAL UPLOADED":
                                    n_ManuallyUploaded = n_ValIndex;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_ValIndex = n_ValIndex + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:

                        BulletedList bulletedList = new BulletedList();
                        BulletedList bulletedListNote = new BulletedList();

                        e.Row.Cells[n_ManuallyUploaded].Visible = false;

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_GrantLevel].Text) && !e.Row.Cells[n_GrantLevel].Text.Equals("&nbsp;") && !e.Row.Cells[n_GrantLevel].Text.Equals(e.Row.Cells[n_CompanyLevel].Text))
                        {
                            ucGrantDetails.lblNote.Visible = ucGrantDetails.lblDiffrentThanCompLevel.Visible = true;
                            ucGrantDetails.lblDiffrentThanCompLevel.Text = Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblDiffrentThanCompLevel'"))[0]["LabelName"]);
                            e.Row.Cells[n_GrantLevel].BackColor = System.Drawing.ColorTranslator.FromHtml("#D6FFD6");
                        }

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_GrantLevel].Text) && !e.Row.Cells[n_GrantLevel].Text.Equals("&nbsp;"))
                        {
                            bulletedList.BulletStyle = System.Web.UI.WebControls.BulletStyle.Square;
                            bulletedList.DataSource = e.Row.Cells[n_GrantLevel].Text.Split(',');
                            bulletedList.DataBind();
                            e.Row.Cells[n_GrantLevel].Controls.Add(bulletedList);
                        }

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_CompanyLevel].Text) && !e.Row.Cells[n_CompanyLevel].Text.Equals("&nbsp;"))
                        {
                            bulletedList = new BulletedList();
                            bulletedList.BulletStyle = System.Web.UI.WebControls.BulletStyle.Square;
                            bulletedList.DataSource = e.Row.Cells[n_CompanyLevel].Text.Split(',');
                            bulletedList.DataBind();
                            e.Row.Cells[n_CompanyLevel].Controls.Add(bulletedList);
                        }
                        if (!string.IsNullOrEmpty(e.Row.Cells[n_ManuallyUploaded].Text) && e.Row.Cells[n_ManuallyUploaded].Text.Equals("True"))
                        {
                            ucGrantDetails.lblNote.Visible = ucGrantDetails.lblManuallyEntered.Visible = true;
                            ucGrantDetails.lblManuallyEntered.Text = Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblManuallyEntered'"))[0]["LabelName"]);
                            e.Row.Cells[n_GrantLevel].BackColor = System.Drawing.ColorTranslator.FromHtml("#E0F0FF");
                            e.Row.Cells[n_GrantLevel].Text = "Manually entered data";

                        }
                        if (string.IsNullOrEmpty(e.Row.Cells[n_GrantLevel].Text) || e.Row.Cells[n_GrantLevel].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[n_GrantLevel].Text = "Same as company level";
                        }
                        bulletedList.Dispose();
                        break;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Set Work-flow Status
        /// <summary>
        /// Set Work-flow status
        /// </summary>
        /// <param name="ucGrantDetails">ucGrantDetails user control object</param>
        public void SetWorkflowStatus(UCGrantDetails ucGrantDetails)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    bool b_IsGrpNoExists = false;

                    if (!ucGrantDetails.hdnProceed.Value.Equals("True"))
                    {
                        foreach (var item in ucGrantDetails.hdnSelectedGrants.Value.ToString().TrimStart(',').Split(','))
                        {
                            foreach (DataRow perRow in ac_SearchGrantDetails.dt_all_Grants.Select("AGRMID = '" + item + "'"))
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(perRow["Group Number"])) && !Convert.ToString(perRow["Group Number"]).Equals("0"))
                                {
                                    b_IsGrpNoExists = true;
                                    ScriptManager.RegisterStartupScript(ucGrantDetails, GetType(), "alertMessage", "if (confirm('" + accountingServiceClient.GetAccounting_L10N("lblReCreateGroup", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10) + "')){ document.getElementById('hdnProceed').value = 'True'; document.getElementById('btnVRProceed').click();  } else { document.getElementById('hdnProceed').value = 'False';  document.getElementById('hdnSelectedGrants').value = '';}", true);
                                }


                            }
                        }
                    }
                    ucGrantDetails.hdnProceed.Value = b_IsGrpNoExists.ToString();
                    if (!ucGrantDetails.hdnProceed.Value.Equals("True"))
                    {
                        ucGrantDetails.hdnProceed.Value = "False";

                        accountingProperties.PageName = CommonConstantModel.s_WorkflowStatus;
                        accountingProperties.Operation = CommonConstantModel.s_OperationCUD;

                        ac_SearchGrantDetails.s_StepNumber = "1";

                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        accountingProperties.AWFID = 1;
                        accountingProperties.GrantDetailsIDList = ucGrantDetails.hdnSelectedGrants.Value.TrimStart(',');
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                        ac_SearchGrantDetails.s_SelectedGrants = string.Empty;
                        ac_SearchGrantDetails.s_SelectedGrants = ucGrantDetails.hdnSelectedGrants.Value;
                        ucGrantDetails.hdnSelectedGrants.Value = string.Empty;

                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Searc/Filter Data
        /// <summary>
        /// This method is used to search records in grid-view
        /// </summary>
        /// <param name="uCGrantDetails">UCGrantDetails page object</param>
        /// <param name="gvUnlocked">Unlocked grid-view</param>
        /// <param name="gvLocked">Locked grid-view</param>
        /// <param name="s_PageName">Page Name</param>
        /// <returns>Search Result</returns>
        internal int btnGDSearch_Click(UCGrantDetails uCGrantDetails, GridView gvUnlocked, GridView gvLocked, string s_PageName)
        {
            try
            {
                int n_SearchResult = 0;

                using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                {
                    DataTable dt_UnlockedOriginal = new DataTable(); DataTable dt_UnlockedFiltered = new DataTable();
                    DataTable dt_LockedOriginal = new DataTable(); DataTable dt_LockedFiltered = new DataTable();

                    int n_chkGDGrantIDCount = uCGrantDetails.chkGDGrantID.Items.Cast<ListItem>().Count(li => li.Selected);
                    int n_chkGDSchemeNameCount = uCGrantDetails.chkGDSchemeName.Items.Cast<ListItem>().Count(li => li.Selected);
                    int n_chkGDCurrencyCount = uCGrantDetails.chkGDCurrency.Items.Cast<ListItem>().Count(li => li.Selected);
                    int n_chkGDStatusCount = uCGrantDetails.chkGDReportStatus.Items.Cast<ListItem>().Count(li => li.Selected);
                    int n_chkGrantCreatedOn = uCGrantDetails.chkGrantCreatedOn.Items.Cast<ListItem>().Count(li => li.Selected);

                    bool b_CurrencyFlag = false; bool b_ReportStatus = false;

                    string s_FromDate = string.IsNullOrEmpty(uCGrantDetails.calGDFromDate.Value) || uCGrantDetails.calGDFromDate.Value.Equals("dd/mmm/yyyy") ? string.Empty : uCGrantDetails.calGDFromDate.Value;
                    string s_ToDate = string.IsNullOrEmpty(uCGrantDetails.calGDToDate.Value) || uCGrantDetails.calGDToDate.Value.Equals("dd/mmm/yyyy") ? string.Empty : uCGrantDetails.calGDToDate.Value;
                    string s_ExerPrcFrom = string.IsNullOrEmpty(uCGrantDetails.txtGDExercisePriceFrom.Text) ? string.Empty : uCGrantDetails.txtGDExercisePriceFrom.Text;
                    string s_ExerPrcTo = string.IsNullOrEmpty(uCGrantDetails.txtGDExercisePriceTo.Text) ? string.Empty : uCGrantDetails.txtGDExercisePriceTo.Text;
                    string s_DateCompare = string.Empty;
                    string s_ExerPrcCompare = string.Empty;
                    string s_GrpNumFrom = string.IsNullOrEmpty(uCGrantDetails.txtVRGrpNumFrom.Text) ? string.Empty : uCGrantDetails.txtVRGrpNumFrom.Text;
                    string s_GrpNumTo = string.IsNullOrEmpty(uCGrantDetails.txtVRGrpNumTo.Text) ? string.Empty : uCGrantDetails.txtVRGrpNumTo.Text;
                    string s_GrpnumCompare = string.Empty;

                    uCGrantDetails.txtGDGrantID.Text = n_chkGDGrantIDCount.Equals(0) ? "--- Please Select ---" : uCGrantDetails.txtGDGrantID.Text;
                    uCGrantDetails.txtGDSchemeName.Text = n_chkGDSchemeNameCount.Equals(0) ? "--- Please Select ---" : uCGrantDetails.txtGDSchemeName.Text;
                    uCGrantDetails.txtGDCurrency.Text = n_chkGDCurrencyCount.Equals(0) ? "--- Please Select ---" : uCGrantDetails.txtGDCurrency.Text;
                    uCGrantDetails.txtGDReportStatus.Text = n_chkGDStatusCount.Equals(0) ? "--- Please Select ---" : uCGrantDetails.txtGDReportStatus.Text;
                    uCGrantDetails.txtGrantCreatedOn.Text = n_chkGrantCreatedOn.Equals(0) ? "--- Please Select ---" : uCGrantDetails.txtGrantCreatedOn.Text;

                    if ((!(string.IsNullOrEmpty(s_FromDate))) && (!(string.IsNullOrEmpty(s_ToDate))))
                    {
                        s_DateCompare = "[Grant Date] >= #" + Convert.ToDateTime(s_FromDate).Date + "# AND [Grant Date] <= #" + Convert.ToDateTime(s_ToDate).Date + "# ";
                    }

                    if ((!(string.IsNullOrEmpty(s_ExerPrcFrom))) && (!(string.IsNullOrEmpty(s_ExerPrcTo))))
                    {
                        s_ExerPrcCompare = "[Exercise Price] >= '" + s_ExerPrcFrom + "' AND [Exercise Price] <= '" + s_ExerPrcTo + "'";
                    }

                    if ((!(string.IsNullOrEmpty(s_GrpNumFrom))) && (!(string.IsNullOrEmpty(s_GrpNumTo))))
                    {
                        s_GrpnumCompare = "[Group Number] >= '" + s_GrpNumFrom + "' AND [Group Number] <= '" + s_GrpNumTo + "'";
                    }

                    /* GrantID Filter */
                    if (n_chkGDGrantIDCount > 0)
                    {
                        uCGrantDetails.txtGDGrantID.Text = string.Empty;

                        for (int i = 0; i < uCGrantDetails.chkGDGrantID.Items.Count; i++)
                        {
                            if (uCGrantDetails.chkGDGrantID.Items[i].Selected == true)
                            {
                                string s_GrantID = "[Grant Registration ID] = '" + uCGrantDetails.chkGDGrantID.Items[i].Text.ToString() + "'";

                                if (n_chkGDGrantIDCount > 1)
                                {
                                    dt_UnlockedOriginal = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_GrantID + "").Count() > 0 && n_chkGDGrantIDCount > 1 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_GrantID + "").CopyToDataTable() : new DataTable();
                                    dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);
                                }

                                else
                                {
                                    dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_GrantID + "").Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_GrantID + "").CopyToDataTable() : new DataTable();
                                }

                                if (!uCGrantDetails.chkGDGrantID.Items[i].Text.Equals("--- Select All ---"))
                                    uCGrantDetails.txtGDGrantID.Text = uCGrantDetails.txtGDGrantID.Text + "," + uCGrantDetails.chkGDGrantID.Items[i].Text;

                            }
                        }
                        uCGrantDetails.txtGDGrantID.Text = Convert.ToString(uCGrantDetails.txtGDGrantID.Text).Trim(',');
                    }

                    /* Scheme Name Filter */
                    if (n_chkGDSchemeNameCount > 0)
                    {
                        uCGrantDetails.txtGDSchemeName.Text = string.Empty;

                        for (int i = 0; i < uCGrantDetails.chkGDSchemeName.Items.Count; i++)
                        {
                            if (uCGrantDetails.chkGDSchemeName.Items[i].Selected == true)
                            {
                                string s_SchemeName = "[Scheme Title] = '" + uCGrantDetails.chkGDSchemeName.Items[i].Text.ToString() + "'";

                                if (((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0)) && n_chkGDGrantIDCount > 0)
                                {
                                    if (n_chkGDSchemeNameCount > 1)
                                    {
                                        DataTable dt_SchemeUnlocked = new DataTable();
                                        DataTable dt_SchemeLocked = new DataTable();

                                        dt_SchemeUnlocked = dt_UnlockedFiltered;
                                        dt_SchemeLocked = dt_LockedFiltered;

                                        dt_UnlockedOriginal = dt_SchemeUnlocked != null && dt_SchemeUnlocked.Rows.Count > 0 && dt_SchemeUnlocked.Select("" + s_SchemeName + "").Count() > 0 && n_chkGDSchemeNameCount > 0 ? dt_SchemeUnlocked.Select("" + s_SchemeName + "").CopyToDataTable() : new DataTable();
                                        dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);

                                        dt_LockedOriginal = dt_SchemeLocked != null && dt_SchemeLocked.Rows.Count > 0 && dt_SchemeLocked.Select("" + s_SchemeName + "").Count() > 0 && n_chkGDSchemeNameCount > 0 ? dt_SchemeLocked.Select("" + s_SchemeName + "").CopyToDataTable() : new DataTable();
                                        dt_LockedFiltered.Merge(dt_LockedOriginal);
                                    }

                                    else
                                    {
                                        dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.Select("" + s_SchemeName + "").Count() > 0 ? dt_UnlockedFiltered.Select("" + s_SchemeName + "").CopyToDataTable() : new DataTable();
                                        dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.Select("" + s_SchemeName + "").Count() > 0 ? dt_LockedFiltered.Select("" + s_SchemeName + "").CopyToDataTable() : new DataTable();
                                    }
                                }

                                else
                                {
                                    if (n_chkGDSchemeNameCount > 1)
                                    {
                                        dt_UnlockedOriginal = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_SchemeName + "").Count() > 0 && n_chkGDSchemeNameCount > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_SchemeName + "").CopyToDataTable() : new DataTable();
                                        dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);
                                    }

                                    else
                                    {
                                        dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_SchemeName + "").Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_SchemeName + "").CopyToDataTable() : new DataTable();
                                    }
                                }

                                if (!uCGrantDetails.chkGDSchemeName.Items[i].Text.Equals("--- Select All ---"))
                                    uCGrantDetails.txtGDSchemeName.Text = uCGrantDetails.txtGDSchemeName.Text + "," + uCGrantDetails.chkGDSchemeName.Items[i].Text;
                            }
                        }
                        uCGrantDetails.txtGDSchemeName.Text = Convert.ToString(uCGrantDetails.txtGDSchemeName.Text).Trim(',');
                    }

                    /* Currency Filter */
                    if (n_chkGDCurrencyCount > 0)
                    {
                        uCGrantDetails.txtGDCurrency.Text = string.Empty;

                        for (int i = 0; i < uCGrantDetails.chkGDCurrency.Items.Count; i++)
                        {
                            if (uCGrantDetails.chkGDCurrency.Items[i].Selected == true)
                            {
                                string s_Currency = "[Currency] = '" + uCGrantDetails.chkGDCurrency.Items[i].Text.ToString() + "'";

                                if ((n_chkGDGrantIDCount > 0 || n_chkGDSchemeNameCount > 0) && ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0)))
                                {
                                    if (n_chkGDCurrencyCount > 1)
                                    {
                                        DataTable dt_SchemeUnlocked = new DataTable();
                                        DataTable dt_SchemeLocked = new DataTable();

                                        dt_SchemeUnlocked = dt_UnlockedFiltered;
                                        dt_SchemeLocked = dt_LockedFiltered;

                                        dt_UnlockedOriginal = dt_SchemeUnlocked != null && dt_SchemeUnlocked.Rows.Count > 0 && dt_SchemeUnlocked.Select("" + s_Currency + "").Count() > 0 && n_chkGDCurrencyCount > 0 ? dt_SchemeUnlocked.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                                        dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);

                                        dt_LockedOriginal = dt_SchemeLocked != null && dt_SchemeLocked.Rows.Count > 0 && dt_SchemeLocked.Select("" + s_Currency + "").Count() > 0 && n_chkGDCurrencyCount > 0 ? dt_SchemeLocked.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                                        dt_LockedFiltered.Merge(dt_LockedOriginal);
                                    }

                                    else
                                    {
                                        dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.Select("" + s_Currency + "").Count() > 0 ? dt_UnlockedFiltered.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                                        dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.Select("" + s_Currency + "").Count() > 0 ? dt_LockedFiltered.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                                    }
                                }

                                else
                                {
                                    if ((n_chkGDGrantIDCount > 0 || n_chkGDSchemeNameCount > 0 || (dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0)) && !b_CurrencyFlag)
                                    {
                                        if (n_chkGDCurrencyCount > 1)
                                        {
                                            DataTable dt_SchemeUnlocked = new DataTable();
                                            DataTable dt_SchemeLocked = new DataTable();

                                            dt_SchemeUnlocked = dt_UnlockedFiltered;
                                            dt_SchemeLocked = dt_LockedFiltered;

                                            dt_UnlockedOriginal = dt_SchemeUnlocked != null && dt_SchemeUnlocked.Rows.Count > 0 && dt_SchemeUnlocked.Select("" + s_Currency + "").Count() > 0 && n_chkGDCurrencyCount > 0 ? dt_SchemeUnlocked.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                                            dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);

                                            dt_LockedOriginal = dt_SchemeLocked != null && dt_SchemeLocked.Rows.Count > 0 && dt_SchemeLocked.Select("" + s_Currency + "").Count() > 0 && n_chkGDCurrencyCount > 0 ? dt_SchemeLocked.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                                            dt_LockedFiltered.Merge(dt_LockedOriginal);
                                        }

                                        else
                                        {
                                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.Select("" + s_Currency + "").Count() > 0 ? dt_UnlockedFiltered.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.Select("" + s_Currency + "").Count() > 0 ? dt_LockedFiltered.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                                        }
                                    }

                                    else
                                    {
                                        if (n_chkGDCurrencyCount > 1)
                                        {
                                            dt_UnlockedOriginal = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_Currency + "").Count() > 0 && n_chkGDCurrencyCount > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                                            dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);
                                            b_CurrencyFlag = true;
                                        }

                                        else
                                        {
                                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_Currency + "").Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                                        }
                                    }
                                }

                                if (!uCGrantDetails.chkGDCurrency.Items[i].Text.Equals("--- Select All ---"))
                                    uCGrantDetails.txtGDCurrency.Text += "," + uCGrantDetails.chkGDCurrency.Items[i].Text;
                            }
                        }
                        uCGrantDetails.txtGDCurrency.Text = Convert.ToString(uCGrantDetails.txtGDCurrency.Text).Trim(',');
                    }

                    /* Report Status Filter*/
                    if (n_chkGDStatusCount > 0)
                    {
                        uCGrantDetails.txtGDReportStatus.Text = string.Empty;

                        for (int i = 0; i < uCGrantDetails.chkGDReportStatus.Items.Count; i++)
                        {
                            if (uCGrantDetails.chkGDReportStatus.Items[i].Selected == true)
                            {
                                string s_ReportStatus = string.Empty;


                                if (uCGrantDetails.chkGDReportStatus.Items[i].Text.ToString() == "Pending")
                                    s_ReportStatus = "Compare Grant' OR [Status]= 'Select Template' OR [Status]= 'Download and Send for Review' OR [Status]= 'Reviewer Feedback' OR [Status]='Final Report";

                                else if (uCGrantDetails.chkGDReportStatus.Items[i].Text.ToString() == "Not Processed")
                                    s_ReportStatus = "Select Grant";

                                else
                                    s_ReportStatus = "Locked";

                                string s_Status = "[Status] = '" + s_ReportStatus + "'";

                                if ((n_chkGDGrantIDCount > 0 || n_chkGDSchemeNameCount > 0 || n_chkGDCurrencyCount > 0) && ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0)))
                                {
                                    if (n_chkGDStatusCount > 1)
                                    {
                                        DataTable dt_SchemeUnlocked = new DataTable();
                                        DataTable dt_SchemeLocked = new DataTable();

                                        dt_SchemeUnlocked = dt_UnlockedFiltered;
                                        dt_SchemeLocked = dt_LockedFiltered;

                                        dt_UnlockedOriginal = dt_SchemeUnlocked != null && dt_SchemeUnlocked.Rows.Count > 0 && dt_SchemeUnlocked.Select("" + s_Status + "").Count() > 0 && n_chkGDStatusCount > 0 ? dt_SchemeUnlocked.Select("" + s_Status + "").CopyToDataTable() : new DataTable();
                                        dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);

                                        dt_LockedOriginal = dt_SchemeLocked != null && dt_SchemeLocked.Rows.Count > 0 && dt_SchemeLocked.Select("" + s_Status + "").Count() > 0 && n_chkGDStatusCount > 0 ? dt_SchemeLocked.Select("" + s_Status + "").CopyToDataTable() : new DataTable();
                                        dt_LockedFiltered.Merge(dt_LockedOriginal);
                                    }

                                    else
                                    {
                                        dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.Select("" + s_Status + "").Count() > 0 ? dt_UnlockedFiltered.Select("" + s_Status + "").CopyToDataTable() : new DataTable();
                                        dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.Select("" + s_Status + "").Count() > 0 ? dt_LockedFiltered.Select("" + s_Status + "").CopyToDataTable() : new DataTable();
                                    }
                                }

                                else
                                {
                                    if ((n_chkGDGrantIDCount > 0 || n_chkGDSchemeNameCount > 0 || n_chkGDCurrencyCount > 0 || (dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0)) && !b_ReportStatus)
                                    {
                                        if (n_chkGDStatusCount > 1)
                                        {
                                            DataTable dt_SchemeUnlocked = new DataTable();
                                            DataTable dt_SchemeLocked = new DataTable();

                                            dt_SchemeUnlocked = dt_UnlockedFiltered;
                                            dt_SchemeLocked = dt_LockedFiltered;

                                            dt_UnlockedOriginal = dt_SchemeUnlocked != null && dt_SchemeUnlocked.Rows.Count > 0 && dt_SchemeUnlocked.Select("" + s_Status + "").Count() > 0 && n_chkGDStatusCount > 0 ? dt_SchemeUnlocked.Select("" + s_Status + "").CopyToDataTable() : new DataTable();
                                            dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);

                                            dt_LockedOriginal = dt_SchemeLocked != null && dt_SchemeLocked.Rows.Count > 0 && dt_SchemeLocked.Select("" + s_Status + "").Count() > 0 && n_chkGDStatusCount > 0 ? dt_SchemeLocked.Select("" + s_Status + "").CopyToDataTable() : new DataTable();
                                            dt_LockedFiltered.Merge(dt_LockedOriginal);
                                        }

                                        else
                                        {
                                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.Select("" + s_Status + "").Count() > 0 ? dt_UnlockedFiltered.Select("" + s_Status + "").CopyToDataTable() : new DataTable();
                                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.Select("" + s_Status + "").Count() > 0 ? dt_LockedFiltered.Select("" + s_Status + "").CopyToDataTable() : new DataTable();
                                        }
                                    }

                                    else
                                    {
                                        if (n_chkGDStatusCount > 1)
                                        {
                                            dt_UnlockedOriginal = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_Status + "").Count() > 0 && n_chkGDStatusCount > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_Status + "").CopyToDataTable() : new DataTable();
                                            dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);

                                            b_ReportStatus = true;
                                        }

                                        else
                                        {
                                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_Status + "").Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_Status + "").CopyToDataTable() : new DataTable();
                                        }
                                    }
                                }

                                if (!uCGrantDetails.chkGDReportStatus.Items[i].Text.Equals("--- Select All ---"))
                                    uCGrantDetails.txtGDReportStatus.Text = uCGrantDetails.txtGDReportStatus.Text + "," + uCGrantDetails.chkGDReportStatus.Items[i].Text;
                            }
                        }
                        uCGrantDetails.txtGDReportStatus.Text = Convert.ToString(uCGrantDetails.txtGDReportStatus.Text).Trim(',');
                    }

                    /* Grant Date From And To Date Filter :- it will filter data that has grant date in between 'Grant From Date and Grant To Date' values */
                    if (!string.IsNullOrEmpty(s_DateCompare))
                    {
                        if ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0))
                        {
                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.Select("" + s_DateCompare + "").Count() > 0 ? dt_UnlockedFiltered.Select("" + s_DateCompare + "").CopyToDataTable() : new DataTable();
                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.Select("" + s_DateCompare + "").Count() > 0 ? dt_LockedFiltered.Select("" + s_DateCompare + "").CopyToDataTable() : new DataTable();
                        }
                        else
                        {
                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_DateCompare + "").Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_DateCompare + "").CopyToDataTable() : new DataTable();
                        }
                    }

                    /* Grant Date From Date Filter :- it will filter data that has grant date greater than or equal to 'Grant Date'*/
                    if (string.IsNullOrEmpty(s_DateCompare) && !string.IsNullOrEmpty(s_FromDate))
                    {
                        if ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0))
                        {
                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date >= Convert.ToDateTime(s_FromDate).Date).Count() > 0 ? dt_UnlockedFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date >= Convert.ToDateTime(s_FromDate).Date).CopyToDataTable() : new DataTable();
                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date >= Convert.ToDateTime(s_FromDate).Date).Count() > 0 ? dt_LockedFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date >= Convert.ToDateTime(s_FromDate).Date).CopyToDataTable() : new DataTable();
                        }
                        else
                        {
                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date >= Convert.ToDateTime(s_FromDate).Date).Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date >= Convert.ToDateTime(s_FromDate).Date).CopyToDataTable() : new DataTable();
                        }
                    }

                    /* Grant Date To Date Filter :- it will filter data that has grant date less than or equal to 'Grant Date' */
                    if (string.IsNullOrEmpty(s_DateCompare) && !string.IsNullOrEmpty(s_ToDate))
                    {
                        if ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0))
                        {
                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date <= Convert.ToDateTime(s_ToDate).Date).Count() > 0 ? dt_UnlockedFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date <= Convert.ToDateTime(s_ToDate).Date).CopyToDataTable() : new DataTable();
                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date <= Convert.ToDateTime(s_ToDate).Date).Count() > 0 ? dt_LockedFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date <= Convert.ToDateTime(s_ToDate).Date).CopyToDataTable() : new DataTable();
                        }
                        else
                        {
                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date <= Convert.ToDateTime(s_ToDate).Date).Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => DateTime.Parse(r["Grant Date"].ToString()).Date <= Convert.ToDateTime(s_ToDate).Date).CopyToDataTable() : new DataTable();
                        }
                    }

                    /* Exercise Price From And To Filter :- it will filter data that has exercise price in between 'From and To Price' values */
                    if (!string.IsNullOrEmpty(s_ExerPrcCompare))
                    {
                        if ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0))
                        {
                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.Select("" + s_ExerPrcCompare + "").Count() > 0 ? dt_UnlockedFiltered.Select("" + s_ExerPrcCompare + "").CopyToDataTable() : new DataTable();
                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.Select("" + s_ExerPrcCompare + "").Count() > 0 ? dt_LockedFiltered.Select("" + s_ExerPrcCompare + "").CopyToDataTable() : new DataTable();
                        }
                        else
                        {
                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_ExerPrcCompare + "").Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_ExerPrcCompare + "").CopyToDataTable() : new DataTable();
                        }
                    }

                    /* Exercise Price From Price Filter :- it will filter data that has exercise price greater than or equal to 'From Price' */
                    if (string.IsNullOrEmpty(s_ExerPrcCompare) && !string.IsNullOrEmpty(s_ExerPrcFrom))
                    {
                        if ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0))
                        {
                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) >= Convert.ToDecimal(s_ExerPrcFrom)).Count() > 0 ? dt_UnlockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) >= Convert.ToDecimal(s_ExerPrcFrom)).CopyToDataTable() : new DataTable();
                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) >= Convert.ToDecimal(s_ExerPrcFrom)).Count() > 0 ? dt_LockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) >= Convert.ToDecimal(s_ExerPrcFrom)).CopyToDataTable() : new DataTable();
                        }
                        else
                        {
                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) >= Convert.ToDecimal(s_ExerPrcFrom)).Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) >= Convert.ToDecimal(s_ExerPrcFrom)).CopyToDataTable() : new DataTable();
                        }
                    }

                    /* Exercise Price To Price Filter :- it will filter data that has exercise price less than or equal to 'To Price' */
                    if (string.IsNullOrEmpty(s_ExerPrcCompare) && !string.IsNullOrEmpty(s_ExerPrcTo))
                    {
                        if ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0))
                        {
                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) <= Convert.ToDecimal(s_ExerPrcTo)).Count() > 0 ? dt_UnlockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) <= Convert.ToDecimal(s_ExerPrcTo)).CopyToDataTable() : new DataTable();
                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) <= Convert.ToDecimal(s_ExerPrcTo)).Count() > 0 ? dt_LockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) <= Convert.ToDecimal(s_ExerPrcTo)).CopyToDataTable() : new DataTable();
                        }
                        else
                        {
                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) <= Convert.ToDecimal(s_ExerPrcTo)).Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => Decimal.Parse(r["Exercise Price"].ToString()) <= Convert.ToDecimal(s_ExerPrcTo)).CopyToDataTable() : new DataTable();
                        }
                    }

                    /* Group Number From And To Filter :- it will filter data that has group number in between 'From and To' values */
                    if (!string.IsNullOrEmpty(s_GrpnumCompare))
                    {
                        if ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0))
                        {
                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.Select("" + s_GrpnumCompare + "").Count() > 0 ? dt_UnlockedFiltered.Select("" + s_GrpnumCompare + "").CopyToDataTable() : new DataTable();
                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.Select("" + s_GrpnumCompare + "").Count() > 0 ? dt_LockedFiltered.Select("" + s_GrpnumCompare + "").CopyToDataTable() : new DataTable();
                        }
                        else
                        {
                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_GrpnumCompare + "").Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_GrpnumCompare + "").CopyToDataTable() : new DataTable();
                        }
                    }

                    /* Group Number From Price Filter :- it will filter data that has group number greater than or equal to 'From' */
                    if (string.IsNullOrEmpty(s_GrpnumCompare) && !string.IsNullOrEmpty(s_GrpNumFrom))
                    {
                        if ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0))
                        {
                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) >= Convert.ToDecimal(s_GrpNumFrom)).Count() > 0 ? dt_UnlockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) >= Convert.ToDecimal(s_GrpNumFrom)).CopyToDataTable() : new DataTable();
                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) >= Convert.ToDecimal(s_GrpNumFrom)).Count() > 0 ? dt_LockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) >= Convert.ToDecimal(s_GrpNumFrom)).CopyToDataTable() : new DataTable();
                        }
                        else
                        {
                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) >= Convert.ToDecimal(s_GrpNumFrom)).Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) >= Convert.ToDecimal(s_GrpNumFrom)).CopyToDataTable() : new DataTable();
                        }
                    }

                    /* Group Number To Price Filter :- it will filter data that has group number less than or equal to 'To' */
                    if (string.IsNullOrEmpty(s_GrpnumCompare) && !string.IsNullOrEmpty(s_GrpNumTo))
                    {
                        if ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0))
                        {
                            dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) <= Convert.ToDecimal(s_GrpNumTo)).Count() > 0 ? dt_UnlockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) <= Convert.ToDecimal(s_GrpNumTo)).CopyToDataTable() : new DataTable();
                            dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) <= Convert.ToDecimal(s_GrpNumTo)).Count() > 0 ? dt_LockedFiltered.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) <= Convert.ToDecimal(s_GrpNumTo)).CopyToDataTable() : new DataTable();
                        }
                        else
                        {
                            dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) <= Convert.ToDecimal(s_GrpNumTo)).Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.AsEnumerable().Where(r => Decimal.Parse(r["Group Number"].ToString()) <= Convert.ToDecimal(s_GrpNumTo)).CopyToDataTable() : new DataTable();
                        }
                    }
                    /* Grant created on Filter */
                    if (n_chkGrantCreatedOn > 0)
                    {
                        uCGrantDetails.txtGrantCreatedOn.Text = string.Empty;

                        for (int i = 0; i < uCGrantDetails.chkGrantCreatedOn.Items.Count; i++)
                        {
                            if (uCGrantDetails.chkGrantCreatedOn.Items[i].Selected == true)
                            {
                                string s_GrantCreatedOn = "[Grant Created On] = '" + uCGrantDetails.chkGrantCreatedOn.Items[i].Text.ToString() + "'";

                                if (((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0)) && n_chkGDGrantIDCount > 0)
                                {
                                    if (n_chkGrantCreatedOn > 1)
                                    {
                                        DataTable dt_GrantCreatedOnUnlocked = new DataTable();
                                        DataTable dt_GrantCreatedOnLocked = new DataTable();

                                        dt_GrantCreatedOnUnlocked = dt_UnlockedFiltered;
                                        dt_GrantCreatedOnLocked = dt_LockedFiltered;

                                        dt_UnlockedOriginal = dt_GrantCreatedOnUnlocked != null && dt_GrantCreatedOnUnlocked.Rows.Count > 0 && dt_GrantCreatedOnUnlocked.Select("" + s_GrantCreatedOn + "").Count() > 0 && n_chkGrantCreatedOn > 0 ? dt_GrantCreatedOnUnlocked.Select("" + s_GrantCreatedOn + "").CopyToDataTable() : new DataTable();
                                        dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);

                                        dt_LockedOriginal = dt_GrantCreatedOnLocked != null && dt_GrantCreatedOnLocked.Rows.Count > 0 && dt_GrantCreatedOnLocked.Select("" + s_GrantCreatedOn + "").Count() > 0 && n_chkGrantCreatedOn > 0 ? dt_GrantCreatedOnLocked.Select("" + s_GrantCreatedOn + "").CopyToDataTable() : new DataTable();
                                        dt_LockedFiltered.Merge(dt_LockedOriginal);
                                    }

                                    else
                                    {
                                        dt_UnlockedFiltered = dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0 && dt_UnlockedFiltered.Select("" + s_GrantCreatedOn + "").Count() > 0 ? dt_UnlockedFiltered.Select("" + s_GrantCreatedOn + "").CopyToDataTable() : new DataTable();
                                        dt_LockedFiltered = dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0 && dt_LockedFiltered.Select("" + s_GrantCreatedOn + "").Count() > 0 ? dt_LockedFiltered.Select("" + s_GrantCreatedOn + "").CopyToDataTable() : new DataTable();
                                    }
                                }

                                else
                                {
                                    if (n_chkGrantCreatedOn > 1)
                                    {
                                        dt_UnlockedOriginal = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_GrantCreatedOn + "").Count() > 0 && n_chkGrantCreatedOn > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_GrantCreatedOn + "").CopyToDataTable() : new DataTable();
                                        dt_UnlockedFiltered.Merge(dt_UnlockedOriginal);
                                    }

                                    else
                                    {
                                        dt_UnlockedFiltered = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_GrantCreatedOn + "").Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("" + s_GrantCreatedOn + "").CopyToDataTable() : new DataTable();
                                    }
                                }

                                if (!uCGrantDetails.chkGrantCreatedOn.Items[i].Text.Equals("--- Select All ---"))
                                    uCGrantDetails.txtGrantCreatedOn.Text = uCGrantDetails.txtGrantCreatedOn.Text + "," + uCGrantDetails.chkGrantCreatedOn.Items[i].Text;
                            }
                        }
                        uCGrantDetails.txtGrantCreatedOn.Text = Convert.ToString(uCGrantDetails.txtGrantCreatedOn.Text).Trim(',');
                    }
                    uCGrantDetails.btnGDClearFilter.Visible = true;

                    /*If Search filter contains data*/
                    if ((dt_UnlockedFiltered != null && dt_UnlockedFiltered.Rows.Count > 0) || (dt_LockedFiltered != null && dt_LockedFiltered.Rows.Count > 0))
                    {
                        _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants = dt_UnlockedFiltered;

                        n_SearchResult = 1;
                    }

                    else
                    {
                        /*If no parameter selected for search*/
                        if (uCGrantDetails.txtGDGrantID.Text.Equals("--- Please Select ---") && uCGrantDetails.txtGDSchemeName.Text.Equals("--- Please Select ---") &&
                            uCGrantDetails.txtGDCurrency.Text.Equals("--- Please Select ---") && uCGrantDetails.txtGDReportStatus.Text.Equals("--- Please Select ---") &&
                          (string.IsNullOrEmpty(uCGrantDetails.calGDFromDate.Value) || uCGrantDetails.calGDFromDate.Value.Equals("dd/mmm/yyyy")) && (string.IsNullOrEmpty(uCGrantDetails.calGDToDate.Value) || uCGrantDetails.calGDToDate.Value.Equals("dd/mmm/yyyy")) &&
                            string.IsNullOrEmpty(uCGrantDetails.txtGDExercisePriceFrom.Text) && string.IsNullOrEmpty(uCGrantDetails.txtGDExercisePriceTo.Text) &&
                            string.IsNullOrEmpty(uCGrantDetails.txtVRGrpNumFrom.Text) && string.IsNullOrEmpty(uCGrantDetails.txtVRGrpNumTo.Text))
                        {
                            _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants = _gvUserControlModel.ac_SearchGrantDetails.dt_main_Unlocked_Valuation_Report != null && _gvUserControlModel.ac_SearchGrantDetails.dt_main_Unlocked_Valuation_Report.Rows.Count > 0 && _gvUserControlModel.ac_SearchGrantDetails.dt_main_Unlocked_Valuation_Report.Select("[Is_Locked] = false").Count() > 0 ? _gvUserControlModel.ac_SearchGrantDetails.dt_main_Unlocked_Valuation_Report.Select("[Is_Locked] = false").CopyToDataTable() : new DataTable();
                            n_SearchResult = 2;
                            uCGrantDetails.btnGDClearFilter.Visible = false;
                        }

                        /* Data Not Exists Case*/
                        else
                        {
                            uCGrantDetails.btnGDDelete.Visible = false;
                        }

                    }

                    if (n_SearchResult != 0)
                        BindGridView(gvUnlocked, gvLocked, _gvUserControlModel, s_PageName);
                }
                return n_SearchResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Bind Search GridView
        /// <summary>
        /// This method is used to bind grid view
        /// </summary>
        /// <param name="gvUnlocked">Unlocked grid-view</param>
        /// <param name="gvLocked">Locked grid-view</param>
        /// <param name="_gvUserControlModel">UserControlModel</param>
        /// <param name="s_PageName">Page Name</param>
        private void BindGridView(GridView gvUnlocked, GridView gvLocked, gvUserControlModel _gvUserControlModel, string s_PageName)
        {
            try
            {
                DataView view = new DataView();

                if (_gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants != null && _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0)
                {
                    view = new DataView(_gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants);
                    DataTable dt_unlocked = view.ToTable("DT", true, new string[] { "Action", "ID", "Grant Registration ID", "Grant Date", "Intrinsic Value", "Fair Value", "Currency", "Granted", "Cancelled", "Vested Cancelled", "Unvested Cancelled", "Lapsed", "Exercised", "Unvested", "Vested", "Outstanding", "Vesting Schedule", "Employee Details", "Actions", "AGRMID", "IS_MU_FV", "IS_MU_IV", "OPERATION_ID", "Status" }).Copy();

                    var groupedRecords = dt_unlocked.AsEnumerable().GroupBy(item => item.Field<string>("Grant Registration ID"));
                    var shortestRecords = groupedRecords.Select(grp => grp.OrderBy(item => item.Field<string>("Grant Date")).OrderByDescending(x => x.Field<int>("OPERATION_ID")).First());
                    using (DataTable dt_Records = shortestRecords.CopyToDataTable())
                    {
                        dt_Records.Columns.Remove("OPERATION_ID");
                        gvUnlocked.DataSource = dt_Records;
                        gvUnlocked.DataBind();
                        dt_unlocked.Dispose();
                    }
                }
                else
                {
                    gvUnlocked.DataSource = new DataTable();
                    gvUnlocked.DataBind();
                }
                view.Dispose();

                BindGridFromDB(s_PageName);
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Clear Filter
        /// <summary>
        /// This Method is used to Clear All Filters
        /// </summary>
        /// <param name="uCGrantDetails">uCGrantDetails</param>
        /// <param name="gvUnlocked">GridView gvUnlocked</param>
        /// <param name="gvLocked">GridView gvLocked</param>
        /// <param name="s_PageName">Page Name</param>
        internal void btnGDClearFilter_Click(UCGrantDetails uCGrantDetails, GridView gvUnlocked, GridView gvLocked, string s_PageName)
        {
            try
            {
                using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                {
                    _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants;
                    uCGrantDetails.btnGDClearFilter.Visible = false;

                    uCGrantDetails.txtGDGrantID.Text = uCGrantDetails.txtGDSchemeName.Text = uCGrantDetails.txtGDCurrency.Text = uCGrantDetails.txtGDReportStatus.Text = uCGrantDetails.txtGrantCreatedOn.Text = "--- Please Select ---";
                    uCGrantDetails.calGDFromDate.Value = uCGrantDetails.calGDToDate.Value =
                    uCGrantDetails.txtGDExercisePriceFrom.Text = uCGrantDetails.txtVRGrpNumFrom.Text =
                    uCGrantDetails.txtGDExercisePriceTo.Text = uCGrantDetails.txtVRGrpNumTo.Text = string.Empty;

                    BindGridView(gvUnlocked, gvLocked, _gvUserControlModel, s_PageName);
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Delete Grant(s)
        /// <summary>
        /// This Method is used to delete Grant(s)
        /// </summary>
        /// <param name="uCGrantDetails">uCGrantDetails</param>
        /// <returns>Result</returns>
        internal int btnGDDelete_Click(UCGrantDetails uCGrantDetails)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PopulateControls = "CUDGrantDetails";
                    accountingProperties.PageName = CommonConstantModel.s_GrantDetails;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.dt_DBGrantRegMaster = null;
                    accountingProperties.dt_DBGrantRegDetails = null;
                    accountingProperties.Action = "D";
                    accountingProperties.Grant_ID = string.IsNullOrEmpty(uCGrantDetails.hdnDeletedRecords.Value) ? string.Empty : uCGrantDetails.hdnDeletedRecords.Value.TrimStart(',');

                    string s_GroupNumber = ac_SearchGrantDetails.dt_all_Grants.Select("AGRMID = '" + uCGrantDetails.hdnDeletedRecords.Value.Split(',')[1] + "'")[0]["Group Number"].ToString();

                    // Determine whether the directory exists. 
                    if (Directory.Exists(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "/" + "FinalReport") + "\\" + "Group_No_" + s_GroupNumber))
                    {
                        Directory.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "/" + "FinalReport") + "\\" + "Group_No_" + s_GroupNumber, true);
                    }

                    string s_str = accountingProperties.Grant_ID.ToString();
                    uCGrantDetails.hdnDeletedRecords.Value = string.Empty;

                    if (s_str.Contains(","))
                    {
                        uCGrantDetails.hdnDeletedRecords.Value = string.Empty;
                    }

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    uCGrantDetails.btnVRProceed.Visible = false;
                    return (Convert.ToInt32(accountingCRUDProperties.dt_Result.Rows[0][0].ToString()));
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Add Grant Button Click Event
        /// <summary>
        /// This method is used for Add Grant Button Click Event
        /// </summary>
        /// <param name="uCGrantDetails">uCGrantDetails</param>
        internal void btnGDAddGrant_Click(UCGrantDetails uCGrantDetails)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    grantDetailsModel.ac_GrantDetails.dt_ViewDataEntered = null;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Redirect From GrantDetails
        /// <summary>
        /// This method is used to Goto Step after click on status on Grant Details page
        /// </summary>
        internal void RedirectFromGrantDetails()
        {
            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                _gvUserControlModel.ac_SearchGrantDetails.s_ChildPageName = "GrantDetails_GotoStep";
            }
        }
        #endregion

        #region Row Bound of gv2 GridView
        /// <summary>
        /// Row Bound of gv2 GridView
        /// </summary>
        /// <param name="e">e</param>
        /// <param name="n_index">index</param>
        /// <param name="n_DatList">DatList</param>
        /// <param name="n_MarketValue">MarketValue</param>
        internal void gv2_RowDataBound(GridViewRowEventArgs e, ref int n_index, ref int n_DatList, ref int n_MarketValue)
        {
            try
            {
                string s_roundingLimit = string.Empty;
                using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                {
                    for (int i = 0; i < e.Row.Cells.Count; i++)
                    {
                        try
                        {
                            s_roundingLimit = e.Row.Cells[0].Text.Contains("Intrinsic Value") ? "1" : e.Row.Cells[0].Text.Contains("Fair Value") ? "2" : e.Row.Cells[0].Text.Contains("Market Price") ? "3" : e.Row.Cells[0].Text.Contains("Exercise Price") ? "4" : e.Row.Cells[0].Text.Contains("Expected Life ") ? "5" : e.Row.Cells[0].Text.Contains("Volatility") ? "6" : e.Row.Cells[0].Text.Contains("Riskfree Rate") ? "7" : e.Row.Cells[0].Text.Contains("Dividend yield") ? "8" : "11";

                            e.Row.Cells[i].Text = e.Row.Cells[i].Text;

                            if (Convert.ToDouble(e.Row.Cells[i].Text) > 999)
                            {

                                e.Row.Cells[i].Text = CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[i].Text, DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Right;

                            }
                            else
                                e.Row.Cells[i].Text = CommonModel.GetRoundedValue(e.Row.Cells[i].Text, DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Right;
                        }
                        catch
                        {
                            // Do nothing
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// This method is used to View Uploaded Document
        /// </summary>
        /// <param name="uCGrantDetails">uCGrantDetails</param>
        internal void LinkButtonViewDocument_Click(UCGrantDetails uCGrantDetails)
        {
            try
            {
                using (gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    if (o_gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0)
                    {
                        DataTable dataTable = o_gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("[Grant Registration ID] = '" + uCGrantDetails.hdnGrantID.Value + "'").Count() > 0 ? o_gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Select("[Grant Registration ID] = '" + uCGrantDetails.hdnGrantID.Value + "'").CopyToDataTable() : new DataTable();

                        uCGrantDetails.gvViewDocument.DataSource = dataTable.DefaultView.ToTable(true, "Document Name", "Document Path", "Actions");
                        uCGrantDetails.gvViewDocument.DataBind();

                        uCGrantDetails.hdnShowGridOne.Value = "1";
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Row DataBound Event of gvViewDocument GridView
        /// </summary>
        /// <param name="uCGrantDetails">uCGrantDetails</param>
        /// <param name="e">e</param>
        internal void gvViewDocument_RowDataBound(UCGrantDetails uCGrantDetails, GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "DOCUMENT PATH":
                                    perColumn.Visible = false;
                                    break;

                                case "ACTIONS":
                                    perColumn.Text = "";
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[1].Visible = false;
                        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[2].Controls.Add(AddControl(uCGrantDetails, "HyperLink", "hplDownload", "Download", "Click here to download", e.Row.Cells[0].Text, string.Empty, e.Row.Cells[1].Text, "", "", string.Empty, "", string.Empty, string.Empty));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to get customize view details
        /// </summary>
        /// <param name="ucGrantDetails">object of UCGrantDetails page</param>
        internal void GetCustomizeViewData(UCGrantDetails ucGrantDetails)
        {
            string CustomizeView_ID = string.Empty;
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                using (DataTable dtDefaultView = CommonModel.GetDefaultViewList(userSessionInfo, CommonConstantModel.s_Get_Default_View, CommonConstantModel.s_MnuGrantDetails))
                {
                    CustomizeView_ID = dtDefaultView.Rows.Count > 0 ? dtDefaultView.Select("ISDEFAULT_VIEW=1").Count() > 0 ? Convert.ToString(dtDefaultView.Select("ISDEFAULT_VIEW=1")[0]["ID"]) : string.Empty : string.Empty;

                    genericProperties.PageName = CommonConstantModel.s_MnuGrantDetails;
                    genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    genericProperties.CustomizeView_ID = string.IsNullOrEmpty(Convert.ToString(ucGrantDetails.ddlDefaultView.SelectedValue)) ? CustomizeView_ID : Convert.ToString(ucGrantDetails.ddlDefaultView.SelectedValue);
                    ac_SearchGrantDetails.dt_CustmizedViewGrantDetails = (DataTable)genericServiceClient.GetCustomizedViewTable(genericProperties);
                }
            }

        }

        /// <summary>
        /// This method will check Adding / Editing Validation of Grant(s) against Locked Accounting Report 
        /// case 1:- if Accounting Report is Locked and user 
        ///          is trying to add a grant which Grant Date entered is before the Locked Reporting Date
        /// case 2:- if Report is locked and user is editing the 
        ///          grant which falls under Locked Accounting Report.
        /// Then the User is not allowed to add/edit the respective Grant
        /// </summary>
        /// <param name="s_GrantDate">string Grant Date</param>
        /// <param name="s_Action">string Action Add/Edit</param>
        /// <returns>int Count of Locked Reporting Date(s) Greater than Grant Date</returns>
        internal int CheckAgainstLockedAccountingReport(string s_GrantDate, string s_Action)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_ReportFilters;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.Type = "REPORT_DATA";

                    using (DataTable dt_ReportData = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[0].Copy())
                    {
                        if (dt_ReportData != null && dt_ReportData.Rows.Count > 0)
                            return (s_Action.Equals("Add") ? dt_ReportData.AsEnumerable().Where(b => b.Field<DateTime>("Accounting Report Date") >= Convert.ToDateTime(s_GrantDate)
                                                                        && b.Field<string>("IS_LOCKED") == "1").ToList().Count
                                                           : dt_ReportData.AsEnumerable().Where(b => b.Field<DateTime>("Accounting Report Date") >= Convert.ToDateTime(s_GrantDate)).ToList().Count);
                    }
                }

                return 0;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to load the selected view for login user.
        /// </summary>
        /// <param name="ucGrantDetails">ucGrantDetails page object</param>
        internal void SetDefaultView(UCGrantDetails ucGrantDetails)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    accountingProperties.PageName = CommonConstantModel.s_MnuGrantDetails;
                    accountingProperties.Operation = "SETDEFAULTVIEW";
                    accountingProperties.s_CustomizeViewPageName = CommonConstantModel.s_MnuAcceleratedVesting;
                    accountingProperties.s_ViewID = Convert.ToString(ucGrantDetails.ddlDefaultView.SelectedValue);
                    accountingProperties.IsDefault = true;

                    AccountingCRUDProperties accountingCRUDProperties = new AccountingCRUDProperties();
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            //ucGrantDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            //ucGrantDetails.ctrSuccessErrorMessage.lblMessage.Text = accountingServiceClient.GetAccounting_L10N("lblAVError", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                            //ucGrantDetails.ctrSuccessErrorMessage.lblMessage.ForeColor = Color.Red;
                            break;

                        case 1:

                            //ucGrantDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            //ucGrantDetails.ctrSuccessErrorMessage.lblMessage.Text = accountingServiceClient.GetAccounting_L10N("lblAVUpdated", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                            //ucGrantDetails.ctrSuccessErrorMessage.lblMessage.ForeColor = Color.Blue;
                            break;
                    }
                }

                BindGridView(ucGrantDetails, CommonConstantModel.s_GrantDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// This method is used to load the selected view for login user.
        /// </summary>
        /// <param name="ucGrantDetails">ucGrantDetails page object</param>
        internal void LoadSelcted_View(UCGrantDetails ucGrantDetails)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.PageName = CommonConstantModel.s_MnuGrantDetails;
                    genericProperties.CustomizeView_ID = Convert.ToString(ucGrantDetails.ddlDefaultView.SelectedValue);
                    genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_SearchGrantDetails.dt_CustmizedViewGrantDetails = (DataTable)genericServiceClient.GetCustomizedViewTable(genericProperties);
                }
                BindGridView(ucGrantDetails, CommonConstantModel.s_GrantDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// This method is used to load the default view for login user.
        /// </summary>
        /// <param name="ucGrantDetails">UCGrantDetails page object</param>
        internal void LoadDefault_ViewDropDowns(UCGrantDetails ucGrantDetails)
        {
            try
            {

                using (DataTable dtDefaultView = CommonModel.GetDefaultViewList(userSessionInfo, CommonConstantModel.s_Get_Default_View, CommonConstantModel.s_MnuGrantDetails))
                {
                    ucGrantDetails.ddlDefaultView.DataSource = dtDefaultView;
                    ucGrantDetails.ddlDefaultView.DataTextField = "VIEW_NAME";
                    ucGrantDetails.ddlDefaultView.DataValueField = "ID";
                    ucGrantDetails.ddlDefaultView.DataBind();
                    ucGrantDetails.ddlDefaultView.Items.Insert(0, new ListItem("--- Please Select ---", "0"));

                    if (dtDefaultView.Rows.Count > 0)
                    {
                        if (ucGrantDetails.ddlDefaultView.Items.Count > 0)
                        {
                            DataRow[] drr = dtDefaultView.Select("ISDEFAULT_VIEW=1");

                            if (drr.Length > 0)
                            {
                                ucGrantDetails.ddlDefaultView.SelectedValue = Convert.ToString(drr[0]["ID"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// This event is used to swtich between the pages of gv.
        /// </summary>
        /// <param name="uCGrantDetails">Object of a Class</param>
        /// <param name="sender">Button object</param>
        internal void btn_Click(UCGrantDetails uCGrantDetails, object sender)
        {

            BindGridView(uCGrantDetails, "GrantDetails");

        }

        /// <summary>
        /// This method is used to add pager for gridview
        /// </summary>
        /// <param name="uCGrantDetails">Page object</param>
        /// <param name="recordCount">RecordCount</param>
        /// <param name="currentPage">CurrentPage</param>
        /// <param name="n_pageIndex">n_pageIndex</param>
        private void PopulatePagerForGridView(UCGrantDetails uCGrantDetails, int recordCount, int currentPage, int n_pageIndex)
        {
            if (!recordCount.Equals(0))
            {
                double dblPageCount = (double)((decimal)recordCount / decimal.Parse("10"));
                int pageCount = (int)Math.Ceiling(dblPageCount);
                int n_TempCurrentPage = currentPage.Equals(1) ? 1 : Convert.ToInt32(Convert.ToInt32(currentPage / 10) + 9);

                int n_pageCount = 1, n_loopCount = 1;

                List<ListItem> pages = new List<ListItem>();
                if (pageCount > 0)
                {
                    for (int i = 1; i <= pageCount; i++)
                    {
                        pages.Add(new ListItem(i.ToString(), i.ToString() + "|" + n_pageCount, i != currentPage));

                        if (n_loopCount.Equals(10))
                        {
                            n_loopCount = 1;
                            n_pageCount = n_pageCount + 1;
                        }
                        else
                        {
                            n_loopCount++;
                        }
                    }
                }

                //Paging logic goes here  
                var v_Get10Records = pages.Skip((n_pageIndex - 1) * 10).Take(10).ToList();

                var NextFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 1;
                var NextLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 10;

                var PreviousFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 10;
                var PreviousLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 1;

                v_Get10Records.Insert(0, new ListItem("First", "1", currentPage > 1));

                if (currentPage > 10)
                {
                    v_Get10Records.Insert(1, new ListItem("....", PreviousFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1) + "-" + PreviousLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1), currentPage > 10));
                }

                if (pageCount > 10)
                {
                    v_Get10Records.Add(new ListItem("....", NextFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1) + "-" + NextLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1), currentPage < pageCount));
                }

                v_Get10Records.Add(new ListItem("Last", pageCount.ToString() + "|" + n_pageCount, currentPage < pageCount));

                uCGrantDetails.rptPager.DataSource = v_Get10Records;
                uCGrantDetails.rptPager.DataBind();
            }
        }

        /// <summary>
        /// This method is used to add pager for gridview
        /// </summary>
        /// <param name="uCGrantDetails">Page object</param>
        /// <param name="recordCount">RecordCount</param>
        /// <param name="currentPage">CurrentPage</param>
        /// <param name="n_pageIndex">n_pageIndex</param>
        private void PopulatePagerForGridView_Locked(UCGrantDetails uCGrantDetails, int recordCount, int currentPage, int n_pageIndex)
        {
            if (!recordCount.Equals(0))
            {
                double dblPageCount = (double)((decimal)recordCount / decimal.Parse("10"));
                int pageCount = (int)Math.Ceiling(dblPageCount);
                int n_TempCurrentPage = currentPage.Equals(1) ? 1 : Convert.ToInt32(Convert.ToInt32(currentPage / 10) + 9);

                int n_pageCount = 1, n_loopCount = 1;

                List<ListItem> pages = new List<ListItem>();
                if (pageCount > 0)
                {
                    for (int i = 1; i <= pageCount; i++)
                    {
                        pages.Add(new ListItem(i.ToString(), i.ToString() + "|" + n_pageCount, i != currentPage));

                        if (n_loopCount.Equals(10))
                        {
                            n_loopCount = 1;
                            n_pageCount = n_pageCount + 1;
                        }
                        else
                        {
                            n_loopCount++;
                        }
                    }
                }

                //Paging logic goes here  
                var v_Get10Records = pages.Skip((n_pageIndex - 1) * 10).Take(10).ToList();

                var NextFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 1;
                var NextLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) + 10;

                var PreviousFirst10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 10;
                var PreviousLast10 = Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').First()) - 1;

                v_Get10Records.Insert(0, new ListItem("First", "1", currentPage > 1));

                if (currentPage > 10)
                {
                    v_Get10Records.Insert(1, new ListItem("....", PreviousFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1) + "-" + PreviousLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) - 1), currentPage > 10));
                }

                if (pageCount > 10)
                {
                    v_Get10Records.Add(new ListItem("....", NextFirst10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1) + "-" + NextLast10 + "|" + (Convert.ToInt32(v_Get10Records[v_Get10Records.Count - 1].Value.Split('|').Last()) + 1), currentPage < pageCount));
                }

                v_Get10Records.Add(new ListItem("Last", pageCount.ToString() + "|" + n_pageCount, currentPage < pageCount));

                uCGrantDetails.rptPager_Locked.DataSource = v_Get10Records;
                uCGrantDetails.rptPager_Locked.DataBind();
            }
        }

        /// <summary>
        /// This method is used to move to next page
        /// </summary>
        /// <param name="uCGrantDetails">UCGrantDetails page object</param>
        /// <param name="pageIndex">PageIndex</param>
        internal void Page_IndexChangeing(UCGrantDetails uCGrantDetails, string pageIndex)
        {
            ac_SearchGrantDetails.n_FromAndToSelected = pageIndex.Split('-').Length > 1 ? "Selected" : string.Empty;
            ac_SearchGrantDetails.n_PageIndex = Convert.ToInt32(pageIndex.Split('-').First().Split('|').First());
            ac_SearchGrantDetails.n_PageSize = 10;
            BindGridView(uCGrantDetails, CommonConstantModel.s_GrantDetails);
            PopulatePagerForGridView(uCGrantDetails, ac_SearchGrantDetails.n_GridViewRecordsCount, Convert.ToInt32(pageIndex.Split('-').First().Split('|').First()), Convert.ToInt32(pageIndex.Split('-').First().Split('|').Last()));
        }

        /// <summary>
        /// This method is used to move to next page
        /// </summary>
        /// <param name="uCGrantDetails">UCGrantDetails page object</param>
        /// <param name="pageIndex">PageIndex</param>
        internal void Page_IndexChangeing_Locked(UCGrantDetails uCGrantDetails, string pageIndex)
        {
            ac_SearchGrantDetails.n_FromAndToSelected_Locked = pageIndex.Split('-').Length > 1 ? "Selected" : string.Empty;
            ac_SearchGrantDetails.n_PageIndex_Locked = Convert.ToInt32(pageIndex.Split('-').First().Split('|').First());
            ac_SearchGrantDetails.n_PageSize_Locked = 10;
            BindGridView(uCGrantDetails, CommonConstantModel.s_GrantDetails);
            PopulatePagerForGridView_Locked(uCGrantDetails, ac_SearchGrantDetails.n_GridViewRecordsCount_Locked, Convert.ToInt32(pageIndex.Split('-').First().Split('|').First()), Convert.ToInt32(pageIndex.Split('-').First().Split('|').Last()));
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~gvUserControlModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}