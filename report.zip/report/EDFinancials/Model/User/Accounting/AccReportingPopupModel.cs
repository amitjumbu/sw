﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Net;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Accounting Reporting Popup Model class
    /// </summary>
    public class AccReportingPopupModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default Constructor
        /// </summary>
        public AccReportingPopupModel()
        {
            if (ac_AccountingReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_AccountingReport);
                ac_AccountingReport = (CommonModel.AC_AccountingReport)HttpContext.Current.Session[CommonConstantModel.s_AC_AccountingReport];
            }
        }

        #endregion

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="accReportingPopup">accReportingPopup</param>
        /// <param name="s_ControlText">s_ControlText</param>
        /// <param name="s_ACC_RPT_GROUP_ID">s_ACC_RPT_GROUP_ID</param>
        /// <param name="s_VersionNumber">s_VersionNumber</param>
        internal void Page_Load(AccReportingPopup accReportingPopup, string s_ControlText, string s_ACC_RPT_GROUP_ID, string s_VersionNumber)
        {
            try
            {
                accReportingPopup.hdnARPControlText.Value = s_ControlText;
                accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value = s_ACC_RPT_GROUP_ID;
                accReportingPopup.hdnARPVersionNumber.Value = s_VersionNumber;
                BindControls(accReportingPopup);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind controls
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        private void BindControls(AccReportingPopup accReportingPopup)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accountingProperties = new AccountingProperties();

                switch (accReportingPopup.hdnARPControlText.Value.ToUpper())
                {
                    case "VIEW VERSIONS":
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PopulateControls = "GET_REPORT_BY_GROUP_ID";
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value);
                        ac_AccountingReport.dt_CommentLog = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[0];
                        accReportingPopup.gvARPReportVersions.DataSource = ac_AccountingReport.dt_CommentLog;
                        accReportingPopup.gvARPReportVersions.DataBind();
                        break;

                    case "INVOICE":
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PopulateControls = "GET_REPORT_BY_GROUP_ID";
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value);

                        using (DataTable dt_InvoiceDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[2])
                        {
                            accReportingPopup.txtARPInvoiceNo.Text = Convert.ToString(dt_InvoiceDetails.Rows[0]["INVOICE_NUMBER"]);
                            if (!string.IsNullOrEmpty(Convert.ToString(dt_InvoiceDetails.Rows[0]["INVOICE_DATE"])))
                                accReportingPopup.txtARPInvoiceDate.Text = Convert.ToDateTime(dt_InvoiceDetails.Rows[0]["INVOICE_DATE"]).ToString("dd/MMM/yyyy");
                        }

                        break;

                    case "UPLOADS":
                        accountingProperties = new AccountingProperties();
                        accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.PopulateControls = "GET_REPORT_BY_GROUP_ID";
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value);
                        ac_AccountingReport.dt_UploadedFiles = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[1];
                        accReportingPopup.gvARPUploadedFiles.DataSource = ac_AccountingReport.dt_UploadedFiles;
                        accReportingPopup.gvARPUploadedFiles.DataBind();
                        break;
                }

                using (AccReportingCommonModel accReportingCommonModel = new AccReportingCommonModel())
                {
                    accReportingCommonModel.GetDataForLockedCondition(Convert.ToInt32(accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value));

                    accReportingCommonModel.GetAllReportsData();
                }
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        /// <param name="e">event args</param>
        internal void gvARPReportVersions_PageIndexChanging(AccReportingPopup accReportingPopup, GridViewPageEventArgs e)
        {
            accReportingPopup.gvARPReportVersions.PageIndex = e.NewPageIndex;
            accReportingPopup.gvARPReportVersions.DataSource = ac_AccountingReport.dt_CommentLog;
            accReportingPopup.gvARPReportVersions.DataBind();
        }

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        /// <param name="e">event args</param>
        /// <param name="n_Index">n_Index</param>
        /// <param name="n_ACC_RPT_GROUP_ID">n_ACC_RPT_GROUP_ID</param>
        /// <param name="n_Report_Vesion">n_Report_Vesion</param>
        /// <param name="n_Comments">n_Comments</param>
        /// <param name="n_TypeoOfUser">n_TypeoOfUser</param>
        /// <param name="n_CreatedOn">n_CreatedOn</param>
        /// <param name="n_ReportNameToDownload">n_ReportNameToDownload</param>
        /// <param name="n_Action">n_Action</param>
        internal void gvARPReportVersions_RowDataBound(AccReportingPopup accReportingPopup, GridViewRowEventArgs e, ref int n_Index, ref int n_ACC_RPT_GROUP_ID, ref int n_Report_Vesion, ref int n_Comments, ref int n_TypeoOfUser, ref int n_CreatedOn, ref int n_ReportNameToDownload, ref int n_Action)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "REPORT VERSION":
                                    n_Report_Vesion = n_Index;
                                    break;
                                case "ACC_RPT_GROUP_ID":
                                    n_ACC_RPT_GROUP_ID = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "COMMENTS":
                                    n_Comments = n_Index;
                                    break;
                                case "TYPE OF USER":
                                    n_TypeoOfUser = n_Index;
                                    break;
                                case "CREATED ON":
                                    n_CreatedOn = n_Index;
                                    break;
                                case "REPORT_NAME":
                                    n_ReportNameToDownload = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "ACTION":
                                    n_Action = n_Index;
                                    break;
                            }
                            n_Index++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_ACC_RPT_GROUP_ID].Visible = e.Row.Cells[n_ReportNameToDownload].Visible = false;
                        e.Row.Cells[n_Report_Vesion].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_CreatedOn].HorizontalAlign = e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        if (!string.IsNullOrEmpty(e.Row.Cells[n_CreatedOn].Text) && !e.Row.Cells[n_CreatedOn].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_CreatedOn].Text = Convert.ToDateTime(e.Row.Cells[n_CreatedOn].Text).ToString("dd/MMM/yyyy");
                        e.Row.Cells[n_Action].Controls.Add(AddLinkButton("Download", "Click here to download report and workings", "lBtnARPDownload", e.Row.Cells[n_ACC_RPT_GROUP_ID].Text, e.Row.Cells[n_Report_Vesion].Text, e.Row.Cells[n_ReportNameToDownload].Text));

                        if (e.Row.RowIndex > 0)
                        {
                            int RowIndex = 1, Count = 1;
                            MergeCells(accReportingPopup.gvARPReportVersions, e, n_Report_Vesion, ref RowIndex, ref Count, ref n_Action);
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to merge cells
        /// </summary>
        /// <param name="gridView">gridView</param>
        /// <param name="e">e</param>
        /// <param name="n_Report_Vesion">n_Report_Vesion</param>
        /// <param name="RowIndex">RowIndex</param>
        /// <param name="Count">Count</param>
        /// <param name="n_Action">n_Action</param>
        private void MergeCells(GridView gridView, GridViewRowEventArgs e, int n_Report_Vesion, ref int RowIndex, ref int Count, ref int n_Action)
        {
            for (int intLoop = 1; intLoop <= e.Row.RowIndex; intLoop++)
            {
                Count++;
                if ((!gridView.Rows[e.Row.RowIndex - intLoop].Cells[n_Report_Vesion].Text.Equals(string.Empty)) && (e.Row.Cells[n_Report_Vesion].Text == gridView.Rows[e.Row.RowIndex - intLoop].Cells[n_Report_Vesion].Text))
                {
                    RowIndex = intLoop;
                    break;
                }
            }

            if (e.Row.Cells[n_Report_Vesion].Text == gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_Report_Vesion].Text)
            {
                e.Row.Cells[n_Report_Vesion].Text = e.Row.Cells[n_Action].Text = "";
                e.Row.Cells[n_Report_Vesion].Visible = e.Row.Cells[n_Action].Visible = false;
                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_Report_Vesion].RowSpan = gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_Action].RowSpan = Count;
            }
        }

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        /// <param name="e">event args</param>
        /// <param name="n_UP_Index">n_UP_Index</param>
        /// <param name="n_UP_ARUDID">n_UP_ARUDID</param>
        /// <param name="n_UP_DocumentName">n_UP_DocumentName</param>
        /// <param name="n_UP_UploadedBy">n_UP_UploadedBy</param>
        /// <param name="n_UP_Download">n_UP_Download</param>
        /// <param name="n_UP_Delete">n_UP_Delete</param>
        internal void gvARPUploadedFiles_RowDataBound(AccReportingPopup accReportingPopup, GridViewRowEventArgs e, ref int n_UP_Index, ref int n_UP_ARUDID, ref int n_UP_DocumentName, ref int n_UP_UploadedBy, ref int n_UP_Download, ref int n_UP_Delete)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ARUDID":
                                    n_UP_ARUDID = n_UP_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "DOCUMENT NAME":
                                    n_UP_DocumentName = n_UP_Index;
                                    break;
                                case "UPLOADED BY":
                                    n_UP_UploadedBy = n_UP_Index;
                                    break;
                                case "DOWNLOAD":
                                    n_UP_Download = n_UP_Index;
                                    break;
                                case "DELETE":
                                    n_UP_Delete = n_UP_Index;
                                    break;
                            }
                            n_UP_Index++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_UP_ARUDID].Visible = false;
                        e.Row.Cells[n_UP_UploadedBy].HorizontalAlign = e.Row.Cells[n_UP_Download].HorizontalAlign = e.Row.Cells[n_UP_Delete].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_UP_Download].Controls.Add(AddImageButton("Click here to download", "imgDocDownload", "~/View/App_Themes/images/download.png", "Download", accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value, e.Row.Cells[n_UP_DocumentName].Text, e.Row.Cells[n_UP_ARUDID].Text.Trim()));
                        e.Row.Cells[n_UP_Delete].Controls.Add(AddImageButton("Click here to delete", "imgDocDelete", "~/View/App_Themes/images/Delete.png", "Delete", accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value, e.Row.Cells[n_UP_DocumentName].Text, e.Row.Cells[n_UP_ARUDID].Text.Trim()));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        /// <param name="e">event args</param>
        internal void gvARPUploadedFiles_PageIndexChanging(AccReportingPopup accReportingPopup, GridViewPageEventArgs e)
        {
            try
            {
                accReportingPopup.gvARPUploadedFiles.PageIndex = e.NewPageIndex;
                accReportingPopup.gvARPUploadedFiles.DataSource = ac_AccountingReport.dt_UploadedFiles;
                accReportingPopup.gvARPUploadedFiles.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method returns LinkButton control object
        /// </summary>
        /// <param name="s_ControlText">s_ControlText</param>
        /// <param name="s_ControlTooltip">s_ControlTooltip</param>
        /// <param name="s_ControlID">s_ControlID</param>
        /// <param name="s_ACC_RPT_GROUP_ID">s_ACC_RPT_GROUP_ID</param>
        /// <param name="n_Report_Vesion">n_Report_Vesion</param>
        /// <param name="s_ReportNameToDownload">s_ReportNameToDownload</param>
        /// <returns>returns LinkButton control object</returns>
        private LinkButton AddLinkButton(string s_ControlText, string s_ControlTooltip, string s_ControlID, string s_ACC_RPT_GROUP_ID, string n_Report_Vesion, string s_ReportNameToDownload)
        {
            try
            {
                using (LinkButton linkButton = new LinkButton())
                {
                    linkButton.ToolTip = s_ControlTooltip;
                    linkButton.Attributes.Add("style", "cursor:pointer;padding:5px;color: blue; text-decoration: underline;");
                    linkButton.Text = s_ControlText;
                    linkButton.ID = s_ControlID;
                    linkButton.Attributes.Add("onclick", "return DownloadReports('" + n_Report_Vesion + "','" + s_ACC_RPT_GROUP_ID + "','" + s_ReportNameToDownload + "')");
                    return linkButton;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// method returns ImageButton control object
        /// </summary>
        /// <param name="s_ControlTooltip">s_ControlTooltip</param>
        /// <param name="s_ControlID">s_ControlID</param>
        /// <param name="s_ImgURL">s_ImgURL</param>
        /// <param name="s_Type">s_Type</param>
        /// <param name="s_ACC_RPT_GROUP_ID">s_ACC_RPT_GROUP_ID</param>
        /// <param name="s_FileName">s_FileName</param>
        /// <param name="s_ARUDID">s_ARUDID</param>
        /// <returns>returns ImageButton control object</returns>
        private ImageButton AddImageButton(string s_ControlTooltip, string s_ControlID, string s_ImgURL, string s_Type, string s_ACC_RPT_GROUP_ID, string s_FileName, string s_ARUDID)
        {
            try
            {
                using (ImageButton linkButton = new ImageButton())
                {
                    linkButton.ToolTip = s_ControlTooltip;
                    linkButton.Attributes.Add("style", "cursor:pointer;padding:5px;color: blue; text-decoration: underline;");
                    linkButton.ID = s_ControlID;
                    linkButton.ImageUrl = s_ImgURL;
                    if (s_Type.Equals("Delete"))
                        linkButton.Attributes.Add("onclick", "return DeleteDocument('" + s_ACC_RPT_GROUP_ID + "','" + s_FileName + "','" + s_ARUDID + "')");
                    else if (s_Type.Equals("Download"))
                        linkButton.Attributes.Add("onclick", "return DownloadDocument('" + s_ACC_RPT_GROUP_ID + "','" + s_FileName + "')");
                    return linkButton;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Invoice save button click event
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        internal void btnARPInvoiceSave_Click(AccReportingPopup accReportingPopup)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.PopulateControls = CommonConstantModel.s_CUDReportData;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value);
                    accountingProperties.VERSION_NUMBER = Convert.ToInt32(accReportingPopup.hdnARPVersionNumber.Value);
                    accountingProperties.INVOICE_NUMBER = accReportingPopup.txtARPInvoiceNo.Text;
                    accountingProperties.INVOICE_DATE = accReportingPopup.txtARPInvoiceDate.Text;
                    accountingProperties.REVIEWER_APPROVAL_STATUS = 2;
                    accountingProperties.IS_SENT_FOR_REVIEW = true;
                    accountingProperties.CLIENT_APPROVAL_STATUS = 2;
                    accountingProperties.IS_SENT_TO_CLIENT = true;
                    accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                    accountingProperties.Action = "U";
                    if (Convert.ToInt32(accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result.Rows[0]["Result"]).Equals(2))
                        ShowHideMessageDiv(accReportingPopup, "InvoiceNoSaveSuccessMsg", false);
                    BindControls(accReportingPopup);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// File upload save button click event
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        internal void btnARPFileUploadSave_Click(AccReportingPopup accReportingPopup)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (accReportingPopup.fileUpARPFileUpload.HasFile && !string.IsNullOrEmpty(accReportingPopup.fileUpARPFileUpload.FileName))
                    {
                        if (accReportingPopup.fileUpARPFileUpload.FileName.EndsWith(".pdf"))
                        {
                            if (accReportingPopup.fileUpARPFileUpload.FileContent.Length <= 10485760)
                            {
                                accountingProperties = new AccountingProperties();
                                accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                                accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                                accountingProperties.PopulateControls = "CUD_REPORT_DOCUMENTS";
                                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value);
                                if (SaveFileToServer(accReportingPopup) == 1)
                                {
                                    accountingProperties.DOCUMENT_NAME = accReportingPopup.fileUpARPFileUpload.FileName;
                                    accountingProperties.IS_DELETED = false;
                                    accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                                    switch (accountingServiceClient.CRUDAccountingOperations(accountingProperties).a_result)
                                    {
                                        case 1: ShowHideMessageDiv(accReportingPopup, "DocumentUploadedSuccessMsg", false); break;
                                        case 2: ShowHideMessageDiv(accReportingPopup, "DocumentDeletedSuccessMsg", false); break;
                                        case 3: ShowHideMessageDiv(accReportingPopup, "DocumentAlreadyExistsErrorMsg", true); break;
                                    }
                                }
                                else ShowHideMessageDiv(accReportingPopup, "DocumentAlreadyExistsErrorMsg", true);
                            }
                            else ShowHideMessageDiv(accReportingPopup, "FileSizeErrorMsg", true);
                        }
                        else ShowHideMessageDiv(accReportingPopup, "InvalidFileExtErrorMsg", true);
                    }
                    else ShowHideMessageDiv(accReportingPopup, "PleaseUploadDocument", true);
                }
                BindControls(accReportingPopup);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// FIle delete button click event
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        internal void btnARPFileDelete_Click(AccReportingPopup accReportingPopup)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {

                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_ReportFilters;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.Type = "REPORT_DATA";

                    using (DataTable dt_ReportData = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[0].Copy())
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value)) && dt_ReportData != null && dt_ReportData.Rows.Count > 0 && dt_ReportData.Select("IS_LOCKED = 1 AND ACC_RPT_GROUP_ID = '" + Convert.ToInt32(accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value) + "'").Length.Equals(0))
                        {
                            accountingProperties = new AccountingProperties();
                            accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                            accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                            accountingProperties.PopulateControls = "CUD_REPORT_DOCUMENTS";
                            accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value);
                            DeleteFileFromServer(accReportingPopup);
                            accountingProperties.DOCUMENT_NAME = accReportingPopup.hdnARPFileName.Value;
                            accountingProperties.ARUDID = Convert.ToInt32(accReportingPopup.hdnARP_ARUDID.Value);
                            accountingProperties.IS_DELETED = true;
                            accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                            accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                        }
                        else
                        {
                            accountingCRUDProperties.a_result = 4;
                        }
                    }

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 1: ShowHideMessageDiv(accReportingPopup, "DocumentUploadedSuccessMsg", false); break;
                        case 2: ShowHideMessageDiv(accReportingPopup, "DocumentDeletedSuccessMsg", false); break;
                        case 3: ShowHideMessageDiv(accReportingPopup, "DocumentAlreadyExistsErrorMsg", true); break;
                        case 4: ShowHideMessageDiv(accReportingPopup, "DocumentReportLocked", true); break;
                    }
                    BindControls(accReportingPopup);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to clear file content
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        internal void btnARPClearFileContent_Click(AccReportingPopup accReportingPopup)
        {
            try
            {
                accReportingPopup.fileUpARPFileUpload.ClearAllFilesFromPersistedStore();
                BindControls(accReportingPopup);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This is used to hide/show message div
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        /// <param name="s_Msg">s_Msg</param>
        /// <param name="b_IsError">b_IsError</param>
        private void ShowHideMessageDiv(AccReportingPopup accReportingPopup, string s_Msg, bool b_IsError)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accReportingPopup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N(s_Msg, CommonConstantModel.s_AccountingReport, CommonConstantModel.s_AccountingL10);
                accReportingPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                accReportingPopup.ctrSuccessErrorMessage.s_MsgForeColor = b_IsError ? Color.Red : Color.Blue;
            }
        }

        /// <summary>
        /// This method is used to save file to the server
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        /// <returns>returns file name</returns>
        public int SaveFileToServer(AccReportingPopup accReportingPopup)
        {
            try
            {
                return UploadFile(accReportingPopup.fileUpARPFileUpload, HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/" + "FinalReport/" + accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value.Trim() + "/"));
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to delete file from server
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        public void DeleteFileFromServer(AccReportingPopup accReportingPopup)
        {
            try
            {
                if (File.Exists(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/" + "FinalReport/" + accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value.Trim() + "/") + accReportingPopup.hdnARPFileName.Value.Trim()))
                    File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/" + "FinalReport/" + accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value.Trim() + "/") + accReportingPopup.hdnARPFileName.Value.Trim());
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to upload file
        /// </summary>
        /// <param name="asyncFileUpload">asyncFileUpload</param>
        /// <param name="s_FolderPath">s_FolderPath</param>
        /// <returns>returns file path</returns>
        private int UploadFile(AjaxControlToolkit.AsyncFileUpload asyncFileUpload, string s_FolderPath)
        {
            try
            {
                string s_FilePath = string.Empty, s_FileName = string.Empty;
                s_FileName = Path.GetFileName(asyncFileUpload.FileName);
                if (!Directory.Exists(s_FolderPath))
                {
                    Directory.CreateDirectory(s_FolderPath);
                    s_FilePath = s_FolderPath + s_FileName;
                }
                else if (!File.Exists(s_FolderPath + s_FileName))
                    s_FilePath = s_FolderPath + s_FileName;

                if (!string.IsNullOrEmpty(s_FilePath))
                    asyncFileUpload.SaveAs(s_FilePath);
                else return 2;
                return 1;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// File download button click event
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        public void btnARPFileDownload_Click(AccReportingPopup accReportingPopup)
        {
            try
            {
                using (WebClient o_WebClient = new WebClient())
                {
                    HttpResponse o_HttpResponse = HttpContext.Current.Response;
                    o_HttpResponse.Clear();
                    o_HttpResponse.ClearContent();
                    o_HttpResponse.ClearHeaders();
                    o_HttpResponse.Buffer = true;
                    accReportingPopup.Response.AddHeader("Content-Disposition", "attachment;filename=" + accReportingPopup.hdnARPFileName.Value);
                    o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/" + "FinalReport/" + accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value.Trim() + "/" + accReportingPopup.hdnARPFileName.Value)));
                    // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.Flush();
                    // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.Response.SuppressContent = true;
                    // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Download report button click event
        /// </summary>
        /// <param name="accReportingPopup">AccReportingPopup page object</param>
        public void imgARPDownloadReport_Click(AccReportingPopup accReportingPopup)
        {
            try
            {
                using (WebClient o_WebClient = new WebClient())
                {
                    HttpResponse o_HttpResponse = HttpContext.Current.Response;
                    o_HttpResponse.ClearContent();
                    o_HttpResponse.ClearHeaders();
                    o_HttpResponse.Buffer = true;
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + accReportingPopup.hdnARPReportNameToDownload.Value.Trim() + ".pdf");
                    o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ACCTemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/FinalReport/" + "Group_No_" + accReportingPopup.hdnARPACC_RPT_GROUP_ID.Value.Trim() + "/" + accReportingPopup.hdnARPReportNameToDownload.Value.Trim() + ".pdf").Replace("/", "\\")));
                    // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.Flush();
                    // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.Response.SuppressContent = true;
                    // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.  
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method returns SSRS query string
        /// </summary>
        /// <param name="s_ACC_RPT_GROUP_ID">s_ACC_RPT_GROUP_ID</param>
        /// <param name="s_VERSION_NUMBER">s_VERSION_NUMBER</param>
        /// <param name="s_ControlID">s_ControlID</param>
        /// <returns>returns SSRS query string</returns>
        internal string GetSSRSReportQueryString(object s_ACC_RPT_GROUP_ID, object s_VERSION_NUMBER, object s_ControlID)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "GET_WORKING_DETAILS_BY_VERSION";
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(s_ACC_RPT_GROUP_ID);
                    accountingProperties.VERSION_NUMBER = Convert.ToInt32(s_VERSION_NUMBER);
                    DataTable dt_Details = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[0];
                    string s_QueryStr = string.Empty;
                    switch (Convert.ToString(s_ControlID))
                    {
                        case "imgARPDownloadCancellation":
                            s_QueryStr = Convert.ToString(
                                genericServiceClient.EncryptString("RptID=14").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("REPORTING_DATE={0}", dt_Details.Rows[0]["REPORTING_DATE"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("MARKET_PRICE_TYPE={0}", dt_Details.Rows[0]["MARKET_PRICE_TYPE"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("SCHEME_NAME={0}", dt_Details.Rows[0]["SCHEME_NAME"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_ID={0}", dt_Details.Rows[0]["EMPLOYEE_ID"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_NAME={0}", dt_Details.Rows[0]["EMPLOYEE_NAME"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("GRANT_REG_ID={0}", dt_Details.Rows[0]["GRANT_REGISTRATION_ID"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("GRANT_OPTION_ID={0}", dt_Details.Rows[0]["GRANT_OPTION_ID"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("SENIOR_MANAGEMENT={0}", (Convert.ToString(dt_Details.Rows[0]["IS_SENIOR_MANAGEMENT"]).Equals("1")) ? "Yes" : "No")).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("GRANT_FROM_DATE={0}", dt_Details.Rows[0]["GRANT_FROM_DATE"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("GRANT_TO_DATE={0}", dt_Details.Rows[0]["GRANT_TO_DATE"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_FOR={0}", dt_Details.Rows[0]["DISPLAY_COST_FOR"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_YR_FROM"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_YR_TO"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_QTR_FROM"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_QTR_TO"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_MONTH_FROM"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_MONTH_TO"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("OPTIONS={0}", string.Empty)).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("CANCELLATION_FROM_DATE={0}", string.Empty)).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("CANCELLATION_TO_DATE={0}", string.Empty)).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("ACC_RPT_GROUP_ID={0}", dt_Details.Rows[0]["ACC_RPT_GROUP_ID"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("VERSION_NUMBER={0}", dt_Details.Rows[0]["VERSION_NUMBER"])).Replace("+", "%2B")
                                 + "&" + genericServiceClient.EncryptString(string.Format("CALCULATION_METHOD={0}", userSessionInfo.ACC_CalculationMethod)).Replace("+", "%2B"));
                            break;
                        case "imgARPDownloadGWVWReport":
                            s_QueryStr = Convert.ToString(
                    genericServiceClient.EncryptString("RptID=12").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("REPORTING_DATE={0}", dt_Details.Rows[0]["REPORTING_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("MARKET_PRICE_TYPE={0}", dt_Details.Rows[0]["MARKET_PRICE_TYPE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("SCHEME_NAME={0}", dt_Details.Rows[0]["SCHEME_NAME"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_ID={0}", dt_Details.Rows[0]["EMPLOYEE_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_NAME={0}", dt_Details.Rows[0]["EMPLOYEE_NAME"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_REG_ID={0}", dt_Details.Rows[0]["GRANT_REGISTRATION_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_OPTION_ID={0}", dt_Details.Rows[0]["GRANT_OPTION_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("SENIOR_MANAGEMENT={0}", (Convert.ToString(dt_Details.Rows[0]["IS_SENIOR_MANAGEMENT"]).Equals("1")) ? "Yes" : "No")).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_FROM_DATE={0}", dt_Details.Rows[0]["GRANT_FROM_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_TO_DATE={0}", dt_Details.Rows[0]["GRANT_TO_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_FOR={0}", dt_Details.Rows[0]["DISPLAY_COST_FOR"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_YR_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_YR_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_QTR_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_QTR_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_MONTH_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_MONTH_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("ACC_RPT_GROUP_ID={0}", dt_Details.Rows[0]["ACC_RPT_GROUP_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("VERSION_NUMBER={0}", dt_Details.Rows[0]["VERSION_NUMBER"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("CALCULATION_METHOD={0}", userSessionInfo.ACC_CalculationMethod)).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_BEFORE={0}", dt_Details.Rows[0]["DISPLAY_COST_BEFORE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_AFTER={0}", dt_Details.Rows[0]["DISPLAY_COST_AFTER"])).Replace("+", "%2B"));
                            break;
                    }
                    return s_QueryStr;
                }
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~AccReportingPopupModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}