﻿using EDFinancials.Model.Generic;
using System;
using System.Data;
using System.Linq;
using System.Web;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// 
    /// </summary>
    public class GetValuationParameters : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public GetValuationParameters()
        {
            if (ac_SearchGrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_SearchGrantDetails);
                ac_SearchGrantDetails = (CommonModel.AC_SearchGrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_SearchGrantDetails];
            }
        }

        /// <summary>
        /// Calculate FV and IV
        /// </summary>
        /// <param name="dt_Details">Original data-table</param>
        /// <param name="s_Select">FairValue/IntrinsicValue</param>
        /// <returns>Calculated values in form of datatable</returns>
        public DataTable GetCalculationsIVnFV(ref DataTable dt_Details, string s_Select)
        {
            try
            {
                using (DataView dataView = new DataView())
                {
                    string s_DecimalLimit = string.Empty;
                    string s_Currency = Convert.ToString(dt_Details.Rows[0]["Currency"]);
                    string s_GrantDate = "Date of Grant: " + dt_Details.Rows[0]["Grant Date"].ToString();
                    ac_SearchGrantDetails.s_FairValue = dt_Details.Rows[0][s_Select.Equals("FairValue") ? "Fair Value" : "Intrinsic Value"].ToString();
                    ac_SearchGrantDetails.s_FinalValue = s_Select.Equals("FairValue") ? " Fair Value Per Option (" + s_Currency + ")" : "Final Intrinsic Value";
                    s_DecimalLimit = ac_SearchGrantDetails.s_FinalValue.Contains("Fair Value") ? "2" : "1";

                    try
                    {
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (userSessionInfo.ACC_IsListed == 1 && Convert.ToDouble(ac_SearchGrantDetails.s_FairValue) > 999)
                            {

                                ac_SearchGrantDetails.s_FairValue = CommonModel.ThousandFormating(CommonModel.GetRoundedValue(ac_SearchGrantDetails.s_FairValue, DecimalLimitTable.Select("ADVSID = '" + s_DecimalLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = '" + s_DecimalLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            else
                                ac_SearchGrantDetails.s_FairValue = CommonModel.GetRoundedValue(ac_SearchGrantDetails.s_FairValue, DecimalLimitTable.Select("ADVSID = '" + s_DecimalLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                        }
                    }
                    catch (Exception)
                    {
                        // Do nothing
                    }

                    dt_Details = new DataView(dt_Details).ToTable
                                    ("DT", false,
                                        s_Select.Equals("FairValue") ?
                                            new string[] { "Vesting Date", "Market Price Per Vest", "Expected Life Per Vest", "Volatility Per Vest", "RFIR Per Vest", "Exercise Price", "Dividend Per Vest", "Fair Value per vest", "Vest Percent (%)", "IS_MU_MKT_FV", "IS_MU_EXL", "IS_MU_VOL", "IS_MU_RFIR", "IS_MU_DIVD", "IS_MU_DIVD_MP_DIVD" } :
                                            new string[] { "Vesting Date", "Market Price IV", "Exercise Price", "Intrinsic Value per vest", "IS_MU_MKT_IV"}
                                    ).Copy();

                    using (DataTable dt_outputTable = new DataTable())
                    {
                        if (!s_Select.Equals("FairValue"))
                        {
                            dt_Details.Columns["Market Price IV"].ColumnName = "Market Price (A)";
                            dt_Details.Columns["Exercise Price"].ColumnName = "Exercise Price (B)";
                            dt_Details.Columns["Intrinsic Value per vest"].ColumnName = "Intrinsic Value (A-B)";
                        }
                        else
                        {
                            dt_Details.Columns["Market Price Per Vest"].ColumnName = "Market Price (" + s_Currency + ")";
                            dt_Details.Columns["Expected Life Per Vest"].ColumnName = "Expected Life";
                            dt_Details.Columns["Volatility Per Vest"].ColumnName = "Volatility (%)";
                            dt_Details.Columns["RFIR Per Vest"].ColumnName = "Riskfree Rate (%)";
                            dt_Details.Columns["Dividend Per Vest"].ColumnName = "Dividend yield (%)";
                            dt_Details.Columns["Exercise Price"].ColumnName = "Exercise Price (" + s_Currency + ")";
                            dt_Details.Columns["Fair Value per vest"].ColumnName = "Fair Value per vest (" + s_Currency + ")";
                        }
                       
                        // Header row's first column is same as in inputTable
                        dt_outputTable.Columns.Add(dt_Details.Columns[0].ColumnName.ToString());

                        int i = 1;
                        foreach(DataRow perRow in dt_Details.Rows)
                        {
                            DataColumn dataColumn = new DataColumn("Vest " + i + ": " + Convert.ToString(perRow["Vesting Date"]), typeof(string));
                            dt_outputTable.Columns.Add(dataColumn);
                            i++;
                        }
                        dt_outputTable.Columns["Vesting Date"].ColumnName = s_GrantDate;
                        dt_outputTable.Columns.Add("Is_Manually_Updated", typeof(string));

                        for (int rCount = 1; rCount <= dt_Details.Columns.Count - 1; rCount++)
                        {
                            DataRow newRow = dt_outputTable.NewRow();

                            for (int cCount = 0; cCount <= dt_Details.Rows.Count - 1; cCount++)
                            {
                                newRow[0] = dt_Details.Columns[rCount].ColumnName.ToString();
                                newRow[cCount + 1] = dt_Details.Rows[cCount][rCount].ToString();
                            }
                            if(newRow[0].Equals("Dividend yield (%)") || newRow[0].Equals("Fair Value per vest (" + s_Currency + ")"))
                            {
                                dt_outputTable.Rows.Add(newRow);
                                dt_outputTable.Rows.Add(dt_outputTable.NewRow());
                            }
                            else
                            {
                                dt_outputTable.Rows.Add(newRow);

                                switch (dt_outputTable.Rows[dt_outputTable.Rows.Count - 1][0].ToString())
                                {
                                    case "IS_MU_MKT_FV":
                                        if (dt_Details.Rows[0]["IS_MU_MKT_FV"].ToString() == "True")
                                            dt_outputTable.Rows[0]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_MKT_IV":
                                        if (dt_Details.Rows[0]["IS_MU_MKT_IV"].ToString() == "True")
                                            dt_outputTable.Rows[0]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_EXL":
                                        if (dt_Details.Rows[0]["IS_MU_EXL"].ToString() == "True")
                                            dt_outputTable.Rows[1]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_VOL":
                                        if (dt_Details.Rows[0]["IS_MU_VOL"].ToString() == "True")
                                            dt_outputTable.Rows[2]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_RFIR":
                                        if (dt_Details.Rows[0]["IS_MU_RFIR"].ToString() == "True")
                                            dt_outputTable.Rows[3]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_DIVD":
                                        if (dt_Details.Rows[0]["IS_MU_DIVD"].ToString() == "True")
                                            dt_outputTable.Rows[5]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_DIVD_MP_DIVD":
                                        if (dt_Details.Rows[0]["IS_MU_DIVD_MP_DIVD"].ToString() == "True")
                                            dt_outputTable.Rows[5]["Is_Manually_Updated"] = "1";
                                        break;
                                }
                            }
                        }

                        dt_outputTable.AcceptChanges();

                        ac_SearchGrantDetails.n_VestCount = dt_outputTable.Columns.Count;
                        ac_SearchGrantDetails.n_RowCount = dt_outputTable.Rows.Count;
                        return dt_outputTable;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Create DataTable for Valuation Parameters
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable CreateDataTable(string s_StepName)
        {
            try
            {
                using (DataTable dt_tempValuationParameters = new DataTable("DT"))
                {
                    switch (s_StepName)
                    {
                        case "SelectGrants":
                            dt_tempValuationParameters.Columns.Add("Parameters selected for grant", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Company Level", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Present Grant Parameters", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Is Manual Uploaded", typeof(string));
                            break;

                        case "CompareGrants":
                            dt_tempValuationParameters.Columns.Add("Parameters selected for grant", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Company Level", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Update Company Parameters", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Present Grant Parameters", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Update Grant Level Parameters", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Is Manual Uploaded", typeof(string));
                            break;
                    }

                    //Do not change sequence of dataRow i.e. "Parameters selected for grant" it will affect in data binding for datatable
                    DataRow dataRow = null;

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Market Price[Intrinsic Value]";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Market Price[Fair Value]";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Expected Life";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Riskfree Rate";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Volatility";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Dividend";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    return dt_tempValuationParameters;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Create Valuation Parameters DataTable with values
        /// </summary>
        /// <param name="accountingServiceClient">accountingServiceClient service object</param>
        /// <param name="dt_ValuationParameter">dt_ValuationParameter DataTable</param>
        /// <param name="ds_ValuationParameters">ds_ValuationParameters Dataset</param>
        /// <param name="s_GrantID">Grant ID</param>
        /// <returns>DataTable</returns>
        public DataTable CreateValuationParamDataTable(AccountingServiceClient accountingServiceClient, DataTable dt_ValuationParameter, DataSet ds_ValuationParameters, string s_GrantID)
        {
            try
            {
                using (DataTable dt_UIParameters = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10_UI))
                {
                    using (DataSet ds = ds_ValuationParameters)
                    {
                        #region Insert values for Market Price[Intrinsic Value]
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table"].Select("COMP_GRANT_REG_ID_IV = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table"].Select("COMP_GRANT_REG_ID_IV = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Stock Exchange concatenated with Parameter 2: Date of Market Price
                                string s_StockExchange = dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_IV"].ToString().Trim() == "lblIVSE01" ?
                                                         "Stock Exchange: " + Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_IV"]).Trim()
                                                         : string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_IV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_IV"] + "'"))[0]["LabelName"]);

                                string s_CalculateIV = "Calculate IV: " + (!string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CALCULATE_IV"])) && Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CALCULATE_IV"]).Equals("1") ? "Yes" : "No");

                                dt_ValuationParameter.Rows[0]["Company Level"] = string.IsNullOrEmpty(s_StockExchange) ? string.Empty : (s_StockExchange + ", ") + (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_IV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_IV"] + "'"))[0]["LabelName"])) + ", " + s_CalculateIV;
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table1"].Select("GRANT_GRANT_REG_ID_IV = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table1"].Select("GRANT_GRANT_REG_ID_IV = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Stock Exchange concatenated with Parameter 2: Date of Market Price
                                string s_StockExchange = dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_IV"].ToString().Trim() == "lblIVSE01" ?
                                                         "Stock Exchange: " + Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EXCHANGE_IV"]).Trim()
                                                         : string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_IV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_IV"] + "'"))[0]["LabelName"]);

                                string s_CalculateIV = "Calculate IV: " + (!string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CALCULATE_IV"])) && Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CALCULATE_IV"]).Equals("1") ? "Yes" : "No");

                                dt_ValuationParameter.Rows[0]["Present Grant Parameters"] = string.IsNullOrEmpty(s_StockExchange) ? string.Empty : (s_StockExchange + ", ") + (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MARKET_PRICE_LABEL_ID_IV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_MARKET_PRICE_LABEL_ID_IV"] + "'"))[0]["LabelName"])) + ", " + s_CalculateIV;
                            }
                        }
                        #endregion

                        #region Fair Value for Market Price[Fair Value]
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table2"].Select("COMP_GRANT_REG_ID_FV = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table2"].Select("COMP_GRANT_REG_ID_FV = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Stock Exchange concatenated with Parameter 2: Date of Market Price
                                string s_StockExchange = dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_FV"].ToString().Trim() == "lblFVSE01" ? 
                                                         "Stock Exchange: " + Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_FV"]).Trim() 
                                                         : string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_FV"])) ? string.Empty: Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_FV"] + "'"))[0]["LabelName"]);

                                dt_ValuationParameter.Rows[1]["Company Level"] = string.IsNullOrEmpty(s_StockExchange) ? string.Empty : (s_StockExchange + ", ") + (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_FV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_FV"] + "'"))[0]["LabelName"]));
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table3"].Select("GRANT_GRANT_REG_ID_FV = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table3"].Select("GRANT_GRANT_REG_ID_FV = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Stock Exchange concatenated with Parameter 2: Date of Market Price
                                string s_StockExchange = dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_FV"].ToString().Trim() == "lblFVSE01" ?
                                                         "Stock Exchange: " + Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EXCHANGE_FV"]).Trim()
                                                         : string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_FV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_FV"] + "'"))[0]["LabelName"]);

                                dt_ValuationParameter.Rows[1]["Present Grant Parameters"] = string.IsNullOrEmpty(s_StockExchange) ? string.Empty : (s_StockExchange + ", ") + (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MARKET_PRICE_LABEL_ID_FV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_MARKET_PRICE_LABEL_ID_FV"] + "'"))[0]["LabelName"]));
                            }
                        }
                        #endregion

                        #region Expected Life
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table4"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table4"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Method for Calculating Expected Life [Might be in Years/Months/Days]
                                if (dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"].ToString().Trim() == "lblMCEL02" || dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"].ToString().Trim() == "lblMCEL03")
                                {

                                    switch (dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_PERIOD_IN"].ToString().Trim())
                                    {
                                        case "Y":
                                            dt_ValuationParameter.Rows[2]["Company Level"] = (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Year(s)";
                                            break;

                                        case "M":
                                            dt_ValuationParameter.Rows[2]["Company Level"] = (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Month(s)";
                                            break;

                                        case "D":
                                            dt_ValuationParameter.Rows[2]["Company Level"] = (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Day(s)";
                                            break;
                                    }

                                }
                                else
                                {
                                    dt_ValuationParameter.Rows[2]["Company Level"] = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]);
                                }
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table5"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table5"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Method for Calculating Expected Life [Might be in Years/Months/Days]
                                if (dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"].ToString().Trim() == "lblMCEL02" || dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"].ToString().Trim() == "lblMCEL03")
                                {

                                    switch (dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_PERIOD_IN"].ToString().Trim())
                                    {
                                        case "Y":
                                            dt_ValuationParameter.Rows[2]["Present Grant Parameters"] = (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Year(s)";
                                            break;

                                        case "M":
                                            dt_ValuationParameter.Rows[2]["Present Grant Parameters"] = (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Month(s)";
                                            break;

                                        case "D":
                                            dt_ValuationParameter.Rows[2]["Present Grant Parameters"] = (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Day(s)";
                                            break;
                                    }

                                }
                                else
                                {
                                    dt_ValuationParameter.Rows[2]["Present Grant Parameters"] = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]);
                                }
                            }
                        }
                        #endregion

                        #region RFIR
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table11"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table11"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                dt_ValuationParameter.Rows[3]["Company Level"] = dt_CompanyLevelParameters.Rows[0]["COMP_RFIR_COUNTRY_NAME"];
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table12"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table12"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                dt_ValuationParameter.Rows[3]["Present Grant Parameters"] = dt_GrantLevelParameters.Rows[0]["GRANT_RFIR_COUNTRY_NAME"];
                            }
                        }
                        #endregion

                        #region Volatility
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table6"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table6"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Volatility of
                                //Parameter 2: Market Price to Calculate Volatility
                                //Parameter 3: Periods to Calculate Volatility
                                string s_VolatilityOf = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_VOL_OF_LABEL_ID"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_VOL_OF_LABEL_ID"] + "'"))[0]["LabelName"]);
                                string s_MPtoCalVol = string.Empty;
                                string s_PeriodstoCalVol = string.Empty;

                                if(s_VolatilityOf.Equals("Own Company"))
                                {
                                    s_VolatilityOf = s_VolatilityOf + " Market Price: " + dt_CompanyLevelParameters.Rows[0]["SHORT_NAME"].ToString().Trim();
                                }
                                if (dt_CompanyLevelParameters.Rows[0]["COMP_TRADING_DAYS_LABEL"].ToString().Trim() == "lblTDD03")
                                {
                                    s_MPtoCalVol = ", " + dt_CompanyLevelParameters.Rows[0]["COMP_TRADING_DAYS"].ToString().Trim() + " Days";
                                }
                                else
                                {
                                    s_MPtoCalVol = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MP_CALC_VOLATILITY"])) ? string.Empty : ", " + (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_MP_CALC_VOLATILITY"] + "'"))[0]["LabelName"].ToString()
                                                    + ", " + (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_TRADING_DAYS_LABEL"] + "'"))[0]["LabelName"].ToString() + " Days";
                                }
                                if (dt_CompanyLevelParameters.Rows[0]["COMP_PRD_CALC_VOL_LABEL"].ToString().Trim() == "lblPTCV03")
                                {
                                    switch (dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_PERIOD_IN"].ToString().Trim())
                                    {
                                        case "Y":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Years";
                                            break;

                                        case "M":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Months";
                                            break;

                                        case "D":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Days";
                                            break;
                                    }
                                }
                                else
                                {
                                    s_PeriodstoCalVol = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_PRD_CALC_VOL_LABEL"])) ? string.Empty : ", Periods to Calculate Volatility: " + (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_PRD_CALC_VOL_LABEL"] + "'"))[0]["LabelName"].ToString();
                                }
                                //Assign values to DataTable
                                dt_ValuationParameter.Rows[4]["Company Level"] = s_VolatilityOf + s_MPtoCalVol + s_PeriodstoCalVol;
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table7"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table7"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Volatility of
                                //Parameter 2: Market Price to Calculate Volatility
                                //Parameter 3: Periods to Calculate Volatility
                                string s_VolatilityOf = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_VOL_OF_LABEL_ID"])) ? string.Empty:Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_VOL_OF_LABEL_ID"] + "'"))[0]["LabelName"]);
                                string s_MPtoCalVol = string.Empty;
                                string s_PeriodstoCalVol = string.Empty;

                                if(s_VolatilityOf.Equals("Own Company"))
                                {
                                    s_VolatilityOf = s_VolatilityOf + " Market Price: " + dt_GrantLevelParameters.Rows[0]["SHORT_NAME"].ToString().Trim();
                                }

                                if (dt_GrantLevelParameters.Rows[0]["GRANT_TRADING_DAYS_LABEL"].ToString().Trim() == "lblTDD03")
                                {
                                    s_MPtoCalVol = ", " + dt_GrantLevelParameters.Rows[0]["GRANT_TRADING_DAYS"].ToString().Trim() + " Days";
                                }
                                else
                                {
                                    s_MPtoCalVol = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MP_CALC_VOLATILITY"])) ? string.Empty : ", " + (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_MP_CALC_VOLATILITY"] + "'"))[0]["LabelName"].ToString() +
                                                   ", " + (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_TRADING_DAYS_LABEL"] + "'"))[0]["LabelName"].ToString() + " Days";
                                }
                                if (dt_GrantLevelParameters.Rows[0]["GRANT_PRD_CALC_VOL_LABEL"].ToString().Trim() == "lblPTCV03")
                                {
                                    switch (dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_PERIOD_IN"].ToString().Trim())
                                    {
                                        case "Y":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + (dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Years");
                                            break;

                                        case "M":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + (dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Months");
                                            break;

                                        case "D":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + (dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Days");
                                            break;
                                    }
                                }
                                else
                                {
                                    s_PeriodstoCalVol = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_PRD_CALC_VOL_LABEL"])) ? string.Empty : ", Periods to Calculate Volatility: " + (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_PRD_CALC_VOL_LABEL"] + "'"))[0]["LabelName"].ToString();
                                }
                                //Assign values to DataTable
                                dt_ValuationParameter.Rows[4]["Present Grant Parameters"] = s_VolatilityOf + s_MPtoCalVol + s_PeriodstoCalVol;
                            }
                        }
                        #endregion

                        #region Dividend
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table8"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table8"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Dividend
                                //Parameter 2: Market Price to Calculate Dividend Yield
                                string s_Dividend = string.Empty;
                                string s_MPtoCalDiviYield = string.Empty;
                                if (dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"].ToString().Trim() == "lblDIV03")
                                {
                                    s_Dividend = (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"]))? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"] + "'"))[0]["LabelName"].ToString()) + " Last " + dt_CompanyLevelParameters.Rows[0]["COMP_NO_OF_YEARS"].ToString().Trim() + " Years";
                                }
                                else
                                {
                                    s_Dividend = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"] + "'"))[0]["LabelName"].ToString();
                                }
                                s_MPtoCalDiviYield = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MP_TO_CAL_DIVIDEND"])) ? string.Empty : ", " + (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_MP_TO_CAL_DIVIDEND"] + "'"))[0]["LabelName"].ToString();

                                //Assign values to DataTable
                                dt_ValuationParameter.Rows[5]["Company Level"] = s_Dividend + s_MPtoCalDiviYield;
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table9"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table9"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Dividend
                                //Parameter 2: Market Price to Calculate Dividend Yield
                                string s_Dividend = string.Empty;
                                string s_MPtoCalDiviYield = string.Empty;
                                if (dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"].ToString().Trim() == "lblDIV03")
                                {
                                    s_Dividend = (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"] + "'"))[0]["LabelName"].ToString()) + " Last " + dt_GrantLevelParameters.Rows[0]["GRANT_NO_OF_YEARS"].ToString().Trim() + " Years";
                                }
                                else
                                {
                                    s_Dividend = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"] + "'"))[0]["LabelName"].ToString();
                                }
                                s_MPtoCalDiviYield = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MP_TO_CAL_DIVIDEND"])) ? string.Empty : ", " + (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_MP_TO_CAL_DIVIDEND"] + "'"))[0]["LabelName"].ToString();

                                //Assign values to DataTable
                                dt_ValuationParameter.Rows[5]["Present Grant Parameters"] = s_Dividend + s_MPtoCalDiviYield;
                            }
                        }
                        #endregion

                        #region Is Manually Uploaded Data
                        using(DataTable dt_ManuallyEntered = ds.Tables["Table10"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table10"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if(dt_ManuallyEntered != null && dt_ManuallyEntered.Rows.Count > 0)
                            {
                                if(dt_ManuallyEntered.Rows[0]["IS_MU_MKT_IV"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[0]["Is Manual Uploaded"] = "True";
                                }
                                if(dt_ManuallyEntered.Rows[0]["IS_MU_MKT_FV"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[1]["Is Manual Uploaded"] = "True";
                                }
                                if(dt_ManuallyEntered.Rows[0]["IS_MU_EXL"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[2]["Is Manual Uploaded"] = "True";
                                }
                                if(dt_ManuallyEntered.Rows[0]["IS_MU_RFIR"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[3]["Is Manual Uploaded"] = "True";
                                }
                                if(dt_ManuallyEntered.Rows[0]["IS_MU_VOL"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[4]["Is Manual Uploaded"] = "True";
                                }
                                if(dt_ManuallyEntered.Rows[0]["IS_MU_DIVD"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[5]["Is Manual Uploaded"] = "True";
                                }
                            }
                        }
                        #endregion
                    }
                }
                return dt_ValuationParameter;
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~GetValuationParameters()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}