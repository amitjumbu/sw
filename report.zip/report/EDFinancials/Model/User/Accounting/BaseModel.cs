﻿using EDFinancials.Model.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    ///  The class file for BaseModel
    /// </summary>
    public class BaseModel : EDFinancials.Model.Admin.BaseModel
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public BaseModel()
        {
            if ((AccountingProperties)System.Web.HttpContext.Current.Session["accountingProperties"] == null)
            {
                accountingProperties = new AccountingProperties();
                System.Web.HttpContext.Current.Session["accountingProperties"] = accountingProperties;
            }
            else
            {
                accountingProperties = (AccountingProperties)System.Web.HttpContext.Current.Session["accountingProperties"];
            }

            if ((AccountingCRUDProperties)System.Web.HttpContext.Current.Session["accountingCRUDProperties"] == null)
            {
                accountingCRUDProperties = new AccountingCRUDProperties();
                System.Web.HttpContext.Current.Session["accountingCRUDProperties"] = accountingCRUDProperties;
            }
            else
            {
                accountingCRUDProperties = (AccountingCRUDProperties)System.Web.HttpContext.Current.Session["accountingCRUDProperties"];
            }
        }

        /// <summary>
        /// PRIVATE DECLARATION FOR ACCOUNTING PROPERTY
        /// </summary>
        private AccountingProperties _accountingProperties;

        /// <summary>
        /// PUBLIC DECLARATION FOR ACCOUNTING PROPERTY
       /// </summary>
        public AccountingProperties accountingProperties
        {
            get { return _accountingProperties; }
            set { _accountingProperties = value; }
        }

        /// <summary>
      /// PRIVATE DECLARATION FOR ACCOUNTING CRUD PROPERTY
        /// </summary>
        private AccountingCRUDProperties _accountingCRUDProperties;

        /// <summary>
      /// PUBLIC DECLARATION FOR ACCOUNTING CRUD PROPERTY
      /// </summary>
        public AccountingCRUDProperties accountingCRUDProperties
        {
            get { return _accountingCRUDProperties; }
            set { _accountingCRUDProperties = value; }
        }

		/// <summary>
        /// OBJECT OF ACCOUNTING PARAMETERS ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_AccountingParameter ac_AccountingParameter;

        /// <summary>
        /// OBJECT OF APPROVE ACCOUNTING PARAMETERS ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ApproveAccountingParams ac_ApproveAccountingParams;

        /// <summary>
        /// OBJECT OF VALUATION REPORT ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_SearchGrantDetails ac_SearchGrantDetails;

        /// <summary>
        /// OBJECT OF GRANT DETAILS ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_GrantDetails ac_GrantDetails;

        /// <summary>
        /// OBJECT OF FINANCIAL YEAR SETUP ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_FinancialYearSetUp ac_FinancialYearSetUp;

        /// <summary>
        /// OBJECT OF Historical Cost ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_HistoricalCost ac_HistoricalCost;
        
		/// <summary>
        /// OBJECT OF EMPLOYEE MASTER ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_EmployeeMaster ac_EmployeeMaster;

        /// <summary>
        /// OBJECT OF CUSTOMIZE VIEW SETUP ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_CustomizeView ac_CustomizeView;

        /// <summary>
        /// OBJECT OF Forfeiture Setup ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ForfeitureSetup ac_ForfeitureSetup;

        /// <summary>
        /// OBJECT OF Accelerated Vesting ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_AcceleratedVesting ac_AcceleratedVesting;

        /// <summary>
        /// OBJECT OF Corporate Action Adjustment ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_CorporateActionAdjustment ac_CorporateActionAdjustment;

        /// <summary>
        /// OBJECT OF ACCOUNTING REPORT ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_AccountingReport ac_AccountingReport;

        /// <summary>
        /// OBJECT OF EMPLOYEE MASTER ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_Modifications ac_Modifications;

        /// <summary>
        /// OBJECT OF TRACKING DETAILS ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_TrackingDetails ac_TrackingDetails;

        /// <summary>
        /// OBJECT OF SUMMARY WORKINGS ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_SummaryWorkings ac_SummaryWorkings;

        /// <summary>
        /// OBJECT OF MASS UPLOAD ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_MassUpload ac_MassUpload;

        /// <summary>
        /// OBJECT OF MASS UPLOAD ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_AccountingScheduledReports ac_AccountingScheduledReports;
    }
}