﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Accounting Parameters Model class
    /// </summary>
    public class AccountingParametersModel : BaseModel, IDisposable
    {

        #region Default constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public AccountingParametersModel()
        {
            if (ac_AccountingParameter == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_AccountingParameter);
                ac_AccountingParameter = (CommonModel.AC_AccountingParameter)HttpContext.Current.Session[CommonConstantModel.s_AC_AccountingParameter];
            }
        }


        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_CanNotEditSettingsMsg = string.Empty, s_BtnAPSSaveText = string.Empty, s_BtnAPSSaveToolTip = string.Empty, s_BtnAPSUpdateText = string.Empty, s_BtnAPSUpdateTooltip = string.Empty;

        #endregion

        #region Common Bind Methods
        /// <summary>
        /// This method is used to Bind the all controls
        /// </summary>
        /// <param name="accountingParameters">Accounting Parameters object</param>
        internal void PopulateAllControls(AccountingParameters accountingParameters)
        {
            try
            {
                BindUI(accountingParameters);
                BindAllControls(accountingParameters);
            }
            catch
            {
                throw;
            }
        }
       

       
        /// <summary>
        /// This method is used to Bind UI controls
        /// </summary>
        /// <param name="accountingParameters">Accounting Parameters page object</param>
        internal void BindUI(AccountingParameters accountingParameters)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_AccountingParameter.dt_AccountingParametersUI == null || ac_AccountingParameter.dt_AccountingParametersUI.Rows.Count.Equals(0))
                    {
                        ac_AccountingParameter.dt_AccountingParametersUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10_UI);
                    }

                    if ((ac_AccountingParameter.dt_AccountingParametersUI != null) && (ac_AccountingParameter.dt_AccountingParametersUI.Rows.Count > 0))
                    {
                        foreach (Control control in accountingParameters.dvMain.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, accountingParameters, ac_AccountingParameter.dt_AccountingParametersUI, (Label)control, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, accountingParameters, ac_AccountingParameter.dt_AccountingParametersUI, null, (TextBox)control, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, accountingParameters, ac_AccountingParameter.dt_AccountingParametersUI, null, null, (Button)control, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcCheckbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeCheckBox, accountingParameters, ac_AccountingParameter.dt_AccountingParametersUI, null, null, null, (CheckBox)control, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, accountingParameters, ac_AccountingParameter.dt_AccountingParametersUI, null, null, null, null, (RadioButton)control, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, accountingParameters, ac_AccountingParameter.dt_AccountingParametersUI, null, null, null, null, null, (BaseValidator)control, null, null);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, accountingParameters, ac_AccountingParameter.dt_AccountingParametersUI, null, null, null, null, null, null, (BaseValidator)control, null);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, accountingParameters, ac_AccountingParameter.dt_AccountingParametersUI, null, null, null, null, null, null, null, (GridView)control);
                                    break;
                            }

                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="accountingParameters">The DownloadTemplate class object</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="label">The label control object</param>
        /// <param name="textBox">The text-box control object</param>
        /// <param name="button">The button control object</param>
        /// <param name="checkBox">The CheckBox control object</param>
        /// <param name="radioButton">radiobutton control object</param>
        /// <param name="ReqValidator">validator control object</param>
        /// <param name="RegExpValidator">validator control object</param>
        /// <param name="gridView">gridview control object</param>
        private void BindPropertiesToControl(string s_cntrlType, AccountingParameters accountingParameters, DataTable Dt_Get_L10N_UI, Label label, TextBox textBox, Button button, CheckBox checkBox, RadioButton radioButton, BaseValidator ReqValidator, BaseValidator RegExpValidator, GridView gridView)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeCheckBox:
                    checkBox.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelName"]);
                    checkBox.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRadioButton:
                    radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                    radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    gridView.EmptyDataText = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + gridView.ID + "'"))[0]["LabelName"]);
                    break;

                case CommonConstantModel.s_cntrlTypeTextBox:
                    break;
            }
        }

        #endregion

        #region Controls Methods/Set Values to static variables
        /// <summary>
        /// This method is used to bind the gridview control/Set values to Variables
        /// </summary>
        /// <param name="accountingParameters">AccountingParameters object</param>
        internal void BindAllControls(AccountingParameters accountingParameters)
        {
            try
            {
                DateTime? dt = null;
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_AccountingParameter;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_OperationRead;
                    accountingProperties.OPERATION_DATE = dt;
                    accountingProperties.ACTION_TYPE = "ACCOUNTING_PARAMS";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_AccountingParameter.ds_AccountingParameters = (DataSet)accountingCRUDProperties.ds_Result;

                    ac_AccountingParameter.dt_AccountingParameters = ac_AccountingParameter.ds_AccountingParameters.Tables[1];
                    accountingParameters.gv.DataSource = ac_AccountingParameter.dt_AccountingParameters;
                    accountingParameters.gv.DataBind();
                    BindUIControlsWithDefaultValues(accountingParameters);
                    SetApprovalHiddenField(accountingParameters);
                    SetValuesToStaticVariables();

                    s_CanNotEditSettingsMsg = accountingServiceClient.GetAccounting_L10N("lblAPSCanNotEditSettingsMsg", CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind  controls with default values
        /// </summary>
        /// <param name="accountingParameters">AccountingParameters control object</param>
        public void BindUIControlsWithDefaultValues(AccountingParameters accountingParameters)
        {
            try
            {
                if (ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows.Count > 0)
                {
                    if (Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Valuation Method"]).Trim().Equals("rdbVMCC01"))
                    {
                        accountingParameters.rdbVMCC01.Checked = true;
                    }
                    else if (Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Valuation Method"]).Trim().Equals("rdbVMCC02"))
                        accountingParameters.rdbVMCC02.Checked = true;
                    else
                        accountingParameters.rdbVMCC03.Checked = true;

                    if (Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Accounting Method"]).Trim().Equals("rdbAM01"))
                    {
                        accountingParameters.rdbAM01.Checked = true;
                        accountingParameters.rdbAM02.Enabled = false;
                    }
                    else if (Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Accounting Method"]).Trim().Equals("rdbAM02"))
                    {
                        accountingParameters.rdbAM02.Checked = true;
                        accountingParameters.rdbAM01.Enabled = false;
                        accountingParameters.rdbRCC01.Visible = false;
                    }
                    if (Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Recognition of Compensation Cost"]).Trim().Equals("rdbRCC01"))
                        accountingParameters.rdbRCC01.Checked = true;
                    else
                        accountingParameters.rdbRCC02.Checked = true;

                    if (Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Vested Cancelled"]).Trim().Equals("chkCRAF01"))
                        accountingParameters.chkCRAF01.Checked = true;

                    if (Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Unvested Cancelled"]).Trim().Equals("chkCRAF02"))
                        accountingParameters.chkCRAF02.Checked = true;

                    if (Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Lapsed"]).Trim().Equals("chkCRAF03"))
                        accountingParameters.chkCRAF03.Checked = true;

                    accountingParameters.txtComments.Text = Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Comments"]).Trim();
                    accountingParameters.txtApplFromDate.Text = !string.IsNullOrEmpty(Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Applicable From Date"])) ? Convert.ToDateTime(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Applicable From Date"]).ToString("dd/MMM/yyyy") : string.Empty;

                    accountingParameters.hdnAPSAppFromDate.Value = accountingParameters.txtApplFromDate.Text = !string.IsNullOrEmpty(Convert.ToString(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Applicable From Date"])) ? Convert.ToDateTime(ac_AccountingParameter.ds_AccountingParameters.Tables[0].Rows[0]["Applicable From Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                    SetValuesToStaticVariables();
                    SetButtonText(accountingParameters.btnAPSSave);
                }
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// Method to set hidden field to check approval status
        /// </summary>
        /// <param name="accountingParameters">accountingParameters page object</param>
        public void SetApprovalHiddenField(AccountingParameters accountingParameters)
        {
            try
            {
                bool b_IsApproved = (from query in ac_AccountingParameter.dt_AccountingParameters.AsEnumerable()
                                     where query.Field<string>("Approval Status|").TrimEnd('|') == "Pending"
                                     select query.Field<string>("Approval Status|").TrimEnd('|')).Distinct().Count() > 0 ? false : true;
                accountingParameters.hdnAPS_IsApproved.Value = b_IsApproved ? "1" : "0";
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        ///  This method is used to set values to static variables
        /// </summary>
        public void SetValuesToStaticVariables()
        {
            s_BtnAPSSaveText = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'btnAPSSave'"))[0]["LabelName"]);
            s_BtnAPSSaveToolTip = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'btnAPSSave'"))[0]["LabelToolTip"]);
            s_BtnAPSUpdateText = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'btnAPSUpdate'"))[0]["LabelName"]);
            s_BtnAPSUpdateTooltip = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'btnAPSUpdate'"))[0]["LabelToolTip"]);
        }

        /// <summary>
        /// Method to check employee role privileges
        /// </summary>
        /// <param name="accountingParameters">AccountingParameters page object</param>
        public void CheckEmployeeRolePriviledges(AccountingParameters accountingParameters)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuAccountingParameter;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case CommonConstantModel.s_VIEW:
                                    accountingParameters.btnAPSReset.Enabled = false;
                                    accountingParameters.btnAPSSave.Enabled = false;
                                    break;

                                case CommonConstantModel.s_ADD:
                                    accountingParameters.btnAPSReset.Enabled = true;
                                    accountingParameters.btnAPSSave.Enabled = true;
                                    break;

                                case CommonConstantModel.s_EDIT:
                                    accountingParameters.btnAPSReset.Enabled = true;
                                    accountingParameters.btnAPSSave.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        #region Customize Method For binding  gridview header

        /// <summary>
        /// This method is used to Customize grid header to add the subheader
        /// </summary>
        /// <param name="gridView">gridView control object</param>
        /// <param name="gridRow">individual row of the gridview</param>
        /// <param name="headerLevels">headerLevels int variable</param>
        internal void CustomizeGridHeader(GridView gridView, GridViewRow gridRow, int headerLevels)
        {
            for (int item = 1; item <= headerLevels; item++)
            {
                //creating new header row
                GridViewRow gridviewRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
                IEnumerable<System.Linq.IGrouping<string, string>> gridHeaders = null;

                //reading existing header 
                gridHeaders = gridRow.Cells.Cast<TableCell>()
                            .Select(cell => GetHeaderText(cell.Text, item))
                            .GroupBy(headerText => headerText);

                foreach (var header in gridHeaders)
                {
                    using (TableHeaderCell cell = new TableHeaderCell())
                    {
                        cell.Text = header.Key.ToString();
                        cell.Visible = !(cell.Text.Contains("APID"));
                        if (item == 2)
                        {
                            if (!cell.Text.Contains("Cost Reversal For"))
                                goto nextHeader;
                            cell.Text = header.Key.Substring(header.Key.LastIndexOf(CommonConstantModel.s_seperator) + 1);
                        }
                        else
                        {
                            if (cell.Text.Contains("Cost Reversal For"))
                                cell.ColumnSpan = 3;
                            else
                                cell.RowSpan = 2;

                        }
                        gridviewRow.Cells.Add(cell);
                        // Adding new header to the grid
                        gridView.Controls[0].Controls.AddAt(gridRow.RowIndex, gridviewRow);
                    }
                nextHeader: ;
                    //do nothing
                }
            }
            //hiding existing header
            gridRow.Visible = false;
        }


        /// <summary>
        /// Reading header text for each levels
        /// </summary>
        /// <param name="headerText">Current header text</param>
        /// <param name="headerLevel">Header level to be customized</param>
        /// <returns>Modified header text</returns>
        private string GetHeaderText(string headerText, int headerLevel)
        {
            if (headerLevel == 2)
            {
                return headerText;
            }
            return headerText.Substring(0, headerText.LastIndexOf(CommonConstantModel.s_seperator));
        }

        #endregion


        /// <summary>
        ///  GridView row data bound event to bind data to grid-view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="n_Index">index of the row</param>
        /// <param name="n_VAL_METH_CAL_CC">VALUATION METHOD parmeters object</param>
        /// <param name="n_ACC_METHOD">ACCOUNTING METHOD parameters object</param>
        /// <param name="n_RECOGNITION_CC">RECOGNITION OF COMPENSATION COST parameters object</param>
        /// <param name="n_COSTREVERSALAF_VC">COST REVERSAL FOR|VESTED CANCELLED parameters object</param>
        /// <param name="n_COSTREVERSALAF_UC">COST REVERSAL FOR|UNVESTED CANCELLED parameters object</param>
        /// <param name="n_COSTREVERSALAF_LAP">COST REVERSAL FOR|LAPSED parameters object</param>
        /// <param name="n_Applicable_From_Date">APPLICABLE FROM DATE</param>
        /// <param name="n_Comments">COMMENTS parameetrs object</param>
        /// <param name="n_To_Date">TO_DATE parameters object</param>
        /// <param name="n_APID">Primary key of table</param>
        /// <param name="n_Approval_Status">APPROVAL_STATUS of parameters</param>
        /// <param name="n_View_History_Data">To view the history of current parameters</param>
        internal void RowDataBindForGVAP(GridViewRowEventArgs e, ref int n_Index, ref int n_VAL_METH_CAL_CC, ref int n_ACC_METHOD, ref int n_RECOGNITION_CC, ref int n_COSTREVERSALAF_VC, ref int n_COSTREVERSALAF_UC, ref int n_COSTREVERSALAF_LAP, ref int n_Applicable_From_Date, ref int n_Comments, ref int n_To_Date, ref int n_APID, ref int n_Approval_Status, ref int n_View_History_Data)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.TrimEnd('|').ToUpper())
                            {
                                case "VALUATION METHOD":
                                    n_VAL_METH_CAL_CC = n_Index;
                                    break;
                                case "ACCOUNTING METHOD":
                                    n_ACC_METHOD = n_Index;
                                    break;
                                case "RECOGNITION OF COMPENSATION COST":
                                    n_RECOGNITION_CC = n_Index;
                                    break;
                                case "COST REVERSAL FOR|VESTED CANCELLED":
                                    n_COSTREVERSALAF_VC = n_Index;
                                    break;
                                case "COST REVERSAL FOR|UNVESTED CANCELLED":
                                    n_COSTREVERSALAF_UC = n_Index;
                                    break;
                                case "COST REVERSAL FOR|LAPSED":
                                    n_COSTREVERSALAF_LAP = n_Index;
                                    break;
                                case "APPLICABLE FROM DATE":
                                    n_Applicable_From_Date = n_Index;
                                    break;
                                case "TO DATE":
                                    n_To_Date = n_Index;
                                    break;
                                case "COMMENTS":
                                    n_Comments = n_Index;
                                    break;
                                case "APPROVAL STATUS":
                                    n_Approval_Status = n_Index;
                                    break;
                                case "VIEW HISTORY":
                                    n_View_History_Data = n_Index;
                                    break;
                                case "APID":
                                    n_APID = n_Index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_Index++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_APID].Visible = false;
                        e.Row.Cells[n_Applicable_From_Date].HorizontalAlign = e.Row.Cells[n_To_Date].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Applicable_From_Date].Text) && !e.Row.Cells[n_Applicable_From_Date].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_Applicable_From_Date].Text = Convert.ToDateTime(e.Row.Cells[n_Applicable_From_Date].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_To_Date].Text) && !e.Row.Cells[n_To_Date].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_To_Date].Text = Convert.ToDateTime(e.Row.Cells[n_To_Date].Text).ToString("dd/MMM/yyyy");

                        e.Row.Cells[n_Comments].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;");

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_VAL_METH_CAL_CC].Text) && !e.Row.Cells[n_VAL_METH_CAL_CC].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[n_VAL_METH_CAL_CC].Text = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = " + "'" + e.Row.Cells[n_VAL_METH_CAL_CC].Text.Trim() + "'" + ""))[0]["LabelName"]); ;
                        }
                        else e.Row.Cells[n_VAL_METH_CAL_CC].Text = "NA";

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_ACC_METHOD].Text) && !e.Row.Cells[n_ACC_METHOD].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_ACC_METHOD].Text = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = " + "'" + e.Row.Cells[n_ACC_METHOD].Text.Trim() + "'" + ""))[0]["LabelName"]);
                        else
                            e.Row.Cells[n_ACC_METHOD].Text = "NA";

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_RECOGNITION_CC].Text) && !e.Row.Cells[n_RECOGNITION_CC].Text.Equals("&nbsp;"))
                        {
                            if (!(e.Row.Cells[n_RECOGNITION_CC].Text.Trim().Equals("rdbRCC01")))
                                e.Row.Cells[n_RECOGNITION_CC].Text = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = " + "'" + e.Row.Cells[n_RECOGNITION_CC].Text.Trim() + "'" + ""))[0]["LabelName"]).Substring(0, 13);
                            else
                                e.Row.Cells[n_RECOGNITION_CC].Text = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = " + "'" + e.Row.Cells[n_RECOGNITION_CC].Text.Trim() + "'" + ""))[0]["LabelName"]);
                        }
                        else
                            e.Row.Cells[n_RECOGNITION_CC].Text = "NA";

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_COSTREVERSALAF_VC].Text) && !e.Row.Cells[n_COSTREVERSALAF_VC].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_COSTREVERSALAF_VC].Text = "Yes";
                        else
                            e.Row.Cells[n_COSTREVERSALAF_VC].Text = "NA";

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_COSTREVERSALAF_UC].Text) && !e.Row.Cells[n_COSTREVERSALAF_UC].Text.Equals("&nbsp;") && !e.Row.Cells[n_COSTREVERSALAF_UC].Text.Equals(""))
                            e.Row.Cells[n_COSTREVERSALAF_UC].Text = "Yes";
                        else
                            e.Row.Cells[n_COSTREVERSALAF_UC].Text = "NA";

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_COSTREVERSALAF_LAP].Text) && !e.Row.Cells[n_COSTREVERSALAF_LAP].Text.Equals("&nbsp;") && !e.Row.Cells[n_COSTREVERSALAF_LAP].Text.Equals(""))
                            e.Row.Cells[n_COSTREVERSALAF_LAP].Text = "Yes";
                        else
                            e.Row.Cells[n_COSTREVERSALAF_LAP].Text = "NA";

                        if (string.IsNullOrEmpty(e.Row.Cells[n_Comments].Text) && !e.Row.Cells[n_Comments].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_Comments].Text = "NA";

                        e.Row.Cells[n_View_History_Data].Controls.Add((Control)new APSCommonModel().AddHistoryHyperLink(e.Row.Cells[n_APID].Text, e.Row.Cells[n_Applicable_From_Date].Text, e.Row.Cells[n_To_Date].Text));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event method
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="accountingParameters">Acounting Parameters page object</param>
        public void PageIndexChangingForGVACP(int NewPageIndex, AccountingParameters accountingParameters)
        {
            try
            {
                accountingParameters.gv.PageIndex = NewPageIndex;
                accountingParameters.gv.DataSource = ac_AccountingParameter.dt_AccountingParameters;
                accountingParameters.gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to rebind all the grids on postback
        /// </summary>
        /// <param name="AccountingParameters">accountingParameters page object</param>
        /// <param name="b_IsPageIndChange">bool variable to check page index changed</param>
        public void ReBindGridsOnPostBack(AccountingParameters AccountingParameters, bool b_IsPageIndChange)
        {
            try
            {
                using (APSCommonModel aPSCommonModel = new APSCommonModel())
                {
                    aPSCommonModel.ReBindGridsOnPostBack(AccountingParameters, b_IsPageIndChange);
                    SetApprovalHiddenField(AccountingParameters);
                }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", userSessionInfo.ACC_CompanyName).Replace("*", userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
            }
        }

        /// <summary>
        /// Method is used to update 'accounting parameter' details
        /// </summary>
        /// <param name="accountingParameters">accountingParameters page object</param>
        /// <returns></returns>
        public int UpdateAccountinParametersData(AccountingParameters accountingParameters)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    int n_RetValue = 0;
                    accountingProperties = new AccountingProperties();
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_AccountingParameter;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    accountingProperties.ModifiedBy = userSessionInfo.ACC_UserID;

                    if (userSessionInfo.ACC_UerTypeID.Equals(5))
                        accountingProperties.APMS_IS_APPROVED = true;
                    else accountingProperties.APMS_IS_APPROVED = false;

                    accountingProperties.PopulateControls = "APMS";

                    if (accountingParameters.rdbVMCC01.Checked)
                        accountingProperties.VAL_METH_CAL_CC_LABEL_ID = accountingParameters.rdbVMCC01.ID;
                    else if (accountingParameters.rdbVMCC02.Checked)
                        accountingProperties.VAL_METH_CAL_CC_LABEL_ID = accountingParameters.rdbVMCC02.ID;
                    else
                        accountingProperties.VAL_METH_CAL_CC_LABEL_ID = accountingParameters.rdbVMCC03.ID;

                    if (accountingParameters.rdbAM01.Checked)
                        accountingProperties.ACC_METHOD_LABEL_ID = accountingParameters.rdbAM01.ID;
                    else
                        accountingProperties.ACC_METHOD_LABEL_ID = accountingParameters.rdbAM02.ID;

                    if (accountingParameters.rdbRCC01.Checked)
                        accountingProperties.RECOGNITION_CC_LABEL_ID = accountingParameters.rdbRCC01.ID;
                    else
                        accountingProperties.RECOGNITION_CC_LABEL_ID = accountingParameters.rdbRCC02.ID;

                    if (accountingParameters.chkCRAF01.Checked)
                        accountingProperties.COSTREVERSALAF_VCLABEL_ID = accountingParameters.chkCRAF01.ID;

                    if (accountingParameters.chkCRAF02.Checked)
                        accountingProperties.COSTREVERSALAF_UCLABEL_ID = accountingParameters.chkCRAF02.ID;

                    if (accountingParameters.chkCRAF03.Checked)
                        accountingProperties.COSTREVERSALAF_LAPLABEL_ID = accountingParameters.chkCRAF03.ID;

                    accountingProperties.APMS_APPLICABLE_FROM_DATE = accountingParameters.txtApplFromDate.Text;
                    accountingProperties.APMS_COMMENTS = accountingParameters.txtComments.Text;
                    //Check whether report is locked or not for entered CA_AppDate
                    if (!CommonModel.CheckAgainstLockedAccountingReport(Convert.ToString(accountingParameters.txtApplFromDate.Text), userSessionInfo))
                    {
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    }
                    else
                    {
                        //set accountingProperties.a_result = 6  or 7  if accounting report is locked for AppDate
                        accountingCRUDProperties.a_result = (!(accountingParameters.hdnUpdateRecord.Value.Equals("U")) ? 6 : 7);
                    }

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            accountingParameters.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblError", CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10);
                            accountingParameters.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            accountingParameters.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 1:
                            accountingParameters.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAPSSaveMessage", CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10);
                            accountingParameters.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            accountingParameters.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            SetButtonText(accountingParameters.btnAPSSave);
                            accountingParameters.hdnAPSAppFromDate.Value = accountingParameters.txtApplFromDate.Text;
                            BindAllControls(accountingParameters);
                            break;

                        case 5:
                            accountingParameters.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAPSCanNotEditSettings", CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10);
                            accountingParameters.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            accountingParameters.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            BindAllControls(accountingParameters);
                            break;

                        case 6:
                            accountingParameters.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblACCParamCantAddSaveAsLockAccRpt", CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10);
                            accountingParameters.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            accountingParameters.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;


                        case 7:
                            accountingParameters.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblACCParamCantEditAsLockAccRpt", CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10);
                            accountingParameters.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            accountingParameters.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;
                    }

                    if (n_RetValue.Equals(1) && userSessionInfo.ACC_UerTypeID.Equals(3))
                    {
                        using (APSCommonModel aPSCommonModel = new APSCommonModel())
                        {
                            if (string.IsNullOrEmpty(accountingProperties.COSTREVERSALAF_VCLABEL_ID) && string.IsNullOrEmpty(accountingProperties.COSTREVERSALAF_UCLABEL_ID) && string.IsNullOrEmpty(accountingProperties.COSTREVERSALAF_LAPLABEL_ID))
                                aPSCommonModel.SendMailForApproval("" + Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'lblAPSValuationMetohd'"))[0]["LabelName"]) + ", " + Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'lblAPSAccountingMethod'"))[0]["LabelName"]) + "," + Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'lblRecognitionCC'"))[0]["LabelName"] + ""));
                            else
                                aPSCommonModel.SendMailForApproval("" + Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'lblAPSValuationMetohd'"))[0]["LabelName"]) + ", " + Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'lblAPSAccountingMethod'"))[0]["LabelName"]) + "," + Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'lblRecognitionCC'"))[0]["LabelName"]) + "," + Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = 'lblRecognitionCC'"))[0]["LabelName"] + ""));
                        }
                    }
                    return n_RetValue;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to set button text and tool-tip
        /// </summary>
        /// <param name="o_Button">Button control object</param>
        public void SetButtonText(Button o_Button)
        {
            switch (o_Button.ID.ToUpper())
            {
                case "BTNAPSSAVE": o_Button.Text = s_BtnAPSUpdateText; o_Button.ToolTip = s_BtnAPSUpdateTooltip; break;
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// method is used to bind history data
        /// </summary>
        /// <param name="s_ConfigID">The id for which history should be display</param>
        /// <returns></returns>
        internal AccountingProperties[] BindHistoryGridByID(object s_ConfigID)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                List<AccountingProperties> lstaccountingProperties = new List<AccountingProperties>();
                accountingProperties = new AccountingProperties();
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.PageName = CommonConstantModel.s_AccountingParameter;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingProperties.CONFIG_ID = Convert.ToInt32(s_ConfigID);
                accountingProperties.PopulateControls = "HISTORYDATA";
                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                foreach (DataRow dtrow in accountingCRUDProperties.dt_Result.Rows)
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.VAL_METH_CAL_CC_LABEL_ID = Convert.ToString(dtrow["Valuation Method"]);
                    accountingProperties.ACC_METHOD_LABEL_ID = Convert.ToString(dtrow["Accounting Method"]);
                    accountingProperties.RECOGNITION_CC_LABEL_ID = Convert.ToString(dtrow["Recognition of Compensation Cost"]);
                    accountingProperties.COSTREVERSALAF_VCLABEL_ID = Convert.ToString(dtrow["Vested Cancelled"]);
                    accountingProperties.COSTREVERSALAF_UCLABEL_ID = Convert.ToString(dtrow["Unvested Cancelled"]);
                    accountingProperties.COSTREVERSALAF_LAPLABEL_ID = Convert.ToString(dtrow["Lapsed"]);
                    accountingProperties.APMS_APPLICABLE_FROM_DATE = !string.IsNullOrEmpty(Convert.ToString(dtrow["Applicable From Date"])) ? Convert.ToDateTime(dtrow["Applicable From Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                    accountingProperties.APMS_COMMENTS = Convert.ToString(dtrow["Comments"]);
                    accountingProperties.APMS_TO_DATE = !string.IsNullOrEmpty(Convert.ToString(dtrow["To Date"])) ? Convert.ToDateTime(dtrow["To Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                    accountingProperties.APMS_IS_APPROVED = Convert.ToBoolean(dtrow["Status"]);

                    if (!string.IsNullOrEmpty(accountingProperties.VAL_METH_CAL_CC_LABEL_ID.Trim()) && !accountingProperties.VAL_METH_CAL_CC_LABEL_ID.Trim().Equals("&nbsp;"))
                    {
                        accountingProperties.VAL_METH_CAL_CC_LABEL_ID = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = " + "'" + accountingProperties.VAL_METH_CAL_CC_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]); ;
                    }
                    else
                        accountingProperties.VAL_METH_CAL_CC_LABEL_ID = "NA";

                    if (!string.IsNullOrEmpty(accountingProperties.ACC_METHOD_LABEL_ID) && !accountingProperties.ACC_METHOD_LABEL_ID.Equals("&nbsp;"))
                        accountingProperties.ACC_METHOD_LABEL_ID = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = " + "'" + accountingProperties.ACC_METHOD_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]);
                    else
                        accountingProperties.ACC_METHOD_LABEL_ID = "NA";

                    if (!string.IsNullOrEmpty(accountingProperties.RECOGNITION_CC_LABEL_ID) && !accountingProperties.RECOGNITION_CC_LABEL_ID.Equals("&nbsp;"))
                    {
                        if (!(accountingProperties.RECOGNITION_CC_LABEL_ID.Equals("rdbRCC01")))
                            accountingProperties.RECOGNITION_CC_LABEL_ID = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = " + "'" + accountingProperties.RECOGNITION_CC_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]).Substring(0, 13);
                        else
                            accountingProperties.RECOGNITION_CC_LABEL_ID = Convert.ToString((ac_AccountingParameter.dt_AccountingParametersUI.Select("LabelID = " + "'" + accountingProperties.RECOGNITION_CC_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]);
                    }

                    else
                        accountingProperties.ACC_METHOD_LABEL_ID = "NA";

                    if (!string.IsNullOrEmpty(accountingProperties.COSTREVERSALAF_VCLABEL_ID) && !accountingProperties.COSTREVERSALAF_VCLABEL_ID.Equals("&nbsp;"))
                        accountingProperties.COSTREVERSALAF_VCLABEL_ID = "Yes";
                    else
                        accountingProperties.COSTREVERSALAF_VCLABEL_ID = "NA";

                    if (!string.IsNullOrEmpty(accountingProperties.COSTREVERSALAF_UCLABEL_ID) && !accountingProperties.COSTREVERSALAF_UCLABEL_ID.Equals("&nbsp;"))
                        accountingProperties.COSTREVERSALAF_UCLABEL_ID = "Yes";
                    else
                        accountingProperties.COSTREVERSALAF_UCLABEL_ID = "NA";

                    if (!string.IsNullOrEmpty(accountingProperties.COSTREVERSALAF_LAPLABEL_ID) && !accountingProperties.COSTREVERSALAF_LAPLABEL_ID.Equals("&nbsp;"))
                        accountingProperties.COSTREVERSALAF_LAPLABEL_ID = "Yes";
                    else
                        accountingProperties.COSTREVERSALAF_LAPLABEL_ID = "NA";

                    lstaccountingProperties.Add(accountingProperties);
                }
                return lstaccountingProperties.ToArray();
            }
        }

        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~AccountingParametersModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}