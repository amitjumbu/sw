﻿using EDFinancials.Model.Generic;
using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;
using System.Linq;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// 
    /// </summary>
    public class ViewUpdateGeneralParamsUCModel : BaseModel, IDisposable
    {
        #region Default constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public ViewUpdateGeneralParamsUCModel()
        {
            if (ac_GrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_GrantDetails);
                ac_GrantDetails = (CommonModel.AC_GrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_GrantDetails];
            }

            if (ac_SearchGrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_SearchGrantDetails);
                ac_SearchGrantDetails = (CommonModel.AC_SearchGrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_SearchGrantDetails];
            }
        }
        #endregion

        #region RowBound Event Of gvGVPGrantDetails GridView
        /// <summary>
        /// The RowBound Event Of gvGVPGrantDetails GridView
        /// </summary>
        /// <param name="viewUpdateGeneralParamsUC">viewUpdateGeneralParamsUC</param>
        /// <param name="sender">gvUGPGrantDetails GridView</param>
        /// <param name="e">e</param>
        /// <param name="n_UVPindex">Index n_UVPindex</param>
        /// <param name="n_Currency"> Currency n_Currency</param>
        /// <param name="n_ExPrc">Exercise Price n_ExPrc</param>
        /// <param name="n_VestDet">Vest Details n_VestDet</param>
        /// <param name="n_Ratio">Ratio n_Ratio</param>
        /// <param name="n_RowIndex">Row Index</param>
        /// <param name="n_MissingPrices">Missing Prices</param>
        internal void gvUGPGrantDetails_RowDataBound(View.User.Accounting.UserControl.ViewUpdateGeneralParamsUC viewUpdateGeneralParamsUC, object sender, System.Web.UI.WebControls.GridViewRowEventArgs e, ref int n_UVPindex, ref int n_Currency, ref int n_ExPrc, ref int n_VestDet, ref int n_Ratio, ref int n_RowIndex, ref int n_MissingPrices)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "CURRENCY":
                                    n_Currency = n_UVPindex;
                                    break;

                                case "EXERCISE PRICE":
                                    n_ExPrc = n_UVPindex;
                                    break;

                                case "VESTING DETAILS":
                                    n_VestDet = n_UVPindex;
                                    break;

                                case "RATIO OPTIONS TO SHARES":
                                    n_Ratio = n_UVPindex;
                                    break;

                                case "MISSING MARKET PRICES":
                                    n_MissingPrices = n_UVPindex;
                                    break;
                            }
                            n_UVPindex = n_UVPindex + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_Currency].HorizontalAlign = e.Row.Cells[n_VestDet].HorizontalAlign = e.Row.Cells[n_Ratio].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_ExPrc].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_VestDet].Controls.Add(AddLinkButton("Click here to View Details", "View Details", "lbtnViewDetails", "return ViewVestDetails(this)"));

                        GridView parentGrid = (GridView)sender;

                        using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                        {
                            NewTotalRow.Font.Bold = true;
                            NewTotalRow.CssClass = "gridItems  gvChildGrid";
                            NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                            NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                            using (TableCell HeaderCell = new TableCell())
                            {
                                HeaderCell.Attributes.Add("Class", "gvChildGrid");
                                HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                HeaderCell.Height = 10;
                                HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                                HeaderCell.ColumnSpan = 9;

                                using (GridView childGrid = new GridView())
                                {
                                    childGrid.CssClass = "Grid";
                                    childGrid.RowStyle.CssClass = "gridItems";
                                    childGrid.CellPadding = 3;
                                    childGrid.CellSpacing = 0;
                                    childGrid.HeaderStyle.CssClass = "HeaderStyle";
                                    
                                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                                    {
                                        accountingProperties.PageName = CommonConstantModel.s_ValuationReport;
                                        accountingProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                                        accountingProperties.Grant_ID = e.Row.Cells[1].Text;
                                        accountingProperties.GET_DATA_TYPE = "VESTWISE";

                                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                                        childGrid.RowDataBound += viewUpdateGeneralParamsUC.childGrid_RowDataBound;
                                        
										using (DataTable dt_GrantDetailsVestwise = accountingCRUDProperties.ds_Result.Tables[0])
                                        {
                                            dt_GrantDetailsVestwise.Columns.Add("Missing Market Prices", typeof(string));
                                            childGrid.DataSource = new System.Data.DataView(dt_GrantDetailsVestwise).ToTable("DT", true, new string[] { "Grant Registration ID", "Vesting Period Number", "Vesting Date", "Expiry Date", "Vest Percent (%)", "Currency", "Missing Market Prices" }).Copy();
                                            childGrid.DataBind();
                                        }
                                    }
                                    
                                    HeaderCell.Controls.Add(childGrid);
                                    NewTotalRow.Cells.Add(HeaderCell);
                                    parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + n_RowIndex, NewTotalRow);
                                    n_RowIndex++;
                                }
                            }
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add link button
        /// </summary>
        /// <param name="s_Tooltip">Tool-tip</param>
        /// <param name="s_Text">Text</param>
        /// <param name="s_ID">ID</param>
        /// <param name="s_FuntionName">FuntionName</param>
        /// <returns>Link Button</returns>
        private LinkButton AddLinkButton(string s_Tooltip, string s_Text, string s_ID, string s_FuntionName)
        {
            try
            {
                LinkButton linkButton = new LinkButton();
                linkButton.ToolTip = s_Tooltip;
                linkButton.Text = s_Text;
                linkButton.ID = s_ID;
                linkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                linkButton.Style.Add("cursor", "pointer");

                linkButton.Attributes.Add("onclick", s_FuntionName);

                return linkButton;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add hidden field
        /// </summary>
        /// <param name="s_GrantID">GrantID</param>
        /// <param name="s_VestingID">VestingID</param>
        /// <returns>HiddenField</returns>
        private HiddenField AddHiddenField(string s_GrantID, string s_VestingID)
        {
            try
            {
                HiddenField hiddenField = new HiddenField();
                hiddenField.ID = "hdnMissingMP";
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    hiddenField.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=17").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrantRegistrationID=" + s_GrantID).Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("VestingPeriodID=" + s_VestingID).Replace("+", "%2B"));
                }

                return hiddenField;
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// Row Data Bound Event Of Child GridView
        /// </summary>
        /// <param name="sender">Child GridView</param>
        /// <param name="e">e</param>
        internal void childGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.DataRow:
                        e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
                        e.Row.Cells[6].Controls.Add(AddLinkButton("Click here to view Missing Market Prices", "View", "lbtnMissingMP", "return ViewMissingVolatilityDates(this)"));
                        e.Row.Cells[6].Controls.Add(AddHiddenField(e.Row.Cells[0].Text, e.Row.Cells[1].Text));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ViewUpdateGeneralParamsUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}