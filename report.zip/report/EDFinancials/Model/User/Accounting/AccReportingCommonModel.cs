﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Accounting Reporting Common Model class
    /// </summary>
    public class AccReportingCommonModel : BaseModel, IDisposable
    {
        /// <summary>
        /// This DataRow is used to store filtered rows of filtered DataTable 
        /// </summary>
        DataRow[] dr = null;

        #region Default constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public AccReportingCommonModel()
        {
            if (ac_AccountingReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_AccountingReport);
                ac_AccountingReport = (CommonModel.AC_AccountingReport)HttpContext.Current.Session[CommonConstantModel.s_AC_AccountingReport];
            }
        }
        #endregion

        #region Common Methods
        /// <summary>
        /// This method is used to encrypt query string data
        /// </summary>
        /// <param name="accountingReport">AccountingReport page object</param>
        /// <param name="accountingProperties">accountingProperties</param>
        internal void EncryptData(AccountingReport accountingReport, AccountingProperties accountingProperties)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                accountingReport.hdnAR_SSRSQueryString.Value = Convert.ToString(
                    genericServiceClient.EncryptString("RptID=12").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("REPORTING_DATE={0}", accountingReport.txtARDate.Text)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("MARKET_PRICE_TYPE={0}", accountingReport.rdoARMarketPriceType.SelectedItem.Value)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("SCHEME_NAME={0}", string.IsNullOrEmpty(accountingProperties.SCHEME_NAME) ? null : accountingProperties.SCHEME_NAME)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_ID={0}", string.IsNullOrEmpty(accountingProperties.EMPLOYEE_ID) ? null : accountingProperties.EMPLOYEE_ID)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_NAME={0}", string.IsNullOrEmpty(accountingProperties.EMPLOYEE_NAME) ? null : accountingProperties.EMPLOYEE_NAME)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("GRANT_REG_ID={0}", string.IsNullOrEmpty(accountingProperties.GRANT_REGISTRATION_ID) ? null : accountingProperties.GRANT_REGISTRATION_ID)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("GRANT_OPTION_ID={0}", string.IsNullOrEmpty(accountingProperties.GRANT_OPTION_ID) ? null : accountingProperties.GRANT_OPTION_ID)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("SENIOR_MANAGEMENT={0}", (Convert.ToString(accountingProperties.Is_SeniorManagement).Equals("1")) ? "Yes" : "No")).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("GRANT_FROM_DATE={0}", accountingProperties.GRANT_FROM_DATE)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("GRANT_TO_DATE={0}", accountingProperties.GRANT_TO_DATE)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_FOR={0}", accountingProperties.DISPLAY_COST_FOR)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_FROM={0}", accountingProperties.COST_FOR_FYNC_YR_FROM)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_TO={0}", accountingProperties.COST_FOR_FYNC_YR_TO)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_FROM={0}", accountingProperties.COST_FOR_FYNC_QTR_FROM)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_TO={0}", accountingProperties.COST_FOR_FYNC_QTR_TO)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_FROM={0}", accountingProperties.COST_FOR_FYNC_MONTH_FROM)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_TO={0}", accountingProperties.COST_FOR_FYNC_MONTH_TO)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("ACC_RPT_GROUP_ID={0}", ac_AccountingReport.s_GroupID)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("CALCULATION_METHOD={0}", userSessionInfo.ACC_CalculationMethod)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("VERSION_NUMBER={0}", ac_AccountingReport.n_VersionNo)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_BEFORE={0}", accountingProperties.DISPLAY_COST_BEFORE)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_AFTER={0}", accountingProperties.DISPLAY_COST_AFTER)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("IS_EMP_ACCESS={0}", (userSessionInfo.ACC_IsEmpAccess.Equals(true) ? "Y" : "N"))).Replace("+", "%2B"));

                accountingReport.hdnAR_SSRSStrForCancellation.Value = Convert.ToString(
                    genericServiceClient.EncryptString("RptID=14").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("REPORTING_DATE={0}", accountingReport.txtARDate.Text)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("MARKET_PRICE_TYPE={0}", accountingReport.rdoARMarketPriceType.SelectedItem.Value)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("SCHEME_NAME={0}", string.IsNullOrEmpty(accountingProperties.SCHEME_NAME) ? null : accountingProperties.SCHEME_NAME)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_ID={0}", string.IsNullOrEmpty(accountingProperties.EMPLOYEE_ID) ? null : accountingProperties.EMPLOYEE_ID)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_NAME={0}", string.IsNullOrEmpty(accountingProperties.EMPLOYEE_NAME) ? null : accountingProperties.EMPLOYEE_NAME)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("GRANT_REG_ID={0}", string.IsNullOrEmpty(accountingProperties.GRANT_REGISTRATION_ID) ? null : accountingProperties.GRANT_REGISTRATION_ID)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("GRANT_OPTION_ID={0}", string.IsNullOrEmpty(accountingProperties.GRANT_OPTION_ID) ? null : accountingProperties.GRANT_OPTION_ID)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("SENIOR_MANAGEMENT={0}", (Convert.ToString(accountingProperties.Is_SeniorManagement).Equals("1")) ? "Yes" : "No")).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("GRANT_FROM_DATE={0}", accountingProperties.GRANT_FROM_DATE)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("GRANT_TO_DATE={0}", accountingProperties.GRANT_TO_DATE)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_FOR={0}", accountingProperties.DISPLAY_COST_FOR)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_FROM={0}", accountingProperties.COST_FOR_FYNC_YR_FROM)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_TO={0}", accountingProperties.COST_FOR_FYNC_YR_TO)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_FROM={0}", accountingProperties.COST_FOR_FYNC_QTR_FROM)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_TO={0}", accountingProperties.COST_FOR_FYNC_QTR_TO)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_FROM={0}", accountingProperties.COST_FOR_FYNC_MONTH_FROM)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_TO={0}", accountingProperties.COST_FOR_FYNC_MONTH_TO)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("OPTIONS={0}", string.Empty)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("CANCELLATION_FROM_DATE={0}", string.Empty)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("CANCELLATION_TO_DATE={0}", string.Empty)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("ACC_RPT_GROUP_ID={0}", ac_AccountingReport.s_GroupID)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("CALCULATION_METHOD={0}", userSessionInfo.ACC_CalculationMethod)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("VERSION_NUMBER={0}", ac_AccountingReport.n_VersionNo)).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("IS_EMP_ACCESS={0}", (userSessionInfo.ACC_IsEmpAccess.Equals(true) ? "Y" : "N"))).Replace("+", "%2B")
                + "&" + genericServiceClient.EncryptString(string.Format("DATE_CONSIDER_FOR_UNVESTED_OPTIONS={0}", string.Empty)).Replace("+", "%2B"));

                accountingReport.hdnAR_SSRSStrForSummary.Value = Convert.ToString(
                    genericServiceClient.EncryptString("RptID=" + Convert.ToString(userSessionInfo.ACC_CalculationMethod.Equals(1) ? 15 : 16)).Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("REPORTING_DATE={0}", accountingReport.txtARDate.Text)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("MARKET_PRICE_TYPE={0}", accountingReport.rdoARMarketPriceType.SelectedItem.Value)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("SCHEME_NAME={0}", string.IsNullOrEmpty(accountingProperties.SCHEME_NAME) ? GetSelectedItems(accountingReport.mddlARSchemeName.chkMultiselect) : accountingProperties.SCHEME_NAME)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_ID={0}", string.IsNullOrEmpty(accountingProperties.EMPLOYEE_ID) ? GetSelectedItems(accountingReport.mddlAREmployeeID.chkMultiselect) : accountingProperties.EMPLOYEE_ID)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_NAME={0}", string.IsNullOrEmpty(accountingProperties.EMPLOYEE_NAME) ? GetSelectedItems(accountingReport.mddlAREmployeeName.chkMultiselect) : accountingProperties.EMPLOYEE_NAME)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("GRANT_REG_ID={0}", string.IsNullOrEmpty(accountingProperties.GRANT_REGISTRATION_ID) ? GetSelectedItems(accountingReport.mddlARGrantRegID.chkMultiselect) : accountingProperties.GRANT_REGISTRATION_ID)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("GRANT_OPTION_ID={0}", string.IsNullOrEmpty(accountingProperties.GRANT_OPTION_ID) ? GetSelectedItems(accountingReport.mddlARGrantOptID.chkMultiselect) : accountingProperties.GRANT_OPTION_ID)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("SENIOR_MANAGEMENT={0}", (Convert.ToString(accountingProperties.Is_SeniorManagement).Equals("1")) ? "Yes" : "No")).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("GRANT_FROM_DATE={0}", accountingProperties.GRANT_FROM_DATE)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("GRANT_TO_DATE={0}", accountingProperties.GRANT_TO_DATE)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_FOR={0}", accountingProperties.DISPLAY_COST_FOR)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_FROM={0}", accountingProperties.COST_FOR_FYNC_YR_FROM)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_TO={0}", accountingProperties.COST_FOR_FYNC_YR_TO)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_FROM={0}", accountingProperties.COST_FOR_FYNC_QTR_FROM)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_TO={0}", accountingProperties.COST_FOR_FYNC_QTR_TO)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_FROM={0}", accountingProperties.COST_FOR_FYNC_MONTH_FROM)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_TO={0}", accountingProperties.COST_FOR_FYNC_MONTH_TO)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("ACC_RPT_GROUP_ID={0}", ac_AccountingReport.s_GroupID)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("CALCULATION_METHOD={0}", userSessionInfo.ACC_CalculationMethod)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("VERSION_NUMBER={0}", ac_AccountingReport.n_VersionNo)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_BEFORE={0}", accountingProperties.DISPLAY_COST_BEFORE)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_AFTER={0}", accountingProperties.DISPLAY_COST_AFTER)).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("LEVEL1={0}", "0")).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("LEVEL2={0}", "0")).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("LEVEL3={0}", "0")).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("LEVEL4={0}", "0")).Replace("+", "%2B")
               + "&" + genericServiceClient.EncryptString(string.Format("LEVEL5={0}", "0")).Replace("+", "%2B")
               );
            }
        }

        /// <summary>
        /// used to encrypt query string data on edit case
        /// </summary>
        /// <param name="accountingReport">AccountingReport page object</param>
        /// <param name="dt_Details">dt_Details</param>
        internal void EncryptData_Edit(AccountingReport accountingReport, DataTable dt_Details)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                accountingReport.hdnAR_SSRSQueryString.Value = Convert.ToString(
                    genericServiceClient.EncryptString("RptID=12").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("REPORTING_DATE={0}", dt_Details.Rows[0]["REPORTING_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("MARKET_PRICE_TYPE={0}", dt_Details.Rows[0]["MARKET_PRICE_TYPE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("SCHEME_NAME={0}", dt_Details.Rows[0]["SCHEME_NAME"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_ID={0}", dt_Details.Rows[0]["EMPLOYEE_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_NAME={0}", dt_Details.Rows[0]["EMPLOYEE_NAME"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_REG_ID={0}", dt_Details.Rows[0]["GRANT_REGISTRATION_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_OPTION_ID={0}", dt_Details.Rows[0]["GRANT_OPTION_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("SENIOR_MANAGEMENT={0}", (Convert.ToString(dt_Details.Rows[0]["IS_SENIOR_MANAGEMENT"]).Equals("1")) ? "Yes" : "No")).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_FROM_DATE={0}", dt_Details.Rows[0]["GRANT_FROM_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_TO_DATE={0}", dt_Details.Rows[0]["GRANT_TO_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_FOR={0}", dt_Details.Rows[0]["DISPLAY_COST_FOR"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_YR_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_YR_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_QTR_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_QTR_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_MONTH_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_MONTH_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("ACC_RPT_GROUP_ID={0}", dt_Details.Rows[0]["ACC_RPT_GROUP_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("VERSION_NUMBER={0}", dt_Details.Rows[0]["VERSION_NUMBER"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("CALCULATION_METHOD={0}", userSessionInfo.ACC_CalculationMethod)).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_BEFORE={0}", dt_Details.Rows[0]["DISPLAY_COST_BEFORE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_AFTER={0}", dt_Details.Rows[0]["DISPLAY_COST_AFTER"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("IS_EMP_ACCESS={0}", (userSessionInfo.ACC_IsEmpAccess.Equals(true) ? "Y" : "N"))).Replace("+", "%2B"));

                accountingReport.hdnAR_SSRSStrForCancellation.Value = Convert.ToString(
                    genericServiceClient.EncryptString("RptID=14").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("REPORTING_DATE={0}", dt_Details.Rows[0]["REPORTING_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("MARKET_PRICE_TYPE={0}", dt_Details.Rows[0]["MARKET_PRICE_TYPE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("SCHEME_NAME={0}", dt_Details.Rows[0]["SCHEME_NAME"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_ID={0}", dt_Details.Rows[0]["EMPLOYEE_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_NAME={0}", dt_Details.Rows[0]["EMPLOYEE_NAME"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_REG_ID={0}", dt_Details.Rows[0]["GRANT_REGISTRATION_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_OPTION_ID={0}", dt_Details.Rows[0]["GRANT_OPTION_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("SENIOR_MANAGEMENT={0}", (Convert.ToString(dt_Details.Rows[0]["IS_SENIOR_MANAGEMENT"]).Equals("1")) ? "Yes" : "No")).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_FROM_DATE={0}", dt_Details.Rows[0]["GRANT_FROM_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_TO_DATE={0}", dt_Details.Rows[0]["GRANT_TO_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_FOR={0}", dt_Details.Rows[0]["DISPLAY_COST_FOR"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_YR_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_YR_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_QTR_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_QTR_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_MONTH_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_MONTH_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("OPTIONS={0}", string.Empty)).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("CANCELLATION_FROM_DATE={0}", string.Empty)).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("CANCELLATION_TO_DATE={0}", string.Empty)).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("ACC_RPT_GROUP_ID={0}", dt_Details.Rows[0]["ACC_RPT_GROUP_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("VERSION_NUMBER={0}", dt_Details.Rows[0]["VERSION_NUMBER"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("CALCULATION_METHOD={0}", userSessionInfo.ACC_CalculationMethod)).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("IS_EMP_ACCESS={0}", (userSessionInfo.ACC_IsEmpAccess.Equals(true) ? "Y" : "N"))).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DATE_CONSIDER_FOR_UNVESTED_OPTIONS={0}", dt_Details.Rows[0]["DATE_CONSIDER_FOR_UNVESTED_OPTIONS"])).Replace("+", "%2B"));

                accountingReport.hdnAR_SSRSStrForSummary.Value = Convert.ToString(
                    genericServiceClient.EncryptString("RptID=" + Convert.ToString(userSessionInfo.ACC_CalculationMethod.Equals(1) ? 15 : 16)).Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("REPORTING_DATE={0}", dt_Details.Rows[0]["REPORTING_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("MARKET_PRICE_TYPE={0}", dt_Details.Rows[0]["MARKET_PRICE_TYPE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("SCHEME_NAME={0}", dt_Details.Rows[0]["SCHEME_NAME"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_ID={0}", dt_Details.Rows[0]["EMPLOYEE_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("EMPLOYEE_NAME={0}", dt_Details.Rows[0]["EMPLOYEE_NAME"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_REG_ID={0}", dt_Details.Rows[0]["GRANT_REGISTRATION_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_OPTION_ID={0}", dt_Details.Rows[0]["GRANT_OPTION_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("SENIOR_MANAGEMENT={0}", (Convert.ToString(dt_Details.Rows[0]["IS_SENIOR_MANAGEMENT"]).Equals("1")) ? "Yes" : "No")).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_FROM_DATE={0}", dt_Details.Rows[0]["GRANT_FROM_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("GRANT_TO_DATE={0}", dt_Details.Rows[0]["GRANT_TO_DATE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_FOR={0}", dt_Details.Rows[0]["DISPLAY_COST_FOR"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_YR_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_YR_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_YR_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_QTR_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_QTR_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_QTR_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_FROM={0}", dt_Details.Rows[0]["COST_FOR_FYNC_MONTH_FROM"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("COST_FOR_FYNC_MONTH_TO={0}", dt_Details.Rows[0]["COST_FOR_FYNC_MONTH_TO"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("ACC_RPT_GROUP_ID={0}", dt_Details.Rows[0]["ACC_RPT_GROUP_ID"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("VERSION_NUMBER={0}", dt_Details.Rows[0]["VERSION_NUMBER"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("CALCULATION_METHOD={0}", userSessionInfo.ACC_CalculationMethod)).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_BEFORE={0}", dt_Details.Rows[0]["DISPLAY_COST_BEFORE"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("DISPLAY_COST_AFTER={0}", dt_Details.Rows[0]["DISPLAY_COST_AFTER"])).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("LEVEL1={0}", "0")).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("LEVEL2={0}", "0")).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("LEVEL3={0}", "0")).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("LEVEL4={0}", "0")).Replace("+", "%2B")
                     + "&" + genericServiceClient.EncryptString(string.Format("LEVEL5={0}", "0")).Replace("+", "%2B")
                     );
            }
        }

        /// <summary>
        /// Method returns checkBoxList control
        /// </summary>
        /// <param name="checkBoxList">checkBoxList</param>
        /// <returns>returns checkBoxList control</returns>
        public string GetSelectedItems(CheckBoxList checkBoxList)
        {
            try
            {
                string s_AllItems = string.Empty;
                foreach (ListItem CurrentItem in checkBoxList.Items)
                {
                    if (string.IsNullOrEmpty(s_AllItems))
                        s_AllItems = CurrentItem.Text.Trim();
                    else
                        s_AllItems += "," + CurrentItem.Text.Trim();
                }
                return s_AllItems;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method returns comma separated string
        /// </summary>
        /// <param name="checkBoxList">checkBoxList</param>
        /// <param name="textBox">textBox</param>
        /// <returns>returns comma separated string</returns>
        public string SearchEmployeeData(CheckBoxList checkBoxList, TextBox textBox)
        {
            try
            {
                string s_CheckedItems = string.Empty, s_SetTextBoxVal = string.Empty;
                foreach (ListItem CurrentItem in checkBoxList.Items)
                {
                    if (CurrentItem.Selected)
                    {
                        if (string.IsNullOrEmpty(s_CheckedItems))
                        {
                            s_CheckedItems = CurrentItem.Text.Trim();
                            s_SetTextBoxVal = CurrentItem.Text.Trim();
                        }
                        else
                        {
                            s_CheckedItems += "," + CurrentItem.Text.Trim();
                            s_SetTextBoxVal += "," + CurrentItem.Text.Trim();
                        }
                    }
                }
                if (!string.IsNullOrEmpty(s_CheckedItems))
                    textBox.Text = s_SetTextBoxVal;
                else
                {
                    textBox.Text = "--- Please Select ---";
                    s_CheckedItems = GetSelectedItems(checkBoxList);
                }
                return s_CheckedItems;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used customize grid header
        /// </summary>
        /// <param name="gridView">gridView</param>
        /// <param name="gridRow">gridRow</param>
        /// <param name="headerLevels">headerLevels</param>
        /// <param name="accountingReport">AccountingReport page object</param>
        /// <param name="s_GridID">s_GridID</param>
        /// <param name="ht_SchemeWIse">ht_SchemeWIse</param>
        public void CustomizeGridHeader(GridView gridView, GridViewRow gridRow, int headerLevels, AccountingReport accountingReport, string s_GridID, ref Hashtable ht_SchemeWIse)
        {
            switch (gridRow.RowType)
            {
                case DataControlRowType.Header:
                    for (int item = 1; item <= headerLevels; item++)
                    {
                        //creating new header row
                        GridViewRow gridviewRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
                        IEnumerable<System.Linq.IGrouping<string, string>> gridHeaders = null;
                        int n_Count = 0;
                        //reading existing header 
                        gridHeaders = gridRow.Cells.Cast<TableCell>()
                                    .Select(cell => GetHeaderText(cell.Text, item))
                                    .GroupBy(headerText => headerText);

                        foreach (var header in gridHeaders)
                        {
                            if (header.Key.ToString().Contains('|') || header.Key.ToString().Contains("split"))
                            {
                                n_Count = n_Count + 1;
                                goto nextLoop;
                            }
                        }

                    nextLoop:
                        foreach (var header in gridHeaders)
                        {
                            using (TableHeaderCell cell = new TableHeaderCell())
                            {
                                cell.Text = header.Key.ToString();

                                if (Convert.ToString(header.Key).Contains("Cost Before") || Convert.ToString(header.Key).Contains("Cost After"))
                                {
                                    string s_HeaderText = header.Key.Substring(0, header.Key.LastIndexOf(" "));

                                    switch (s_HeaderText.ToUpper())
                                    {
                                        case "COST BEFORE FY":
                                            cell.Visible = accountingReport.rdoARDisplayCostBefore.SelectedValue.Equals("Y");
                                            break;

                                        case "COST AFTER FY":
                                            cell.Visible = accountingReport.rdoARDisplayCostAfter.SelectedValue.Equals("Y");
                                            break;
                                    }
                                }
                                else
                                    cell.Visible = !(cell.Text.Equals("COST_TYPE") || cell.Text.Equals("COST") || cell.Text.Equals("AGRMID") || cell.Text.Equals("OPT_VEST_ID") || cell.Text.Contains("OPT_GRANTED_ID") || cell.Text.Equals("OPTION_ID") || cell.Text.Equals("OP_OPTION_ID")
                                    || cell.Text.Contains("COST_SUM") || cell.Text.Contains("TOTAL_COST") || cell.Text.Contains("GRANT_OPTION_ID")
                                    || cell.Text.Contains("VPD_VESTING_PERIOD_ID") || cell.Text.Contains("OP_VESTING_PERIOD_ID") || cell.Text.Contains("SCH_SCHEME_TITLE") || cell.Text.Contains("HCOST") || cell.Text.Contains("VAL_METHOD") || cell.Text.Contains("OP_VAL_METHOD") || cell.Text.Contains("VALUATION_METHOD") || cell.Text.Contains("OPID"));

                                if (gridView.ID.Equals("gvARSummaryReport"))
                                {
                                    switch (cell.Text.ToUpper())
                                    {
                                        case "SCHEME NAME":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SCHEME_NAME'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SCHEME_NAME'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SCHEME_NAME'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SCHEME_NAME'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "EMPLOYEE ID":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_ID'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "EMPLOYEE NAME":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_NAME'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "GRANT REGISTRATION ID":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "GRANT OPTION ID":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANT_OPTION_ID'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANT_OPTION_ID'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANT_OPTION_ID'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANT_OPTION_ID'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "GRANT DATE":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_DATE'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_DATE'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_DATE'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_GRANT_DATE'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "GRADE":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRADE'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRADE'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRADE'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRADE'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "DESIGNATION":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DESIGNATION'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DESIGNATION'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DESIGNATION'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DESIGNATION'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "SENIOR MANAGEMENT":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SENIOR MANAGEMENT'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SENIOR MANAGEMENT'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SENIOR MANAGEMENT'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'SENIOR MANAGEMENT'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "DATE OF JOINING":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DATE_OF_JOINING'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DATE_OF_JOINING'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DATE_OF_JOINING'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'DATE_OF_JOINING'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "VEST ID":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_PERIOD_NO'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_PERIOD_NO'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_PERIOD_NO'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_PERIOD_NO'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "VEST DATE":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_DATE'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_DATE'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_DATE'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_VESTING_DATE'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "VEST %":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VEST_PERCENT'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VEST_PERCENT'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VEST_PERCENT'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VEST_PERCENT'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;


                                        case "OPTIONS GRANTED":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANTED_OPTIONS'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANTED_OPTIONS'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANTED_OPTIONS'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRANTED_OPTIONS'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "OPTIONS VESTED CANCELLED":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "OPTIONS UNVESTED CANCELLED":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "OPTIONS LAPSED":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LAPSED_OPTIONS'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LAPSED_OPTIONS'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LAPSED_OPTIONS'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LAPSED_OPTIONS'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "VESTED AND EXERCISABLE OPTIONS":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_AND_EXERCISABLE'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_AND_EXERCISABLE'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_AND_EXERCISABLE'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VESTED_AND_EXERCISABLE'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "UNVESTED OPTIONS":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_OPTIONS'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_OPTIONS'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_OPTIONS'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'UNVESTED_OPTIONS'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "OUTSTANDING OPTIONS":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "EXERCISED OPTIONS":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "LIVE OPTIONS FOR COMPENSATION COST":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LIVE_OPTIONS_FOR_COMPENSATION_COST'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LIVE_OPTIONS_FOR_COMPENSATION_COST'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LIVE_OPTIONS_FOR_COMPENSATION_COST'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'LIVE_OPTIONS_FOR_COMPENSATION_COST'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "ACCLELARATED OPTIONS":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_QUANTITY'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_QUANTITY'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_QUANTITY'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_QUANTITY'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "ACCELERATED VESTING DATE":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_DATE'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_DATE'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_DATE'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'ACCELERATED_DATE'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "FORFEITURE GROUP":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "RATE APPLIED":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'RATE_APPLIED'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'RATE_APPLIED'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'RATE_APPLIED'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'RATE_APPLIED'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "FORFEITURE RATE":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_RATE'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_RATE'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_RATE'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'FORFEITURE_RATE'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "OPTIONS LIKELY TO BE FORFEITED":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OPTIONS_LIKELY_TO_BE_FORFEITED'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OPTIONS_LIKELY_TO_BE_FORFEITED'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OPTIONS_LIKELY_TO_BE_FORFEITED'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'OPTIONS_LIKELY_TO_BE_FORFEITED'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "NET OPTIONS FOR COMPENSATION COST":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'NET_OPTIONS_FOR_COMPENSATION_COST'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'NET_OPTIONS_FOR_COMPENSATION_COST'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'NET_OPTIONS_FOR_COMPENSATION_COST'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'NET_OPTIONS_FOR_COMPENSATION_COST'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "CURRENCY":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'CURRENCY_NAME'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'CURRENCY_NAME'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'CURRENCY_NAME'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'CURRENCY_NAME'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "EXERCISE PRICE":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_EXERCISE_PRICE'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_EXERCISE_PRICE'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_EXERCISE_PRICE'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'GRS_EXERCISE_PRICE'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "EXERCISE PRICE POST CORPORATE ACTION / MODIFICATION":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISE_PRICE_POST_CORPORATE_ACTION_MODIFICATION'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISE_PRICE_POST_CORPORATE_ACTION_MODIFICATION'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISE_PRICE_POST_CORPORATE_ACTION_MODIFICATION'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'EXERCISE_PRICE_POST_CORPORATE_ACTION_MODIFICATION'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                       case "EXPIRY DATE":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_EXPIRY_DATE'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_EXPIRY_DATE'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_EXPIRY_DATE'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'VPD_EXPIRY_DATE'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;

                                        case "IV_FV":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;
                                      
                                        case "IV_FV POST CORPORATE ACTION / MODIFICATION / CHANGE IN ESTIMATED DATE OF LISTING":
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV_POST_CORP_ACT_MODF_EDL'").Count() > 0;
                                            cell.Visible = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? true : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV_POST_CORP_ACT_MODF_EDL'").Count() > 0;
                                            dr = ac_AccountingReport.dt_CustmizedViewAccounting == null || ac_AccountingReport.dt_CustmizedViewAccounting.Rows.Count.Equals(0) ? null : ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV_POST_CORP_ACT_MODF_EDL'").Count() > 0 ? ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV_POST_CORP_ACT_MODF_EDL'") : null;
                                            cell.Text = dr != null && ac_AccountingReport.dt_CustmizedViewAccounting.Select("COLUMN_NAME = 'IV_FV_POST_CORP_ACT_MODF_EDL'").Count() > 0 ?
                                                             dr[0]["COLUMN_ALIAS"].ToString()
                                                            : cell.Text;
                                            break;
                                        case "IV_FV PARAMETERS SPLIT |EXPECTED LIFE":
                                        case "IV_FV PARAMETERS SPLIT |VOLATILITY":
                                        case "IV_FV PARAMETERS SPLIT |DIVIDEND":
                                        case "IV_FV PARAMETERS SPLIT |RFIR":
                                        case "IV_FV PARAMETERS VALUES SPLIT |EXPECTED LIFE":
                                        case "IV_FV PARAMETERS VALUES SPLIT |VOLATILITY (%)":
                                        case "IV_FV PARAMETERS VALUES SPLIT |DIVIDEND (%)":
                                        case "IV_FV PARAMETERS VALUES SPLIT |RFIR (%)":
                                            cell.Visible = accountingReport.rdoARMarketPriceType.SelectedItem.Text.Equals("FV");
                                            break;
                                    }
                                }
                                if (item == 2)
                                {
                                    if (!cell.Text.Contains("split"))
                                        goto nextHeader;
                                    cell.Text = header.Key.Substring(header.Key.LastIndexOf(CommonConstantModel.s_seperator) + 1);
                                }
                                else
                                {
                                    if (cell.Text.Contains("split"))
                                    {
                                        cell.Text = cell.Text.Replace("split", "");
                                        if (cell.Text.Contains("IV_FV Parameters"))
                                            cell.ColumnSpan = accountingReport.rdoARMarketPriceType.SelectedItem.Text.Equals("FV") ? 5 : 1;
                                        else if (cell.Text.Contains("OP_") || cell.Text.Contains("QO_"))
                                            cell.ColumnSpan = 3;
                                        else if (cell.Text.Contains("Q_") && accountingReport.rdoARDisplayCostFor.SelectedItem.Value.Equals("Q"))
                                        {
                                            if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---")
                                               && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---")
                                               && accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Trim().Equals(accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Trim()))
                                            {
                                                cell.ColumnSpan = (Convert.ToInt32(accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Trim().ToUpper().Replace("QUARTER ", ""))
                                                    - Convert.ToInt32(accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Trim().ToUpper().Replace("QUARTER ", ""))) + 2;
                                            }
                                            else
                                            {
                                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                                {
                                                    switch (accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Trim().ToUpper())
                                                    {
                                                        case "QUARTER 1": cell.ColumnSpan = 5; break;
                                                        case "QUARTER 2": cell.ColumnSpan = 4; break;
                                                        case "QUARTER 3": cell.ColumnSpan = 3; break;
                                                        case "QUARTER 4": cell.ColumnSpan = 2; break;
                                                    }
                                                }
                                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                                {
                                                    switch (accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Trim().ToUpper())
                                                    {
                                                        case "QUARTER 1": cell.ColumnSpan = 2; break;
                                                        case "QUARTER 2": cell.ColumnSpan = 3; break;
                                                        case "QUARTER 3": cell.ColumnSpan = 4; break;
                                                        case "QUARTER 4": cell.ColumnSpan = 5; break;
                                                    }
                                                }
                                                else cell.ColumnSpan = 5;
                                            }
                                        }
                                        else if (cell.Text.Contains("Q_") && accountingReport.rdoARDisplayCostFor.SelectedItem.Value.Equals("M"))
                                            cell.ColumnSpan = 13;
                                        else if (accountingReport.rdoARDisplayCostFor.SelectedItem.Value.Equals("Q"))
                                        {
                                            if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---")
                                                && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---")
                                                && accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Trim().Equals(accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Trim()))
                                            {
                                                cell.ColumnSpan = (Convert.ToInt32(accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Trim().ToUpper().Replace("QUARTER ", ""))
                                                    - Convert.ToInt32(accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Trim().ToUpper().Replace("QUARTER ", ""))) + 1;
                                            }
                                            else
                                            {
                                                if (!accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                                {
                                                    switch (accountingReport.ddlARFinancialQrFrom.SelectedItem.Value.Trim().ToUpper())
                                                    {
                                                        case "QUARTER 1": cell.ColumnSpan = 4; break;
                                                        case "QUARTER 2": cell.ColumnSpan = 3; break;
                                                        case "QUARTER 3": cell.ColumnSpan = 2; break;
                                                        case "QUARTER 4": cell.ColumnSpan = 1; break;
                                                    }
                                                }
                                                if (!accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                                {
                                                    switch (accountingReport.ddlARFinancialQrTo.SelectedItem.Value.Trim().ToUpper())
                                                    {
                                                        case "QUARTER 1": cell.ColumnSpan = 1; break;
                                                        case "QUARTER 2": cell.ColumnSpan = 2; break;
                                                        case "QUARTER 3": cell.ColumnSpan = 3; break;
                                                        case "QUARTER 4": cell.ColumnSpan = 4; break;
                                                    }
                                                }
                                                else cell.ColumnSpan = 4;
                                            }
                                        }
                                        else if (accountingReport.rdoARDisplayCostFor.SelectedItem.Value.Equals("M"))
                                            cell.ColumnSpan = 12;
                                        else cell.ColumnSpan = 2;
                                    }
                                    else if (n_Count <= 0)
                                        cell.RowSpan = 1;
                                    else cell.RowSpan = 2;
                                }
                                gridviewRow.Cells.Add(cell);
                                // Adding new header to the grid
                                gridView.Controls[0].Controls.AddAt(gridRow.RowIndex, gridviewRow);
                                if (cell.Text.Contains("IV_FV"))
                                {
                                    if (accountingReport.rdoARMarketPriceType.SelectedItem.Value.Equals("IV"))
                                        cell.Text = cell.Text.Replace("IV_FV", "Intrinsic Value");
                                    else cell.Text = cell.Text.Replace("IV_FV", "Fair Value");
                                }

                                if (cell.Text.Contains("OP_Cost"))
                                    cell.Text = cell.Text.Replace("OP_Cost", "Options");
                                if (cell.Text.Contains("QO_Cost"))
                                    cell.Text = cell.Text.Replace("QO_Cost", "Options");
                                if (cell.Text.Contains("OP_"))
                                    cell.Text = cell.Text.Replace("OP_", "");
                                if (cell.Text.Contains("QO_"))
                                    cell.Text = cell.Text.Replace("QO_", "");
                                if (cell.Text.Contains("Q_"))
                                    cell.Text = cell.Text.Replace("Q_", "");
                                cell.HorizontalAlign = HorizontalAlign.Center;
                            }
                        nextHeader: ;
                        }
                    }
                    //hiding existing header
                    gridRow.Visible = false;
                    break;

                case DataControlRowType.DataRow:
                    #region Below code does decimal rounding , Thousand separating and aligns to the right.
                    using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                    {
                        switch (s_GridID)
                        {
                            case "gvARMainReport":
                                for (int n_CellCount = 1; n_CellCount < gridRow.Cells.Count; n_CellCount++)
                                {
                                    if (!string.IsNullOrEmpty(Convert.ToString(gridRow.Cells[n_CellCount].Text)) && !Convert.ToString(gridRow.Cells[n_CellCount].Text).Equals("&nbsp;"))
                                    {
                                        switch (n_CellCount)
                                        {
                                            case 1:
                                                gridRow.Cells[n_CellCount].Visible = true;
                                                break;

                                            case 7:
                                                if (gridRow.Cells.Count.Equals(8) && accountingReport.rdoARDisplayCostFor.SelectedValue.Equals("Y"))
                                                    gridRow.Cells[n_CellCount].Visible = accountingReport.rdoARDisplayCostAfter.SelectedValue.Equals("Y");
                                                break;

                                            case 8:
                                                if (accountingReport.rdoARDisplayCostFor.SelectedValue.Equals("Y"))
                                                    gridRow.Cells[n_CellCount].Visible = accountingReport.rdoARDisplayCostAfter.SelectedValue.Equals("Y");
                                                break;
                                        }

                                        //if (accountingReport.rdoARDisplayCostFor.SelectedValue.Equals("Q") || accountingReport.rdoARDisplayCostFor.SelectedValue.Equals("M"))
                                        //    gridRow.Cells[gridRow.Cells.Count - 1].Visible = accountingReport.rdoARDisplayCostAfter.SelectedValue.Equals("Y");

                                        gridRow.Cells[n_CellCount].Text = Convert.ToDouble(gridRow.Cells[n_CellCount].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(gridRow.Cells[n_CellCount].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(gridRow.Cells[n_CellCount].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                    }

                                    gridRow.Cells[n_CellCount].HorizontalAlign = HorizontalAlign.Right;
                                }
                                break;

                            case "gvARSummaryReport":
                                /* FV, IV decimal rounding , Thousand separating */
                                for (int n_CellCount = Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COST"]); n_CellCount < gridRow.Cells.Count - 1; n_CellCount++)
                                {
                                    if (n_CellCount == Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COST"]) + 1)
                                        gridRow.Cells[n_CellCount].Visible = accountingReport.rdoARDisplayCostBefore.SelectedValue.Equals("Y");

                                    else if (n_CellCount == Convert.ToInt32(ht_SchemeWIse["n_SR_OP_OPTION_ID"]) - 1)
                                        gridRow.Cells[n_CellCount].Visible = accountingReport.rdoARDisplayCostAfter.SelectedValue.Equals("Y"); ;

                                    gridRow.Cells[n_CellCount].HorizontalAlign = HorizontalAlign.Right;
                                }

                                gridRow.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].HorizontalAlign = HorizontalAlign.Right;

                                if (accountingReport.rdoARMarketPriceType.SelectedItem.Text.Equals("IV"))
                                {
                                    gridRow.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVP_EL"])].Visible =
                                    gridRow.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVP_VOL"])].Visible =
                                    gridRow.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVP_DIV"])].Visible =
                                    gridRow.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVP_RFIR"])].Visible =
                                    gridRow.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Visible =
                                    gridRow.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Visible =
                                    gridRow.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Visible =
                                    gridRow.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Visible = false;
                                }

                                break;
                        }
                    }
                    #endregion
                    break;
            }
        }

        /// <summary>
        /// Method returns header text
        /// </summary>
        /// <param name="headerText">headerText</param>
        /// <param name="headerLevel">headerLevel</param>
        /// <returns>returns header text</returns>
        public string GetHeaderText(string headerText, int headerLevel)
        {
            if (headerLevel == 2)
            {
                return headerText;
            }
            if (headerText.LastIndexOf(CommonConstantModel.s_seperator) > 0)
                return headerText.Substring(0, headerText.LastIndexOf(CommonConstantModel.s_seperator));
            else return headerText;
        }

        /// <summary>
        /// This method is used to set selected items
        /// </summary>
        /// <param name="checkBoxList">checkBoxList</param>
        /// <param name="textBox">textBox</param>
        /// <param name="s_Values">s_Values</param>
        public void SetSelectedItems(CheckBoxList checkBoxList, TextBox textBox, string s_Values)
        {
            try
            {
                if (!string.IsNullOrEmpty(s_Values))
                {
                    foreach (ListItem CurrentItem in checkBoxList.Items)
                    {
                        int pos = Array.IndexOf(s_Values.Split(','), CurrentItem.Text);
                        if (pos > -1)
                        {
                            CurrentItem.Selected = true;
                        }
                    }
                    textBox.Text = s_Values;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// used to clear selected items
        /// </summary>
        /// <param name="checkBoxList">checkBoxList</param>
        /// <param name="textBox">textBox</param>
        public void ClearSelectedItems(CheckBoxList checkBoxList, TextBox textBox)
        {
            try
            {
                checkBoxList.Items.Clear();
                textBox.Text = "--- Please Select ---";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// THis method is used to trigger an email to the user/reviewer
        /// </summary>
        /// <param name="s_XMLFileName">s_XMLFileName</param>
        /// <param name="accountingReport">AccountingReport page object</param>
        /// <param name="s_MailTo">s_MailTo</param>
        /// <param name="s_ACC_RPT_GROUP_ID">s_ACC_RPT_GROUP_ID</param>
        /// <param name="n_VERSION_NUMBER">n_VERSION_NUMBER</param>
        public void SendMail(string s_XMLFileName, AccountingReport accountingReport, string s_MailTo, string s_ACC_RPT_GROUP_ID, int n_VERSION_NUMBER)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        string s_EmailIds = string.Empty;
                        switch (s_MailTo)
                        {
                            case "USER":
                                accountingProperties = new AccountingProperties();
                                accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                                accountingProperties.PopulateControls = "GET_WORKING_DETAILS_BY_VERSION";
                                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(s_ACC_RPT_GROUP_ID);
                                accountingProperties.VERSION_NUMBER = Convert.ToInt32(n_VERSION_NUMBER);
                                DataTable dt_Details = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result.Tables[0];
                                s_EmailIds = Convert.ToString(dt_Details.Rows[0]["EMAIL_ID"]);
                                break;
                            case "REVIEWER":
                                ac_AccountingReport.dt_ReviewerDetails = genericServiceClient.GetReviewerDetails(genericProperties);
                                if (ac_AccountingReport.dt_ReviewerDetails.Rows.Count > 0)
                                {
                                    int i = 0;
                                    foreach (DataRow row in ac_AccountingReport.dt_ReviewerDetails.Rows)
                                    {
                                        if (string.IsNullOrEmpty(s_EmailIds))
                                            s_EmailIds = ac_AccountingReport.dt_ReviewerDetails.Rows[i][0].ToString();
                                        else s_EmailIds += ", " + ac_AccountingReport.dt_ReviewerDetails.Rows[i][0].ToString();
                                        i = i + 1;
                                    }
                                }
                                break;
                        }
                        emailProperties.s_MailBody = GetMailBody(s_XMLFileName, accountingReport.txtARDate.Text);
                        emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                        emailProperties.b_IsBodyHtml = true;
                        emailProperties.s_MailTo = s_EmailIds;
                        emailProperties.s_MailCC = "";
                        emailProperties.s_MailBCC = "";
                        emailProperties.s_MailSubject = GetMailSubject(emailProperties.s_MailBody);
                        genericServiceClient.SaveSendMail(emailProperties);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// method returns mail subject
        /// </summary>
        /// <param name="s_MailBody">s_MailBody</param>
        /// <returns>returns mail subject</returns>
        public string GetMailSubject(string s_MailBody)
        {
            try
            {
                return Regex.Match(s_MailBody.ToString(), @"<Title>\s*(.+?)\s*</Title>").Value.Replace("\r", "").Replace("<Title>", "").Replace("</Title>", "").Replace("\n", "").Replace("\t", "");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method returns mail body
        /// </summary>
        /// <param name="s_XMLFileName">s_XMLFileName</param>
        /// <param name="s_ReportingDate">s_ReportingDate</param>
        /// <returns>returns mail body</returns>
        public string GetMailBody(string s_XMLFileName, string s_ReportingDate)
        {
            try
            {
                StringBuilder s_MailBody = new StringBuilder();
                s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\" + s_XMLFileName + ".html"));
                s_MailBody.Replace("@UserName", userSessionInfo.ACC_UserName);
                s_MailBody.Replace("@CompanyName", userSessionInfo.ACC_CompanyTitle);
                s_MailBody.Replace("@Link", ConfigurationManager.AppSettings["SiteURL"]);
                s_MailBody.Replace("@ValCustSupportID", ConfigurationManager.AppSettings["ValCustSupport"]);
                s_MailBody.Replace("@ReportingDate", Convert.ToDateTime(s_ReportingDate).ToString("dd/MMM/yyyy"));
                return s_MailBody.ToString();
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Popup Window Methods

        /// <summary>
        /// Method returns list object of valuation parameters
        /// </summary>
        /// <param name="o_GrantRegID">o_GrantRegID</param>
        /// <returns>returns list object of valuation parameters</returns>
        public AccountingProperties[] BindValuationParasToCompare(object o_GrantRegID)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    List<AccountingProperties> o_Details = new List<AccountingProperties>();
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_ReportValuationParams;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_AccountingReport.ds_ReportValuationParams = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                    using (DataTable dt_ValuationParameter = CreateDataTable("SelectGrants"))
                    {
                        dt_ValuationParameter.TableName = "dtValuationParameters";
                        ac_AccountingReport.dt_ReportValuationParams = CreateValuationParamDataTable(accountingServiceClient, dt_ValuationParameter, ac_AccountingReport.ds_ReportValuationParams, Convert.ToString(o_GrantRegID));
                        foreach (DataRow dtrow in ac_AccountingReport.dt_ReportValuationParams.Rows)
                        {
                            accountingProperties = new AccountingProperties();
                            accountingProperties.PARAMETERS_SELECTED_FOR_GRANT = Convert.ToString(dtrow["Parameters Selected for grant"]);
                            accountingProperties.COMPANY_LEVEL_PARAMETERS = Convert.ToString(dtrow["Company Level"]);
                            accountingProperties.PRESENT_GRANT_PARAMETERS = Convert.ToString(dtrow["Present Grant Parameters"]);
                            accountingProperties.IS_MANUALY_UPLOADED = Convert.ToString(dtrow["Present Grant Parameters"]);
                            o_Details.Add(accountingProperties);
                        }
                    }
                    return o_Details.ToArray();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Thos method is used to view IV FV calculations
        /// </summary>
        /// <param name="o_GrantRegID">o_GrantRegID</param>
        /// <param name="o_MP_Type">o_MP_Type</param>
        /// <param name="accountingReport">AccountingReport page object</param>
        public void ViewIVFVCalculations(object o_GrantRegID, string o_MP_Type, AccountingReport accountingReport)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    DataTable dataTable = ac_AccountingReport.ds_ReportDetails.Tables[1].Select("[Grant Registration ID] = '" + o_GrantRegID + "'").CopyToDataTable();

                    using (DataTable outputTable = GetCalculationsIVnFV(ref dataTable, o_MP_Type, Convert.ToString(o_GrantRegID)))
                    {
                        accountingReport.gv2.DataSource = outputTable;
                        accountingReport.gv2.DataBind();
                    }

                    accountingReport.dhnARIsIVFVCalcModal.Value = "true";
                    accountingReport.lblARPopupHeader.Text = o_MP_Type.Equals("IV") ? "Calculation of Intrinsic Value" : "Calculation of Fair value";
                    accountingReport.gvARSummaryReport.DataSource = ac_AccountingReport.ds_ReportDetails.Tables[1];
                    accountingReport.gvARSummaryReport.DataBind();
                    accountingReport.hdnARAccordionIndex.Value = "2";
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method returns IV FV calculations
        /// </summary>
        /// <param name="dt_Details">dt_Details</param>
        /// <param name="s_Select">s_Select</param>
        /// <param name="o_GrantRegID">o_GrantRegID</param>
        /// <returns>returns IV FV calculations</returns>
        public DataTable GetCalculationsIVnFV(ref DataTable dt_Details, string s_Select, string o_GrantRegID)
        {
            try
            {
                using (DataView dataView = new DataView())
                {
                    string s_DecimalLimit = string.Empty;
                    string s_Currency = Convert.ToString(dt_Details.Rows[0]["Currency"]);
                    string s_GrantDate = "Date of Grant: " + Convert.ToDateTime(dt_Details.Rows[0]["Grant Date"]).ToString("dd/MMM/yyyy");
                    ac_AccountingReport.s_FairValue = dt_Details.Rows[0]["IV_FV"].ToString();
                    ac_AccountingReport.s_FinalValue = s_Select.Equals("FV") ? " Fair Value Per Option (" + s_Currency + ")" : "Final Intrinsic Value";
                    s_DecimalLimit = ac_AccountingReport.s_FinalValue.Contains("FV") ? "2" : "1";

                    using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                    {
                        if (userSessionInfo.ACC_IsListed == 1 && Convert.ToDouble(ac_AccountingReport.s_FairValue) > 999)
                            ac_AccountingReport.s_FairValue = CommonModel.ThousandFormating(CommonModel.GetRoundedValue(ac_AccountingReport.s_FairValue, DecimalLimitTable.Select("ADVSID = '" + s_DecimalLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = '" + s_DecimalLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                        else
                            ac_AccountingReport.s_FairValue = CommonModel.GetRoundedValue(ac_AccountingReport.s_FairValue, DecimalLimitTable.Select("ADVSID = '" + s_DecimalLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                    }
                    DataTable dataTable = ac_AccountingReport.dt_VestingDetails.Select("[Grant Registration ID] = '" + o_GrantRegID + "'").CopyToDataTable();
                    dt_Details = new DataView(dataTable).ToTable
                                    ("DT", false,
                                        s_Select.Equals("FV") ?
                                            new string[] { "Vesting Date", "Market Price Per Vest", "Expected Life Per Vest", "Volatility Per Vest", "RFIR Per Vest", "Exercise Price", "Dividend Per Vest", "Fair Value per vest", "Vest Percent (%)", "IS_MU_MKT_FV", "IS_MU_EXL", "IS_MU_VOL", "IS_MU_RFIR", "IS_MU_DIVD", "IS_MU_DIVD_MP_DIVD" } :
                                            new string[] { "Vesting Date", "Market Price IV", "Intrinsic Value per vest", "Exercise Price", "IS_MU_MKT_IV" }
                                    ).Copy();

                    using (DataTable dt_outputTable = new DataTable())
                    {
                        if (!s_Select.Equals("FV"))
                        {
                            dt_Details.Columns["Market Price Per Vest"].ColumnName = "Market Price (A)";
                            dt_Details.Columns["Exercise Price"].ColumnName = "Exercise Price (B)";
                            dt_Details.Columns["Intrinsic Value per vest"].ColumnName = "Intrinsic Value (A-B)";
                        }
                        else
                        {
                            dt_Details.Columns["Market Price Per Vest"].ColumnName = "Market Price (" + s_Currency + ")";
                            dt_Details.Columns["Expected Life Per Vest"].ColumnName = "Expected Life";
                            dt_Details.Columns["Volatility Per Vest"].ColumnName = "Volatility (%)";
                            dt_Details.Columns["RFIR Per Vest"].ColumnName = "Riskfree Rate (%)";
                            dt_Details.Columns["Dividend Per Vest"].ColumnName = "Dividend yield (%)";
                            dt_Details.Columns["Exercise Price"].ColumnName = "Exercise Price (" + s_Currency + ")";
                            dt_Details.Columns["Fair Value per vest"].ColumnName = "Fair Value per vest (" + s_Currency + ")";
                        }

                        // Header row's first column is same as in inputTable
                        dt_outputTable.Columns.Add(dt_Details.Columns[0].ColumnName.ToString());

                        int i = 1;
                        foreach (DataRow perRow in dt_Details.Rows)
                        {
                            DataColumn dataColumn = new DataColumn("Vest " + i + ": " + Convert.ToString(perRow["Vesting Date"]), typeof(string));
                            dt_outputTable.Columns.Add(dataColumn);
                            i++;
                        }
                        dt_outputTable.Columns["Vesting Date"].ColumnName = s_GrantDate;
                        dt_outputTable.Columns.Add("Is_Manually_Updated", typeof(string));

                        for (int rCount = 1; rCount <= dt_Details.Columns.Count - 1; rCount++)
                        {
                            DataRow newRow = dt_outputTable.NewRow();

                            for (int cCount = 0; cCount <= dt_Details.Rows.Count - 1; cCount++)
                            {
                                newRow[0] = dt_Details.Columns[rCount].ColumnName.ToString();
                                newRow[cCount + 1] = dt_Details.Rows[cCount][rCount].ToString();
                            }
                            if (newRow[0].Equals("Dividend yield (%)") || newRow[0].Equals("Fair Value per vest (" + s_Currency + ")"))
                            {
                                dt_outputTable.Rows.Add(newRow);
                                dt_outputTable.Rows.Add(dt_outputTable.NewRow());
                            }
                            else
                            {
                                dt_outputTable.Rows.Add(newRow);

                                switch (dt_outputTable.Rows[dt_outputTable.Rows.Count - 1][0].ToString())
                                {
                                    case "IS_MU_MKT_FV":
                                        if (dt_Details.Rows[0]["IS_MU_MKT_FV"].ToString() == "True")
                                            dt_outputTable.Rows[0]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_MKT_IV":
                                        if (dt_Details.Rows[0]["IS_MU_MKT_IV"].ToString() == "True")
                                            dt_outputTable.Rows[0]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_EXL":
                                        if (dt_Details.Rows[0]["IS_MU_EXL"].ToString() == "True")
                                            dt_outputTable.Rows[1]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_VOL":
                                        if (dt_Details.Rows[0]["IS_MU_VOL"].ToString() == "True")
                                            dt_outputTable.Rows[2]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_RFIR":
                                        if (dt_Details.Rows[0]["IS_MU_RFIR"].ToString() == "True")
                                            dt_outputTable.Rows[3]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_DIVD":
                                        if (dt_Details.Rows[0]["IS_MU_DIVD"].ToString() == "True")
                                            dt_outputTable.Rows[5]["Is_Manually_Updated"] = "1";
                                        break;

                                    case "IS_MU_DIVD_MP_DIVD":
                                        if (dt_Details.Rows[0]["IS_MU_DIVD_MP_DIVD"].ToString() == "True")
                                            dt_outputTable.Rows[5]["Is_Manually_Updated"] = "1";
                                        break;
                                }
                            }
                        }
                        dt_outputTable.AcceptChanges();
                        ac_AccountingReport.n_VestCount = dt_outputTable.Columns.Count;
                        ac_AccountingReport.n_RowCount = dt_outputTable.Rows.Count;
                        return dt_outputTable;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to create Data table
        /// </summary>
        /// <param name="s_StepName">s_StepName</param>
        /// <returns>returns DataTable</returns>
        public DataTable CreateDataTable(string s_StepName)
        {
            try
            {
                using (DataTable dt_tempValuationParameters = new DataTable("DT"))
                {
                    switch (s_StepName)
                    {
                        case "SelectGrants":
                            dt_tempValuationParameters.Columns.Add("Parameters selected for grant", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Company Level", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Present Grant Parameters", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Is Manual Uploaded", typeof(string));
                            break;

                        case "CompareGrants":
                            dt_tempValuationParameters.Columns.Add("Parameters selected for grant", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Company Level", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Update Company Parameters", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Present Grant Parameters", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Update Grant Level Parameters", typeof(string));
                            dt_tempValuationParameters.Columns.Add("Is Manual Uploaded", typeof(string));
                            break;
                    }

                    //Do not change sequence of dataRow i.e. "Parameters selected for grant" it will affect in data binding for datatable
                    DataRow dataRow = null;

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Market Price[Intrinsic Value]";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Market Price[Fair Value]";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Expected Life";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Riskfree Rate";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Volatility";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    dataRow = dt_tempValuationParameters.NewRow();
                    dataRow["Parameters selected for grant"] = "Dividend";
                    dt_tempValuationParameters.Rows.Add(dataRow);

                    return dt_tempValuationParameters;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to create Data table
        /// </summary>
        /// <param name="accountingServiceClient">accountingServiceClient</param>
        /// <param name="dt_ValuationParameter">dt_ValuationParameter</param>
        /// <param name="ds_ValuationParameters">ds_ValuationParameters</param>
        /// <param name="s_GrantID">s_GrantID</param>
        /// <returns></returns>
        public DataTable CreateValuationParamDataTable(AccountingServiceClient accountingServiceClient, DataTable dt_ValuationParameter, DataSet ds_ValuationParameters, string s_GrantID)
        {
            try
            {
                using (DataTable dt_UIParameters = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10_UI))
                {
                    using (DataSet ds = ds_ValuationParameters)
                    {
                        #region Insert values for Market Price[Intrinsic Value]
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table"].Select("COMP_GRANT_REG_ID_IV = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table"].Select("COMP_GRANT_REG_ID_IV = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Stock Exchange concatenated with Parameter 2: Date of Market Price
                                string s_StockExchange = dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_IV"].ToString().Trim() == "lblIVSE01" ?
                                                         "Stock Exchange: " + Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_IV"]).Trim()
                                                         : string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_IV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_IV"] + "'"))[0]["LabelName"]);

                                string s_CalculateIV = "Calculate IV: " + (!string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CALCULATE_IV"])) && Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CALCULATE_IV"]).Equals("1") ? "Yes" : "No");

                                dt_ValuationParameter.Rows[0]["Company Level"] = string.IsNullOrEmpty(s_StockExchange) ? string.Empty : (s_StockExchange + ", ") + (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_IV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_IV"] + "'"))[0]["LabelName"])) + ", " + s_CalculateIV;
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table1"].Select("GRANT_GRANT_REG_ID_IV = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table1"].Select("GRANT_GRANT_REG_ID_IV = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Stock Exchange concatenated with Parameter 2: Date of Market Price
                                string s_StockExchange = dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_IV"].ToString().Trim() == "lblIVSE01" ?
                                                         "Stock Exchange: " + Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EXCHANGE_IV"]).Trim()
                                                         : string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_IV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_IV"] + "'"))[0]["LabelName"]);

                                string s_CalculateIV = "Calculate IV: " + (!string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CALCULATE_IV"])) && Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CALCULATE_IV"]).Equals("1") ? "Yes" : "No");

                                dt_ValuationParameter.Rows[0]["Present Grant Parameters"] = string.IsNullOrEmpty(s_StockExchange) ? string.Empty : (s_StockExchange + ", ") + (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MARKET_PRICE_LABEL_ID_IV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_MARKET_PRICE_LABEL_ID_IV"] + "'"))[0]["LabelName"])) + ", " + s_CalculateIV;
                            }
                        }
                        #endregion

                        #region Fair Value for Market Price[Fair Value]
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table2"].Select("COMP_GRANT_REG_ID_FV = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table2"].Select("COMP_GRANT_REG_ID_FV = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Stock Exchange concatenated with Parameter 2: Date of Market Price
                                string s_StockExchange = dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_FV"].ToString().Trim() == "lblFVSE01" ?
                                                         "Stock Exchange: " + Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_FV"]).Trim()
                                                         : string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_FV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_FV"] + "'"))[0]["LabelName"]);

                                dt_ValuationParameter.Rows[1]["Company Level"] = string.IsNullOrEmpty(s_StockExchange) ? string.Empty : (s_StockExchange + ", ") + (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_FV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_FV"] + "'"))[0]["LabelName"]));
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table3"].Select("GRANT_GRANT_REG_ID_FV = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table3"].Select("GRANT_GRANT_REG_ID_FV = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Stock Exchange concatenated with Parameter 2: Date of Market Price
                                string s_StockExchange = dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_FV"].ToString().Trim() == "lblFVSE01" ?
                                                         "Stock Exchange: " + Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EXCHANGE_FV"]).Trim()
                                                         : string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_FV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_FV"] + "'"))[0]["LabelName"]);

                                dt_ValuationParameter.Rows[1]["Present Grant Parameters"] = string.IsNullOrEmpty(s_StockExchange) ? string.Empty : (s_StockExchange + ", ") + (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MARKET_PRICE_LABEL_ID_FV"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_MARKET_PRICE_LABEL_ID_FV"] + "'"))[0]["LabelName"]));
                            }
                        }
                        #endregion

                        #region Expected Life
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table4"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table4"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Method for Calculating Expected Life [Might be in Years/Months/Days]
                                if (dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"].ToString().Trim() == "lblMCEL02" || dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"].ToString().Trim() == "lblMCEL03")
                                {

                                    switch (dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_PERIOD_IN"].ToString().Trim())
                                    {
                                        case "Y":
                                            dt_ValuationParameter.Rows[2]["Company Level"] = (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Year(s)";
                                            break;

                                        case "M":
                                            dt_ValuationParameter.Rows[2]["Company Level"] = (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Month(s)";
                                            break;

                                        case "D":
                                            dt_ValuationParameter.Rows[2]["Company Level"] = (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Day(s)";
                                            break;
                                    }

                                }
                                else
                                {
                                    dt_ValuationParameter.Rows[2]["Company Level"] = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]);
                                }
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table5"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table5"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Method for Calculating Expected Life [Might be in Years/Months/Days]
                                if (dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"].ToString().Trim() == "lblMCEL02" || dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"].ToString().Trim() == "lblMCEL03")
                                {

                                    switch (dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_PERIOD_IN"].ToString().Trim())
                                    {
                                        case "Y":
                                            dt_ValuationParameter.Rows[2]["Present Grant Parameters"] = (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Year(s)";
                                            break;

                                        case "M":
                                            dt_ValuationParameter.Rows[2]["Present Grant Parameters"] = (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Month(s)";
                                            break;

                                        case "D":
                                            dt_ValuationParameter.Rows[2]["Present Grant Parameters"] = (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]) + ": " + dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Day(s)";
                                            break;
                                    }

                                }
                                else
                                {
                                    dt_ValuationParameter.Rows[2]["Present Grant Parameters"] = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"] + "'"))[0]["LabelName"]);
                                }
                            }
                        }
                        #endregion

                        #region RFIR
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table11"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table11"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                dt_ValuationParameter.Rows[3]["Company Level"] = dt_CompanyLevelParameters.Rows[0]["COMP_RFIR_COUNTRY_NAME"];
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table12"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table12"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                dt_ValuationParameter.Rows[3]["Present Grant Parameters"] = dt_GrantLevelParameters.Rows[0]["GRANT_RFIR_COUNTRY_NAME"];
                            }
                        }
                        #endregion

                        #region Volatility
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table6"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table6"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Volatility of
                                //Parameter 2: Market Price to Calculate Volatility
                                //Parameter 3: Periods to Calculate Volatility
                                string s_VolatilityOf = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_VOL_OF_LABEL_ID"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_VOL_OF_LABEL_ID"] + "'"))[0]["LabelName"]);
                                string s_MPtoCalVol = string.Empty;
                                string s_PeriodstoCalVol = string.Empty;

                                if (s_VolatilityOf.Equals("Own Company"))
                                {
                                    s_VolatilityOf = s_VolatilityOf + " Market Price: " + dt_CompanyLevelParameters.Rows[0]["SHORT_NAME"].ToString().Trim();
                                }
                                if (dt_CompanyLevelParameters.Rows[0]["COMP_TRADING_DAYS_LABEL"].ToString().Trim() == "lblTDD03")
                                {
                                    s_MPtoCalVol = ", " + dt_CompanyLevelParameters.Rows[0]["COMP_TRADING_DAYS"].ToString().Trim() + " Days";
                                }
                                else
                                {
                                    s_MPtoCalVol = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MP_CALC_VOLATILITY"])) ? string.Empty : ", " + (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_MP_CALC_VOLATILITY"] + "'"))[0]["LabelName"].ToString()
                                                    + ", " + (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_TRADING_DAYS_LABEL"] + "'"))[0]["LabelName"].ToString() + " Days";
                                }
                                if (dt_CompanyLevelParameters.Rows[0]["COMP_PRD_CALC_VOL_LABEL"].ToString().Trim() == "lblPTCV03")
                                {
                                    switch (dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_PERIOD_IN"].ToString().Trim())
                                    {
                                        case "Y":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Years";
                                            break;

                                        case "M":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Months";
                                            break;

                                        case "D":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"].ToString().Trim() + " Days";
                                            break;
                                    }
                                }
                                else
                                {
                                    s_PeriodstoCalVol = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_PRD_CALC_VOL_LABEL"])) ? string.Empty : ", Periods to Calculate Volatility: " + (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_PRD_CALC_VOL_LABEL"] + "'"))[0]["LabelName"].ToString();
                                }
                                //Assign values to DataTable
                                dt_ValuationParameter.Rows[4]["Company Level"] = s_VolatilityOf + s_MPtoCalVol + s_PeriodstoCalVol;
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table7"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table7"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Volatility of
                                //Parameter 2: Market Price to Calculate Volatility
                                //Parameter 3: Periods to Calculate Volatility
                                string s_VolatilityOf = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_VOL_OF_LABEL_ID"])) ? string.Empty : Convert.ToString((dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_VOL_OF_LABEL_ID"] + "'"))[0]["LabelName"]);
                                string s_MPtoCalVol = string.Empty;
                                string s_PeriodstoCalVol = string.Empty;

                                if (s_VolatilityOf.Equals("Own Company"))
                                {
                                    s_VolatilityOf = s_VolatilityOf + " Market Price: " + dt_GrantLevelParameters.Rows[0]["SHORT_NAME"].ToString().Trim();
                                }

                                if (dt_GrantLevelParameters.Rows[0]["GRANT_TRADING_DAYS_LABEL"].ToString().Trim() == "lblTDD03")
                                {
                                    s_MPtoCalVol = ", " + dt_GrantLevelParameters.Rows[0]["GRANT_TRADING_DAYS"].ToString().Trim() + " Days";
                                }
                                else
                                {
                                    s_MPtoCalVol = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MP_CALC_VOLATILITY"])) ? string.Empty : ", " + (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_MP_CALC_VOLATILITY"] + "'"))[0]["LabelName"].ToString() +
                                                   ", " + (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_TRADING_DAYS_LABEL"] + "'"))[0]["LabelName"].ToString() + " Days";
                                }
                                if (dt_GrantLevelParameters.Rows[0]["GRANT_PRD_CALC_VOL_LABEL"].ToString().Trim() == "lblPTCV03")
                                {
                                    switch (dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_PERIOD_IN"].ToString().Trim())
                                    {
                                        case "Y":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + (dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Years");
                                            break;

                                        case "M":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + (dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Months");
                                            break;

                                        case "D":
                                            s_PeriodstoCalVol = ", Periods to Calculate Volatility: " + (dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"].ToString().Trim() + " Days");
                                            break;
                                    }
                                }
                                else
                                {
                                    s_PeriodstoCalVol = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_PRD_CALC_VOL_LABEL"])) ? string.Empty : ", Periods to Calculate Volatility: " + (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_PRD_CALC_VOL_LABEL"] + "'"))[0]["LabelName"].ToString();
                                }
                                //Assign values to DataTable
                                dt_ValuationParameter.Rows[4]["Present Grant Parameters"] = s_VolatilityOf + s_MPtoCalVol + s_PeriodstoCalVol;
                            }
                        }
                        #endregion

                        #region Dividend
                        //Company Level parameters
                        using (DataTable dt_CompanyLevelParameters = ds.Tables["Table8"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table8"].Select("COMP_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Dividend
                                //Parameter 2: Market Price to Calculate Dividend Yield
                                string s_Dividend = string.Empty;
                                string s_MPtoCalDiviYield = string.Empty;
                                if (dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"].ToString().Trim() == "lblDIV03")
                                {
                                    s_Dividend = (string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"] + "'"))[0]["LabelName"].ToString()) + " Last " + dt_CompanyLevelParameters.Rows[0]["COMP_NO_OF_YEARS"].ToString().Trim() + " Years";
                                }
                                else
                                {
                                    s_Dividend = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"] + "'"))[0]["LabelName"].ToString();
                                }
                                s_MPtoCalDiviYield = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MP_TO_CAL_DIVIDEND"])) ? string.Empty : ", " + (dt_UIParameters.Select("LabelID = '" + dt_CompanyLevelParameters.Rows[0]["COMP_MP_TO_CAL_DIVIDEND"] + "'"))[0]["LabelName"].ToString();

                                //Assign values to DataTable
                                dt_ValuationParameter.Rows[5]["Company Level"] = s_Dividend + s_MPtoCalDiviYield;
                            }
                        }
                        //Present Grant Level parameters
                        using (DataTable dt_GrantLevelParameters = ds.Tables["Table9"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table9"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_GrantLevelParameters != null && dt_GrantLevelParameters.Rows.Count > 0)
                            {
                                //Parameter 1: Dividend
                                //Parameter 2: Market Price to Calculate Dividend Yield
                                string s_Dividend = string.Empty;
                                string s_MPtoCalDiviYield = string.Empty;
                                if (dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"].ToString().Trim() == "lblDIV03")
                                {
                                    s_Dividend = (string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"] + "'"))[0]["LabelName"].ToString()) + " Last " + dt_GrantLevelParameters.Rows[0]["GRANT_NO_OF_YEARS"].ToString().Trim() + " Years";
                                }
                                else
                                {
                                    s_Dividend = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"])) ? string.Empty : (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"] + "'"))[0]["LabelName"].ToString();
                                }
                                s_MPtoCalDiviYield = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MP_TO_CAL_DIVIDEND"])) ? string.Empty : ", " + (dt_UIParameters.Select("LabelID = '" + dt_GrantLevelParameters.Rows[0]["GRANT_MP_TO_CAL_DIVIDEND"] + "'"))[0]["LabelName"].ToString();

                                //Assign values to DataTable
                                dt_ValuationParameter.Rows[5]["Present Grant Parameters"] = s_Dividend + s_MPtoCalDiviYield;
                            }
                        }
                        #endregion

                        #region Is Manually Uploaded Data
                        using (DataTable dt_ManuallyEntered = ds.Tables["Table10"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0 ? ds.Tables["Table10"].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable() : null)
                        {
                            if (dt_ManuallyEntered != null && dt_ManuallyEntered.Rows.Count > 0)
                            {
                                if (dt_ManuallyEntered.Rows[0]["IS_MU_MKT_IV"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[0]["Is Manual Uploaded"] = "True";
                                }
                                if (dt_ManuallyEntered.Rows[0]["IS_MU_MKT_FV"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[1]["Is Manual Uploaded"] = "True";
                                }
                                if (dt_ManuallyEntered.Rows[0]["IS_MU_EXL"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[2]["Is Manual Uploaded"] = "True";
                                }
                                if (dt_ManuallyEntered.Rows[0]["IS_MU_RFIR"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[3]["Is Manual Uploaded"] = "True";
                                }
                                if (dt_ManuallyEntered.Rows[0]["IS_MU_VOL"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[4]["Is Manual Uploaded"] = "True";
                                }
                                if (dt_ManuallyEntered.Rows[0]["IS_MU_DIVD"].ToString().Equals("True"))
                                {
                                    dt_ValuationParameter.Rows[5]["Is Manual Uploaded"] = "True";
                                }
                            }
                        }
                        #endregion
                    }
                }
                return dt_ValuationParameter;
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Locking Validation and Get the Data for All Reports Main GridView
        /// <summary>
        /// This method will check whether the Valuation Report is locked or not for Grant(s) before locking Accounting Report
        /// </summary>
        /// <param name="n_hdnARACC_RPT_GRP_ID">int Report Group ID</param>
        internal void GetDataForLockedCondition(int n_hdnARACC_RPT_GRP_ID)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "VALIDATE_ACCOUNTING_REPORT";
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.OPT_GRANT_IDs = string.Empty;
                    accountingProperties.ACC_RPT_GROUP_ID = Convert.ToInt32(n_hdnARACC_RPT_GRP_ID);

                    ac_AccountingReport.ds_ValidateLockGrant = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Get the Data for All Reports Main GridView
        /// </summary>
        internal void GetAllReportsData()
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_ReportFilters;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.Type = "REPORT_DATA";
                    ac_AccountingReport.ds_ReportFilters = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;

                    if (ac_AccountingReport.ds_ReportFilters.Tables.Count > 0)
                        ac_AccountingReport.dt_MainReportDetails = ac_AccountingReport.ds_ReportFilters.Tables[0];
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~AccReportingCommonModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}