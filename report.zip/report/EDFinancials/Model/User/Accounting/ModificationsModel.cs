﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    ///Modifications Model Class.
    /// </summary>
    public class
        ModificationsModel : BaseModel, IDisposable
    {

        /// <summary>
        /// Default constructor
        /// </summary>
        public ModificationsModel()
        {
            if (ac_Modifications == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_Modifications);
                ac_Modifications = (CommonModel.AC_Modifications)HttpContext.Current.Session[CommonConstantModel.s_AC_Modifications];
            }
        }

        /// <summary>
        /// Enables or disables control according to roles assigned to user.
        /// </summary>
        /// <param name="Modifications">Modifications page</param>
        internal void CheckEmployeeRolePriviledges(Modifications Modifications)
        {
            try
            {

                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuModifications;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":

                                    break;

                                case "ADD":
                                    Modifications.btnMD_AddNew.Enabled = true;
                                    Modifications.btnMD_Calculate.Enabled = true;
                                    Modifications.btnMD_Save.Enabled = true;
                                    Modifications.btnMD_SubmitOptions.Enabled = true;
                                    Modifications.btnMD_CompensationCost.Enabled = true;
                                    Modifications.btnMD_SubmitCompensation.Enabled = true;
                                    break;

                                case "EDIT":
                                    ac_Modifications.b_IsEnabled = true;
                                    break;

                                case "DELETE":
                                    Modifications.btnMD_Delete.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method loads the initial settings and data required for the page.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        public void LoadInitialSettings(Modifications modifications)
        {
            CheckEmployeeRolePriviledges(modifications);
            BindUI(modifications);
            Get_Modification_Details(modifications);
            LoadAllSearchDropDowns(modifications);
        }

        /// <summary>
        /// This Method is used to bind UI text to the Employee master page.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        internal void BindUI(Modifications modifications)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                try
                {

                    ac_Modifications.dt_ModificationsUIText = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_Modifications, CommonConstantModel.s_AccountingL10_UI);

                    if ((ac_Modifications.dt_ModificationsUIText != null) && (ac_Modifications.dt_ModificationsUIText.Rows.Count > 0))
                    {
                        foreach (Control control in modifications.dvMain.Controls)
                        {
                            var a = (control.GetType().FullName.ToUpper());
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, modifications, ac_Modifications.dt_ModificationsUIText, (Label)control, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, modifications, ac_Modifications.dt_ModificationsUIText, null, (TextBox)control, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, modifications, ac_Modifications.dt_ModificationsUIText, null, null, (Button)control, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, modifications, ac_Modifications.dt_ModificationsUIText, null, null, null, null, (RadioButton)control, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, modifications, ac_Modifications.dt_ModificationsUIText, null, null, null, null, null, (BaseValidator)control, null, null);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, modifications, ac_Modifications.dt_ModificationsUIText, null, null, null, null, null, null, (BaseValidator)control, null);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, modifications, ac_Modifications.dt_ModificationsUIText, null, null, null, null, null, null, null, (GridView)control);
                                    break;
                            }

                        }
                        modifications.lblMD_SearchAccordHead.Text = Convert.ToString((ac_Modifications.dt_ModificationsUIText.Select("LabelID='lblMD_SearchAccordHead'"))[0]["LabelName"]);

                        modifications.lblMD_AddEditModHeading.Text = Convert.ToString((ac_Modifications.dt_ModificationsUIText.Select("LabelID='lblMD_AddEditModHeading'"))[0]["LabelName"]);

                        modifications.lblMD_AccordAddEditOptions.Text = Convert.ToString((ac_Modifications.dt_ModificationsUIText.Select("LabelID='lblMD_AccordAddEditOptions'"))[0]["LabelName"]);

                        modifications.lblMD_CompCostHeading.Text = Convert.ToString((ac_Modifications.dt_ModificationsUIText.Select("LabelID='lblMD_CompCostHeading'"))[0]["LabelName"]);

                        modifications.chkModificationOthersType.Text = Convert.ToString((ac_Modifications.dt_ModificationsUIText.Select("LabelID='chkModificationOthersType'"))[0]["LabelName"]);

                        modifications.lblVestWiseDate.Text = Convert.ToString((ac_Modifications.dt_ModificationsUIText.Select("LabelID='lblVestWiseDate'"))[0]["LabelName"]);

                        modifications.lblChangeInOptions.Text = Convert.ToString((ac_Modifications.dt_ModificationsUIText.Select("LabelID='lblChangeInOptions'"))[0]["LabelName"]);
                        modifications.trChangeInOptions.Visible = userSessionInfo.ACC_CalculationMethod == 2;

                        modifications.ddl_AddOptions_EmpVestDate.Visible = userSessionInfo.ACC_CalculationMethod > 0;
                        modifications.tr_DropdownForVestWise_Date.Visible = userSessionInfo.ACC_CalculationMethod == 2;
                        modifications.hdnCalcMethod.Value = userSessionInfo.ACC_CalculationMethod.ToString();
                    }
                }
                catch
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="Modifications">The DownloadTemplate class object</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="label">The label control object</param>
        /// <param name="textBox">The text-box control object</param>
        /// <param name="button">The button control object</param>
        /// <param name="checkBox">The CheckBox control object</param>
        /// <param name="radioButton">radiobutton control object</param>
        /// <param name="ReqValidator">validator control object</param>
        /// <param name="RegExpValidator">validator control object</param>
        /// <param name="gridView">gridview control object</param>
        private void BindPropertiesToControl(string s_cntrlType, Modifications Modifications, DataTable Dt_Get_L10N_UI, Label label, TextBox textBox, Button button, CheckBox checkBox, RadioButton radioButton, BaseValidator ReqValidator, BaseValidator RegExpValidator, GridView gridView)
        {
            switch (s_cntrlType)
            {

                case CommonConstantModel.s_cntrlTypeLabel:
                    try
                    {

                        label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                        label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                        break;
                    }
                    catch
                    {
                        throw;
                    }

                case CommonConstantModel.s_cntrlTypeButton:
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRadioButton:
                    radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                    radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    gridView.EmptyDataText = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + gridView.ID + "'"))[0]["LabelName"]);
                    break;
            }
        }

        /// <summary>
        /// This method checks whether a modification exists than the date selected in date of modification textbox.
        /// </summary>
        /// <param name="modifications">MODIFICATIONS PAGE OBJECT</param>
        /// <returns></returns>
        internal bool Is_Modifications_Exist(Modifications modifications)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "IS_MODIFICATIONS_EXIST";

                    accountingProperties.ModificationLevel = Convert.ToInt16(modifications.rbtnMD_ModificationLevel.SelectedValue);
                    accountingProperties.Date_Of_Modification = Convert.ToDateTime(modifications.txtMD_DateOfModification.Text).AddHours(23.0);
                    accountingProperties.PageName = CommonConstantModel.s_Modifications;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    using (DataTable dt_GetModStatusForDate = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result)
                    {
                        return Convert.ToBoolean(Convert.ToInt16(dt_GetModStatusForDate.Rows[0][0].ToString()));
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// THIS METHOD LOADS THE MODIFICATION TYPE RADIOLIST.
        /// </summary>
        /// <param name="modifications">Modification page object</param>
        public void Load_ModificationType(Modifications modifications)
        {
            if (string.IsNullOrEmpty(ac_Modifications.s_IsGrantModified))
            {
                accountingProperties.Is_OthersSelected = Convert.ToInt16(modifications.chkModificationOthersType.Checked);
                if (modifications.chkModificationType.Items.Count == 3)
                {
                    accountingProperties.Is_Exer_Price = Convert.ToInt16(modifications.chkModificationType.Items[0].Selected);
                    accountingProperties.Is_Exer_Period = Convert.ToInt16(modifications.chkModificationType.Items[1].Selected);
                    accountingProperties.Is_Vest_Period = Convert.ToInt16(modifications.chkModificationType.Items[2].Selected);
                }
                else
                {
                    accountingProperties.Is_Exer_Period = Convert.ToInt16(modifications.chkModificationType.Items[0].Selected);
                    accountingProperties.Is_Vest_Period = Convert.ToInt16(modifications.chkModificationType.Items[1].Selected);
                }

                modifications.chkModificationType.DataSource = ac_Modifications.dt_LoadMenuData;
                modifications.chkModificationType.DataTextField = "MODIFICATION_TYPE";
                modifications.chkModificationType.DataBind();

                if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("1"))
                {
                    modifications.chkModificationType.Items.RemoveAt(0);
                }

            }
            modifications.chkModificationOthersType.Checked = Convert.ToBoolean(accountingProperties.Is_OthersSelected);

            if (modifications.chkModificationType.Items.Count == 3)
            {
                modifications.chkModificationType.Items[0].Selected = Convert.ToBoolean(accountingProperties.Is_Exer_Price);
                modifications.chkModificationType.Items[1].Selected = Convert.ToBoolean(accountingProperties.Is_Exer_Period);
                if (modifications.chkModificationType.Items.Count == 3)
                    modifications.chkModificationType.Items[2].Selected = Convert.ToBoolean(accountingProperties.Is_Vest_Period);
            }
            else
            {
                modifications.chkModificationType.Items[0].Selected = Convert.ToBoolean(accountingProperties.Is_Exer_Period);
                modifications.chkModificationType.Items[1].Selected = Convert.ToBoolean(accountingProperties.Is_Vest_Period);
            }
        }

        /// <summary>
        /// This method is used to Populate the Modification pre data according to the parameter selected and then bind it.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        internal void Populate_Modification_Details(Modifications modifications)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    ac_Modifications.dt_Populate_Modification_details = new DataTable();
                    ac_Modifications.dt_Populate_Modification_Grantwise = new DataTable();
                    modifications.rbtnMD_ModificationLevel.Items[1].Attributes.CssStyle.Add("visibility", userSessionInfo.ACC_CalculationMethod > 0 ? "visible" : "hidden");
                    modifications.hdnIsCancelled.Value = string.Empty;
                    if (Is_Modifications_Exist(modifications))
                    {
                        ac_Modifications.dt_ModificationInput_Outputs.Clear();
                        ac_Modifications.dt_Calculated_IV_FV_details.Clear();
                        modifications.lbl_MD_DateOfModification_edit.Text = modifications.txtMD_DateOfModification.Text;

                        Load_ModificationType(modifications);
                        accountingProperties.Action = modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0") ? "GET_GRANT_LEVEL_DETAILS" : "GET_EMP_LEVEL_DETAILS";

                        if (modifications.hdnOperationType.Value == "VIEW_MODIFICATION")
                        {
                            modifications.chkModificationType.Enabled = modifications.chkModificationOthersType.Enabled = modifications.chkChangeInOptions.Enabled = modifications.txtMD_Remark.Enabled = false;
                        }

                        accountingProperties.Action = ((modifications.hdnOperationType.Value == "UPDATE_MODIFICATION" || modifications.hdnOperationType.Value == "VIEW_MODIFICATION") && modifications.rbtnMD_ModificationLevel.SelectedValue == "0") ? "GET_EXISTING_MOD_GRANT_LEVEL_DETAILS" : accountingProperties.Action;

                        accountingProperties.Date_Of_Modification = DateTime.Parse(modifications.txtMD_DateOfModification.Text).AddHours(23.0);
                        accountingProperties.PageName = CommonConstantModel.s_Modifications;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.SEN_CalculationMethod = userSessionInfo.ACC_CalculationMethod;
                        modifications.hdnCalculationMethod.Value = accountingProperties.SEN_CalculationMethod.ToString() + accountingProperties.Action;

                        ac_Modifications.dt_Populate_Modification_Grantwise = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                        if (!modifications.hdnOperationType.Value.Equals("CREATE_MODIFICATION") && (modifications.rbtnMD_ModificationLevel.SelectedValue == "0"))
                        {
                            ac_Modifications.dt_Populate_Modification_Grantwise = (ac_Modifications.dt_Populate_Modification_Grantwise.AsEnumerable()
                                .Where(b => b.Field<int?>("AMMID") == Convert.ToInt32(modifications.hdnAMMID.Value))).CopyToDataTable();
                        }
                        if ((modifications.hdnOperationType.Value == "UPDATE_MODIFICATION" || modifications.hdnOperationType.Value == "VIEW_MODIFICATION") && modifications.rbtnMD_ModificationLevel.SelectedValue == "1")
                        {
                            accountingProperties.Action = ((modifications.hdnOperationType.Value == "UPDATE_MODIFICATION" || modifications.hdnOperationType.Value == "VIEW_MODIFICATION") && modifications.rbtnMD_ModificationLevel.SelectedValue == "1") ? "GET_EMP_LEVEL_PRE_MOD_DETAILS" : string.Empty;

                            accountingProperties.Date_Of_Modification = DateTime.Parse(modifications.txtMD_DateOfModification.Text).AddHours(23.0);
                            accountingProperties.PageName = CommonConstantModel.s_Modifications;
                            accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                            accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            accountingProperties.SEN_CalculationMethod = userSessionInfo.ACC_CalculationMethod;

                            ac_Modifications.dt_Pre_Modification_Details = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                        }
                        if (modifications.hdnOperationType.Value == "UPDATE_MODIFICATION" || modifications.hdnOperationType.Value == "VIEW_MODIFICATION")
                        {
                            foreach (DataRow dr in ac_Modifications.dt_Populate_Modification_Grantwise.Rows)
                            {
                                dr["OPERATION_DATE"] = Convert.ToDateTime(dr["OPERATION_DATE"]).Date;
                            }

                            try
                            {
                                ac_Modifications.dt_Populate_Modification_Grantwise = ac_Modifications.dt_Populate_Modification_Grantwise.Select("OPERATION_DATE = '" + Convert.ToDateTime(modifications.txtMD_DateOfModification.Text).Date + "' ").CopyToDataTable();
                            }
                            catch (Exception Ex)
                            {
                                if (Ex.Message.Contains("no DataRows"))
                                {
                                    modifications.gv_AddEditModifications.DataSource = null;
                                    modifications.gv_AddEditModifications.DataBind();
                                    return;
                                }
                            }
                        }

                        if (modifications.rbtnMD_ModificationLevel.SelectedValue == "0")
                        {
                            modifications.gv_AddEditModifications.DataSource = ac_Modifications.dt_Populate_Modification_Grantwise;
                            accountingProperties.Action = "GET_GRANT_LEVEL_VESTWISE_DETAILS";
                            accountingProperties.Action = (modifications.hdnOperationType.Value == "UPDATE_MODIFICATION" || modifications.hdnOperationType.Value == "VIEW_MODIFICATION") ? "GET_EXISTING_MOD_GRANT_LEVEL_VESTWISE_DETAILS" : accountingProperties.Action;
                            ac_Modifications.dt_Populate_Modification_details = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                            if (!modifications.hdnOperationType.Value.Equals("CREATE_MODIFICATION"))
                            {
                                ac_Modifications.dt_Populate_Modification_details = (ac_Modifications.dt_Populate_Modification_details.AsEnumerable()
                                .Where(b => b.Field<int?>("AMMID") == Convert.ToInt32(modifications.hdnAMMID.Value))).CopyToDataTable();
                            }
                            modifications.rbtnMD_ModificationLevel.Items[1].Attributes.CssStyle.Add("visibility", userSessionInfo.ACC_CalculationMethod.Equals(2) ? "visible" : "hidden");
                        }
                        else
                        {
                            using (DataView dv_Dataview = new DataView(ac_Modifications.dt_Populate_Modification_Grantwise))
                            {
                                DataTable dt_EmployeeWise = new DataTable();
                                dt_EmployeeWise = dv_Dataview.ToTable(true, "AGRMID", "OPT GRANTED ID", "EMPID", "Employee Id", "Employee Name", "Grant Date", "Grant Registration ID", "Grant Option ID", "CURRENCY NAME", "EXERCISE PRICE", "Action");

                                dt_EmployeeWise.Columns.Add("Vesting Schedule", typeof(string), "");
                                SetColumnsOrder(dt_EmployeeWise, ac_Modifications.s_EmployeeVestWise_ColumnNames);


                                if (!string.IsNullOrEmpty(ac_Modifications.s_IsGrantModified))
                                {
                                    try
                                    {
                                        dt_EmployeeWise = dt_EmployeeWise.Select("[Grant Registration ID] IN (" + ac_Modifications.s_IsGrantModified.TrimEnd(',') + ")").CopyToDataTable();
                                    }
                                    catch (Exception Ex)
                                    {
                                        if (Ex.Message.Contains("no DataRows"))
                                        {
                                            modifications.gv_AddEditModifications.DataSource = null;
                                            modifications.gv_AddEditModifications.DataBind();
                                            return;
                                        }
                                        else
                                        {
                                            throw;
                                        }
                                    }
                                }



                                modifications.gv_AddEditModifications.DataSource = dt_EmployeeWise;
                                ac_Modifications.dt_Populate_Modification_details = ac_Modifications.dt_Populate_Modification_Grantwise.Copy();
                            }
                        }

                        modifications.btnMD_CompensationCost.Visible = ac_Modifications.b_IsEnabled = !modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0") && modifications.chkChangeInOptions.Checked;

                        modifications.gv_AddEditModifications.DataBind();

                        modifications.btnMD_Reset.Visible = modifications.btnMD_Save.Visible = modifications.btnMD_Calculate.Visible = modifications.gv_AddEditModifications.Rows.Count > 0 ? true : false;


                        if (modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION"))
                            DisableControls(modifications, false);
                    }
                    else
                    {
                        modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_ModExistsOnDate", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                        modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                    }
                }
                Accordian_HideShow(modifications, modifications.hdnAccordianIndex.Value);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to disable/enable the controls according to the conditions.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        /// <param name="b_Status">Is view or not</param>
        internal void DisableControls(Modifications modifications, bool b_Status)
        {

            modifications.chkModificationType.Enabled = b_Status;
            modifications.chkModificationOthersType.Enabled = b_Status;
            modifications.chkChangeInOptions.Enabled = b_Status;
            modifications.txtMD_Remark.Enabled = b_Status;

            modifications.btnMD_Calculate.Enabled = b_Status;

            modifications.btnMD_Save.Enabled = b_Status;
            modifications.btnMD_Reset.Enabled = b_Status;
            modifications.btnMD_Calculate.Enabled = b_Status;
            modifications.btnMD_SubmitOptions.Enabled = b_Status;
            modifications.btnMD_SubmitCompensation.Enabled = b_Status;

            modifications.txtMM_PreMod_OptVestCancelled.Enabled = b_Status;
            modifications.txtMM_PostMod_OptVestCancelled.Enabled = b_Status;

            modifications.txtMM_PreMod_OptUnVestCancelled.Enabled = b_Status;
            modifications.txtMM_PostMod_OptUnVestCancelled.Enabled = b_Status;

            modifications.txtMM_PreMod_OptLapsed.Enabled = b_Status;
            modifications.txtMM_PostMod_OptLapsed.Enabled = b_Status;

            modifications.txtMM_PreMod_OptExercised.Enabled = b_Status;
            modifications.txtMM_PostMod_OptExercised.Enabled = b_Status;

            modifications.txtMM_PreMod_OptUnvested.Enabled = b_Status;
            modifications.txtMM_PostMod_OptUnvested.Enabled = b_Status;

            modifications.txtMM_PostMod_OptVestedAndExercisable.Enabled = b_Status;
            modifications.txtMM_PreMod_OptVestedAndExercisable.Enabled = b_Status;
        }



        /// <summary>
        /// This method loads the content of Modification type checkbox list.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        public void ModificationType_checkbox(Modifications modifications)
        {
            if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0"))
            {
                modifications.chkModificationType.DataSource = ac_Modifications.dt_LoadMenuData;
                modifications.chkModificationType.DataTextField = "MODIFICATION_TYPE";
                modifications.chkModificationType.DataBind();
                modifications.rbtnMD_ModificationLevel.Items[1].Attributes.CssStyle.Add("visibility", userSessionInfo.ACC_CalculationMethod.Equals(2) ? "visible" : "hidden");
            }
            else if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("1"))
            {
                modifications.chkModificationType.DataSource = ac_Modifications.dt_LoadMenuData;
                modifications.chkModificationType.DataTextField = "MODIFICATION_TYPE";
                modifications.chkModificationType.DataBind();
                modifications.chkModificationType.Items.RemoveAt(0);
            }
            if (modifications.hdnIsCancelBtn.Value.Equals("1"))
            {
                modifications.chkModificationType.DataSource = ac_Modifications.dt_LoadMenuData;
                modifications.chkModificationType.DataTextField = "MODIFICATION_TYPE";
                modifications.chkModificationType.DataBind();
                modifications.btnMD_Calculate.Enabled = modifications.btnMD_Save.Enabled = modifications.btnMD_Reset.Enabled = true;

                Accordian_HideShow(modifications, modifications.hdnAccordianIndex.Value);

                ResetPopulateConditions(modifications);
                modifications.hdnAccordianIndex.Value = "0";
                modifications.hdnIsCancelBtn.Value = "";
            }

            ac_Modifications.s_IsGrantModified = string.Empty;
            accountingProperties.s_IsJointModification = string.Empty;
            modifications.btnMD_Calculate.Visible = modifications.btnMD_Save.Visible = modifications.btnMD_Reset.Visible = modifications.btnMD_CompensationCost.Visible = false;
            modifications.chkModificationType.Enabled = modifications.chkModificationOthersType.Enabled = modifications.chkChangeInOptions.Enabled = modifications.txtMD_Remark.Enabled = true;

            modifications.chkChangeInOptions.Checked = modifications.chkModificationOthersType.Checked = false;
            modifications.chkModificationType.SelectedIndex = -1;

            if (modifications.hdnOperationType.Value == "UPDATE_MODIFICATION" || modifications.hdnOperationType.Value == "VIEW_MODIFICATION")
            {
                if (modifications.hdnIsJointModication.Value.Equals("1"))
                {
                    if (modifications.hdnEMPLModiType.Value.Equals("Exercise Period"))
                        modifications.chkModificationType.Items[0].Selected = true;
                    else if (modifications.hdnEMPLModiType.Value.Equals("Vesting Period"))
                        modifications.chkModificationType.Items[1].Selected = true;
                    else
                        modifications.chkModificationOthersType.Checked = true;
                    modifications.chkChangeInOptions.Checked = true;
                }
                else
                {
                    if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("1"))
                    {
                        modifications.chkModificationType.Items[0].Selected = Convert.ToBoolean(accountingProperties.Is_Exer_Period);
                        modifications.chkModificationType.Items[1].Selected = Convert.ToBoolean(accountingProperties.Is_Vest_Period);
                    }
                    else
                    {
                        modifications.chkModificationType.Items[0].Selected = Convert.ToBoolean(accountingProperties.Is_Exer_Price);
                        modifications.chkModificationType.Items[1].Selected = Convert.ToBoolean(accountingProperties.Is_Exer_Period);
                        modifications.chkModificationType.Items[2].Selected = Convert.ToBoolean(accountingProperties.Is_Vest_Period);
                    }

                    modifications.chkModificationOthersType.Checked = Convert.ToBoolean(accountingProperties.Is_OthersSelected);
                    modifications.chkChangeInOptions.Checked = Convert.ToBoolean(accountingProperties.ChangeInOptions);

                }
                if (modifications.hdnOperationType.Value == "VIEW_MODIFICATION")
                    modifications.chkModificationType.Enabled = modifications.chkModificationOthersType.Enabled = modifications.chkChangeInOptions.Enabled = modifications.txtMD_Remark.Enabled = false;
            }

            Accordian_HideShow(modifications, modifications.hdnAccordianIndex.Value);
        }

        /// <summary>
        /// This method populates the option details of employee according to the calculation method.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        public void Populate_OptionDetails(Modifications modifications)
        {
            DisableControls(modifications, true);
            if (userSessionInfo.ACC_CalculationMethod.Equals(1))
            {
                Populate_OptionDetails_Grantwise(modifications);
            }
            else
            {
                Populate_OptionDetails_Vestwise(modifications);
            }
            Accordian_HideShow(modifications, modifications.hdnAccordianIndex.Value);
        }

        /// <summary>
        /// This method populates the option details of employee according to the grantwise method.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        internal void Populate_OptionDetails_Grantwise(Modifications modifications)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CalculationMethod = userSessionInfo.ACC_CalculationMethod;
                    accountingProperties.Action = "GET_EMP_LEVEL_DETAILS_GRANTWISE";

                    using (DataTable dt_GetOPtionsDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result)
                    {



                        modifications.lblMD_EmployeeIdVal.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Employee ID"].ToString();

                        modifications.lblMD_EmployeeNameVal.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Employee Name"].ToString();
                        var CharCount = modifications.lblMD_EmployeeNameVal.Text.Split('&').Count();

                        for (var i = 0; i < CharCount; i++)
                        {
                            modifications.lblMD_EmployeeNameVal.Text = modifications.lblMD_EmployeeNameVal.Text.Replace("&#39;", "'");
                        }
                        modifications.lblMD_SchemeNameVal.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Scheme Name"].ToString();

                        modifications.lblMD_GrantRegIdVal.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Grant Registration ID"].ToString();

                        modifications.lblMD_GrantOptIdVal.Text = modifications.hdnGntOptID_AddOpt.Value;

                        modifications.lblMD_GrantDateVal.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Grant Date"].ToString();


                        modifications.lblMM_OptGranted_Value.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Granted"].ToString();

                        modifications.lblMM_OptVestCancelled_Value.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Vested Cancelled"].ToString();

                        modifications.lblMM_OptUnVestCancelled_Value.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Unvested Cancelled"].ToString();

                        modifications.lblMM_OptLapsed_Value.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Lapsed"].ToString();

                        modifications.lblMM_OptExercised_Value.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Exercised"].ToString();

                        modifications.lblMM_OptUnvested_Value.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Unvested"].ToString();

                        modifications.lblMM_OptVestedAndExercisable_Value.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Vested and Exercisable"].ToString();

                        modifications.lblMD_OutstandingOptions_Value.Text = dt_GetOPtionsDetails.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Outstanding"].ToString();
                    }

                    modifications.hdnAccordianIndex.Value = "2";
                    modifications.hdnControlID.Value = "";
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method populates the option details of employee according to the vestwise method.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        internal void Populate_OptionDetails_Vestwise(Modifications modifications)
        {
            try
            {
                modifications.ddl_AddOptions_EmpVestDate.DataSource = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'").CopyToDataTable();
                modifications.ddl_AddOptions_EmpVestDate.DataTextField = "Vesting Date";
                modifications.ddl_AddOptions_EmpVestDate.DataValueField = "OPT_VEST_ID";
                modifications.ddl_AddOptions_EmpVestDate.DataBind();

                modifications.lblMD_EmployeeIdVal.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Employee ID"].ToString();

                modifications.lblMD_EmployeeNameVal.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Employee Name"].ToString();
                var CharCount = modifications.lblMD_EmployeeNameVal.Text.Split('&').Count();

                for (var i = 0; i < CharCount; i++)
                {
                    modifications.lblMD_EmployeeNameVal.Text = modifications.lblMD_EmployeeNameVal.Text.Replace("&#39;", "'");
                }
                modifications.lblMD_SchemeNameVal.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Scheme Name"].ToString();

                modifications.lblMD_GrantRegIdVal.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Grant Registration ID"].ToString();

                modifications.lblMD_GrantOptIdVal.Text = modifications.hdnGntOptID_AddOpt.Value;

                modifications.lblMD_GrantDateVal.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Grant Date"].ToString();

                modifications.lblMD_OptionsLastUpdatedDate.Text = Convert.ToDateTime(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["OPERATION_DATE"]).ToString("dd/MMM/yyyy");

                modifications.lblPreModificationsToDate.Text = Convert.ToDateTime(modifications.txtMD_DateOfModification.Text).ToString("dd/MMM/yyyy");

                modifications.lblMD_PostModDate.Text = Convert.ToDateTime(modifications.txtMD_DateOfModification.Text).ToString("dd/MMM/yyyy");
                GetOptionsForParticularVest(modifications, modifications.ddl_AddOptions_EmpVestDate.SelectedValue);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method gets details of particular vest id.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        /// <param name="s_VestId">Vest id</param>
        internal void GetOptionsForParticularVest(Modifications modifications, string s_VestId)
        {
            modifications.lblMM_OptGranted_Value.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Granted"].ToString();

            modifications.lblMM_OptVestCancelled_Value.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Vested Cancelled"].ToString();

            modifications.lblMM_OptUnVestCancelled_Value.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Unvested Cancelled"].ToString();

            modifications.lblMM_OptLapsed_Value.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Lapsed"].ToString();

            modifications.lblMM_OptExercised_Value.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Exercised"].ToString();

            modifications.lblMM_OptUnvested_Value.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Unvested"].ToString();

            modifications.lblMM_OptVestedAndExercisable_Value.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Vested and Exercisable"].ToString();

            modifications.lblMD_OutstandingOptions_Value.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Outstanding"].ToString();

            modifications.lblMM_TotalOptionsPostMod.Text = Convert.ToString(Convert.ToInt64(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Vested Cancelled"]) + Convert.ToInt64(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Unvested Cancelled"])
                + Convert.ToInt64(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Lapsed"])
                + Convert.ToInt64(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Exercised"])
                + Convert.ToInt64(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Unvested"])
                + Convert.ToInt64(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Vested and Exercisable"]));

            modifications.txtMM_PostMod_OptVestCancelled.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Vested Cancelled"].ToString();

            modifications.txtMM_PostMod_OptUnVestCancelled.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Unvested Cancelled"].ToString();

            modifications.txtMM_PostMod_OptLapsed.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Lapsed"].ToString();

            modifications.txtMM_PostMod_OptExercised.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Exercised"].ToString();

            modifications.txtMM_PostMod_OptUnvested.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Unvested"].ToString();

            modifications.txtMM_PostMod_OptVestedAndExercisable.Text = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Vested and Exercisable"].ToString();

            modifications.lblMD_PostModOutstandingOptCal.Text = Convert.ToString(Convert.ToInt64(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Unvested"]) + Convert.ToInt64(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["Vested and Exercisable"]));

            if (ac_Modifications.dt_Pre_Modification_Details != null && ac_Modifications.dt_Pre_Modification_Details.Rows.Count > 0 && ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'").Count() > 0)
            {
                modifications.lblMM_TotalOptionsPreMod.Text = Convert.ToString(Convert.ToInt64(ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["VESTED_CANCELLED_OPTIONS"]) + Convert.ToInt64(ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["UNVESTED_CANCELLED_OPTIONS"])
                    + Convert.ToInt64(ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["LAPSED_OPTIONS"])
                    + Convert.ToInt64(ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["EXERCISED_OPTIONS"])
                    + Convert.ToInt64(ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["UNVESTED_OPTIONS"])
                    + Convert.ToInt64(ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["VESTED_AND_EXERCISABLE"]));

                modifications.txtMM_PreMod_OptVestCancelled.Text = ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["VESTED_CANCELLED_OPTIONS"].ToString();

                modifications.txtMM_PreMod_OptUnVestCancelled.Text = ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["UNVESTED_CANCELLED_OPTIONS"].ToString();

                modifications.txtMM_PreMod_OptLapsed.Text = ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["LAPSED_OPTIONS"].ToString();

                modifications.txtMM_PreMod_OptExercised.Text = ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["EXERCISED_OPTIONS"].ToString();

                modifications.txtMM_PreMod_OptUnvested.Text = ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["UNVESTED_OPTIONS"].ToString();

                modifications.txtMM_PreMod_OptVestedAndExercisable.Text = ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["VESTED_AND_EXERCISABLE"].ToString();

                modifications.lblMD_PreModOutstandingOptCal.Text = Convert.ToString(Convert.ToInt64(ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["UNVESTED_OPTIONS"]) + Convert.ToInt64(ac_Modifications.dt_Pre_Modification_Details.Select("[OPT_VEST_ID] = '" + s_VestId + "'")[0]["VESTED_AND_EXERCISABLE"]));
            }
            modifications.hdnAccordianIndex.Value = "2";
            modifications.hdnControlID.Value = "";
        }

        /// <summary>
        /// This method is used to Calculate the Options.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        internal void Calculate_Options(Modifications modifications)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (modifications.hdnControlID.Value.Equals("PreOptions"))
                    {
                        modifications.lblMM_TotalOptionsPreMod.Text = (Convert.ToInt32(modifications.txtMM_PreMod_OptVestCancelled.Text) + Convert.ToInt32(modifications.txtMM_PreMod_OptUnVestCancelled.Text) + Convert.ToInt32(modifications.txtMM_PreMod_OptLapsed.Text) + Convert.ToInt32(modifications.txtMM_PreMod_OptExercised.Text) + Convert.ToInt32(modifications.txtMM_PreMod_OptUnvested.Text) + Convert.ToInt32(modifications.txtMM_PreMod_OptVestedAndExercisable.Text)).ToString();

                        modifications.lblMD_PreModOutstandingOptCal.Text = (Convert.ToInt32(modifications.txtMM_PreMod_OptUnvested.Text) + Convert.ToInt32(modifications.txtMM_PreMod_OptVestedAndExercisable.Text)).ToString();
                    }
                    else
                    {
                        modifications.lblMM_TotalOptionsPostMod.Text = (Convert.ToInt32(modifications.txtMM_PostMod_OptVestCancelled.Text) + Convert.ToInt32(modifications.txtMM_PostMod_OptUnVestCancelled.Text) + Convert.ToInt32(modifications.txtMM_PostMod_OptLapsed.Text) + Convert.ToInt32(modifications.txtMM_PostMod_OptExercised.Text) + Convert.ToInt32(modifications.txtMM_PostMod_OptUnvested.Text) + Convert.ToInt32(modifications.txtMM_PostMod_OptVestedAndExercisable.Text)).ToString();

                        modifications.lblMD_PostModOutstandingOptCal.Text = (Convert.ToInt32(modifications.txtMM_PostMod_OptUnvested.Text) + Convert.ToInt32(modifications.txtMM_PostMod_OptVestedAndExercisable.Text)).ToString();
                    }

                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method loads the The list of Modifications in the main gridview gv.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        internal void Get_Modification_Details(Modifications modifications)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "GET_MODIFICATIONS_DETAILS";
                    accountingProperties.Date_Of_Modification = Convert.ToDateTime("01/01/1900");
                    accountingProperties.PageName = CommonConstantModel.s_Modifications;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    ac_Modifications.dt_Get_Modification_details = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;

                    modifications.gv.DataSource = ac_Modifications.dt_Get_Modification_details;
                    modifications.gv.DataBind();
                    modifications.btnMD_Delete.Visible = modifications.gv.Rows.Count > 0 ? true : false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method creates the dynamic textboxes for the gridview and shows the data in edited format for modification and further calculations.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        /// <param name="GvRow">Gridview row to be altereds</param>
        /// <param name="i">row number of gridview</param>
        /// <param name="n_AGRMID">value of the parameter</param>
        /// <param name="s_ParaName">parameter name to be compared</param>
        /// <param name="n_GrantRegId">Grant Registration id</param>
        internal void AddControlsGridView(Modifications modifications, GridViewRow GvRow, int i, int n_AGRMID, string s_ParaName, int n_GrantRegId)
        {
            DataTable dt_Filter_InputOtput_OnAGRMID = new DataTable();
            DataTable dt_FilterCalculated_IV_FV_details_OnAGRMID = new DataTable();
            string s_VestId = modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0") ? GvRow.Cells[5].Text : GvRow.Cells[7].Text;
            if (ac_Modifications.dt_ModificationInput_Outputs.Rows.Count > 0)
            {
                try
                {
                    dt_Filter_InputOtput_OnAGRMID = ac_Modifications.dt_ModificationInput_Outputs.Select("" + s_ParaName + " = '" + GvRow.Cells[n_AGRMID].Text + "'").CopyToDataTable();
                    dt_FilterCalculated_IV_FV_details_OnAGRMID = ac_Modifications.b_Valdation_Status == true ? ac_Modifications.dt_Calculated_IV_FV_details.Select("GRANT_REGISTRATION_ID = '" + GvRow.Cells[n_GrantRegId].Text + "'").CopyToDataTable() : null;
                }
                catch (Exception)
                {
                    // Do Nothing.
                }
            }

            if (accountingProperties.Is_Exer_Period > 0)
            {
                TextBox txtExercisePeriod = new TextBox();
                txtExercisePeriod.ID = "txtExercisePeriod" + "|" + GvRow.Cells[modifications.n_AGRMID].Text + "AGRMID" + "|" + GvRow.Cells[n_GrantRegId].Text + "|" + GvRow.Cells[ac_Modifications.n_VestPeriodIndex].Text + "|" + s_VestId;
                txtExercisePeriod.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                txtExercisePeriod.CssClass = "cTextBox datepickerControl";
                txtExercisePeriod.EnableViewState = true;
                txtExercisePeriod.Text = dt_Filter_InputOtput_OnAGRMID.Rows.Count > 0 ? dt_Filter_InputOtput_OnAGRMID.Rows[i]["EXERCISE_PERIOD"].ToString() : GvRow.Cells[ac_Modifications.n_ExerPeriodIndex].Text;
                GvRow.Cells[ac_Modifications.n_ExerPeriodIndex].Controls.Add(txtExercisePeriod);
            }

            if (accountingProperties.Is_Vest_Period > 0)
            {
                TextBox txtVestPeriod = new TextBox();
                txtVestPeriod.ID = "txtVestPeriod" + "|" + GvRow.Cells[modifications.n_AGRMID].Text + "AGRMID" + "|" + GvRow.Cells[n_GrantRegId].Text + "|" + GvRow.Cells[ac_Modifications.n_VestPeriodIndex].Text + "|" + s_VestId; 
                txtVestPeriod.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                txtVestPeriod.CssClass = "cTextBox datepickerControl";
                txtVestPeriod.EnableViewState = true;
                txtVestPeriod.Text = dt_Filter_InputOtput_OnAGRMID.Rows.Count > 0 ? dt_Filter_InputOtput_OnAGRMID.Rows[i]["VESTING_PERIOD"].ToString() : GvRow.Cells[ac_Modifications.n_VestPeriodIndex].Text;
                GvRow.Cells[ac_Modifications.n_VestPeriodIndex].Controls.Add(txtVestPeriod);
            }

            TextBox txtIvIncremental = new TextBox();
            txtIvIncremental.ID = "txtIvIncremental" + "|" + GvRow.Cells[modifications.n_AGRMID].Text + "AGRMID" + "|" + GvRow.Cells[n_GrantRegId].Text + "|" + GvRow.Cells[ac_Modifications.n_VestPeriodIndex].Text + "|" + s_VestId;
            txtIvIncremental.ClientIDMode = System.Web.UI.ClientIDMode.Static;
            txtIvIncremental.CssClass = "cTextBox";
            txtIvIncremental.EnableViewState = true;
            txtIvIncremental.Width = 75;
            if (modifications.hdnIsCalculatebtn.Value == "1") txtIvIncremental.Text = ac_Modifications.b_Valdation_Status == true ? (dt_Filter_InputOtput_OnAGRMID.Select("AGRMID = '" + GvRow.Cells[modifications.n_AGRMID].Text + "'")[i]["IV_INCREMENTAL"].ToString().Count() > 0) ? dt_Filter_InputOtput_OnAGRMID.Select("AGRMID = '" + GvRow.Cells[modifications.n_AGRMID].Text + "'")[i]["IV_INCREMENTAL"].ToString() : dt_FilterCalculated_IV_FV_details_OnAGRMID.Rows[i]["IV_INCREMENTAL"].ToString() : string.Empty;
            else
                txtIvIncremental.Text = (modifications.hdnOperationType.Value.Equals("UPDATE_MODIFICATION") && modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0")) ? (ac_Modifications.dt_Populate_Modification_details.Rows.Count > 0 && ac_Modifications.dt_Populate_Modification_details != null) ? ac_Modifications.dt_Populate_Modification_details.Select("AGRMID = '" + GvRow.Cells[modifications.n_AGRMID].Text + "'")[i]["IV Incremental"].ToString() : (modifications.hdnOperationType.Value.Equals("UPDATE_MODIFICATION") && modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("1")) ? (ac_Modifications.dt_Populate_Modification_Grantwise.Rows.Count > 0 && ac_Modifications.dt_Populate_Modification_Grantwise != null) ? ac_Modifications.dt_Populate_Modification_Grantwise.Rows[i]["INTRINSIC VALUE"].ToString() : string.Empty : string.Empty : string.Empty;
         
            GvRow.Cells[ac_Modifications.n_IVIncremental].Controls.Add(txtIvIncremental);

            TextBox txtFvIncremental = new TextBox();
            txtFvIncremental.ID = "txtFvIncremental" + "|" + GvRow.Cells[modifications.n_AGRMID].Text + "AGRMID" + "|" + GvRow.Cells[n_GrantRegId].Text + "|" + GvRow.Cells[ac_Modifications.n_VestPeriodIndex].Text + "|" + s_VestId;
            txtFvIncremental.ClientIDMode = System.Web.UI.ClientIDMode.Static;
            txtFvIncremental.CssClass = "cTextBox";
            txtFvIncremental.EnableViewState = true;
            txtFvIncremental.Width = 75;
            if (modifications.hdnIsCalculatebtn.Value == "1") txtFvIncremental.Text = ac_Modifications.b_Valdation_Status == true ? (dt_Filter_InputOtput_OnAGRMID.Select("AGRMID = '" + GvRow.Cells[modifications.n_AGRMID].Text + "'")[i]["FV_INCREMENTAL"].ToString().Count() > 0) ? dt_Filter_InputOtput_OnAGRMID.Select("AGRMID = '" + GvRow.Cells[modifications.n_AGRMID].Text + "'")[i]["FV_INCREMENTAL"].ToString() : dt_FilterCalculated_IV_FV_details_OnAGRMID.Rows[i]["FV_INCREMENTAL"].ToString() : string.Empty;
            else
                txtFvIncremental.Text = (modifications.hdnOperationType.Value.Equals("UPDATE_MODIFICATION") && modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0")) ? (ac_Modifications.dt_Populate_Modification_details.Rows.Count > 0 && ac_Modifications.dt_Populate_Modification_details != null) ? ac_Modifications.dt_Populate_Modification_details.Select("AGRMID = '" + GvRow.Cells[modifications.n_AGRMID].Text + "'")[i]["FV Incremental"].ToString() : (modifications.hdnOperationType.Value.Equals("UPDATE_MODIFICATION") && modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("1")) ? (ac_Modifications.dt_Populate_Modification_Grantwise.Rows.Count > 0 && ac_Modifications.dt_Populate_Modification_Grantwise != null) ? ac_Modifications.dt_Populate_Modification_Grantwise.Rows[i]["FAIR VALUE"].ToString() : string.Empty : string.Empty : string.Empty;
            GvRow.Cells[ac_Modifications.n_FVIncremental].Controls.Add(txtFvIncremental);

            dt_Filter_InputOtput_OnAGRMID.Dispose();
            if (ac_Modifications.b_Valdation_Status)
                dt_FilterCalculated_IV_FV_details_OnAGRMID.Dispose();
        }

        /// <summary>
        /// This method is used to get TextBox values from dynamically created GridView in order to pass on to the DataTable.
        /// </summary>
        /// <param name="nameValueCollection">collection of all controls on the page.</param>
        /// <param name="modifications">Historical Cost page object</param>
        internal void GetValuesFromTextbox(System.Collections.Specialized.NameValueCollection nameValueCollection, Modifications modifications)
        {
            try
            {
                ac_Modifications.dt_ModificationInput_Outputs = new DataTable();
                ac_Modifications.b_IsFirst_Entry = true;
                int i_count = 0;

                CreateInputTable(ac_Modifications.dt_ModificationInput_Outputs);
                foreach (DataRow sourcerow in ac_Modifications.dt_Populate_Modification_details.Rows)
                {
                    DataRow dr = ac_Modifications.dt_ModificationInput_Outputs.NewRow();
                    ac_Modifications.dt_ModificationInput_Outputs.Rows.Add(dr);
                    ac_Modifications.dt_ModificationInput_Outputs.Rows[i_count]["AGRMID"] = sourcerow["AGRMID"];
                    ac_Modifications.dt_ModificationInput_Outputs.Rows[i_count]["AGDID"] = sourcerow["AGDID"];
                    ac_Modifications.dt_ModificationInput_Outputs.Rows[i_count]["CREATED_BY"] = userSessionInfo.ACC_UserID;
                    ac_Modifications.dt_ModificationInput_Outputs.Rows[i_count]["Vesting Period Number"] = sourcerow["Vesting Period Number"];
                    if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("1"))
                    {
                        ac_Modifications.dt_ModificationInput_Outputs.Rows[i_count]["OPT_GRANTED_ID"] = sourcerow["OPT GRANTED ID"];
                        ac_Modifications.dt_ModificationInput_Outputs.Rows[i_count]["OPT_VEST_ID"] = sourcerow["OPT_VEST_ID"];
                    }
                    i_count = i_count + 1;
                }

                if (accountingProperties.Is_Exer_Period > 0)
                {

                    GetData_ForEach_InputCol(ac_Modifications.dt_ModificationInput_Outputs, nameValueCollection, "txtExercisePeriod", "EXERCISE_PERIOD", ac_Modifications.b_IsFirst_Entry, modifications);
                }
                else
                {
                    i_count = 0;
                    foreach (DataRow sourcerow in ac_Modifications.dt_Populate_Modification_details.Rows)
                    {
                        ac_Modifications.dt_ModificationInput_Outputs.Rows[i_count]["EXERCISE_PERIOD"] = modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0") ? sourcerow["Exercise Period"] : sourcerow["Expiry Date"]; ;
                        i_count = i_count + 1;
                    }
                }
                if (accountingProperties.Is_Vest_Period > 0)
                    GetData_ForEach_InputCol(ac_Modifications.dt_ModificationInput_Outputs, nameValueCollection, "txtVestPeriod", "VESTING_PERIOD", ac_Modifications.b_IsFirst_Entry, modifications);
                else
                {
                    i_count = 0;
                    // if (ac_Modifications.dt_ModificationInput_Outputs.Rows.Count == 0)
                    foreach (DataRow sourcerow in ac_Modifications.dt_Populate_Modification_details.Rows)
                    {
                        ac_Modifications.dt_ModificationInput_Outputs.Rows[i_count]["VESTING_PERIOD"] = modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0") ? sourcerow["Vesting Period"] : sourcerow["Vesting Date"];
                        i_count = i_count + 1;
                    }
                }
                GetData_ForEach_InputCol(ac_Modifications.dt_ModificationInput_Outputs, nameValueCollection, "txtIvIncremental", "IV_INCREMENTAL", ac_Modifications.b_IsFirst_Entry, modifications);
                GetData_ForEach_InputCol(ac_Modifications.dt_ModificationInput_Outputs, nameValueCollection, "txtFvIncremental", "FV_INCREMENTAL", ac_Modifications.b_IsFirst_Entry, modifications);

                DataTable dt_Reverseclone = ac_Modifications.dt_ModificationInput_Outputs.Copy();
                dt_Reverseclone.Clear();
                for (int i = ac_Modifications.dt_ModificationInput_Outputs.Rows.Count - 1; i >= 0; i--)
                {
                    DataRow dr = dt_Reverseclone.NewRow();
                    dr.ItemArray = ac_Modifications.dt_ModificationInput_Outputs.Rows[i].ItemArray;
                    dt_Reverseclone.Rows.Add(dr);
                }
                ac_Modifications.dt_ModificationInput_Outputs = dt_Reverseclone;

                i_count = ac_Modifications.dt_Populate_Modification_details.Rows.Count - 1;


                foreach (DataRow sourcerow in ac_Modifications.dt_Populate_Modification_details.Rows)
                {
                    if (accountingProperties.Is_Exer_Price == 0 || (!modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0")))
                            ac_Modifications.dt_ModificationInput_Outputs.Rows[i_count]["EXERCISE_PRICE"] = ac_Modifications.dt_Populate_Modification_Grantwise.Select("AGRMID = '" + sourcerow["AGRMID"] + "'")[0]["Exercise Price"].ToString();

                    i_count = i_count - 1;
                }

                if (accountingProperties.Is_Exer_Price > 0)
                    GetData_ForEach_InputCol(ac_Modifications.dt_ModificationInput_Outputs, nameValueCollection, "txtExercisePrice", "EXERCISE_PRICE", ac_Modifications.b_IsFirst_Entry, modifications);

                dt_Reverseclone = ac_Modifications.dt_ModificationInput_Outputs.Copy();
                dt_Reverseclone.Clear();

                for (int i = ac_Modifications.dt_ModificationInput_Outputs.Rows.Count - 1; i >= 0; i--)
                {
                    DataRow dr = dt_Reverseclone.NewRow();
                    dr.ItemArray = ac_Modifications.dt_ModificationInput_Outputs.Rows[i].ItemArray;
                    dt_Reverseclone.Rows.Add(dr);
                }
                ac_Modifications.dt_ModificationInput_Outputs = dt_Reverseclone;
                ac_Modifications.dt_ModificationInput_Outputs.Columns.Remove("ParamId");
                ac_Modifications.dt_ModificationInput_Outputs.Columns.Remove("H_COST_MANUALLY");

                SetColumnsOrder(ac_Modifications.dt_ModificationInput_Outputs, ac_Modifications.s_ColumnNames);
                ac_Modifications.dt_ModificationInput_Outputs.TableName = "DT";
                accountingProperties.dt_Modifications = ac_Modifications.dt_ModificationInput_Outputs.Copy();
                accountingProperties.PageName = CommonConstantModel.s_Modifications;
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;
                modifications.rbtnMD_ModificationLevel.Items[1].Attributes.CssStyle.Add("visibility", userSessionInfo.ACC_CalculationMethod.Equals(2) ? "visible" : "hidden");
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This is the common code that gets the data from the dynamic control.
        /// </summary>
        /// <param name="Temp_Datatable">destination datatable</param>
        /// <param name="nameValueCollection">collection of controls on page</param>
        /// <param name="s_ModTypeControlPrefix">Prefix of cotrol id</param>
        /// <param name="s_colName">column name in which data has to be written.</param>
        /// <param name="IsFirstCol">is this first time being altered</param>
        /// <param name="modifications">Modifications page object</param>
        internal void GetData_ForEach_InputCol(DataTable Temp_Datatable, System.Collections.Specialized.NameValueCollection nameValueCollection, string s_ModTypeControlPrefix, string s_colName, bool IsFirstCol, Modifications modifications)
        {
            int i = 0;
            int[] AGRMID = new int[ac_Modifications.dt_Populate_Modification_Grantwise.Rows.Count];
            double[] ExerPrice = new double[ac_Modifications.dt_Populate_Modification_Grantwise.Rows.Count];
            int n_AGRMID = 0, n_VESTID = 0;
            try
            {
                foreach (var item in nameValueCollection.AllKeys)
                {
                    if (Convert.ToString(item).Contains(s_ModTypeControlPrefix))
                    {
                        var SplitterArray = item.Split('$').Last().Split('|');
                        if (!(nameValueCollection[item].Equals("")))
                        {
                            if (s_ModTypeControlPrefix.Contains("txtExercisePrice"))
                            {
                                AGRMID[i] = Convert.ToInt16(SplitterArray[1]);
                                ExerPrice[i] = Convert.ToDouble(nameValueCollection[item]);
                            }
                            else
                            {
                                n_AGRMID = Convert.ToInt16(SplitterArray[1].Split('A')[0]);
                                n_VESTID = Convert.ToInt16(SplitterArray[4]);
                                foreach (DataRow perRow in Temp_Datatable.Rows)
                                {
                                    if ((Convert.ToString(perRow["AGRMID"]) == n_AGRMID.ToString()) && (Convert.ToString(perRow["Vesting Period Number"]) == n_VESTID.ToString()))
                                    {
                                        perRow[s_colName] = nameValueCollection[item];
                                    }
                                }

                            }
                            i = i + 1;

                        }
                        else
                        {
                            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                            {
                                ac_Modifications.b_Valdation_Status = false;

                                if (item.Contains("Incremental"))
                                {
                                    // Do nothing.
                                }
                                else
                                {
                                    if (modifications.chkModificationOthersType.Checked)
                                    {
                                        modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_Blankrecord", accountingProperties.PageName, CommonConstantModel.s_AccountingL10) + s_colName.Replace("_", " ") + " of " + "Grant Reg Id- " + SplitterArray[2] + " & Vest Period id- " + SplitterArray[3];
                                        modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                        modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                        throw new System.NullReferenceException(modifications.ctrSuccessErrorMessage.s_MessageText);
                                    }
                                }
                            }
                        }
                    }
                }

                if (s_ModTypeControlPrefix.Contains("txtExercisePrice"))
                {
                    for (int j = 0; j < AGRMID.Length; j++)
                    {
                        foreach (DataRow dr in Temp_Datatable.Rows)
                        {
                            if (AGRMID[j] == Convert.ToInt16(dr["AGRMID"]))
                            {
                                dr["EXERCISE_PRICE"] = ExerPrice[j];
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method gets only the modified grant set / employee set data out of the list of input data from gv_Modifications .
        /// </summary>
        /// <param name="nameValueCollection">control collection of form</param>
        /// <param name="modifications">modification page  object.</param>
        internal void GetOnlyModifiedRows(System.Collections.Specialized.NameValueCollection nameValueCollection, Modifications modifications)
        {
            if (ac_Modifications.dt_ModificationInput_Outputs.Rows.Count > 0)
            {
                string s_List = string.Empty;
                try
                {

                    if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0"))
                    {
                        accountingProperties.s_IsJointModification = string.Empty;
                        ac_Modifications.s_IsGrantModified = string.Empty;

                        if (!modifications.chkModificationOthersType.Checked)
                        {
                            // LOOKING FOR ANY CHANGE IN EXERCISE PRICE
                            using (DataView dv_Dataview = new DataView(ac_Modifications.dt_Populate_Modification_Grantwise))
                            {
                                DataTable dt_CheckModifiedPrice = dv_Dataview.ToTable(true, "AGRMID", "Grant Registration Id", "Exercise Price");

                                foreach (DataRow datarow in dt_CheckModifiedPrice.Rows)
                                {
                                    if (Convert.ToDouble(datarow["Exercise Price"]) != Convert.ToDouble(ac_Modifications.dt_ModificationInput_Outputs.Select("AGRMID = " + datarow["AGRMID"] + "")[0]["EXERCISE_PRICE"]))
                                    {
                                        s_List = s_List + datarow["AGRMID"].ToString() + ",";
                                    }
                                }
                            }

                            // LOOKING FOR ANY CHANGE IN VESTING PERIOD OR EXERCISE PERIOD.
                            using (DataView dv_Dataview = new DataView(ac_Modifications.dt_Populate_Modification_details))
                            {
                                DataTable dt_CheckModifiedPrice = dv_Dataview.ToTable(true, "AGRMID", "Grant Registration Id", "Vesting Period Number", "Vesting Period", "Exercise Period");

                                foreach (DataRow datarow in dt_CheckModifiedPrice.Rows)
                                {
                                    if (Convert.ToString(datarow["Vesting Period"]) != Convert.ToString(ac_Modifications.dt_ModificationInput_Outputs.Select("AGRMID = " + datarow["AGRMID"] + "AND [Vesting Period Number] = " + datarow["Vesting Period Number"] + "")[0]["VESTING_PERIOD"]) || Convert.ToString(datarow["Exercise Period"]) != Convert.ToString(ac_Modifications.dt_ModificationInput_Outputs.Select("AGRMID = " + datarow["AGRMID"] + " AND [Vesting Period Number] = " + datarow["Vesting Period Number"] + "")[0]["EXERCISE_PERIOD"]))
                                    {
                                        s_List = s_List + datarow["AGRMID"].ToString() + ",";
                                    }
                                }
                            }

                            ac_Modifications.dt_ModificationInput_Outputs = ac_Modifications.dt_ModificationInput_Outputs.Select("AGRMID IN (" + s_List.TrimEnd(',') + ")").CopyToDataTable();
                        }
                        else
                        {
                            using (DataView dv_Dataview = new DataView(ac_Modifications.dt_ModificationInput_Outputs))
                            {
                                DataTable dt_dtaTable = dv_Dataview.ToTable(true, "AGRMID", "IV_INCREMENTAL", "FV_INCREMENTAL");

                                foreach (DataRow datarow in dt_dtaTable.Rows)
                                {
                                    if (!(string.IsNullOrEmpty(datarow["IV_INCREMENTAL"].ToString()) && string.IsNullOrEmpty(datarow["FV_INCREMENTAL"].ToString())))
                                        if ((string.IsNullOrEmpty(datarow["IV_INCREMENTAL"].ToString()) ? 0 : Convert.ToDouble(datarow["IV_INCREMENTAL"])) > 0.0 || (string.IsNullOrEmpty(datarow["FV_INCREMENTAL"].ToString()) ? 0 : Convert.ToDouble(datarow["FV_INCREMENTAL"])) > 0.0)
                                        {
                                            s_List = s_List + datarow["AGRMID"].ToString() + ",";
                                        }
                                }
                            }

                            ac_Modifications.dt_ModificationInput_Outputs = ac_Modifications.dt_ModificationInput_Outputs.Select("AGRMID IN (" + s_List.TrimEnd(',') + ")").CopyToDataTable();
                        }

                        DataView dV_DataView = new DataView(ac_Modifications.dt_ModificationInput_Outputs);

                        using (DataTable dt_GetUnique_ID = dV_DataView.ToTable(true, "AGRMID"))
                        {
                            foreach (DataRow dr in dt_GetUnique_ID.Rows)
                            {
                                ac_Modifications.s_IsGrantModified = ac_Modifications.s_IsGrantModified + " '" + ac_Modifications.dt_Populate_Modification_Grantwise.Select("AGRMID = " + dr["AGRMID"] + "")[0]["Grant Registration ID"].ToString() + "'" + ",";
                            }
                        }

                    }
                    else
                    {
                        if (!modifications.chkModificationOthersType.Checked)
                        {
                            using (DataView dv_Dataview = new DataView(ac_Modifications.dt_Populate_Modification_details))
                            {
                                DataTable dt_CheckModifiedPrice = dv_Dataview.ToTable(true, "OPT GRANTED ID", "AGDID", "Grant Option Id", "Vesting Period Number", "Vesting Date", "Expiry Date");
                                string s_ExerPeriod, s_VestPeriod = string.Empty;
                                foreach (DataRow datarow in dt_CheckModifiedPrice.Rows)
                                {
                                    s_VestPeriod = Convert.ToString(ac_Modifications.dt_ModificationInput_Outputs.Select("[OPT_GRANTED_ID] = '" + datarow["OPT GRANTED ID"] + "' AND [Vesting Period Number] = '" + datarow["Vesting Period Number"] + "'")[0]["VESTING_PERIOD"]);

                                    s_ExerPeriod = Convert.ToString(ac_Modifications.dt_ModificationInput_Outputs.Select("[OPT_GRANTED_ID] = '" + datarow["OPT GRANTED ID"] + "' AND [Vesting Period Number] = '" + datarow["Vesting Period Number"] + "'")[0]["EXERCISE_PERIOD"]);

                                    if (Convert.ToString(datarow["Vesting Date"]) != s_VestPeriod || Convert.ToString(datarow["Expiry Date"]) != s_ExerPeriod)
                                    {
                                        s_List = s_List + datarow["OPT GRANTED ID"].ToString() + ",";
                                    }
                                }
                            }

                            ac_Modifications.dt_ModificationInput_Outputs = ac_Modifications.dt_ModificationInput_Outputs.Select("[OPT_GRANTED_ID] IN (" + s_List.TrimEnd(',') + ")").CopyToDataTable();
                        }
                        else
                        {
                            using (DataView dv_Dataview = new DataView(ac_Modifications.dt_ModificationInput_Outputs))
                            {
                                DataTable dt_dtaTable = dv_Dataview.ToTable(true, "OPT_GRANTED_ID", "AGDID", "Vesting Period Number", "IV_INCREMENTAL", "FV_INCREMENTAL");

                                foreach (DataRow datarow in dt_dtaTable.Rows)
                                {
                                    if (((string.IsNullOrEmpty(datarow["IV_INCREMENTAL"].ToString()) ? 0 : Convert.ToDouble(datarow["IV_INCREMENTAL"])) > 0.0 || (string.IsNullOrEmpty(datarow["FV_INCREMENTAL"].ToString()) ? 0 : Convert.ToDouble(datarow["FV_INCREMENTAL"])) > 0.0))
                                    {
                                        s_List = s_List + datarow["OPT_GRANTED_ID"].ToString() + ",";
                                    }
                                }
                            }

                            ac_Modifications.dt_ModificationInput_Outputs = ac_Modifications.dt_ModificationInput_Outputs.Select("[OPT_GRANTED_ID] IN (" + s_List.TrimEnd(',') + ")").CopyToDataTable();
                        }

                        accountingProperties.s_IsJointModification = string.IsNullOrEmpty(ac_Modifications.s_IsGrantModified) ? "" : "1";
                    }

                    SetColumnsOrder(ac_Modifications.dt_ModificationInput_Outputs, ac_Modifications.s_ColumnNames);
                    ac_Modifications.dt_ModificationInput_Outputs.TableName = "DT";
                    accountingProperties.dt_Modifications = ac_Modifications.dt_ModificationInput_Outputs.Copy();
                    accountingProperties.PageName = CommonConstantModel.s_Modifications;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                }
                catch (Exception Ex)
                {
                    ac_Modifications.b_Valdation_Status = false;
                    if (Ex.Message.Contains("The IN keyword must be followed by a non-empty list of expressions"))
                    {
                        using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                        {
                            modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_NothingToSave", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            throw new System.Exception(modifications.ctrSuccessErrorMessage.s_MessageText);
                        }
                    }
                    else
                    {
                        throw;
                    }
                }
            }

        }

        /// <summary>
        /// This method performs Create / update / delete / apporve / disapprove actions based on the action type provided.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        public void PerformCUD(Modifications modifications)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Id = modifications.hdn_ModId.Value.Contains(",") ? 0 : modifications.hdn_ModId.Value == "" ? 0 : Convert.ToInt32(modifications.hdn_ModId.Value);
                    accountingProperties.Ids = modifications.hdn_ModId.Value.TrimStart(',');

                    if (string.IsNullOrEmpty(accountingProperties.s_IsJointModification))
                    {
                        accountingProperties.Date_Of_Modification = Convert.ToDateTime(modifications.txtMD_DateOfModification.Text == "dd/mmm/yyyy" ? "01/01/1900" : modifications.txtMD_DateOfModification.Text);
                        accountingProperties.Date_Of_Modification = accountingProperties.Date_Of_Modification + DateTime.Now.TimeOfDay;
                    }
                    else
                    {
                        accountingProperties.Date_Of_Modification = ac_Modifications.s_ModificationDate_Combined;
                    }
                    accountingProperties.Action = modifications.hdnOperationType.Value;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;
                    accountingProperties.SEN_CalculationMethod = userSessionInfo.ACC_CalculationMethod;
                    accountingProperties.ChangeInOptions = Convert.ToInt16(modifications.chkChangeInOptions.Checked);
                    accountingProperties.ModificationLevel = Convert.ToInt16(modifications.rbtnMD_ModificationLevel.SelectedValue == "" ? "0" : modifications.rbtnMD_ModificationLevel.SelectedValue);

                    accountingProperties.ModificationType = accountingProperties.Is_Exer_Price == 1 ? "Exercise Price, " : "";
                    accountingProperties.ModificationType = accountingProperties.Is_Exer_Period == 1 ? accountingProperties.ModificationType + "Exercise Period, " : accountingProperties.ModificationType;
                    accountingProperties.ModificationType = accountingProperties.Is_Vest_Period == 1 ? accountingProperties.ModificationType + "Vesting Period" : accountingProperties.ModificationType;

                    accountingProperties.ModificationType = accountingProperties.Is_OthersSelected == 1 ? "Others" : accountingProperties.ModificationType;
                    if (modifications.hdnOperationType.Value == "DELETE_MODIFICATIONS")
                        accountingProperties.ModificationType = accountingProperties.ModificationType.TrimEnd(' ').TrimEnd(',');
                    else
                        accountingProperties.ModificationType = (accountingProperties.s_IsJointModification.Equals("1") && accountingProperties.ModificationLevel.Equals(1)) ? (!string.IsNullOrEmpty(accountingProperties.ModificationType)) ? accountingProperties.ModificationType.Replace("Exercise Price", string.Empty).TrimEnd(' ', ',').TrimStart(',', ' ') : string.Empty : accountingProperties.ModificationType.TrimEnd(' ').TrimEnd(',');

                    accountingProperties.REMARK = modifications.txtMD_Remark.Text;

                    if (ac_Modifications.dt_ModificationInput_Outputs.Rows.Count > 0)
                    {
                        accountingProperties.dt_Modifications = ac_Modifications.dt_ModificationInput_Outputs.Copy();
                    }

                    switch (accountingServiceClient.CRUDAccountingOperations(accountingProperties).a_result)
                    {
                        case 0:
                            modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_Error", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;

                        case 1:

                            modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_Added", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                            if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0") && (userSessionInfo.ACC_CalculationMethod.Equals(2)))
                            {
                                Populate_EmployeeLevelData_AfterGrantLevelSaved(modifications);
                                ModificationType_checkbox(modifications);
                                accountingProperties.s_IsJointModification = "1";
                                modifications.chkChangeInOptions.Checked = true;
                            }
                            else
                            {
                                ResetPopulateConditions(modifications);
                                modifications.hdnAccordianIndex.Value = "0";
                            }
                            break;

                        case 2:
                            modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_Updated", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                            if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0") && (userSessionInfo.ACC_CalculationMethod.Equals(2)) && (modifications.hdnIsJointModication.Value.Equals("1")))
                            {
                                modifications.clearColumnIndexes();
                                Populate_EmployeeLevelData_AfterGrantLevelSaved(modifications);
                                ModificationType_checkbox(modifications);
                                accountingProperties.s_IsJointModification = "1";
                                modifications.chkChangeInOptions.Checked = true;
                            }
                            else
                            {
                                modifications.hdnAccordianIndex.Value = "0";
                            }
                            break;

                        case 3:
                            modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_Deleted", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 4:
                            modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_OptionsAdded", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            accountingProperties.Action = modifications.hdnOperationType.Value = modifications.hdnPreviousAction.Value;
                            accountingProperties.s_IsJointModification = accountingProperties.s_IsJointModification.Equals("1") ? accountingProperties.s_IsJointModification : "0";

                            modifications.hdnAccordianIndex.Value = "1";
                            modifications.lblMM_TotalOptionsPreMod.Text = modifications.lblMM_TotalOptionsPostMod.Text = modifications.txtMM_PreMod_OptVestCancelled.Text = modifications.txtMM_PostMod_OptVestCancelled.Text = modifications.txtMM_PreMod_OptUnVestCancelled.Text = modifications.txtMM_PostMod_OptUnVestCancelled.Text = modifications.txtMM_PreMod_OptLapsed.Text = modifications.txtMM_PostMod_OptLapsed.Text = modifications.txtMM_PreMod_OptExercised.Text = modifications.txtMM_PostMod_OptExercised.Text = modifications.txtMM_PreMod_OptUnvested.Text = modifications.txtMM_PostMod_OptUnvested.Text = modifications.txtMM_PreMod_OptVestedAndExercisable.Text = modifications.txtMM_PostMod_OptVestedAndExercisable.Text = modifications.lblMD_PreModOutstandingOptCal.Text = modifications.lblMD_PostModOutstandingOptCal.Text = "0";
                            break;

                        case 5:
                            modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_CompensationCost", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            modifications.hdnAccordianIndex.Value = "0";
                            break;
                    }

                    Accordian_HideShow(modifications, modifications.hdnAccordianIndex.Value);
                    accountingProperties.ModificationType = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method validates the input data which has been saved the the datatable.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        /// <param name="PeriodType">column name that has to be validated</param>
        /// <returns>returns boolean status</returns>
        internal bool ValidateDates(Modifications modifications, string PeriodType)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    DataView view = new DataView(ac_Modifications.dt_ModificationInput_Outputs);
                    string s_filterParameter = modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0") ? "AGRMID" : "OPT_GRANTED_ID";
                    DataTable dt_GetDistinct_AGRMID_and_VestID = view.ToTable(true, s_filterParameter);

                    foreach (DataRow dr in dt_GetDistinct_AGRMID_and_VestID.Rows)
                    {
                        DataTable dtr_GetDetails_AGRMID_Wise = ac_Modifications.dt_ModificationInput_Outputs.Select("" + s_filterParameter + " = '" + dr[s_filterParameter].ToString() + "'").CopyToDataTable();

                        for (int i = 0; i < dtr_GetDetails_AGRMID_Wise.Rows.Count; i++)
                        {
                            try
                            {
                                if (PeriodType.Equals("EXERCISE_PRICE"))
                                {
                                    var n_checkPrice = Convert.ToDouble(dtr_GetDetails_AGRMID_Wise.Rows[i][PeriodType]);
                                }
                                else
                                {
                                    var date_checkNextDate = Convert.ToDateTime(dtr_GetDetails_AGRMID_Wise.Rows[i][PeriodType]);
                                }
                            }
                            catch (Exception)
                            {
                                if (PeriodType.Equals("EXERCISE_PRICE"))
                                {
                                    ac_Modifications.s_ListofInvalidInputs = ac_Modifications.s_ListofInvalidInputs + " " + PeriodType.Replace("_", " ") + " of " + "Grant Reg Id- '" + ac_Modifications.dt_Populate_Modification_details.Select("[" + s_filterParameter.Replace("_", " ") + "] = '" + dr[s_filterParameter].ToString() + "'")[0]["Grant Registration Id"] + "',";
                                    break;
                                }
                                else
                                {
                                    ac_Modifications.s_ListofInvalidInputs = ac_Modifications.s_ListofInvalidInputs + " " + PeriodType.Replace("_", " ") + " of " + "Grant Reg Id- '" + ac_Modifications.dt_Populate_Modification_details.Select("[" + s_filterParameter.Replace("_", " ") + "] = '" + dr[s_filterParameter].ToString() + "'")[0]["Grant Registration Id"] + "' & Vest id- '" + (i + 1) + "',";
                                }
                            }
                        }
                        if (ac_Modifications.s_ListofInvalidInputs.Length > 0)
                        {
                            continue;
                        }


                        if (!PeriodType.Equals("EXERCISE_PRICE"))
                            for (int i = 0; i < dtr_GetDetails_AGRMID_Wise.Rows.Count - 1; i++)
                            {
                                try
                                {
                                    if (Convert.ToDateTime(ac_Modifications.dt_Populate_Modification_details.Select("[" + s_filterParameter.Replace("_", " ") + "] = '" + dr[s_filterParameter].ToString() + "'")[0]["Grant Date"]) > Convert.ToDateTime(dtr_GetDetails_AGRMID_Wise.Rows[i][PeriodType]))
                                    {
                                        ac_Modifications.b_Valdation_Status = false;
                                        modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_PeriodDate_GrantDate_Conflict", accountingProperties.PageName, CommonConstantModel.s_AccountingL10) + PeriodType.Replace("_", " ") + " of " + "Grant Reg Id- '" + ac_Modifications.dt_Populate_Modification_details.Select("[" + s_filterParameter.Replace("_", " ") + "] = '" + dr[s_filterParameter].ToString() + "'")[0]["Grant Registration Id"] + "' & Vest id- '" + (i + 1) + "'.";
                                        modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                        modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                        return ac_Modifications.b_Valdation_Status;

                                    }

                                    if (Convert.ToDateTime(dtr_GetDetails_AGRMID_Wise.Rows[i + 1][PeriodType]) < Convert.ToDateTime(dtr_GetDetails_AGRMID_Wise.Rows[i][PeriodType]))
                                    {
                                        ac_Modifications.b_Valdation_Status = false;
                                        modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_PeriodDate_Invalid", accountingProperties.PageName, CommonConstantModel.s_AccountingL10) + PeriodType.Replace("_", " ") + " of " + "Grant Reg Id- '" + ac_Modifications.dt_Populate_Modification_details.Select("[" + s_filterParameter.Replace("_", " ") + "] = '" + dr[s_filterParameter].ToString() + "'")[0]["Grant Registration Id"] + "' & Vest id- '" + (i + 2) + "'.";
                                        modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                        modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                        return ac_Modifications.b_Valdation_Status;

                                    }
                                    else
                                    {
                                        ac_Modifications.b_Valdation_Status = true;
                                    }
                                    if (dtr_GetDetails_AGRMID_Wise.Rows.Count == i)  // checks valid date for last row.
                                    {
                                        var dtr = Convert.ToDateTime(dtr_GetDetails_AGRMID_Wise.Rows[i][dtr_GetDetails_AGRMID_Wise.Rows.Count]);
                                    }
                                }
                                catch (Exception)
                                {
                                    ac_Modifications.s_ListofInvalidInputs = ac_Modifications.s_ListofInvalidInputs + " " + PeriodType.Replace("_", " ") + " of " + "Grant Reg Id- '" + ac_Modifications.dt_Populate_Modification_details.Select("[" + s_filterParameter + "] = '" + dr[s_filterParameter].ToString() + "'")[0]["Grant Registration Id"] + "' & Vest id- '" + (i + 1) + "',";
                                }
                            }

                    }
                    if (ac_Modifications.s_ListofInvalidInputs.Length > 0)
                    {
                        ac_Modifications.b_Valdation_Status = false;
                        modifications.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMD_Invalid_Input", accountingProperties.PageName, CommonConstantModel.s_AccountingL10) + ac_Modifications.s_ListofInvalidInputs.TrimEnd(',') + ".";
                        modifications.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        modifications.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                        return ac_Modifications.b_Valdation_Status;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return ac_Modifications.b_Valdation_Status;
        }

        /// <summary>
        /// Checks whether the inputs are valid.
        /// </summary>
        /// <returns>returns boolean</returns>
        internal bool IsInput_Valid()
        {
            ac_Modifications.s_ListofInvalidInputs = string.Empty;
            return ac_Modifications.b_Valdation_Status;
        }

        /// <summary>
        /// This Method gets the calculations done from sql procedure.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        /// <param name="validation_Status">input validation status</param>
        internal void GetCalculationsOfIncrementals(Modifications modifications, bool validation_Status)
        {
            try
            {
                accountingProperties.Action = "GET_IV_FV_CALCULATIONS";
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingProperties.Date_Of_Modification = Convert.ToDateTime(modifications.txtMD_DateOfModification.Text);

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (validation_Status)
                    {
                        ac_Modifications.dt_Calculated_IV_FV_details = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                    }

                    if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0"))
                    {
                        modifications.gv_AddEditModifications.DataSource = ac_Modifications.dt_Populate_Modification_Grantwise;
                        foreach (DataRow dr in ac_Modifications.dt_ModificationInput_Outputs.Rows)
                        {
                            dr["OPTION_INTRISIC_VALUE"] = ac_Modifications.dt_Calculated_IV_FV_details.Select("[AGRMID] = '" + dr["AGRMID"] + "'")[0]["OPTION INTRINSIC VALUE"].ToString();
                            dr["OPTION_FAIR_VALUE"] = ac_Modifications.dt_Calculated_IV_FV_details.Select("[AGRMID] = '" + dr["AGRMID"] + "'")[0]["OPTION FAIR VALUE"].ToString();

                            if (!modifications.chkModificationOthersType.Checked)
                            {
                                dr["IV_INCREMENTAL"] = ac_Modifications.dt_Calculated_IV_FV_details.Select("[AGRMID] = '" + dr["AGRMID"] + "'")[0]["IV_INCREMENTAL"].ToString();
                                dr["FV_INCREMENTAL"] = ac_Modifications.dt_Calculated_IV_FV_details.Select("[AGRMID] = '" + dr["AGRMID"] + "'")[0]["FV_INCREMENTAL"].ToString();
                            }
                        }
                    }
                    else
                    {
                        foreach (DataRow dr in ac_Modifications.dt_ModificationInput_Outputs.Rows)
                        {
                            dr["OPTION_INTRISIC_VALUE"] = ac_Modifications.dt_Calculated_IV_FV_details.Select("[AGRMID] = '" + dr["AGRMID"] + "'")[0]["OPTION INTRINSIC VALUE"].ToString();
                            dr["OPTION_FAIR_VALUE"] = ac_Modifications.dt_Calculated_IV_FV_details.Select("[AGRMID] = '" + dr["AGRMID"] + "'")[0]["OPTION FAIR VALUE"].ToString();
                        }

                        using (DataView dv_Dataview = new DataView(ac_Modifications.dt_Populate_Modification_Grantwise))
                        {
                            DataTable dt_EmployeeWise = dv_Dataview.ToTable(true, "AGRMID", "OPT GRANTED ID", "EMPID", "Employee Id", "Employee Name", "Grant Date", "Grant Registration ID", "Grant Option ID", "CURRENCY NAME", "EXERCISE PRICE", "Action");

                            dt_EmployeeWise.Columns.Add("Vesting Schedule", typeof(string), "");
                            SetColumnsOrder(dt_EmployeeWise, ac_Modifications.s_EmployeeVestWise_ColumnNames);

                            if (!string.IsNullOrEmpty(ac_Modifications.s_IsGrantModified))
                            {
                                try
                                {
                                    dt_EmployeeWise = dt_EmployeeWise.Select("[Grant Registration ID] IN (" + ac_Modifications.s_IsGrantModified.TrimEnd(',') + ")").CopyToDataTable();
                                }
                                catch (Exception Ex)
                                {
                                    if (Ex.Message.Contains("no DataRows"))
                                    {
                                        modifications.gv_AddEditModifications.DataSource = null;
                                        modifications.gv_AddEditModifications.DataBind();
                                        return;
                                    }
                                    else
                                    {
                                        throw;
                                    }
                                }
                            }
                            modifications.gv_AddEditModifications.DataSource = dt_EmployeeWise;

                            accountingProperties.Action = "GET_EMP_LEVEL_DETAILS";
                        }
                    }
                    modifications.gv_AddEditModifications.DataBind();
                    modifications.hdnIsCalculatebtn.Value = "0";
                    modifications.hdnAccordianIndex.Value = "1";
                }

                Accordian_HideShow(modifications, modifications.hdnAccordianIndex.Value);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to re-order column names
        /// </summary>
        /// <param name="dataTable">orignal datatable</param>
        /// <param name="columnNames">array of column names</param>
        /// <returns>DataTable</returns>
        private DataTable SetColumnsOrder(DataTable dataTable, params String[] columnNames)
        {
            for (int columnIndex = 0; columnIndex < columnNames.Length; columnIndex++)
            {
                dataTable.Columns[columnNames[columnIndex]].SetOrdinal(columnIndex);
            }
            return dataTable;
        }

        /// <summary>
        /// This method is used to load the gridview and then bind it.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        internal void Populate_EmployeeLevelData_AfterGrantLevelSaved(Modifications modifications)
        {
            try
            {
                ac_Modifications.s_ModificationDate_Combined = accountingProperties.Date_Of_Modification;
                modifications.rbtnMD_ModificationLevel.SelectedValue = "1";
                Populate_Modification_Details(modifications);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method binds row in gridview / hides some of the columns .
        /// </summary>
        /// <param name="e">gridviewRow event</param>
        /// <param name="n_index"> index number</param>
        /// <param name="n_ID">ID</param>
        /// <param name="n_Action">Action</param>
        /// <param name="n_AMMID">n_AMMID</param>
        /// <param name="n_Delete">n_Delete</param>
        /// <param name="n_IS_JOINT_MODIFICATION">n_IS_JOINT_MODIFICATION</param>
        /// <param name="n_EMPMODITYPE">n_EMPMODITYPE</param>
        public void gv_BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Action, ref int n_AMMID, ref int n_Delete, ref int n_IS_JOINT_MODIFICATION, ref int n_EMPMODITYPE)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "AMMID":
                                perColumn.Visible = false;
                                n_AMMID = n_index;
                                break;

                            case "DELETE":
                                n_Delete = n_index;
                                e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                e.Row.Cells[n_Delete].HorizontalAlign = HorizontalAlign.Center;
                                break;

                            case "ACTION":
                                n_Action = n_index;
                                break;

                            case "IS_JOINT_MODIFICATION":
                                perColumn.Visible = false;
                                n_IS_JOINT_MODIFICATION = n_index;
                                break;

                            case "EMPLMODTYPE":
                                perColumn.Visible = false;
                                n_EMPMODITYPE = n_index;
                                break;
                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    try
                    {
                        e.Row.Cells[n_AMMID].Visible = e.Row.Cells[n_IS_JOINT_MODIFICATION].Visible = false;
                        e.Row.Cells[n_EMPMODITYPE].Visible = false;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("View Modification", true, "~/View/App_Themes/images/ViewHistory.png", "", e.Row.Cells[n_AMMID].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, e.Row.Cells[5].Text, e.Row.Cells[7].Text, "View", e.Row.Cells[n_IS_JOINT_MODIFICATION].Text, e.Row.Cells[n_EMPMODITYPE].Text));
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit Modification", true, "~/View/App_Themes/images/Edit.png", "", e.Row.Cells[n_AMMID].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, e.Row.Cells[5].Text, e.Row.Cells[7].Text, "Edit", e.Row.Cells[n_IS_JOINT_MODIFICATION].Text, e.Row.Cells[n_EMPMODITYPE].Text));
                        e.Row.Cells[n_Delete].Controls.Add(AddCheckBox(e.Row.Cells[n_AMMID].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        e.Row.Cells[n_Delete].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        break;
                    }
                    catch
                    {
                        throw;
                    }
            }
        }

        /// <summary>
        /// This Method binds row in gridview / hides some of the columns .
        /// </summary>
        /// <param name="e">gridviewRow event</param>
        /// <param name="n_Opt_Granted_Id">n_Opt_Granted_Id</param>
        /// <param name="n_index"> index number</param>
        /// <param name="n_VestingSchedule">n_VestingSchedule</param>
        /// <param name="n_Action">n_Action</param>
        /// <param name="n_EMPID">n_EMPID</param>
        /// <param name="n_EmployeeId">n_EmployeeId</param>
        /// <param name="n_EmployeeName">n_EmployeeName</param>
        /// <param name="n_SchemeName">n_SchemeName</param>
        /// <param name="n_GrantRegId">n_GrantRegId</param>
        /// <param name="n_GrantOptId">n_GrantOptId</param>
        /// <param name="n_GrantDate">n_GrantDate</param>
        /// <param name="n_Operation_ID">n_Operation_ID</param>
        /// <param name="n_Operation_Date">n_Operation_Date</param>
        /// <param name="n_IsLock">n_IsLock</param>
        /// <param name="modifications">Page object</param>
        /// <param name="n_IS_JOINT_MODIFICATION">n_IS_JOINT_MODIFICATION</param>
        /// <param name="n_AMMID">n_AMMID</param>
        public void gv_AddEditModifications_BindRows(GridViewRowEventArgs e, ref int n_Opt_Granted_Id, ref int n_index, ref int n_VestingSchedule, ref int n_Action, ref int n_EMPID, ref int n_EmployeeId, ref int n_EmployeeName, ref int n_SchemeName, ref int n_GrantRegId, ref int n_GrantOptId, ref int n_GrantDate, ref int n_Operation_ID, ref int n_Operation_Date, ref int n_IsLock, Modifications modifications, ref int n_IS_JOINT_MODIFICATION, ref int n_AMMID)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "OPT GRANTED ID":
                                perColumn.Visible = false;
                                n_Opt_Granted_Id = n_index;
                                break;

                            case "AGRMID":
                                perColumn.Visible = false;
                                ac_Modifications.n_AGRMIDIndex = n_index;
                                break;

                            case "EMPID":
                                perColumn.Visible = false;
                                n_EMPID = n_index;
                                break;

                            case "OPERATION_DATE":
                                perColumn.Visible = false;
                                n_Operation_Date = n_index;
                                break;

                            case "OPERATION_ID":
                                perColumn.Visible = false;
                                n_Operation_ID = n_index;
                                break;

                            case "IS_LOCK":
                                perColumn.Visible = false;
                                n_IsLock = n_index;
                                break;

                            case "EMPLOYEE ID":
                                n_EmployeeId = n_index;
                                break;

                            case "EMPLOYEE NAME":
                                n_EmployeeName = n_index;
                                break;

                            case "VESTING SCHEDULE":
                                n_VestingSchedule = n_index;
                                break;

                            case "SCHEME NAME":
                                n_SchemeName = n_index;
                                break;

                            case "GRANT REGISTRATION ID":
                                n_GrantRegId = n_index;
                                break;

                            case "GRANT OPTION ID":
                                n_GrantOptId = n_index;
                                break;

                            case "GRANT DATE":
                                n_GrantDate = n_index;
                                break;

                            case "EXERCISE PRICE":
                                ac_Modifications.n_ExerPriceIndex = n_index;
                                break;

                            case "IV_INCREMENTAL":
                                ac_Modifications.n_IVIncremental = n_index;
                                break;

                            case "FV_INCREMENTAL":
                                ac_Modifications.n_FVIncremental = n_index;
                                break;

                            case "IS_JOINT_MODIFICATION":
                                perColumn.Visible = false;
                                n_IS_JOINT_MODIFICATION = n_index;
                                break;

                            case "ACTION":
                                n_Action = n_index;
                                break;

                            case "AMMID":
                                perColumn.Visible = false;
                                n_AMMID = n_index;
                                break;
                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    try
                    {
                        e.Row.Cells[ac_Modifications.n_AGRMIDIndex].Visible = e.Row.Cells[n_Opt_Granted_Id].Visible = e.Row.Cells[n_Operation_ID].Visible = e.Row.Cells[n_IsLock].Visible = e.Row.Cells[n_EMPID].Visible = e.Row.Cells[n_Operation_Date].Visible = false;
                        e.Row.Cells[n_IS_JOINT_MODIFICATION].Visible = e.Row.Cells[n_AMMID].Visible = false;
                        e.Row.Cells[n_VestingSchedule].Controls.Add(AddLinkButton(e.Row.Cells[2].Text, false));

                        if (accountingProperties.Action.Contains("GET_EMP_LEVEL_DETAILS") || accountingProperties.Action.Contains("GET_EMP_LEVEL_PRE_MOD_DETAILS"))
                        {
                            e.Row.Cells[n_Action].Controls.Add(AddImageLink("Add Options", ac_Modifications.b_IsEnabled, "~/View/App_Themes/images/Add.png", e.Row.Cells[n_Opt_Granted_Id].Text, "", "", "", "", "", "", "AddOptions", "", ""));
                        }
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;

                        if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0"))
                        {
                            if (accountingProperties.Is_Exer_Price > 0 && (!modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION")) && (!accountingProperties.Action.Contains("GET_EMP_LEVEL_DETAILS")))
                            {
                                TextBox txtExercisePrice = new TextBox();
                                txtExercisePrice.ID = "txtExercisePrice" +  "|" + e.Row.Cells[0].Text + "|" + e.Row.Cells[4].Text + "|" + e.Row.Cells[6].Text;
                                txtExercisePrice.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                txtExercisePrice.CssClass = "cTextBox";
                                txtExercisePrice.EnableViewState = true;

                                try
                                {
                                    txtExercisePrice.Text = ac_Modifications.dt_ModificationInput_Outputs.Rows.Count > 0 ? ac_Modifications.dt_ModificationInput_Outputs.Select("AGRMID = '" + Convert.ToInt16(e.Row.Cells[ac_Modifications.n_AGRMIDIndex].Text) + "'")[0]["EXERCISE_PRICE"].ToString() : e.Row.Cells[ac_Modifications.n_ExerPriceIndex].Text;
                                }
                                catch (Exception Ex)
                                {
                                    if (Ex.Message.Contains("Index was outside the bounds of the array"))
                                    {
                                        // Do nothing.
                                    }
                                    else
                                    {
                                        throw;
                                    }
                                }

                                e.Row.Cells[ac_Modifications.n_ExerPriceIndex].Controls.Add(txtExercisePrice);
                            }
                        }
                        break;
                    }
                    catch
                    {
                        throw;
                    }
            }
        }

        /// <summary>
        /// This method is used to bind the datarows of gv_CompesationCost grid.
        /// </summary>
        /// <param name="e">e</param>
        /// <param name="n_Opt_Granted_Id">n_Opt_Granted_Id</param>
        /// <param name="n_index">n_index</param>
        /// <param name="n_VestingSchedule">n_VestingSchedule</param>
        /// <param name="n_EmployeeId">n_EmployeeId</param>
        /// <param name="n_EmployeeName">n_EmployeeName</param>
        /// <param name="n_Outstanding">n_Outstanding</param>
        /// <param name="n_System_IV_Cost">n_System_IV_Cost</param>
        /// <param name="n_System_FV_Cost">n_System_FV_Cost</param>
        /// <param name="Iv_Incremental">Iv_Incremental</param>
        /// <param name="Fv_Incremental">Fv_Incremental</param>
        /// <param name="n_IntrinsicValue">n_IntrinsicValue</param>
        /// <param name="n_FairValue">n_FairValue</param>
        /// <param name="n_Granted">n_Granted</param>
        /// <param name="n_IvPostModCost">n_IvPostModCost</param>
        /// <param name="n_FvPostModCost">n_FvPostModCost</param>
        /// <param name="modifications">modifications page object</param>
        public void gv_CompesationCost_BindRows(GridViewRowEventArgs e, ref int n_Opt_Granted_Id, ref int n_index, ref int n_VestingSchedule, ref int n_EmployeeId, ref int n_EmployeeName, ref int n_Outstanding, ref int n_System_IV_Cost, ref int n_System_FV_Cost, ref int Iv_Incremental, ref int Fv_Incremental, ref int n_IntrinsicValue, ref int n_FairValue, ref int n_Granted, ref int n_IvPostModCost, ref int n_FvPostModCost, Modifications modifications)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "OPT GRANTED ID":
                                perColumn.Visible = false;
                                n_Opt_Granted_Id = n_index;
                                break;

                            case "AGRMID":
                                perColumn.Visible = false;
                                ac_Modifications.n_AGRMIDIndex = n_index;
                                break;

                            case "EMPID":
                                perColumn.Visible = false;
                                ac_Modifications.n_EMPIDIndex = n_index;
                                break;

                            case "INTRINSIC VALUE":
                                perColumn.Visible = false;
                                n_IntrinsicValue = n_index;
                                break;

                            case "FAIR VALUE":
                                perColumn.Visible = false;
                                n_FairValue = n_index;
                                break;

                            case "IV POST MODIFICATION COST":
                                perColumn.Visible = !modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION");
                                n_IvPostModCost = n_index;
                                break;

                            case "FV POST MODIFICATION COST":
                                perColumn.Visible = !modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION");
                                n_FvPostModCost = n_index;
                                break;

                            case "GRANTED":
                                perColumn.Visible = false;
                                n_Granted = n_index;
                                break;

                            case "EMPLOYEE ID":
                                n_EmployeeId = n_index;
                                break;

                            case "EMPLOYEE NAME":
                                n_EmployeeName = n_index;
                                break;

                            case "VESTING SCHEDULE":
                                n_VestingSchedule = n_index;
                                break;

                            case "OUTSTANDING":
                                n_Outstanding = n_index;
                                break;

                            case "COST AS PER SYSTEM BY IV":
                                n_System_IV_Cost = n_index;
                                break;

                            case "COST AS PER SYSTEM BY FV":
                                n_System_FV_Cost = n_index;
                                break;

                            case "IV INCREMENTAL COST":
                                perColumn.Visible = !modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION");
                                Iv_Incremental = n_index;
                                break;

                            case "FV INCREMENTAL COST":
                                perColumn.Visible = !modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION");
                                Fv_Incremental = n_index;
                                break;

                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    try
                    {
                        e.Row.Cells[n_IvPostModCost].Visible = e.Row.Cells[n_FvPostModCost].Visible = e.Row.Cells[Iv_Incremental].Visible = e.Row.Cells[Fv_Incremental].Visible = !modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION");

                        e.Row.Cells[ac_Modifications.n_AGRMIDIndex].Visible = e.Row.Cells[n_Opt_Granted_Id].Visible = e.Row.Cells[ac_Modifications.n_EMPIDIndex].Visible = e.Row.Cells[n_IntrinsicValue].Visible = e.Row.Cells[n_FairValue].Visible = e.Row.Cells[n_Granted].Visible = false;

                        e.Row.Cells[n_VestingSchedule].Controls.Add(AddLinkButton(e.Row.Cells[2].Text, true));
                        e.Row.Cells[n_VestingSchedule].HorizontalAlign = HorizontalAlign.Center;

                        break;
                    }
                    catch
                    {
                        throw;
                    }
            }
        }


        #region Add Grid within Grid
        /// <summary>
        /// this method is used to add child grid
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">event arguement</param>
        /// <param name="b_IsLocked">bool lock status</param>
        /// <param name="AGRMID">this is AGRMID</param>
        /// <param name="Opt_Grnt_id"></param>
        /// <param name="n_Empid">n_Empid</param>
        /// <param name="n_VestIndex">this is  vest index number</param>
        /// <param name="n_VestID">this is  this vest id</param>
        /// <param name="n_VestDelete">this has vest id to be deleted</param>
        /// <param name="n_VestAction">vesting action to be performed</param>
        /// <param name="n_VestGrantDate">this is vest grant date</param>
        /// <param name="rowIndex">this is row index</param>
        /// <param name="modifications">modifications page object</param>
        /// <param name="s_PageName"></param>               
        public void AddChildGrid(object sender, GridViewRowEventArgs e, bool b_IsLocked, string AGRMID, string Opt_Grnt_id, string n_Empid, ref int n_VestIndex, ref int n_VestID, ref int n_VestDelete, ref int n_VestAction, ref int n_VestGrantDate, ref int rowIndex, Modifications modifications, string s_PageName)
        {
            try
            {
                GridView parentGrid = (GridView)sender;

                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                {
                    NewTotalRow.Font.Bold = true;
                    NewTotalRow.CssClass = "gridItems  gvChildGrid";
                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                    using (TableCell HeaderCell = new TableCell())
                    {
                        HeaderCell.Attributes.Add("Class", "gvChildGrid");
                        HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        HeaderCell.Height = 10;
                        HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                        HeaderCell.ColumnSpan = s_PageName.Equals("ValuationReport") ? 9 : 12;

                        using (GridView childGrid = new GridView())
                        {
                            childGrid.CssClass = "Grid";
                            childGrid.RowStyle.CssClass = "gridItems";
                            childGrid.CellPadding = 3;
                            childGrid.CellSpacing = 0;
                            childGrid.HeaderStyle.CssClass = "HeaderStyle";
                            childGrid.ID = "childGrid_" + rowIndex;
                            n_VestIndex = n_VestID = n_VestDelete = n_VestAction = n_VestGrantDate = 0;

                            if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0"))
                            {

                                if (b_IsLocked)
                                {
                                    childGrid.RowDataBound += modifications.childGridLockedRec_RowDataBound;
                                    childGrid.DataSource = new System.Data.DataView(ac_SearchGrantDetails.dt_temp_Locked_Valuation_Report).ToTable("DT", true, new string[] { "AGRMID", "AGDID", "Scheme Name", "Grant Date", "Grant Registration Id", "Vesting Period Number", "Currency", "Exercise Period", "Vesting Period" }).Copy().Select("AGRMID = '" + AGRMID + "'").CopyToDataTable();
                                    childGrid.DataBind();
                                }
                                else
                                {
                                    childGrid.RowDataBound += modifications.childGrid_RowDataBound;
                                    childGrid.DataSource = new System.Data.DataView(ac_Modifications.dt_Populate_Modification_details).ToTable("DT", true, new string[] { "AGRMID", "AGDID", "Scheme Name", "Grant Date", "Grant Registration Id", "Vesting Period Number", "Vesting Period", "Exercise Period", "IV Incremental", "FV Incremental" }).Copy().Select("AGRMID = '" + AGRMID + "' ").CopyToDataTable();
                                    childGrid.DataBind();
                                }


                                HeaderCell.Controls.Add(childGrid);
                                NewTotalRow.Cells.Add(HeaderCell);
                                parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + rowIndex, NewTotalRow);
                            }
                            else
                            {
                                childGrid.RowDataBound += modifications.childGrid_RowDataBound;

                                if (!ac_Modifications.dt_Populate_Modification_Grantwise.Columns.Contains("IV Incremental"))
                                {
                                    ac_Modifications.dt_Populate_Modification_Grantwise.Columns.Add("IV Incremental", typeof(double), "");
                                    ac_Modifications.dt_Populate_Modification_Grantwise.Columns.Add("FV Incremental", typeof(double), "");
                                }

                                childGrid.DataSource = new System.Data.DataView(ac_Modifications.dt_Populate_Modification_Grantwise).ToTable("DT", true, new string[] { "OPT_VEST_ID", "AGRMID", "OPT GRANTED ID", "AGDID", "EMPID", "Scheme Name", "Grant Registration ID", "Vesting Period Number", "Vesting Date", "Expiry Date", "IV Incremental", "FV Incremental" }).Copy().Select("[OPT GRANTED ID] = '" + Opt_Grnt_id + "' AND EMPID = '" + n_Empid + "' ").CopyToDataTable();

                                childGrid.DataBind();

                                HeaderCell.Controls.Add(childGrid);
                                NewTotalRow.Cells.Add(HeaderCell);
                                parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + rowIndex, NewTotalRow);

                            }
                            rowIndex++;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// this method is used to add child grid
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">evwent arguement</param>
        /// <param name="b_IsLocked">bool lock status</param>
        /// <param name="AGRMID">this is AGRMID </param>
        /// <param name="n_VestIndex">this is  vest index number</param>
        /// <param name="n_VestID">this is  this vest id</param>
        /// <param name="n_VestDelete">this has vest id to be deleted</param>
        /// <param name="n_VestAction">vesting action to be performed</param>
        /// <param name="n_VestGrantDate">this is vest grant date></param>
        /// <param name="rowIndex">this is row index</param>
        /// <param name="s_PageName"></param>
        /// <param name="n_Empid">n_Empid</param>
        /// <param name="modifications">modifications page object.</param>
        public void AddChildGrid_COC(object sender, GridViewRowEventArgs e, bool b_IsLocked, string AGRMID, string n_Empid, ref int n_VestIndex, ref int n_VestID, ref int n_VestDelete, ref int n_VestAction, ref int n_VestGrantDate, ref int rowIndex, Modifications modifications, string s_PageName)
        {
            try
            {
                GridView parentGrid = (GridView)sender;

                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                {
                    NewTotalRow.Font.Bold = true;
                    NewTotalRow.CssClass = "gridItems  gvChildGrid_COC";
                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                    using (TableCell HeaderCell = new TableCell())
                    {
                        HeaderCell.Attributes.Add("Class", "gvChildGrid_COC");
                        HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        HeaderCell.Height = 10;
                        HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                        HeaderCell.ColumnSpan = s_PageName.Equals("ValuationReport") ? 9 : 12;

                        using (GridView childGrid = new GridView())
                        {
                            childGrid.CssClass = "Grid";
                            childGrid.RowStyle.CssClass = "gridItems";
                            childGrid.CellPadding = 3;
                            childGrid.CellSpacing = 0;
                            childGrid.HeaderStyle.CssClass = "HeaderStyle";
                            childGrid.ID = "childGrid_" + rowIndex;
                            n_VestIndex = n_VestID = n_VestDelete = n_VestAction = n_VestGrantDate = 0;

                            childGrid.RowDataBound += modifications.CompesationCost_childGrid_RowDataBound;

                            if (!ac_Modifications.dt_Populate_Modification_details.Columns.Contains("IV Incremental"))
                            {
                                ac_Modifications.dt_Populate_Modification_details.Columns.Add("Vesting Schedule", typeof(string), "");
                                ac_Modifications.dt_Populate_Modification_details.Columns.Add("IV Incremental", typeof(double), "");
                                ac_Modifications.dt_Populate_Modification_details.Columns.Add("FV Incremental", typeof(double), "");
                            }

                            if (userSessionInfo.ACC_CalculationMethod.Equals(1))
                            {

                                childGrid.DataSource = new System.Data.DataView(ac_Modifications.dt_Populate_Modification_details).ToTable("DT", true, new string[] { "OPT GRANTED ID", "AGRMID", "EMPID", "Outstanding", "COST AS PER SYSTEM BY IV", "Iv Post Modification Cost", "Iv Incremental Cost", "IV / Options", "COST AS PER SYSTEM BY FV", "Fv Post Modification Cost", "Fv Incremental Cost", "FV / Options" }).Copy().Select("AGRMID = '" + AGRMID + "' AND EMPID = '" + n_Empid + "' ").CopyToDataTable();

                                childGrid.DataBind();

                                HeaderCell.Controls.Add(childGrid);
                                NewTotalRow.Cells.Add(HeaderCell);
                                parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + rowIndex, NewTotalRow);
                            }
                            else
                            {
                                childGrid.DataSource = new System.Data.DataView(ac_Modifications.dt_Populate_Modification_details).ToTable("DT", true, new string[] { "OPT_VEST_ID", "OPT GRANTED ID", "AGRMID", "EMPID", "Outstanding", "COST AS PER SYSTEM BY IV", "Iv Post Modification Cost", "Iv Incremental Cost", "IV / Options", "COST AS PER SYSTEM BY FV", "Fv Post Modification Cost", "Fv Incremental Cost", "FV / Options" }).Copy().Select("AGRMID = '" + AGRMID + "' AND EMPID = '" + n_Empid + "' ").CopyToDataTable();

                                childGrid.DataBind();

                                HeaderCell.Controls.Add(childGrid);
                                NewTotalRow.Cells.Add(HeaderCell);
                                parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + rowIndex, NewTotalRow);
                            }

                            rowIndex++;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// This method is used to bind the datarows of gv_CompesationCost grid.
        /// </summary>
        /// <param name="e">e</param>
        /// <param name="n_Opt_vest_Id">n_Opt_Granted_Id</param>
        /// <param name="n_Opt_Granted_Id"></param>
        /// <param name="n_index">n_index</param>
        /// <param name="n_VestingSchedule"></param>
        /// <param name="n_EmployeeId"></param>
        /// <param name="n_EmployeeName"></param>
        /// <param name="n_Outstanding"></param>
        /// <param name="n_System_IV_Cost"></param>
        /// <param name="n_System_FV_Cost"></param>
        /// <param name="Iv_Incremental"></param>
        /// <param name="Fv_Incremental"></param>
        /// <param name="n_IntrinsicValue"></param>
        /// <param name="n_FairValue"></param>
        /// <param name="n_Granted"></param>
        /// <param name="n_IvPostModCost"></param>
        /// <param name="n_FvPostModCost"></param>
        /// <param name="n_AGRMID"></param>
        /// <param name="n_EMPID"></param>
        /// <param name="modifications">modifications page object</param>        
        public void gv_CompesationCost_ChildBindRows(GridViewRowEventArgs e, ref int n_Opt_vest_Id, ref int n_Opt_Granted_Id, ref int n_index, ref int n_VestingSchedule, ref int n_EmployeeId, ref int n_EmployeeName, ref int n_Outstanding, ref int n_System_IV_Cost, ref int n_System_FV_Cost, ref int Iv_Incremental, ref int Fv_Incremental, ref int n_IntrinsicValue, ref int n_FairValue, ref int n_Granted, ref int n_IvPostModCost, ref int n_FvPostModCost, ref int n_AGRMID, ref int n_EMPID, Modifications modifications)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "OPT_VEST_ID":
                                perColumn.Visible = false;
                                n_Opt_vest_Id = n_Opt_vest_Id > 0 ? n_Opt_vest_Id : n_index;
                                break;

                            case "OPT GRANTED ID":
                                perColumn.Visible = false;
                                n_Opt_Granted_Id = n_Opt_Granted_Id > 0 ? n_Opt_Granted_Id : n_index; ;
                                break;

                            case "AGRMID":
                                perColumn.Visible = false;
                                n_AGRMID = n_AGRMID > 0 ? n_AGRMID : n_index; ;
                                break;

                            case "EMPID":
                                perColumn.Visible = false;
                                n_EMPID = n_EMPID > 0 ? n_EMPID : n_index; ;
                                break;

                            case "INTRINSIC VALUE":
                                perColumn.Visible = false;
                                n_IntrinsicValue = n_IntrinsicValue > 0 ? n_IntrinsicValue : n_index; ;
                                break;

                            case "FAIR VALUE":
                                perColumn.Visible = false;
                                n_FairValue = n_FairValue > 0 ? n_FairValue : n_index; ;
                                break;

                            case "IV POST MODIFICATION COST":
                                perColumn.Visible = !modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION");
                                n_IvPostModCost = n_IvPostModCost > 0 ? n_IvPostModCost : n_index; ;
                                break;

                            case "FV POST MODIFICATION COST":
                                perColumn.Visible = !modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION");
                                n_FvPostModCost = n_FvPostModCost > 0 ? n_FvPostModCost : n_index; ;
                                break;

                            case "GRANTED":
                                perColumn.Visible = false;
                                n_Granted = n_Granted > 0 ? n_Granted : n_index; ;
                                break;

                            case "EMPLOYEE ID":
                                n_EmployeeId = n_EmployeeId > 0 ? n_EmployeeId : n_index; ;
                                break;

                            case "EMPLOYEE NAME":
                                n_EmployeeName = n_EmployeeName > 0 ? n_EmployeeName : n_index; ;
                                break;

                            case "VESTING SCHEDULE":
                                n_VestingSchedule = n_VestingSchedule > 0 ? n_VestingSchedule : n_index; ;
                                break;

                            case "OUTSTANDING":
                                n_Outstanding = n_Outstanding > 0 ? n_Outstanding : n_index; ;
                                break;

                            case "COST AS PER SYSTEM BY IV":
                                n_System_IV_Cost = n_System_IV_Cost > 0 ? n_System_IV_Cost : n_index; ;
                                break;

                            case "COST AS PER SYSTEM BY FV":
                                n_System_FV_Cost = n_System_FV_Cost > 0 ? n_System_FV_Cost : n_index; ;
                                break;

                            case "IV INCREMENTAL COST":
                                perColumn.Visible = !modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION");
                                Iv_Incremental = Iv_Incremental > 0 ? Iv_Incremental : n_index; ;
                                break;

                            case "FV INCREMENTAL COST":
                                perColumn.Visible = !modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION");
                                Fv_Incremental = Fv_Incremental > 0 ? Fv_Incremental : n_index; ;
                                break;

                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    try
                    {
                        e.Row.Cells[n_IvPostModCost].Visible = e.Row.Cells[n_FvPostModCost].Visible = e.Row.Cells[Iv_Incremental].Visible = e.Row.Cells[Fv_Incremental].Visible = !modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION");

                        e.Row.Cells[n_AGRMID].Visible = e.Row.Cells[n_Opt_Granted_Id].Visible = e.Row.Cells[n_EMPID].Visible = e.Row.Cells[n_IntrinsicValue].Visible = e.Row.Cells[n_FairValue].Visible = e.Row.Cells[n_Granted].Visible = false;

                        if (!modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION"))
                        {
                            TextBox txtIv_Incremental = new TextBox();
                            txtIv_Incremental.ID = "txtIv_Incremental_" + e.Row.Cells[0].Text + "_" + e.Row.Cells[n_EMPID].Text + "_" + e.Row.Cells[n_EmployeeId].Text + e.Row.Cells[n_Opt_Granted_Id].Text;
                            txtIv_Incremental.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                            txtIv_Incremental.CssClass = "cTextBox";
                            txtIv_Incremental.EnableViewState = true;
                            txtIv_Incremental.Text = e.Row.Cells[Iv_Incremental].Text;
                            txtIv_Incremental.ToolTip = "Calculated value-" + txtIv_Incremental.Text;
                            e.Row.Cells[Iv_Incremental].Controls.Add(txtIv_Incremental);

                            TextBox txtFv_Incremental = new TextBox();
                            txtFv_Incremental.ID = "txtFv_Incremental_" + e.Row.Cells[0].Text + "_" + e.Row.Cells[n_EMPID].Text + "_" + e.Row.Cells[n_EmployeeId].Text + e.Row.Cells[n_Opt_Granted_Id].Text;
                            txtFv_Incremental.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                            txtFv_Incremental.CssClass = "cTextBox";
                            txtFv_Incremental.EnableViewState = true;
                            txtFv_Incremental.Text = e.Row.Cells[Fv_Incremental].Text;
                            txtFv_Incremental.ToolTip = "Calculated value-" + txtFv_Incremental.Text;
                            e.Row.Cells[Fv_Incremental].Controls.Add(txtFv_Incremental);
                        }
                        break;
                    }
                    catch
                    {
                        throw;
                    }
            }
        }


        /// <summary>
        /// Bind GridView Rows
        /// </summary>
        /// <param name="modifications">this is modifications page object</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="n_index">index</param>
        /// <param name="n_EmployeeId">n_EmployeeId</param>
        /// <param name="n_Action">Action</param>
        /// <param name="n_GrantRegId">int n_GrantRegId column id</param>
        /// <param name="n_GrantDate">n_GrantDate</param>
        /// <param name="n_Opt_Vest_Id">n_Opt_Vest_Id</param>
        /// <param name="n_FairValVest">n_FairValVest</param>
        /// <param name="n_IntrsicValVest">n_IntrsicValVest</param>
        /// <param name="n_VestOptID">n_VestOptID</param>
        /// <param name="n_SchemeName">n_VestOptID</param>
        /// <param name="n_Opt_Granted_Id">n_Opt_Granted_Id</param>
        /// <param name="n_AGRMID">n_AGRMID</param>
        /// <param name="n_AGDID">n_AGDID</param>
        /// <param name="n_EMPID">n_EMPID</param>
        public void BindChildGridViewRows(Modifications modifications, GridViewRowEventArgs e, ref int n_index, ref int n_EmployeeId, ref int n_GrantRegId, ref int n_Action, ref int n_SchemeName, ref int n_GrantDate, ref int n_FairValVest, ref int n_IntrsicValVest, ref int n_VestOptID, ref int n_Opt_Vest_Id, ref int n_Opt_Granted_Id, ref int n_AGRMID, ref int n_AGDID, ref int n_EMPID)
        {
            try
            {
                int n_ParameterVal = 0;
                string s_ParaName = string.Empty;
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "AGRMID":
                                    perColumn.Visible = false;
                                    n_AGRMID = n_index;
                                    break;

                                case "OPT_VEST_ID":
                                    perColumn.Visible = false;
                                    n_Opt_Vest_Id = n_index;
                                    break;

                                case "OPT GRANTED ID":
                                    perColumn.Visible = false;
                                    n_Opt_Granted_Id = n_index;
                                    break;

                                case "AGDID":
                                    perColumn.Visible = false;
                                    n_AGDID = n_index;
                                    break;

                                case "EMPID":
                                    perColumn.Visible = false;
                                    n_EMPID = n_index;
                                    break;

                                case "EMPLOYEE ID":
                                    n_EmployeeId = n_index;
                                    break;

                                case "EMPLOYEE NAME":
                                    n_EmployeeId = n_index;
                                    break;

                                case "SCHEME NAME":
                                    n_SchemeName = n_index;
                                    break;

                                case "GRANT REGISTRATION ID":
                                    n_GrantRegId = n_index;
                                    break;

                                case "GRANT DATE":
                                    n_GrantDate = n_index;
                                    break;

                                case "EXERCISE PERIOD":
                                    ac_Modifications.n_ExerPeriodIndex = n_index;
                                    break;

                                case "VESTING PERIOD":
                                    ac_Modifications.n_VestPeriodIndex = n_index;
                                    break;

                                case "EXPIRY DATE":
                                    ac_Modifications.n_ExerPeriodIndex = n_index;
                                    break;

                                case "VESTING DATE":
                                    ac_Modifications.n_VestPeriodIndex = n_index;
                                    break;

                                case "IV INCREMENTAL":
                                    ac_Modifications.n_IVIncremental = n_index;
                                    break;

                                case "FV INCREMENTAL":
                                    ac_Modifications.n_FVIncremental = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:

                        e.Row.Cells[n_EMPID].Visible = e.Row.Cells[n_Opt_Granted_Id].Visible = e.Row.Cells[n_AGDID].Visible = e.Row.Cells[n_Opt_Vest_Id].Visible = e.Row.Cells[n_AGRMID].Visible = false;
                        if (modifications.rbtnMD_ModificationLevel.SelectedValue.Equals("0"))
                        {
                            s_ParaName = "AGRMID";
                            n_ParameterVal = n_AGRMID;
                        }
                        else
                        {
                            s_ParaName = "OPT_GRANTED_ID";
                            n_ParameterVal = 2;
                        }
                        if (!modifications.hdnOperationType.Value.Equals("VIEW_MODIFICATION"))
                            AddControlsGridView(modifications, e.Row, e.Row.RowIndex, n_ParameterVal, s_ParaName, n_GrantRegId);
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add link button
        /// </summary>
        /// <param name="s_GRID">Grid id</param>
        /// <param name="IsCompensationCost"></param>
        /// <returns></returns>
        private LinkButton AddLinkButton(string s_GRID, bool IsCompensationCost)
        {
            try
            {
                LinkButton linkButton = new LinkButton();
                linkButton.ToolTip = "Click here to view vestwise details";
                linkButton.Text = "View Details";
                linkButton.ID = "lbtnViewDetails";
                linkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                linkButton.Style.Add("cursor", "pointer");

                if (!string.IsNullOrEmpty(s_GRID))
                {
                    linkButton.Attributes.Add("onclick", IsCompensationCost ? "return ShowCOC_Details(this)" : "return ShowDetails(this)");
                }
                return linkButton;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method Adds 'Delete all' checkbox in the Header Part.
        /// </summary>
        /// <returns>Returns Checkbox</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chkDeleteAll";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Text = string.Empty;
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }

        /// <summary>
        /// This method adds image button to gridview Action column at runtime .
        /// </summary>
        /// <param name="s_strToolTip">ToolTip for Button</param>
        /// <param name="b_IsEnabled">Enable status for image button</param>
        /// <param name="s_strUrl">Image Url</param>
        /// <param name="s_Opt_Granted_Id">s_Opt_Granted_Id</param>
        /// <param name="s_AMMID">s_AMMID</param>
        /// <param name="s_ModDate">s_ModDate</param>
        /// <param name="s_ModLevel">s_ModLevel</param>
        /// <param name="s_Modtype">s_Modtype</param>
        /// <param name="s_ModChangeInOpt">s_ModChangeInOpt</param>
        /// <param name="s_ModRemark">s_ModRemark</param>
        /// <param name="s_ControlType">s_ControlType</param>
        /// <returns>returns Imagebutton</returns>
        /// <param name="s_Is_Joint_Modification">s_Is_Joint_Modification</param>
        /// <param name="s_EMPMODITYPE">s_EMPMODITYPE</param>
        private ImageButton AddImageLink(string s_strToolTip, bool b_IsEnabled, string s_strUrl, string s_Opt_Granted_Id, string s_AMMID, string s_ModDate, string s_ModLevel, string s_Modtype, string s_ModChangeInOpt, string s_ModRemark, string s_ControlType, string s_Is_Joint_Modification, string s_EMPMODITYPE)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = b_IsEnabled == true ? s_strToolTip + " enabled" : s_strToolTip + " disabled"; ;
                imgButton.Enabled = b_IsEnabled;
                imgButton.Style.Add("cursor", "pointer");


                switch (s_ControlType.ToUpper())
                {
                    case "EDIT":
                        imgButton.Attributes.Add("onclick", "return EditModification('" + s_AMMID + "','" + s_ModDate + "','" + s_ModLevel + "','" + s_Modtype + "','" + s_ModChangeInOpt + "','" + s_ModRemark + "','" + s_Is_Joint_Modification + "','" + s_EMPMODITYPE + "')");
                        break;
                    case "VIEW":
                        imgButton.Attributes.Add("onclick", "return ViewModification('" + s_AMMID + "','" + s_ModDate + "','" + s_ModLevel + "','" + s_Modtype + "','" + s_ModChangeInOpt + "','" + s_ModRemark + "','" + s_Is_Joint_Modification + "','" + s_EMPMODITYPE + "')");
                        break;

                    case "ADDOPTIONS":
                        if (!string.IsNullOrEmpty(s_Opt_Granted_Id))
                        {
                            imgButton.Attributes.Add("onclick", "return ShowAddOptionsSection('" + s_Opt_Granted_Id + "')");
                        }
                        break;
                }
                return imgButton;
            }
        }

        /// <summary>
        /// This Method add checkboxes in the gridview first column.
        /// </summary>
        /// <param name="s_ModID">s_ModID</param>
        /// <param name="IsDeleted">IsDeleted</param>
        /// <returns>returns CheckBox</returns>
        private CheckBox AddCheckBox(string s_ModID, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_ModID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");

                if (!string.IsNullOrEmpty(s_ModID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_ModID + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// THIS METHOD GETS THE SERACH QUERY FOR FILTERING THE MODIFICATION GRID.
        /// </summary>
        /// <param name="modifications">modifications page object</param>
        /// <returns>returns string</returns>
        public string GetFilterCriteria(Modifications modifications)
        {
            string s_SearchQuery = string.Empty;
            if (modifications.hdnIsSearchInput.Value != "0")
            {
                s_SearchQuery = " WHERE ";

                if (modifications.txtMD_SearchFromDate.Text != "dd/mmm/yyyy")
                {
                    s_SearchQuery = s_SearchQuery + "MODIFICATION_DATE >= '" + modifications.txtMD_SearchFromDate.Text + "'";
                }

                if (modifications.txtMD_SearchToDate.Text != "dd/mmm/yyyy")
                {
                    s_SearchQuery = s_SearchQuery.Length > 7 ? s_SearchQuery + " AND" : s_SearchQuery; ;
                    s_SearchQuery = s_SearchQuery + " MODIFICATION_DATE <= '" + Convert.ToDateTime(modifications.txtMD_SearchToDate.Text).AddHours(23.58) + "' ";
                }

                if (modifications.ddMD_Status.SelectedIndex > (0))
                {
                    s_SearchQuery = s_SearchQuery.Length > 7 ? s_SearchQuery + " AND " : s_SearchQuery + " ";


                    s_SearchQuery = s_SearchQuery + (modifications.ddMD_Status.SelectedValue != "0" ? "[STATUS] = " + Convert.ToString(Convert.ToInt16(modifications.ddMD_Status.SelectedValue.ToString()) - 1) : " ");
                }

                if ((s_SearchQuery.Length > 7 && modifications.hdn_IsModTypeSelected.Value == "1"))
                {
                    s_SearchQuery = s_SearchQuery + " AND ";
                }

                s_SearchQuery = s_SearchQuery + "";
                bool isFirst_item = true;
                foreach (ListItem CurrentItem in modifications.UcEM_ModificationType.chkMultiselect.Items)
                {
                    if (CurrentItem.Selected)
                    {
                        s_SearchQuery = !isFirst_item ? s_SearchQuery + " OR " : s_SearchQuery + "";
                        s_SearchQuery = s_SearchQuery + "MODIFICATION_TYPE LIKE  ";
                        s_SearchQuery = s_SearchQuery + "'%" + CurrentItem.Text + "%'";
                        isFirst_item = false;
                    }
                }
                modifications.btnMD_ClearSearch.Visible = true;
            }
            else
            {
                modifications.ddMD_Status.SelectedValue = "0";
                modifications.txtMD_SearchFromDate.Text = "";
                modifications.txtMD_SearchToDate.Text = "";
                modifications.btnMD_ClearSearch.Visible = false;
                modifications.UcEM_ModificationType.chkMultiselect.SelectedIndex = -1;
            }
            s_SearchQuery = s_SearchQuery.TrimEnd(',');
            return s_SearchQuery;
        }

        /// <summary>
        /// This method is used to filter the grid data according to serarch criteria.
        /// </summary>
        /// <param name="modifications">modifications page object</param>s
        public void FilterGridData(Modifications modifications)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SearchQuery = GetFilterCriteria(modifications);
                    accountingProperties.Action = "SEARCH_MODIFICATION_MASTER";
                    accountingProperties.Date_Of_Modification = Convert.ToDateTime(modifications.txtMD_DateOfModification.Text == "dd/mmm/yyyy" ? "01/01/1900" : modifications.txtMD_DateOfModification.Text);
                    accountingProperties.PageName = CommonConstantModel.s_Modifications;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    ac_Modifications.dt_Get_Modification_details = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;

                    modifications.gv.DataSource = ac_Modifications.dt_Get_Modification_details;
                    modifications.gv.DataBind();
                    modifications.btnMD_Delete.Visible = modifications.gv.Rows.Count > 0 ? true : false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is is used to centralise the loop for used for searching the row to be filtered.
        /// </summary>
        /// <param name="dt_temp">temporary dataTable</param>
        /// <param name="dt_CopyEmployeeRow">table from which data is to be copied</param>
        /// <returns>returns DataTable</returns>
        internal DataTable processDataTable(DataTable dt_temp, DataTable dt_CopyEmployeeRow)
        {
            foreach (DataRow dr in dt_temp.Rows)
            {
                var newDataRow = dt_CopyEmployeeRow.NewRow();
                newDataRow.ItemArray = dr.ItemArray;
                dt_CopyEmployeeRow.Rows.Add(newDataRow);
            }
            return dt_CopyEmployeeRow;
        }

        /// <summary>
        /// This Method loads all the Search section dropdowns.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        internal void LoadAllSearchDropDowns(Modifications modifications)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "LOAD_SEARCH_PARAMS";
                    accountingProperties.PageName = CommonConstantModel.s_Modifications;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.Date_Of_Modification = Convert.ToDateTime("01/01/1900");
                    ac_Modifications.dt_LoadMenuData = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;

                    using (DataTable dt_LoadMenuData = ac_Modifications.dt_LoadMenuData.Copy())
                    {
                        LoadRows(dt_LoadMenuData, modifications.UcEM_ModificationType.chkMultiselect, "MODIFICATION_TYPE");
                        modifications.chkModificationType.DataSource = dt_LoadMenuData;
                        modifications.chkModificationType.DataTextField = "MODIFICATION_TYPE";
                        modifications.chkModificationType.DataBind();
                        dt_LoadMenuData.Rows.RemoveAt(2);
                        modifications.ddMD_Status.DataSource = dt_LoadMenuData;
                        modifications.ddMD_Status.DataTextField = "STATUS";
                        modifications.ddMD_Status.DataValueField = "VALUE";
                        modifications.ddMD_Status.DataBind();
                        modifications.rbtnMD_ModificationLevel.DataSource = dt_LoadMenuData;
                        modifications.rbtnMD_ModificationLevel.DataTextField = "MODIFICATION_LEVEL";
                        modifications.rbtnMD_ModificationLevel.DataValueField = "VALUE";
                        modifications.rbtnMD_ModificationLevel.DataBind();

                        if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                        {
                            modifications.rbtnMD_ModificationLevel.Items[1].Attributes.CssStyle.Add("visibility", "visible");
                        }
                        else
                        {
                            modifications.rbtnMD_ModificationLevel.Items[1].Attributes.CssStyle.Add("visibility", "hidden");
                            modifications.rbtnMD_ModificationLevel.SelectedValue = "0";
                        }
                    }

                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method resets the populated data grid and data conditions.ss
        /// </summary>
        /// <param name="modifications">modifications page object</param>
        internal void ResetPopulateConditions(Modifications modifications)
        {
            modifications.txtMD_DateOfModification.Text = string.Empty;
            modifications.chkModificationType.SelectedIndex = -1;
            modifications.chkChangeInOptions.Checked = false;
            modifications.rbtnMD_ModificationLevel.SelectedIndex = -1;
            modifications.hdnAccordianIndex.Value = "1";
            modifications.gv_AddEditModifications.DataSource = new DataTable();
            modifications.gv_AddEditModifications.DataBind();

            modifications.btnMD_Calculate.Visible = modifications.btnMD_Save.Visible = modifications.btnMD_Reset.Visible = modifications.btnMD_CompensationCost.Visible = false;
            ac_Modifications.s_IsGrantModified = string.Empty;
            accountingProperties.s_IsJointModification = string.Empty;
            accountingProperties.Is_Exer_Price = 0;
            accountingProperties.Is_Exer_Period = 0;
            accountingProperties.Is_Vest_Period = 0;

            modifications.chkModificationType.DataSource = ac_Modifications.dt_LoadMenuData;
            modifications.chkModificationType.DataTextField = "MODIFICATION_TYPE";
            modifications.chkModificationType.DataBind();
        }

        /// <summary>
        /// This method creates a datatable based on the filtered row and adds the row in the datatable.
        /// </summary>
        /// <param name="dt">datatable to be filtered</param>
        /// <param name="chkbxList">checkboxlist which is used as a reference to filter as a parameter</param>
        /// <param name="s_col_Name">column name on which filtered is to be performed</param>
        internal void LoadRows(DataTable dt, CheckBoxList chkbxList, string s_col_Name)
        {
            DataTable datatable_temp = new DataTable();
            foreach (DataRow dr in dt.Rows)
            {
                try
                {
                    string test = Convert.ToString(datatable_temp.Select("" + s_col_Name + " = '" + dr[s_col_Name].ToString() + "'")[0][s_col_Name]);
                }
                catch (Exception)
                {
                    if (!string.IsNullOrEmpty(dr[s_col_Name].ToString()))
                        chkbxList.Items.Add(dr[s_col_Name].ToString());
                    if (datatable_temp.Columns.Count == 0)
                        datatable_temp.Columns.Add(s_col_Name);
                    datatable_temp.Rows.Add(dr[s_col_Name].ToString());
                }
            }
            datatable_temp.Dispose();
        }

        /// <summary>
        /// To change pages of gridview
        /// </summary>
        /// <param name="sender">senders object</param>
        /// <param name="e">event arguement</param>
        /// <param name="gv">gridview gv</param>
        /// <param name="s_ModificationsGroupID">row id that are selected by user</param>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_ModificationsGroupID)
        {
            try
            {
                string[] s_AssignModGpID = s_ModificationsGroupID.TrimStart(',').Split(',');

                ac_Modifications.dt_Get_Modification_details.Columns["Delete"].Expression = string.Empty;
                ac_Modifications.dt_Get_Modification_details.AcceptChanges();

                foreach (string perID in s_AssignModGpID)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_Modifications.dt_Get_Modification_details.Select("AMMID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }

                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_Modifications.dt_Get_Modification_details;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to change pages of gridview.
        /// </summary>
        /// <param name="e">gridview event arguement e</param>
        /// <param name="Modifications">employee master object</param>
        internal void gv_AddEditModifications_PageIndexChanging(GridViewPageEventArgs e, Modifications Modifications)
        {
            try
            {
                Modifications.gv.PageIndex = e.NewPageIndex;
                Modifications.gv.DataSource = ac_Modifications.dt_Get_Modification_details;
                Modifications.gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method creates column into the datatable supplied.
        /// </summary>
        /// <param name="Temp_Datatable">datatable</param>
        internal void CreateInputTable(DataTable Temp_Datatable)
        {
            try
            {
                if (Temp_Datatable.Columns.Count == 0)
                {
                    Temp_Datatable.Columns.Add("PARAMID", typeof(string));
                    Temp_Datatable.Columns.Add("AGRMID", typeof(int));
                    Temp_Datatable.Columns.Add("AGDID", typeof(int));
                    Temp_Datatable.Columns.Add("EXERCISE_PRICE", typeof(string));
                    Temp_Datatable.Columns.Add("EXERCISE_PERIOD", typeof(string));
                    Temp_Datatable.Columns.Add("VESTING_PERIOD", typeof(string));
                    Temp_Datatable.Columns.Add("Vesting Period Number", typeof(int));
                    Temp_Datatable.Columns.Add("IV_INCREMENTAL", typeof(double));
                    Temp_Datatable.Columns.Add("FV_INCREMENTAL", typeof(double));
                    Temp_Datatable.Columns.Add("OPTION_INTRISIC_VALUE", typeof(double));
                    Temp_Datatable.Columns.Add("OPTION_FAIR_VALUE", typeof(double));

                    Temp_Datatable.Columns.Add("OPT_GRANTED_ID", typeof(string));
                    Temp_Datatable.Columns.Add("GRANT_OPTION_ID", typeof(string));
                    Temp_Datatable.Columns.Add("EMPID", typeof(int));
                    Temp_Datatable.Columns.Add("VPD_VESTING_PERIOD_ID", typeof(int));
                    Temp_Datatable.Columns.Add("VPD_VESTING_DATE", typeof(string));
                    Temp_Datatable.Columns.Add("GRANTED_OPTIONS", typeof(int));
                    Temp_Datatable.Columns.Add("CANCELLED_OPTIONS", typeof(int));
                    Temp_Datatable.Columns.Add("VESTED_CANCELLED_OPTIONS", typeof(int));
                    Temp_Datatable.Columns.Add("UNVESTED_CANCELLED_OPTIONS", typeof(int));
                    Temp_Datatable.Columns.Add("LAPSED_OPTIONS", typeof(int));
                    Temp_Datatable.Columns.Add("EXERCISED_OPTIONS", typeof(int));
                    Temp_Datatable.Columns.Add("UNVESTED_OPTIONS", typeof(int));
                    Temp_Datatable.Columns.Add("VESTED_AND_EXERCISABLE", typeof(int));
                    Temp_Datatable.Columns.Add("OUTSTANDING_OPTIONS", typeof(int));
                    Temp_Datatable.Columns.Add("COST_AS_PER_SYSTEM", typeof(int));
                    Temp_Datatable.Columns.Add("H_COST_MANUALLY", typeof(int));
                    Temp_Datatable.Columns.Add("OPERATION_ID", typeof(int));
                    Temp_Datatable.Columns.Add("OPERATION_DATE", typeof(int));
                    Temp_Datatable.Columns.Add("PRE_POST_MOD", typeof(int));
                    Temp_Datatable.Columns.Add("CREATED_BY", typeof(int));

                    Temp_Datatable.Columns.Add("OPT_VEST_ID", typeof(int));
                    Temp_Datatable.Columns.Add("REPORTING_DATE", typeof(string));
                    Temp_Datatable.Columns.Add("COST_IV", typeof(double));
                    Temp_Datatable.Columns.Add("COST_FV", typeof(double));
                    Temp_Datatable.Columns.Add("IV_INCREMENTAL_COST", typeof(double));
                    Temp_Datatable.Columns.Add("FV_INCREMENTAL_COST", typeof(double));
                    Temp_Datatable.Columns.Add("IS_IV_INPUT_MANUAL", typeof(int));
                    Temp_Datatable.Columns.Add("IS_FV_INPUT_MANUAL", typeof(int));
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method gets data from textboxes and saves into the table.
        /// </summary>
        /// <param name="modifications">modifications page object</param>
        internal void GetData_ForOptions(Modifications modifications)
        {
            try
            {
                DataTable Temp_Datatable = new DataTable();

                DataRow PreModRow = Temp_Datatable.NewRow();
                if (Temp_Datatable.Columns.Count == 0)
                {
                    CreateInputTable(Temp_Datatable);
                    Temp_Datatable.Rows.Add(PreModRow);
                }

                Temp_Datatable.Columns.Remove("PARAMID");
                Temp_Datatable.Columns.Remove("Vesting Period Number");
                // Pre Modification Data
                Temp_Datatable.Rows[0]["OPT_GRANTED_ID"] = string.IsNullOrEmpty(Convert.ToString(modifications.hdnGntOptID_AddOpt.Value)) ? 0 : Convert.ToInt64(modifications.hdnGntOptID_AddOpt.Value);
                Temp_Datatable.Rows[0]["AGRMID"] = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] =  " + Convert.ToInt32(modifications.hdnGntOptID_AddOpt.Value) + "")[0]["AGRMID"].ToString();
                Temp_Datatable.Rows[0]["GRANT_OPTION_ID"] = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Grant Option ID"].ToString();
                Temp_Datatable.Rows[0]["EMPID"] = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["EMPID"].ToString();
                Temp_Datatable.Rows[0]["GRANTED_OPTIONS"] = string.IsNullOrEmpty(Convert.ToString(modifications.hdnPreTotalOptions.Value)) ? 0 : Convert.ToInt64(modifications.hdnPreTotalOptions.Value);
                Temp_Datatable.Rows[0]["CANCELLED_OPTIONS"] = Convert.ToInt16(modifications.txtMM_PreMod_OptUnVestCancelled.Text) + (Convert.ToInt16(modifications.txtMM_PreMod_OptVestCancelled.Text));
                Temp_Datatable.Rows[0]["VESTED_CANCELLED_OPTIONS"] = modifications.txtMM_PreMod_OptVestCancelled.Text;
                Temp_Datatable.Rows[0]["UNVESTED_CANCELLED_OPTIONS"] = modifications.txtMM_PreMod_OptUnVestCancelled.Text;
                Temp_Datatable.Rows[0]["LAPSED_OPTIONS"] = modifications.txtMM_PreMod_OptLapsed.Text;
                Temp_Datatable.Rows[0]["EXERCISED_OPTIONS"] = modifications.txtMM_PreMod_OptExercised.Text;
                Temp_Datatable.Rows[0]["UNVESTED_OPTIONS"] = modifications.txtMM_PreMod_OptUnvested.Text;
                Temp_Datatable.Rows[0]["VESTED_AND_EXERCISABLE"] = modifications.txtMM_PreMod_OptVestedAndExercisable.Text;
                Temp_Datatable.Rows[0]["OUTSTANDING_OPTIONS"] = string.IsNullOrEmpty(Convert.ToString(modifications.hdnPreOutstandingOptions.Value)) ? 0 : Convert.ToInt64(modifications.hdnPreOutstandingOptions.Value);
                Temp_Datatable.Rows[0]["PRE_POST_MOD"] = 0;
                Temp_Datatable.Rows[0]["VPD_VESTING_PERIOD_ID"] = userSessionInfo.ACC_CalculationMethod == 2 ? ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + modifications.ddl_AddOptions_EmpVestDate.SelectedValue + "'")[0]["Vesting Period Number"].ToString() : "0";
                Temp_Datatable.Rows[0]["OPT_VEST_ID"] = userSessionInfo.ACC_CalculationMethod == 2 ? modifications.ddl_AddOptions_EmpVestDate.SelectedValue : "0";

                DataRow PosteModRow = Temp_Datatable.NewRow();
                Temp_Datatable.Rows.Add(PosteModRow);
                // Post Modification Data
                Temp_Datatable.Rows[1]["OPT_GRANTED_ID"] = string.IsNullOrEmpty(Convert.ToString(modifications.hdnGntOptID_AddOpt.Value)) ? 0 : Convert.ToInt64(modifications.hdnGntOptID_AddOpt.Value);
                Temp_Datatable.Rows[1]["AGRMID"] = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] =  " + Convert.ToInt32(modifications.hdnGntOptID_AddOpt.Value) + "")[0]["AGRMID"].ToString();
                Temp_Datatable.Rows[1]["GRANT_OPTION_ID"] = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["Grant Option ID"].ToString();
                Temp_Datatable.Rows[1]["EMPID"] = ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + modifications.hdnGntOptID_AddOpt.Value + "'")[0]["EMPID"].ToString();
                Temp_Datatable.Rows[1]["GRANTED_OPTIONS"] = string.IsNullOrEmpty(Convert.ToString(modifications.hdnTotalOptions.Value)) ? 0 : Convert.ToInt64(modifications.hdnTotalOptions.Value);
                Temp_Datatable.Rows[1]["CANCELLED_OPTIONS"] = Convert.ToInt64(modifications.txtMM_PostMod_OptUnVestCancelled.Text) + (Convert.ToInt64(modifications.txtMM_PostMod_OptVestCancelled.Text));
                Temp_Datatable.Rows[1]["VESTED_CANCELLED_OPTIONS"] = modifications.txtMM_PostMod_OptVestCancelled.Text;
                Temp_Datatable.Rows[1]["UNVESTED_CANCELLED_OPTIONS"] = modifications.txtMM_PostMod_OptUnVestCancelled.Text;
                Temp_Datatable.Rows[1]["LAPSED_OPTIONS"] = modifications.txtMM_PostMod_OptLapsed.Text;
                Temp_Datatable.Rows[1]["EXERCISED_OPTIONS"] = modifications.txtMM_PostMod_OptExercised.Text;
                Temp_Datatable.Rows[1]["UNVESTED_OPTIONS"] = modifications.txtMM_PostMod_OptUnvested.Text;
                Temp_Datatable.Rows[1]["VESTED_AND_EXERCISABLE"] = modifications.txtMM_PostMod_OptVestedAndExercisable.Text;
                Temp_Datatable.Rows[1]["OUTSTANDING_OPTIONS"] = string.IsNullOrEmpty(Convert.ToString(modifications.hdnOutstandingOptions.Value)) ? 0 : Convert.ToInt64(modifications.hdnOutstandingOptions.Value);
                Temp_Datatable.Rows[1]["PRE_POST_MOD"] = 1;
                Temp_Datatable.Rows[1]["VPD_VESTING_PERIOD_ID"] = userSessionInfo.ACC_CalculationMethod == 2 ? ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT_VEST_ID] = '" + modifications.ddl_AddOptions_EmpVestDate.SelectedValue + "'")[0]["Vesting Period Number"].ToString() : "0";
                Temp_Datatable.Rows[1]["OPT_VEST_ID"] = userSessionInfo.ACC_CalculationMethod == 2 ? modifications.ddl_AddOptions_EmpVestDate.SelectedValue : "0";

                Temp_Datatable.TableName = "DT";
                accountingProperties.dt_Modifications = Temp_Datatable;
                accountingProperties.PageName = CommonConstantModel.s_Modifications;
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;
                modifications.hdnOperationType.Value = (!string.IsNullOrEmpty(modifications.hdnEdit.Value) && modifications.hdnEdit.Value.Equals("U")) ? "UPDATE_MODIFICATION" : "ADD_OPTIONS";

                accountingProperties.Date_Of_Modification = Convert.ToDateTime(modifications.txtMD_DateOfModification.Text == "dd/mmm/yyyy" ? "01/01/1900" : modifications.txtMD_DateOfModification.Text);
                accountingProperties.Date_Of_Modification = ac_Modifications.s_ModificationDate_Combined = accountingProperties.Date_Of_Modification + DateTime.Now.TimeOfDay;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to populate the compensation cost into gridview and then bind it.
        /// </summary>
        /// <param name="modifications">Modifications page object</param>
        internal void Populate_CompensationCost_Details(Modifications modifications)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    ac_Modifications.dt_ModificationInput_Outputs.Clear();
                    ac_Modifications.dt_Calculated_IV_FV_details.Clear();

                    accountingProperties.Action = "GET_EMP_LEVEL_DETAILS_GRANTWISE";
                    accountingProperties.Date_Of_Modification = Convert.ToDateTime(modifications.txtMD_DateOfModification.Text == "dd/mmm/yyyy" ? "01/01/1900" : modifications.txtMD_DateOfModification.Text);
                    accountingProperties.PageName = CommonConstantModel.s_Modifications;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.SEN_CalculationMethod = userSessionInfo.ACC_CalculationMethod;
                    modifications.hdnCalculationMethod.Value = accountingProperties.SEN_CalculationMethod.ToString() + "COMPENSATION_COST";


                    ac_Modifications.dt_Populate_Modification_Grantwise = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                    ac_Modifications.dt_Populate_Modification_Grantwise = (ac_Modifications.dt_Populate_Modification_Grantwise.Select("OPERATION_ID = 8").Count() > 0) ? ac_Modifications.dt_Populate_Modification_Grantwise.Select("OPERATION_ID = 8").CopyToDataTable() : new DataTable();
                    if (ac_Modifications.dt_Populate_Modification_Grantwise.Rows.Count > 0)
                    {
                        ac_Modifications.dt_Populate_Modification_Grantwise.Columns.Add("Vesting Schedule", typeof(string));
                        using (DataView dv_Dataview = new DataView(ac_Modifications.dt_Populate_Modification_Grantwise))
                        {
                            modifications.gv_CompensationCost.DataSource = dv_Dataview.ToTable(true, ac_Modifications.s_CCost__Common);
                        }

                        accountingProperties.Action = "GET_EMP_LEVEL_DETAILS";

                        ac_Modifications.dt_Populate_Modification_details = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                        ac_Modifications.dt_Populate_Modification_details = (ac_Modifications.dt_Populate_Modification_details.Select("OPERATION_ID = 8").Count() > 0) ? ac_Modifications.dt_Populate_Modification_details.Select("OPERATION_ID = 8").CopyToDataTable() : new DataTable();
                        using (DataView dv_Dataview = new DataView(ac_Modifications.dt_Populate_Modification_details))
                        {
                            ac_Modifications.dt_Populate_Modification_details = dv_Dataview.ToTable(true, userSessionInfo.ACC_CalculationMethod == 1 ? ac_Modifications.s_CCost__GrantWise : ac_Modifications.s_CCost__VestWise);

                            if (userSessionInfo.ACC_CalculationMethod.Equals(1))
                            {
                                ac_Modifications.dt_Populate_Modification_details.Columns.Add("Outstanding", typeof(int));
                                ac_Modifications.dt_Populate_Modification_details.Columns.Add("COST AS PER SYSTEM BY IV", typeof(double));
                                ac_Modifications.dt_Populate_Modification_details.Columns.Add("COST AS PER SYSTEM BY FV", typeof(double));
                                ac_Modifications.dt_Populate_Modification_details.Columns.Add("Granted", typeof(int));

                                foreach (DataRow dr in ac_Modifications.dt_Populate_Modification_details.Rows)
                                {
                                    dr["Outstanding"] = Convert.ToString(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + dr["OPT GRANTED ID"] + "'")[0]["Outstanding"]);
                                    dr["Granted"] = Convert.ToString(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + dr["OPT GRANTED ID"] + "'")[0]["Granted"]);
                                    dr["COST AS PER SYSTEM BY IV"] = Convert.ToString(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + dr["OPT GRANTED ID"] + "'")[0]["COST AS PER SYSTEM BY IV"]);
                                    dr["COST AS PER SYSTEM BY FV"] = Convert.ToString(ac_Modifications.dt_Populate_Modification_Grantwise.Select("[OPT GRANTED ID] = '" + dr["OPT GRANTED ID"] + "'")[0]["COST AS PER SYSTEM BY FV"]);
                                }

                            }

                            ac_Modifications.dt_Populate_Modification_details.Columns.Add("Outstanding Options Post Modification", typeof(double));

                            ac_Modifications.dt_Populate_Modification_details.Columns.Add("Fv Post Modification Cost", typeof(double));
                            ac_Modifications.dt_Populate_Modification_details.Columns.Add("Fv Incremental Cost", typeof(double));
                            ac_Modifications.dt_Populate_Modification_details.Columns.Add("FV / Options", typeof(double));

                            ac_Modifications.dt_Populate_Modification_details.Columns.Add("Iv Post Modification Cost", typeof(double));
                            ac_Modifications.dt_Populate_Modification_details.Columns.Add("Iv Incremental Cost", typeof(double));
                            ac_Modifications.dt_Populate_Modification_details.Columns.Add("IV / Options", typeof(double));

                            SetColumnsOrder(ac_Modifications.dt_Populate_Modification_details, ac_Modifications.s_CCost_ColumnNames);
                            Calculate_CompensationCost_for_Emp(modifications, ac_Modifications.dt_Populate_Modification_details);

                        }
                        modifications.gv_CompensationCost.DataBind();
                        modifications.hdnAccordianIndex.Value = "3";
                        Accordian_HideShow(modifications, modifications.hdnAccordianIndex.Value);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method Calculate Compensation Costs and insert it into the datatable.
        /// </summary>
        /// <param name="modifications">modifications page objects</param>
        /// <param name="dt_InputForCoc">dt_InputForCoc table</param>
        internal void Calculate_CompensationCost_for_Emp(Modifications modifications, DataTable dt_InputForCoc)
        {

            DataTable Temp_Datatable = new DataTable();
            CreateInputTable(Temp_Datatable);
            string s_SearchQuery = string.Empty;
            foreach (DataRow dr in dt_InputForCoc.Rows)
            {
                DataRow PreModRow = Temp_Datatable.NewRow();

                PreModRow["OPT_GRANTED_ID"] = dr["OPT GRANTED ID"];
                PreModRow["OPT_VEST_ID"] = userSessionInfo.ACC_CalculationMethod == 1 ? "0" : dr["OPT_VEST_ID"];
                PreModRow["REPORTING_DATE"] = modifications.txtMD_DateOfModification.Text;

                Temp_Datatable.Rows.Add(PreModRow);
            }

            Temp_Datatable.Columns.Remove("PARAMID");
            Temp_Datatable.Columns.Remove("Vesting Period Number");

            Temp_Datatable.TableName = "DT";
            accountingProperties.dt_Modifications = Temp_Datatable;
            accountingProperties.Action = "GET_COMPENSATION_COST_CALCULATIONS";
            accountingProperties.Date_Of_Modification = Convert.ToDateTime(modifications.txtMD_DateOfModification.Text);
            accountingProperties.PageName = CommonConstantModel.s_Modifications;
            accountingProperties.Operation = CommonConstantModel.s_OperationRead;

            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                using (DataTable dt_Calculated_Comp_Cost = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result)
                {
                    foreach (DataRow dr in dt_InputForCoc.Rows)
                    {
                        s_SearchQuery = userSessionInfo.ACC_CalculationMethod.Equals(2) ? " AND OPT_VEST_ID = " + dr["OPT_VEST_ID"] : string.Empty;
                        dr["Iv Post Modification Cost"] = Convert.ToString(dt_Calculated_Comp_Cost.Select("OPT_GRANTED_ID = '" + dr["OPT GRANTED ID"] + "' " + s_SearchQuery + " ")[0]["SYSTEM_COST_IV"]);
                        dr["Iv Incremental Cost"] = !string.IsNullOrEmpty(Convert.ToString(dr["Iv Post Modification Cost"])) && !string.IsNullOrEmpty(Convert.ToString(dr["COST AS PER SYSTEM BY IV"])) ? Convert.ToDouble(dr["Iv Post Modification Cost"]) - Convert.ToDouble(dr["COST AS PER SYSTEM BY IV"]) : 0;
                        dr["IV / Options"] = (Convert.ToDouble(dr["INTRINSIC VALUE"]) / Convert.ToDouble(dr["Granted"]));

                        dr["Fv Post Modification Cost"] = Convert.ToString(dt_Calculated_Comp_Cost.Select("OPT_GRANTED_ID = '" + dr["OPT GRANTED ID"] + "'  " + s_SearchQuery + " ")[0]["SYSTEM_COST_FV"]);
                        dr["Fv Incremental Cost"] = !string.IsNullOrEmpty(Convert.ToString(dr["Fv Post Modification Cost"])) && !string.IsNullOrEmpty(Convert.ToString(dr["COST AS PER SYSTEM BY FV"])) ? Convert.ToDouble(dr["Fv Post Modification Cost"]) - Convert.ToDouble(dr["COST AS PER SYSTEM BY FV"]) : 0;
                        dr["FV / Options"] = (Convert.ToDouble(dr["FAIR VALUE"]) / Convert.ToDouble(dr["Granted"]));

                    }
                }
            }
        }

        /// <summary>
        ///  This method Get inputs from compensation grid view.
        /// </summary>
        /// <param name="modifications">page object</param>
        /// <param name="nameValueCollection">Form control collection</param>
        public void Get_CompensationCost_Inputs(Modifications modifications, System.Collections.Specialized.NameValueCollection nameValueCollection)
        {
            DataTable dt_Get_CocInputs = new DataTable();
            CreateInputTable(dt_Get_CocInputs);
            int i_count = 0;

            foreach (DataRow sourcerow in ac_Modifications.dt_Populate_Modification_details.Rows)
            {
                DataRow dr = dt_Get_CocInputs.NewRow();
                dt_Get_CocInputs.Rows.Add(dr);

                dt_Get_CocInputs.Rows[i_count]["OPT_VEST_ID"] = userSessionInfo.ACC_CalculationMethod == 1 ? "0" : sourcerow["OPT_VEST_ID"];
                dt_Get_CocInputs.Rows[i_count]["Opt_Granted_ID"] = sourcerow["Opt Granted ID"];
                dt_Get_CocInputs.Rows[i_count]["COST_IV"] = sourcerow["COST AS PER SYSTEM BY IV"];
                dt_Get_CocInputs.Rows[i_count]["COST_FV"] = sourcerow["COST AS PER SYSTEM BY FV"];


                i_count = i_count + 1;
            }

            int[] Opt_Granted_ID = new int[ac_Modifications.dt_Populate_Modification_details.Rows.Count];
            double[] txt_IV_Incremental = new double[ac_Modifications.dt_Populate_Modification_details.Rows.Count];
            double[] txt_FV_Incremental = new double[ac_Modifications.dt_Populate_Modification_details.Rows.Count];

            i_count = 0;
            GetData_ForEach_InputCol(dt_Get_CocInputs, nameValueCollection, "txtIv_Incremental", "IV_INCREMENTAL_COST", ac_Modifications.b_IsFirst_Entry, modifications);
            GetData_ForEach_InputCol(dt_Get_CocInputs, nameValueCollection, "txtFv_Incremental", "FV_INCREMENTAL_COST", ac_Modifications.b_IsFirst_Entry, modifications);

            foreach (DataRow sourcerow in ac_Modifications.dt_Populate_Modification_details.Rows)
            {
                dt_Get_CocInputs.Rows[i_count]["IS_IV_INPUT_MANUAL"] = Convert.ToInt16(Convert.ToDouble(sourcerow["Iv Incremental Cost"]) != Convert.ToDouble(dt_Get_CocInputs.Rows[i_count]["IV_INCREMENTAL_COST"]));
                dt_Get_CocInputs.Rows[i_count]["IS_FV_INPUT_MANUAL"] = Convert.ToInt16(Convert.ToDouble(sourcerow["Fv Incremental Cost"]) != Convert.ToDouble(dt_Get_CocInputs.Rows[i_count]["FV_INCREMENTAL_COST"]));

                i_count = i_count + 1;
            }

            dt_Get_CocInputs.Columns.Remove("ParamId");
            dt_Get_CocInputs.Columns.Remove("Vesting Period Number");

            dt_Get_CocInputs.TableName = "DT";
            ac_Modifications.dt_ModificationInput_Outputs = dt_Get_CocInputs.Copy();
            accountingProperties.PageName = CommonConstantModel.s_Modifications;
            accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

        }

        /// <summary>
        /// This method hides / shows the accordian head depending upon the index of accordian passed to it.
        /// </summary>
        /// <param name="modifications">object of modifications</param>
        /// <param name="n_Accordian_index">accordian index number</param>
        public void Accordian_HideShow(Modifications modifications, string n_Accordian_index)
        {
            try
            {
                switch (n_Accordian_index)
                {
                    case "0":
                        modifications.h3Search.Style.Add("display", "block");
                        modifications.h4AddEditMod.Style.Add("display", "none");
                        modifications.h4AddEditOptions.Style.Add("display", "none");
                        modifications.h4CompCost.Style.Add("display", "none");
                        break;

                    case "1":
                        modifications.h3Search.Style.Add("display", "none");
                        modifications.h4AddEditMod.Style.Add("display", "block");
                        modifications.h4AddEditOptions.Style.Add("display", "none");
                        modifications.h4CompCost.Style.Add("display", "none");
                        break;

                    case "2":
                        modifications.h3Search.Style.Add("display", "none");
                        modifications.h4AddEditMod.Style.Add("display", "none");
                        modifications.h4AddEditOptions.Style.Add("display", "block");
                        modifications.h4CompCost.Style.Add("display", "none");
                        break;

                    case "3":
                        modifications.h3Search.Style.Add("display", "none");
                        modifications.h4AddEditMod.Style.Add("display", "none");
                        modifications.h4AddEditOptions.Style.Add("display", "none");
                        modifications.h4CompCost.Style.Add("display", "block");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ModificationsModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}