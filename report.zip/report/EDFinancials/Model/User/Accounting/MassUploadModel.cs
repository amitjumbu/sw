﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    ///  Massupload page file
    /// </summary>
    public class MassUploadModel : BaseModel, IDisposable
    {       
        /// <summary>
        /// Default constructor
        /// </summary>
        public MassUploadModel()
        {
            if (ac_MassUpload == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_MassUpload);
                ac_MassUpload = (CommonModel.AC_MassUpload)HttpContext.Current.Session[CommonConstantModel.s_AC_MassUpload];
            }
        }

        /// <summary>
        /// This method is used to Bind UI controls
        /// </summary>
        /// <param name="massUpload">Mass upload page object</param>
        internal void BindUI(MassUpload massUpload)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_MassUpload.dt_MassUploadUI == null || ac_MassUpload.dt_MassUploadUI.Rows.Count.Equals(0))
                    {
                        ac_MassUpload.dt_MassUploadUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_MassUpload, CommonConstantModel.s_AccountingL10_UI);
                    }

                    if ((ac_MassUpload.dt_MassUploadUI != null) && (ac_MassUpload.dt_MassUploadUI.Rows.Count > 0))
                    {
                        foreach (Control control in massUpload.dvMain.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_MassUpload.dt_MassUploadUI, (Label)control);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_MassUpload.dt_MassUploadUI, (TextBox)control);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_MassUpload.dt_MassUploadUI, (Button)control);
                                    break;

                                case CommonConstantModel.s_wcCheckbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeCheckBox, ac_MassUpload.dt_MassUploadUI, (CheckBox)control);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, ac_MassUpload.dt_MassUploadUI, (RadioButton)control);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, ac_MassUpload.dt_MassUploadUI, (BaseValidator)control);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, ac_MassUpload.dt_MassUploadUI, (BaseValidator)control);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_MassUpload.dt_MassUploadUI, (GridView)control);
                                    break;
                            }

                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="control">control</param>
        private void BindPropertiesToControl(string s_cntrlType, DataTable Dt_Get_L10N_UI, Control control)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    Label label = (Label)control;
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    Button button = (Button)control;
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeCheckBox:
                    CheckBox checkBox = (CheckBox)control;
                    checkBox.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelName"]);
                    checkBox.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRadioButton:
                    RadioButton radioButton = (RadioButton)control;
                    radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                    radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    RequiredFieldValidator ReqValidator = (RequiredFieldValidator)control;
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegularExpressionValidator RegExpValidator = (RegularExpressionValidator)control;
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="massUpload"></param>
        internal void EncryptReportID(MassUpload massUpload)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                massUpload.hdnOptionVestwise.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=18").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                massUpload.hdnOptionVestwise.Dispose();
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~MassUploadModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion                               
    }
}