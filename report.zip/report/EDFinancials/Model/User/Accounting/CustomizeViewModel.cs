﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomizeViewModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public CustomizeViewModel()
        {
            if (ac_CustomizeView == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_CustomizeView);
                ac_CustomizeView = (CommonModel.AC_CustomizeView)HttpContext.Current.Session[CommonConstantModel.s_AC_CustomizeView];
            }
        }

        /// <summary>
        /// Check user have rights on the page or not
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        internal void CheckEmployeeRolePriviledges(CustomizeView customizeView)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuCustomizeView;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    customizeView.btnAddCustomization.Enabled = false;
                                    customizeView.btnSave.Enabled = false;
                                    customizeView.btnDelete.Enabled = false;
                                    ac_CustomizeView.Is_Edit = false;
                                    break;

                                case "ADD":
                                    customizeView.btnAddCustomization.Enabled = true;
                                    customizeView.btnSave.Enabled = true;
                                    break;

                                case "EDIT":
                                    ac_CustomizeView.Is_Edit = true;
                                    customizeView.btnAddCustomization.Enabled = true;
                                    customizeView.btnSave.Enabled = true;
                                    break;

                                case "DELETE":
                                    customizeView.btnDelete.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind customize view UI
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        internal void BindUI(CustomizeView customizeView)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_CustomizeView.dt_Bind_UI.Rows.Count.Equals(0))
                    {
                        ac_CustomizeView.dt_Bind_UI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10_UI);
                    }

                    if ((ac_CustomizeView.dt_Bind_UI != null) && (ac_CustomizeView.dt_Bind_UI.Rows.Count > 0))
                    {
                        foreach (Control control in customizeView.dvCustomizeView.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, customizeView, ac_CustomizeView.dt_Bind_UI, (Label)control, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, customizeView, ac_CustomizeView.dt_Bind_UI, null, null, (Button)control, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, customizeView, ac_CustomizeView.dt_Bind_UI, null, null, null, null, null, (BaseValidator)control, null, null);
                                    break;
                            }

                        }

                        customizeView.btnProcess.Text = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = '" + customizeView.btnProcess.ID + "'"))[0]["LabelName"]);
                        customizeView.lblAddCustomizeViewHeader.Text = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = '" + customizeView.lblAddCustomizeViewHeader.ID + "'"))[0]["LabelName"]);

                        customizeView.gvCustomizeView.EmptyDataText = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblDataNotExit'"))[0]["LabelName"]);
                        customizeView.gvFinal.EmptyDataText = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblDataNotExit'"))[0]["LabelName"]);
                        customizeView.gvLeft.EmptyDataText = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblColNotAvailable'"))[0]["LabelName"]);
                        customizeView.gvRight.EmptyDataText = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblColNotAvailable'"))[0]["LabelName"]);
                        customizeView.s_ColNotAvailable = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblColNotAvailable'"))[0]["LabelName"]);

                        customizeView.lblAssignUserHeader.Text = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = '" + customizeView.lblAssignUserHeader.ID + "'"))[0]["LabelName"]);
                        customizeView.lblSelectUser.Text = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = '" + customizeView.lblSelectUser.ID + "'"))[0]["LabelName"]);
                        customizeView.btnAssignUser.Text = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = '" + customizeView.btnAssignUser.ID + "'"))[0]["LabelName"]);
                        customizeView.lblErrorMessage.Text = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = '" + customizeView.lblErrorMessage.ID + "'"))[0]["LabelName"]);
                        customizeView.btnDeleteAssignUser.Text = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = '" + customizeView.btnDeleteAssignUser.ID + "'"))[0]["LabelName"]);
                        customizeView.btnDeleteAssignUser.ToolTip = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = '" + customizeView.btnDeleteAssignUser.ID + "'"))[0]["LabelToolTip"]);
                        customizeView.lblPreviewHeader.Text = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = '" + customizeView.lblPreviewHeader.ID + "'"))[0]["LabelName"]);

                        customizeView.gvAssignedUser.EmptyDataText = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblDataNotExit'"))[0]["LabelName"]);
                        customizeView.gvUsers.EmptyDataText = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblDataNotExit'"))[0]["LabelName"]);

                        customizeView.btnClearFilter.Visible = false;
                        customizeView.lblErrorMessage.Visible = false;
                        customizeView.btnDeleteAssignUser.Visible = false;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="label">The label control object</param>
        /// <param name="textBox">The text-box control object</param>
        /// <param name="button">The button control object</param>
        /// <param name="checkBox">The CheckBox control object</param>
        /// <param name="radioButton">radiobutton control object</param>
        /// <param name="ReqValidator">validator control object</param>
        /// <param name="RegExpValidator">validator control object</param>
        /// <param name="gridView">gridview control object</param>
        private void BindPropertiesToControl(string s_cntrlType, CustomizeView customizeView, DataTable Dt_Get_L10N_UI, Label label, TextBox textBox, Button button, CheckBox checkBox, RadioButton radioButton, BaseValidator ReqValidator, BaseValidator RegExpValidator, GridView gridView)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    gridView.EmptyDataText = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + gridView.ID + "'"))[0]["LabelName"]);
                    break;
            }
        }

        /// <summary>
        /// Method is used to to bind control with data
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        internal void BindControls(CustomizeView customizeView)
        {
            try
            {
                customizeView.btnProcess.Visible = false;

                customizeView.gvLeft.DataSource = null;
                customizeView.gvLeft.DataBind();

                customizeView.gvRight.DataSource = null;
                customizeView.gvRight.DataBind();

                customizeView.gvAssignedUser.DataSource = null;
                customizeView.gvAssignedUser.DataBind();

                // BIND VIEW DROP DOWN LIST AVAILABLE IN SEARCH PANEL

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "CUSTOMIZE_VIEWS";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    customizeView.ddlSearchViewName.DataSource = accountingCRUDProperties.dt_Result;
                    customizeView.ddlSearchViewName.DataTextField = "VIEW_NAME";
                    customizeView.ddlSearchViewName.DataValueField = "VIEW_NAME";
                    customizeView.ddlSearchViewName.DataBind();

                    customizeView.ddlSearchViewName.Items.Insert(0, "--- Please Select ---");
                }

                // BIND CUSTOMIZE VIEW FOR

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "CUSTOMIZE_VIEW_FOR";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    // SEARCH PANLE DROP DOWN LIST
                    customizeView.ddlSearchPageName.DataSource = accountingCRUDProperties.dt_Result;
                    customizeView.ddlSearchPageName.DataTextField = "CUSTOMIZE_FOR";
                    customizeView.ddlSearchPageName.DataValueField = "CUSTOMIZE_FOR";
                    customizeView.ddlSearchPageName.DataBind();

                    customizeView.ddlSearchPageName.Items.Insert(0, "--- Please Select ---");
                }

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "MAPPINGS_AVAILABLE";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    // ADD/EDIT DROP DOWN LIST                    
                    customizeView.ddlCustomizeViewFor.DataSource = accountingCRUDProperties.dt_Result;
                    customizeView.ddlCustomizeViewFor.DataTextField = "PAGE_NAME";
                    customizeView.ddlCustomizeViewFor.DataValueField = "PAGE_NAME";
                    customizeView.ddlCustomizeViewFor.DataBind();

                    customizeView.ddlCustomizeViewFor.Items.Insert(0, "--- Please Select ---");
                }

                // BIND ROW NUMBER GRID

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "ROW_NUMBERS";

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    customizeView.ddlNoOfRows.DataSource = accountingCRUDProperties.dt_Result;
                    customizeView.ddlNoOfRows.DataTextField = "ROW_NUM";
                    customizeView.ddlNoOfRows.DataValueField = "ROW_NUM";
                    customizeView.ddlNoOfRows.DataBind();
                }

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind grid views
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        internal void BindSearchGrid(CustomizeView customizeView)
        {
            try
            {
                // BIND CUSTOMIZE GRID VIEW DETAILS AVAILABLE IN SEARCH PANEL

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "SELECT_CUSTOMIZE_VIEW";

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    ac_CustomizeView.dt_CustomizeView = accountingCRUDProperties.dt_Result;
                    ac_CustomizeView.dt_Temp_CustomizeView = ac_CustomizeView.dt_CustomizeView;

                    customizeView.gvCustomizeView.DataSource = ac_CustomizeView.dt_Temp_CustomizeView;
                    customizeView.gvCustomizeView.DataBind();
                }

                // Bind Users Grid
                BindUserToGrid(customizeView);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Users Grid
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        private void BindUserToGrid(CustomizeView customizeView)
        {
            try
            {
                customizeView.n_gvUserIndex = 0;
                customizeView.n_gvUserID = 0;
                customizeView.n_gvUserDelete = 0;

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "GET_USERS";

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_CustomizeView.dt_Temp_UserList = accountingCRUDProperties.dt_Result;
                    ac_CustomizeView.dt_Temp_UserList = ac_CustomizeView.dt_Temp_UserList;

                    customizeView.gvUsers.DataSource = ac_CustomizeView.dt_Temp_UserList;
                    customizeView.gvUsers.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to apply filter on grid view
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        internal void ApplyFilter(CustomizeView customizeView)
        {
            try
            {
                string s_ViewName = customizeView.ddlSearchViewName.SelectedIndex > 0 ? "[View Name] = '" + Convert.ToString(customizeView.ddlSearchViewName.SelectedItem.Text) + "'" : string.Empty;
                string s_PageName = customizeView.ddlSearchPageName.SelectedIndex > 0 ? "[For Page] = '" + Convert.ToString(customizeView.ddlSearchPageName.SelectedItem.Text) + "'" : string.Empty;

                if ((!(string.IsNullOrEmpty(s_ViewName))) || (!(string.IsNullOrEmpty(s_PageName))))
                {
                    customizeView.btnClearFilter.Visible = true;
                }

                ac_CustomizeView.dt_Temp_CustomizeView = ac_CustomizeView.dt_CustomizeView;

                try
                {
                    if (!(string.IsNullOrEmpty(s_ViewName)))
                        ac_CustomizeView.dt_Temp_CustomizeView = ac_CustomizeView.dt_Temp_CustomizeView.Select("" + s_ViewName + "").CopyToDataTable();

                    if (!(string.IsNullOrEmpty(s_PageName)))
                        ac_CustomizeView.dt_Temp_CustomizeView = ac_CustomizeView.dt_Temp_CustomizeView.Select("" + s_PageName + "").CopyToDataTable();
                }
                catch
                {
                    ac_CustomizeView.dt_Temp_CustomizeView = new DataTable();
                }

                customizeView.gvCustomizeView.DataSource = ac_CustomizeView.dt_Temp_CustomizeView;
                customizeView.gvCustomizeView.DataBind();
                customizeView.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                customizeView.h3AddEdit.Style.Add("display", "none");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to deselect filter on customize grid view.
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        internal void ResetFilter(CustomizeView customizeView)
        {
            try
            {
                customizeView.btnClearFilter.Visible = false;

                customizeView.ddlSearchViewName.SelectedIndex = -1;
                customizeView.ddlSearchPageName.SelectedIndex = -1;

                customizeView.gvCustomizeView.DataSource = ac_CustomizeView.dt_CustomizeView;
                customizeView.gvCustomizeView.DataBind();

                ac_CustomizeView.dt_Temp_CustomizeView = ac_CustomizeView.dt_CustomizeView;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view row data bind event
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="e"></param>
        /// <param name="n_index">Parameter for Row index</param>
        /// <param name="n_ID">Parameter for ID</param>
        /// <param name="n_Delete">Parameter for Delete column</param>
        /// <param name="n_Action">Parameter for Action Column</param>
        /// <param name="s_ViewName">Parameter for Customize view name</param>
        /// <param name="n_No_Of_Rows">Parameter grid view page count</param>
        internal void gvCustomizeView_RowDataBound(CustomizeView customizeView, GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action, ref string s_ViewName, ref int n_No_Of_Rows)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    n_Delete = n_index;
                                    e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                    break;

                                case "No Of Rows":
                                    n_No_Of_Rows = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    break;
                            }

                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_No_Of_Rows].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Delete].HorizontalAlign = e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Delete].Controls.Add(AddCheckBox(e.Row.Cells[1].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[1].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, "Edit"));
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink_Assign_USER("Assign User", "~/View/App_Themes/images/add-user.png", e.Row.Cells[1].Text, "Assign", customizeView));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to add checkboxes to all grid rows
        /// </summary>
        /// <returns>Return check box objects</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            try
            {
                using (CheckBox checkBox = new CheckBox())
                {
                    checkBox.ID = "chk";
                    checkBox.Text = string.Empty;
                    checkBox.InputAttributes.Add("Value", "0");
                    checkBox.Checked = false;
                    checkBox.AutoPostBack = false;
                    checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                    return checkBox;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Add check box to the grid
        /// </summary>
        /// <param name="s_CustViewID">Customize View Id</param>
        /// <param name="IsDeleted">Deleted flag as Parameter</param>
        /// <returns>Return as a check box</returns>
        private CheckBox AddCheckBox(string s_CustViewID, bool IsDeleted)
        {
            try
            {
                using (CheckBox checkBox = new CheckBox())
                {
                    checkBox.InputAttributes.Add("Value", s_CustViewID);
                    checkBox.ID = "chk";
                    checkBox.Checked = IsDeleted;
                    checkBox.AutoPostBack = false;
                    checkBox.Attributes.Add("name", "Types");
                    checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                    if (!string.IsNullOrEmpty(s_CustViewID))
                    {
                        checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_CustViewID + "',this)");
                    }

                    return checkBox;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to add action image button
        /// </summary>
        /// <param name="s_ToolTip">Parameter for Tool tip</param>
        /// <param name="s_Url">Parameter for image URL</param>
        /// <param name="s_ViewId">Parameter for customize view Id</param>
        /// <param name="s_ViewName">Parameter for customize view name</param>
        /// <param name="s_PageFor">Parameter for Page name selected for create customzie view</param>
        /// <param name="s_NoOfRows">Parameter for grid view page count</param>
        /// <param name="s_Action">CUD Operation varaiable as Parameter</param>
        /// <returns>Return as a image button</returns>
        private Control AddImageLink(string s_ToolTip, string s_Url, string s_ViewId, string s_ViewName, string s_PageFor, string s_NoOfRows, string s_Action)
        {
            try
            {
                using (ImageButton imgButton = new ImageButton())
                {
                    imgButton.ImageUrl = s_Url;
                    imgButton.ToolTip = s_ToolTip;
                    imgButton.Style.Add("cursor", "pointer");

                    if (!string.IsNullOrEmpty(s_ViewName))
                    {
                        imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_ViewId + "','" + s_ViewName + "','" + s_PageFor + "', '" + s_NoOfRows + "', '" + s_Action + "', this)");
                    }

                    imgButton.Enabled = ac_CustomizeView.Is_Edit;
                    return imgButton;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to assign user image button to grid
        /// </summary>
        /// <param name="s_ToolTip">Parameter for Tool tip</param>
        /// <param name="s_Url">Parameter for image URL</param>
        /// <param name="s_ViewId">Parameter for customize view Id</param>
        /// <param name="s_Action">CUD Operation varaiable as Parameter</param>
        /// <param name="customizeView"></param>
        /// <returns>Return as a image button</returns>      
        private Control AddImageLink_Assign_USER(string s_ToolTip, string s_Url, string s_ViewId, string s_Action, CustomizeView customizeView)
        {
            try
            {
                ImageButton imgButton = new ImageButton();

                imgButton.ImageUrl = s_Url;
                imgButton.ID = s_ViewId;
                imgButton.ToolTip = s_ToolTip;
                imgButton.Style.Add("cursor", "pointer");

                imgButton.Click += customizeView.imgButton_Click;

                if (!string.IsNullOrEmpty(s_ViewId))
                {
                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        imgButton.Attributes.Add("onclick", "return ViewAssignUser('" + s_ViewId + "','Assign User')");
                    }
                }
                return imgButton;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to handel page index changing event
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        internal void gvCustomizeView_PageIndexChanging(CustomizeView customizeView, object sender, GridViewPageEventArgs e)
        {
            try
            {
                customizeView.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                customizeView.gvCustomizeView.PageIndex = e.NewPageIndex;
                customizeView.gvCustomizeView.DataSource = ac_CustomizeView.dt_Temp_CustomizeView;
                customizeView.gvCustomizeView.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Delete cumstomze view
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        internal void DeleteCustomizeView(CustomizeView customizeView)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    accountingProperties.PopulateControls = "DELETE_VIEW";

                    string s_InputString = string.Empty, s_OutputString = string.Empty;

                    if (!string.IsNullOrEmpty(customizeView.hdnDeletedRecords.Value))
                    {
                        accountingProperties.Action = "DEL";
                        accountingProperties.s_ViewIDs = customizeView.hdnDeletedRecords.Value.TrimStart(',');
                    }

                    AccountingCRUDProperties accountingCRUDProperties = new AccountingCRUDProperties();
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            customizeView.h3AddEdit.Style.Add("display", "block");
                            customizeView.hdnIsPanelExpand.Value = accountingProperties.Action.Equals("DEL") ? "0" : "1";
                            customizeView.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            customizeView.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("FAIL_MSG", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                            customizeView.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 3:
                            customizeView.h3AddEdit.Style.Add("display", "none");
                            customizeView.hdnIsPanelExpand.Value = "0";
                            customizeView.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            customizeView.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("DELETE_DATA", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                            customizeView.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            customizeView.hdnDeletedRecords.Value = string.Empty;
                            break;

                        case 6:
                            customizeView.h3AddEdit.Style.Add("display", "none");
                            customizeView.hdnIsPanelExpand.Value = "0";
                            customizeView.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            customizeView.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("ALREADY_ASSIGNED_USER", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                            customizeView.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            customizeView.hdnDeletedRecords.Value = string.Empty;
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind some specific message to control
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        internal void BindUIMessage(CustomizeView customizeView)
        {
            try
            {
                if ((ac_CustomizeView.dt_Bind_UI != null) && (ac_CustomizeView.dt_Bind_UI.Rows.Count > 0))
                {
                    customizeView.s_SelectedColumn = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblRightHeader'"))[0]["LabelName"]);
                    customizeView.gvCustomizeView.EmptyDataText = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblDataNotExit'"))[0]["LabelName"]);
                    customizeView.gvFinal.EmptyDataText = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblDataNotExit'"))[0]["LabelName"]);
                    customizeView.gvLeft.EmptyDataText = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblColNotAvailable'"))[0]["LabelName"]);
                    customizeView.gvRight.EmptyDataText = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblColNotAvailable'"))[0]["LabelName"]);
                    customizeView.s_ColNotAvailable = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = 'lblColNotAvailable'"))[0]["LabelName"]);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind Available column list to grid
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        internal void BindLeftGrid(CustomizeView customizeView)
        {
            try
            {
                customizeView.h3AddEdit.Style.Add("display", "block");
                customizeView.hdnIsPanelExpand.Value = "1";
                customizeView.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                // BIND LEFT GRID
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.s_CutomizeViewFor = customizeView.ddlCustomizeViewFor.SelectedItem.Text;
                    accountingProperties.PopulateControls = "LEFT_GRID";

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    customizeView.gvLeft.DataSource = accountingCRUDProperties.dt_Result;
                    customizeView.gvLeft.DataBind();

                    customizeView.gvRight.DataSource = null;
                    customizeView.gvRight.DataBind();

                    ac_CustomizeView.dt_LeftGridData = accountingCRUDProperties.dt_Result;

                    if (accountingCRUDProperties.dt_Result.Rows.Count > 0)
                    {
                        customizeView.btnProcess.Visible = true;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind Right hand seleted data to final grid
        /// </summary>
        /// <param name="s_Values">Parameter for selected column</param>
        /// <param name="s_PageName">Parameter for customize view for</param>
        /// <param name="o_Data">Parameter for View Id and Customize view page for</param>
        /// <returns>return stirng array as result</returns>
        internal string BindFinalGrid(object s_Values, object s_PageName, object o_Data)
        {
            try
            {
                if (!Convert.ToString(s_Values).ToUpper().Equals("DATA DOES NOT EXIST"))
                {
                    bool b_IsColumnExist = true;

                    ac_CustomizeView.dt_FinalData = new DataTable("dt_FinalData");
                    ac_CustomizeView.dt_FinalData.Columns.Add("COLUMN_NAME", typeof(string));
                    ac_CustomizeView.dt_FinalData.Columns.Add("COLUMN_ALIAS", typeof(string));
                    ac_CustomizeView.dt_FinalData.Columns.Add("COLUMN_ALIAS_NEW", typeof(string));
                    ac_CustomizeView.dt_FinalData.Columns.Add("SHOW_TOTAL", typeof(string));
                    ac_CustomizeView.dt_FinalData.Columns.Add("DECIMAL_NUMBER", typeof(string));

                    foreach (string s_FieldName in Convert.ToString(s_Values).Split(','))
                    {
                        DataRow dataRow = ac_CustomizeView.dt_FinalData.NewRow();

                        DataRow[] dataRowEmployee = null;

                        if (!string.IsNullOrEmpty(Convert.ToString(o_Data)))
                        {
                            dataRowEmployee = ac_CustomizeView.dt_EditFinalView.Select("COLUMN_ALIAS = '" + s_FieldName.Trim() + "'");

                            if (dataRowEmployee.Length == 0)
                            {
                                b_IsColumnExist = false;
                                dataRowEmployee = ac_CustomizeView.dt_LeftGridData.Select("COLUMN_ALIAS = '" + s_FieldName.Trim() + "'");
                            }
                        }
                        else
                        {
                            b_IsColumnExist = false;
                            dataRowEmployee = ac_CustomizeView.dt_LeftGridData.Select("COLUMN_ALIAS = '" + s_FieldName.Trim() + "'");
                        }

                        dataRow["COLUMN_NAME"] = Convert.ToString(dataRowEmployee[0]["COLUMN_NAME"]);
                        dataRow["COLUMN_ALIAS"] = Convert.ToString(dataRowEmployee[0]["COLUMN_ALIAS"]);
                        dataRow["COLUMN_ALIAS_NEW"] = b_IsColumnExist ? Convert.ToString(dataRowEmployee[0]["COLUMN_ALIAS_NEW"]) : string.Empty;
                        dataRow["SHOW_TOTAL"] = b_IsColumnExist ? Convert.ToString(dataRowEmployee[0]["SHOW_TOTAL"]) : Convert.ToString(dataRowEmployee[0]["COLUMN_DATATYPE"]);
                        dataRow["DECIMAL_NUMBER"] = b_IsColumnExist ? Convert.ToString(dataRowEmployee[0]["DECIMAL_NUMBER"]) : string.Empty;
                        ac_CustomizeView.dt_FinalData.Rows.Add(dataRow);

                    }
                }

                return DataTableToJSON(ac_CustomizeView.dt_FinalData);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Return datatable to Json
        /// </summary>
        /// <param name="dt_FinalData">Parameter for datatable</param>
        /// <returns>return as string array</returns>
        private string DataTableToJSON(DataTable dt_FinalData)
        {
            try
            {
                JavaScriptSerializer json = new JavaScriptSerializer();

                Dictionary<string, object> dictionary = new Dictionary<string, object>();

                if (dt_FinalData.Rows.Count > 0)
                {
                    object[] arr = new object[dt_FinalData.Rows.Count + 1];

                    for (int i = 0; i <= dt_FinalData.Rows.Count - 1; i++)
                    {
                        arr[i] = dt_FinalData.Rows[i].ItemArray;
                    }

                    dictionary.Add(dt_FinalData.TableName, arr);
                }

                return json.Serialize(dictionary);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to seve final grid data to database.
        /// </summary>
        /// <param name="o_ColumnAliasNew">String array of Column new alies name</param>
        /// <param name="o_IsTotal">String array of contaits should total available for column</param>
        /// <param name="o_DecimalPoint">String array of contaits decimal point information</param>
        /// <param name="o_PageName">Parameter is used to selected page name</param>
        /// <param name="o_ViewName">Parameter is used for entered view name</param>
        /// <param name="o_NoOfRows">Parameter is used for selected no of rows</param>
        /// <param name="o_Edit">Parameter for check reuest for edit/insert</param>
        /// <returns>return stirng array as result</returns>
        internal string[] SaveCustomizeView(object o_ColumnAliasNew, object o_IsTotal, object o_DecimalPoint, object o_PageName, object o_ViewName, object o_NoOfRows, object o_Edit)
        {
            try
            {
                string[] s_Result = new string[2];

                if (!string.IsNullOrEmpty(Convert.ToString(o_ColumnAliasNew)))
                {
                    for (int i = 0; i < Convert.ToString(o_ColumnAliasNew).Split(',').Length; i++)
                    {
                        ac_CustomizeView.dt_FinalData.Rows[i]["COLUMN_ALIAS_NEW"] = Convert.ToString(o_ColumnAliasNew).Split(',')[i];
                        ac_CustomizeView.dt_FinalData.Rows[i]["SHOW_TOTAL"] = ((Convert.ToString(o_IsTotal).Split(',')[i]) == "null") ? string.Empty : (Convert.ToString(o_IsTotal).Split(',')[i].TrimStart('"').TrimEnd('"').Equals("false")) ? "0" : "1";
                        ac_CustomizeView.dt_FinalData.Rows[i]["DECIMAL_NUMBER"] = ((Convert.ToString(o_DecimalPoint).Split(',')[i]) == "null") ? string.Empty : Convert.ToString(o_DecimalPoint).Split(',')[i];
                        ac_CustomizeView.dt_FinalData.AcceptChanges();
                    }

                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                        accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                        accountingProperties.s_ViewName = Convert.ToString(o_ViewName);
                        accountingProperties.s_Row_Number = Convert.ToString(o_NoOfRows);
                        accountingProperties.s_CUSTOMIZE_VIEW_FOR = Convert.ToString(o_PageName);
                        accountingProperties.dt_CustomizeViewDet = ac_CustomizeView.dt_FinalData;
                        accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                        accountingProperties.PopulateControls = "INSERT_VIEW";

                        if (string.IsNullOrEmpty(Convert.ToString(o_Edit)))
                        {
                            accountingProperties.Action = "INS";
                            accountingProperties.s_ViewID = string.Empty;
                        }
                        else
                        {
                            accountingProperties.Action = "UPD";
                            string[] s_Data = Convert.ToString(o_Edit).Split('|');
                            accountingProperties.s_ViewID = Convert.ToString(s_Data[0]);
                        }

                        AccountingCRUDProperties accountingCRUDProperties = new AccountingCRUDProperties();
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                        s_Result[0] = Convert.ToString(accountingCRUDProperties.a_result);

                        switch (accountingCRUDProperties.a_result)
                        {
                            case 0:
                                s_Result[1] = accountingServiceClient.GetAccounting_L10N("FAIL_MSG", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                                break;

                            case 1:
                                s_Result[1] = accountingServiceClient.GetAccounting_L10N("INSERT_SUCCESS_MSG", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                                break;

                            case 2:
                                s_Result[1] = accountingServiceClient.GetAccounting_L10N("UPDATE_SUCCESS_MSG", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                                break;

                            case 5:
                                s_Result[1] = accountingServiceClient.GetAccounting_L10N("ALREADY_EXIST", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                                break;
                        }
                    }
                }

                return s_Result;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        internal void btnCancel_Click(CustomizeView customizeView)
        {
            try
            {
                RefreshPage(customizeView);

                customizeView.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                customizeView.ctrSuccessErrorMessage.s_MessageText = string.Empty;

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        private void RefreshPage(CustomizeView customizeView)
        {
            try
            {
                customizeView.hdnIsPanelExpand.Value = "0";
                customizeView.h3AddEdit.Style.Add("display", "none");

                customizeView.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                customizeView.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                customizeView.ddlCustomizeViewFor.SelectedIndex = -1;
                customizeView.ddlNoOfRows.SelectedIndex = -1;

                customizeView.txtViewName.Text = string.Empty;

                BindControls(customizeView);

                BindUIMessage(customizeView);

                customizeView.gvLeft.DataSource = null;
                customizeView.gvLeft.DataBind();

                customizeView.gvRight.DataSource = null;
                customizeView.gvRight.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        internal void ShowMessage(CustomizeView customizeView, object sender, EventArgs e)
        {
            try
            {
                switch ((((Button)sender).ID).ToUpper())
                {
                    case "BTNSAVEREFRESH":
                        using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                        {
                            customizeView.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("INSERT_SUCCESS_MSG", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                        }
                        break;

                    case "BTNEDITMESSAGE":
                        using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                        {
                            customizeView.hdnEditView.Value = string.Empty;
                            customizeView.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("UPDATE_SUCCESS_MSG", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                        }
                        break;
                }
                RefreshPage(customizeView);

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// HANDLE IMAGE BUTTON CLICK EVENT
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        internal void imgButton_Click(CustomizeView customizeView, object sender, ImageClickEventArgs e)
        {
            try
            {

                customizeView.hdnSelectedUsers.Value = string.Empty;

                customizeView.PopupBackgroundDiv.Style.Add("display", "block");
                customizeView.PopupMainContentDiv.Style.Add("display", "block");

                customizeView.gvUsers.PageIndex = 0;
                customizeView.gvAssignedUser.PageIndex = 0;

                HideErrorMessage(customizeView);

                customizeView.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                ac_CustomizeView.s_ViewId = ((ImageButton)sender).ID;

                if (ac_CustomizeView.dt_Temp_CustomizeView.Rows.Count > 0)
                {
                    DataRow[] dataRow = ac_CustomizeView.dt_Temp_CustomizeView.Select("ID = '" + ac_CustomizeView.s_ViewId + "'");

                    if (dataRow.Length > 0)
                    {
                        customizeView.lblAssignUserHeader.Text = Convert.ToString((ac_CustomizeView.dt_Bind_UI.Select("LabelID = '" + customizeView.lblAssignUserHeader.ID + "'"))[0]["LabelName"]) + " to View : " + Convert.ToString(dataRow[0]["View Name"]);
                    }
                }

                // BIND ASSIGNED USERS TO GRID
                BindAssignedUsersGrid(customizeView, ac_CustomizeView.s_ViewId);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// COMMON METHOD FOR BIND USERS GRID AND ASSIGN USERS TO GRID
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="s_ViewId">Parameter is used for assign View Id</param>
        private void BindAssignedUsersGrid(CustomizeView customizeView, string s_ViewId)
        {
            try
            {
                // BIND ASSIGNED USERS TO GRID
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "ASSIGNED_USERS";
                    accountingProperties.s_ViewID = s_ViewId;

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_CustomizeView.dt_AssignUserList = accountingCRUDProperties.dt_Result;

                    customizeView.gvAssignedUser.DataSource = ac_CustomizeView.dt_AssignUserList;
                    customizeView.gvAssignedUser.DataBind();

                    customizeView.btnDeleteAssignUser.Visible = ac_CustomizeView.dt_AssignUserList.Rows.Count > 0;
                }

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customizeView"></param>
        /// <param name="e"></param>
        /// <param name="n_gvAssignUserIndex"></param>
        /// <param name="n_gvAssignUserID"></param>
        /// <param name="n_gvAssignUserDelete"></param>
        /// <param name="n_gvAssignUserDefView"></param>
        internal void gvAssignedUser_RowDataBound(CustomizeView customizeView, GridViewRowEventArgs e, ref int n_gvAssignUserIndex, ref int n_gvAssignUserID, ref int n_gvAssignUserDelete, ref int n_gvAssignUserDefView)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    n_gvAssignUserID = n_gvAssignUserIndex;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    n_gvAssignUserDelete = n_gvAssignUserIndex;
                                    e.Row.Cells[n_gvAssignUserDelete].Controls.Add(AddgvAssignedUserCheckBox("chkDelete", "SelectAllAssignedUsersCheckBoxes", "No", ""));
                                    break;

                                case "DEFAULT VIEW":
                                    n_gvAssignUserDefView = n_gvAssignUserIndex;
                                    break;
                            }
                            n_gvAssignUserIndex = n_gvAssignUserIndex + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_gvAssignUserID].Visible = false;
                        e.Row.Cells[n_gvAssignUserDelete].HorizontalAlign = e.Row.Cells[n_gvAssignUserDelete].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_gvAssignUserDelete].Controls.Add(AddAssignedUsersCheckBox(e.Row.Cells[1].Text, e.Row.Cells[n_gvAssignUserDelete].Text.Equals("1"), "chkAssignedUsers", "DeleteSelectedAssignedUsersRecords"));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private Control AddgvAssignedUserCheckBox(string s_ControlID, string s_JavascriptMethodName, string s_ParameterOne, string Caption)
        {
            try
            {
                using (CheckBox checkBox = new CheckBox())
                {
                    checkBox.ID = s_ControlID;
                    checkBox.Text = Caption;
                    checkBox.InputAttributes.Add("Value", "0");
                    checkBox.Checked = s_ParameterOne.Equals("YES");
                    checkBox.AutoPostBack = false;
                    checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                    switch (s_JavascriptMethodName)
                    {
                        case "SelectAllAssignedUsersCheckBoxes":
                            checkBox.Attributes.Add("Onclick", "javascript : return SelectAllAssignedUsersCheckBoxes(this);");
                            break;
                    }
                    return checkBox;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to select user for Assign to User
        /// </summary>
        /// <param name="s_ID">Parameter for User Id</param>
        /// <param name="IsDeleted">Parameter for set status</param>
        /// <param name="s_ControlID">Parameter for User Id</param>
        /// <param name="s_JavascriptMethodName">Parameter for User Id</param>
        /// <returns>Return check box control</returns>
        private Control AddAssignedUsersCheckBox(string s_ID, bool IsDeleted, string s_ControlID, string s_JavascriptMethodName)
        {
            try
            {
                // string s_ControlID, string s_JavascriptMethodName, string s_ParameterOne, string Caption, string s_Action
                using (CheckBox checkBox = new CheckBox())
                {
                    checkBox.InputAttributes.Add("Value", s_ID);
                    checkBox.ID = s_ControlID;
                    checkBox.Checked = IsDeleted;
                    checkBox.AutoPostBack = false;
                    checkBox.Attributes.Add("name", "Types");
                    checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                    if (!string.IsNullOrEmpty(s_ID))
                    {
                        switch (s_JavascriptMethodName)
                        {
                            case "DeleteSelectedAssignedUsersRecords":
                                checkBox.Attributes.Add("onclick", "return DeleteSelectedAssignedUsersRecords('" + s_ID + "',this)");
                                break;
                        }
                    }
                    return checkBox;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// HANDLE GRID VIEW PAGE INDEX CHANGING EVENT
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        internal void gvAssignedUser_PageIndexChanging(CustomizeView customizeView, object sender, GridViewPageEventArgs e)
        {
            try
            {
                customizeView.PopupBackgroundDiv.Style.Add("display", "block");
                customizeView.PopupMainContentDiv.Style.Add("display", "block");

                // METHOD IS USED TO HIDE ERROR MESSGE AFTER REFRESH GRID VIEW
                HideErrorMessage(customizeView);

                customizeView.n_gvAssignUserIndex = 0;
                customizeView.n_gvAssignUserID = 0;
                customizeView.n_gvAssignUserDelete = 0;

                customizeView.gvAssignedUser.PageIndex = e.NewPageIndex;
                customizeView.gvAssignedUser.DataSource = ac_CustomizeView.dt_AssignUserList;
                customizeView.gvAssignedUser.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customizeView"></param>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        internal void btnDeleteAssignUser_Click(CustomizeView customizeView, object sender, EventArgs e)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    accountingProperties.PopulateControls = "DELETE_ASSIGN_USERS";

                    if (!string.IsNullOrEmpty(customizeView.hdnDeleteAssignUser.Value))
                    {
                        accountingProperties.Action = "DEL";
                        accountingProperties.s_Assigned_Users_ID = customizeView.hdnDeleteAssignUser.Value.TrimStart(',');
                    }

                    AccountingCRUDProperties accountingCRUDProperties = new AccountingCRUDProperties();
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    customizeView.PopupBackgroundDiv.Style.Add("display", "block");
                    customizeView.PopupMainContentDiv.Style.Add("display", "block");

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            customizeView.lblErrorMessage.Visible = true;
                            customizeView.lblErrorMessage.Text = accountingServiceClient.GetAccounting_L10N("FAIL_MSG", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                            customizeView.lblErrorMessage.ForeColor = Color.Red;
                            break;

                        case 3:
                            customizeView.lblErrorMessage.Visible = true;
                            customizeView.lblErrorMessage.Text = accountingServiceClient.GetAccounting_L10N("REMOVE_ASSIGNED_USER", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                            customizeView.lblErrorMessage.ForeColor = Color.Blue;
                            break;
                    }
                }

                // BIND ASSIGNED USERS TO GRID
                BindAssignedUsersGrid(customizeView, ac_CustomizeView.s_ViewId);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind controls to user grid
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="e">contains the event data</param>
        /// <param name="n_gvUserIndex">Parameter for idntity index</param>
        /// <param name="n_gvUserID">Prarmeter for set User Id index</param>
        /// <param name="n_gvUserDelete">Parameter for delete index</param>
        /// <param name="n_gvUserDefView">Default view index</param>
        internal void gvUsers_RowDataBound(CustomizeView customizeView, GridViewRowEventArgs e, ref int n_gvUserIndex, ref int n_gvUserID, ref int n_gvUserDelete, ref int n_gvUserDefView)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "UMID":
                                    n_gvUserID = n_gvUserIndex;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    n_gvUserDelete = n_gvUserIndex;
                                    e.Row.Cells[n_gvUserDelete].Controls.Add(AddgvUserCheckBox("chkDelete", "SelectAllUsersCheckBoxes", "No", "", "Delete"));
                                    break;

                                case "DEFAULT VIEW":
                                    n_gvUserDefView = n_gvUserIndex;
                                    break;
                            }

                            n_gvUserIndex = n_gvUserIndex + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_gvUserID].Visible = false;
                        e.Row.Cells[n_gvUserDelete].HorizontalAlign = e.Row.Cells[n_gvUserDelete].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_gvUserDelete].Controls.Add(AddUsersCheckBox(e.Row.Cells[1].Text, e.Row.Cells[n_gvUserDelete].Text.Equals("1"), "chkUsers", "DeleteSelectedUsersRecords", "Delete", e.Row.RowIndex));
                        e.Row.Cells[n_gvUserDefView].HorizontalAlign = e.Row.Cells[n_gvUserDefView].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_gvUserDefView].Controls.Add(AddUsersCheckBox(e.Row.Cells[1].Text, e.Row.Cells[n_gvUserDefView].Text.Equals("1"), "chkUsersDefaultView", "DefaultSelectedUsersRecords", "Default", e.Row.RowIndex));

                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>return check box control</returns>
        private Control AddgvUserCheckBox(string s_ControlID, string s_JavascriptMethodName, string s_ParameterOne, string Caption, string s_Action)
        {
            try
            {
                using (CheckBox checkBox = new CheckBox())
                {
                    checkBox.ID = s_ControlID;
                    checkBox.Text = Caption;
                    checkBox.InputAttributes.Add("Value", "0");
                    checkBox.Checked = s_ParameterOne.Equals("YES");
                    checkBox.AutoPostBack = false;
                    checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                    switch (s_JavascriptMethodName)
                    {
                        case "SelectAllUsersCheckBoxes":
                            checkBox.Attributes.Add("Onclick", "javascript : return SelectAllUsersCheckBoxes(this, '" + s_Action + "');");
                            break;
                    }
                    return checkBox;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add checkbox
        /// </summary>
        /// <param name="s_UserId">User ID</param>
        /// <param name="IsDeleted">Is Delete</param>
        /// <param name="s_ControlID">Control ID</param>
        /// <param name="s_JavascriptMethodName">Method name</param>
        /// <param name="s_Action">Action</param>
        /// <param name="n_RowIndex">Row number</param>
        /// <returns>Control</returns>
        private Control AddUsersCheckBox(string s_UserId, bool IsDeleted, string s_ControlID, string s_JavascriptMethodName, string s_Action, int n_RowIndex)
        {
            try
            {
                using (CheckBox checkBox = new CheckBox())
                {
                    checkBox.ID = s_ControlID + "_" + n_RowIndex;
                    checkBox.Text = "";
                    checkBox.InputAttributes.Add("class", s_Action.Equals("Delete") ? "Delete" : "Default");
                    checkBox.InputAttributes.Add("Value", "0");
                    checkBox.Checked = IsDeleted;
                    checkBox.AutoPostBack = false;

                    checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                    switch (s_JavascriptMethodName)
                    {
                        case "DeleteSelectedUsersRecords":
                            checkBox.Attributes.Add("Onclick", "javascript : return DeleteSelectedUsersRecords('" + s_UserId + "',this);");
                            break;

                        case "DefaultSelectedUsersRecords":
                            checkBox.Attributes.Add("Onclick", "javascript : return DefaultSelectedUsersRecords('" + s_UserId + "',this);");
                            break;
                    }

                    return checkBox;
                }
            }
            catch
            {
                throw;
            }
        }
        
        /// <summary>
        ///  HANDLE GRID VIEW PAGE INDEX CHANGING EVENT
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        internal void gvUsers_PageIndexChanging(CustomizeView customizeView, object sender, GridViewPageEventArgs e)
        {
            try
            {
                customizeView.PopupBackgroundDiv.Style.Add("display", "block");
                customizeView.PopupMainContentDiv.Style.Add("display", "block");

                // METHOD IS USED TO HIDE ERROR MESSGE AFTER REFRESH GRID VIEW
                HideErrorMessage(customizeView);

                customizeView.n_gvUserIndex = 0;
                customizeView.n_gvUserID = 0;
                customizeView.n_gvUserDelete = 0;

                customizeView.gvUsers.PageIndex = e.NewPageIndex;
                customizeView.gvUsers.DataSource = ac_CustomizeView.dt_Temp_UserList;
                customizeView.gvUsers.DataBind();

                // BIND ASSIGNED USERS TO GRID
                BindAssignedUsersGrid(customizeView, ac_CustomizeView.s_ViewId);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// METHOD IS USED TO HIDE ERROR MESSGE AFTER REFRESH GRID VIEW
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        private static void HideErrorMessage(CustomizeView customizeView)
        {
            customizeView.lblErrorMessage.Text = string.Empty;
            customizeView.lblErrorMessage.Visible = false;
        }

        /// <summary>
        /// BUTTON EVENT IS USED TO ASSIGN VIEW TO USERS 
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        internal void btnAssignUser_Click(CustomizeView customizeView, object sender, EventArgs e)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.PopulateControls = "INSERT_ASSIGN_USERS";

                    accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;

                    if (!string.IsNullOrEmpty(customizeView.hdnSelectedUsers.Value))
                    {
                        accountingProperties.Action = "INS";
                        accountingProperties.s_ViewIDs = customizeView.hdnSelectedUsers.Value.TrimStart(',');
                    }

                    int i = 1;
                    ac_CustomizeView.dt_AssignUserToView = new DataTable("dt_AssignUserToView");
                    ac_CustomizeView.dt_AssignUserToView.Columns.Add("temp_ID", typeof(int));
                    ac_CustomizeView.dt_AssignUserToView.Columns.Add("VIEW_ID", typeof(string));
                    ac_CustomizeView.dt_AssignUserToView.Columns.Add("USER_IDS", typeof(string));
                    ac_CustomizeView.dt_AssignUserToView.Columns.Add("IsDefaultView", typeof(string));

                    string[] DefaultViewlist = Convert.ToString(customizeView.hdnDefaultView.Value).Split(',');

                    foreach (string s_UserId in accountingProperties.s_ViewIDs.Split(','))
                    {
                        DataRow dataRow = ac_CustomizeView.dt_AssignUserToView.NewRow();
                        dataRow["temp_ID"] = i++;
                        dataRow["VIEW_ID"] = ac_CustomizeView.s_ViewId;
                        dataRow["USER_IDS"] = s_UserId;
                        dataRow["IsDefaultView"] = DefaultViewlist.Where(element => element.Equals(s_UserId)).Count().Equals(0) ? "0" : "1";
                        ac_CustomizeView.dt_AssignUserToView.Rows.Add(dataRow);
                    }

                    accountingProperties.dt_AssignUsersToView = ac_CustomizeView.dt_AssignUserToView;

                    AccountingCRUDProperties accountingCRUDProperties = new AccountingCRUDProperties();
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    customizeView.PopupBackgroundDiv.Style.Add("display", "block");
                    customizeView.PopupMainContentDiv.Style.Add("display", "block");
                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            customizeView.lblErrorMessage.Visible = true;
                            customizeView.lblErrorMessage.Text = accountingServiceClient.GetAccounting_L10N("FAIL_MSG", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                            customizeView.lblErrorMessage.ForeColor = Color.Red;
                            break;

                        case 1:
                            customizeView.lblErrorMessage.Visible = true;
                            customizeView.lblErrorMessage.Text = accountingServiceClient.GetAccounting_L10N("ASSIGNED_USER", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                            customizeView.lblErrorMessage.ForeColor = Color.Blue;
                            break;

                        case 5:
                            customizeView.lblErrorMessage.Visible = true;
                            customizeView.lblErrorMessage.Text = accountingServiceClient.GetAccounting_L10N("ALREADY_ASSIGNED", CommonConstantModel.s_CustomizeView, CommonConstantModel.s_AccountingL10);
                            customizeView.lblErrorMessage.ForeColor = Color.Red;
                            break;
                    }
                }

                // Bind Users Grid
                BindUserToGrid(customizeView);

                // BIND ASSIGNED USERS TO GRID
                BindAssignedUsersGrid(customizeView, ac_CustomizeView.s_ViewId);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// BIND LEFT GRID 
        /// </summary>
        /// <param name="customizeView">Customize view page object</param>
        /// <param name="sender">contains a reference to the control/object that raised the event</param>
        /// <param name="e">contains the event data</param>
        internal void OnEditButton(CustomizeView customizeView, object sender, EventArgs e)
        {
            try
            {
                customizeView.PopupBackgroundDiv.Style.Add("display", "none");
                customizeView.PopupMainContentDiv.Style.Add("display", "none");

                customizeView.h3AddEdit.Style.Add("display", "block");
                customizeView.hdnIsPanelExpand.Value = "1";
                customizeView.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                customizeView.ddlCustomizeViewFor.Enabled = false;
                customizeView.txtViewName.Enabled = false;
                customizeView.btnLoadColumn.Enabled = false;

                customizeView.ddlCustomizeViewFor.CssClass = "cDropDownList";
                customizeView.txtViewName.CssClass = "cTextBox";

                // BIND LEFT GRID
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.s_CutomizeViewFor = customizeView.ddlCustomizeViewFor.SelectedItem.Text;
                    accountingProperties.s_ViewID = customizeView.hdnEditView.Value;
                    accountingProperties.PopulateControls = "LEFT_GRID_EDIT";

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    customizeView.gvLeft.DataSource = accountingCRUDProperties.dt_Result;
                    customizeView.gvLeft.DataBind();

                    customizeView.gvRight.DataSource = null;
                    customizeView.gvRight.DataBind();

                    ac_CustomizeView.dt_LeftGridData = accountingCRUDProperties.dt_Result;

                    if (accountingCRUDProperties.dt_Result.Rows.Count > 0)
                    {
                        customizeView.btnProcess.Visible = true;
                    }

                    BindUIMessage(customizeView);
                }

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.s_CutomizeViewFor = customizeView.ddlCustomizeViewFor.SelectedItem.Text;
                    accountingProperties.s_ViewID = customizeView.hdnEditView.Value;
                    accountingProperties.PopulateControls = "FINAL_GRID_EDIT";

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_CustomizeView.dt_FinalData = accountingCRUDProperties.dt_Result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// METHOD IS USED TO BIND RIGHT HAND GRID AFTER CLIK ON EDIT BUTTON
        /// </summary>
        /// <param name="o_Data">Parameter for View Id and Customize view page for</param>
        /// <returns>RETRUN STRING ARRAY</returns>
        internal string BindRightGridOnEdit(object o_Data)
        {
            try
            {
                // BIND LEFT GRID ON EDIT
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    string[] s_Data = Convert.ToString(o_Data).Split('|');
                    accountingProperties.s_ViewID = Convert.ToString(s_Data[0]);
                    accountingProperties.s_CutomizeViewFor = Convert.ToString(s_Data[1]);
                    accountingProperties.PopulateControls = "RIGHT_GRID_EDIT";

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_CustomizeView.dt_EditRightView = accountingCRUDProperties.dt_Result.Copy();
                }

                return DataTableToJSON(ac_CustomizeView.dt_EditRightView);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// METHOD IS USED TO BIND FINAL GRID ON EDIT
        /// </summary>
        /// <param name="o_Data">Parameter for View Id and Customize view page for</param>
        /// <returns>RETRUN STRING ARRAY</returns>
        internal string BindFinalGridOnEdit(object o_Data)
        {
            try
            {
                // BIND FINAL GRID ON EDTI
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CustomizeView;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    string[] s_Data = Convert.ToString(o_Data).Split('|');
                    accountingProperties.s_ViewID = Convert.ToString(s_Data[0]);
                    accountingProperties.s_CutomizeViewFor = Convert.ToString(s_Data[1]);
                    accountingProperties.PopulateControls = "FINAL_GRID_EDIT";

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_CustomizeView.dt_EditFinalView = accountingCRUDProperties.dt_Result.Copy();
                }

                return DataTableToJSON(ac_CustomizeView.dt_EditFinalView);
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CustomizeViewModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}