﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// The class file for HCCommon Model
    /// </summary>
    public class HCCommonModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public HCCommonModel()
        {
            if (ac_HistoricalCost == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_HistoricalCost);
                ac_HistoricalCost = (CommonModel.AC_HistoricalCost)HttpContext.Current.Session[CommonConstantModel.s_AC_HistoricalCost];
            }
        }

        /// <summary>
        /// Used to bind tooltips to dropdown items
        /// </summary>
        /// <param name="list">ListControl object</param>
        public void BindToolTip(ListControl list)
        {
            try
            {
                foreach (ListItem item in list.Items)
                {
                    item.Attributes.Add("title", item.Text);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to rebind all the grids on postback
        /// </summary>
        /// <param name="historicalCost">HistoricalCost page object</param>
        /// <param name="b_IsPageIndChange">boolean value as a input parameter</param>
        public void ReBindAddGridsOnPostBack(HistoricalCost historicalCost, bool b_IsPageIndChange)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_AccountingParameter;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_OperationRead;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_AccountingParameter.ds_AccountingParameters = (DataSet)accountingCRUDProperties.ds_Result;
                    historicalCost.gvAParmsHCost.DataSource = ac_AccountingParameter.ds_AccountingParameters.Tables[1];
                    historicalCost.gv.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// method is used to add Image link 
        /// </summary>
        /// <param name="historicalCost">historicalCost page object</param>
        /// <param name="s_ToolTip">ToolTip object</param>
        /// <param name="s_Url">Url object</param>
        /// <param name="s_OPID">OPID object</param>
        /// <param name="s_OGID">OGIS object</param>
        /// <param name="s_Islocked">s_Islocked object</param>
        /// <returns></returns>
        public ImageButton AddImageLink(HistoricalCost historicalCost, string s_ToolTip, string s_Url, string s_OPID, string s_OGID,string s_Islocked)
        {
            ImageButton imgButton = new ImageButton();

            imgButton.ImageUrl = s_Url;
            imgButton.ToolTip = s_ToolTip;
            imgButton.Style.Add("cursor", "pointer");
            imgButton.ID = "imgAction" + "_" + s_OGID;
            imgButton.ClientIDMode = ClientIDMode.Static;
            imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_OPID + "',this,'" + s_Islocked + "')");
            imgButton.Click += new ImageClickEventHandler(historicalCost.imgButton_Click);
            return imgButton;

        }


        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~HCCommonModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}