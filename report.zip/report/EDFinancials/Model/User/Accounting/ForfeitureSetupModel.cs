﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Forfeiture Setup Model class
    /// </summary>
    public class ForfeitureSetupModel : BaseModel, IDisposable
    {
        #region Default Constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public ForfeitureSetupModel()
        {
            if (ac_ForfeitureSetup == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ForfeitureSetup);
                ac_ForfeitureSetup = (CommonModel.AC_ForfeitureSetup)HttpContext.Current.Session[CommonConstantModel.s_AC_ForfeitureSetup];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_CanNotEditFRSettingsMsg = string.Empty, s_BtnFRSSaveText = string.Empty, s_BtnFRSSaveToolTip = string.Empty, s_BtnFRSUpdateText = string.Empty, s_BtnFRSUpdateTooltip = string.Empty;

        #endregion

        #region Page Load Event

        /// <summary>
        /// Page Load event
        /// </summary>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        /// <param name="b_IsApprovalScreen">b_IsApprovalScreen</param>
        public void Page_Load(ForfeitureSetup forfeitureSetup, bool b_IsApprovalScreen)
        {
            try
            {
                BindUI(forfeitureSetup, b_IsApprovalScreen);
                EncryptData(forfeitureSetup);
                CheckEmployeeRolePriviledges(forfeitureSetup);
                BindAllFGControls(forfeitureSetup, "Page_Load", b_IsApprovalScreen);
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Method to check employee role privileges
        /// </summary>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        public void CheckEmployeeRolePriviledges(ForfeitureSetup forfeitureSetup)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuAccountingParameter;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                forfeitureSetup.ctrForfeitureGroupCreation.btnFCGAddNewGroup.Enabled = false;
                forfeitureSetup.ctrForfeitureGroupCreation.btnFGCFileUpload.Enabled = forfeitureSetup.ctrForfeitureGroupCreation.btnFGCSave.Enabled = forfeitureSetup.ctrForfeitureGroupCreation.hplFGCSelectEmployees.Enabled = false;
                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case CommonConstantModel.s_ADD:
                                    forfeitureSetup.ctrForfeitureGroupCreation.btnFCGAddNewGroup.Enabled = true;
                                    forfeitureSetup.ctrForfeitureGroupCreation.btnFGCFileUpload.Enabled = true;
                                    forfeitureSetup.ctrForfeitureGroupCreation.btnFGCSave.Enabled = true;
                                    forfeitureSetup.ctrForfeitureGroupCreation.hplFGCSelectEmployees.Enabled = true;
                                    break;

                                case CommonConstantModel.s_EDIT:
                                    forfeitureSetup.ctrForfeitureGroupCreation.btnFGCSave.Enabled = true;
                                    forfeitureSetup.ctrForfeitureGroupCreation.hplFGCSelectEmployees.Enabled = true;
                                    ac_ForfeitureSetup.b_IsEditRights = true;
                                    break;

                                case CommonConstantModel.s_DELETE:
                                    ac_ForfeitureSetup.b_IsDeleteRights = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Encrypt 
        /// </summary>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        internal void EncryptData(ForfeitureSetup forfeitureSetup)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                forfeitureSetup.hdnFGCSSRSQueryString.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=7").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("FGAID=0").Replace("+", "%2B"));
                forfeitureSetup.hdnFGCSSRSQueryString.Dispose();
                forfeitureSetup.ctrForfeitureRateCalc.hdnFRCSSRSReportID.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=8").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                forfeitureSetup.ctrForfeitureRateCalc.hdnFRCSSRSReportID.Dispose();
            }
        }

        /// <summary>
        /// This method is used to Bind UI
        /// </summary>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        /// <param name="b_IsApprovalScreen">b_IsApprovalScreen</param>
        private void BindUI(ForfeitureSetup forfeitureSetup, bool b_IsApprovalScreen)
        {
            try
            {
                ac_ForfeitureSetup.n_PageSize = 10;
                ac_ForfeitureSetup.n_PageIndex = 1;
                ac_ForfeitureSetup.n_GridViewRecordsCount = 0;
                ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit = string.Empty;

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_ForfeitureSetup.dt_ForfeitureSetupUI == null || ac_ForfeitureSetup.dt_ForfeitureSetupUI.Rows.Count.Equals(0))
                    {
                        ac_ForfeitureSetup.dt_ForfeitureSetupUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10_UI);
                    }
                    if ((ac_ForfeitureSetup.dt_ForfeitureSetupUI != null) && (ac_ForfeitureSetup.dt_ForfeitureSetupUI.Rows.Count > 0))
                    {
                        foreach (Control control in forfeitureSetup.divForefitureSetup.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_ForfeitureSetup.dt_ForfeitureSetupUI, (Label)control, null, null, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, (Button)control, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, null, null, (GridView)control, null);
                                    break;
                            }
                        }
                    }
                    SetValuesToStaticVariables();
                    forfeitureSetup.ctrForfeitureGroupCreation.lblFGCAddNewGroup.Text = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'lblFGCAddNewGroup'"))[0]["LabelName"]);
                    forfeitureSetup.ctrForfeitureGroupCreation.lblFGCApplFromDateEdit.Text = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'lblFGCApplFromDateEdit'"))[0]["LabelName"]);
                    s_CanNotEditFRSettingsMsg = accountingServiceClient.GetAccounting_L10N("lblFRSCanNotEditSettingsMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                    using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                    {
                        forfeitureGroupCreationModel.BindUI(forfeitureSetup.ctrForfeitureGroupCreation);
                    }
                    using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                    {
                        forfeitureRateSettingsModel.BindUI(forfeitureSetup.ctrForfeitureRateSettings, b_IsApprovalScreen);
                    }
                    using (ForfeitureRateCalcModel forfeitureRateCalcModel = new ForfeitureRateCalcModel())
                    {
                        forfeitureRateCalcModel.BindUI(forfeitureSetup.ctrForfeitureRateCalc, b_IsApprovalScreen);
                    }
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        /// <summary>
        ///  This method is used to set values to static variables
        /// </summary>
        public void SetValuesToStaticVariables()
        {
            s_BtnFRSSaveText = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'btnFRSSave'"))[0]["LabelName"]);
            s_BtnFRSSaveToolTip = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'btnFRSSave'"))[0]["LabelToolTip"]);
            s_BtnFRSUpdateText = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'btnFRSUpdate'"))[0]["LabelName"]);
            s_BtnFRSUpdateTooltip = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'btnFRSUpdate'"))[0]["LabelToolTip"]);
        }

        /// <summary>
        /// This method is used to bind all the controls
        /// </summary>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        /// <param name="s_Type">s_Type</param>
        /// <param name="b_IsApprovalScreen">b_IsApprovalScreen</param>
        private void BindAllFGControls(ForfeitureSetup forfeitureSetup, string s_Type, bool b_IsApprovalScreen)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    forfeitureGroupCreationModel.BindFGCControls(forfeitureSetup.ctrForfeitureGroupCreation, s_Type, false, b_IsApprovalScreen);
                }
                using (ForfeitureRateSettingsModel forfeitureRateSettingsModel = new ForfeitureRateSettingsModel())
                {
                    forfeitureRateSettingsModel.BindFRSControls(forfeitureSetup.ctrForfeitureRateSettings, s_Type, b_IsApprovalScreen);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        /// <summary>
        /// This method is used to show/hide success/error messages
        /// </summary>
        /// <param name="b_IsVisible">b_IsVisible</param>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        /// <param name="s_Type">s_Type</param>
        /// <param name="n_RetValue">n_RetValue</param>
        /// <param name="b_IsApprovalScreen">b_IsApprovalScreen</param>
        public void DisplayMessage(bool b_IsVisible, ForfeitureSetup forfeitureSetup, string s_Type, int n_RetValue, bool b_IsApprovalScreen)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    switch (s_Type)
                    {
                        case "FGC_FILE_UPLOAD":
                            forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "1";
                            forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "");
                            switch (n_RetValue)
                            {
                                case 1:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCFileUploadSuccessMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 2:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCSelectFileToUpload", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 3:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCFileDeleteSuccessMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 4:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCInvalidFileExtMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 5:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCFileSizeErrorMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                            }
                            break;
                        case "FGC":
                            switch (n_RetValue)
                            {
                                case 1:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCGroupCreateSuccessMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "0";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "none");
                                    if (userSessionInfo.ACC_UerTypeID.Equals(3))
                                    {
                                        SendMailForApproval("FGC_NEW", forfeitureSetup);
                                    }
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 2:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCGroupUpdateSuccessMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "0";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "none");
                                    if (userSessionInfo.ACC_UerTypeID.Equals(3))
                                    {
                                        SendMailForApproval("FGC_UPDATE", forfeitureSetup);
                                    }
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 3:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCGroupDeleteSuccessMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "0";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "none");
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 4:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCGroupAlreadyExistsMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "1";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "");
                                    RebindForfeitureGrids(forfeitureSetup, "FGC_ERROR", b_IsApprovalScreen);
                                    break;
                                case 5:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCDateCompareMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "1";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "");
                                    RebindForfeitureGrids(forfeitureSetup, "FGC_ERROR", b_IsApprovalScreen);
                                    break;
                                case 6:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCdissociateBeforeDeleteMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "0";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "none");
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 8:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCEmployeeAlreadyExistsMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "1";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "");
                                    RebindForfeitureGrids(forfeitureSetup, "FGC_ERROR", b_IsApprovalScreen);
                                    break;
                                case 9:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCEmpAlreadyExistsDate", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "1";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "");
                                    RebindForfeitureGrids(forfeitureSetup, "FGC_ERROR", b_IsApprovalScreen);
                                    break;
                                case 10:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCGroupPlzSelectEmp", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "1";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "");
                                    RebindForfeitureGrids(forfeitureSetup, "FGC_ERROR", b_IsApprovalScreen);
                                    break;
                                case 11:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCGroupPlzSelectApplFromEdit", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "1";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "");
                                    RebindForfeitureGrids(forfeitureSetup, "FGC_ERROR", b_IsApprovalScreen);
                                    break;
                                //This case is used to check if report is locked against given applicable date while saving the data.
                                case 12:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCantAddSaveAsLockAccRpt", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    break;

                                case 13:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCGroupPlzSelectEmp", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "1";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "");
                                    RebindForfeitureGrids(forfeitureSetup, "FGC_ERROR", b_IsApprovalScreen);
                                    break;
                            }
                            break;
                        case "FGC_APPROVAL":
                            switch (n_RetValue)
                            {
                                case 1:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCDisapprovedSuccessMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "0";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "none");
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 2:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFGCApprovedSuccessMsg", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.hdnFGCAccordionIndex.Value = "0";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "none");
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                            }
                            break;
                        case "FRS":
                            switch (n_RetValue)
                            {
                                case 1: forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFRSSaveMessage", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    if (userSessionInfo.ACC_UerTypeID.Equals(3))
                                    {
                                        SendMailForApproval("FRS", forfeitureSetup);
                                    }
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 2: forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFRSRecAlreadyExists", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 5: forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFRSCanNotEditSettings", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                //This case is used to check if report is locked against given applicable date while saving the data.
                                case 6:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFRSCantAddSaveAsLockAccRpt", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    break;

                                case 7:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFRSCantEditAsLockAccRpt", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    break;
                            }
                            break;
                        case "FRS_APPROVAL":
                            switch (n_RetValue)
                            {
                                case 1:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFRSConfigDisApprMessage", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "none");
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                                case 2:
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFRSConfigApproveMessage", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "none");
                                    RebindForfeitureGrids(forfeitureSetup, s_Type, b_IsApprovalScreen);
                                    break;
                            }
                            break;
                    }
                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        /// <summary>
        /// This method is used to clear message div
        /// </summary>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        public void ClearMessageDiv(ForfeitureSetup forfeitureSetup)
        {
            try
            {
                forfeitureSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        /// <summary>
        /// this method is used to rebind forfeiture grids on post-back
        /// </summary>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        /// <param name="s_Type">s_Type</param>
        /// <param name="b_IsApprovalPage">b_IsApprovalPage</param>
        public void RebindForfeitureGrids(ForfeitureSetup forfeitureSetup, string s_Type, bool b_IsApprovalPage)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    BindAllFGControls(forfeitureSetup, s_Type, b_IsApprovalPage);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        /// <summary>
        /// Close popup button click event
        /// </summary>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        public void btnFGCClosePopup_Click(ForfeitureSetup forfeitureSetup)
        {
            try
            {
                using (ForfeitureGroupCreationModel forfeitureGroupCreationModel = new ForfeitureGroupCreationModel())
                {
                    ClearMessageDiv(forfeitureSetup);
                    forfeitureSetup.ctrForfeitureGroupCreation.h3FGCHistory.Style.Add("display", "none");
                    if (!forfeitureSetup.hdnPopupType.Value.Equals("AddRemoveEmployeesIframe"))
                        forfeitureSetup.ctrForfeitureGroupCreation.h3FGCAddEdit.Style.Add("display", "none");
                    forfeitureSetup.hdnPopupType.Value = string.Empty;
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        /// <summary>
        /// THis method is used to trigger a mail to the reviewer
        /// </summary>
        /// <param name="s_Parameter"></param>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        public void SendMailForApproval(string s_Parameter, ForfeitureSetup forfeitureSetup)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_ForfeitureSetup.dt_ReviewerDetails = genericServiceClient.GetReviewerDetails(genericProperties);
                    string s_EmailIds = string.Empty;
                    if (ac_ForfeitureSetup.dt_ReviewerDetails.Rows.Count > 0)
                    {
                        int i = 0;
                        foreach (DataRow row in ac_ForfeitureSetup.dt_ReviewerDetails.Rows)
                        {
                            if (string.IsNullOrEmpty(s_EmailIds))
                                s_EmailIds = ac_ForfeitureSetup.dt_ReviewerDetails.Rows[i][0].ToString();
                            else s_EmailIds += ", " + ac_ForfeitureSetup.dt_ReviewerDetails.Rows[i][0].ToString();
                            i = i + 1;
                        }
                    }

                    emailProperties.s_MailBody = GetMailBody(s_Parameter, forfeitureSetup);
                    emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                    emailProperties.b_IsBodyHtml = true;
                    emailProperties.s_MailTo = s_EmailIds;
                    emailProperties.s_MailCC = "";
                    emailProperties.s_MailBCC = "";
                    emailProperties.s_MailSubject = GetMailSubject(s_Parameter, forfeitureSetup);
                    genericServiceClient.SaveSendMail(emailProperties);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Append parameters in MailBody
        /// </summary>
        /// <param name="s_Parameter">The parameters name</param>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        /// <returns>Mail body in for of string</returns>
        public string GetMailBody(string s_Parameter, ForfeitureSetup forfeitureSetup)
        {
            try
            {
                StringBuilder s_MailBody = new StringBuilder();
                switch (s_Parameter)
                {
                    case "FGC_NEW":
                        s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\ForftureGrpAddedMailAlert.html"));
                        s_MailBody.Replace("@GroupName", forfeitureSetup.ctrForfeitureGroupCreation.txtFGCGroupName.Text.Trim());
                        break;
                    case "FGC_UPDATE":
                        s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\ForftureGrpUpdatedMailAlert.html"));
                        s_MailBody.Replace("@GroupName", forfeitureSetup.ctrForfeitureGroupCreation.txtFGCGroupName.Text.Trim());
                        break;
                    case "FRS":
                        s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\ForftureRateConfigChngeMailAlert.html"));
                        break;
                }
                s_MailBody.Replace("@UserName", userSessionInfo.ACC_UserName);
                s_MailBody.Replace("@Company", userSessionInfo.ACC_CompanyTitle);
                s_MailBody.Replace("@Database", userSessionInfo.ACC_CompanyName);
                s_MailBody.Replace("@Link", ConfigurationManager.AppSettings["SiteURL"]);
                s_MailBody.Replace("@ValCustSupport", ConfigurationManager.AppSettings["ValCustSupport"]);
                return s_MailBody.ToString();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Append parameters in MailBody
        /// </summary>
        /// <param name="s_Parameter">s_Parameter - "FGC_NEW" : Forfeiture Group Creation , "FGC_UPDATE" - : Forfeiture Group update , "FRS" : Forfeiture Rate Settings</param>
        /// <param name="forfeitureSetup">ForfeitureSetup page object</param>
        /// <returns>Mail body in for of string</returns>
        public string GetMailSubject(string s_Parameter, ForfeitureSetup forfeitureSetup)
        {
            try
            {
                StringBuilder s_Subject = new StringBuilder();
                switch (s_Parameter)
                {
                    case "FGC_NEW": s_Subject.Append("@Company - New Forfeiture Group with name '" + forfeitureSetup.ctrForfeitureGroupCreation.txtFGCGroupName.Text.Trim() + "' has been created"); break;
                    case "FGC_UPDATE": s_Subject.Append("@Company - Change in Forfeiture Group : " + forfeitureSetup.ctrForfeitureGroupCreation.txtFGCGroupName.Text.Trim()); break;
                    case "FRS": s_Subject.Append("@Company - Change in Forfeiture Rate Settings"); break;
                }
                s_Subject.Replace("@Company", userSessionInfo.ACC_CompanyTitle);
                return s_Subject.ToString();
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Destructor
        /// <summary>
        /// Default Destructor
        /// </summary>
        ~ForfeitureSetupModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}