﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using System.Collections.Generic;
using System.Collections;
using System.Web.Services;
using System.IO;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Class file of Summary report
    /// </summary>
    public class AccSummaryWorkingsReportModel : BaseModel, IDisposable
    {
        #region Default constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public AccSummaryWorkingsReportModel()
        {
            if (ac_SummaryWorkings == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_AccSummaryWorkings);
                ac_SummaryWorkings = (CommonModel.AC_SummaryWorkings)HttpContext.Current.Session[CommonConstantModel.s_AC_AccSummaryWorkings];
            }
        }
        #endregion


        /// <summary>
        /// This method is used to Bind UI controls
        /// </summary>
        /// <param name="accSummaryWorkingsReport">AccSummaryWorkings Report page object</param>
        internal void BindUI(AccSummaryWorkingsReport accSummaryWorkingsReport)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_SummaryWorkings.dt_SummaryWorkingsUI == null || ac_SummaryWorkings.dt_SummaryWorkingsUI.Rows.Count.Equals(0))
                    {
                        ac_SummaryWorkings.dt_SummaryWorkingsUI = accountingServiceClient.GetAccounting_L10N_UI("AccSummaryReports", CommonConstantModel.s_AccountingL10_UI);
                    }

                    if ((ac_SummaryWorkings.dt_SummaryWorkingsUI != null) && (ac_SummaryWorkings.dt_SummaryWorkingsUI.Rows.Count > 0))
                    {
                        foreach (Control control in accSummaryWorkingsReport.dvMain.Controls)
                        {
                            BindUISwitchCase(control);
                        }
                        foreach (Control ctr in accSummaryWorkingsReport.divARHideShowAdvSearch.Controls)
                        {
                            BindUISwitchCase(ctr);
                        }

                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// this method is used  to bind control UI
        /// </summary>
        /// <param name="control">control</param>
        private void BindUISwitchCase(Control control)
        {
            switch (control.GetType().FullName.ToUpper())
            {
                case CommonConstantModel.s_wcLabel:
                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_SummaryWorkings.dt_SummaryWorkingsUI, (Label)control, null, null, null, null, null, null, null, null, null);
                    break;

                case CommonConstantModel.s_wcButton:
                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_SummaryWorkings.dt_SummaryWorkingsUI, null, null, (Button)control, null, null, null, null, null, null, null);
                    break;

                case CommonConstantModel.s_wcGridview:
                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_SummaryWorkings.dt_SummaryWorkingsUI, null, null, null, null, null, null, null, null, (GridView)control, null);
                    break;

                case CommonConstantModel.s_wcRequiredFieldValidator:
                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, ac_SummaryWorkings.dt_SummaryWorkingsUI, null, null, null, null, null, (BaseValidator)control, null, null, null, null);
                    break;

                case CommonConstantModel.s_wcRugularExpressionValidator:
                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, ac_SummaryWorkings.dt_SummaryWorkingsUI, null, null, null, null, null, null, (BaseValidator)control, null, null, null);
                    break;

            }
        }


        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="accSummaryWorkingsReport">The accSummaryWorkingsReport Page object</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="label">The label control object</param>
        /// <param name="textBox">The text-box control object</param>
        /// <param name="button">The button control object</param>
        /// <param name="checkBox">The CheckBox control object</param>
        /// <param name="radioButton">radiobutton control object</param>
        /// <param name="ReqValidator">validator control object</param>
        /// <param name="RegExpValidator">validator control object</param>
        /// <param name="gridView">gridview control object</param>
        private void BindPropertiesToControl(string s_cntrlType, AccSummaryWorkingsReport accSummaryWorkingsReport, DataTable Dt_Get_L10N_UI, Label label, TextBox textBox, Button button, CheckBox checkBox, RadioButton radioButton, BaseValidator ReqValidator, BaseValidator RegExpValidator, GridView gridView)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeCheckBox:
                    checkBox.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelName"]);
                    checkBox.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRadioButton:
                    radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                    radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    gridView.EmptyDataText = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + gridView.ID + "'"))[0]["LabelName"]);
                    break;

                case CommonConstantModel.s_cntrlTypeTextBox:
                    break;
            }
        }

        #region Bind Controls
        /// <summary>
        /// This method is used to Bind Data to dropdowns
        /// </summary>
        /// <param name="accSummaryWorkingsReport">accSummary Workings Report page object</param>
        /// <param name="s_ReportingDate">Reporting Date object</param>
        internal void BindControls(AccSummaryWorkingsReport accSummaryWorkingsReport, string s_ReportingDate)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "GET_SUMMARY_WORKINGS_FILTERS";
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.REPORTING_DATE = string.Empty;
                    accountingProperties.Type = "FILTERS";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_SummaryWorkings.ds_SummaryWorkings = accountingCRUDProperties.ds_Result;
                    if (ac_SummaryWorkings.ds_SummaryWorkings != null && ac_SummaryWorkings.ds_SummaryWorkings.Tables.Count > 0)
                    {
                        accSummaryWorkingsReport.ddlARFinancialYrFrom.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[0].AsEnumerable()
                                                                                    where b.Field<string>("FINC_YEAR") != null
                                                                                    select b.Field<string>("FINC_YEAR")).Distinct();
                        accSummaryWorkingsReport.ddlARFinancialYrFrom.DataBind();
                        accSummaryWorkingsReport.ddlARFinancialYrFrom.Items.Insert(0, "--- Please Select ---");

                        accSummaryWorkingsReport.ddlARFinancialYrTo.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[0].AsEnumerable()
                                                                                  where b.Field<string>("FINC_YEAR") != null
                                                                                  select b.Field<string>("FINC_YEAR")).Distinct();
                        accSummaryWorkingsReport.ddlARFinancialYrTo.DataBind();
                        accSummaryWorkingsReport.ddlARFinancialYrTo.Items.Insert(0, "--- Please Select ---");

                        accSummaryWorkingsReport.ddlARFinancialQrFrom.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[0].AsEnumerable()
                                                                                    where b.Field<string>("FINC_QUARTER") != null
                                                                                    select b.Field<string>("FINC_QUARTER")).Distinct();
                        accSummaryWorkingsReport.ddlARFinancialQrFrom.DataBind();
                        accSummaryWorkingsReport.ddlARFinancialQrFrom.Items.Insert(0, "--- Please Select ---");

                        accSummaryWorkingsReport.ddlARFinancialQrTo.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[0].AsEnumerable()
                                                                                  where b.Field<string>("FINC_QUARTER") != null
                                                                                  select b.Field<string>("FINC_QUARTER")).Distinct();
                        accSummaryWorkingsReport.ddlARFinancialQrTo.DataBind();
                        accSummaryWorkingsReport.ddlARFinancialQrTo.Items.Insert(0, "--- Please Select ---");

                        accSummaryWorkingsReport.ddlARFinancialMonthFrom.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[1].AsEnumerable()
                                                                                       where b.Field<string>("PARAM") != null
                                                                                       select b.Field<string>("PARAM")).Distinct();
                        accSummaryWorkingsReport.ddlARFinancialMonthFrom.DataBind();
                        accSummaryWorkingsReport.ddlARFinancialMonthFrom.Items.Insert(0, "--- Please Select ---");

                        accSummaryWorkingsReport.ddlARFinancialMonthTo.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[1].AsEnumerable()
                                                                                     where b.Field<string>("PARAM") != null
                                                                                     select b.Field<string>("PARAM")).Distinct();
                        accSummaryWorkingsReport.ddlARFinancialMonthTo.DataBind();
                        accSummaryWorkingsReport.ddlARFinancialMonthTo.Items.Insert(0, "--- Please Select ---");

                        //Bind lEVEL1 drop-down 
                        accSummaryWorkingsReport.ddlMultiSelectLevel1.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[2].AsEnumerable()
                                                                                    where b.Field<string>("FIELD_NAME") != null
                                                                                    select b.Field<string>("FIELD_NAME")).Distinct();
                        accSummaryWorkingsReport.ddlMultiSelectLevel1.DataBind();
                        accSummaryWorkingsReport.ddlMultiSelectLevel1.Items.Insert(0, "--- Please Select ---");


                        accSummaryWorkingsReport.rdoARMarketPriceType.Items.FindByValue("FV").Selected = ac_SummaryWorkings.ds_SummaryWorkings != null && ac_SummaryWorkings.ds_SummaryWorkings.Tables[3] != null && ac_SummaryWorkings.ds_SummaryWorkings.Tables[3].Rows.Count > 0 && (ac_SummaryWorkings.ds_SummaryWorkings.Tables[3].Rows[0]["VAL_METHOD"].ToString().Equals("rdbVMCC03") || ac_SummaryWorkings.ds_SummaryWorkings.Tables[3].Rows[0]["VAL_METHOD"].ToString().Equals("rdbVMCC02"));
                        accSummaryWorkingsReport.rdoARMarketPriceType.Items.FindByValue("IV").Selected = !accSummaryWorkingsReport.rdoARMarketPriceType.Items.FindByValue("FV").Selected;

                    }
                    accSummaryWorkingsReport.txtARDate.Text = s_ReportingDate;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method id Used to bind conditional gridview
        /// </summary>
        /// <param name="accSummaryWorkingsReport">AccSummaryWorkingsReport Page Object</param>
        /// <param name="s_CID">Control Id Object</param>
        /// <param name="s_Level_1">s_Level_1 Object</param>
        /// <param name="s_Level_2">s_Level_2 Object</param>
        /// <param name="s_Level_3"> s_Level_3 Object</param>
        /// <param name="s_Level_4">s_Level_4 Object</param>
        internal void GetData(AccSummaryWorkingsReport accSummaryWorkingsReport, string s_CID, string s_Level_1, string s_Level_2, string s_Level_3, string s_Level_4)
        {
            DataTable dt = new DataTable("DT");
            accSummaryWorkingsReport.gvARMainReport.DataSource = dt;
            accSummaryWorkingsReport.gvARMainReport.DataBind();
            ac_SummaryWorkings.s_Scheme = string.Empty;

            switch (s_CID)
            {
                case "ddlMultiSelectLevel1":
                    accSummaryWorkingsReport.ddlMultiSelectLevel2.Items.Clear();
                    accSummaryWorkingsReport.ddlMultiSelectLevel2.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[2].AsEnumerable()
                                                                                where b.Field<string>("FIELD_NAME") != s_Level_1
                                                                                select b.Field<string>("FIELD_NAME")).Distinct();
                    accSummaryWorkingsReport.ddlMultiSelectLevel2.DataBind();
                    accSummaryWorkingsReport.ddlMultiSelectLevel2.Items.Insert(0, "--- Please Select ---");

                    break;

                case "ddlMultiSelectLevel2":
                    accSummaryWorkingsReport.ddlMultiSelectLevel3.Items.Clear();
                    accSummaryWorkingsReport.ddlMultiSelectLevel3.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[2].AsEnumerable()
                                                                                where (b.Field<string>("FIELD_NAME") != accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedItem.Text && b.Field<string>("FIELD_NAME") != s_Level_2)
                                                                                select b.Field<string>("FIELD_NAME")).Distinct();
                    accSummaryWorkingsReport.ddlMultiSelectLevel3.DataBind();
                    accSummaryWorkingsReport.ddlMultiSelectLevel3.Items.Insert(0, "--- Please Select ---");

                    break;

                case "ddlMultiSelectLevel3":
                    accSummaryWorkingsReport.ddlMultiSelectLevel4.Items.Clear();
                    accSummaryWorkingsReport.ddlMultiSelectLevel4.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[2].AsEnumerable()
                                                                                where (b.Field<string>("FIELD_NAME") != accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedItem.Text && b.Field<string>("FIELD_NAME") != accSummaryWorkingsReport.ddlMultiSelectLevel2.SelectedItem.Text && b.Field<string>("FIELD_NAME") != accSummaryWorkingsReport.ddlMultiSelectLevel3.SelectedItem.Text)
                                                                                select b.Field<string>("FIELD_NAME")).Distinct();
                    accSummaryWorkingsReport.ddlMultiSelectLevel4.DataBind();
                    accSummaryWorkingsReport.ddlMultiSelectLevel4.Items.Insert(0, "--- Please Select ---");

                    break;

                case "ddlMultiSelectLevel4":
                    accSummaryWorkingsReport.ddlMultiSelectLevel5.Items.Clear();
                    accSummaryWorkingsReport.ddlMultiSelectLevel5.DataSource = (from b in ac_SummaryWorkings.ds_SummaryWorkings.Tables[2].AsEnumerable()
                                                                                where (b.Field<string>("FIELD_NAME") != accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedItem.Text && b.Field<string>("FIELD_NAME") != accSummaryWorkingsReport.ddlMultiSelectLevel2.SelectedItem.Text
                                                                                && b.Field<string>("FIELD_NAME") != accSummaryWorkingsReport.ddlMultiSelectLevel3.SelectedItem.Text && b.Field<string>("FIELD_NAME") != accSummaryWorkingsReport.ddlMultiSelectLevel4.SelectedItem.Text)
                                                                                select b.Field<string>("FIELD_NAME")).Distinct();
                    accSummaryWorkingsReport.ddlMultiSelectLevel5.DataBind();
                    accSummaryWorkingsReport.ddlMultiSelectLevel5.Items.Insert(0, "--- Please Select ---");

                    break;

            }

        }


        /// <summary>
        /// This method is used to filter the grid data
        /// </summary>
        /// <param name="accSummaryWorkingsReport">AccSummaryWorkingsReport Page Object</param>
        internal void FilterGridData(AccSummaryWorkingsReport accSummaryWorkingsReport)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_AccountingReport;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "SUMMARY_REPORT";
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.REPORTING_DATE = accSummaryWorkingsReport.txtARDate.Text;
                    accountingProperties.MARKET_PRICE_TYPE = accSummaryWorkingsReport.rdoARMarketPriceType.SelectedItem.Text;
                    accountingProperties.DISPLAY_COST_FOR = accSummaryWorkingsReport.rdoARDisplayCostFor.SelectedItem.Value;
                    switch (accSummaryWorkingsReport.rdoARDisplayCostFor.SelectedItem.Value.Trim())
                    {
                        case "Y":
                            if (!accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                accountingProperties.COST_FOR_FYNC_YR_FROM = accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Text;
                            if (!accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                accountingProperties.COST_FOR_FYNC_YR_TO = accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Text;
                            break;
                        case "Q":
                            if (!accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                            {
                                accountingProperties.COST_FOR_FYNC_YR_FROM = accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                if (!accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_QTR_FROM = accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Text;
                            }
                            if (!accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                            {
                                accountingProperties.COST_FOR_FYNC_YR_TO = accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Text;
                                if (!accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_QTR_TO = accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Text;
                            }
                            break;
                        case "M":
                            if (!accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                            {
                                accountingProperties.COST_FOR_FYNC_YR_FROM = accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Text;
                                if (!accSummaryWorkingsReport.ddlARFinancialMonthFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialMonthFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_MONTH_FROM = accSummaryWorkingsReport.ddlARFinancialMonthFrom.SelectedItem.Text;
                            }
                            if (!accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                            {
                                accountingProperties.COST_FOR_FYNC_YR_TO = accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Text;
                                if (!accSummaryWorkingsReport.ddlARFinancialMonthTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialMonthTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                    accountingProperties.COST_FOR_FYNC_MONTH_TO = accSummaryWorkingsReport.ddlARFinancialMonthTo.SelectedItem.Text;
                            }
                            break;
                    }

                    accountingProperties.DISPLAY_COST_BEFORE = accSummaryWorkingsReport.rdoARDisplayCostBefore.SelectedItem.Value;
                    accountingProperties.DISPLAY_COST_AFTER = accSummaryWorkingsReport.rdoARDisplayCostAfter.SelectedItem.Value;
                    accountingProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                    accountingProperties.CALCULATION_METHOD = userSessionInfo.ACC_CalculationMethod;
                    accountingProperties.LEVEL_1 = !(accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedItem.Text.Equals("--- Please Select ---") || (accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedIndex.Equals(-1))) ? accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedItem.Text : string.Empty;
                    accountingProperties.LEVEL_2 = !(accSummaryWorkingsReport.ddlMultiSelectLevel2.SelectedIndex.Equals(-1) || (accSummaryWorkingsReport.ddlMultiSelectLevel2.SelectedItem.Text.Equals("--- Please Select ---"))) ? accSummaryWorkingsReport.ddlMultiSelectLevel2.SelectedItem.Text : string.Empty;
                    accountingProperties.LEVEL_3 = !((accSummaryWorkingsReport.ddlMultiSelectLevel3.SelectedIndex.Equals(-1)) || accSummaryWorkingsReport.ddlMultiSelectLevel3.SelectedItem.Text.Equals("--- Please Select ---")) ? accSummaryWorkingsReport.ddlMultiSelectLevel3.SelectedItem.Text : string.Empty;
                    accountingProperties.LEVEL_4 = !((accSummaryWorkingsReport.ddlMultiSelectLevel4.SelectedIndex.Equals(-1)) || accSummaryWorkingsReport.ddlMultiSelectLevel4.SelectedItem.Text.Equals("--- Please Select ---")) ? accSummaryWorkingsReport.ddlMultiSelectLevel4.SelectedItem.Text : string.Empty;
                    accountingProperties.LEVEL_5 = !((accSummaryWorkingsReport.ddlMultiSelectLevel5.SelectedIndex.Equals(-1)) || accSummaryWorkingsReport.ddlMultiSelectLevel5.SelectedItem.Text.Equals("--- Please Select ---")) ? accSummaryWorkingsReport.ddlMultiSelectLevel5.SelectedItem.Text : string.Empty;
                    ac_SummaryWorkings.ds_ReportDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                    if (ac_SummaryWorkings.ds_ReportDetails != null && ac_SummaryWorkings.ds_ReportDetails.Tables[1].Rows.Count > 0 || ac_SummaryWorkings.ds_ReportDetails.Tables[0].Rows.Count > 0)
                    {
                        ac_SummaryWorkings.dt_MainReport = ac_SummaryWorkings.ds_ReportDetails.Tables[1];
                        ac_SummaryWorkings.dt_MainReportDetails = ac_SummaryWorkings.ds_ReportDetails.Tables[0];

                        if (ac_SummaryWorkings.dt_MainReportDetails.Rows.Count > 0)
                        {
                            ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("OPTION_ID");
                            ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("GRANT_OPTION_ID");
                            ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("VPD_VESTING_PERIOD_ID");
                            ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("SCH_SCHEME_TITLE");
                            ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("LEVEL1_APPLICABLE_FROM");
                            ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("LEVEL1_APPLICABLE_TO");
                            ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("UNVESTED");
                            ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("EMPID");
                            if (!accountingProperties.LEVEL_2.Equals(string.Empty))
                            {
                                ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("LEVEL2_APPLICABLE_FROM");
                                ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("LEVEL2_APPLICABLE_TO");
                            }
                            else if (!accountingProperties.LEVEL_3.Equals(string.Empty))
                            {
                                ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("LEVEL3_APPLICABLE_FROM");
                                ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("LEVEL3_APPLICABLE_TO");
                            }
                            else if (!accountingProperties.LEVEL_4.Equals(string.Empty))
                            {
                                ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("LEVEL4_APPLICABLE_FROM");
                                ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("LEVEL4_APPLICABLE_TO");
                            }
                            else if (!accountingProperties.LEVEL_5.Equals(string.Empty))
                            {
                                ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("LEVEL5_APPLICABLE_FROM");
                                ac_SummaryWorkings.dt_MainReportDetails.Columns.Remove("LEVEL5_APPLICABLE_TO");
                            }
                            ac_SummaryWorkings.dt_MainReportDetails.Columns["LEVEL_1"].ColumnName = !accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedItem.Text.Equals("--- Please Select ---") ? accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedItem.Text : "LEVEL_1";
                            ac_SummaryWorkings.dt_MainReportDetails.AcceptChanges();
                        }
                        if (ac_SummaryWorkings.ds_ReportDetails.Tables[1].Rows.Count > 0)
                        {
                            ac_SummaryWorkings.dt_MainReport.Columns["LEVEL_1"].ColumnName = !accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedItem.Text.Equals("--- Please Select ---") ? accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedItem.Text : "LEVEL_1";
                            accSummaryWorkingsReport.divARReportSection.Style.Add("display", "");
                            accSummaryWorkingsReport.divAREmptyRow.Style.Add("display", "none");
                        }
                        else
                        {
                            accSummaryWorkingsReport.divARReportSection.Style.Add("display", "none");
                            accSummaryWorkingsReport.divAREmptyRow.Style.Add("display", "");
                        }
                        ac_SummaryWorkings.n_RowCount = ac_SummaryWorkings.dt_MainReport.Columns.Count;
                        accSummaryWorkingsReport.gvARMainReport.DataSource = ac_SummaryWorkings.dt_MainReport;
                        accSummaryWorkingsReport.gvARMainReport.DataBind();
                    }
                    else
                    {
                        accSummaryWorkingsReport.gvARMainReport.DataSource = new DataTable();
                        accSummaryWorkingsReport.gvARMainReport.DataBind();
                        accSummaryWorkingsReport.divARReportSection.Style.Add("display", "block");
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion



        /// <summary>
        ///  Page Index change event of Gridview
        /// </summary>
        /// <param name="accSummaryWorkingsReport">AccSummaryWorkingsReport Page Object</param>
        /// <param name="e">event args object</param>
        internal void gvARMainReport_PageIndexChanging(AccSummaryWorkingsReport accSummaryWorkingsReport, GridViewPageEventArgs e)
        {
            try
            {
                accSummaryWorkingsReport.gvARMainReport.PageIndex = e.NewPageIndex;
                accSummaryWorkingsReport.gvARMainReport.DataSource = ac_SummaryWorkings.dt_MainReport;
                accSummaryWorkingsReport.gvARMainReport.DataBind();
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// This method is used customize grid header
        /// </summary>
        /// <param name="gridView">gridView</param>
        /// <param name="gridRow">gridRow</param>
        /// <param name="headerLevels">headerLevels</param>
        /// <param name="accSummaryWorkingsReport">accSummaryWorkingsReport page object</param>
        /// <param name="s_GridID">s_GridID</param>
        /// <param name="e">event args object</param>
        /// <param name="n_SR_Index">n_SR_Index object</param>
        /// <param name="ht_SchemeWIse">hashtable object</param>
        /// <param name="n_MergeRowCount">n_MergeRowCount object</param>
        public void CustomizeGridHeader(GridView gridView, GridViewRow gridRow, int headerLevels, AccSummaryWorkingsReport accSummaryWorkingsReport, string s_GridID, GridViewRowEventArgs e, ref int n_SR_Index, ref Hashtable ht_SchemeWIse, ref int n_MergeRowCount)
        {
            n_MergeRowCount = 1;
            switch (gridRow.RowType)
            {
                case DataControlRowType.Header:
                    #region Customize Header
                    for (int item = 1; item <= headerLevels; item++)
                    {
                        //creating new header row
                        GridViewRow gridviewRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
                        IEnumerable<System.Linq.IGrouping<string, string>> gridHeaders = null;
                        int n_Count = 0;
                        //reading existing header 
                        gridHeaders = gridRow.Cells.Cast<TableCell>()
                                    .Select(cell => GetHeaderText(cell.Text, item))
                                    .GroupBy(headerText => headerText);
                        foreach (var header in gridHeaders)
                        {
                            if (header.Key.ToString().Contains('|') || header.Key.ToString().Contains("split"))
                            {
                                n_Count = n_Count + 1;
                                goto nextLoop;
                            }
                        }

                    nextLoop:
                        foreach (var header in gridHeaders)
                        {
                            using (TableHeaderCell cell = new TableHeaderCell())
                            {
                                cell.Text = header.Key.ToString();
                                cell.Visible = !(cell.Text.Equals("AGRMID") || cell.Text.Equals("OPT_VEST_ID") || cell.Text.Contains("OPT_GRANTED_ID")
                                    || cell.Text.Contains("COST_SUM") || cell.Text.Contains("TOTAL_COST") || cell.Text.Contains("GRANT_OPTION_ID")
                                    || cell.Text.Contains("VPD_VESTING_PERIOD_ID") || cell.Text.Contains("SCH_SCHEME_TITLE"));

                                if (item == 2)
                                {
                                    if (!cell.Text.Contains("split"))
                                        goto nextHeader;
                                    cell.Text = header.Key.Substring(header.Key.LastIndexOf(CommonConstantModel.s_seperator) + 1);
                                }
                                else
                                {
                                    if (cell.Text.Contains("split"))
                                    {
                                        cell.Text = cell.Text.Replace("split", "");
                                        if (cell.Text.Contains("IV_FV Parameters"))
                                            cell.ColumnSpan = 5;
                                        else if (cell.Text.Contains("OP_") || cell.Text.Contains("QO_"))
                                            cell.ColumnSpan = 3;
                                        else if (cell.Text.Contains("Q_") && accSummaryWorkingsReport.rdoARDisplayCostFor.SelectedItem.Value.Equals("Q"))
                                        {
                                            if (!accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---") && !accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---")
                                               && !accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---") && !accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---")
                                               && accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Trim().Equals(accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Trim()))
                                            {
                                                cell.ColumnSpan = (Convert.ToInt32(accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Trim().ToUpper().Replace("QUARTER ", ""))
                                                    - Convert.ToInt32(accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Trim().ToUpper().Replace("QUARTER ", ""))) + 2;
                                            }
                                            else
                                            {
                                                if (!accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---") && !accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                                {
                                                    switch (accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Trim().ToUpper())
                                                    {
                                                        case "QUARTER 1": cell.ColumnSpan = 5; break;
                                                        case "QUARTER 2": cell.ColumnSpan = 4; break;
                                                        case "QUARTER 3": cell.ColumnSpan = 3; break;
                                                        case "QUARTER 4": cell.ColumnSpan = 2; break;
                                                    }
                                                }
                                                if (!accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---") && !accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                                {
                                                    switch (accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Trim().ToUpper())
                                                    {
                                                        case "QUARTER 1": cell.ColumnSpan = 2; break;
                                                        case "QUARTER 2": cell.ColumnSpan = 3; break;
                                                        case "QUARTER 3": cell.ColumnSpan = 4; break;
                                                        case "QUARTER 4": cell.ColumnSpan = 5; break;
                                                    }
                                                }
                                                else cell.ColumnSpan = 5;
                                            }
                                        }
                                        else if (cell.Text.Contains("Q_") && accSummaryWorkingsReport.rdoARDisplayCostFor.SelectedItem.Value.Equals("M"))
                                            cell.ColumnSpan = 13;
                                        else if (accSummaryWorkingsReport.rdoARDisplayCostFor.SelectedItem.Value.Equals("Q"))
                                        {
                                            if (!accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---") && !accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---")
                                                && !accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---") && !accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---")
                                                && accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Trim().Equals(accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Trim()))
                                            {
                                                cell.ColumnSpan = (Convert.ToInt32(accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Trim().ToUpper().Replace("QUARTER ", ""))
                                                    - Convert.ToInt32(accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Trim().ToUpper().Replace("QUARTER ", ""))) + 1;
                                            }
                                            else
                                            {
                                                if (!accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrFrom.SelectedItem.Value.Equals("--- Please Select ---") && !accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Equals("--- Please Select ---"))
                                                {
                                                    switch (accSummaryWorkingsReport.ddlARFinancialQrFrom.SelectedItem.Value.Trim().ToUpper())
                                                    {
                                                        case "QUARTER 1": cell.ColumnSpan = 4; break;
                                                        case "QUARTER 2": cell.ColumnSpan = 3; break;
                                                        case "QUARTER 3": cell.ColumnSpan = 2; break;
                                                        case "QUARTER 4": cell.ColumnSpan = 1; break;
                                                    }
                                                }
                                                if (!accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialYrTo.SelectedItem.Value.Equals("--- Please Select ---") && !accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("0") && !accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Equals("--- Please Select ---"))
                                                {
                                                    switch (accSummaryWorkingsReport.ddlARFinancialQrTo.SelectedItem.Value.Trim().ToUpper())
                                                    {
                                                        case "QUARTER 1": cell.ColumnSpan = 1; break;
                                                        case "QUARTER 2": cell.ColumnSpan = 2; break;
                                                        case "QUARTER 3": cell.ColumnSpan = 3; break;
                                                        case "QUARTER 4": cell.ColumnSpan = 4; break;
                                                    }
                                                }
                                                else cell.ColumnSpan = 4;
                                            }
                                        }
                                        else if (accSummaryWorkingsReport.rdoARDisplayCostFor.SelectedItem.Value.Equals("M"))
                                            cell.ColumnSpan = 12;
                                        else cell.ColumnSpan = 2;
                                    }
                                    else if (n_Count <= 0)
                                        cell.RowSpan = 1;
                                    else cell.RowSpan = 2;
                                }
                                gridviewRow.Cells.Add(cell);
                                // Adding new header to the grid
                                gridView.Controls[0].Controls.AddAt(gridRow.RowIndex, gridviewRow);
                                if (cell.Text.Contains("IV_FV"))
                                {
                                    if (accSummaryWorkingsReport.rdoARMarketPriceType.SelectedItem.Value.Equals("IV"))
                                        cell.Text = cell.Text.Replace("IV_FV", "Intrinsic Value");
                                    else cell.Text = cell.Text.Replace("IV_FV", "Fair Value");
                                }

                                if (cell.Text.Contains("OP_Cost"))
                                    cell.Text = cell.Text.Replace("OP_Cost", "Options");
                                if (cell.Text.Contains("QO_Cost"))
                                    cell.Text = cell.Text.Replace("QO_Cost", "Options");
                                if (cell.Text.Contains("OP_"))
                                    cell.Text = cell.Text.Replace("OP_", "");
                                if (cell.Text.Contains("QO_"))
                                    cell.Text = cell.Text.Replace("QO_", "");
                                if (cell.Text.Contains("Q_"))
                                    cell.Text = cell.Text.Replace("Q_", "");
                                cell.HorizontalAlign = HorizontalAlign.Center;
                            }
                        nextHeader: ;
                        }
                    }
                    //hiding existing header
                    gridRow.Visible = false;
                    #endregion


                    if (gridView.ID.Equals("gvARMainReport"))
                    {
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {

                            switch (perColumn.Text.ToUpper())
                            {
                                case "SCHEME NAME":
                                    ht_SchemeWIse["n_SR_Scheme"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                            }
                            n_SR_Index = n_SR_Index + 1;
                        }
                    }

                    break;

                case DataControlRowType.DataRow:
                    e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme"]))].HorizontalAlign = HorizontalAlign.Center;
                    if (gridView.ID.Equals("gvARMainReport") && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme"]))].Text.Trim()) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme"]))].Text.Trim().Equals("&nbsp;"))
                    {
                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme"]))].Controls.Add(AddLinkButton(accSummaryWorkingsReport, e.Row.Cells[0].Text));
                        if (e.Row.RowIndex > 0)
                        {
                            int RowIndex = 1, Count = 1;
                            MergeCells(accSummaryWorkingsReport.gvARMainReport, e, Convert.ToInt32(ht_SchemeWIse["n_SR_Scheme"]), ref RowIndex, ref Count, ref n_MergeRowCount);
                        }
                    }
                    else
                    {
                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Scheme"]))].Controls.Add(AddLinkButton(accSummaryWorkingsReport, e.Row.Cells[0].Text));
                        //  MergeRows(gridView);
                    }

                    #region Below code does decimal rounding , Thousand separating and aligns to the right.
                    using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                    {
                        switch (s_GridID)
                        {
                            case "gvARMainReport":
                                int n_Place = 0;
                                n_Place = !(accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedItem.Text.Equals("--- Please Select ---") || (accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedIndex.Equals(-1))) ?
                                           !(accSummaryWorkingsReport.ddlMultiSelectLevel2.SelectedItem.Text.Equals("--- Please Select ---") || (accSummaryWorkingsReport.ddlMultiSelectLevel2.SelectedIndex.Equals(-1))) ?
                                           !(accSummaryWorkingsReport.ddlMultiSelectLevel3.SelectedItem.Text.Equals("--- Please Select ---") || (accSummaryWorkingsReport.ddlMultiSelectLevel3.SelectedIndex.Equals(-1))) ?
                                           !(accSummaryWorkingsReport.ddlMultiSelectLevel4.SelectedItem.Text.Equals("--- Please Select ---") || (accSummaryWorkingsReport.ddlMultiSelectLevel4.SelectedIndex.Equals(-1))) ?
                                           !(accSummaryWorkingsReport.ddlMultiSelectLevel5.SelectedItem.Text.Equals("--- Please Select ---") || (accSummaryWorkingsReport.ddlMultiSelectLevel5.SelectedIndex.Equals(-1))) ?
                                           6 : 5 : 4 : 3 : 2 : 3;


                                if (ac_SummaryWorkings.n_RowCount > gridRow.Cells.Count)
                                {
                                    n_Place = n_Place - 1;
                                }
                                for (int n_CellCount = n_Place; n_CellCount < gridRow.Cells.Count; n_CellCount++)
                                {
                                    if (!string.IsNullOrEmpty(Convert.ToString(gridRow.Cells[n_CellCount].Text)) && !Convert.ToString(gridRow.Cells[n_CellCount].Text).Equals("&nbsp;"))
                                    {
                                        gridRow.Cells[n_CellCount].Text = Convert.ToDouble(gridRow.Cells[n_CellCount].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(gridRow.Cells[n_CellCount].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(gridRow.Cells[n_CellCount].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                    }
                                }
                                break;
                        }
                    }
                    #endregion
                    break;
            }
        }

        /// <summary>
        /// Add link button
        /// </summary>
        /// <param name="accSummaryWorkingsReport">this is accSummaryWorkingsReport page object</param>
        /// <param name="s_GRID">Gridview ID</param>
        /// <returns></returns>
        private LinkButton AddLinkButton(AccSummaryWorkingsReport accSummaryWorkingsReport, string s_GRID)
        {
            try
            {
                LinkButton linkButton = new LinkButton();
                linkButton.ToolTip = "Click here to view vestwise details";
                linkButton.Text = s_GRID;
                linkButton.ID = "lbtnViewDetails";
                linkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                linkButton.Style.Add("cursor", "pointer");

                if (!string.IsNullOrEmpty(s_GRID))
                {
                    linkButton.Attributes.Add("onclick", "return ShowDetails(this)");
                }
                return linkButton;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This function is used to get link button object
        /// </summary>
        /// <param name="s_ControlText">s_ControlText</param>
        /// <param name="s_ControlTooltip">s_ControlTooltip</param>
        /// <param name="s_ControlID">s_ControlID</param>
        /// <param name="s_ACC_RPT_GROUP_ID">s_ACC_RPT_GROUP_ID</param>
        /// <param name="s_ReportName">s_ReportName</param>
        /// <param name="s_VersionNumber">s_VersionNumber</param>
        /// <returns>return link button control object</returns>
        private LinkButton AddLinkButton(string s_ControlText, string s_ControlTooltip, string s_ControlID, string s_ACC_RPT_GROUP_ID, string s_ReportName, string s_VersionNumber)
        {
            try
            {
                using (LinkButton linkButton = new LinkButton())
                {

                    linkButton.Attributes.Add("style", "cursor:pointer;padding:5px;color: blue; text-decoration: underline;");
                    linkButton.Text = s_ControlText;
                    linkButton.ClientIDMode = ClientIDMode.Static;
                    linkButton.ID = s_ControlID;
                    if (s_ControlID.Equals("lbtnAREditAndView"))
                        linkButton.ToolTip = "Click here to Edit." + Environment.NewLine + "Grant(s) : " + s_ControlTooltip;
                    else linkButton.ToolTip = s_ControlTooltip;
                    linkButton.Attributes.Add("onclick", "return OpenModalDialog('" + s_ControlText + "','" + s_ACC_RPT_GROUP_ID + "','" + s_ControlID + "','" + s_ReportName + "','" + s_VersionNumber + "')");
                    return linkButton;
                }
            }
            catch
            {
                throw;
            }
        }



        /// <summary>
        /// Method returns header text
        /// </summary>
        /// <param name="headerText">headerText</param>
        /// <param name="headerLevel">headerLevel</param>
        /// <returns>returns header text</returns>
        public string GetHeaderText(string headerText, int headerLevel)
        {
            if (headerLevel == 2)
            {
                return headerText;
            }
            if (headerText.LastIndexOf(CommonConstantModel.s_seperator) > 0)
                return headerText.Substring(0, headerText.LastIndexOf(CommonConstantModel.s_seperator));
            else return headerText;
        }

        /// <summary>
        /// This Method is used to add Child Gridview at Runtime
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="e">event args's object</param>
        /// <param name="n_SR_Index">n_SR_Index index num</param>
        /// <param name="accSummaryWorkingsReport">AccSummaryWorkingsReport Page Object</param>
        /// <param name="S_Path">Path file name</param>
        /// <param name="s_SchemeName">Parameter for Scheme Name</param>
        /// <param name="n_rowIndex">Parameter for grid view row index</param>
        /// <param name="n_MergeRowCount">MergeRowCount Object</param>
        internal void AddChildGrid(object sender, GridViewRowEventArgs e, ref int n_SR_Index, AccSummaryWorkingsReport accSummaryWorkingsReport, string S_Path, string s_SchemeName, ref int n_rowIndex, ref int n_MergeRowCount)
        {
            try
            {
                //if (!ac_SummaryWorkings.s_Scheme.Equals(s_SchemeName))
                //{
                    GridView parentGrid = (GridView)sender;
                    ac_SummaryWorkings.s_Scheme = s_SchemeName;

                    using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                    {
                        NewTotalRow.Font.Bold = true;
                        NewTotalRow.CssClass = "gridItems  gvChildGrid";
                        NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                        using (TableCell HeaderCell = new TableCell())
                        {
                            HeaderCell.Attributes.Add("Class", "gvChildGrid");
                            HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                            HeaderCell.Height = 10;
                            HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                            HeaderCell.ColumnSpan = 20;
                            using (GridView childGrid = new GridView())
                            {
                                childGrid.CssClass = "Grid";
                                childGrid.RowStyle.CssClass = "gridItems";
                                childGrid.CellPadding = 3;
                                childGrid.CellSpacing = 0;
                                childGrid.HeaderStyle.CssClass = "HeaderStyle";
                                childGrid.ID = "childGrid_" + n_rowIndex;
                                childGrid.RowDataBound += accSummaryWorkingsReport.childGrid_RowDataBound;
                                childGrid.DataSource = ac_SummaryWorkings.dt_MainReportDetails.Select("[Scheme Name]= '" + s_SchemeName + "'").CopyToDataTable();
                                childGrid.DataBind();
                                ResetHashValues(accSummaryWorkingsReport.ht_SchemeWIse, accSummaryWorkingsReport);

                                HeaderCell.Controls.Add(childGrid);
                                NewTotalRow.Cells.Add(HeaderCell);
                                parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + (n_MergeRowCount > 1 ? ((n_MergeRowCount - 1) + 1) : (n_MergeRowCount + 1)) + n_rowIndex, NewTotalRow);
                                n_rowIndex++;

                            }
                        }
                    //}
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Child Gridview Row data bound event
        /// </summary>
        /// <param name="sender">sender's object</param>
        /// <param name="accSummaryWorkingsReport">AccSummaryWorkingsReport Page Object</param>
        /// <param name="e">event Args object</param>
        /// <param name="n_SR_Index">n_SR_Index object</param>
        /// <param name="ht_SchemeWIse">hashtable object</param>
        internal void childGrid_RowDataBound(object sender, AccSummaryWorkingsReport accSummaryWorkingsReport, GridViewRowEventArgs e, ref int n_SR_Index, ref Hashtable ht_SchemeWIse)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {

                            switch (perColumn.Text.ToUpper())
                            {
                                case "SCHEME NAME":
                                    ht_SchemeWIse["n_SR_Scheme_Name"] = n_SR_Index;
                                    break;

                                case "AGRMID":
                                    ht_SchemeWIse["n_SR_AGRMID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPT_VEST_ID":
                                    ht_SchemeWIse["n_SR_OPT_VEST_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPT_GRANTED_ID":
                                    ht_SchemeWIse["n_SR_OPT_GRANTED_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPTION_ID":
                                    ht_SchemeWIse["n_SR_OPTION_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "EMPLOYEE ID":
                                    ht_SchemeWIse["n_SR_Employee_ID"] = n_SR_Index;
                                    break;

                                case "EMPLOYEE NAME":
                                    ht_SchemeWIse["n_SR_Employee_Name"] = n_SR_Index;
                                    break;

                                case "CURRENCY":
                                    ht_SchemeWIse["n_SR_Currency"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "RATE APPLIED":
                                    ht_SchemeWIse["n_SR_RATE_APPLIED"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "FORFEITURE GROUP":
                                    ht_SchemeWIse["n_SR_FORFEITURE_GROUP"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "GRANT REGISTRATION ID":
                                    ht_SchemeWIse["n_SR_Grant_Reg_ID"] = n_SR_Index;
                                    break;

                                case "GRANT OPTION ID":
                                    ht_SchemeWIse["n_SR_GrantOptionID"] = n_SR_Index;
                                    break;

                                case "GRANT DATE":
                                    ht_SchemeWIse["n_SR_Grant_Date"] = n_SR_Index;
                                    break;

                                case "GRADE":
                                    ht_SchemeWIse["n_SR_Grade"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "DESIGNATION":
                                    ht_SchemeWIse["n_SR_Designation"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "SENIOR MANAGEMENT":
                                    ht_SchemeWIse["n_SR_Senior_Management"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IV_FV":
                                    ht_SchemeWIse["n_SR_IV_FV"] = n_SR_Index;
                                    break;

                                case "IV_FV PARAMETERS SPLIT |MARKET PRICE":
                                    ht_SchemeWIse["n_SR_IVP_MP"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IV_FV PARAMETERS SPLIT |EXPECTED LIFE":
                                    ht_SchemeWIse["n_SR_IVP_EL"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IV_FV PARAMETERS SPLIT |VOLATILITY":
                                    ht_SchemeWIse["n_SR_IVP_VOL"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IV_FV PARAMETERS SPLIT |DIVIDEND":
                                    ht_SchemeWIse["n_SR_IVP_DIV"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IV_FV PARAMETERS SPLIT |RFIR":
                                    ht_SchemeWIse["n_SR_IVP_RFIR"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IV_FV PARAMETERS VALUES SPLIT |MARKET PRICE":
                                    ht_SchemeWIse["n_SR_IVPV_MP"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IV_FV PARAMETERS VALUES SPLIT |EXPECTED LIFE":
                                    ht_SchemeWIse["n_SR_IVPV_EL"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IV_FV PARAMETERS VALUES SPLIT |VOLATILITY (%)":
                                    ht_SchemeWIse["n_SR_IVPV_VOL"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IV_FV PARAMETERS VALUES SPLIT |DIVIDEND (%)":
                                    ht_SchemeWIse["n_SR_IVPV_DIV"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "IV_FV PARAMETERS VALUES SPLIT |RFIR (%)":
                                    ht_SchemeWIse["n_SR_IVPV_RFIR"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "DATE OF JOINING":
                                    ht_SchemeWIse["n_SR_DATE_OF_JOINING"] = n_SR_Index;
                                    break;

                                case "VEST ID":
                                    ht_SchemeWIse["n_SR_VestID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "VEST DATE":
                                    ht_SchemeWIse["n_SR_VEST_DATE"] = n_SR_Index;
                                    break;

                                case "VEST %":
                                    ht_SchemeWIse["n_SR_VEST_PERC"] = n_SR_Index;
                                    break;


                                case "OPTIONS GRANTED":
                                    ht_SchemeWIse["n_SR_OPTIONS_GRANTED"] = n_SR_Index;
                                    break;

                                case "OPTIONS VESTED CANCELLED":
                                    ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"] = n_SR_Index;
                                    break;

                                case "OPTIONS UNVESTED CANCELLED":
                                    ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"] = n_SR_Index;
                                    break;

                                case "OPTIONS LAPSED":
                                    ht_SchemeWIse["n_SR_OPTIONS_LAPSED"] = n_SR_Index;
                                    break;

                                case "VESTED AND EXERCISABLE OPTIONS":
                                    ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"] = n_SR_Index;
                                    break;

                                case "UNVESTED OPTIONS":
                                    ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"] = n_SR_Index;
                                    break;

                                case "OUTSTANDING OPTIONS":
                                    ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"] = n_SR_Index;
                                    break;

                                case "EXERCISED OPTIONS":
                                    ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"] = n_SR_Index;
                                    break;

                                case "LIVE OPTIONS FOR COMPENSATION COST":
                                    ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"] = n_SR_Index;
                                    break;

                                case "ACCLELARATED OPTIONS":
                                    ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACCELERATED VESTING DATE":
                                    ht_SchemeWIse["n_SR_ACCELERATED_VESTING_DATE"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "FORFEITURE RATE":
                                    ht_SchemeWIse["n_SR_FORFEITURE_RATE"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPTIONS LIKELY TO BE FORFEITED":
                                    ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"] = n_SR_Index;
                                    break;

                                case "NET OPTIONS FOR COMPENSATION COST":
                                    ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"] = n_SR_Index;
                                    break;

                                case "IV_FV POST CORPORATE ACTION / MODIFICATION / CHANGE IN ESTIMATED DATE OF LISTING":
                                    ht_SchemeWIse["n_SR_Fair_Value_post_Corporate_Action_Modification"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "EXERCISE PRICE POST CORPORATE ACTION / MODIFICATION":
                                    ht_SchemeWIse["n_SR_Exercise_price_Modification"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "EXERCISE PRICE":
                                    ht_SchemeWIse["n_SR_EERCISE_PRICE"] = n_SR_Index;
                                    break;

                                case "EXERCISEPRICE POST CORPORATE ACTION / MODIFICATION":
                                    ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "TOTAL COMPENSATION COST":
                                    ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"] = n_SR_Index;
                                    break;

                                case "COST_SUM":
                                    ht_SchemeWIse["n_SR_COST_SUM"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "TOTAL_COST":
                                    ht_SchemeWIse["n_SR_TOTAL_COST"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "GRANT_OPTION_ID":
                                    ht_SchemeWIse["n_SR_GRANT_OPTION_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "SCH_SCHEME_TITLE1":
                                    ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE1"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "SCH_SCHEME_TITLE":
                                    ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "VPD_VESTING_PERIOD_ID":
                                    ht_SchemeWIse["n_SR_VPD_VESTING_PERIOD_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "OP_VESTING_PERIOD_ID":
                                    ht_SchemeWIse["n_SR_OP_VESTING_PERIOD_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "VESTING_PERIOD_ID":
                                    ht_SchemeWIse["n_SR_VESTING_PERIOD_ID"] = n_SR_Index;
                                    perColumn.Visible = false;
                                    break;


                            }
                            n_SR_Index = n_SR_Index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        GridView parentGrid = (GridView)sender;
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPT_VEST_ID"])))
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPT_VEST_ID"]))].Visible = false;
                        if ((!userSessionInfo.ACC_IsEmpAccess))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Employee_ID"]))].Text = "";
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_Employee_Name"]))].Text = "";
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].Text = Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].Text).ToString("dd/MMM/yyyy");
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_DATE"]))].HorizontalAlign = HorizontalAlign.Center;
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_VEST_PERC"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_PERC"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_PERC"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VEST_PERC"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"]))].HorizontalAlign = HorizontalAlign.Right;
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"]))].HorizontalAlign = HorizontalAlign.Right;
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_EERCISE_PRICE"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EERCISE_PRICE"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EERCISE_PRICE"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_EERCISE_PRICE"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_IV_FV"]))].HorizontalAlign = HorizontalAlign.Right;
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])) && !string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"]))].Text) && !e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"]))].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"]))].HorizontalAlign = HorizontalAlign.Right;
                        }

                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_AGRMID"]))].Visible = e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_OPT_GRANTED_ID"]))].Visible = false;
                        e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_COST_SUM"]))].Visible =
                            e.Row.Cells[Convert.ToInt32(Convert.ToString(ht_SchemeWIse["n_SR_TOTAL_COST"]))].Visible = false;


                        // MergeRows(parentGrid);

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_GRANTED"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LAPSED"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"])].Text, "0");
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"])].Text, "0");
                            }
                            //for (int n_Index = Convert.ToInt32(ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE1"]) + 1; n_Index < Convert.ToInt32(ht_SchemeWIse["n_SR_ViewWorkings"]); n_Index++)
                            //{
                            //    if (!string.IsNullOrEmpty(e.Row.Cells[n_Index].Text) && !e.Row.Cells[n_Index].Text.Equals("&nbsp;"))
                            //    {
                            //        e.Row.Cells[n_Index].Text = Convert.ToDouble(e.Row.Cells[n_Index].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Index].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[n_Index].Text, "0");
                            //    }
                            //}

                            /* FV, IV, Exercise Price decimal rounding , Thousand separating */
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EERCISE_PRICE"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EERCISE_PRICE"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EERCISE_PRICE"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EERCISE_PRICE"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EERCISE_PRICE"])].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EERCISE_PRICE"])].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_Exercise_price_Modification"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_Exercise_price_Modification"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_Exercise_price_Modification"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_Exercise_price_Modification"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_Exercise_price_Modification"])].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_Exercise_price_Modification"])].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION"])].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION"])].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            /* Market Price, Expected Life, Volatility, Dividend, RFIR decimal rounding , Thousand separating */
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text, DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_MP"])].Text, DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text, DecimalLimitTable.Select("ADVSID = 5")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 5")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_EL"])].Text, DecimalLimitTable.Select("ADVSID = 5")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text, DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_VOL"])].Text, DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text, DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_RFIR"])].Text, DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text, DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IVPV_DIV"])].Text, DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            /* Compensation Cost decimal rounding , Thousand separating */
                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"])].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            if (!string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text) && !e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(ht_SchemeWIse["n_SR_IV_FV"])].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            for (int n_Index = Convert.ToInt32(ht_SchemeWIse["n_SR_TOTAL_COST"]) + 1; n_Index < Convert.ToInt32(ht_SchemeWIse["n_SR_OP_OPTION_ID"]); n_Index++)
                            {
                                if (!string.IsNullOrEmpty(e.Row.Cells[n_Index].Text) && !e.Row.Cells[n_Index].Text.Equals("&nbsp;"))
                                {
                                    e.Row.Cells[n_Index].Text = Convert.ToDouble(e.Row.Cells[n_Index].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Index].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Index].Text, DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                }
                            }
                        }
                        #endregion
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to create hash-table of int parameters 
        /// </summary>
        /// <param name="ht_SchemeWIse">Hash-table object</param>
        internal void CreateHashTable(Hashtable ht_SchemeWIse)
        {
            try
            {
                /* Scheme wise report hash-table initialization - Start */
                ht_SchemeWIse.Add("n_SR_Scheme", 0);
                ht_SchemeWIse.Add("n_SR_Scheme_Name", 0);
                ht_SchemeWIse.Add("n_SR_AGRMID", 0);
                ht_SchemeWIse.Add("n_SR_OPT_VEST_ID", 0);
                ht_SchemeWIse.Add("n_SR_OP_OPTION_ID", 0);
                ht_SchemeWIse.Add("n_SR_OPT_GRANTED_ID", 0);
                ht_SchemeWIse.Add("n_SR_OPTION_ID", 0);
                ht_SchemeWIse.Add("n_SR_Grant_Date", 0);
                ht_SchemeWIse.Add("n_SR_Grade", 0);
                ht_SchemeWIse.Add("n_SR_Designation", 0);
                ht_SchemeWIse.Add("n_SR_Senior_Management", 0);
                ht_SchemeWIse.Add("n_SR_DATE_OF_JOINING", 0);
                ht_SchemeWIse.Add("n_SR_IVP_MP", 0);
                ht_SchemeWIse.Add("n_SR_IVP_EL", 0);
                ht_SchemeWIse.Add("n_SR_IVP_VOL", 0);
                ht_SchemeWIse.Add("n_SR_IVP_DIV", 0);
                ht_SchemeWIse.Add("n_SR_IVP_RFIR", 0);
                ht_SchemeWIse.Add("n_SR_IVPV_MP", 0);
                ht_SchemeWIse.Add("n_SR_IVPV_EL", 0);
                ht_SchemeWIse.Add("n_SR_IVPV_VOL", 0);
                ht_SchemeWIse.Add("n_SR_IVPV_DIV", 0);
                ht_SchemeWIse.Add("n_SR_IVPV_RFIR", 0);
                ht_SchemeWIse.Add("n_SR_VestingDetails", 0);
                ht_SchemeWIse.Add("n_SR_ViewWorkings", 0);
                ht_SchemeWIse.Add("n_SR_GrantOptionID", 0);
                ht_SchemeWIse.Add("n_SR_Employee_ID", 0);
                ht_SchemeWIse.Add("n_SR_Employee_Name", 0);
                ht_SchemeWIse.Add("n_SR_Currency", 0);
                ht_SchemeWIse.Add("n_SR_IV_FV", 0);
                ht_SchemeWIse.Add("n_SR_VEST_DATE", 0);
                ht_SchemeWIse.Add("n_SR_VEST_PERC", 0);
                ht_SchemeWIse.Add("n_SR_OPTIONS_GRANTED", 0);
                ht_SchemeWIse.Add("n_SR_OPTIONS_VESTED_CANCELLED", 0);
                ht_SchemeWIse.Add("n_SR_OPTIONS_UNVESTED_CANCELLED", 0);
                ht_SchemeWIse.Add("n_SR_OPTIONS_LAPSED", 0);
                ht_SchemeWIse.Add("n_SR_VESTED_EXERCISABLE_OPTIONS", 0);
                ht_SchemeWIse.Add("n_SR_UNVESTED_OPTIONS", 0);
                ht_SchemeWIse.Add("n_SR_OUTSTANDING_OPTIONS", 0);
                ht_SchemeWIse.Add("n_SR_EXERCISED_OPTIONS", 0);
                ht_SchemeWIse.Add("n_SR_LIVE_OPTIONS_FOR_COMP_COST", 0);
                ht_SchemeWIse.Add("n_SR_ACCLELARATED_OPTIONS", 0);
                ht_SchemeWIse.Add("n_SR_ACCELERATED_VESTING_DATE", 0);
                ht_SchemeWIse.Add("n_SR_FORFEITURE_RATE", 0);
                ht_SchemeWIse.Add("n_SR_RATE_APPLIED", 0);
                ht_SchemeWIse.Add("n_SR_FORFEITURE_GROUP", 0);
                ht_SchemeWIse.Add("n_SR_OPTIONS_LIKELY_TOBE_FORFEITED", 0);
                ht_SchemeWIse.Add("n_SR_NET_OPTIONS_FOR_COMP_COST", 0);
                ht_SchemeWIse.Add("n_SR_Exercise_price_Modification", 0);
                ht_SchemeWIse.Add("n_SR_EERCISE_PRICE", 0);
                ht_SchemeWIse.Add("n_SR_EXERCISEPRICE_POST_CORP_ACTION", 0);
                ht_SchemeWIse.Add("n_SR_TOTAL_COMPENSATION_COST", 0);
                ht_SchemeWIse.Add("n_SR_COST_SUM", 0);
                ht_SchemeWIse.Add("n_SR_TOTAL_COST", 0);
                ht_SchemeWIse.Add("n_SR_GRANT_OPTION_ID", 0);
                ht_SchemeWIse.Add("n_SR_SCH_SCHEME_TITLE", 0);
                ht_SchemeWIse.Add("n_SR_SCH_SCHEME_TITLE1", 0);
                ht_SchemeWIse.Add("n_SR_OP_VESTING_PERIOD_ID", 0);
                ht_SchemeWIse.Add("n_SR_VPD_VESTING_PERIOD_ID", 0);
                ht_SchemeWIse.Add("n_SR_VESTING_PERIOD_ID", 0);
                ht_SchemeWIse.Add("n_LEVEL1", 0);
                /* Scheme wise report hash-table initialization - End */
            }
            catch
            {
                throw;
            }
        }

        #region Reset Hash Table values
        /// <summary>
        /// This method is used to reset values of Dictionary
        /// </summary>
        /// <param name="ht_SchemeWIse">Hash table object</param>
        /// <param name="accSummaryWorkingsReport">accSummaryWorkingsReport page object</param>
        private void ResetHashValues(Hashtable ht_SchemeWIse, AccSummaryWorkingsReport accSummaryWorkingsReport)
        {
            ht_SchemeWIse["n_SR_Scheme"] = 0;
            ht_SchemeWIse["n_SR_Scheme_Name"] = 0;
            ht_SchemeWIse["n_SR_AGRMID"] = 0;
            ht_SchemeWIse["n_SR_OPT_VEST_ID"] = 0;
            ht_SchemeWIse["n_SR_OP_OPTION_ID"] = 0;
            ht_SchemeWIse["n_SR_OPT_GRANTED_ID"] = 0;
            ht_SchemeWIse["n_SR_OPTION_ID"] = 0;
            ht_SchemeWIse["n_SR_Grant_Date"] = 0;
            ht_SchemeWIse["n_SR_Grade"] = 0;
            ht_SchemeWIse["n_SR_Designation"] = 0;
            ht_SchemeWIse["n_SR_Senior_Management"] = 0;
            ht_SchemeWIse["n_SR_DATE_OF_JOINING"] = 0;
            ht_SchemeWIse["n_SR_IVP_MP"] = 0;
            ht_SchemeWIse["n_SR_IVP_EL"] = 0;
            ht_SchemeWIse["n_SR_IVP_VOL"] = 0;
            ht_SchemeWIse["n_SR_IVP_DIV"] = 0;
            ht_SchemeWIse["n_SR_IVP_RFIR"] = 0;
            ht_SchemeWIse["n_SR_IVPV_MP"] = 0;
            ht_SchemeWIse["n_SR_IVPV_EL"] = 0;
            ht_SchemeWIse["n_SR_IVPV_VOL"] = 0;
            ht_SchemeWIse["n_SR_IVPV_DIV"] = 0;
            ht_SchemeWIse["n_SR_IVPV_RFIR"] = 0;
            ht_SchemeWIse["n_SR_VestingDetails"] = 0;
            ht_SchemeWIse["n_SR_ViewWorkings"] = 0;
            ht_SchemeWIse["n_SR_GrantOptionID"] = 0;
            ht_SchemeWIse["n_SR_Employee_ID"] = 0;
            ht_SchemeWIse["n_SR_Employee_Name"] = 0;
            ht_SchemeWIse["n_SR_Currency"] = 0;
            ht_SchemeWIse["n_SR_IV_FV"] = 0;
            ht_SchemeWIse["n_SR_VEST_DATE"] = 0;
            ht_SchemeWIse["n_SR_VEST_PERC"] = 0;
            ht_SchemeWIse["n_SR_OPTIONS_GRANTED"] = 0;
            ht_SchemeWIse["n_SR_OPTIONS_VESTED_CANCELLED"] = 0;
            ht_SchemeWIse["n_SR_OPTIONS_UNVESTED_CANCELLED"] = 0;
            ht_SchemeWIse["n_SR_OPTIONS_LAPSED"] = 0;
            ht_SchemeWIse["n_SR_VESTED_EXERCISABLE_OPTIONS"] = 0;
            ht_SchemeWIse["n_SR_UNVESTED_OPTIONS"] = 0;
            ht_SchemeWIse["n_SR_OUTSTANDING_OPTIONS"] = 0;
            ht_SchemeWIse["n_SR_EXERCISED_OPTIONS"] = 0;
            ht_SchemeWIse["n_SR_LIVE_OPTIONS_FOR_COMP_COST"] = 0;
            ht_SchemeWIse["n_SR_ACCLELARATED_OPTIONS"] = 0;
            ht_SchemeWIse["n_SR_ACCELERATED_VESTING_DATE"] = 0;
            ht_SchemeWIse["n_SR_FORFEITURE_RATE"] = 0;
            ht_SchemeWIse["n_SR_RATE_APPLIED"] = 0;
            ht_SchemeWIse["n_SR_FORFEITURE_GROUP"] = 0;
            ht_SchemeWIse["n_SR_OPTIONS_LIKELY_TOBE_FORFEITED"] = 0;
            ht_SchemeWIse["n_SR_NET_OPTIONS_FOR_COMP_COST"] = 0;
            ht_SchemeWIse["n_SR_Exercise_price_Modification"] = 0;
            ht_SchemeWIse["n_SR_EERCISE_PRICE"] = 0;
            ht_SchemeWIse["n_SR_EXERCISEPRICE_POST_CORP_ACTION"] = 0;
            ht_SchemeWIse["n_SR_TOTAL_COMPENSATION_COST"] = 0;
            ht_SchemeWIse["n_SR_COST_SUM"] = 0;
            ht_SchemeWIse["n_SR_TOTAL_COST"] = 0;
            ht_SchemeWIse["n_SR_GRANT_OPTION_ID"] = 0;
            ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE"] = 0;
            ht_SchemeWIse["n_SR_SCH_SCHEME_TITLE1"] = 0;
            ht_SchemeWIse["n_SR_OP_VESTING_PERIOD_ID"] = 0;
            ht_SchemeWIse["n_SR_VPD_VESTING_PERIOD_ID"] = 0;
            ht_SchemeWIse["n_SR_VESTING_PERIOD_ID"] = 0;
            accSummaryWorkingsReport.n_CSR_Index = 0;
            accSummaryWorkingsReport.n_SR_Index = 0;

        }
        #endregion

        /// <summary>
        /// This method is used to merge cells
        /// </summary>
        /// <param name="gridView">Gridview object</param>
        /// <param name="e">event args object</param>
        /// <param name="n_SR_Scheme">scheme Name object</param>
        /// <param name="RowIndex">rowindex object</param>
        /// <param name="Count">int count object</param>
        /// <param name="n_MergeRowCount">MergeRowCount object</param>
        private void MergeCells(GridView gridView, GridViewRowEventArgs e, int n_SR_Scheme, ref int RowIndex, ref int Count, ref int n_MergeRowCount)
        {
            for (int intLoop = 1; intLoop <= e.Row.RowIndex; intLoop++)
            {
                Count++;
                if ((!gridView.Rows[e.Row.RowIndex - intLoop].Cells[n_SR_Scheme].Text.Equals(string.Empty)) && (e.Row.Cells[n_SR_Scheme].Text == gridView.Rows[e.Row.RowIndex - intLoop].Cells[n_SR_Scheme].Text))
                {
                    RowIndex = intLoop;
                    break;
                }
            }

            if (e.Row.Cells[n_SR_Scheme].Text == gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_Scheme].Text)
            {
                e.Row.Cells[n_SR_Scheme].Text = "";

                e.Row.Cells[n_SR_Scheme].Visible = false;

                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_SR_Scheme].RowSpan = Count;

                n_MergeRowCount = Count;
            }
        }


        /// <summary>
        /// This method is used to Merge The Rows In GridView.
        /// </summary>
        /// <param name="gvARMainReport">GridView gvARMainReport object</param>
        public static void MergeRows(GridView gvARMainReport)
        {
            for (int rowIndex = gvARMainReport.Rows.Count - 2; rowIndex >= 0; rowIndex--)
            {
                GridViewRow row = gvARMainReport.Rows[rowIndex];
                GridViewRow previousRow = gvARMainReport.Rows[rowIndex + 1];

                for (int i = 0; i < row.Cells.Count; i++)
                {
                    // if (!row.Cells[i].Text.Equals("0") && !row.Cells[i].Text.Equals("1"))
                    {
                        if ((row.Cells[i].Text == previousRow.Cells[i].Text) && (!row.Cells[i].Text.Equals("&nbsp;")))
                        {
                            row.Cells[i].RowSpan = previousRow.Cells[i].RowSpan < 2 ? 2 :
                                                   previousRow.Cells[i].RowSpan + 1;
                            previousRow.Cells[i].Visible = false;
                        }
                    }
                }
            }
        }

        ///// <summary>
        ///// This method is used to export the date to excel
        ///// </summary>
        //internal void ExportGridToExcel(AccSummaryWorkingsReport accSummaryWorkingsReport)
        //{

        //    HttpContext.Current.Response.Clear();
        //    HttpContext.Current.Response.Buffer = true;
        //    HttpContext.Current.Response.ClearContent();
        //    HttpContext.Current.Response.ClearHeaders();
        //    HttpContext.Current.Response.Charset = "";
        //    string FileName = "Vithal" + DateTime.Now + ".xls";
        //    StringWriter strwritter = new StringWriter();
        //    HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
        //    HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        //    HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
        //    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
        //    accSummaryWorkingsReport.gvARMainReport.GridLines = GridLines.Both;
        //    accSummaryWorkingsReport.gvARMainReport.HeaderStyle.Font.Bold = true;
        //    accSummaryWorkingsReport.gvARMainReport.RenderControl(htmltextwrtter);
        //    HttpContext.Current.Response.Write(strwritter.ToString());
        //    HttpContext.Current.Response.End();
        //}

        internal void ClearControls(AccSummaryWorkingsReport accSummaryWorkingsReport)
        {
            accSummaryWorkingsReport.txtARDate.Text = Convert.ToDateTime(DateTime.Now).ToString("dd/MMM/yyyy");
            accSummaryWorkingsReport.ddlMultiSelectLevel1.SelectedIndex = -1;

            accSummaryWorkingsReport.rdoARMarketPriceType.Items.FindByValue("FV").Selected = ac_SummaryWorkings.ds_SummaryWorkings != null && ac_SummaryWorkings.ds_SummaryWorkings.Tables[3] != null && ac_SummaryWorkings.ds_SummaryWorkings.Tables[3].Rows.Count > 0 && (ac_SummaryWorkings.ds_SummaryWorkings.Tables[3].Rows[0]["VAL_METHOD"].ToString().Equals("rdbVMCC03") || ac_SummaryWorkings.ds_SummaryWorkings.Tables[3].Rows[0]["VAL_METHOD"].ToString().Equals("rdbVMCC02"));
            accSummaryWorkingsReport.rdoARMarketPriceType.Items.FindByValue("IV").Selected = !accSummaryWorkingsReport.rdoARMarketPriceType.Items.FindByValue("FV").Selected;

        }
        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~AccSummaryWorkingsReportModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}