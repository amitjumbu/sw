﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting.UserControl;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// 
    /// </summary>
    public class ForfeitureRateCalcModel : BaseModel, IDisposable
    {
        #region Default Constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public ForfeitureRateCalcModel()
        {
            if (ac_ForfeitureSetup == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ForfeitureSetup);
                ac_ForfeitureSetup = (CommonModel.AC_ForfeitureSetup)HttpContext.Current.Session[CommonConstantModel.s_AC_ForfeitureSetup];
            }
        }
        #endregion

        #region Methods

        /// <summary>
        /// This method is used to bind UI
        /// </summary>
        /// <param name="forfeitureRateCalculationsUC">ForfeitureRateSettings page object</param>
        /// <param name="b_IsApprovalScreen">b_IsApprovalScreen</param>
        public void BindUI(ForfeitureRateCalculationsUC forfeitureRateCalculationsUC, bool b_IsApprovalScreen)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_ForfeitureSetup.dt_ForfeitureSetupUI == null || ac_ForfeitureSetup.dt_ForfeitureSetupUI.Rows.Count.Equals(0))
                    {
                        ac_ForfeitureSetup.dt_ForfeitureSetupUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10_UI);
                    }
                    if ((ac_ForfeitureSetup.dt_ForfeitureSetupUI != null) && (ac_ForfeitureSetup.dt_ForfeitureSetupUI.Rows.Count > 0))
                    {
                        foreach (Control control in forfeitureRateCalculationsUC.divForfeitureRateCalculations.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_ForfeitureSetup.dt_ForfeitureSetupUI, (Label)control, null, null, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, (TextBox)control, null, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, (Button)control, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcCheckbox:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeCheckBox, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, (CheckBox)control, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, (BaseValidator)control, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, (BaseValidator)control, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, null, null, (GridView)control, null);
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Destructor
        /// <summary>
        /// Default Destructor
        /// </summary>
        ~ForfeitureRateCalcModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}