﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Tracking Details Model Class.
    /// </summary>
    public class TrackingDetailsModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public TrackingDetailsModel()
        {
            if (ac_TrackingDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_TrackingDetails);
                ac_TrackingDetails = (CommonModel.AC_TrackingDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_TrackingDetails];
            }
        }

        /// <summary>
        /// This method loads the initial settings and data required for the page.
        /// </summary>
        /// <param name="trackingDetails">trackingDetails page object</param>
        public void LoadInitialSettings(TrackingDetails trackingDetails)
        {
            try
            {
                CheckEmployeeRolePriviledges(trackingDetails);
                BindUI(trackingDetails);
                LoadGridData(trackingDetails);
                Load_ddTD_SelectTrackingType(trackingDetails);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Enables or disables control according to roles assigned to user.
        /// </summary>
        /// <param name="trackingDetails">trackingDetails page</param>
        internal void CheckEmployeeRolePriviledges(TrackingDetails trackingDetails)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnutrackingDetails;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    break;

                                case "ADD":
                                    trackingDetails.btnTD_AddNew.Enabled = true;
                                    trackingDetails.btnTD_Submit.Enabled = true;
                                    break;

                                case "DELETE":
                                    trackingDetails.btnTD_Delete.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to bind UI text to the tracking Details page.
        /// </summary>
        /// <param name="trackingDetails">trackingDetails page object</param>
        internal void BindUI(TrackingDetails trackingDetails)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                try
                {
                    ac_TrackingDetails.dt_Tracking_detailsUIText = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_TrackingDetails, CommonConstantModel.s_AccountingL10_UI);
                    if ((ac_TrackingDetails.dt_Tracking_detailsUIText != null) && (ac_TrackingDetails.dt_Tracking_detailsUIText.Rows.Count > 0))
                    {
                        foreach (Control control in trackingDetails.dvMain.Controls)
                        {
                            var a = (control.GetType().FullName.ToUpper());
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, trackingDetails, ac_TrackingDetails.dt_Tracking_detailsUIText, (Label)control, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, trackingDetails, ac_TrackingDetails.dt_Tracking_detailsUIText, null, (TextBox)control, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, trackingDetails, ac_TrackingDetails.dt_Tracking_detailsUIText, null, null, (Button)control, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, trackingDetails, ac_TrackingDetails.dt_Tracking_detailsUIText, null, null, null, null, (RadioButton)control, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, trackingDetails, ac_TrackingDetails.dt_Tracking_detailsUIText, null, null, null, null, null, (BaseValidator)control, null, null);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, trackingDetails, ac_TrackingDetails.dt_Tracking_detailsUIText, null, null, null, null, null, null, (BaseValidator)control, null);
                                    break;

                                case CommonConstantModel.s_wcRangeValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, trackingDetails, ac_TrackingDetails.dt_Tracking_detailsUIText, null, null, null, null, null, null, (BaseValidator)control, null);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, trackingDetails, ac_TrackingDetails.dt_Tracking_detailsUIText, null, null, null, null, null, null, null, (GridView)control);
                                    break;
                            }

                        }
                        trackingDetails.lblTD_AccordEditHead.Text = Convert.ToString((ac_TrackingDetails.dt_Tracking_detailsUIText.Select("LabelID='lblTD_AccordEditHead'"))[0]["LabelName"]);

                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="trackingDetails">The trackingDetails page object</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="label">The label control object</param>
        /// <param name="textBox">The text-box control object</param>
        /// <param name="button">The button control object</param>
        /// <param name="checkBox">The CheckBox control object</param>
        /// <param name="radioButton">radiobutton control object</param>
        /// <param name="ReqValidator">validator control object</param>
        /// <param name="RegExpValidator">validator control object</param>
        /// <param name="gridView">gridview control object</param>
        private void BindPropertiesToControl(string s_cntrlType, TrackingDetails trackingDetails, DataTable Dt_Get_L10N_UI, Label label, TextBox textBox, Button button, CheckBox checkBox, RadioButton radioButton, BaseValidator ReqValidator, BaseValidator RegExpValidator, GridView gridView)
        {
            try
            {

                switch (s_cntrlType)
                {

                    case CommonConstantModel.s_cntrlTypeLabel:


                        label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                        label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                        break;


                    case CommonConstantModel.s_cntrlTypeButton:

                        button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                        button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                        break;


                    case CommonConstantModel.s_cntrlTypeRadioButton:

                        radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                        radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                        break;


                    case CommonConstantModel.s_cntrlTypeRFValidator:

                        ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                        break;

                    case CommonConstantModel.s_cntrlTypeRExprValidator:

                        RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                        break;

                    case CommonConstantModel.s_cntrlTypeGridView:

                        gridView.EmptyDataText = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + gridView.ID + "'"))[0]["LabelName"]);
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to load gridview data.
        /// </summary>
        public void LoadGridData(TrackingDetails trackingDetails)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "GET_TRACKING_DETAILS";
                    accountingProperties.PageName = CommonConstantModel.s_TrackingDetails;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    ac_TrackingDetails.dt_Get_Tracking_details = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                    ddTDSearch_TrackingType(trackingDetails);
                    FilterGridData(trackingDetails);

                    trackingDetails.btnTD_Delete.Visible = trackingDetails.gv.Rows.Count > 0 ? true : false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Binds Row of gridview and restructures column according to needs.
        /// </summary>
        /// <param name="e">Gridview Row Event Argum.</param>
        /// <param name="n_index">index number</param>
        /// <param name="n_ID">INDEX ID</param>
        /// <param name="n_Delete">Row  Id to be deleted.</param>
        /// <param name="n_AtmID">Traking Master ID</param>        
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_AtmID)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "ATMDID":
                                n_ID = n_index;
                                perColumn.Visible = false;
                                break;

                            case "DELETE":
                                n_Delete = n_index;
                                e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                break;

                            case "ATMID":
                                n_AtmID = n_index;
                                perColumn.Visible = false;
                                break;

                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    try
                    {
                        e.Row.Cells[n_ID].Visible = e.Row.Cells[n_AtmID].Visible = false;
                        e.Row.Cells[1].Controls.Add(AddCheckBox(e.Row.Cells[n_ID].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        e.Row.Cells[n_Delete].HorizontalAlign = HorizontalAlign.Center;
                        break;
                    }
                    catch
                    {
                        throw;
                    }
            }
        }


        /// <summary>
        /// this method adds checkboxes in the first column of the gridview 
        /// </summary>
        /// <param name="s_TrackingDetailsID">TRACKING DETAIL ID</param>
        /// <param name="IsDeleted"> is deleted boolean</param>
        /// <returns></returns>
        private CheckBox AddCheckBox(string s_TrackingDetailsID, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_TrackingDetailsID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");
                if (!string.IsNullOrEmpty(s_TrackingDetailsID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_TrackingDetailsID + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// Filters Gridview data according to the parameters selected
        /// </summary>
        /// <param name="trackingDetails">object of tracking Details Page</param>
        public void FilterGridData(TrackingDetails trackingDetails)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                try
                {
                    if (ac_TrackingDetails.dt_Get_Tracking_details.Rows.Count > 0)
                    {
                        string s_TrackingType = trackingDetails.ddTDSearch_TrackingType.SelectedValue != "--- Please Select ---" ? "[ATMID] = '" + Convert.ToString(trackingDetails.ddTDSearch_TrackingType.SelectedValue) + "'" : string.Empty;

                        ac_TrackingDetails.dt_FilteredDataTable = ac_TrackingDetails.dt_Get_Tracking_details;

                        try
                        {
                            if (!(string.IsNullOrEmpty(s_TrackingType)))
                                ac_TrackingDetails.dt_FilteredDataTable = ac_TrackingDetails.dt_FilteredDataTable.Select("" + s_TrackingType + "").CopyToDataTable();
                            else
                            {
                                ac_TrackingDetails.dt_FilteredDataTable = ac_TrackingDetails.dt_Get_Tracking_details;
                            }
                        }
                        catch
                        {
                            ac_TrackingDetails.dt_FilteredDataTable = new DataTable();
                        }

                        trackingDetails.gv.DataSource = ac_TrackingDetails.dt_FilteredDataTable;
                        trackingDetails.gv.DataBind();
                        trackingDetails.btnTD_Delete.Visible = trackingDetails.gv.Rows.Count > 0 ? true : false;
                    }
                    else
                    {
                        trackingDetails.gv.DataBind();
                    }
                }
                catch
                {
                    throw;
                }

                trackingDetails.btnTD_Delete.Visible = trackingDetails.gv.Rows.Count > 0 ? true : false;
            }
        }

        /// <summary>
        ///This method oads ddTDSearch_TrackingType dropdownlist.
        /// </summary>
        public void ddTDSearch_TrackingType(TrackingDetails trackingDetails)
        {
            try
            {
                using (DataView dv_Dataview = new DataView(ac_TrackingDetails.dt_Get_Tracking_details))
                {
                    using (DataTable dt_GetTrankingTypes = dv_Dataview.ToTable(true, "ATMID", "Tracking Type"))
                    {
                        trackingDetails.ddTDSearch_TrackingType.DataSource = dt_GetTrankingTypes;
                        trackingDetails.ddTDSearch_TrackingType.DataTextField = "Tracking Type";
                        trackingDetails.ddTDSearch_TrackingType.DataValueField = "ATMID";
                        trackingDetails.ddTDSearch_TrackingType.DataBind();
                        trackingDetails.ddTDSearch_TrackingType.Items.Insert(0, "--- Please Select ---");
                        trackingDetails.ddTDSearch_TrackingType.SelectedValue = "--- Please Select ---";
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method loads Load_ddTD_SelectTrackingType dropdownlist.
        /// </summary>
        /// <param name="trackingDetails">object of tracking Details Page</param>
        public void Load_ddTD_SelectTrackingType(TrackingDetails trackingDetails)
        {
            try
            {
                accountingProperties.Action = "GET_TRACKING_MASTER";
                accountingProperties.PageName = CommonConstantModel.s_TrackingDetails;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    trackingDetails.ddTD_SelectTrackingType.DataSource = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                    trackingDetails.ddTD_SelectTrackingType.DataTextField = "DATA";
                    trackingDetails.ddTD_SelectTrackingType.DataValueField = "VALUE";
                    trackingDetails.ddTD_SelectTrackingType.Items.Insert(0, "--- Please Select ---");
                    trackingDetails.ddTD_SelectTrackingType.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to change pages index of gridview.
        /// </summary>
        /// <param name="sender">senders object</param>
        /// <param name="e">event arguement</param>
        /// <param name="gv">gridview gv</param>
        /// <param name="s_TrackingDetailsGroupID">row id that are selected by user</param>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_TrackingDetailsGroupID)
        {
            try
            {
                string[] s_AssignGpID = s_TrackingDetailsGroupID.TrimStart(',').Split(',');

                ac_TrackingDetails.dt_FilteredDataTable.Columns["Delete"].Expression = string.Empty;
                ac_TrackingDetails.dt_FilteredDataTable.AcceptChanges();

                foreach (string perID in s_AssignGpID)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_TrackingDetails.dt_FilteredDataTable.Select("ATMID ='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }

                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_TrackingDetails.dt_FilteredDataTable;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method Adds "Delete all" checkbox at the header of delete column.
        /// </summary>
        /// <returns>CheckBox</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chkDeleteAll";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Text = string.Empty;
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }

        }

        /// <summary>
        /// This method is to Create / Delete the records  in database table .
        /// </summary>
        /// <param name="trackingDetails">object of  page.</param>
        /// <param name="RowId">Row ids that has been selected</param>
        /// <returns></returns>
        internal bool PerformCUD(TrackingDetails trackingDetails, string RowId)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                bool b_status = false;
                accountingProperties.Id = RowId.Contains(",") ? 0 : Convert.ToInt32(RowId);
                accountingProperties.Ids = RowId;
                accountingProperties.AtmID = Convert.ToInt32(trackingDetails.ddTD_SelectTrackingType.SelectedValue);
                accountingProperties.Param_Name = CommonModel.ReplaceApostrophe(trackingDetails.txtTD_FieldName.Text);
                accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                accountingProperties.Action = trackingDetails.hdnBtnID.Value;
                accountingProperties.PageName = CommonConstantModel.s_TrackingDetails;
                accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                try
                {
                    switch (accountingServiceClient.CRUDAccountingOperations(accountingProperties).a_result)
                    {
                        case 0:
                            trackingDetails.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblTD_Error", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            trackingDetails.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            trackingDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            trackingDetails.hdnAccordianIndex.Value = "0";
                            break;

                        case 1:
                            trackingDetails.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblTD_Added", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            trackingDetails.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            trackingDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            trackingDetails.hdnAccordianIndex.Value = "0";
                            b_status = true;
                            break;


                        case 3:
                            LoadGridData(trackingDetails);
                            trackingDetails.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblTD_Deleted", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            trackingDetails.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            trackingDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            trackingDetails.hdnDeletedRecords.Value = "";
                            trackingDetails.hdnAccordianIndex.Value = "0";
                            b_status = true;
                            break;

                        case 4:
                            trackingDetails.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblTD_CanNotBeDeleted", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            trackingDetails.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            trackingDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            trackingDetails.hdnAccordianIndex.Value = "0";
                            break;

                        case 5:
                            trackingDetails.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblTD_Exists", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            trackingDetails.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            trackingDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            trackingDetails.hdnAccordianIndex.Value = "1";
                            break;

                    }
                    trackingDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    trackingDetails.txtTD_FieldName.Text = "";
                    trackingDetails.ddTD_SelectTrackingType.SelectedIndex = -1;
                    return b_status;
                }
                catch
                {
                    throw;
                }
            }
        }


        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~TrackingDetailsModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}