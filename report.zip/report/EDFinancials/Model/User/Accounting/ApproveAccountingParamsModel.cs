﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// The class file of Approve Accounting ParamsModel page
    /// </summary>
    public class ApproveAccountingParamsModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public ApproveAccountingParamsModel()
        {
            if (ac_ApproveAccountingParams == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ApproveAccountingParams);
                ac_ApproveAccountingParams = (CommonModel.AC_ApproveAccountingParams)HttpContext.Current.Session[CommonConstantModel.s_AC_ApproveAccountingParams];
            }
        }

        #endregion

        #region Bind UI methods
        /// <summary>
        /// This method is used to bind UI labels from xml
        /// </summary>
        /// <param name="approveAccountingParameters">approveAccountingParameters page object</param>
        public void BindUI(ApproveAccountingParameters approveAccountingParameters)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI == null || ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI.Rows.Count.Equals(0))
                    {
                        ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10_UI);
                    }
                    if ((ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI != null) && (ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI.Rows.Count > 0))
                    {
                        foreach (Control control in approveAccountingParameters.dvMain.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, approveAccountingParameters, ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI, (Label)control, null, null);
                                    break;
                                case CommonConstantModel.s_wcGridview:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, approveAccountingParameters, ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI, null, (GridView)control, null);
                                    break;
                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, approveAccountingParameters, ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI, null, null, (Button)control);
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">This private method is used to Bind controls with their properties.</param>
        /// <param name="approveAccountingParameters">The approveAccountingParameters page object</param>
        /// <param name="Dt_Get_L10N_UI">This datatable contains the data of the XML UI</param>
        /// <param name="label">The lael control object</param>
        /// <param name="gridView">The gridview control object</param>
        /// <param name="button">The button control object</param>
        private void BindPropertiesToControl(string s_cntrlType, ApproveAccountingParameters approveAccountingParameters, DataTable Dt_Get_L10N_UI, Label label, GridView gridView, Button button)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    gridView.EmptyDataText = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + gridView.ID + "'"))[0]["LabelName"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;


            }
        }

        /// <summary>
        /// Method to populate all the controls on page load
        /// </summary>
        /// <param name="approveAccountingParameters">ApproveAccountingParameters page object</param>
        public void BindApprovalGrid(ApproveAccountingParameters approveAccountingParameters)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_AccountingParameter;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "APPROVALDATA";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_ApproveAccountingParams.ds_ApprAccParams = (DataSet)accountingCRUDProperties.ds_Result;
                    approveAccountingParameters.gvAPAApprovalGrid.DataSource = ac_ApproveAccountingParams.ds_ApprAccParams.Tables[0];
                    approveAccountingParameters.gvAPAApprovalGrid.DataBind();
                    if (ac_ApproveAccountingParams.ds_ApprAccParams.Tables[0].Rows.Count <= 0)
                    {
                        approveAccountingParameters.btnAPSApprove.Enabled = approveAccountingParameters.btnAPSDisApprove.Enabled = false;
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Approval Section
        /// <summary>
        /// this event used when a data row is bound to data in a GridView control.
        /// </summary>
        /// <param name="e">event args</param>
        /// <param name="approveAccountingParameters">ApproveAccountingParameters page object</param>
        /// <param name="n_Index">index of the row</param>
        /// <param name="n_Parameters">Parameters name which are updated</param>
        /// <param name="n_PreviousSettings">PreviousSettings which was present for given parmameters</param>
        /// <param name="n_CurrentSettings">CurrentSettings which are updated for given parameters but pending for approval</param>
        /// <param name="n_CONFIGID">CONFIGID against whom setting will be approve</param>
        public void gvAPAApprovalGrid_RowDataBound(GridViewRowEventArgs e, ApproveAccountingParameters approveAccountingParameters, ref int n_Index, ref int n_Parameters, ref int n_PreviousSettings, ref int n_CurrentSettings, ref int n_CONFIGID)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "PARAMETERS":
                                    n_Parameters = n_Index;
                                    break;
                                case "PREVIOUS SETTINGS":
                                    n_PreviousSettings = n_Index;
                                    break;
                                case "CURRENT SETTINGS":
                                    n_CurrentSettings = n_Index;
                                    break;
                                case "CONFIGID":
                                    n_CONFIGID = n_Index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_Index++;
                        }
                        break;
                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_CONFIGID].Visible = false;
                        e.Row.Cells[n_PreviousSettings].Controls.Add(AddBulletedList(e.Row.Cells[n_Parameters].Text, e.Row.Cells[n_PreviousSettings].Text, "PreviousSettings"));
                        e.Row.Cells[n_CurrentSettings].Controls.Add(AddBulletedList(e.Row.Cells[n_Parameters].Text, e.Row.Cells[n_CurrentSettings].Text, "CurrentSettings"));
                        e.Row.Cells[n_PreviousSettings].Width = e.Row.Cells[n_CurrentSettings].Width = 300;
                        e.Row.Cells[n_Parameters].Width = 200;
                        SetConfigIDsToHdnFields(e.Row.Cells[n_CONFIGID].Text, approveAccountingParameters);
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to get bulleted list object
        /// </summary>
        /// <param name="s_Type">Accounting parameters type</param>
        /// <param name="s_Parameters">~ separated string object</param>
        /// <param name="s_Settings">Setting Type</param>
        /// <returns></returns>
        private BulletedList AddBulletedList(string s_Type, string s_Parameters, string s_Settings)
        {
            using (BulletedList bulletedList = new BulletedList())
            {
                string[] Parameters = s_Parameters.Split('~');
                string s_ItemToAdd = string.Empty;
                string s_VAL_METH_CAL_CC_LABEL_ID = string.Empty, s_ACC_METHOD_LABEL_ID = string.Empty, s_RECOGNITION_CC_LABEL_ID = string.Empty,
                     s_COSTREVERSALAF_VCLABEL_ID = string.Empty, s_COSTREVERSALAF_UCLABEL_ID = string.Empty, s_COSTREVERSALAF_LAPLABEL_ID = string.Empty;
                switch (s_Type.ToUpper())
                {
                    case "VALUATION METHOD":
                        foreach (string item in Parameters)
                        {
                            string[] s_Items = item.Split(':');
                            switch (s_Items[0])
                            {
                                case "VAL_METH_CAL_CC_LABEL_ID": s_VAL_METH_CAL_CC_LABEL_ID = s_Items[1]; break;
                            }
                        }
                        if (!string.IsNullOrEmpty(s_VAL_METH_CAL_CC_LABEL_ID))
                        {
                            s_ItemToAdd = string.Empty;
                            s_ItemToAdd = Convert.ToString((ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI.Select("LabelID = '" + s_VAL_METH_CAL_CC_LABEL_ID + "'"))[0]["LabelName"]);
                            bulletedList.Items.Add(s_ItemToAdd);
                        }
                        break;
                    case "ACCOUNTING METHOD":
                        foreach (string item in Parameters)
                        {
                            string[] s_Items = item.Split(':');
                            switch (s_Items[0])
                            {
                                case "ACC_METHOD_LABEL_ID": s_ACC_METHOD_LABEL_ID = s_Items[1]; break;
                            }
                        }
                        if (!string.IsNullOrEmpty(s_ACC_METHOD_LABEL_ID))
                        {
                            bulletedList.Items.Add(Convert.ToString((ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI.Select("LabelID = '" + s_ACC_METHOD_LABEL_ID + "'"))[0]["LabelName"]));
                        }
                        break;
                    case "RECOGNITION OF COMPENSATION COST":
                        foreach (string item in Parameters)
                        {
                            string[] s_Items = item.Split(':');
                            switch (s_Items[0])
                            {
                                case "RECOGNITION_CC_LABEL_ID": s_RECOGNITION_CC_LABEL_ID = s_Items[1]; break;
                            }
                        }
                        if (!string.IsNullOrEmpty(s_RECOGNITION_CC_LABEL_ID))
                            bulletedList.Items.Add(Convert.ToString((ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI.Select("LabelID = '" + s_RECOGNITION_CC_LABEL_ID + "'"))[0]["LabelName"]));
                        break;
                    case "COST REVERSAL ALLOWED FOR":
                        foreach (string item in Parameters)
                        {
                            string[] s_Items = item.Split(':');
                            switch (s_Items[0])
                            {
                                case "COSTREVERSALAF_VCLABEL_ID": s_COSTREVERSALAF_VCLABEL_ID = s_Items[1]; break;
                                case "COSTREVERSALAF_UCLABEL_ID": s_COSTREVERSALAF_UCLABEL_ID = s_Items[1]; break;
                                case "COSTREVERSALAF_LAPLABEL_ID": s_COSTREVERSALAF_LAPLABEL_ID = s_Items[1]; break;
                            }
                        }
                        if (!string.IsNullOrEmpty(s_COSTREVERSALAF_VCLABEL_ID))
                            bulletedList.Items.Add(Convert.ToString((ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI.Select("LabelID = '" + s_COSTREVERSALAF_VCLABEL_ID + "'"))[0]["LabelName"]));

                        if (!string.IsNullOrEmpty(s_COSTREVERSALAF_UCLABEL_ID))
                            bulletedList.Items.Add(Convert.ToString((ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI.Select("LabelID = '" + s_COSTREVERSALAF_UCLABEL_ID + "'"))[0]["LabelName"]));

                        if (!string.IsNullOrEmpty(s_COSTREVERSALAF_LAPLABEL_ID))
                            bulletedList.Items.Add(Convert.ToString((ac_ApproveAccountingParams.dt_ApprAccParamsSetupUI.Select("LabelID = '" + s_COSTREVERSALAF_LAPLABEL_ID + "'"))[0]["LabelName"]));
                        break;
                }
                return bulletedList;
            }
        }

        /// <summary>
        /// This method is used to set Config ID's to hidden fields
        /// </summary>
        /// <param name="s_ConfigID">ConfigID : primary key</param>
        /// <param name="approveAccountingParameters">ApproveAccountingParameters page object</param>
        private void SetConfigIDsToHdnFields(string s_ConfigID, ApproveAccountingParameters approveAccountingParameters)
        {
            if (!string.IsNullOrEmpty(s_ConfigID) || !s_ConfigID.Equals("&nbsp;"))
            {
                approveAccountingParameters.hdnAPValueID.Value = s_ConfigID;
            }
        }

        /// <summary>
        /// Button click event to approve Accounting parameters
        /// </summary>
        /// <param name="approveAccountingParameters">ApproveAccountingParameters page object</param>
        /// <param name="b_IsApproved">boolean value for approve/disapprove</param>
        public void btnAPSApprove_Click(ApproveAccountingParameters approveAccountingParameters, bool b_IsApproved)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_AccountingParameter;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.IS_APPROVED = b_IsApproved;
                    accountingProperties.APMS_ID = !string.IsNullOrEmpty(approveAccountingParameters.hdnAPValueID.Value) ? Convert.ToInt32(approveAccountingParameters.hdnAPValueID.Value) : 0;
                    accountingProperties.PopulateControls = "APPROVALDATA";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    approveAccountingParameters.hdnConfigIDs.Value = string.Empty;

                    if (accountingCRUDProperties.a_result > 0)
                    {
                        switch (accountingCRUDProperties.a_result)
                        {
                            case 1:
                                approveAccountingParameters.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAPSConfigDisApprMessage", CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10);
                                approveAccountingParameters.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                approveAccountingParameters.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                                break;
                            case 2:
                                approveAccountingParameters.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAPSConfigApproveMessage", CommonConstantModel.s_AccountingParameter, CommonConstantModel.s_AccountingL10);
                                approveAccountingParameters.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                approveAccountingParameters.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                                break;
                        }
                        BindApprovalGrid(approveAccountingParameters);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Button click event to disapprove accounting parameters
        /// </summary>
        /// <param name="approveAccountingParameters">ApproveAccountingParameters page object</param>
        /// <param name="b_IsApproved">boolean value for approve/disapprove</param>
        public void btnAPSDisApprove_Click(ApproveAccountingParameters approveAccountingParameters, bool b_IsApproved)
        {
            try
            {
                btnAPSApprove_Click(approveAccountingParameters, b_IsApproved);
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}