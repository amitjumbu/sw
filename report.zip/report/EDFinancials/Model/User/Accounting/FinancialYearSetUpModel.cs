﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    ///  The model class for FinancialYearSetUp Page.
    /// </summary>
    public class FinancialYearSetUpModel : BaseModel, IDisposable
    {
        StringBuilder sb_ErrorMessage = new StringBuilder();

        #region Default Constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public FinancialYearSetUpModel()
        {
            if (ac_FinancialYearSetUp == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_FinancialYearSetUp);
                ac_FinancialYearSetUp = (CommonModel.AC_FinancialYearSetUp)HttpContext.Current.Session[CommonConstantModel.s_AC_FinancialYearSetUp];
            }
        }
        #endregion

        /// <summary>
        /// This method will bind all the names to the respective controls
        /// </summary>
        /// <param name="financialYearSetUp">The FinancialYearSetUp Object</param>
        internal void BindUI(FinancialYearSetUp financialYearSetUp)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    using (DataTable dt_Get_L10N_UI = (DataTable)accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_FinancialYearSetUp, CommonConstantModel.s_AccountingL10_UI))
                    {
                        if ((dt_Get_L10N_UI != null) && (dt_Get_L10N_UI.Rows.Count > 0))
                        {
                            foreach (Control control in financialYearSetUp.divFY.Controls)
                            {
                                switch (control.GetType().FullName.ToUpper())
                                {
                                    case CommonConstantModel.s_wcLabel:
                                        BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, financialYearSetUp, dt_Get_L10N_UI, (Label)control, null, null);
                                        break;

                                    case CommonConstantModel.s_wcTextbox:
                                        BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, financialYearSetUp, dt_Get_L10N_UI, null, (TextBox)control, null);
                                        break;

                                    case CommonConstantModel.s_wcButton:
                                        BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, financialYearSetUp, dt_Get_L10N_UI, null, null, (Button)control);
                                        break;
                                }
                            }
                        }

                        financialYearSetUp.lblFYHeaderTwo.Text = Convert.ToString((dt_Get_L10N_UI.Select("LabelID = 'lblFYHeaderTwo'"))[0]["LabelName"]);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="financialYearSetUp">The FinancialYearSetUp Object</param>
        /// <param name="dt_Get_L10N_UI">Datatable to get UI related names of controls</param>
        /// <param name="label">label object</param>
        /// <param name="textBox">textbox object</param>
        /// <param name="button">button object</param>
        private void BindPropertiesToControl(string s_cntrlType, FinancialYearSetUp financialYearSetUp, DataTable dt_Get_L10N_UI, Label label, TextBox textBox, Button button)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    label.Text = Convert.ToString((dt_Get_L10N_UI.Select("LabelID = '" + Convert.ToString(label.ID) + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((dt_Get_L10N_UI.Select("LabelID = '" + Convert.ToString(label.ID) + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    button.Text = Convert.ToString((dt_Get_L10N_UI.Select("LabelID = '" + Convert.ToString(button.ID) + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((dt_Get_L10N_UI.Select("LabelID = '" + Convert.ToString(button.ID) + "'"))[0]["LabelToolTip"]);
                    break;
            }
        }

        /// <summary>
        /// The method to check Role Priviledges assigned to the User
        /// </summary>
        /// <param name="financialYearSetUp">The FinancialYearSetUp Object</param>
        internal void CheckEmployeeRolePriviledges(FinancialYearSetUp financialYearSetUp)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuFinancialYearSetUp;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePreviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePreviledges != null && dt_RolePreviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePreviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case CommonConstantModel.s_VIEW:
                                    financialYearSetUp.btnFYUpdateFY.Enabled = false;
                                    financialYearSetUp.btnFYSave.Enabled = false;
                                    break;

                                case CommonConstantModel.s_ADD:
                                    financialYearSetUp.btnFYUpdateFY.Enabled = true;
                                    financialYearSetUp.btnFYSave.Enabled = true;
                                    break;

                                case CommonConstantModel.s_EDIT:
                                    financialYearSetUp.btnFYUpdateFY.Enabled = true;
                                    financialYearSetUp.btnFYSave.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind the Financial Year GridView and Financial Years to the DropdownList.
        /// </summary>
        /// <param name="financialYearSetUp">The FinancialYearSetUp Object</param>
        internal void BindFinYrGrid(FinancialYearSetUp financialYearSetUp)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_FinancialYearSetUp;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;

                    accountingProperties.PopulateControls = "GET_FINC_YR_DETAILS";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    accountingCRUDProperties.ds_Result.Tables[0].TableName = "DT_FY_DATA";

                    accountingCRUDProperties.ds_Result.Tables[1].TableName = "DT_LOCKED_DATA";
                    ac_FinancialYearSetUp.dt_LockedData = (DataTable)accountingCRUDProperties.ds_Result.Tables[1];

                    ac_FinancialYearSetUp.dt_FincYr = (DataTable)accountingCRUDProperties.ds_Result.Tables[0].DefaultView.ToTable(true, "AFYMID", "FINC_YEAR", "Quarter", "From Date", "To Date");

                    financialYearSetUp.ddlFYViewFincYr.DataSource = ac_FinancialYearSetUp.dt_FincYr.DefaultView.ToTable(true, "AFYMID", "FINC_YEAR");
                    financialYearSetUp.ddlFYViewFincYr.DataTextField = "FINC_YEAR";
                    financialYearSetUp.ddlFYViewFincYr.DataValueField = "AFYMID";
                    financialYearSetUp.ddlFYViewFincYr.DataBind();

                    financialYearSetUp.ddlFYViewFincYr.SelectedIndex = Convert.ToInt32(ac_FinancialYearSetUp.dt_FincYr.Compute("max(AFYMID)", string.Empty)) - 15;

                    financialYearSetUp.gvFincYr.DataSource = ac_FinancialYearSetUp.dt_FincYr.Select("FINC_YEAR='" + Convert.ToString(financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text) + "'").CopyToDataTable();
                    financialYearSetUp.gvFincYr.DataBind();

                    financialYearSetUp.h4FYAddEdit.Style.Add("display", "none");
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Row Data Bound Event of gvFincYr GridView
        /// </summary>
        /// <param name="sender">gvFincYr GridView</param>
        /// <param name="e">e</param>
        /// <param name="n_index">Index</param>
        /// <param name="n_AFYMID">Financial YearMaster Table ID index</param>
        /// <param name="n_FincYr">Financial Year index</param>
        /// <param name="n_FromDate">From Date index</param>
        /// <param name="n_ToDate">To Date index</param>
        /// <param name="financialYearSetUp">The FinancialYearSetUp Object</param>
        internal void gvFincYr_RowDataBound(object sender, GridViewRowEventArgs e, ref int n_index, ref int n_AFYMID, ref int n_FincYr, ref int n_FromDate, ref int n_ToDate, FinancialYearSetUp financialYearSetUp)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "AFYMID":
                                    n_AFYMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "FINC_YEAR":
                                    n_FincYr = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "FROM DATE":
                                    n_FromDate = n_index;
                                    break;

                                case "TO DATE":
                                    n_ToDate = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_FincYr].Visible = e.Row.Cells[n_AFYMID].Visible = false;
                        e.Row.Cells[n_FromDate].HorizontalAlign = e.Row.Cells[n_ToDate].HorizontalAlign = HorizontalAlign.Center;

                        if (Convert.ToString(((GridView)sender).ID).Equals("gvFYUpdateFY"))
                        {
                            using (ImageButton imgbtn_gvFYUpdateFY = new ImageButton())
                            {
                                imgbtn_gvFYUpdateFY.ID = "imgbtn_gvFYUpdateFY_" + e.Row.RowIndex;
                                imgbtn_gvFYUpdateFY.Attributes.Add("runat", "server");
                                imgbtn_gvFYUpdateFY.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                imgbtn_gvFYUpdateFY.ImageUrl = "~/View/App_Themes/images/alert_1.png";
                                e.Row.Cells[n_FromDate].Controls.Add(imgbtn_gvFYUpdateFY);
                            }

                            using (TextBox txt_gvFYUpdateFY = new TextBox())
                            {
                                txt_gvFYUpdateFY.ID = "txt_gvFYUpdateFY_" + e.Row.RowIndex;
                                txt_gvFYUpdateFY.CssClass = "cTextBox datepickerFincYr";
                                txt_gvFYUpdateFY.Attributes.Add("runat", "server");
                                txt_gvFYUpdateFY.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                txt_gvFYUpdateFY.Style.Add("width", "100px");
                                txt_gvFYUpdateFY.Text = Convert.ToDateTime(e.Row.Cells[n_FromDate].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[n_FromDate].Controls.Add(new LiteralControl("&nbsp;"));
                                e.Row.Cells[n_FromDate].Controls.Add(txt_gvFYUpdateFY);
                            }

                            using (Label lbl_gvFYUpdateFY = new Label())
                            {
                                lbl_gvFYUpdateFY.ID = "lbl_gvFYUpdateFY_" + e.Row.RowIndex;
                                lbl_gvFYUpdateFY.Attributes.Add("runat", "server");
                                lbl_gvFYUpdateFY.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                lbl_gvFYUpdateFY.Text = Convert.ToDateTime(e.Row.Cells[n_ToDate].Text).ToString("dd/MMM/yyyy");
                                e.Row.Cells[n_ToDate].Controls.Add(lbl_gvFYUpdateFY);
                            }
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The button click event of View Financial Year
        /// </summary>
        /// <param name="financialYearSetUp">The FinancialYearSetUp Object</param>
        internal void btnFYViewFincYr_Click(FinancialYearSetUp financialYearSetUp)
        {
            try
            {
                financialYearSetUp.gvFincYr.DataSource = ac_FinancialYearSetUp.dt_FincYr.Select("FINC_YEAR='" + Convert.ToString(financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text) + "'").CopyToDataTable();
                financialYearSetUp.gvFincYr.DataBind();
                financialYearSetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                financialYearSetUp.h4FYAddEdit.Style.Add("display", "none");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The button click event of Update Financial Year Set Up
        /// </summary>
        /// <param name="financialYearSetUp">The FinancialYearSetUp Object</param>
        internal void btnFYUpdateFY_Click(FinancialYearSetUp financialYearSetUp)
        {
            try
            {
                financialYearSetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                financialYearSetUp.h4FYAddEdit.Style.Add("display", "normal");

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {

                    Boolean bool_IsLocked = false;
                    int n_AFYMID = 0;
                    int n_CurrentAFYMID = 0;

                    if (ac_FinancialYearSetUp.dt_LockedData != null && ac_FinancialYearSetUp.dt_LockedData.Rows.Count > 0)
                    {
                        for (int n_LockedRptDate = 0; n_LockedRptDate <= ac_FinancialYearSetUp.dt_LockedData.Rows.Count - 1; n_LockedRptDate++)
                        {
                            n_AFYMID = Convert.ToInt32(ac_FinancialYearSetUp.dt_FincYr.Select().Where(p => (Convert.ToDateTime(p["From Date"]) <= Convert.ToDateTime(Convert.ToString(ac_FinancialYearSetUp.dt_LockedData.Rows[n_LockedRptDate]["REPORTING_DATE"]))) && (Convert.ToDateTime(p["To Date"]) >= Convert.ToDateTime(Convert.ToString(ac_FinancialYearSetUp.dt_LockedData.Rows[n_LockedRptDate]["REPORTING_DATE"])))).CopyToDataTable().Rows[0]["AFYMID"].ToString());
                            n_CurrentAFYMID = Convert.ToInt32(ac_FinancialYearSetUp.dt_FincYr.Select("FINC_YEAR='" + Convert.ToString(financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text) + "'").CopyToDataTable().Rows[0]["AFYMID"].ToString());

                            if(n_AFYMID >= n_CurrentAFYMID)
                            {
                                bool_IsLocked = true;
                                break;
                            }
                        }
                    }

                    if (bool_IsLocked)
                    {
                        financialYearSetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                        financialYearSetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        financialYearSetUp.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFYLockedData", CommonConstantModel.s_FinancialYearSetUp, CommonConstantModel.s_AccountingL10);
                        financialYearSetUp.h4FYAddEdit.Style.Add("display", "none");
                    }
                    else
                    {
                        financialYearSetUp.ddlFYApplyTillYears.DataSource = ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID <='" + Convert.ToInt32(ac_FinancialYearSetUp.dt_FincYr.Compute("max(AFYMID)", string.Empty)) + "'" + "AND AFYMID >= '" + Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) + "'").CopyToDataTable().DefaultView.ToTable(true, "AFYMID", "FINC_YEAR");
                        financialYearSetUp.ddlFYApplyTillYears.DataTextField = "FINC_YEAR";
                        financialYearSetUp.ddlFYApplyTillYears.DataValueField = "AFYMID";
                        financialYearSetUp.ddlFYApplyTillYears.DataBind();
                        financialYearSetUp.hdnAccordionIndex.Value = "1";

                        financialYearSetUp.gvFYUpdateFY.DataSource = ac_FinancialYearSetUp.dt_FincYr.Select("FINC_YEAR='" + Convert.ToString(financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text) + "'").CopyToDataTable();
                        financialYearSetUp.gvFYUpdateFY.DataBind();

                        financialYearSetUp.hdnFYQ1FromDate.Value = ac_FinancialYearSetUp.dt_FincYr.Select("FINC_YEAR='" + Convert.ToString(financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text) + "'").CopyToDataTable().Rows[0][3].ToString();
                        financialYearSetUp.hdnFYQ2FromDate.Value = ac_FinancialYearSetUp.dt_FincYr.Select("FINC_YEAR='" + Convert.ToString(financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text) + "'").CopyToDataTable().Rows[1][3].ToString();
                        financialYearSetUp.hdnFYQ3FromDate.Value = ac_FinancialYearSetUp.dt_FincYr.Select("FINC_YEAR='" + Convert.ToString(financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text) + "'").CopyToDataTable().Rows[2][3].ToString();
                        financialYearSetUp.hdnFYQ4FromDate.Value = ac_FinancialYearSetUp.dt_FincYr.Select("FINC_YEAR='" + Convert.ToString(financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text) + "'").CopyToDataTable().Rows[3][3].ToString();
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The button click event of Save updated Financial Year
        /// </summary>
        /// <param name="financialYearSetUp">The FinancialYearSetUp Object</param>
        internal void btnFYSave_Click(FinancialYearSetUp financialYearSetUp)
        {
            try
            {
                bool b_ValidFlag = Validate_FinancialYears(financialYearSetUp);

                if (!b_ValidFlag)
                {
                    DataTable dt_TempFincYrData = new DataTable();
                    dt_TempFincYrData.Columns.Add("AFYMID", typeof(int));
                    dt_TempFincYrData.Columns.Add("FINC_YEAR", typeof(string));
                    dt_TempFincYrData.Columns.Add("Quarter", typeof(string));
                    dt_TempFincYrData.Columns.Add("From Date", typeof(DateTime));
                    dt_TempFincYrData.Columns.Add("To Date", typeof(DateTime));

                    dt_TempFincYrData.Rows.Add(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) - 1) + "'").Count() > 0 ?
                                               Convert.ToInt32(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) - 1) + "'")[0].ItemArray[0]) : 0,
                                               ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) - 1) + "'").Count() > 0 ?
                                               Convert.ToString(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) - 1) + "'")[3].ItemArray[1]) : string.Empty,
                                               ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) - 1) + "'").Count() > 0 ?
                                               Convert.ToString(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) - 1) + "'")[3].ItemArray[2]) : string.Empty,
                                               ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) - 1) + "'").Count() > 0 ?
                                               Convert.ToString(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) - 1) + "'")[3].ItemArray[3]) : string.Empty,
                                               ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) - 1) + "'").Count() > 0 ?
                                               Convert.ToString(Convert.ToDateTime(financialYearSetUp.hdnFYQ1FromDate.Value).AddDays(-1).ToString("dd/MMM/yyyy")) : string.Empty);

                    dt_TempFincYrData.Merge(ac_FinancialYearSetUp.dt_UpdatedFYData);

                    if (financialYearSetUp.chkFYApplyTillYears.Checked && !financialYearSetUp.ddlFYApplyTillYears.SelectedIndex.Equals(financialYearSetUp.ddlFYApplyTillYears.Items.Count - 1))
                    {
                        dt_TempFincYrData.Rows.Add(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) + 1) + "'").Count() > 0 ?
                                              Convert.ToInt32(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) + 1) + "'")[0].ItemArray[0]) : 0,
                                              ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) + 1) + "'").Count() > 0 ?
                                              Convert.ToString(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) + 1) + "'")[3].ItemArray[1]) : string.Empty,
                                              ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) + 1) + "'").Count() > 0 ?
                                              Convert.ToString(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) + 1) + "'")[3].ItemArray[2]) : string.Empty,

                                              ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) + 1) + "'").Count() > 0 ?
                                              Convert.ToString(Convert.ToDateTime(dt_TempFincYrData.Rows[4]["To Date"].ToString()).AddYears(Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) - Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue)).AddDays(1).ToString("dd/MMM/yyyy")) : string.Empty,

                                              ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) + 1) + "'").Count() > 0 ?
                                              Convert.ToString(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + Convert.ToInt32(Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) + 1) + "'")[0].ItemArray[4]) : string.Empty);
                    }

                    if (Convert.ToDateTime(dt_TempFincYrData.Rows[0]["From Date"]) >= Convert.ToDateTime(dt_TempFincYrData.Rows[0]["To Date"]) || (financialYearSetUp.chkFYApplyTillYears.Checked && dt_TempFincYrData.Rows.Count.Equals(6) && Convert.ToDateTime(dt_TempFincYrData.Rows[5]["From Date"]) >= Convert.ToDateTime(dt_TempFincYrData.Rows[5]["To Date"])))
                    {
                        financialYearSetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                        financialYearSetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                        if (Convert.ToDateTime(dt_TempFincYrData.Rows[0]["From Date"]) >= Convert.ToDateTime(dt_TempFincYrData.Rows[0]["To Date"]))
                            sb_ErrorMessage.Append(string.Format("The previous Financial Year {0}'s 'To Date' of Quarter 4 can not be greater than the 'From Date' of Quarter 4 of Financial Year {0}", dt_TempFincYrData.Rows[0]["FINC_YEAR"], dt_TempFincYrData.Rows[0]["FINC_YEAR"]));
                        else
                            sb_ErrorMessage.Append(string.Format("The next Financial Year {0}'s 'From Date' of Quarter 1 can not be greater than the 'To Date' of Quarter 1 of Financial Year {0}", dt_TempFincYrData.Rows[5]["FINC_YEAR"], dt_TempFincYrData.Rows[5]["FINC_YEAR"]));

                        financialYearSetUp.ctrSuccessErrorMessage.s_MessageText = sb_ErrorMessage.ToString();
                        financialYearSetUp.h4FYAddEdit.Style.Add("display", "normal");

                        financialYearSetUp.gvFYUpdateFY.DataSource = ac_FinancialYearSetUp.dt_UpdatedFYData;
                        financialYearSetUp.gvFYUpdateFY.DataBind();
                    }
                    else
                    {
                        int n_RowIndex = 0, n_Years = 1;
                        int n_IndexCnt = 0;

                        DataTable dt_UpdatedFYDataOne = new DataTable();
                        dt_UpdatedFYDataOne = ac_FinancialYearSetUp.dt_UpdatedFYData.Copy();

                        DataTable dt_UpdatedFYDataTwo = new DataTable();
                        dt_UpdatedFYDataTwo.Columns.Add("AFYMID", typeof(int));
                        dt_UpdatedFYDataTwo.Columns.Add("FINC_YEAR", typeof(string));
                        dt_UpdatedFYDataTwo.Columns.Add("Quarter", typeof(string));
                        dt_UpdatedFYDataTwo.Columns.Add("From Date", typeof(DateTime));
                        dt_UpdatedFYDataTwo.Columns.Add("To Date", typeof(DateTime));


                        n_RowIndex = 0; n_Years = 1;
                        n_IndexCnt = Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue) + 1;
                        int n_Condition = financialYearSetUp.chkFYApplyTillYears.Checked ? (Convert.ToInt32(financialYearSetUp.ddlFYApplyTillYears.SelectedValue) - Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue)) * 4 : (Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.Items.Count) - Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue)) * 4;

                        for (int n_Index = 1; n_Index <= n_Condition; n_Index++)
                        {
                            if (n_RowIndex == 4)
                            {
                                n_RowIndex = 0;
                                n_IndexCnt++; n_Years++;
                            }

                            dt_UpdatedFYDataTwo.Rows.Add(Convert.ToInt32(Convert.ToString(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + n_IndexCnt + "'")[n_RowIndex].ItemArray[0])),
                                Convert.ToString(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + n_IndexCnt + "'")[n_RowIndex].ItemArray[1]),
                                Convert.ToString(ac_FinancialYearSetUp.dt_FincYr.Select("AFYMID = '" + n_IndexCnt + "'")[n_RowIndex].ItemArray[2]),
                                Convert.ToDateTime(Convert.ToString(ac_FinancialYearSetUp.dt_UpdatedFYData.Rows[n_RowIndex]["From Date"])).AddYears(n_Years).ToString("dd/MMM/yyyy"),
                                Convert.ToDateTime(Convert.ToString(ac_FinancialYearSetUp.dt_UpdatedFYData.Rows[n_RowIndex]["To Date"])).AddYears(n_Years).ToString("dd/MMM/yyyy"));

                            n_RowIndex++;
                        }


                        dt_UpdatedFYDataOne.Merge(dt_UpdatedFYDataTwo);

                        using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                        {
                            accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            accountingProperties.PageName = CommonConstantModel.s_FinancialYearSetUp;
                            accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                            accountingProperties.PopulateControls = "CUD_FINC_YR_DETAILS";
                            accountingProperties.dt_DBFinancialYear = dt_UpdatedFYDataOne.DefaultView.ToTable(true, "AFYMID", "Quarter", "From Date", "To Date");
                            accountingProperties.dt_DBFinancialYear.TableName = "DT";
                            accountingProperties.b_IsTillYrChecked = financialYearSetUp.chkFYApplyTillYears.Checked;
                            accountingProperties.AFYMID = Convert.ToInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue);
                            accountingProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                            accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                            financialYearSetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            financialYearSetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            financialYearSetUp.h4FYAddEdit.Style.Add("display", "none");
                            financialYearSetUp.hdnAccordionIndex.Value = "0";

                            switch (accountingCRUDProperties.a_result)
                            {
                                case 0:
                                    financialYearSetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                    financialYearSetUp.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblFYErrorSave", CommonConstantModel.s_FinancialYearSetUp, CommonConstantModel.s_AccountingL10);
                                    break;

                                case 1:
                                    financialYearSetUp.ctrSuccessErrorMessage.s_MessageText = financialYearSetUp.chkFYApplyTillYears.Checked ? accountingServiceClient.GetAccounting_L10N("lblFYSaveTwo", CommonConstantModel.s_FinancialYearSetUp, CommonConstantModel.s_AccountingL10) : accountingServiceClient.GetAccounting_L10N("lblFYSaveOne", CommonConstantModel.s_FinancialYearSetUp, CommonConstantModel.s_AccountingL10);
                                    break;
                            }
                        }

                        BindFinYrGrid(financialYearSetUp);
                    }
                }
                else
                {
                    financialYearSetUp.gvFYUpdateFY.DataSource = ac_FinancialYearSetUp.dt_UpdatedFYData;
                    financialYearSetUp.gvFYUpdateFY.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to validate the Updated Financial Year
        /// </summary>
        /// <param name="financialYearSetUp">The FinancialYearSetUp Object</param>
        private bool Validate_FinancialYears(FinancialYearSetUp financialYearSetUp)
        {
            try
            {
                bool b_ErrorFlag = false;
                string s_QuarterNo = string.Empty;
                int n_ErrorNum = 0;
                StringBuilder sb_ErrorMessage = new StringBuilder();

                DataTable dt_TempValidate = new DataTable();
                dt_TempValidate.Columns.Add("AFYMID", typeof(int));
                dt_TempValidate.Columns.Add("FINC_YEAR", typeof(string));
                dt_TempValidate.Columns.Add("Quarter", typeof(string));
                dt_TempValidate.Columns.Add("From Date", typeof(DateTime));
                dt_TempValidate.Columns.Add("To Date", typeof(DateTime));

                string s_Q1FromDate = financialYearSetUp.hdnFYQ1FromDate.Value; DateTime dat_Q1FromDate = DateTime.Parse(s_Q1FromDate);
                string s_Q2FromDate = financialYearSetUp.hdnFYQ2FromDate.Value; DateTime dat_Q2FromDate = DateTime.Parse(s_Q2FromDate);
                string s_Q3FromDate = financialYearSetUp.hdnFYQ3FromDate.Value; DateTime dat_Q3FromDate = DateTime.Parse(s_Q3FromDate);
                string s_Q4FromDate = financialYearSetUp.hdnFYQ4FromDate.Value; DateTime dat_Q4FromDate = DateTime.Parse(s_Q4FromDate);

                dt_TempValidate.Rows.Add(Convert.ToUInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue), financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text, "Quarter 1", dat_Q1FromDate.ToString("dd/MMM/yyyy"), (dat_Q2FromDate.AddDays(-1)).ToString("dd/MMM/yyyy"));
                dt_TempValidate.Rows.Add(Convert.ToUInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue), financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text, "Quarter 2", dat_Q2FromDate.ToString("dd/MMM/yyyy"), (dat_Q3FromDate.AddDays(-1)).ToString("dd/MMM/yyyy"));
                dt_TempValidate.Rows.Add(Convert.ToUInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue), financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text, "Quarter 3", dat_Q3FromDate.ToString("dd/MMM/yyyy"), (dat_Q4FromDate.AddDays(-1)).ToString("dd/MMM/yyyy"));
                dt_TempValidate.Rows.Add(Convert.ToUInt32(financialYearSetUp.ddlFYViewFincYr.SelectedValue), financialYearSetUp.ddlFYViewFincYr.SelectedItem.Text, "Quarter 4", dat_Q4FromDate.ToString("dd/MMM/yyyy"), (dat_Q1FromDate.AddYears(1).AddDays(-1)).ToString("dd/MMM/yyyy"));

                for (int n_Cnt = 0; n_Cnt < dt_TempValidate.Rows.Count; n_Cnt++)
                {
                    if (Convert.ToDateTime(dt_TempValidate.Rows[n_Cnt][3].ToString()) >= Convert.ToDateTime(dt_TempValidate.Rows[n_Cnt][4].ToString()))
                    {
                        s_QuarterNo = Convert.ToString(n_Cnt + 1);
                        n_ErrorNum = 1;
                        b_ErrorFlag = true;
                    }

                    else if (!b_ErrorFlag)
                    {
                        if (n_Cnt != 3 && (Convert.ToDateTime(dt_TempValidate.Rows[n_Cnt][3].ToString()) >= Convert.ToDateTime(dt_TempValidate.Rows[n_Cnt + 1][4].ToString())))
                        {
                            s_QuarterNo = Convert.ToString(n_Cnt + 1);
                            n_ErrorNum = 2;
                            b_ErrorFlag = true;
                        }
                    }

                    if (b_ErrorFlag)
                        break;
                }

                if (b_ErrorFlag)
                {
                    financialYearSetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                    financialYearSetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    financialYearSetUp.h4FYAddEdit.Style.Add("display", "normal");

                    switch (n_ErrorNum)
                    {
                        case 1:
                            sb_ErrorMessage.Append(string.Format("The 'To Date' cannot be less than or equal to the 'From Date' for {0}", "Quarter " + s_QuarterNo));
                            financialYearSetUp.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(sb_ErrorMessage);
                            break;

                        case 2:
                            sb_ErrorMessage.Append(string.Format("The 'From Date' of Quarter {0} can not be greater than or equal to the 'To Date' of Quarter {1}", s_QuarterNo, Convert.ToInt32(s_QuarterNo) + 1));
                            financialYearSetUp.ctrSuccessErrorMessage.s_MessageText = Convert.ToString(sb_ErrorMessage);
                            break;
                    }
                }

                ac_FinancialYearSetUp.dt_UpdatedFYData = dt_TempValidate;
                return b_ErrorFlag;
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~FinancialYearSetUpModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}