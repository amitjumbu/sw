﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting.UserControl;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Forfeiture Rate Settings Model class
    /// </summary>
    public class ForfeitureRateSettingsModel : BaseModel, IDisposable
    {
        #region Default Constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public ForfeitureRateSettingsModel()
        {
            if (ac_ForfeitureSetup == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ForfeitureSetup);
                ac_ForfeitureSetup = (CommonModel.AC_ForfeitureSetup)HttpContext.Current.Session[CommonConstantModel.s_AC_ForfeitureSetup];
            }
        }
        #endregion

        #region Page load event

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="forfeitureRateSettingsUC">ForfeitureRateSettings page object</param>
        internal void Page_Load(ForfeitureRateSettingsUC forfeitureRateSettingsUC)
        {
            try
            {
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// This method is used to bind UI
        /// </summary>
        /// <param name="forfeitureRateSettingsUC">ForfeitureRateSettings page object</param>
        /// <param name="b_IsApprovalScreen">b_IsApprovalScreen</param>
        public void BindUI(ForfeitureRateSettingsUC forfeitureRateSettingsUC, bool b_IsApprovalScreen)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_ForfeitureSetup.dt_ForfeitureSetupUI == null || ac_ForfeitureSetup.dt_ForfeitureSetupUI.Rows.Count.Equals(0))
                    {
                        ac_ForfeitureSetup.dt_ForfeitureSetupUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10_UI);
                    }
                    if ((ac_ForfeitureSetup.dt_ForfeitureSetupUI != null) && (ac_ForfeitureSetup.dt_ForfeitureSetupUI.Rows.Count > 0))
                    {
                        if (b_IsApprovalScreen)
                        {
                            forfeitureRateSettingsUC.divVPAApprovalGrid.Visible = true;
                            forfeitureRateSettingsUC.divForfeitureRateSettings.Visible = false;
                            foreach (Control control in forfeitureRateSettingsUC.divVPAApprovalGrid.Controls)
                            {
                                switch (control.GetType().FullName.ToUpper())
                                {
                                    case CommonConstantModel.s_wcLabel:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_ForfeitureSetup.dt_ForfeitureSetupUI, (Label)control, null, null, null, null, null, null, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcButton:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, (Button)control, null, null, null, null, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcGridview:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, null, null, (GridView)control, null);
                                        break;
                                }
                            }
                        }
                        else
                        {
                            forfeitureRateSettingsUC.divVPAApprovalGrid.Visible = false;
                            forfeitureRateSettingsUC.divForfeitureRateSettings.Visible = true;
                            foreach (Control control in forfeitureRateSettingsUC.divForfeitureRateSettings.Controls)
                            {
                                switch (control.GetType().FullName.ToUpper())
                                {
                                    case CommonConstantModel.s_wcLabel:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_ForfeitureSetup.dt_ForfeitureSetupUI, (Label)control, null, null, null, null, null, null, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcTextbox:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, (TextBox)control, null, null, null, null, null, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcButton:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, (Button)control, null, null, null, null, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcCheckbox:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeCheckBox, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, (CheckBox)control, null, null, null, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcRadiobutton:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, (RadioButton)control, null, null, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcRequiredFieldValidator:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, (BaseValidator)control, null, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcRugularExpressionValidator:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, (BaseValidator)control, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcGridview:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, null, null, (GridView)control, null);
                                        break;
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind/populate all the controls
        /// </summary>
        /// <param name="forfeitureRateSettingsUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="s_Type">s_Type</param>
        /// <param name="b_IsApprovalScreen">b_IsApprovalScreen</param>
        internal void BindFRSControls(ForfeitureRateSettingsUC forfeitureRateSettingsUC, string s_Type, bool b_IsApprovalScreen)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    if (!b_IsApprovalScreen)
                    {
                        accountingProperties.PopulateControls = CommonConstantModel.s_FRSRead;
                        ac_ForfeitureSetup.ds_ForfeitureRateSettings = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                        ac_ForfeitureSetup.dt_FRSDetails = ac_ForfeitureSetup.ds_ForfeitureRateSettings.Tables[0];
                        ac_ForfeitureSetup.dt_FRSHistoryData = ac_ForfeitureSetup.ds_ForfeitureRateSettings.Tables[1];
                        forfeitureRateSettingsUC.gvFRSDetails.DataSource = ac_ForfeitureSetup.dt_FRSHistoryData;
                        forfeitureRateSettingsUC.gvFRSDetails.DataBind();
                        if (ac_ForfeitureSetup.dt_FRSDetails.Rows.Count > 0 && s_Type.Equals("Page_Load"))
                        {
                            forfeitureRateSettingsUC.rdoTrueUpYes.Checked = ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["IS_TRUE_UP_CHECKED"].Equals("1") ? true : false;
                            forfeitureRateSettingsUC.rdoTrueUpNo.Checked = ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["IS_TRUE_UP_CHECKED"].Equals("1") ? false : true;
                            forfeitureRateSettingsUC.rdoCancelationDate.Checked = ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["IS_TRUE_UP_CHECKED"].Equals("1") ? true : false;
                            forfeitureRateSettingsUC.rdoVestingDate.Checked = ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["IS_TRUE_UP_VEST_DATE"].Equals("1") ? true : false;

                            if (Convert.ToString(ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["FORFEITURE_CALC_ON_LABEL_ID"]).Trim().Equals("lblFCO01"))
                            {
                                forfeitureRateSettingsUC.lblFCO01.Checked = true;
                                forfeitureRateSettingsUC.lblFCO02.Checked = false;
                            }
                            else if (Convert.ToString(ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["FORFEITURE_CALC_ON_LABEL_ID"]).Trim().Equals("lblFCO02"))
                            {
                                forfeitureRateSettingsUC.lblFCO01.Checked = false;
                                forfeitureRateSettingsUC.lblFCO02.Checked = true;
                                if (ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["IS_LAPSED_OPTIONS_CHECKED"].Equals("1"))
                                    forfeitureRateSettingsUC.chkFRSLapsedOptions.Checked = true;
                                if (ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["IS_VESTED_CANCELLED_CHECKED"].Equals("1"))
                                    forfeitureRateSettingsUC.chkFRSVestedCancelled.Checked = true;
                                if (ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["IS_UNVESTED_CANCELLED_CHECKED"].Equals("1"))
                                    forfeitureRateSettingsUC.chkFRSUnvestedCancelled.Checked = true;
                            }
                            forfeitureRateSettingsUC.hdnFRSAppFromDate.Value = forfeitureRateSettingsUC.txtFRSApplFromDate.Text = Convert.ToDateTime(ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["APPLICABLE_FROM_DATE"]).ToString("dd/MMM/yyyy");
                            forfeitureRateSettingsUC.txtFRSRemark.Text = Convert.ToString(ac_ForfeitureSetup.dt_FRSDetails.Rows[0]["Remark"]);
                            forfeitureRateSettingsUC.btnFRSSave.Text = ForfeitureSetupModel.s_BtnFRSUpdateText;
                            SetApprovalHiddenField(forfeitureRateSettingsUC);
                        }
                    }
                    else
                    {
                        accountingProperties.PopulateControls = CommonConstantModel.s_FRSApprovalData;
                        ac_ForfeitureSetup.dt_ForfeitreRteSettgsToApprve = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                        forfeitureRateSettingsUC.gvFRSApprovalGrid.DataSource = ac_ForfeitureSetup.dt_ForfeitreRteSettgsToApprve;
                        forfeitureRateSettingsUC.gvFRSApprovalGrid.DataBind();
                        if (ac_ForfeitureSetup.dt_ForfeitreRteSettgsToApprve.Rows.Count > 0)
                            forfeitureRateSettingsUC.btnFRSApprove.Enabled = forfeitureRateSettingsUC.btnFRSDisApprove.Enabled = true;
                        else forfeitureRateSettingsUC.btnFRSApprove.Enabled = forfeitureRateSettingsUC.btnFRSDisApprove.Enabled = false;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to set hidden field to check approval status
        /// </summary>
        /// <param name="forfeitureRateSettingsUC">ForfeitureRateSettings page object</param>
        public void SetApprovalHiddenField(ForfeitureRateSettingsUC forfeitureRateSettingsUC)
        {
            try
            {
                bool s_IsApproved = (from query in ac_ForfeitureSetup.dt_FRSHistoryData.AsEnumerable()
                                     where query.Field<string>("Approval Status") == "Pending"
                                     select query.Field<string>("Approval Status")).Distinct().Count() > 0 ? false : true;
                forfeitureRateSettingsUC.hdnFRS_IsApproved.Value = s_IsApproved ? "1" : "0";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="forfeitureRateSettingsUC">ForfeitureRateSettings page object</param>
        internal int btnFRSSave_Click(ForfeitureRateSettingsUC forfeitureRateSettingsUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    accountingProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    accountingProperties.PopulateControls = CommonConstantModel.s_ForfeitureRateSettings;
                    if (userSessionInfo.ACC_UerTypeID.Equals(5))
                        accountingProperties.IS_APPROVED = true;
                    else accountingProperties.IS_APPROVED = false;
                    accountingProperties.IS_TRUE_UP_CHECKED = forfeitureRateSettingsUC.rdoTrueUpYes.Checked ? true : false;

                    if (forfeitureRateSettingsUC.rdoCancelationDate.Checked)
                    {
                        accountingProperties.IS_TRUE_UP_CANCEL_DATE = forfeitureRateSettingsUC.rdoCancelationDate.Checked ? true : false;
                    }
                    else 
                    {
                        accountingProperties.IS_TRUE_UP_VEST_DATE = forfeitureRateSettingsUC.rdoVestingDate.Checked ? true : false;
                    }

                    if (forfeitureRateSettingsUC.lblFCO01.Checked)
                    {
                        accountingProperties.FORFEITURE_CALC_ON_LABEL_ID = forfeitureRateSettingsUC.lblFCO01.ID.Trim();
                        accountingProperties.IS_LAPSED_OPTIONS_CHECKED = accountingProperties.IS_VESTED_CANCELLED_CHECKED = accountingProperties.IS_UNVESTED_CANCELLED_CHECKED = false;
                    }
                    else if (forfeitureRateSettingsUC.lblFCO02.Checked)
                    {
                        accountingProperties.FORFEITURE_CALC_ON_LABEL_ID = forfeitureRateSettingsUC.lblFCO02.ID.Trim();
                        accountingProperties.IS_LAPSED_OPTIONS_CHECKED = forfeitureRateSettingsUC.chkFRSLapsedOptions.Checked ? true : false;
                        accountingProperties.IS_VESTED_CANCELLED_CHECKED = forfeitureRateSettingsUC.chkFRSVestedCancelled.Checked ? true : false;
                        accountingProperties.IS_UNVESTED_CANCELLED_CHECKED = forfeitureRateSettingsUC.chkFRSUnvestedCancelled.Checked ? true : false;
                    }
                    accountingProperties.REMARK = forfeitureRateSettingsUC.txtFRSRemark.Text;
                    accountingProperties.APPLICABLE_FROM_DATE = forfeitureRateSettingsUC.txtFRSApplFromDate.Text;
                    //Check whether report is locked or not for entered FR_AppDate
                    if (!CommonModel.CheckAgainstLockedAccountingReport(Convert.ToString(accountingProperties.APPLICABLE_FROM_DATE), userSessionInfo))
                    {
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                        if (accountingCRUDProperties.a_result.Equals(1))
                        {
                            SetButtonText(forfeitureRateSettingsUC.btnFRSSave);
                        }

                        return accountingCRUDProperties.a_result;
                    }
                    else
                    {
                        //set accountingProperties.a_result = 6  if accounting report is locked for FR_EffectiveDate
                        return  (!forfeitureRateSettingsUC.hdnUpdateRecord.Value.Equals("U")) ? 6: 7 ;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to set button text and tool-tip
        /// </summary>
        /// <param name="o_Button">Button control object</param>
        public void SetButtonText(Button o_Button)
        {
            // case "BTNAPSSAVE": o_Button.Text = s_BtnAPSUpdateText; o_Button.ToolTip = s_BtnAPSUpdateTooltip; break;
        }

        /// <summary>
        /// Forfeiture Rate Settings grid-view page index change event
        /// </summary>
        /// <param name="forfeitureRateSettingsUC">ForfeitureRateSettings page object</param>
        /// <param name="e">event args</param>
        internal void gvFRSDetails_PageIndexChanging(ForfeitureRateSettingsUC forfeitureRateSettingsUC, GridViewPageEventArgs e)
        {
            try
            {
                forfeitureRateSettingsUC.gvFRSDetails.PageIndex = e.NewPageIndex;
                forfeitureRateSettingsUC.gvFRSDetails.DataSource = ac_ForfeitureSetup.dt_FRSHistoryData;
                forfeitureRateSettingsUC.gvFRSDetails.DataBind();

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        /// <param name="n_Index"></param>
        /// <param name="n_True_Up"></param>
        /// <param name="n_Forfeiture_Calculation_On"></param>
        /// <param name="n_IS_LAPSED_OPTIONS_CHECKED"></param>
        /// <param name="n_IS_VESTED_CANCELLED_CHECKED"></param>
        /// <param name="n_IS_UNVESTED_CANCELLED_CHECKED"></param>
        /// <param name="n_Remark"></param>
        /// <param name="n_Applicable_From_Date"></param>
        /// <param name="n_To_Date"></param>
        /// <param name="n_FRSID"></param>
        /// <param name="n_Approval_Status"></param>
        /// <param name="n_View_History_Data"></param>
        internal void gvFRSDetails_RowDataBound(GridViewRowEventArgs e, ref int n_Index, ref int n_True_Up, ref int n_Forfeiture_Calculation_On, ref int n_IS_LAPSED_OPTIONS_CHECKED, ref int n_IS_VESTED_CANCELLED_CHECKED, ref int n_IS_UNVESTED_CANCELLED_CHECKED, ref int n_Remark, ref int n_Applicable_From_Date, ref int n_To_Date, ref int n_FRSID, ref int n_Approval_Status, ref int n_View_History_Data)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "TRUE UP":
                                    n_True_Up = n_Index;
                                    break;
                                case "FORFEITURE CALCULATION ON":
                                    n_Forfeiture_Calculation_On = n_Index;
                                    break;
                                case "IS_LAPSED_OPTIONS_CHECKED":
                                    n_IS_LAPSED_OPTIONS_CHECKED = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "IS_VESTED_CANCELLED_CHECKED":
                                    n_IS_VESTED_CANCELLED_CHECKED = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "IS_UNVESTED_CANCELLED_CHECKED":
                                    n_IS_UNVESTED_CANCELLED_CHECKED = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "REMARK":
                                    n_Remark = n_Index;
                                    break;
                                case "APPLICABLE FROM DATE":
                                    n_Applicable_From_Date = n_Index;
                                    break;
                                case "TO DATE":
                                    n_To_Date = n_Index;
                                    break;
                                case "FRSID":
                                    n_FRSID = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "APPROVAL STATUS":
                                    n_Approval_Status = n_Index;
                                    break;
                                case "VIEW HISTORY":
                                    n_View_History_Data = n_Index;
                                    break;
                            }
                            n_Index++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_FRSID].Visible = e.Row.Cells[n_IS_LAPSED_OPTIONS_CHECKED].Visible = e.Row.Cells[n_IS_VESTED_CANCELLED_CHECKED].Visible = e.Row.Cells[n_IS_UNVESTED_CANCELLED_CHECKED].Visible = false;
                        e.Row.Cells[n_Applicable_From_Date].HorizontalAlign = e.Row.Cells[n_To_Date].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Applicable_From_Date].Text) && !e.Row.Cells[n_Applicable_From_Date].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_Applicable_From_Date].Text = Convert.ToDateTime(e.Row.Cells[n_Applicable_From_Date].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_To_Date].Text) && !e.Row.Cells[n_To_Date].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_To_Date].Text = Convert.ToDateTime(e.Row.Cells[n_To_Date].Text).ToString("dd/MMM/yyyy");

                        e.Row.Cells[n_Remark].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;");

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Forfeiture_Calculation_On].Text) && !e.Row.Cells[n_Forfeiture_Calculation_On].Text.Equals("&nbsp;"))
                        {
                            if ((e.Row.Cells[n_Forfeiture_Calculation_On].Text.Trim().Equals("lblFCO02")))
                            {
                                string s_Concat = string.Empty;
                                if (e.Row.Cells[n_IS_LAPSED_OPTIONS_CHECKED].Text.Equals("1"))
                                {
                                    s_Concat += " ( " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSLapsedOptions'"))[0]["LabelName"]);
                                }
                                if (e.Row.Cells[n_IS_VESTED_CANCELLED_CHECKED].Text.Equals("1"))
                                {
                                    if (string.IsNullOrEmpty(s_Concat))
                                        s_Concat += " ( " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSVestedCancelled'"))[0]["LabelName"]);
                                    else s_Concat += " , " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSVestedCancelled'"))[0]["LabelName"]);
                                }
                                if (e.Row.Cells[n_IS_UNVESTED_CANCELLED_CHECKED].Text.Equals("1"))
                                {
                                    if (string.IsNullOrEmpty(s_Concat))
                                        s_Concat += " ( " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSUnvestedCancelled'"))[0]["LabelName"]);
                                    else s_Concat += " , " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSUnvestedCancelled'"))[0]["LabelName"]);
                                }
                                if (!string.IsNullOrEmpty(s_Concat))
                                    s_Concat += " ) ";
                                e.Row.Cells[n_Forfeiture_Calculation_On].Text = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_Forfeiture_Calculation_On].Text.Trim() + "'" + ""))[0]["LabelName"]) + s_Concat;
                            }
                            else
                                e.Row.Cells[n_Forfeiture_Calculation_On].Text = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_Forfeiture_Calculation_On].Text.Trim() + "'" + ""))[0]["LabelName"]);
                        }
                        e.Row.Cells[n_Forfeiture_Calculation_On].Attributes.Add("style", "text-wrap:normal; word-wrap: break-word; max-width: 150px;");
                        e.Row.Cells[n_View_History_Data].Controls.Add((Control)AddHistoryHyperLink(e.Row.Cells[n_FRSID].Text));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="e">event args</param>
        /// <param name="n_Appr_Index">n_Appr_PARAMETERS</param>
        /// <param name="n_Appr_PARAMETERS">n_Appr_PARAMETERS</param>
        /// <param name="n_Appr_PREVIOUSSETTINGS">n_Appr_PREVIOUSSETTINGS</param>
        /// <param name="n_Appr_CURRENTSETTINGS">n_Appr_CURRENTSETTINGS</param>
        /// <param name="n_Appr_FRSAID">n_Appr_FRSAID</param>
        /// <param name="forfeitureRateSettingsUC">ForfeitureRateSettings page object</param>
        internal void gvFRSApprovalGrid_RowDataBound(GridViewRowEventArgs e, ref int n_Appr_Index, ref int n_Appr_PARAMETERS, ref int n_Appr_PREVIOUSSETTINGS, ref int n_Appr_CURRENTSETTINGS, ref int n_Appr_FRSAID, ForfeitureRateSettingsUC forfeitureRateSettingsUC)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "PARAMETERS":
                                    n_Appr_PARAMETERS = n_Appr_Index;
                                    break;
                                case "PREVIOUS SETTINGS":
                                    n_Appr_PREVIOUSSETTINGS = n_Appr_Index;
                                    break;
                                case "CURRENT SETTINGS":
                                    n_Appr_CURRENTSETTINGS = n_Appr_Index;
                                    break;
                                case "FRSAID":
                                    n_Appr_FRSAID = n_Appr_Index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_Appr_Index++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_Appr_FRSAID].Visible = false;
                        e.Row.Cells[n_Appr_PREVIOUSSETTINGS].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;");
                        e.Row.Cells[n_Appr_CURRENTSETTINGS].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;");

                        e.Row.Cells[n_Appr_PREVIOUSSETTINGS].Controls.Add(AddBulletedList(e.Row.Cells[n_Appr_PREVIOUSSETTINGS].Text, "PreviousSettings"));
                        e.Row.Cells[n_Appr_CURRENTSETTINGS].Controls.Add(AddBulletedList(e.Row.Cells[n_Appr_CURRENTSETTINGS].Text, "CurrentSettings"));

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Appr_PREVIOUSSETTINGS].Text) && !string.IsNullOrEmpty(e.Row.Cells[n_Appr_CURRENTSETTINGS].Text) && !e.Row.Cells[n_Appr_PREVIOUSSETTINGS].Text.Equals("&nbsp;") && !e.Row.Cells[n_Appr_CURRENTSETTINGS].Text.Equals("&nbsp;") && e.Row.Cells[n_Appr_PREVIOUSSETTINGS].Text != e.Row.Cells[n_Appr_CURRENTSETTINGS].Text)
                            e.Row.Cells[n_Appr_PREVIOUSSETTINGS].Attributes.Add("style", "color:green;");

                        e.Row.Cells[n_Appr_PREVIOUSSETTINGS].Width = e.Row.Cells[n_Appr_CURRENTSETTINGS].Width = 400;
                        e.Row.Cells[n_Appr_PARAMETERS].Width = 200;
                        SetConfigIDsToHdnFields(e.Row.Cells[n_Appr_FRSAID].Text, forfeitureRateSettingsUC);
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to set Config ID's to hidden fields
        /// </summary>
        /// <param name="s_FRSAID">s_FRSAID : primary key</param>
        /// <param name="forfeitureRateSettingsUC">ForfeitureRateSettings page object</param>
        private void SetConfigIDsToHdnFields(string s_FRSAID, ForfeitureRateSettingsUC forfeitureRateSettingsUC)
        {
            if (!string.IsNullOrEmpty(s_FRSAID) || !s_FRSAID.Equals("&nbsp;"))
            {
                forfeitureRateSettingsUC.hdnFRSIDToApprove.Value = s_FRSAID;
            }
        }

        /// <summary>
        /// This method is used to get bulleted list object
        /// </summary>
        /// <param name="s_Parameters">~ separated string object</param>
        /// <param name="s_Settings">Setting Type</param>
        /// <returns></returns>
        private BulletedList AddBulletedList(string s_Parameters, string s_Settings)
        {
            using (BulletedList bulletedList = new BulletedList())
            {
                string[] Parameters = s_Parameters.Split('~');
                string s_ItemToAdd = string.Empty;
                string s_IS_TRUE_UP_CHECKED = string.Empty, s_FORFEITURE_CALC_ON_LABEL_ID = string.Empty,
                    s_IS_LAPSED_OPTIONS_CHECKED = string.Empty, s_IS_VESTED_CANCELLED_CHECKED = string.Empty, s_IS_UNVESTED_CANCELLED_CHECKED = string.Empty;
                foreach (string item in Parameters)
                {
                    string[] s_Items = item.Split(':');
                    switch (s_Items[0])
                    {
                        case "IS_TRUE_UP_CHECKED": s_IS_TRUE_UP_CHECKED = s_Items[1]; break;
                        case "FORFEITURE_CALC_ON_LABEL_ID": s_FORFEITURE_CALC_ON_LABEL_ID = s_Items[1]; break;
                        case "IS_LAPSED_OPTIONS_CHECKED": s_IS_LAPSED_OPTIONS_CHECKED = s_Items[1]; break;
                        case "IS_VESTED_CANCELLED_CHECKED": s_IS_VESTED_CANCELLED_CHECKED = s_Items[1]; break;
                        case "IS_UNVESTED_CANCELLED_CHECKED": s_IS_UNVESTED_CANCELLED_CHECKED = s_Items[1]; break;
                    }
                }
                if (!string.IsNullOrEmpty(s_IS_TRUE_UP_CHECKED))
                {
                    bulletedList.Items.Add(s_IS_TRUE_UP_CHECKED.Equals("1") ? "Yes" : "No");
                }
                if (!string.IsNullOrEmpty(s_FORFEITURE_CALC_ON_LABEL_ID))
                {
                    s_ItemToAdd = string.Empty;
                    if (s_FORFEITURE_CALC_ON_LABEL_ID.Trim().Equals("lblFCO02"))
                    {
                        string s_Concat = string.Empty;
                        if (s_IS_LAPSED_OPTIONS_CHECKED.Equals("1"))
                        {
                            s_Concat += " ( " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSLapsedOptions'"))[0]["LabelName"]);
                        }
                        if (s_IS_VESTED_CANCELLED_CHECKED.Equals("1"))
                        {
                            if (string.IsNullOrEmpty(s_Concat))
                                s_Concat += " ( " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSVestedCancelled'"))[0]["LabelName"]);
                            else s_Concat += " , " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSVestedCancelled'"))[0]["LabelName"]);
                        }
                        if (s_IS_UNVESTED_CANCELLED_CHECKED.Equals("1"))
                        {
                            if (string.IsNullOrEmpty(s_Concat))
                                s_Concat += " ( " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSUnvestedCancelled'"))[0]["LabelName"]);
                            else s_Concat += " , " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSUnvestedCancelled'"))[0]["LabelName"]);
                        }
                        if (!string.IsNullOrEmpty(s_Concat))
                            s_Concat += " ) ";
                        s_ItemToAdd = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = " + "'" + s_FORFEITURE_CALC_ON_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + s_Concat;
                    }
                    else
                        s_ItemToAdd = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = " + "'" + s_FORFEITURE_CALC_ON_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]);
                    bulletedList.Items.Add(s_ItemToAdd);
                }
                return bulletedList;
            }
        }

        /// <summary>
        /// This method is used to add image link to grid-view rows
        /// </summary>
        /// <param name="s_FRSID">The Id for which link should be displayed</param>
        /// <returns>Returns control HyperLink</returns>
        public HyperLink AddHistoryHyperLink(string s_FRSID)
        {
            using (HyperLink hyperLink = new HyperLink())
            {
                hyperLink.Text = "View History";
                hyperLink.ToolTip = "Click here to view history data";
                hyperLink.ID = "hypFRSHistory";
                hyperLink.ClientIDMode = ClientIDMode.Static;
                hyperLink.CssClass = "cHyperLinksp";
                hyperLink.TabIndex = 9;
                hyperLink.Attributes.Add("onclick", "return ViewFRSHistoryData('" + s_FRSID + "')");
                return hyperLink;
            }
        }

        /// <summary>
        /// Method is used to bind history data to grid
        /// </summary>
        /// <param name="o_FRSID">o_FRSID</param>
        /// <returns></returns>
        public AccountingProperties[] BindFRSHistoryGrid(object o_FRSID)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    List<AccountingProperties> o_Details = new List<AccountingProperties>();
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "FRS_HISTORY_DATA";
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.FRSID = Convert.ToInt32(o_FRSID);
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    foreach (DataRow dtrow in accountingCRUDProperties.dt_Result.Rows)
                    {
                        accountingProperties = new AccountingProperties();
                        accountingProperties.IS_TRUE_UP_CHECKED = Convert.ToString(dtrow["IS_TRUE_UP_CHECKED"]).Equals("1") ? true : false;
                        if (!string.IsNullOrEmpty(Convert.ToString(dtrow["FORFEITURE_CALC_ON_LABEL_ID"])) && !Convert.ToString(dtrow["FORFEITURE_CALC_ON_LABEL_ID"]).Equals("&nbsp;"))
                        {
                            if (Convert.ToString(dtrow["FORFEITURE_CALC_ON_LABEL_ID"]).Trim().Equals("lblFCO02"))
                            {
                                string s_Concat = string.Empty;
                                if (Convert.ToString(dtrow["IS_LAPSED_OPTIONS_CHECKED"]).Equals("1"))
                                {
                                    s_Concat += " ( " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSLapsedOptions'"))[0]["LabelName"]);
                                }
                                if (Convert.ToString(dtrow["IS_VESTED_CANCELLED_CHECKED"]).Equals("1"))
                                {
                                    if (string.IsNullOrEmpty(s_Concat))
                                        s_Concat += " ( " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSVestedCancelled'"))[0]["LabelName"]);
                                    else s_Concat += " , " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSVestedCancelled'"))[0]["LabelName"]);
                                }
                                if (Convert.ToString(dtrow["IS_UNVESTED_CANCELLED_CHECKED"]).Equals("1"))
                                {
                                    if (string.IsNullOrEmpty(s_Concat))
                                        s_Concat += " ( " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSUnvestedCancelled'"))[0]["LabelName"]);
                                    else s_Concat += " , " + Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'chkFRSUnvestedCancelled'"))[0]["LabelName"]);
                                }
                                if (!string.IsNullOrEmpty(s_Concat))
                                    s_Concat += " ) ";
                                accountingProperties.FORFEITURE_CALC_ON_LABEL_ID = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = " + "'" + Convert.ToString(dtrow["FORFEITURE_CALC_ON_LABEL_ID"]).Trim() + "'" + ""))[0]["LabelName"]) + s_Concat;
                            }
                            else
                                accountingProperties.FORFEITURE_CALC_ON_LABEL_ID = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = " + "'" + Convert.ToString(dtrow["FORFEITURE_CALC_ON_LABEL_ID"]).Trim() + "'" + ""))[0]["LabelName"]);
                        }
                        accountingProperties.REMARK = Convert.ToString(dtrow["REMARK"]);
                        if (!string.IsNullOrEmpty(Convert.ToString(dtrow["APPLICABLE_FROM_DATE"])))
                            accountingProperties.APPLICABLE_FROM_DATE = Convert.ToDateTime(Convert.ToString(dtrow["APPLICABLE_FROM_DATE"])).ToString("dd/MMM/yyyy");
                        if (!string.IsNullOrEmpty(Convert.ToString(dtrow["TO_DATE"])))
                            accountingProperties.APPLICABLE_TO_DATE = Convert.ToDateTime(Convert.ToString(dtrow["TO_DATE"])).ToString("dd/MMM/yyyy");
                        else accountingProperties.APPLICABLE_TO_DATE = string.Empty;
                        accountingProperties.APPROVAL_STATUS = Convert.ToString(dtrow["Approval Status"]);
                        o_Details.Add(accountingProperties);
                    }
                    return o_Details.ToArray();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Button click event to approve/disapprove valuation parameters
        /// </summary>
        /// <param name="forfeitureRateSettingsUC">ForfeitureRateSettings page object</param>
        /// <param name="b_IsApproved">boolean value for approve/disapprove</param>
        public int btnFRSApprove_Click(ForfeitureRateSettingsUC forfeitureRateSettingsUC, bool b_IsApproved)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.IS_APPROVED = b_IsApproved;
                    if (!string.IsNullOrEmpty(forfeitureRateSettingsUC.hdnFRSIDToApprove.Value))
                    {
                        accountingProperties.FRSAID = Convert.ToInt32(forfeitureRateSettingsUC.hdnFRSIDToApprove.Value);
                    }
                    accountingProperties.PopulateControls = "FRS_UPDATE_STATUS";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    forfeitureRateSettingsUC.hdnFRSIDToApprove.Value = string.Empty;
                    
                    forfeitureRateSettingsUC.gvFRSApprovalGrid.DataSource = null;
                    forfeitureRateSettingsUC.gvFRSApprovalGrid.DataBind();
                    forfeitureRateSettingsUC.btnFRSApprove.Enabled = forfeitureRateSettingsUC.btnFRSDisApprove.Enabled = false;
                    return accountingCRUDProperties.a_result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Button click event to approve/disapprove valuation parameters
        /// </summary>
        /// <param name="forfeitureRateSettingsUC">ForfeitureRateSettings page object</param>
        /// <param name="b_IsApproved">boolean value for approve/disapprove</param>
        public int btnFRSDisApprove_Click(ForfeitureRateSettingsUC forfeitureRateSettingsUC, bool b_IsApproved)
        {
            try
            {
                return btnFRSApprove_Click(forfeitureRateSettingsUC, b_IsApproved);
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Destructor
        /// <summary>
        /// Default Destructor
        /// </summary>
        ~ForfeitureRateSettingsModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}