﻿using EDFinancials.Model.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;
using System.Linq;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// EmployeeAssociationModel class
    /// </summary>
    public class EmployeeAssociationModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_ErrorOccured = string.Empty, s_Created = string.Empty, s_Updated = string.Empty, s_Deleted = string.Empty, s_AlreadyExists = string.Empty;

        #region Default constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public EmployeeAssociationModel()
        {
            if (ac_GrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_GrantDetails);
                ac_GrantDetails = (CommonModel.AC_GrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_GrantDetails];
            }

            if (ac_SearchGrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_SearchGrantDetails);
                ac_SearchGrantDetails = (CommonModel.AC_SearchGrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_SearchGrantDetails];
            }
        }
        #endregion

        /// <summary>
        /// This method is used to View Uploaded Document
        /// </summary>
        /// <param name="s_GrantID">GrantID</param>
        internal string BindEmployeeDetails(string s_GrantID)
        {
            try
            {
                string s_Data = string.Empty;

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    using (DataSet dataSet = new DataSet())
                    {
                        DateTime? nullDate = null;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.PageName = CommonConstantModel.s_GetOptionsDetails;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                        accountingProperties.ReportDate = nullDate;
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                        using (DataTable dt_EmployeeDetails = new DataTable("dt_EmployeeDetails"))
                        {
                            dt_EmployeeDetails.Columns.Add("EMPLOYEE_ID", typeof(string));
                            dt_EmployeeDetails.Columns.Add("EMPLOYEE_NAME", typeof(string));
                            dt_EmployeeDetails.Columns.Add("GRANTED_OPTIONS", typeof(string));
                            dt_EmployeeDetails.Columns.Add("Grant Option ID", typeof(string));
                            DataRow dr_EmployeeDetails;

                            foreach (DataRow perRow in accountingCRUDProperties.ds_Result.Tables[0].Select("[GRANT REGISTRATION ID] = '" + s_GrantID + "'"))
                            {
                                dr_EmployeeDetails = dt_EmployeeDetails.NewRow();
                                dr_EmployeeDetails["EMPLOYEE_ID"] = Convert.ToString(perRow["Employee ID"]);
                                dr_EmployeeDetails["EMPLOYEE_NAME"] = Convert.ToString(perRow["Employee Name"]);
                                dr_EmployeeDetails["GRANTED_OPTIONS"] = string.IsNullOrEmpty(Convert.ToString(perRow["Granted"])) ? 0 : Convert.ToInt64(perRow["Granted"]);
                                dr_EmployeeDetails["Grant Option ID"] = Convert.ToString(perRow["Grant Option ID"]);

                                dt_EmployeeDetails.Rows.Add(dr_EmployeeDetails);
                            }
                            dataSet.Tables.Add(dt_EmployeeDetails);
                        }

                        if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                        {
                            using (DataTable dt_EmployeeDetails_V = accountingCRUDProperties.ds_Result.Tables[1].Copy())
                            {
                                dt_EmployeeDetails_V.TableName = "dt_EmployeeDetails_V";
                                dataSet.Tables.Add(dt_EmployeeDetails_V);
                            }
                        }
                        return DataSetToJSON(dataSet);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to View Uploaded Document
        /// </summary>
        /// <param name="s_GrantID">GrantID</param>
        internal string AssociateEmployee(string s_GrantID)
        {
            try
            {
                DataSet ds_EmployeeDetails = new DataSet();
                string s_GrantRegDate = string.Empty;

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    DateTime? nullDate = null;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_GetOptionsDetails;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.ReportDate = nullDate;

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    using (DataTable dt_EmployeeDetails = new DataTable("dt_EmployeeDetails"))
                    {
                        dt_EmployeeDetails.Columns.Add("Grant Option ID", typeof(string));
                        dt_EmployeeDetails.Columns.Add("Employee ID", typeof(string));
                        dt_EmployeeDetails.Columns.Add("Granted Options", typeof(string));

                        DataRow dr_EmployeeDetails;

                        foreach (DataRow perRow in accountingCRUDProperties.ds_Result.Tables[0].Select("[GRANT REGISTRATION ID] = '" + s_GrantID + "'"))
                        {
                            dr_EmployeeDetails = dt_EmployeeDetails.NewRow();
                            s_GrantRegDate = Convert.ToString(perRow["Grant Date"]);
                            dr_EmployeeDetails["Grant Option ID"] = Convert.ToString(perRow["GRANT OPTION ID"]);
                            dr_EmployeeDetails["Employee ID"] = Convert.ToString(perRow["Employee ID"]);
                            dr_EmployeeDetails["Granted Options"] = Convert.ToString(perRow["Granted"]);

                            dt_EmployeeDetails.Rows.Add(dr_EmployeeDetails);
                        }
                        ds_EmployeeDetails.Tables.Add(dt_EmployeeDetails);
                    }
                    using (DataTable dt_EmployeeIDDetails = accountingCRUDProperties.ds_Result.Tables[2].Copy())
                    {
                        dt_EmployeeIDDetails.TableName = "dt_EmployeeIDDetails";
                        ds_EmployeeDetails.Tables.Add(dt_EmployeeIDDetails);
                    }

                    if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                    {
                        using (DataTable dt_EmployeeDetails_V = accountingCRUDProperties.ds_Result.Tables[1].Copy())
                        {
                            dt_EmployeeDetails_V.TableName = "dt_EmployeeDetails_V";
                            ds_EmployeeDetails.Tables.Add(dt_EmployeeDetails_V);
                        }
                    }

                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_Get_Vesting_Schedule;
                    accountingProperties.Grant_ID = s_GrantID;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    using (DataTable dt_VestingSchedule = accountingCRUDProperties.dt_Result.Copy())
                    {
                        dt_VestingSchedule.TableName = "dt_VestingSchedule";
                        ds_EmployeeDetails.Tables.Add(dt_VestingSchedule);
                    }

                    using (AccountingServiceClient _accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties.PageName = CommonConstantModel.s_ValuationReport;
                        accountingProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                        accountingProperties.Grant_ID = s_GrantID;
                        accountingProperties.GET_DATA_TYPE = "VESTWISE";

                        accountingCRUDProperties = _accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.PageName = CommonConstantModel.s_Restrict_Corp_Action_Apply;
                        accountingProperties.Type = "RESTRICT_USER_CORP_ACTION_APPLIED";
                        accountingProperties.REPORTING_DATE = Convert.ToString(accountingCRUDProperties.ds_Result.Tables[0].Select("[GRANT REGISTRATION ID] = '" + s_GrantID + "'")[0]["Grant Date"]);
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    }
                    using (DataTable dt_CorpDetails = accountingCRUDProperties.ds_Result.Tables[0].Copy())
                    {
                        dt_CorpDetails.TableName = "dt_CorpDetails";
                        ds_EmployeeDetails.Tables.Add(dt_CorpDetails);
                    }
                }
                return DataSetToJSON(ds_EmployeeDetails);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Serialize Json object
        /// </summary>
        /// <param name="dataSet">Dataset used to </param>
        /// <returns>string</returns>
        private string DataSetToJSON(DataSet dataSet)
        {
            JavaScriptSerializer json = new JavaScriptSerializer();
            Dictionary<string, object> dictionary = new Dictionary<string, object>();

            foreach (DataTable dt in dataSet.Tables)
            {
                object[] arr = new object[dt.Rows.Count + 1];

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    arr[i] = dt.Rows[i].ItemArray;
                }

                dictionary.Add(dt.TableName, arr);
            }

            return json.Serialize(dictionary);
        }

        /// <summary>
        /// This method is used to Serialize Json object
        /// </summary>
        /// <param name="dt">Dataset used to </param>
        /// <returns>string</returns>
        private string DataTableToJSON(DataTable dt)
        {
            JavaScriptSerializer json = new JavaScriptSerializer();
            Dictionary<string, object> dictionary = new Dictionary<string, object>();

            object[] arr = new object[dt.Rows.Count + 1];

            for (int i = 0; i <= dt.Rows.Count - 1; i++)
            {
                arr[i] = dt.Rows[i].ItemArray;
            }

            dictionary.Add(dt.TableName, arr);

            return json.Serialize(dictionary);
        }

        /// <summary>
        /// This method is used to perform CRUD operation
        /// </summary>
        /// <param name="s_GratID">string GratID</param>
        /// <param name="s_GrantOptionID">string GrantOptionID</param>
        /// <param name="s_EmployeeID">string EmployeeID</param>
        /// <param name="n_GrantedOptions">int GrantedOptions</param>
        /// <param name="a_GrantedOptions">array GrantedOptions</param>
        /// <param name="s_Action">string Action</param>
        /// <returns>string array</returns>
        internal string[] CUD_AssociateEmployee(string s_GratID, string s_GrantOptionID, string s_EmployeeID, int n_GrantedOptions, object a_GrantedOptions, string s_Action)
        {
            try
            {
                string[] s_Result = new string[3];

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CUDAssociateEmployees;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;

                    accountingProperties.SEN_CalculationMethod = userSessionInfo.ACC_CalculationMethod;
                    accountingProperties.Action = s_Action.Equals("imgSave") ? "C" : s_Action.Equals("imgEdit1") ? "U" : s_Action.Equals("imgDelete") ? "D" : string.Empty;
                    accountingProperties.Grant_ID = s_GratID;
                    accountingProperties.s_GrantOptionID = s_GrantOptionID;
                    accountingProperties.s_EmployeeID = s_EmployeeID;
                    accountingProperties.s_CaluationMethod = Convert.ToString(userSessionInfo.ACC_CalculationMethod);
                    accountingProperties.n_GrantedOptions = n_GrantedOptions;
                    accountingProperties.dt_GrantedOptionsVest = CreateTable(s_GrantOptionID, a_GrantedOptions);
                    accountingProperties.n_OperationID = 4;
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    accountingProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    s_Result[0] = accountingCRUDProperties.a_result.ToString();

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblGDError", CommonConstantModel.s_EmployeeAccosiation, CommonConstantModel.s_AccountingL10);
                            break;

                        case 1:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblGDCreated", CommonConstantModel.s_EmployeeAccosiation, CommonConstantModel.s_AccountingL10);
                            break;

                        case 2:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblGDUpdated", CommonConstantModel.s_EmployeeAccosiation, CommonConstantModel.s_AccountingL10);
                            break;

                        case 3:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblGDDeleted", CommonConstantModel.s_EmployeeAccosiation, CommonConstantModel.s_AccountingL10);
                            break;

                        case 5:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblGDIsExist", CommonConstantModel.s_EmployeeAccosiation, CommonConstantModel.s_AccountingL10);
                            break;

                        case 6:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblGDLocked", CommonConstantModel.s_EmployeeAccosiation, CommonConstantModel.s_AccountingL10);
                            break;
                    }

                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_Get_Vesting_Schedule;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.Grant_ID = s_GratID;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    using (DataTable dt_VestingSchedule = accountingCRUDProperties.dt_Result.Copy())
                    {
                        dt_VestingSchedule.TableName = "dt_VestingSchedule";
                        s_Result[2] = DataTableToJSON(dt_VestingSchedule).Replace("{", string.Empty).Replace("}", string.Empty).Replace("[", string.Empty).Replace("]", string.Empty).Replace("\"", string.Empty).Replace("dt_VestingSchedule:", string.Empty);
                    }
                    
                    return s_Result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Get Vesting Schedule
        /// </summary>
        /// <param name="s_GrantID">Grant ID</param>
        /// <returns>string[]</returns>
        internal string[] GetVestingSchedule(string s_GrantID)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                string[] s_Result = new string[2];
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.PageName = CommonConstantModel.s_Get_Vesting_Schedule;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingProperties.Grant_ID = s_GrantID;
                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                using (DataTable dt_VestingSchedule = accountingCRUDProperties.dt_Result.Copy())
                {
                    dt_VestingSchedule.TableName = "dt_VestingSchedule";
                    s_Result[0] = DataTableToJSON(dt_VestingSchedule).Replace("{", string.Empty).Replace("}", string.Empty).Replace("[", string.Empty).Replace("]", string.Empty).Replace("\"", string.Empty).Replace("dt_VestingSchedule:", string.Empty);
                }
                return s_Result;
            }
        }
        /// <summary>
        /// This method is used to store vestwise data
        /// </summary>
        /// <param name="s_GrantOptionID">GrantOptionID</param>
        /// <param name="a_GrantedOptions">GrantedOptions</param>
        /// <returns>DataTable</returns>
        private DataTable CreateTable(string s_GrantOptionID, object a_GrantedOptions)
        {
            string[] s_GrantedOptions = Array.ConvertAll(Convert.ToString(a_GrantedOptions).Split(','), Convert.ToString);

            DataTable dataTable = new DataTable("dt_VestwiseData");


            dataTable.Columns.Add("OPT_GRANTED_ID", typeof(string));
            dataTable.Columns.Add("AGRMID", typeof(Int32));
            dataTable.Columns.Add("GRANT_OPTION_ID", typeof(string));
            dataTable.Columns.Add("EMPID", typeof(Int32));
            dataTable.Columns.Add("VPD_VESTING_PERIOD_ID", typeof(Int32));
            dataTable.Columns.Add("VPD_VESTING_DATE", typeof(DateTime));
            dataTable.Columns.Add("GRANTED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("CANCELLED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("VESTED_CANCELLED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("UNVESTED_CANCELLED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("CANCELLATION_DATE", typeof(DateTime));
            dataTable.Columns.Add("LAPSED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("LAPSED_DATE", typeof(DateTime));
            dataTable.Columns.Add("EXERCISED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("EXERCISED_DATE", typeof(DateTime));
            dataTable.Columns.Add("UNVESTED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("VESTED_AND_EXERCISABLE", typeof(Int32));
            dataTable.Columns.Add("OUTSTANDING_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("FORFEITURE_RATE", typeof(Int32));
            dataTable.Columns.Add("COST_AS_PER_SYSTEM", typeof(Decimal));
            dataTable.Columns.Add("H_COST_MANUALLY", typeof(Decimal));
            dataTable.Columns.Add("OPERATION_ID", typeof(Int32));
            dataTable.Columns.Add("OPERATION_DATE", typeof(DateTime));
            dataTable.Columns.Add("COST_AS_PER_SYSTEM_BY_FV", typeof(Decimal));
            dataTable.Columns.Add("COST_AS_PER_SYSTEM_BY_IV", typeof(Decimal));

            DataRow dr_GrantedOptionsVestwise;
            int n_count = 1;
            foreach (var perItem in s_GrantedOptions)
            {
                dr_GrantedOptionsVestwise = dataTable.NewRow();
                dr_GrantedOptionsVestwise["GRANT_OPTION_ID"] = s_GrantOptionID;
                dr_GrantedOptionsVestwise["OPERATION_ID"] = 4;
                dr_GrantedOptionsVestwise["GRANTED_OPTIONS"] = string.IsNullOrEmpty(perItem) ? 0 : Convert.ToInt32(perItem);
                dr_GrantedOptionsVestwise["VPD_VESTING_PERIOD_ID"] = n_count;
                n_count++;
                dataTable.Rows.Add(dr_GrantedOptionsVestwise);
            }

            return dataTable;
        }
        #region RowBound Event Of gvGVPGrantDetails GridView
        /// <summary>
        /// The RowBound Event Of gvGVPGrantDetails GridView
        /// </summary>
        /// <param name="employeeAssociationUC">employeeAssociationUC</param>
        /// <param name="sender">gvUGPGrantDetails GridView</param>
        /// <param name="e">e</param>
        /// <param name="n_UVPindex">Index n_UVPindex</param>
        /// <param name="n_Currency"> Currency n_Currency</param>
        /// <param name="n_ExPrc">Exercise Price n_ExPrc</param>
        /// <param name="n_VestDet">Vest Details n_VestDet</param>
        /// <param name="n_Ratio">Ratio n_Ratio</param>
        /// <param name="n_RowIndex">Row Index</param>
        /// <param name="n_AssociateEmployees">Associate Employees</param>
        /// <param name="n_GrantID">GrantID</param>
        /// <param name="n_VestCount">Vest Count</param>
        internal void gvCurrentGrants_RowDataBound(View.User.Accounting.UserControl.EmployeeAssociationUC employeeAssociationUC, object sender, System.Web.UI.WebControls.GridViewRowEventArgs e, ref int n_UVPindex, ref int n_Currency, ref int n_ExPrc, ref int n_VestDet, ref int n_Ratio, ref int n_RowIndex, ref int n_AssociateEmployees, ref int n_GrantID, ref int n_VestCount)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "CURRENCY":
                                    n_Currency = n_UVPindex;
                                    break;

                                case "EXERCISE PRICE":
                                    n_ExPrc = n_UVPindex;
                                    break;

                                case "VESTING DETAILS":
                                    n_VestDet = n_UVPindex;
                                    break;

                                case "RATIO OPTIONS TO SHARES":
                                    n_Ratio = n_UVPindex;
                                    break;

                                case "ASSOCIATE EMPLOYEES":
                                    n_AssociateEmployees = n_UVPindex;
                                    break;

                                case "GRANT ID":
                                    n_GrantID = n_UVPindex;
                                    break;

                                case "VEST COUNT":
                                    n_VestCount = n_UVPindex;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_UVPindex = n_UVPindex + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_VestCount].Visible = false;
                        e.Row.Cells[n_Currency].HorizontalAlign = e.Row.Cells[n_VestDet].HorizontalAlign = e.Row.Cells[n_Ratio].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_ExPrc].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_VestDet].Controls.Add(AddLinkButton("Click here to View Details", "View Details", "lbtnViewDetails", string.Empty, string.Empty));
                        e.Row.Cells[n_AssociateEmployees].Controls.Add(AddLinkButton("Click here to associate employees", "Associate", e.Row.Cells[n_GrantID].Text, e.Row.Cells[n_GrantID].Text, e.Row.Cells[n_VestCount].Text));
                        GridView parentGrid = (GridView)sender;

                        using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                        {
                            NewTotalRow.Font.Bold = true;
                            NewTotalRow.CssClass = "gridItems  gvChildGrid";
                            NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                            NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                            using (TableCell HeaderCell = new TableCell())
                            {
                                HeaderCell.Attributes.Add("Class", "gvChildGrid");
                                HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                HeaderCell.Height = 10;
                                HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                                HeaderCell.ColumnSpan = 9;

                                using (GridView childGrid = new GridView())
                                {
                                    childGrid.CssClass = "Grid";
                                    childGrid.RowStyle.CssClass = "gridItems";
                                    childGrid.CellPadding = 3;
                                    childGrid.CellSpacing = 0;
                                    childGrid.HeaderStyle.CssClass = "HeaderStyle";

                                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                                    {
                                        accountingProperties.PageName = CommonConstantModel.s_ValuationReport;
                                        accountingProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                                        accountingProperties.GET_DATA_TYPE = "VESTWISE";
                                        accountingProperties.Grant_ID = e.Row.Cells[1].Text;
                                        accountingProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;
                                        accountingProperties.SEN_IsMYESOPsClient = userSessionInfo.ACC_IsMYESOPsClient;
                                        accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                        accountingProperties.SEN_CompanyTitle = userSessionInfo.ACC_CompanyTitle;

                                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                                        childGrid.RowDataBound += employeeAssociationUC.childGrid_RowDataBound;
                                        childGrid.DataSource = new System.Data.DataView(accountingCRUDProperties.ds_Result.Tables[0]).ToTable("DT", true, new string[] { "Grant Registration ID", "Vesting Period Number", "Vesting Date", "Expiry Date", "Vest Percent (%)", "Currency" }).Copy();
                                        childGrid.DataBind();
                                    }

                                    HeaderCell.Controls.Add(childGrid);
                                    NewTotalRow.Cells.Add(HeaderCell);
                                    parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + n_RowIndex, NewTotalRow);
                                    n_RowIndex++;
                                }
                            }
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add link button
        /// </summary>
        /// <param name="s_Tooltip">Tooltip</param>
        /// <param name="s_Text">Text of the control</param>
        /// <param name="s_ControlID">Dynamic control ID</param>
        /// <param name="s_GrantID">Grant ID</param>
        /// <param name="s_VestCount">Vest Count</param>
        /// <returns>Link Button</returns>
        private LinkButton AddLinkButton(string s_Tooltip, string s_Text, string s_ControlID, string s_GrantID, string s_VestCount)
        {
            try
            {
                using (LinkButton linkButton = new LinkButton())
                {
                    linkButton.ToolTip = s_Tooltip;
                    linkButton.Text = s_Text;
                    linkButton.ID = s_ControlID;
                    linkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    linkButton.Style.Add("cursor", "pointer");

                    if (string.IsNullOrEmpty(s_GrantID))
                    {
                        linkButton.Attributes.Add("onclick", "return ViewVestDetails(this)");
                    }
                    else
                    {
                        linkButton.Attributes.Add("onclick", "return AssociateEmployees(this,'" + s_GrantID + "', '" + userSessionInfo.ACC_CalculationMethod + "', '" + s_VestCount + "')");
                    }
                    return linkButton;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// Row Data Bound Event Of Child GridView
        /// </summary>
        /// <param name="sender">Child GridView</param>
        /// <param name="e">e</param>
        internal void childGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~EmployeeAssociationModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}