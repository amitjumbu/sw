﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting.UserControl;
using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// The model class for CorporateActionCalcUC Page.
    /// </summary>
    public class CorporateActionCalcUCModel : BaseModel, IDisposable
    {
        #region Default Constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public CorporateActionCalcUCModel()
        {
            if (ac_CorporateActionAdjustment == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_CorporateActionAdjustment);
                ac_CorporateActionAdjustment = (CommonModel.AC_CorporateActionAdjustment)HttpContext.Current.Session[CommonConstantModel.s_AC_CorporateActionAdjustment];
            }
        }
        #endregion

        /// <summary>
        /// This method is used to Bind names to all controls of Page
        /// </summary>
        /// <param name="corporateActionCalcUC">corporateActionCalcUC Page Object</param>
        internal void BindUI(CorporateActionCalcUC corporateActionCalcUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    foreach (Control control in corporateActionCalcUC.divCAAUpdateCalc.Controls)
                    {
                        switch (control.GetType().FullName.ToUpper())
                        {
                            case CommonConstantModel.s_wcLabel:
                                CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_CorporateActionAdjustment.dt_CorpActionAdjUI, (Label)control, null, null, null, null, null, null, null, null, null);
                                break;

                            case CommonConstantModel.s_wcTextbox:
                                CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_CorporateActionAdjustment.dt_CorpActionAdjUI, null, (TextBox)control, null, null, null, null, null, null, null, null);
                                break;

                            case CommonConstantModel.s_wcButton:
                                CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_CorporateActionAdjustment.dt_CorpActionAdjUI, null, null, (Button)control, null, null, null, null, null, null, null);
                                break;
                        }
                    }

                    corporateActionCalcUC.hdnlblCAASumPreGreater.Value = accountingServiceClient.GetAccounting_L10N("lblCAASumPreGreater", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                    corporateActionCalcUC.hdnlblCAASumPostGreater.Value = accountingServiceClient.GetAccounting_L10N("lblCAASumPostGreater", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind value to all the labels and gvCAAUpdateCalcCorpAction GridView 
        /// </summary>
        /// <param name="corporateActionCalcUC">corporateActionCalcUC Page Object</param>
        /// <param name="s_GrantOptID">Grant Option ID</param>
        internal void btnCAAUpdateCorpActEffect_Click(CorporateActionCalcUC corporateActionCalcUC, string s_GrantOptID)
        {
            try
            {
                var var_Data = userSessionInfo.ACC_CalculationMethod.Equals(1) ?
                                (from data in ac_CorporateActionAdjustment.dt_UpdateCorpActAdj.AsEnumerable()
                                 where data.Field<string>("Grant Option ID") == s_GrantOptID
                                 select data) :
                                (from data in ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.AsEnumerable()
                                 where data.Field<string>("Grant Option ID") == s_GrantOptID
                                 select data);

                if (var_Data.Count() > 0)
                {
                    DataTable dt_CAAUpdateCorpActEffect = new DataTable();

                    dt_CAAUpdateCorpActEffect.Columns.Add(" ", typeof(string));
                    dt_CAAUpdateCorpActEffect.Columns.Add("Data Updated as on", typeof(string));
                    dt_CAAUpdateCorpActEffect.Columns.Add("Pre-Corporate Action Date", typeof(string));
                    dt_CAAUpdateCorpActEffect.Columns.Add("Post-Corporate Action Date", typeof(string));

                    /* For Vestwise Client */
                    if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                    {
                        if (string.IsNullOrEmpty(corporateActionCalcUC.hdnddlCAAVestingDatesIndex.Value))
                        {
                            var var_Dates = (from data in ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.AsEnumerable()
                                             where data.Field<string>("Grant Option ID") == Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value)
                                             select data).Distinct();

                            using (DataTable dt_VestingDates = var_Dates.CopyToDataTable().DefaultView.ToTable(true, "Vesting Date", "Vesting Period Number"))
                            {
                                corporateActionCalcUC.ddlCAAVestingDates.DataTextField = "Vesting Date";
                                corporateActionCalcUC.ddlCAAVestingDates.DataValueField = "Vesting Period Number";
                                corporateActionCalcUC.ddlCAAVestingDates.DataSource = dt_VestingDates;
                                corporateActionCalcUC.ddlCAAVestingDates.DataBind();
                            }

                            var var_FVIVExPrc = (from data in ac_CorporateActionAdjustment.dt_UpdateCorpActAdj.AsEnumerable()
                                                 where data.Field<string>("Grant Option ID") == s_GrantOptID
                                                 select data);

                            corporateActionCalcUC.hdnCAAMasterExPrc.Value = string.IsNullOrEmpty(Convert.ToString(var_FVIVExPrc.CopyToDataTable().Rows[0]["Exercise Price"])) ? "0.00" : Convert.ToString(var_FVIVExPrc.CopyToDataTable().Rows[0]["Exercise Price"]);

                            #region Below code does decimal rounding , Thousand separating for Exercise Price.
                            using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                            {
                                if (!corporateActionCalcUC.hdnCAAMasterExPrc.Value.Equals("0.00"))
                                {
                                    corporateActionCalcUC.hdnCAAMasterExPrc.Value = Convert.ToDouble(corporateActionCalcUC.hdnCAAMasterExPrc.Value) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(corporateActionCalcUC.hdnCAAMasterExPrc.Value, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(corporateActionCalcUC.hdnCAAMasterExPrc.Value, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                }
                            }
                            #endregion
                        }

                        dt_CAAUpdateCorpActEffect = BindgvCAAUpdateCalcCorpActionGrid(corporateActionCalcUC, dt_CAAUpdateCorpActEffect);

                        corporateActionCalcUC.trCAAVestingDates.Style.Add("display", "normal");
                        corporateActionCalcUC.trCAAViewNote.Style.Add("display", "normal");
                    }

                    /* For Grantwise Client */
                    else
                    {
                        dt_CAAUpdateCorpActEffect.Rows.Add("Options Granted", var_Data.CopyToDataTable().Rows[0]["Options Granted"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Pre_Options Granted"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Pre_Options Granted"].ToString().Equals("&nbsp;") ? var_Data.CopyToDataTable().Rows[0]["Options Granted"].ToString() : var_Data.CopyToDataTable().Rows[0]["Pre_Options Granted"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Post_Options Granted"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Post_Options Granted"].ToString().Equals("&nbsp;") ? string.Empty : var_Data.CopyToDataTable().Rows[0]["Post_Options Granted"].ToString());
                        dt_CAAUpdateCorpActEffect.Rows.Add("Options Vested Cancelled", var_Data.CopyToDataTable().Rows[0]["Options Vested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Vested Cancelled"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Vested Cancelled"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Pre_Options Vested Cancelled"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Pre_Options Vested Cancelled"].ToString().Equals("&nbsp;") ? var_Data.CopyToDataTable().Rows[0]["Options Vested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Vested Cancelled"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Vested Cancelled"].ToString() : var_Data.CopyToDataTable().Rows[0]["Pre_Options Vested Cancelled"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Post_Options Vested Cancelled"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Post_Options Vested Cancelled"].ToString().Equals("&nbsp;") ? string.Empty : var_Data.CopyToDataTable().Rows[0]["Post_Options Vested Cancelled"].ToString());
                        dt_CAAUpdateCorpActEffect.Rows.Add("Options Unvested Cancelled", var_Data.CopyToDataTable().Rows[0]["Options Unvested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Unvested Cancelled"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Unvested Cancelled"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Pre_Options Unvested Cancelled"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Pre_Options Unvested Cancelled"].ToString().Equals("&nbsp;") ? var_Data.CopyToDataTable().Rows[0]["Options Unvested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Unvested Cancelled"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Unvested Cancelled"].ToString() : var_Data.CopyToDataTable().Rows[0]["Pre_Options Unvested Cancelled"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Post_Options Unvested Cancelled"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Post_Options Unvested Cancelled"].ToString().Equals("&nbsp;") ? string.Empty : var_Data.CopyToDataTable().Rows[0]["Post_Options Unvested Cancelled"].ToString());
                        dt_CAAUpdateCorpActEffect.Rows.Add("Options Lapsed", var_Data.CopyToDataTable().Rows[0]["Options Lapsed"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Lapsed"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Lapsed"].ToString(), var_Data.CopyToDataTable().Rows[0]["Pre_Options Lapsed"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Pre_Options Lapsed"].ToString()) ? var_Data.CopyToDataTable().Rows[0]["Options Lapsed"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Lapsed"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Lapsed"].ToString() : var_Data.CopyToDataTable().Rows[0]["Pre_Options Lapsed"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Post_Options Unvested Cancelled"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Post_Options Unvested Cancelled"].ToString().Equals("&nbsp;") ? string.Empty : var_Data.CopyToDataTable().Rows[0]["Post_Options Unvested Cancelled"].ToString());
                        dt_CAAUpdateCorpActEffect.Rows.Add("Options Exercised", var_Data.CopyToDataTable().Rows[0]["Options Exercised"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Exercised"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Exercised"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Pre_Options Exercised"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Pre_Options Exercised"].ToString().Equals("&nbsp;") ? var_Data.CopyToDataTable().Rows[0]["Options Exercised"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Exercised"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Exercised"].ToString() : var_Data.CopyToDataTable().Rows[0]["Pre_Options Exercised"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Post_Options Exercised"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Post_Options Exercised"].ToString().Equals("&nbsp;") ? string.Empty : var_Data.CopyToDataTable().Rows[0]["Post_Options Exercised"].ToString());
                        dt_CAAUpdateCorpActEffect.Rows.Add("Options Unvested", var_Data.CopyToDataTable().Rows[0]["Options Unvested"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Unvested"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Unvested"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Pre_Options Unvested"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Pre_Options Unvested"].ToString().Equals("&nbsp;") ? var_Data.CopyToDataTable().Rows[0]["Options Unvested"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Unvested"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Unvested"].ToString() : var_Data.CopyToDataTable().Rows[0]["Pre_Options Unvested"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Post_Options Unvested"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Post_Options Unvested"].ToString().Equals("&nbsp;") ? string.Empty : var_Data.CopyToDataTable().Rows[0]["Post_Options Unvested"].ToString());
                        dt_CAAUpdateCorpActEffect.Rows.Add("Vested And Exercisable", var_Data.CopyToDataTable().Rows[0]["Options Vested And Exercisable"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Vested And Exercisable"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Vested And Exercisable"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Pre_Options Vested And Exercisable"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Pre_Options Vested And Exercisable"].ToString().Equals("&nbsp;") ? var_Data.CopyToDataTable().Rows[0]["Options Vested And Exercisable"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Options Vested And Exercisable"].ToString()) ? "0" : var_Data.CopyToDataTable().Rows[0]["Options Vested And Exercisable"].ToString() : var_Data.CopyToDataTable().Rows[0]["Pre_Options Vested And Exercisable"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Post_Options Vested And Exercisable"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Post_Options Vested And Exercisable"].ToString().Equals("&nbsp;") ? string.Empty : var_Data.CopyToDataTable().Rows[0]["Post_Options Vested And Exercisable"].ToString());
                        dt_CAAUpdateCorpActEffect.Rows.Add("Intrinsic Value", var_Data.CopyToDataTable().Rows[0]["Intrinsic Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Intrinsic Value"].ToString()) ? "0.00" : Convert.ToString(Decimal.Round(Convert.ToDecimal(var_Data.CopyToDataTable().Rows[0]["Intrinsic Value"].ToString()), 2)), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Pre_Intrinsic Value"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Pre_Intrinsic Value"].ToString().Equals("&nbsp;") ? var_Data.CopyToDataTable().Rows[0]["Intrinsic Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Intrinsic Value"].ToString()) ? "0.00" : Convert.ToString(Decimal.Round(Convert.ToDecimal(var_Data.CopyToDataTable().Rows[0]["Intrinsic Value"].ToString()), 2)) : Convert.ToString(Decimal.Round(Convert.ToDecimal(var_Data.CopyToDataTable().Rows[0]["Pre_Intrinsic Value"].ToString()), 2)), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Post_Intrinsic Value"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Post_Intrinsic Value"].ToString().Equals("&nbsp;") ? string.Empty : Convert.ToString(Decimal.Round(Convert.ToDecimal(var_Data.CopyToDataTable().Rows[0]["Post_Intrinsic Value"].ToString()), 2)));
                        dt_CAAUpdateCorpActEffect.Rows.Add("Fair Value", var_Data.CopyToDataTable().Rows[0]["Fair Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Fair Value"].ToString()) ? "0.00" : Convert.ToString(Decimal.Round(Convert.ToDecimal(var_Data.CopyToDataTable().Rows[0]["Fair Value"].ToString()), 2)), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Pre_Fair Value"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Pre_Fair Value"].ToString().Equals("&nbsp;") ? var_Data.CopyToDataTable().Rows[0]["Fair Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Fair Value"].ToString()) ? "0.00" : Convert.ToString(Decimal.Round(Convert.ToDecimal(var_Data.CopyToDataTable().Rows[0]["Fair Value"].ToString()), 2)) : Convert.ToString(Decimal.Round(Convert.ToDecimal(var_Data.CopyToDataTable().Rows[0]["Pre_Fair Value"].ToString()), 2)), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Post_Fair Value"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Post_Fair Value"].ToString().Equals("&nbsp;") ? string.Empty : Convert.ToString(Decimal.Round(Convert.ToDecimal(var_Data.CopyToDataTable().Rows[0]["Post_Fair Value"].ToString()), 2)));
                        dt_CAAUpdateCorpActEffect.Rows.Add("Exercise Price", var_Data.CopyToDataTable().Rows[0]["Exercise Price"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Exercise Price"].ToString()) ? "0.00" : var_Data.CopyToDataTable().Rows[0]["Exercise Price"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Pre_Exercise Price"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Pre_Exercise Price"].ToString().Equals("&nbsp;") ? var_Data.CopyToDataTable().Rows[0]["Exercise Price"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Exercise Price"].ToString()) ? "0.00" : var_Data.CopyToDataTable().Rows[0]["Exercise Price"].ToString() : var_Data.CopyToDataTable().Rows[0]["Pre_Exercise Price"].ToString(), string.IsNullOrEmpty(var_Data.CopyToDataTable().Rows[0]["Post_Exercise Price"].ToString()) || var_Data.CopyToDataTable().Rows[0]["Post_Exercise Price"].ToString().Equals("&nbsp;") ? string.Empty : var_Data.CopyToDataTable().Rows[0]["Post_Exercise Price"].ToString());

                        corporateActionCalcUC.trCAAVestingDates.Style.Add("display", "none");
                        corporateActionCalcUC.trCAAViewNote.Style.Add("display", "none");
                    }

                    corporateActionCalcUC.gvCAAUpdateCalcCorpAction.DataSource = dt_CAAUpdateCorpActEffect;
                    corporateActionCalcUC.gvCAAUpdateCalcCorpAction.DataBind();

                    corporateActionCalcUC.lblCAAEmpIDval.Text = " " + var_Data.CopyToDataTable().Rows[0]["Employee ID"].ToString();
                    corporateActionCalcUC.lblCAAEmpNameVal.Text = " " + var_Data.CopyToDataTable().Rows[0]["Employee Name"].ToString();
                    corporateActionCalcUC.lblCAASchemNameVal.Text = " " + var_Data.CopyToDataTable().Rows[0]["Scheme Name"].ToString();
                    corporateActionCalcUC.lblCAAGrantDateVal.Text = " " + var_Data.CopyToDataTable().Rows[0]["Grant Date"].ToString();
                    corporateActionCalcUC.lblCAAGrantIDVal.Text = " " + var_Data.CopyToDataTable().Rows[0]["Grant Registration ID"].ToString();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind gvCAAUpdateCalcCorpAction for Vestwise Client
        /// </summary>
        /// <param name="corporateActionCalcUC">corporateActionCalcUC Page Object</param>
        /// <param name="dt_CAAUpdateCorpActEffect">Datatable dt_CAAUpdateCorpActEffect</param>
        /// <returns>Datatable dt_CAAUpdateCorpActEffect</returns>
        private DataTable BindgvCAAUpdateCalcCorpActionGrid(CorporateActionCalcUC corporateActionCalcUC, DataTable dt_CAAUpdateCorpActEffect)
        {
            try
            {
                string s_VestDate = corporateActionCalcUC.ddlCAAVestingDates.SelectedItem.Text;
                int n_VestID = Convert.ToInt32(corporateActionCalcUC.ddlCAAVestingDates.SelectedItem.Value);

                ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow = new DataTable();

                if (ac_CorporateActionAdjustment.dt_SavedCorpActAdjVestwiseShadow != null && ac_CorporateActionAdjustment.dt_SavedCorpActAdjVestwiseShadow.Rows.Count > 0)
                {
                    ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow = ac_CorporateActionAdjustment.dt_SavedCorpActAdjVestwiseShadow.Select("GRANT_OPTION_ID = '" + Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value) + "'").Count() > 0 ?
                        ac_CorporateActionAdjustment.dt_SavedCorpActAdjVestwiseShadow.Select("GRANT_OPTION_ID = '" + Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value) + "'").CopyToDataTable().DefaultView.ToTable(true, "OPT_GRANTED_ID", "AGRMID", "EMPID", "GRANT_OPTION_ID", "VPD_VESTING_PERIOD_ID", "VPD_VESTING_DATE", "VPD_VEST_PERCENT", "VPD_EXPIRY_DATE",
                            "IS_MU_FV", "IS_MU_IV", "PRE_VEST_GRANTED_OPTIONS", "PRE_VEST_CANCELLED_OPTIONS", "PRE_VEST_VESTED_CANCELLED_OPTIONS", "PRE_VEST_UNVESTED_CANCELLED_OPTIONS",
                            "PRE_VEST_LAPSED_OPTIONS", "PRE_VEST_EXERCISED_OPTIONS", "PRE_VEST_UNVESTED_OPTIONS", "PRE_VEST_VESTED_AND_EXERCISABLE",
                            "PRE_VEST_OUTSTANDING_OPTIONS", "PRE_VEST_INTRINSIC_VALUE", "PRE_VEST_FAIR_VALUE", "PRE_VEST_EXERCISE_PRICE",
                            "PRE_VEST_COMPENSATION_COST_BYIV", "PRE_VEST_COMPENSATION_COST_BYFV", "POST_VEST_GRANTED_OPTIONS", "POST_VEST_CANCELLED_OPTIONS", "POST_VEST_VESTED_CANCELLED_OPTIONS",
                            "POST_VEST_UNVESTED_CANCELLED_OPTIONS", "POST_VEST_LAPSED_OPTIONS", "POST_VEST_EXERCISED_OPTIONS", "POST_VEST_UNVESTED_OPTIONS",
                            "POST_VEST_VESTED_AND_EXERCISABLE", "POST_VEST_OUTSTANDING_OPTIONS", "POST_VEST_INTRINSIC_VALUE",
                            "POST_VEST_FAIR_VALUE", "POST_VEST_EXERCISE_PRICE", "POST_VEST_COMPENSATION_COST_BYIV", "POST_VEST_COMPENSATION_COST_BYFV", "CANCELLATION_DATE", "LAPSED_DATE", "EXERCISED_DATE", "OPERATION_ID", "OPERATION_DATE", "IS_SAVED", "IS_JOINT_MODIFICATION").Copy() : null;

                    if (ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow == null)
                    {
                        ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow = ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.Select("[Grant Option ID]= '" + Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value) + "'").CopyToDataTable().DefaultView.ToTable(true, "OPT GRANTED ID", "AGRMID", "EMPID", "Grant Option ID", "Vesting Period Number", "Vesting_Date", "Vest Percent (%)", "Expiry_Date",
                            "IS_MU_FV", "IS_MU_IV", "Pre_Vest_Options Granted", "Pre_Vest_Options Cancelled", "Pre_Vest_Options Vested Cancelled", "Pre_Vest_Options Unvested Cancelled",
                            "Pre_Vest_Options Lapsed", "Pre_Vest_Options Exercised", "Pre_Vest_Options Unvested", "Pre_Vest_Options Vested And Exercisable",
                            "Pre_Vest_Outstanding Options", "Pre_Vest_Intrinsic Value", "Pre_Vest_Fair Value", "Pre_Vest_Exercise Price",
                            "Pre_Vest CompCostIV", "Pre_Vest CompCostFV", "Post_Vest_Options Granted", "Post_Vest_Options Cancelled", "Post_Vest_Options Vested Cancelled",
                            "Post_Vest_Options Unvested Cancelled", "Post_Vest_Options Lapsed", "Post_Vest_Options Exercised", "Post_Vest_Options Unvested",
                            "Post_Vest_Options Vested And Exercisable", "Post_Vest_Outstanding Options", "Post_Vest_Intrinsic Value",
                            "Post_Vest_Fair Value", "Post_Vest_Exercise Price", "Post_Vest CompCostIV", "Post_Vest CompCostFV", "Cancellation Date", "Lapsed Date", "Exercised Date", "Vest_OPERATION_ID", "Vest_OPERATION_DATE", "IS_SAVED", "IS_JOINT_MODIFICATION").Copy();

                        ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow = RenameColumns(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow);
                    }
                }

                /* Copy Data into ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow table if Data is not saved for the Vests from original dt_UpdateCorpActAdjVestwise table */
                for (int n_VestCount = 1; n_VestCount <= corporateActionCalcUC.ddlCAAVestingDates.Items.Count; n_VestCount++)
                {
                    /* Check if data is available for the Vesting Date */
                    DataRow[] dr_IsVestExists = ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow != null && ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows.Count > 0 && ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Select("VPD_VESTING_PERIOD_ID='" + n_VestCount + "'").Count() > 0 ? ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Select("VPD_VESTING_PERIOD_ID='" + n_VestCount + "'") : null;

                    if (dr_IsVestExists == null)
                    {
                        ac_CorporateActionAdjustment.dt_TempCorpActVestGrantedOptionsShadow = ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.Select("[Grant Option ID]= '" + Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value) + "'" + "and [Vesting Period Number]='" + n_VestCount + "'").CopyToDataTable().DefaultView.ToTable(true, "OPT GRANTED ID", "AGRMID", "EMPID", "Grant Option ID", "Vesting Period Number", "Vesting_Date", "Vest Percent (%)", "Expiry_Date",
                            "IS_MU_FV", "IS_MU_IV", "Pre_Vest_Options Granted", "Pre_Vest_Options Cancelled", "Pre_Vest_Options Vested Cancelled", "Pre_Vest_Options Unvested Cancelled",
                            "Pre_Vest_Options Lapsed", "Pre_Vest_Options Exercised", "Pre_Vest_Options Unvested", "Pre_Vest_Options Vested And Exercisable",
                            "Pre_Vest_Outstanding Options", "Pre_Vest_Intrinsic Value", "Pre_Vest_Fair Value", "Pre_Vest_Exercise Price",
                            "Pre_Vest CompCostIV", "Pre_Vest CompCostFV", "Post_Vest_Options Granted", "Post_Vest_Options Cancelled", "Post_Vest_Options Vested Cancelled",
                            "Post_Vest_Options Unvested Cancelled", "Post_Vest_Options Lapsed", "Post_Vest_Options Exercised", "Post_Vest_Options Unvested",
                            "Post_Vest_Options Vested And Exercisable", "Post_Vest_Outstanding Options", "Post_Vest_Intrinsic Value",
                            "Post_Vest_Fair Value", "Post_Vest_Exercise Price", "Post_Vest CompCostIV", "Post_Vest CompCostFV", "Cancellation Date", "Lapsed Date", "Exercised Date", "Vest_OPERATION_ID", "Vest_OPERATION_DATE", "IS_SAVED", "IS_JOINT_MODIFICATION").Copy();

                        ac_CorporateActionAdjustment.dt_TempCorpActVestGrantedOptionsShadow = RenameColumns(ac_CorporateActionAdjustment.dt_TempCorpActVestGrantedOptionsShadow);

                        ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Merge(ac_CorporateActionAdjustment.dt_TempCorpActVestGrantedOptionsShadow);
                    }
                }

                ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Columns["IS_MU_FV"].SetOrdinal(37);
                ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Columns["IS_MU_IV"].SetOrdinal(37);

                DataRow[] dr_Data = ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.Select("[Grant Option ID] = '" + Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value) + "'" + "and [Vesting Date] = '" + s_VestDate + "'" + "and [Vesting Period Number] ='" + n_VestID + "'").Count() > 0 ? ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.Select("[Grant Option ID] = '" + Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value) + "'" + "and [Vesting Date] = '" + s_VestDate + "'" + "and [Vesting Period Number] ='" + n_VestID + "'") : null;
                DataRow[] dr_SavedData = ac_CorporateActionAdjustment.dt_SavedCorpActAdjVestwiseShadow != null && ac_CorporateActionAdjustment.dt_SavedCorpActAdjVestwiseShadow.Rows.Count > 0 && ac_CorporateActionAdjustment.dt_SavedCorpActAdjVestwiseShadow.Select("GRANT_OPTION_ID = '" + Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value) + "'" + "and VPD_VESTING_DATE = '" + Convert.ToDateTime(s_VestDate) + "'" + "and VPD_VESTING_PERIOD_ID ='" + n_VestID + "'").Count() > 0 ? ac_CorporateActionAdjustment.dt_SavedCorpActAdjVestwiseShadow.Select("GRANT_OPTION_ID = '" + Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value) + "'" + "and VPD_VESTING_DATE = '" + Convert.ToDateTime(s_VestDate) + "'" + "and VPD_VESTING_PERIOD_ID ='" + n_VestID + "'") : ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow != null && ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows.Count > 0 && ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Select("GRANT_OPTION_ID = '" + Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value) + "'" + "and VPD_VESTING_DATE = '" + s_VestDate + "'" + "and VPD_VESTING_PERIOD_ID ='" + n_VestID + "'").Count() > 0 ? ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Select("GRANT_OPTION_ID = '" + Convert.ToString(corporateActionCalcUC.hdnCAAUpdGrntOptID.Value) + "'" + "and VPD_VESTING_DATE = '" + s_VestDate + "'" + "and VPD_VESTING_PERIOD_ID ='" + n_VestID + "'") : null;

                if (dr_Data != null)
                {
                    dt_CAAUpdateCorpActEffect.Rows.Add("Options Granted", dr_Data[0]["Vest_Options Granted"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Granted"].ToString()) ? "0" : dr_Data[0]["Vest_Options Granted"].ToString(), dr_Data[0]["Pre_Vest_Options Granted"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Pre_Vest_Options Granted"].ToString()) ? dr_Data[0]["Vest_Options Granted"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Granted"].ToString()) ? "0" : dr_Data[0]["Vest_Options Granted"].ToString() : dr_Data[0]["Pre_Vest_Options Granted"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["POST_VEST_GRANTED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["POST_VEST_GRANTED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["POST_VEST_GRANTED_OPTIONS"]) : dr_Data[0]["Post_Vest_Options Granted"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Post_Vest_Options Granted"].ToString()) ? string.Empty : dr_Data[0]["Post_Vest_Options Granted"].ToString());
                    dt_CAAUpdateCorpActEffect.Rows.Add("Options Vested Cancelled", dr_Data[0]["Vest_Options Vested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Vested Cancelled"].ToString()) ? "0" : dr_Data[0]["Vest_Options Vested Cancelled"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["PRE_VEST_VESTED_CANCELLED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["PRE_VEST_VESTED_CANCELLED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["PRE_VEST_VESTED_CANCELLED_OPTIONS"]) : dr_Data[0]["Pre_Vest_Options Vested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Pre_Vest_Options Vested Cancelled"].ToString()) ? dr_Data[0]["Vest_Options Vested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Vested Cancelled"].ToString()) ? "0" : dr_Data[0]["Vest_Options Vested Cancelled"].ToString() : dr_Data[0]["Pre_Vest_Options Vested Cancelled"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["POST_VEST_VESTED_CANCELLED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["POST_VEST_VESTED_CANCELLED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["POST_VEST_VESTED_CANCELLED_OPTIONS"]) : dr_Data[0]["Post_Vest_Options Vested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Post_Vest_Options Vested Cancelled"].ToString()) ? string.Empty : dr_Data[0]["Post_Vest_Options Vested Cancelled"].ToString());
                    dt_CAAUpdateCorpActEffect.Rows.Add("Options Unvested Cancelled", dr_Data[0]["Vest_Options Unvested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Unvested Cancelled"].ToString()) ? "0" : dr_Data[0]["Vest_Options Unvested Cancelled"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["PRE_VEST_UNVESTED_CANCELLED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["PRE_VEST_UNVESTED_CANCELLED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["PRE_VEST_UNVESTED_CANCELLED_OPTIONS"]) : dr_Data[0]["Pre_Vest_Options Unvested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Pre_Vest_Options Unvested Cancelled"].ToString()) ? dr_Data[0]["Vest_Options Unvested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Unvested Cancelled"].ToString()) ? "0" : dr_Data[0]["Vest_Options Unvested Cancelled"].ToString() : dr_Data[0]["Pre_Vest_Options Unvested Cancelled"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["POST_VEST_UNVESTED_CANCELLED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["POST_VEST_UNVESTED_CANCELLED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["POST_VEST_UNVESTED_CANCELLED_OPTIONS"]) : dr_Data[0]["Post_Vest_Options Unvested Cancelled"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Post_Vest_Options Unvested Cancelled"].ToString()) ? string.Empty : dr_Data[0]["Post_Vest_Options Unvested Cancelled"].ToString());
                    dt_CAAUpdateCorpActEffect.Rows.Add("Options Lapsed", dr_Data[0]["Vest_Options Lapsed"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Lapsed"].ToString()) ? "0" : dr_Data[0]["Vest_Options Lapsed"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["PRE_VEST_LAPSED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["PRE_VEST_LAPSED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["PRE_VEST_LAPSED_OPTIONS"]) : dr_Data[0]["Pre_Vest_Options Lapsed"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Pre_Vest_Options Lapsed"].ToString()) ? dr_Data[0]["Vest_Options Lapsed"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Lapsed"].ToString()) ? "0" : dr_Data[0]["Vest_Options Lapsed"].ToString() : dr_Data[0]["Pre_Vest_Options Lapsed"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["POST_VEST_LAPSED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["POST_VEST_LAPSED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["POST_VEST_LAPSED_OPTIONS"]) : dr_Data[0]["Post_Vest_Options Lapsed"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Post_Vest_Options Lapsed"].ToString()) ? string.Empty : dr_Data[0]["Post_Vest_Options Lapsed"].ToString());
                    dt_CAAUpdateCorpActEffect.Rows.Add("Options Exercised", dr_Data[0]["Vest_Options Exercised"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Exercised"].ToString()) ? "0" : dr_Data[0]["Vest_Options Exercised"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["PRE_VEST_EXERCISED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["PRE_VEST_EXERCISED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["PRE_VEST_EXERCISED_OPTIONS"]) : dr_Data[0]["Pre_Vest_Options Exercised"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Pre_Vest_Options Exercised"].ToString()) ? dr_Data[0]["Vest_Options Exercised"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Exercised"].ToString()) ? "0" : dr_Data[0]["Vest_Options Exercised"].ToString() : dr_Data[0]["Pre_Vest_Options Exercised"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["POST_VEST_EXERCISED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["POST_VEST_EXERCISED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["POST_VEST_EXERCISED_OPTIONS"]) : dr_Data[0]["Post_Vest_Options Exercised"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Post_Vest_Options Exercised"].ToString()) ? string.Empty : dr_Data[0]["Post_Vest_Options Exercised"].ToString());
                    dt_CAAUpdateCorpActEffect.Rows.Add("Options Unvested", dr_Data[0]["Vest_Options Unvested"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Unvested"].ToString()) ? "0" : dr_Data[0]["Vest_Options Unvested"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["PRE_VEST_UNVESTED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["PRE_VEST_UNVESTED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["PRE_VEST_UNVESTED_OPTIONS"]) : dr_Data[0]["Pre_Vest_Options Unvested"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Pre_Vest_Options Unvested"].ToString()) ? dr_Data[0]["Vest_Options Unvested"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Unvested"].ToString()) ? "0" : dr_Data[0]["Vest_Options Unvested"].ToString() : dr_Data[0]["Pre_Vest_Options Unvested"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["POST_VEST_UNVESTED_OPTIONS"])) && !Convert.ToString(dr_SavedData[0]["POST_VEST_UNVESTED_OPTIONS"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["POST_VEST_UNVESTED_OPTIONS"]) : dr_Data[0]["Post_Vest_Options Unvested"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Post_Vest_Options Unvested"].ToString()) ? string.Empty : dr_Data[0]["Post_Vest_Options Unvested"].ToString());
                    dt_CAAUpdateCorpActEffect.Rows.Add("Vested and Exercisable", dr_Data[0]["Vest_Options Vested and Exercisable"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Vested and Exercisable"].ToString()) ? "0" : dr_Data[0]["Vest_Options Vested and Exercisable"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["PRE_VEST_VESTED_AND_EXERCISABLE"])) && !Convert.ToString(dr_SavedData[0]["PRE_VEST_VESTED_AND_EXERCISABLE"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["PRE_VEST_VESTED_AND_EXERCISABLE"]) : dr_Data[0]["Pre_Vest_Options Vested and Exercisable"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Pre_Vest_Options Vested and Exercisable"].ToString()) ? dr_Data[0]["Vest_Options Vested and Exercisable"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Options Vested and Exercisable"].ToString()) ? "0" : dr_Data[0]["Vest_Options Vested and Exercisable"].ToString() : dr_Data[0]["Pre_Vest_Options Vested and Exercisable"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["POST_VEST_VESTED_AND_EXERCISABLE"])) && !Convert.ToString(dr_SavedData[0]["POST_VEST_VESTED_AND_EXERCISABLE"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["POST_VEST_VESTED_AND_EXERCISABLE"]) : dr_Data[0]["Post_Vest_Options Vested and Exercisable"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Post_Vest_Options Vested and Exercisable"].ToString()) ? string.Empty : dr_Data[0]["Post_Vest_Options Vested and Exercisable"].ToString());
                    dt_CAAUpdateCorpActEffect.Rows.Add("Intrinsic Value", dr_Data[0]["Vest_Intrinsic Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Intrinsic Value"].ToString()) ? "0" : Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Vest_Intrinsic Value"].ToString()), 2)), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["PRE_VEST_INTRINSIC_VALUE"])) && !Convert.ToString(dr_SavedData[0]["PRE_VEST_INTRINSIC_VALUE"]).Equals("&nbsp;") ? Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_SavedData[0]["PRE_VEST_INTRINSIC_VALUE"].ToString()), 2)) : dr_Data[0]["Pre_Vest_Intrinsic Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Pre_Vest_Intrinsic Value"].ToString()) ? dr_Data[0]["Vest_Intrinsic Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Intrinsic Value"].ToString()) ? "0" : Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Vest_Intrinsic Value"].ToString()), 2)) : Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Pre_Vest_Intrinsic Value"].ToString()), 2)), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["POST_VEST_INTRINSIC_VALUE"])) && !Convert.ToString(dr_SavedData[0]["POST_VEST_INTRINSIC_VALUE"]).Equals("&nbsp;") ? Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_SavedData[0]["POST_VEST_INTRINSIC_VALUE"].ToString()), 2)) : dr_Data[0]["Post_Vest_Intrinsic Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Post_Vest_Intrinsic Value"].ToString()) ? string.Empty : Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Vest_Intrinsic Value"].ToString()), 2)));
                    dt_CAAUpdateCorpActEffect.Rows.Add("Fair Value", dr_Data[0]["Vest_Fair Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Fair Value"].ToString()) ? "0" : Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Vest_Fair Value"].ToString()), 2)), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["PRE_VEST_FAIR_VALUE"])) && !Convert.ToString(dr_SavedData[0]["PRE_VEST_FAIR_VALUE"]).Equals("&nbsp;") ? Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_SavedData[0]["PRE_VEST_FAIR_VALUE"].ToString()), 2)) : dr_Data[0]["Pre_Vest_Fair Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Pre_Vest_Fair Value"].ToString()) ? dr_Data[0]["Vest_Fair Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Fair Value"].ToString()) ? "0" : Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Vest_Fair Value"].ToString()), 2)) : Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Pre_Vest_Fair Value"].ToString()), 2)), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["POST_VEST_FAIR_VALUE"])) && !Convert.ToString(dr_SavedData[0]["POST_VEST_FAIR_VALUE"]).Equals("&nbsp;") ? Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_SavedData[0]["POST_VEST_FAIR_VALUE"].ToString()), 2)) : dr_Data[0]["Post_Vest_Fair Value"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Post_Vest_Fair Value"].ToString()) ? string.Empty : Convert.ToString(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Vest_Fair Value"].ToString()), 2)));
                    dt_CAAUpdateCorpActEffect.Rows.Add("Exercise Price", dr_Data[0]["Vest_Exercise Price"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Exercise Price"].ToString()) ? "0" : dr_Data[0]["Vest_Exercise Price"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["PRE_VEST_EXERCISE_PRICE"])) && !Convert.ToString(dr_SavedData[0]["PRE_VEST_EXERCISE_PRICE"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["PRE_VEST_EXERCISE_PRICE"]) : dr_Data[0]["Pre_Vest_Exercise Price"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Pre_Vest_Exercise Price"].ToString()) ? dr_Data[0]["Vest_Exercise Price"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Vest_Exercise Price"].ToString()) ? "0" : dr_Data[0]["Vest_Exercise Price"].ToString() : dr_Data[0]["Pre_Vest_Exercise Price"].ToString(), dr_SavedData != null && !string.IsNullOrEmpty(Convert.ToString(dr_SavedData[0]["POST_VEST_EXERCISE_PRICE"])) && !Convert.ToString(dr_SavedData[0]["POST_VEST_EXERCISE_PRICE"]).Equals("&nbsp;") ? Convert.ToString(dr_SavedData[0]["POST_VEST_EXERCISE_PRICE"]) : dr_Data[0]["Post_Vest_Exercise Price"].ToString().Equals("&nbsp;") || string.IsNullOrEmpty(dr_Data[0]["Post_Vest_Exercise Price"].ToString()) ? string.Empty : dr_Data[0]["Post_Vest_Exercise Price"].ToString());
                }

                return dt_CAAUpdateCorpActEffect;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to rename the columns of ac_CorporateActionAdjustment.dt_TempCorpActVestGrantedOptionsShadow Table
        /// </summary>
        /// <param name="dt_RenameTable">DataTable dt_RenameTable</param>
        /// <returns>returns renamed DataTable dt_RenameTable</returns>
        private DataTable RenameColumns(DataTable dt_RenameTable)
        {
            dt_RenameTable.Columns["Grant Option ID"].ColumnName = "GRANT_OPTION_ID";
            dt_RenameTable.Columns["Vesting Period Number"].ColumnName = "VPD_VESTING_PERIOD_ID";
            dt_RenameTable.Columns["Vesting_Date"].ColumnName = "VPD_VESTING_DATE";
            dt_RenameTable.Columns["Vest Percent (%)"].ColumnName = "VPD_VEST_PERCENT";
            dt_RenameTable.Columns["Expiry_Date"].ColumnName = "VPD_EXPIRY_DATE";
            dt_RenameTable.Columns["Pre_Vest_Options Granted"].ColumnName = "PRE_VEST_GRANTED_OPTIONS";
            dt_RenameTable.Columns["Pre_Vest_Options Cancelled"].ColumnName = "PRE_VEST_CANCELLED_OPTIONS";
            dt_RenameTable.Columns["Pre_Vest_Options Vested Cancelled"].ColumnName = "PRE_VEST_VESTED_CANCELLED_OPTIONS";
            dt_RenameTable.Columns["Pre_Vest_Options Unvested Cancelled"].ColumnName = "PRE_VEST_UNVESTED_CANCELLED_OPTIONS";
            dt_RenameTable.Columns["Pre_Vest_Options Lapsed"].ColumnName = "PRE_VEST_LAPSED_OPTIONS";
            dt_RenameTable.Columns["Pre_Vest_Options Exercised"].ColumnName = "PRE_VEST_EXERCISED_OPTIONS";
            dt_RenameTable.Columns["Pre_Vest_Options Unvested"].ColumnName = "PRE_VEST_UNVESTED_OPTIONS";
            dt_RenameTable.Columns["Pre_Vest_Options Vested And Exercisable"].ColumnName = "PRE_VEST_VESTED_AND_EXERCISABLE";
            dt_RenameTable.Columns["Pre_Vest_Outstanding Options"].ColumnName = "PRE_VEST_OUTSTANDING_OPTIONS";
            dt_RenameTable.Columns["Pre_Vest_Intrinsic Value"].ColumnName = "PRE_VEST_INTRINSIC_VALUE";
            dt_RenameTable.Columns["Pre_Vest_Fair Value"].ColumnName = "PRE_VEST_FAIR_VALUE";
            dt_RenameTable.Columns["Pre_Vest_Exercise Price"].ColumnName = "PRE_VEST_EXERCISE_PRICE";
            dt_RenameTable.Columns["Pre_Vest CompCostIV"].ColumnName = "PRE_VEST_COMPENSATION_COST_BYIV";
            dt_RenameTable.Columns["Pre_Vest CompCostFV"].ColumnName = "PRE_VEST_COMPENSATION_COST_BYFV";
            dt_RenameTable.Columns["Post_Vest_Options Granted"].ColumnName = "POST_VEST_GRANTED_OPTIONS";
            dt_RenameTable.Columns["Post_Vest_Options Cancelled"].ColumnName = "POST_VEST_CANCELLED_OPTIONS";
            dt_RenameTable.Columns["Post_Vest_Options Vested Cancelled"].ColumnName = "POST_VEST_VESTED_CANCELLED_OPTIONS";
            dt_RenameTable.Columns["Post_Vest_Options Unvested Cancelled"].ColumnName = "POST_VEST_UNVESTED_CANCELLED_OPTIONS";
            dt_RenameTable.Columns["Post_Vest_Options Lapsed"].ColumnName = "POST_VEST_LAPSED_OPTIONS";
            dt_RenameTable.Columns["Post_Vest_Options Exercised"].ColumnName = "POST_VEST_EXERCISED_OPTIONS";
            dt_RenameTable.Columns["Post_Vest_Options Unvested"].ColumnName = "POST_VEST_UNVESTED_OPTIONS";
            dt_RenameTable.Columns["Post_Vest_Options Vested And Exercisable"].ColumnName = "POST_VEST_VESTED_AND_EXERCISABLE";
            dt_RenameTable.Columns["Post_Vest_Outstanding Options"].ColumnName = "POST_VEST_OUTSTANDING_OPTIONS";
            dt_RenameTable.Columns["Post_Vest_Intrinsic Value"].ColumnName = "POST_VEST_INTRINSIC_VALUE";
            dt_RenameTable.Columns["Post_Vest_Fair Value"].ColumnName = "POST_VEST_FAIR_VALUE";
            dt_RenameTable.Columns["Post_Vest_Exercise Price"].ColumnName = "POST_VEST_EXERCISE_PRICE";
            dt_RenameTable.Columns["Post_Vest CompCostIV"].ColumnName = "POST_VEST_COMPENSATION_COST_BYIV";
            dt_RenameTable.Columns["Post_Vest CompCostFV"].ColumnName = "POST_VEST_COMPENSATION_COST_BYFV";
            dt_RenameTable.Columns["Cancellation Date"].ColumnName = "CANCELLATION_DATE";
            dt_RenameTable.Columns["Lapsed Date"].ColumnName = "LAPSED_DATE";
            dt_RenameTable.Columns["Exercised Date"].ColumnName = "EXERCISED_DATE";
            dt_RenameTable.Columns["Vest_OPERATION_ID"].ColumnName = "OPERATION_ID";
            dt_RenameTable.Columns["Vest_OPERATION_DATE"].ColumnName = "OPERATION_DATE";

            return dt_RenameTable;
        }

        /// <summary>
        /// The Row Data Bound Event of gvCAAUpdateCalcCorpAction GridView
        /// </summary>
        /// <param name="sender">gvCAAUpdateCalcCorpAction GridView</param>
        /// <param name="e">e</param>
        /// <param name="corporateActionCalcUC">corporateActionCalcUC Page Object</param>
        /// <param name="n_indexgvUpd">int parameter of n_indexgvUpd</param>
        /// <param name="n_DataUpdatedAsOn">int parameter of Data Updated As On</param>
        /// <param name="n_PreCorpAct">int parameter of Pre Corporate Action</param>
        /// <param name="n_PostCorpAct">int parameter of Post Corporate Action</param>
        internal void gvCAAUpdateCalcCorpAction_RowDataBound(object sender, GridViewRowEventArgs e, CorporateActionCalcUC corporateActionCalcUC, ref int n_indexgvUpd, ref int n_DataUpdatedAsOn, ref int n_PreCorpAct, ref int n_PostCorpAct)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "DATA UPDATED AS ON":
                                    n_DataUpdatedAsOn = n_indexgvUpd;

                                    perColumn.Text = perColumn.Text + " : " + (!string.IsNullOrEmpty(Convert.ToString(ac_CorporateActionAdjustment.ds_UpdateCorpActAdj.Tables[4].Rows[0]["Data Updated As on"])) ? Convert.ToString(ac_CorporateActionAdjustment.ds_UpdateCorpActAdj.Tables[4].Rows[0]["Data Updated As on"]) : corporateActionCalcUC.lblCAAEffectDateVal.Text);
                                    break;

                                case "PRE-CORPORATE ACTION DATE":
                                    n_PreCorpAct = n_indexgvUpd;

                                    var var_Data = (from data in ac_CorporateActionAdjustment.dt_UpdateCorpActAdj.AsEnumerable()
                                                    where data.Field<string>("Grant Option ID") == corporateActionCalcUC.hdnCAAUpdGrntOptID.Value
                                                    select data);

                                    perColumn.Text = perColumn.Text + " : " + Convert.ToString(ac_CorporateActionAdjustment.dt_CorpActAdj.Select("[Effective Date] ='" + Convert.ToString(Convert.ToDateTime(var_Data.CopyToDataTable().Rows[0]["OPERATION_DATE"]).ToString("dd/MMM/yyyy")) + "'").Count() > 0 ? Convert.ToString(Convert.ToDateTime(var_Data.CopyToDataTable().Rows[0]["OPERATION_DATE"]).ToString("dd/MMM/yyyy")) : corporateActionCalcUC.lblCAAEffectDateVal.Text);
                                    break;

                                case "POST-CORPORATE ACTION DATE":
                                    n_PostCorpAct = n_indexgvUpd;
                                    perColumn.Text = perColumn.Text + " : " + corporateActionCalcUC.lblCAAEffectDateVal.Text;
                                    break;
                            }
                            n_indexgvUpd = n_indexgvUpd + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        #region Below code does decimal rounding , Thousand separating
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            switch (e.Row.RowIndex)
                            {
                                case 0:
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                case 6:
                                    if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[n_DataUpdatedAsOn].Text)) && !e.Row.Cells[n_DataUpdatedAsOn].Text.Equals("&nbsp;"))
                                        e.Row.Cells[n_DataUpdatedAsOn].Text = Convert.ToDouble(e.Row.Cells[n_DataUpdatedAsOn].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_DataUpdatedAsOn].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[n_DataUpdatedAsOn].Text, "0");
                                    break;

                                case 7:
                                    /* For IV */
                                    if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[n_DataUpdatedAsOn].Text)) && !e.Row.Cells[n_DataUpdatedAsOn].Text.Equals("&nbsp;"))
                                        e.Row.Cells[n_DataUpdatedAsOn].Text = Convert.ToDouble(e.Row.Cells[n_DataUpdatedAsOn].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_DataUpdatedAsOn].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_DataUpdatedAsOn].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                    break;

                                case 8:
                                    /* For FV */
                                    if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[n_DataUpdatedAsOn].Text)) && !e.Row.Cells[n_DataUpdatedAsOn].Text.Equals("&nbsp;"))
                                        e.Row.Cells[n_DataUpdatedAsOn].Text = Convert.ToDouble(e.Row.Cells[n_DataUpdatedAsOn].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_DataUpdatedAsOn].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_DataUpdatedAsOn].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                    break;

                                case 9:
                                    /* For Exercise Price */
                                    if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[n_DataUpdatedAsOn].Text)) && !e.Row.Cells[n_DataUpdatedAsOn].Text.Equals("&nbsp;"))
                                        e.Row.Cells[n_DataUpdatedAsOn].Text = Convert.ToDouble(e.Row.Cells[n_DataUpdatedAsOn].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_DataUpdatedAsOn].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_DataUpdatedAsOn].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                    break;
                            }
                        }
                        #endregion

                        e.Row.Cells[n_DataUpdatedAsOn].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_PreCorpAct].HorizontalAlign = e.Row.Cells[n_PostCorpAct].HorizontalAlign = HorizontalAlign.Center;

                        e.Row.Cells[n_PreCorpAct].Controls.Add(AddControl(corporateActionCalcUC, "TextBox", "txtBox", e.Row.Cells[n_PreCorpAct].Text, string.Empty, string.Empty, "Pre-CorpAct", string.Empty, string.Empty, e.Row.RowIndex));
                        e.Row.Cells[n_PostCorpAct].Controls.Add(AddControl(corporateActionCalcUC, "TextBox", "txtBox", e.Row.Cells[n_PostCorpAct].Text, string.Empty, string.Empty, "Post-CorpAct", string.Empty, string.Empty, e.Row.RowIndex));

                        e.Row.Cells[n_PreCorpAct].Controls.Add(AddControl(corporateActionCalcUC, "RequiredFieldValidator", "rfv", e.Row.Cells[n_DataUpdatedAsOn].Text, string.Empty, string.Empty, "Pre-CorpAct", string.Empty, string.Empty, e.Row.RowIndex));
                        e.Row.Cells[n_PostCorpAct].Controls.Add(AddControl(corporateActionCalcUC, "RequiredFieldValidator", "rfv", string.Empty, string.Empty, string.Empty, "Post-CorpAct", string.Empty, string.Empty, e.Row.RowIndex));

                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Add Controls to the GridView
        /// </summary>
        /// <param name="corporateActionCalcUC">corporateActionCalcUC Page Object</param>
        /// <param name="s_ControlName">Name of the Control</param>
        /// <param name="s_ControlID">ID of the Control</param>
        /// <param name="s_ControlText">Text of the Control</param>
        /// <param name="s_Tooltip">Tooltip of the Control</param>
        /// <param name="s_JavascriptMethodName">Javascript Method Name of the Control</param>
        /// <param name="s_EventName">Event Name  of the Control</param>
        /// <param name="s_ParameterOne">ParameterOne to be passed to the Control</param>
        /// <param name="s_ParameterTwo">ParameterTwo to be passed to the Control</param>
        /// <param name="n_RowIndex">Row Index</param>
        /// <returns>Control</returns>
        private Control AddControl(CorporateActionCalcUC corporateActionCalcUC, string s_ControlName, string s_ControlID, string s_ControlText, string s_Tooltip, string s_JavascriptMethodName, string s_EventName, string s_ParameterOne, string s_ParameterTwo, int n_RowIndex)
        {
            try
            {
                switch (s_ControlName)
                {
                    case "TextBox":
                        TextBox txtBox = new TextBox();
                        txtBox.ID = s_ControlID + "_" + s_EventName + "_" + n_RowIndex;
                        txtBox.Enabled = s_EventName.Equals("Pre-CorpAct") && (n_RowIndex == 0 || n_RowIndex == 7 || n_RowIndex == 8 || n_RowIndex == 9) && !corporateActionCalcUC.hdnCorpActType.Value.Equals("OTHERS") ? false : s_EventName.Equals("Pre-CorpAct") && corporateActionCalcUC.hdnCorpActType.Value.Equals("OTHERS") && n_RowIndex == 0 ? false : true;
                        txtBox.CssClass = s_EventName.Equals("Pre-CorpAct") ? "cTextBoxUpdCAA Validators" : "cTextBoxUpdCAAPost Validators";
                        txtBox.ClientIDMode = ClientIDMode.Static;
                        txtBox.EnableViewState = true;
                        txtBox.Attributes.Add("onkeyup", "javascript:return ValidateSum(this, event,'" + s_ControlText + "','" + n_RowIndex + "')");
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!s_ControlText.Equals("&nbsp;"))
                            {
                                switch (n_RowIndex)
                                {
                                    case 0:
                                    case 1:
                                    case 2:
                                    case 3:
                                    case 4:
                                    case 5:
                                    case 6:
                                        txtBox.Text = Convert.ToDouble(s_ControlText) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(s_ControlText, "0"), "0") : CommonModel.GetRoundedValue(s_ControlText, "0");
                                        break;

                                    case 7:
                                        /* For IV */
                                        txtBox.Text = Convert.ToDouble(s_ControlText) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(s_ControlText, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(s_ControlText, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                        break;

                                    case 8:
                                        /* For FV */
                                        txtBox.Text = Convert.ToDouble(s_ControlText) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(s_ControlText, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(s_ControlText, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                        break;

                                    case 9:
                                        /* For Exercise Price */
                                        txtBox.Text = Convert.ToDouble(s_ControlText) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(s_ControlText, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(s_ControlText, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                        break;
                                }
                            }
                        }

                        return txtBox;

                    case "RequiredFieldValidator":
                        RequiredFieldValidator rfv_PreCorpAct = new RequiredFieldValidator();
                        rfv_PreCorpAct.ID = s_ControlID + "_" + s_EventName + "_" + n_RowIndex;
                        rfv_PreCorpAct.ControlToValidate = "txtBox" + "_" + s_EventName + "_" + n_RowIndex;
                        rfv_PreCorpAct.ValidationGroup = "ValdInt" + s_EventName;
                        rfv_PreCorpAct.ClientIDMode = ClientIDMode.Static;
                        rfv_PreCorpAct.CssClass = "EDValidator";
                        rfv_PreCorpAct.ToolTip = "Please Enter Value";

                        return rfv_PreCorpAct;
                }
                return new Control();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Save Pre-Corpoarte Action Data and Post-Corpoarte Action Data 
        /// </summary>
        /// <param name="corporateActionCalcUC">corporateActionCalcUC Page Object</param>
        /// <param name="s_AGRMID">string AGRMID Grant ID</param>
        /// <param name="s_EMPID">string EMPID Employee Id</param>
        /// <param name="s_GrantOptionID">string Grant Option ID</param>
        /// <param name="s_EffectiveDate">string Effective Date</param>
        /// <param name="s_PreCorpAct">string of Pre-Corpoarte Action Data Values</param>
        /// <param name="s_PostCorpAct">string of Post-Corpoarte Action Data Values</param>
        /// <returns>accountingCRUDProperties.a_result Result</returns>
        internal int btnCAACalcSave_Click(CorporateActionCalcUC corporateActionCalcUC, string s_AGRMID, string s_EMPID, string s_GrantOptionID, string s_EffectiveDate, string s_PreCorpAct, string s_PostCorpAct)
        {
            try
            {
                string[] s_arrPreCorpAct = s_PreCorpAct.Split('~');
                string[] s_arrPostCorpAct = s_PostCorpAct.Split('~');

                /* Save Functionality for the Vestwise Client */
                if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                {
                    if (ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Select("GRANT_OPTION_ID ='" + s_GrantOptionID + "'").Count() == 0)
                        ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Clear();

                    /* Check if data already entered for the Vesting Date */
                    DataRow[] dr_IfExists = ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Select("VPD_VESTING_DATE='" + corporateActionCalcUC.ddlCAAVestingDates.SelectedItem.Text + "'").Count() > 0 ? ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Select("VPD_VESTING_DATE='" + corporateActionCalcUC.ddlCAAVestingDates.SelectedItem.Text + "'") : null;

                    /* Delete if data already entered for the Vesting Date */
                    if (dr_IfExists != null)
                    {
                        foreach (DataRow row in dr_IfExists)
                        {
                            ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows.Remove(row);
                        }
                        ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.AcceptChanges();
                    }

                    DataRow[] dr_Row = ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.Select("[Grant Option ID] ='" + s_GrantOptionID + "'");

                    ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows.Add(Convert.ToInt32(dr_Row[0]["OPT GRANTED ID"].ToString()), Convert.ToInt32(s_AGRMID), Convert.ToInt32(s_EMPID), s_GrantOptionID, Convert.ToInt32(corporateActionCalcUC.ddlCAAVestingDates.SelectedValue), Convert.ToDateTime(corporateActionCalcUC.ddlCAAVestingDates.SelectedItem.Text), Convert.ToDecimal(dr_Row[0]["Vest Percent (%)"].ToString()), Convert.ToDateTime(dr_Row[0]["Expiry Date"].ToString()),
                        Convert.ToInt64(s_arrPreCorpAct[1].ToString()), Convert.ToInt64(s_arrPreCorpAct[2].ToString()) + Convert.ToInt64(s_arrPreCorpAct[3].ToString()), Convert.ToInt64(s_arrPreCorpAct[2].ToString()), Convert.ToInt64(s_arrPreCorpAct[3].ToString()), Convert.ToInt64(s_arrPreCorpAct[4].ToString()), Convert.ToInt64(s_arrPreCorpAct[5].ToString()), Convert.ToInt64(s_arrPreCorpAct[6].ToString()), Convert.ToInt64(s_arrPreCorpAct[7].ToString()), Convert.ToInt64(s_arrPreCorpAct[6].ToString()) + Convert.ToInt64(s_arrPreCorpAct[7].ToString()), Convert.ToDecimal(s_arrPreCorpAct[8].ToString()), Convert.ToDecimal(s_arrPreCorpAct[9].ToString()), Convert.ToDecimal(s_arrPreCorpAct[10].ToString()), Convert.ToDecimal(s_arrPreCorpAct[7].ToString()) * Convert.ToDecimal(s_arrPreCorpAct[8].ToString()), Convert.ToDecimal(s_arrPreCorpAct[7].ToString()) * Convert.ToDecimal(s_arrPreCorpAct[9].ToString()),
                        Convert.ToInt64(s_arrPostCorpAct[1].ToString()), Convert.ToInt64(s_arrPostCorpAct[2].ToString()) + Convert.ToInt64(s_arrPostCorpAct[3].ToString()), Convert.ToInt64(s_arrPostCorpAct[2].ToString()), Convert.ToInt64(s_arrPostCorpAct[3].ToString()), Convert.ToInt64(s_arrPostCorpAct[4].ToString()), Convert.ToInt64(s_arrPostCorpAct[5].ToString()), Convert.ToInt64(s_arrPostCorpAct[6].ToString()), Convert.ToInt64(s_arrPostCorpAct[7].ToString()), Convert.ToInt64(s_arrPostCorpAct[6].ToString()) + Convert.ToInt64(s_arrPostCorpAct[7].ToString()), Convert.ToDecimal(s_arrPostCorpAct[8].ToString()), Convert.ToDecimal(s_arrPostCorpAct[9].ToString()), Convert.ToDecimal(s_arrPostCorpAct[10].ToString()), Convert.ToDecimal(s_arrPostCorpAct[7].ToString()) * Convert.ToDecimal(s_arrPostCorpAct[8].ToString()), Convert.ToDecimal(s_arrPostCorpAct[7].ToString()) * Convert.ToDecimal(s_arrPostCorpAct[9].ToString()),
                        string.IsNullOrEmpty(corporateActionCalcUC.hdnIsMUFV.Value) || Convert.ToString(corporateActionCalcUC.hdnIsMUFV.Value).Equals("&nbsp;") ? false : (Convert.ToDecimal(s_arrPostCorpAct[9].ToString()) == Convert.ToDecimal(corporateActionCalcUC.hdnIsMUFV.Value) ? false : true),
                        string.IsNullOrEmpty(corporateActionCalcUC.hdnIsMUIV.Value) || Convert.ToString(corporateActionCalcUC.hdnIsMUIV.Value).Equals("&nbsp;") ? false : (Convert.ToDecimal(s_arrPostCorpAct[8].ToString()) == Convert.ToDecimal(corporateActionCalcUC.hdnIsMUIV.Value) ? false : true),
                        string.IsNullOrEmpty(dr_Row[0]["Cancellation Date"].ToString()) ? (object)DBNull.Value : Convert.ToDateTime(dr_Row[0]["Cancellation Date"].ToString()),
                        string.IsNullOrEmpty(dr_Row[0]["Lapsed Date"].ToString()) ? (object)DBNull.Value : Convert.ToDateTime(dr_Row[0]["Lapsed Date"].ToString()),
                        string.IsNullOrEmpty(dr_Row[0]["Exercised Date"].ToString()) ? (object)DBNull.Value : Convert.ToDateTime(dr_Row[0]["Exercised Date"].ToString()),
                        4, Convert.ToDateTime(s_EffectiveDate) + DateTime.Now.TimeOfDay, 1, string.IsNullOrEmpty(dr_Row[0]["IS_JOINT_MODIFICATION"].ToString()) || Convert.ToString(dr_Row[0]["IS_JOINT_MODIFICATION"].ToString()).Equals("&nbsp;") ? (object)DBNull.Value : Convert.ToBoolean(dr_Row[0]["IS_JOINT_MODIFICATION"].ToString()));

                    using (DataView dv_CorpActVestGrantedOptionsShadow = new DataView(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow))
                    {
                        if (dv_CorpActVestGrantedOptionsShadow.Count > 0)
                        {
                            dv_CorpActVestGrantedOptionsShadow.Sort = "VPD_VESTING_PERIOD_ID";

                            ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow = dv_CorpActVestGrantedOptionsShadow.ToTable();
                        }
                    }

                    foreach (DataRow dr_UpdRow in ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows)
                    {
                        dr_UpdRow["OPERATION_DATE"] = Convert.ToDateTime(s_EffectiveDate) + DateTime.Now.TimeOfDay;
                    }
                }

                /* Save Functionality for the Grantwise Client */
                if (ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow == null)
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow = new DataTable();

                if (ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Count == 0 && ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Rows.Count == 0)
                {
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("AGRMID", typeof(int));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("EMPID", typeof(int));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("GRANT_OPTION_ID", typeof(string));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_GRANTED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_CANCELLED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_VESTED_CANCELLED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_UNVESTED_CANCELLED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_LAPSED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_EXERCISED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_UNVESTED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_VESTED_AND_EXERCISABLE", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_OUTSTANDING_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_INTRINSIC_VALUE", typeof(decimal));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_FAIR_VALUE", typeof(decimal));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_EXERCISE_PRICE", typeof(decimal));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_COMPENSATION_COST_BYIV", typeof(decimal));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("PRE_COMPENSATION_COST_BYFV", typeof(decimal));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_GRANTED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_CANCELLED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_VESTED_CANCELLED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_UNVESTED_CANCELLED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_LAPSED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_EXERCISED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_UNVESTED_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_VESTED_AND_EXERCISABLE", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_OUTSTANDING_OPTIONS", typeof(Int64));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_INTRINSIC_VALUE", typeof(decimal));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_FAIR_VALUE", typeof(decimal));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_EXERCISE_PRICE", typeof(decimal));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_COMPENSATION_COST_BYIV", typeof(decimal));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("POST_COMPENSATION_COST_BYFV", typeof(decimal));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("IS_MU_FV", typeof(bool));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("IS_MU_IV", typeof(bool));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("CANCELLATION_DATE", typeof(DateTime));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("LAPSED_DATE", typeof(DateTime));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("EXERCISED_DATE", typeof(DateTime));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("OPERATION_ID", typeof(int));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("OPERATION_DATE", typeof(DateTime));
                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Columns.Add("IS_JOINT_MODIFICATION", typeof(bool));
                }

                ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Clear();

                if (userSessionInfo.ACC_CalculationMethod.Equals(1))
                {
                    DataRow[] dr_Row = ac_CorporateActionAdjustment.dt_UpdateCorpActAdj.Select("[Grant Option ID] ='" + s_GrantOptionID + "'");

                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Rows.Add(Convert.ToInt32(s_AGRMID), Convert.ToInt32(s_EMPID), s_GrantOptionID,
                        Convert.ToInt64(s_arrPreCorpAct[1].ToString()), Convert.ToInt64(s_arrPreCorpAct[2].ToString()) + Convert.ToInt64(s_arrPreCorpAct[3].ToString()), Convert.ToInt64(s_arrPreCorpAct[2].ToString()), Convert.ToInt64(s_arrPreCorpAct[3].ToString()), Convert.ToInt64(s_arrPreCorpAct[4].ToString()), Convert.ToInt64(s_arrPreCorpAct[5].ToString()), Convert.ToInt64(s_arrPreCorpAct[6].ToString()), Convert.ToInt64(s_arrPreCorpAct[7].ToString()), Convert.ToInt64(s_arrPreCorpAct[6].ToString()) + Convert.ToInt64(s_arrPreCorpAct[7].ToString()), Convert.ToDecimal(s_arrPreCorpAct[8].ToString()), Convert.ToDecimal(s_arrPreCorpAct[9].ToString()), Convert.ToDecimal(s_arrPreCorpAct[10].ToString()), Convert.ToDecimal(s_arrPreCorpAct[7].ToString()) * Convert.ToDecimal(s_arrPreCorpAct[8].ToString()), Convert.ToDecimal(s_arrPreCorpAct[7].ToString()) * Convert.ToDecimal(s_arrPreCorpAct[9].ToString()),
                        Convert.ToInt64(s_arrPostCorpAct[1].ToString()), Convert.ToInt64(s_arrPostCorpAct[2].ToString()) + Convert.ToInt64(s_arrPostCorpAct[3].ToString()), Convert.ToInt64(s_arrPostCorpAct[2].ToString()), Convert.ToInt64(s_arrPostCorpAct[3].ToString()), Convert.ToInt64(s_arrPostCorpAct[4].ToString()), Convert.ToInt64(s_arrPostCorpAct[5].ToString()), Convert.ToInt64(s_arrPostCorpAct[6].ToString()), Convert.ToInt64(s_arrPostCorpAct[7].ToString()), Convert.ToInt64(s_arrPostCorpAct[6].ToString()) + Convert.ToInt64(s_arrPostCorpAct[7].ToString()), Convert.ToDecimal(s_arrPostCorpAct[8].ToString()), Convert.ToDecimal(s_arrPostCorpAct[9].ToString()), Convert.ToDecimal(s_arrPostCorpAct[10].ToString()), Convert.ToDecimal(s_arrPostCorpAct[7].ToString()) * Convert.ToDecimal(s_arrPostCorpAct[8].ToString()), Convert.ToDecimal(s_arrPostCorpAct[7].ToString()) * Convert.ToDecimal(s_arrPostCorpAct[9].ToString()),
                        string.IsNullOrEmpty(corporateActionCalcUC.hdnIsMUFV.Value) || Convert.ToString(corporateActionCalcUC.hdnIsMUFV.Value).Equals("&nbsp;") ? false : Convert.ToDecimal(s_arrPostCorpAct[9].ToString()) == Convert.ToDecimal(corporateActionCalcUC.hdnIsMUFV.Value) ? false : true,
                        string.IsNullOrEmpty(corporateActionCalcUC.hdnIsMUIV.Value) || Convert.ToString(corporateActionCalcUC.hdnIsMUIV.Value).Equals("&nbsp;") ? false : Convert.ToDecimal(s_arrPostCorpAct[8].ToString()) == Convert.ToDecimal(corporateActionCalcUC.hdnIsMUIV.Value) ? false : true,
                        string.IsNullOrEmpty(dr_Row[0]["Cancellation Date"].ToString()) ? (object)DBNull.Value : Convert.ToDateTime(dr_Row[0]["Cancellation Date"].ToString()),
                        string.IsNullOrEmpty(dr_Row[0]["Lapsed Date"].ToString()) ? (object)DBNull.Value : Convert.ToDateTime(dr_Row[0]["Lapsed Date"].ToString()),
                        string.IsNullOrEmpty(dr_Row[0]["Exercised Date"].ToString()) ? (object)DBNull.Value : Convert.ToDateTime(dr_Row[0]["Exercised Date"].ToString()),
                        4, Convert.ToDateTime(s_EffectiveDate) + DateTime.Now.TimeOfDay, string.IsNullOrEmpty(dr_Row[0]["IS_JOINT_MODIFICATION"].ToString()) || Convert.ToString(dr_Row[0]["IS_JOINT_MODIFICATION"].ToString()).Equals("&nbsp;") ? (object)DBNull.Value : Convert.ToBoolean(dr_Row[0]["IS_JOINT_MODIFICATION"].ToString()));

                    ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow = ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.Select("[Grant Option ID] ='" + s_GrantOptionID + "'").CopyToDataTable().DefaultView.ToTable(true, "OPT GRANTED ID", "AGRMID", "EMPID", "Grant Option ID", "Vesting Period Number",
                    "Vesting_Date", "Vest Percent (%)", "Expiry_Date", "Pre_Vest_Options Granted", "Pre_Vest_Options Cancelled", "Pre_Vest_Options Vested Cancelled", "Pre_Vest_Options Unvested Cancelled",
                    "Pre_Vest_Options Lapsed", "Pre_Vest_Options Exercised", "Pre_Vest_Options Unvested", "Pre_Vest_Options Vested And Exercisable", "Pre_Vest_Outstanding Options",
                    "Pre_Vest_Intrinsic Value", "Pre_Vest_Fair Value", "Pre_Vest_Exercise Price", "Pre_Vest CompCostIV", "Pre_Vest CompCostFV",
                    "Post_Vest_Options Granted", "Post_Vest_Options Cancelled", "Post_Vest_Options Vested Cancelled", "Post_Vest_Options Unvested Cancelled", "Post_Vest_Options Lapsed",
                    "Post_Vest_Options Exercised", "Post_Vest_Options Unvested", "Post_Vest_Options Vested And Exercisable", "Post_Vest_Outstanding Options", "Post_Vest_Intrinsic Value",
                    "Post_Vest_Fair Value", "Post_Vest_Exercise Price", "Post_Vest CompCostIV", "Post_Vest CompCostFV", "IS_MU_FV",
                    "IS_MU_IV", "Cancellation Date", "Lapsed Date", "Exercised Date", "Vest_OPERATION_ID", "Vest_OPERATION_DATE", "IS_SAVED", "IS_JOINT_MODIFICATION");

                    ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow = RenameColumns(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow);

                    for (int n_NoOfVest = 0; n_NoOfVest < Convert.ToInt32(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow != null && ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows.Count > 0 ? ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows.Count : 0); n_NoOfVest++)
                    {
                        ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[n_NoOfVest]["OPERATION_ID"] = 4;
                        ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[n_NoOfVest]["OPERATION_DATE"] = Convert.ToDateTime(s_EffectiveDate) + DateTime.Now.TimeOfDay;
                    }
                }
                else
                {
                    DataRow[] dr_Row = ac_CorporateActionAdjustment.dt_UpdateCorpActAdj.Select("[Grant Option ID] ='" + s_GrantOptionID + "'");

                    Decimal dc_PostFV = 0;
                    Decimal dc_PostCompCostFV = 0;

                    foreach (DataRow perRow in ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows)
                    {
                        dc_PostFV += (string.IsNullOrEmpty(Convert.ToString(perRow["POST_VEST_FAIR_VALUE"])) || Convert.ToString(perRow["POST_VEST_FAIR_VALUE"]).Equals("&nbsp;") ? 0 : Convert.ToDecimal(perRow["POST_VEST_FAIR_VALUE"])) * Convert.ToDecimal(perRow["VPD_VEST_PERCENT"]) / 100;
                    }

                    dc_PostCompCostFV = dc_PostFV * Convert.ToDecimal(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_VESTED_AND_EXERCISABLE)", string.Empty));

                    ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Rows.Add(Convert.ToInt32(s_AGRMID), Convert.ToInt32(s_EMPID), s_GrantOptionID,
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[0]["PRE_VEST_GRANTED_OPTIONS"].ToString()),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(PRE_VEST_CANCELLED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(PRE_VEST_VESTED_CANCELLED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(PRE_VEST_UNVESTED_CANCELLED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(PRE_VEST_LAPSED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(PRE_VEST_EXERCISED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(PRE_VEST_UNVESTED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(PRE_VEST_VESTED_AND_EXERCISABLE)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(PRE_VEST_OUTSTANDING_OPTIONS)", string.Empty)),
                        Convert.ToDecimal(dr_Row[0]["Intrinsic Value"].ToString()),
                        Convert.ToDecimal(dr_Row[0]["Fair Value"].ToString()),
                        Convert.ToDecimal(dr_Row[0]["Exercise Price"].ToString()),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(PRE_VEST_COMPENSATION_COST_BYIV)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(PRE_VEST_COMPENSATION_COST_BYFV)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_GRANTED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_CANCELLED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_VESTED_CANCELLED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_UNVESTED_CANCELLED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_LAPSED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_EXERCISED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_UNVESTED_OPTIONS)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_VESTED_AND_EXERCISABLE)", string.Empty)),
                        Convert.ToInt64(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_OUTSTANDING_OPTIONS)", string.Empty)),

                        Convert.ToDecimal(Convert.ToDecimal(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("Sum(POST_VEST_INTRINSIC_VALUE)", string.Empty)) / ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows.Count),
                        dc_PostFV,
                        Convert.ToDecimal(corporateActionCalcUC.hdnCAAMasterExPrc.Value),

                        Convert.ToDecimal(Convert.ToDecimal(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("Sum(POST_VEST_INTRINSIC_VALUE)", string.Empty)) / ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows.Count) * Convert.ToDecimal(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Compute("sum(POST_VEST_VESTED_AND_EXERCISABLE)", string.Empty)),
                        dc_PostCompCostFV,
                        ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Select("IS_MU_FV = True").Count() > 0 ? true : false, ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Select("IS_MU_IV = True").Count() > 0 ? true : false,
                        string.IsNullOrEmpty(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[0]["CANCELLATION_DATE"].ToString()) ? (object)DBNull.Value : Convert.ToDateTime(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[0]["CANCELLATION_DATE"].ToString()),
                        string.IsNullOrEmpty(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[0]["LAPSED_DATE"].ToString()) ? (object)DBNull.Value : Convert.ToDateTime(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[0]["LAPSED_DATE"].ToString()),
                        string.IsNullOrEmpty(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[0]["EXERCISED_DATE"].ToString()) ? (object)DBNull.Value : Convert.ToDateTime(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[0]["EXERCISED_DATE"].ToString()),
                        4, Convert.ToDateTime(s_EffectiveDate) + DateTime.Now.TimeOfDay, string.IsNullOrEmpty(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[0]["IS_JOINT_MODIFICATION"].ToString()) ? (object)DBNull.Value : Convert.ToBoolean(ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Rows[0]["IS_JOINT_MODIFICATION"].ToString()));
                }

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    SaveCorpActData(accountingServiceClient);
                }

                return accountingCRUDProperties.a_result;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Save the Corporate Action Data to the Database
        /// </summary>
        /// <param name="accountingServiceClient">accountingServiceClient Object</param>
        private void SaveCorpActData(AccountingServiceClient accountingServiceClient)
        {
            accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
            accountingProperties.PageName = CommonConstantModel.s_CorporateActionAdjustment;
            accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
            accountingProperties.PopulateControls = "Save_Corporate_Action_Data";
            accountingProperties.dt_DBCorpActGrantedOptionsShadow = ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow.Copy();
            accountingProperties.dt_DBCorpActGrantedOptionsShadow.TableName = "DT";
            accountingProperties.dt_DBCorpActVestGrantedOptionsShadow = ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow.Copy();
            accountingProperties.dt_DBCorpActVestGrantedOptionsShadow.TableName = "DT";

            accountingProperties.n_CalcMethod = userSessionInfo.ACC_CalculationMethod;
            accountingProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

            accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CorporateActionCalcUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}