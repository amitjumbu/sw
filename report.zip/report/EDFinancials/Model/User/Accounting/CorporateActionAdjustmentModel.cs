﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// The model class for CorporateActionAdjustment Page.
    /// </summary>
    public class CorporateActionAdjustmentModel : BaseModel, IDisposable
    {
        #region Default Constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public CorporateActionAdjustmentModel()
        {
            if (ac_CorporateActionAdjustment == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_CorporateActionAdjustment);
                ac_CorporateActionAdjustment = (CommonModel.AC_CorporateActionAdjustment)HttpContext.Current.Session[CommonConstantModel.s_AC_CorporateActionAdjustment];
            }
        }
        #endregion

        /// <summary>
        /// This method will bind all the names to the respective controls
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        internal void BindUI(CorporateActionAdjustment corporateActionAdjustment)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    using (ac_CorporateActionAdjustment.dt_CorpActionAdjUI = (DataTable)accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10_UI))
                    {
                        if ((ac_CorporateActionAdjustment.dt_CorpActionAdjUI != null) && (ac_CorporateActionAdjustment.dt_CorpActionAdjUI.Rows.Count > 0))
                        {
                            foreach (Control control in corporateActionAdjustment.divCAAdj.Controls)
                            {
                                switch (control.GetType().FullName.ToUpper())
                                {
                                    case CommonConstantModel.s_wcLabel:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_CorporateActionAdjustment.dt_CorpActionAdjUI, (Label)control, null, null, null, null, null, null, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcTextbox:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_CorporateActionAdjustment.dt_CorpActionAdjUI, null, (TextBox)control, null, null, null, null, null, null, null, null);
                                        break;

                                    case CommonConstantModel.s_wcButton:
                                        CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_CorporateActionAdjustment.dt_CorpActionAdjUI, null, null, (Button)control, null, null, null, null, null, null, null);
                                        break;
                                }
                            }
                        }

                        /* Bind the UI of CorporateActionUpdRevertUC User Control */
                        using (CorporateActionUpdRevertUCModel corporateActionUpdRevertUCModel = new CorporateActionUpdRevertUCModel())
                        {
                            corporateActionUpdRevertUCModel.BindUI(corporateActionAdjustment.corpActUpdRevertUC);
                        }

                        /* Bind the UI of CorporateActionCalcUC User Control */
                        using (CorporateActionCalcUCModel corporateActionCalcUCModel = new CorporateActionCalcUCModel())
                        {
                            corporateActionCalcUCModel.BindUI(corporateActionAdjustment.corpActCalculationUC);
                        }

                        corporateActionAdjustment.lblCAAHeaderTwo.Text = Convert.ToString((ac_CorporateActionAdjustment.dt_CorpActionAdjUI.Select("LabelID = 'lblCAAHeaderTwo'"))[0]["LabelName"]);
                        corporateActionAdjustment.lblCAAHeaderThree.Text = Convert.ToString((ac_CorporateActionAdjustment.dt_CorpActionAdjUI.Select("LabelID = 'lblCAAHeaderThree'"))[0]["LabelName"]);
                        corporateActionAdjustment.hdnlblCAACantUpdateAlreadyApplied.Value = accountingServiceClient.GetAccounting_L10N("lblCAACantUpdateAlreadyApplied", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                        corporateActionAdjustment.hdnlblCAACantUpdate.Value = accountingServiceClient.GetAccounting_L10N("lblCAACantUpdate", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                        corporateActionAdjustment.hdnlblCAACantRevertAlreadyDone.Value = accountingServiceClient.GetAccounting_L10N("lblCAACantRevertAlreadyDone", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                        corporateActionAdjustment.hdnlblCAACantRevert.Value = accountingServiceClient.GetAccounting_L10N("lblCAACantRevert", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                        corporateActionAdjustment.corpActCalculationUC.lblCAAVestingDates.Text = Convert.ToString((ac_CorporateActionAdjustment.dt_CorpActionAdjUI.Select("LabelID = 'lblCAAVestingDates'"))[0]["LabelName"]);
                        corporateActionAdjustment.corpActCalculationUC.lblCAAVestingDates.ToolTip = Convert.ToString((ac_CorporateActionAdjustment.dt_CorpActionAdjUI.Select("LabelID = 'lblCAAVestingDates'"))[0]["LabelTooltip"]);
                        corporateActionAdjustment.corpActUpdRevertUC.lblCAAApplyNote.Text = corporateActionAdjustment.corpActUpdRevertUC.lblCAAApplyNote.Text.Replace("~", "</br></br>");
                        corporateActionAdjustment.corpActCalculationUC.lblCAAViewNote.Text = Convert.ToString((ac_CorporateActionAdjustment.dt_CorpActionAdjUI.Select("LabelID = 'lblCAAViewNote'"))[0]["LabelName"]).Replace("~", "</br></br>");
                        corporateActionAdjustment.corpActUpdRevertUC.lblCAAPopUpPreCorpActFVIVTitle.Text = Convert.ToString((ac_CorporateActionAdjustment.dt_CorpActionAdjUI.Select("LabelID = 'lblCAAPopUpPreCorpActFVIVTitle'"))[0]["LabelName"]);
                        corporateActionAdjustment.corpActUpdRevertUC.lblCAAPopUpPostCorpActFVIVTitle.Text = Convert.ToString((ac_CorporateActionAdjustment.dt_CorpActionAdjUI.Select("LabelID = 'lblCAAPopUpPostCorpActFVIVTitle'"))[0]["LabelName"]);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The method to check Role Priviledges assigned to the User
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        internal void CheckEmployeeRolePriviledges(CorporateActionAdjustment corporateActionAdjustment)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuCorporateActionAdjustment;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                ac_CorporateActionAdjustment.dt_RolePreviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The method to Make Enable/Disable the Controls
        /// </summary>
        /// <param name="imageButton">ImageButton imageButton Control</param>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        private void EnableDisableControls(ImageButton imageButton, CorporateActionAdjustment corporateActionAdjustment)
        {
            using (ac_CorporateActionAdjustment.dt_RolePreviledges)
            {
                if (ac_CorporateActionAdjustment.dt_RolePreviledges != null && ac_CorporateActionAdjustment.dt_RolePreviledges.Rows.Count > 0)
                {
                    foreach (DataRow rowPriviledge in ac_CorporateActionAdjustment.dt_RolePreviledges.Rows)
                    {
                        switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                        {
                            case CommonConstantModel.s_ADD:
                                corporateActionAdjustment.btnCAASearch.Enabled = true;
                                imageButton.Enabled = imageButton.ID.Equals("imgBtnEdit");
                                break;

                            case CommonConstantModel.s_EDIT:
                                corporateActionAdjustment.btnCAASearch.Enabled = true;
                                imageButton.Enabled = imageButton.ID.Equals("imgBtnEdit");
                                break;

                            case CommonConstantModel.s_DELETE:
                                imageButton.Enabled = imageButton.ID.Equals("imgBtnEdit") ? ac_CorporateActionAdjustment.dt_RolePreviledges.Select("PRIVILEDGES = 'ADD' OR PRIVILEDGES = 'EDIT'").Count() > 0 : imageButton.ID.Equals("imgBtnRevert");
                                break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// This method is used to Bind gvCAAjd Gridview and Dropdown controls
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        internal void BindGrid(CorporateActionAdjustment corporateActionAdjustment)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    ValuationProperties valuationProperties = new ValuationProperties();
                    ValuationCRUDProperties valuationCRUDProperties = new ValuationCRUDProperties();

                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_CorporateAction;
                    valuationProperties.PopulateControls = "GET_CORPORATE_ACTION_DETAILS";
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    using (ac_CorporateActionAdjustment.dt_CorpActAdj = (DataTable)valuationCRUDProperties.dt_Result)
                    {
                        corporateActionAdjustment.gvCAAjd.DataSource = ac_CorporateActionAdjustment.dt_CorpActAdj != null && ac_CorporateActionAdjustment.dt_CorpActAdj.Rows.Count > 0 ? ac_CorporateActionAdjustment.dt_CorpActAdj : new DataTable();
                        corporateActionAdjustment.gvCAAjd.DataBind();
                    }

                    BindDropDowns(corporateActionAdjustment);

                    corporateActionAdjustment.corpActUpdRevertUC.hdnIsFVIVPopSelected.Value = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind Dropdowns on the Page
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        private void BindDropDowns(CorporateActionAdjustment corporateActionAdjustment)
        {
            try
            {
                corporateActionAdjustment.ddlCAActionType.Items.Clear();
                corporateActionAdjustment.ddlCAActionType.Items.Insert(0, "--- Please Select ---");
                corporateActionAdjustment.ddlCAActionType.Items.Insert(1, "Bonus");
                corporateActionAdjustment.ddlCAActionType.Items.Insert(2, "Split");
                corporateActionAdjustment.ddlCAActionType.Items.Insert(3, "Others");

                corporateActionAdjustment.ddlCAAApplied.Items.Clear();
                corporateActionAdjustment.ddlCAAApplied.Items.Insert(0, "--- Please Select ---");
                corporateActionAdjustment.ddlCAAApplied.Items.Insert(1, "Yes");
                corporateActionAdjustment.ddlCAAApplied.Items.Insert(2, "No");

                corporateActionAdjustment.txtCAAEffectFromDate.Text = corporateActionAdjustment.txtCAAEffectToDate.Text = string.Empty;
                corporateActionAdjustment.btnCAAReset.Visible = false;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to clear all the datatables
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        internal void ClearAllTables(CorporateActionAdjustment corporateActionAdjustment)
        {
            try
            {
                ac_CorporateActionAdjustment.dt_CorpActGrantedOptionsShadow = null;
                ac_CorporateActionAdjustment.dt_CorpActVestGrantedOptionsShadow = null;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  This method is the click Event of Search Button
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        internal void btnCAASearch_Click(CorporateActionAdjustment corporateActionAdjustment)
        {
            try
            {
                DataTable dt_FilteredCorpActAdj = ac_CorporateActionAdjustment.dt_CorpActAdj.Copy();
                string s_CorpActionType = corporateActionAdjustment.ddlCAActionType.SelectedItem.Text;
                string s_Applied = corporateActionAdjustment.ddlCAAApplied.SelectedItem.Text;
                string s_EffectFromDate = corporateActionAdjustment.txtCAAEffectFromDate.Text;
                string s_EffectToDate = corporateActionAdjustment.txtCAAEffectToDate.Text;
                string s_EffectDateCompare = string.Empty;

                if (!string.IsNullOrEmpty(s_EffectFromDate) && !s_EffectFromDate.Equals("dd/mmm/yyyy") && !string.IsNullOrEmpty(s_EffectToDate) && !s_EffectToDate.Equals("dd/mmm/yyyy"))
                    s_EffectDateCompare = "[Effective Date] >= #" + Convert.ToDateTime(s_EffectFromDate) + "# AND [Effective Date] <= #" + Convert.ToDateTime(s_EffectToDate) + "# ";

                if (dt_FilteredCorpActAdj != null && dt_FilteredCorpActAdj.Rows.Count > 0)
                {
                    if (!s_CorpActionType.Equals("--- Please Select ---"))
                        dt_FilteredCorpActAdj = dt_FilteredCorpActAdj.Select("[Corporate Action Type] ='" + s_CorpActionType + "'").Count() > 0 ? dt_FilteredCorpActAdj.Select("[Corporate Action Type] ='" + s_CorpActionType + "'").CopyToDataTable() : new DataTable();

                    if (!s_Applied.Equals("--- Please Select ---"))
                        dt_FilteredCorpActAdj = dt_FilteredCorpActAdj.Select("Applied ='" + s_Applied + "'").Count() > 0 ? dt_FilteredCorpActAdj.Select("Applied ='" + s_Applied + "'").CopyToDataTable() : new DataTable();

                    if (!string.IsNullOrEmpty(s_EffectDateCompare))
                        dt_FilteredCorpActAdj = dt_FilteredCorpActAdj.Select("" + s_EffectDateCompare + "").Count() > 0 ? dt_FilteredCorpActAdj.Select("" + s_EffectDateCompare + "").CopyToDataTable() : new DataTable();
                    else
                    {
                        if (!string.IsNullOrEmpty(s_EffectFromDate) && !s_EffectFromDate.Equals("dd/mmm/yyyy"))
                            dt_FilteredCorpActAdj = dt_FilteredCorpActAdj.AsEnumerable().Where(r => DateTime.Parse(r["Effective Date"].ToString()).Date >= Convert.ToDateTime(s_EffectFromDate).Date).Count() > 0 ? dt_FilteredCorpActAdj.AsEnumerable().Where(r => DateTime.Parse(r["Effective Date"].ToString()).Date >= Convert.ToDateTime(s_EffectFromDate).Date).CopyToDataTable() : new DataTable();

                        else if (!string.IsNullOrEmpty(s_EffectToDate) && !s_EffectToDate.Equals("dd/mmm/yyyy"))
                            dt_FilteredCorpActAdj = dt_FilteredCorpActAdj.AsEnumerable().Where(r => DateTime.Parse(r["Effective Date"].ToString()).Date <= Convert.ToDateTime(s_EffectToDate).Date).Count() > 0 ? dt_FilteredCorpActAdj.AsEnumerable().Where(r => DateTime.Parse(r["Effective Date"].ToString()).Date <= Convert.ToDateTime(s_EffectToDate).Date).CopyToDataTable() : new DataTable();
                    }
                }

                corporateActionAdjustment.gvCAAjd.DataSource = dt_FilteredCorpActAdj;
                corporateActionAdjustment.gvCAAjd.DataBind();

                corporateActionAdjustment.btnCAAReset.Visible = !s_CorpActionType.Equals("--- Please Select ---") || !s_Applied.Equals("--- Please Select ---") || !s_EffectFromDate.Equals("dd/mmm/yyyy") || !s_EffectToDate.Equals("dd/mmm/yyyy");

                corporateActionAdjustment.h4CAAUpdateRevertPanel.Style.Add("display", "none");
                corporateActionAdjustment.h4CAAUpdateCalculatePanel.Style.Add("display", "none");
                corporateActionAdjustment.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The RowData Bound Event of gvCAAjd GridView
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        /// <param name="sender">gvCAAjd GridView</param>
        /// <param name="e">e</param>
        /// <param name="n_index">int n_index parameter</param>
        /// <param name="hash_Table">hashtable of all ref int parameters</param>
        internal void gvCAAjd_RowDataBound(CorporateActionAdjustment corporateActionAdjustment, object sender, GridViewRowEventArgs e, ref int n_index, ref Hashtable hash_Table)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    hash_Table["n_ID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    hash_Table["n_Delete"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "COMPANY NAME":
                                    hash_Table["n_CompanyName"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION_TYPE":
                                    hash_Table["n_ACTION_TYPE"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "CORPORATE ACTION TYPE":
                                    hash_Table["n_CorporateActionType"] = n_index;
                                    break;

                                case "EFFECTIVE DATE":
                                    hash_Table["n_EffectiveDate"] = n_index;
                                    break;

                                case "EFFECTIVE_DATE":
                                    hash_Table["n_EFFECTIVE_DATE"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "RATIO":
                                    hash_Table["n_Ratio"] = n_index;
                                    break;

                                case "RATIO_MULTIPLIER":
                                    hash_Table["n_RATIO_MULTIPLIER"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "RATIO_DIVISOR":
                                    hash_Table["n_RATIO_DIVISOR"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "APPLIED":
                                    hash_Table["n_Applied"] = n_index;
                                    break;

                                case "APPLIED_EDIT":
                                    hash_Table["n_APPLIED_EDIT"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "APPLYTO":
                                    hash_Table["n_ApplyTo"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "COMMENTS":
                                    hash_Table["n_Comments"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    hash_Table["n_Action"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTIONS":
                                    hash_Table["n_Actions"] = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_ID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_Delete"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_CompanyName"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_ACTION_TYPE"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_EFFECTIVE_DATE"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_RATIO_MULTIPLIER"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_RATIO_DIVISOR"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_APPLIED_EDIT"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_ApplyTo"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_Comments"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_Action"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_Ratio"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_EffectiveDate"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_Applied"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_Actions"].ToString())].HorizontalAlign = HorizontalAlign.Center;

                        e.Row.Cells[Convert.ToInt32(hash_Table["n_Applied"].ToString())].Controls.Add(AddControl(corporateActionAdjustment, "CheckBox", "chkBox", string.Empty, string.Empty, string.Empty, string.Empty, e.Row.Cells[Convert.ToInt32(hash_Table["n_Applied"].ToString())].Text, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty));
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_Actions"].ToString())].Controls.Add(AddControl(corporateActionAdjustment, "ImageButton", "imgBtnEdit", "~/View/App_Themes/images/Edit.png", "Click to Update Corporate Action", "UpdateCorporateAction", string.Empty, e.Row.Cells[Convert.ToInt32(hash_Table["n_ID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_CorporateActionType"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_Ratio"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_EffectiveDate"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_ApplyTo"].ToString())].Text, string.Empty));
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_Actions"].ToString())].Controls.Add(AddControl(corporateActionAdjustment, "ImageButton", "imgBtnRevert", "~/View/App_Themes/images/Revert.png", "Click to Revert Corporate Action Effect", "RevertCorporateAction", string.Empty, e.Row.Cells[Convert.ToInt32(hash_Table["n_EFFECTIVE_DATE"].ToString())].Text, string.Empty, string.Empty, string.Empty, string.Empty, Convert.ToString(CommonModel.CheckAgainstLockedAccountingReport(e.Row.Cells[Convert.ToInt32(hash_Table["n_EffectiveDate"].ToString())].Text, userSessionInfo) ? 1 : 0)));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Add Controls to the GridView
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        /// <param name="s_ControlName">Name of the Control</param>
        /// <param name="s_ControlID">ID of the Control</param>
        /// <param name="s_ControlText">Text of the Control</param>
        /// <param name="s_Tooltip">Tooltip of the Control</param>
        /// <param name="s_JavascriptMethodName">Javascript Method Name of the Control</param>
        /// <param name="s_EventName">Event Name  of the Control</param>
        /// <param name="s_ParameterOne">Parameter One to be passed to the Control</param>
        /// <param name="s_ParameterTwo">Parameter Two to be passed to the Control</param>
        /// <param name="s_ParameterThree">Parameter Three to be passed to the Control</param>
        /// <param name="s_ParameterFour">Parameter Four to be passed to the Control</param>
        /// <param name="s_ParameterFive">Parameter Five to be passed to the Control</param>
        /// <param name="s_IsLocked">s_IsLocked to check lock report</param>
        /// <returns>Control CheckBox/ImageButton</returns>
        private Control AddControl(CorporateActionAdjustment corporateActionAdjustment, string s_ControlName, string s_ControlID, string s_ControlText, string s_Tooltip, string s_JavascriptMethodName, string s_EventName, string s_ParameterOne, string s_ParameterTwo, string s_ParameterThree, string s_ParameterFour, string s_ParameterFive,string s_IsLocked)
        {
            try
            {
                switch (s_ControlName)
                {
                    case "CheckBox":
                        CheckBox checkBox = new CheckBox();
                        checkBox.ID = s_ControlID;
                        checkBox.CssClass = "chkBox";
                        checkBox.Enabled = false;
                        checkBox.Checked = s_ParameterOne.Equals("YES");

                        return checkBox;

                    case "ImageButton":
                        ImageButton imageButton = new ImageButton();
                        imageButton.ID = s_ControlID;
                        imageButton.ToolTip = s_Tooltip;
                        imageButton.ImageUrl = s_ControlText;
                        imageButton.CssClass = s_JavascriptMethodName.Equals("UpdateCorporateAction") ? "update" : "revert";
                        imageButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                        EnableDisableControls(imageButton, corporateActionAdjustment);

                        switch (s_JavascriptMethodName)
                        {
                            case "UpdateCorporateAction":
                                imageButton.Attributes.Add("onclick", "return UpdateCorporateAction('" + s_ParameterOne + "','" + s_ParameterTwo + "','" + s_ParameterThree + "','" + s_ParameterFour + "','" + s_ParameterFive + "',this)");
                                break;

                            case "RevertCorporateAction":
                                imageButton.Attributes.Add("onclick", "return RevertCorporateAction('" + s_ParameterOne + "',this,'" + s_IsLocked + "')");
                                break;
                        }

                        return imageButton;
                }

                return new Control();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The btnCAAUpdateCorpAct Button Click Event. This method is used to Bind gvCAAUpdateCorpAction GridView
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        internal void btnCAAUpdateCorpAct_Click(CorporateActionAdjustment corporateActionAdjustment)
        {
            try
            {
                corporateActionAdjustment.corpActUpdRevertUC.lblCAACorpActVal.Font.Bold = corporateActionAdjustment.corpActUpdRevertUC.lblCAACorpActRatioVal.Font.Bold = corporateActionAdjustment.corpActUpdRevertUC.lblCAAEffectDateVal.Font.Bold = corporateActionAdjustment.corpActUpdRevertUC.lblCAAToOptions.Font.Bold = corporateActionAdjustment.corpActCalculationUC.lblCAACorpActVal.Font.Bold = corporateActionAdjustment.corpActCalculationUC.lblCAACorpActRatioVal.Font.Bold = corporateActionAdjustment.corpActCalculationUC.lblCAAEffectDateVal.Font.Bold = corporateActionAdjustment.corpActCalculationUC.lblCAAToOptions.Font.Bold = true;

                corporateActionAdjustment.corpActUpdRevertUC.lblCAACorpActVal.Text = corporateActionAdjustment.corpActCalculationUC.lblCAACorpActVal.Text = Convert.ToString(corporateActionAdjustment.hdnCAACorpActVal.Value);
                corporateActionAdjustment.corpActUpdRevertUC.lblCAACorpActRatioVal.Text = corporateActionAdjustment.corpActCalculationUC.lblCAACorpActRatioVal.Text = Convert.ToString(corporateActionAdjustment.hdnCAACorpActRatioVal.Value);
                corporateActionAdjustment.corpActUpdRevertUC.lblCAAEffectDateVal.Text = corporateActionAdjustment.corpActCalculationUC.lblCAAEffectDateVal.Text = Convert.ToString(corporateActionAdjustment.hdnCAAEffectDateVal.Value);
                corporateActionAdjustment.corpActUpdRevertUC.lblCAAToOptions.Text = corporateActionAdjustment.corpActCalculationUC.lblCAAToOptions.Text = corporateActionAdjustment.corpActCalculationUC.hdnlblCAAToOptions.Value.Equals("A") ? Convert.ToString((ac_CorporateActionAdjustment.dt_CorpActionAdjUI.Select("LabelID = 'lblCAAApplyToAllOptions'"))[0]["LabelName"]) : Convert.ToString((ac_CorporateActionAdjustment.dt_CorpActionAdjUI.Select("LabelID = 'lblCAAApplyToOutStandOptions'"))[0]["LabelName"]);

                corporateActionAdjustment.corpActUpdRevertUC.btnCAAUpdateCorpAct_Click(Convert.ToString(corporateActionAdjustment.hdnCAAEffectDateVal.Value));

                corporateActionAdjustment.hdnAccordionIndex.Value = corporateActionAdjustment.hdnAccordionIndex.Value.Equals("2") ? corporateActionAdjustment.hdnAccordionIndex.Value : "1";

                corporateActionAdjustment.h4CAAUpdateRevertPanel.Style.Add("display", "block");

                if (corporateActionAdjustment.hdnAccordionIndex.Value.Equals("2"))
                    corporateActionAdjustment.h4CAAUpdateCalculatePanel.Style.Add("display", "block");
                else
                    corporateActionAdjustment.h4CAAUpdateCalculatePanel.Style.Add("display", "none");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Revert Corporate Action Button Click Event. It will revert the Applied Corporate Action.
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        internal void btnCAARevertCorpAct_Click(CorporateActionAdjustment corporateActionAdjustment)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    corporateActionAdjustment.corpActUpdRevertUC.CheckForLockedData(corporateActionAdjustment.hdnCAAEffectDateVal.Value, accountingServiceClient);

                    if (ac_CorporateActionAdjustment.dt_UpdateCorpActAdj.Rows[0]["IS_LOCKED"].Equals(1))
                    {
                        DisplayMessage(corporateActionAdjustment, "btnCAARevertCorpAct", 2);
                    }
                    else
                    {
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.PageName = CommonConstantModel.s_CorporateActionAdjustment;
                        accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                        accountingProperties.PopulateControls = "Apply_Revert_Corporate_Action_To_Data";
                        accountingProperties.Action = "REVERT";
                        accountingProperties.Effective_Date = Convert.ToDateTime(corporateActionAdjustment.hdnCAAEffectDateVal.Value);
                        accountingProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                        DisplayMessage(corporateActionAdjustment, "btnCAARevertCorpAct", accountingCRUDProperties.a_result);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The btnCAAUpdateCorpActEffect Button Click Event. This method is used to Adjust/Update Corporate Action Data
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        internal void btnCAAUpdateCorpActEffect_Click(CorporateActionAdjustment corporateActionAdjustment)
        {
            try
            {
                corporateActionAdjustment.corpActCalculationUC.hdnCAAUpdGrntOptID.Value = corporateActionAdjustment.hdnCAAGrntOptID.Value;
                corporateActionAdjustment.corpActCalculationUC.hdnCorpActType.Value = corporateActionAdjustment.hdnCAACorpActVal.Value;

                corporateActionAdjustment.corpActCalculationUC.btnCAAUpdateCorpActEffect_Click(Convert.ToString(corporateActionAdjustment.hdnCAAGrntOptID.Value));

                corporateActionAdjustment.hdnAccordionIndex.Value = "2";
                corporateActionAdjustment.h4CAAUpdateCalculatePanel.Style.Add("display", "block");
                corporateActionAdjustment.divCAAUpdateCalculate.Style.Add("display", "block");

                corporateActionAdjustment.corpActCalculationUC.btnCAACalculate.Enabled = corporateActionAdjustment.corpActCalculationUC.lblCAACorpActVal.Text.Equals("OTHERS") ? false : true;
                corporateActionAdjustment.corpActCalculationUC.btnCAACalcSave.Enabled = corporateActionAdjustment.corpActCalculationUC.lblCAACorpActVal.Text.Equals("OTHERS") ? true : false;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Page Index Change Event of gvCAAjd GridView
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        /// <param name="e">e</param>
        internal void gvCAAjd_PageIndexChanging(CorporateActionAdjustment corporateActionAdjustment, GridViewPageEventArgs e)
        {
            try
            {
                corporateActionAdjustment.gvCAAjd.PageIndex = e.NewPageIndex;

                corporateActionAdjustment.gvCAAjd.DataSource = ac_CorporateActionAdjustment.dt_CorpActAdj;
                corporateActionAdjustment.gvCAAjd.DataBind();

                corporateActionAdjustment.h4CAAUpdateRevertPanel.Style.Add("display", "none");
                corporateActionAdjustment.h4CAAUpdateCalculatePanel.Style.Add("display", "none");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind gvCAAjd GridView
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        internal void BindgvCAAjdGridView(CorporateActionAdjustment corporateActionAdjustment)
        {
            try
            {
                BindGrid(corporateActionAdjustment);

                corporateActionAdjustment.h4CAAUpdateCalculatePanel.Style.Add("display", "none");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to display the Message
        /// </summary>
        /// <param name="corporateActionAdjustment">corporateActionAdjustment Page Object</param>
        /// <param name="s_SenderID">Control ID</param>
        /// <param name="n_Result">int Result</param>
        internal void DisplayMessage(CorporateActionAdjustment corporateActionAdjustment, string s_SenderID, int n_Result)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    corporateActionAdjustment.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                    corporateActionAdjustment.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    corporateActionAdjustment.h4CAAUpdateRevertPanel.Style.Add("display", "none");

                    if (n_Result == 0)
                    {
                        corporateActionAdjustment.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                        corporateActionAdjustment.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblCAAErrorSave", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                    }
                    else
                    {
                        switch (s_SenderID)
                        {
                            case "btnCAACalcSave":
                                corporateActionAdjustment.h4CAAUpdateRevertPanel.Style.Add("display", "block");

                                switch (n_Result)
                                {
                                    case 1:
                                        corporateActionAdjustment.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblCAASuccessSave", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                                        corporateActionAdjustment.h4CAAUpdateCalculatePanel.Style.Add("display", "none");
                                        corporateActionAdjustment.hdnAccordionIndex.Value = "1";
                                        break;

                                    case 2:
                                        corporateActionAdjustment.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblCAASuccessSave", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                                        corporateActionAdjustment.corpActCalculationUC.hdnddlCAAVestingDatesIndex.Value = "Set";
                                        break;
                                }
                                break;

                            case "btnCAAApply":
                                corporateActionAdjustment.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblCAASuccessApply", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                                corporateActionAdjustment.hdnAccordionIndex.Value = "0";
                                break;

                            case "btnCAARevertCorpAct":
                                switch (n_Result)
                                {
                                    case 1:
                                        corporateActionAdjustment.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblCAASuccessRevert", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                                        corporateActionAdjustment.hdnAccordionIndex.Value = "0";
                                        break;

                                    case 2:
                                        corporateActionAdjustment.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                        corporateActionAdjustment.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblCAACantRevertAsDataIsLocked", CommonConstantModel.s_CorporateActionAdjustment, CommonConstantModel.s_AccountingL10);
                                        break;
                                }
                                break;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CorporateActionAdjustmentModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}