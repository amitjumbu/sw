﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting.UserControl;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Forfeiture Group Creation Model Class
    /// </summary>
    public class ForfeitureGroupCreationModel : BaseModel, IDisposable
    {
        #region Default Constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public ForfeitureGroupCreationModel()
        {
            if (ac_ForfeitureSetup == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ForfeitureSetup);
                ac_ForfeitureSetup = (CommonModel.AC_ForfeitureSetup)HttpContext.Current.Session[CommonConstantModel.s_AC_ForfeitureSetup];
            }
        }
        #endregion

        #region Static Variables

        /// <summary>
        /// 
        /// </summary>
        public static string s_FGCSaveText = string.Empty, s_FGCSaveToolTip = string.Empty;

        #endregion

        #region Page Load event

        /// <summary>
        /// Page Load event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        internal void Page_Load(ForfeitureGroupCreationUC forfeitureGroupCreationUC)
        {
            try
            {

            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Bind UI method to bind controls from XML file
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        public void BindUI(ForfeitureGroupCreationUC forfeitureGroupCreationUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_ForfeitureSetup.dt_ForfeitureSetupUI == null || ac_ForfeitureSetup.dt_ForfeitureSetupUI.Rows.Count.Equals(0))
                    {
                        ac_ForfeitureSetup.dt_ForfeitureSetupUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10_UI);
                    }
                    if ((ac_ForfeitureSetup.dt_ForfeitureSetupUI != null) && (ac_ForfeitureSetup.dt_ForfeitureSetupUI.Rows.Count > 0))
                    {
                        foreach (Control control in forfeitureGroupCreationUC.divForfeitureGrpCreatn.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_ForfeitureSetup.dt_ForfeitureSetupUI, (Label)control, null, null, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, (TextBox)control, null, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, (Button)control, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcCheckbox:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeCheckBox, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, (CheckBox)control, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, (RadioButton)control, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, (BaseValidator)control, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, (BaseValidator)control, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRangeValidator:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRangeValidator, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, null, (BaseValidator)control, null, null);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, null, null, (GridView)control, null);
                                    break;

                                case CommonConstantModel.s_wcHyperLink:
                                    CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeHyperLink, ac_ForfeitureSetup.dt_ForfeitureSetupUI, null, null, null, null, null, null, null, null, null, (HyperLink)control);
                                    break;
                            }
                        }
                    }
                }
                s_FGCSaveText = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'btnFGCSave'"))[0]["LabelName"]);
                s_FGCSaveToolTip = Convert.ToString((ac_ForfeitureSetup.dt_ForfeitureSetupUI.Select("LabelID = 'btnFGCSave'"))[0]["LabelName"]);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind/populate all the controls
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="s_Type">Type of event</param>
        /// <param name="b_IsEditClick">Boolean value to check edit click event</param>
        /// <param name="b_IsApprovalScreen">b_IsApprovalScreen</param>
        internal void BindFGCControls(ForfeitureGroupCreationUC forfeitureGroupCreationUC, string s_Type, bool b_IsEditClick, bool b_IsApprovalScreen)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PAGE_SIZE = ac_ForfeitureSetup.n_PageSize.Equals(0) ? 10 : ac_ForfeitureSetup.n_PageSize;
                    accountingProperties.PAGE_INDEX = ac_ForfeitureSetup.n_PageIndex.Equals(0) ? 1 : ac_ForfeitureSetup.n_PageIndex;
                    accountingProperties.PopulateControls = CommonConstantModel.s_FGCRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.FGAID = string.IsNullOrEmpty(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit) 
                                                ? 0 
                                                : ((s_Type.Equals("FGC") || s_Type.Equals("FGC_FILE_UPLOAD")) && !(string.IsNullOrEmpty(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit))) 
                                                 ? 0 
                                                 : Convert.ToInt32(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit);

                    if (b_IsApprovalScreen)
                        accountingProperties.IS_APPROVAL_DATA = true;
                    if (!s_Type.Equals("FGC_FILE_UPLOAD") && !s_Type.Equals("PopupClose") && !s_Type.Equals("FGC_ERROR"))
                    {
                        ac_ForfeitureSetup.ds_ForfeitureSetupDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;
                        ac_ForfeitureSetup.dt_ForfeitureSetupDetails = ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[0];
                        ac_ForfeitureSetup.dt_AllEmployeesList = ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[2];
                        ac_ForfeitureSetup.dt_AssociatedEmployeesList = ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[3];
                        ac_ForfeitureSetup.dt_SelectedEmployeesList = ac_ForfeitureSetup.dt_SelectedEmployeesList != null && ac_ForfeitureSetup.dt_SelectedEmployeesList.Rows.Count.Equals(0) ? ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[3].Copy() : ac_ForfeitureSetup.dt_SelectedEmployeesList;
                        ac_ForfeitureSetup.n_GridViewRecordsCount = Convert.ToInt32(ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[4].Rows[0]["TOTAL_COUNT"]);
                    }
                    forfeitureGroupCreationUC.gvFGCForfeitureGroup.DataSource = ac_ForfeitureSetup.dt_ForfeitureSetupDetails;
                    forfeitureGroupCreationUC.gvFGCForfeitureGroup.DataBind();
                    forfeitureGroupCreationUC.lblFGCNote.Visible = ac_ForfeitureSetup.dt_ForfeitureSetupDetails.Rows.Count > 0;
                    forfeitureGroupCreationUC.hplFGCForfeitureGrpEmpList.Visible = ac_ForfeitureSetup.dt_ForfeitureSetupDetails.Rows.Count > 0;
                    if (!s_Type.Equals("FGC_ERROR"))
                    {
                        if (s_Type.Equals("PopupClose"))
                        {
                            ac_ForfeitureSetup.s_Type = s_Type.ToString();
                            forfeitureGroupCreationUC.gvFGCAssociatedEmployees.DataSource = ac_ForfeitureSetup.dt_SelectedEmployeesList;
                        }
                        else forfeitureGroupCreationUC.gvFGCAssociatedEmployees.DataSource = ac_ForfeitureSetup.dt_AssociatedEmployeesList;
                        forfeitureGroupCreationUC.gvFGCAssociatedEmployees.DataBind();
                    }
                    if (b_IsEditClick)
                    {
                        forfeitureGroupCreationUC.gvFGCUploadedFiles.DataSource = ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[1];
                        forfeitureGroupCreationUC.gvFGCUploadedFiles.DataBind();
                    }
                    else
                    {
                        forfeitureGroupCreationUC.gvFGCUploadedFiles.DataSource = ac_ForfeitureSetup.dt_ForfeitureDocuments;
                        forfeitureGroupCreationUC.gvFGCUploadedFiles.DataBind();
                    }
                    if (b_IsApprovalScreen)
                    {
                        forfeitureGroupCreationUC.btnFCGAddNewGroup.Style.Add("display", "none");
                        forfeitureGroupCreationUC.btnFGCApprove.Style.Add("display", "");
                        forfeitureGroupCreationUC.btnFGCDisapprove.Style.Add("display", "");
                        forfeitureGroupCreationUC.btnFGCSave.Style.Add("display", "none");
                        forfeitureGroupCreationUC.btnFGCFileUpload.Style.Add("display", "none");
                        forfeitureGroupCreationUC.btnFGCClearFileContent.Style.Add("display", "none");
                        forfeitureGroupCreationUC.hplFGCSelectEmployees.Style.Add("display", "none");
                        forfeitureGroupCreationUC.rblFGCAssignGroupTo.Enabled = false;
                        forfeitureGroupCreationUC.lblFGCUploadDoc.Text = "Uploaded Documents";
                        forfeitureGroupCreationUC.fileFGCUploadDoc.Style.Add("display", "none");
                        forfeitureGroupCreationUC.hplFGCForfeitureGrpEmpList.Style.Add("display", "none");
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Forfeiture group Save button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="s_FolderPath">Folder path to save uploaded file(s) to the server</param>
        /// <returns>returns result( 0- Error ,1- Inserted Successfully ,2- Updated Successfully )</returns>
        internal int btnFGCSave_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC, string s_FolderPath)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    if (!string.IsNullOrEmpty(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value))
                        accountingProperties.FGAID = Convert.ToInt32(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value);
                    accountingProperties.FORFEITURE_GROUP_NAME = forfeitureGroupCreationUC.txtFGCGroupName.Text;
                    accountingProperties.FORFEITURE_RATE = Convert.ToDecimal(forfeitureGroupCreationUC.txtFGCForfeitureRate.Text);
                    accountingProperties.APPLICABLE_FROM_DATE = forfeitureGroupCreationUC.txtFGCApplFromDate.Text;
                    accountingProperties.APPLICABLE_TO_DATE = forfeitureGroupCreationUC.hdnFGCForfrToDateToEdit.Value;
                    accountingProperties.COMMENTS = forfeitureGroupCreationUC.txtFCGComments.Text;
                    accountingProperties.EMPLOYEE_CHECK = forfeitureGroupCreationUC.rblFGCAssignGroupTo.SelectedItem.Value;
                    accountingProperties.IS_DELETED = false;
                    if (userSessionInfo.ACC_UerTypeID.Equals(5))
                        accountingProperties.IS_APPROVED = true;
                    else accountingProperties.IS_APPROVED = false;

                    /* forfeiture employee association - start */
                    if (accountingProperties.EMPLOYEE_CHECK.Equals("S") && ac_ForfeitureSetup.dt_AssociatedEmployeesList.Rows.Count <= 0 && ac_ForfeitureSetup.dt_SelectedEmployeesList.Rows.Count <= 0)
                    {
                        /* please select employee(s) or select 'No Employees' option as you haven't associated/selected any employee to the group. */
                        return 10;
                    }
                    if (accountingProperties.EMPLOYEE_CHECK.Equals("S") && ac_ForfeitureSetup.dt_SelectedEmployeesList.Rows.Count <= 0 && string.IsNullOrEmpty(accountingProperties.FGAID.ToString()))
                    {
                        /* please select employee(s) as you haven't associated/selected any employee to the group. */
                        return 13;
                    }
                    if (!string.IsNullOrEmpty(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value) && Convert.ToInt32(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value.Trim()) > 0)
                    {
                        if (accountingProperties.EMPLOYEE_CHECK.Equals("S"))
                        {
                            int n_CountChk = 0;

                            if (ac_ForfeitureSetup.dt_AssociatedEmployeesList.Rows.Count > 0 && ac_ForfeitureSetup.dt_SelectedEmployeesList.Rows.Count > 0)
                            {
                                n_CountChk = ac_ForfeitureSetup.dt_AssociatedEmployeesList.AsEnumerable().Select(r => r.Field<int>("EMPID"))
                                        .Except(ac_ForfeitureSetup.dt_SelectedEmployeesList.AsEnumerable().Select(r => r.Field<int>("EMPID"))).Count();
                            }

                            if (n_CountChk > 0 && forfeitureGroupCreationUC.txtFGCApplFromDateEdit.Text.Equals("dd/mmm/yyyy") || string.IsNullOrEmpty(forfeitureGroupCreationUC.txtFGCApplFromDateEdit.Text))
                                return 11; /* Please select Applicable From Date for newly added / removed employee(s). */
                        }
                        else if (accountingProperties.EMPLOYEE_CHECK.Equals("A"))
                        {
                            int n_CountChk = ac_ForfeitureSetup.dt_AllEmployeesList.AsEnumerable().Select(r => r.Field<int>("EMPID"))
                                            .Except(ac_ForfeitureSetup.dt_AssociatedEmployeesList.AsEnumerable().Select(r => r.Field<int>("EMPID"))).Count();
                            if (n_CountChk > 0)
                                return 11; /* Please select Applicable From Date for newly added / removed employee(s). */
                        }
                        else if (accountingProperties.EMPLOYEE_CHECK.Equals("N") && ac_ForfeitureSetup.dt_AssociatedEmployeesList.Rows.Count > 0 && (forfeitureGroupCreationUC.txtFGCApplFromDateEdit.Text.Equals("dd/mmm/yyyy") || string.IsNullOrEmpty(forfeitureGroupCreationUC.txtFGCApplFromDateEdit.Text)))
                        {
                            return 11; /* Please select Applicable From Date for newly added / removed employee(s). */
                        }
                    }
                    if (accountingProperties.EMPLOYEE_CHECK.Equals("A") && ac_ForfeitureSetup.dt_AllEmployeesList.Rows.Count > 0)
                    {
                        ac_ForfeitureSetup.dt_AssociatedEmployeesList = ac_ForfeitureSetup.dt_AllEmployeesList.Copy();
                        using (AccountingServiceClient o_accountingServiceClient = new AccountingServiceClient())
                        {
                            accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                            accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                            accountingProperties.PAGE_SIZE = ac_ForfeitureSetup.n_PageSize.Equals(0) ? 10 : ac_ForfeitureSetup.n_PageSize;
                            accountingProperties.PAGE_INDEX = ac_ForfeitureSetup.n_PageIndex.Equals(0) ? 1 : ac_ForfeitureSetup.n_PageIndex;
                            accountingProperties.PopulateControls = CommonConstantModel.s_FGCRead;
                            accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            accountingProperties.FGAID = string.IsNullOrEmpty(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit) ? 0 : Convert.ToInt32(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit);
                            accountingProperties.s_GET_ALL_EMPLOYEE = "TRUE";
                            accountingCRUDProperties = o_accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                            ac_ForfeitureSetup.dt_AssociatedEmployeesList = accountingCRUDProperties.ds_Result.Tables[6].Copy();
                        }
                    }
                    else if (accountingProperties.EMPLOYEE_CHECK.Equals("S") && ac_ForfeitureSetup.dt_SelectedEmployeesList.Rows.Count > 0)
                    {
                        ac_ForfeitureSetup.dt_AssociatedEmployeesList = ac_ForfeitureSetup.dt_SelectedEmployeesList.Copy();
                    }
                    if (ac_ForfeitureSetup.dt_AssociatedEmployeesList.Rows.Count > 0)
                    {
                        using (DataTable dt_Employees = new DataTable())
                        {
                            dt_Employees.Columns.Add("EMPID", typeof(int));
                            dt_Employees.Columns.Add("APPLICABLE_FROM_DATE", typeof(string));
                            foreach (DataRow o_row in ac_ForfeitureSetup.dt_AssociatedEmployeesList.Rows)
                            {
                                DataRow dr1 = dt_Employees.NewRow();
                                dr1[0] = o_row[1];
                                dr1[1] = !string.IsNullOrEmpty(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value) && !forfeitureGroupCreationUC.txtFGCApplFromDateEdit.Text.Equals("dd/mmm/yyyy") ? forfeitureGroupCreationUC.txtFGCApplFromDateEdit.Text : forfeitureGroupCreationUC.txtFGCApplFromDate.Text;
                                dt_Employees.Rows.Add(dr1);
                            }
                            dt_Employees.TableName = "DT";
                            accountingProperties.dt_EMPLOYEE_ASSOCIATION = dt_Employees;
                        }
                    }
                    /* forfeiture employee association - end */
                    /* forfeiture documents - start */
                    if (ac_ForfeitureSetup.dt_ForfeitureDocuments.Rows.Count > 0)
                    {
                        using (DataTable dt_Documents = new DataTable())
                        {
                            dt_Documents.Columns.Add("FGAID", typeof(int));
                            dt_Documents.Columns.Add("File Name", typeof(string));
                            dt_Documents.Columns.Add("File Path", typeof(string));
                            foreach (DataRow o_row in ac_ForfeitureSetup.dt_ForfeitureDocuments.Rows)
                            {
                                string s_ReturnStr = SaveFileToServer(forfeitureGroupCreationUC, Convert.ToString(o_row[2]), s_FolderPath + forfeitureGroupCreationUC.txtFGCGroupName.Text.Trim() + "/", false);
                                if (!string.IsNullOrEmpty(s_ReturnStr))
                                {
                                    string[] files = s_ReturnStr.Split('~');
                                    DataRow dr1 = dt_Documents.NewRow();
                                    dr1[0] = 0;
                                    dr1[1] = files[1];
                                    dr1[2] = files[0];
                                    dt_Documents.Rows.Add(dr1);
                                }
                            }
                            dt_Documents.TableName = "DT";
                            accountingProperties.dt_FORFEITURE_DOCUMENTS = dt_Documents;
                        }
                    }
                    /* forfeiture documents - End */
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    accountingProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    DeleteDirectory(s_FolderPath + userSessionInfo.ACC_UserName);
                    forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value = forfeitureGroupCreationUC.hdnFGCForfrToDateToEdit.Value = forfeitureGroupCreationUC.hdnFGCForFromDateToEdit.Value = string.Empty;

                    //Check whether report is locked or not for entered CA_AppDate
                    if (!CommonModel.CheckAgainstLockedAccountingReport(Convert.ToString(forfeitureGroupCreationUC.txtFGCApplFromDate.Text), userSessionInfo))
                    {
                        accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                        accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                        accountingProperties.PopulateControls = CommonConstantModel.s_ForfeitureGroupCreation;
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                        return accountingServiceClient.CRUDAccountingOperations(accountingProperties).a_result;
                    }
                    else
                    {
                        //set accountingProperties.a_result = 12 or 13  if accounting report is locked for CA_EffectiveDate
                        return 12;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Delete Forfeiture group Button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <returns>returns integer value ( 0 - Error, 1- Deleted successfully ) </returns>
        internal int btnFGCDeleteFGrp_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.PopulateControls = CommonConstantModel.s_ForfeitureGroupCreation;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    if (!string.IsNullOrEmpty(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value))
                        accountingProperties.FGAID = Convert.ToInt32(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value);
                    accountingProperties.IS_DELETED = true;
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    accountingProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value = forfeitureGroupCreationUC.hdnFGCForfrToDateToEdit.Value = forfeitureGroupCreationUC.hdnFGCForFromDateToEdit.Value = string.Empty;
                    return accountingServiceClient.CRUDAccountingOperations(accountingProperties).a_result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Forfeiture group Edit button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="b_IsApprovalPage">boolean value to check whether the current screen is approval</param>
        internal void btnFGCEdit_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC, bool b_IsApprovalPage)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_FGCRead;
                    accountingProperties.PAGE_SIZE = ac_ForfeitureSetup.n_PageSize.Equals(0) ? 10 : ac_ForfeitureSetup.n_PageSize;
                    accountingProperties.PAGE_INDEX = ac_ForfeitureSetup.n_PageIndex.Equals(0) ? 1 : ac_ForfeitureSetup.n_PageIndex;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_ForfeitureSetup.n_GridViewRecordsCount = Convert.ToInt32(ac_ForfeitureSetup.ds_ForfeitureSetupDetails.Tables[4].Rows[0]["TOTAL_COUNT"]);
                    accountingProperties.FGAID = Convert.ToInt32(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value);
                    ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit = forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value;

                    ac_ForfeitureSetup.ds_ForfeitureEditDetails = accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result;

                    if (ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[0].Rows.Count > 0)
                    {
                        forfeitureGroupCreationUC.txtFGCGroupName.Text = Convert.ToString(ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[0].Rows[0]["Group Name"]);
                        forfeitureGroupCreationUC.txtFGCGroupName.Enabled = false;
                        forfeitureGroupCreationUC.txtFGCForfeitureRate.Text = Convert.ToString(ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[0].Rows[0]["Forfeiture Rate (%)"]);
                        forfeitureGroupCreationUC.txtFGCApplFromDate.Text = Convert.ToDateTime(ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[0].Rows[0]["Applicable From Date"]).ToString("dd/MMM/yyyy");
                        forfeitureGroupCreationUC.txtFGCApplFromDateEdit.Text = string.Empty;
                        forfeitureGroupCreationUC.hdnFGCForfrToDateToEdit.Value = !string.IsNullOrEmpty(Convert.ToString(ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[0].Rows[0]["To Date"])) ? Convert.ToDateTime(ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[0].Rows[0]["To Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                        forfeitureGroupCreationUC.rblFGCAssignGroupTo.ClearSelection();
                        forfeitureGroupCreationUC.rblFGCAssignGroupTo.Items.FindByValue(Convert.ToString(ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[0].Rows[0]["EMPLOYEE_CHECK"]).Trim()).Selected = true;
                        forfeitureGroupCreationUC.txtFCGComments.Text = Convert.ToString(ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[0].Rows[0]["COMMENTS"]);
                        forfeitureGroupCreationUC.hdnFGCAccordionIndex.Value = "1";
                        forfeitureGroupCreationUC.h3FGCAddEdit.Style.Add("display", "");
                        forfeitureGroupCreationUC.h3FGCHistory.Style.Add("display", "none");
                        ac_ForfeitureSetup.s_Type = string.Empty;
                        if (!b_IsApprovalPage)
                            forfeitureGroupCreationUC.trFGCApplFromDateEdit.Style.Add("display", "");
                        if (Convert.ToBoolean(ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[0].Rows[0]["IS_APPROVED"]))
                            forfeitureGroupCreationUC.btnFGCSave.Enabled = true;
                        else
                        {
                            forfeitureGroupCreationUC.btnFGCSave.Enabled = false;
                            forfeitureGroupCreationUC.btnFGCSave.ToolTip = accountingServiceClient.GetAccounting_L10N("lblFGCCanNotEdit", CommonConstantModel.s_ForfeitureSetup, CommonConstantModel.s_AccountingL10);
                        }
                    }
                    ac_ForfeitureSetup.dt_ForfeitureDocuments = ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[1];
                    ac_ForfeitureSetup.dt_AllEmployeesList = ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[2];
                    ac_ForfeitureSetup.dt_AssociatedEmployeesList = ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[3];
                    //ac_ForfeitureSetup.dt_SelectedFGEmployeesList = ac_ForfeitureSetup.ds_ForfeitureEditDetails.Tables[6];
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// View history button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        internal void btnFGCViewHistory_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_FGCHistoryData;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.FGAID = Convert.ToInt32(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value);
                    accountingProperties.HISTORY_TYPE = CommonConstantModel.s_FGHistoryType;
                    ac_ForfeitureSetup.dt_ForfeitureHistoryData = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                    forfeitureGroupCreationUC.lblFGCHistoryHeader.Text = "Forfeiture Group : " + Convert.ToString(ac_ForfeitureSetup.dt_ForfeitureHistoryData.Rows[0]["Group Name"]);
                    forfeitureGroupCreationUC.gvFGCHistory.DataSource = ac_ForfeitureSetup.dt_ForfeitureHistoryData;
                    forfeitureGroupCreationUC.gvFGCHistory.DataBind();
                    forfeitureGroupCreationUC.hdnFGCAccordionIndex.Value = "2";
                    forfeitureGroupCreationUC.h3FGCAddEdit.Style.Add("display", "none");
                    forfeitureGroupCreationUC.h3FGCHistory.Style.Add("display", "");
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add New Group button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        public void btnFCGAddNewGroup_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC)
        {
            try
            {
                ac_ForfeitureSetup.dt_AssociatedEmployeesList = new DataTable();
                ac_ForfeitureSetup.dt_SelectedEmployeesList = new DataTable();
                forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value = forfeitureGroupCreationUC.txtFGCGroupName.Text = forfeitureGroupCreationUC.txtFGCForfeitureRate.Text = forfeitureGroupCreationUC.txtFGCApplFromDate.Text = string.Empty;
                forfeitureGroupCreationUC.hdnFGCForFromDateToEdit.Value = forfeitureGroupCreationUC.hdnFGCForfrToDateToEdit.Value = forfeitureGroupCreationUC.txtFCGComments.Text = string.Empty;
                forfeitureGroupCreationUC.hdnFGCAccordionIndex.Value = "1";
                ac_ForfeitureSetup.s_Type = "FGC_FILE_UPLOAD";
                forfeitureGroupCreationUC.h3FGCAddEdit.Style.Add("display", "");
                forfeitureGroupCreationUC.h3FGCHistory.Style.Add("display", "none");
                forfeitureGroupCreationUC.txtFGCGroupName.Enabled = true;
                forfeitureGroupCreationUC.trFGCApplFromDateEdit.Style.Add("display", "none");
                forfeitureGroupCreationUC.rblFGCAssignGroupTo.ClearSelection();
                forfeitureGroupCreationUC.rblFGCAssignGroupTo.Items.FindByValue("N").Selected = true;
                forfeitureGroupCreationUC.gvFGCAssociatedEmployees.DataSource = null;
                forfeitureGroupCreationUC.gvFGCAssociatedEmployees.DataBind();
                forfeitureGroupCreationUC.gvFGCUploadedFiles.DataSource = null;
                forfeitureGroupCreationUC.gvFGCUploadedFiles.DataBind();
                forfeitureGroupCreationUC.txtFGCApplFromDateEdit.Text = string.Empty;
                forfeitureGroupCreationUC.btnFGCSave.Enabled = true;
                forfeitureGroupCreationUC.btnFGCSave.Text = s_FGCSaveText;
                forfeitureGroupCreationUC.btnFGCSave.ToolTip = s_FGCSaveToolTip;
               
                ac_ForfeitureSetup.dt_ForfeitureDocuments = new DataTable();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Cancel button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        public void btnFGCCancel_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC)
        {
            try
            {
                forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value = forfeitureGroupCreationUC.txtFGCGroupName.Text = forfeitureGroupCreationUC.txtFGCForfeitureRate.Text = forfeitureGroupCreationUC.txtFGCApplFromDate.Text = string.Empty;
                forfeitureGroupCreationUC.hdnFGCForFromDateToEdit.Value = forfeitureGroupCreationUC.hdnFGCForfrToDateToEdit.Value = forfeitureGroupCreationUC.txtFCGComments.Text = string.Empty;
                forfeitureGroupCreationUC.hdnFGCAccordionIndex.Value = "0";
                forfeitureGroupCreationUC.h3FGCAddEdit.Style.Add("display", "none");
                forfeitureGroupCreationUC.h3FGCHistory.Style.Add("display", "none");
                forfeitureGroupCreationUC.txtFGCApplFromDateEdit.Text = "01/Jan/1990";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Delete Directory form server
        /// </summary>
        /// <param name="s_Path">directory path to delete</param>
        private void DeleteDirectory(string s_Path)
        {
            try
            {
                if (Directory.Exists(s_Path))
                {
                    DirectoryInfo downloadedMessageInfo = new DirectoryInfo(s_Path);
                    foreach (FileInfo file in downloadedMessageInfo.GetFiles())
                    {
                        file.Delete();
                    }
                    foreach (DirectoryInfo dir in downloadedMessageInfo.GetDirectories())
                    {
                        dir.Delete(true);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Delete File button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        internal int btnFGCDeleteFile_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_ForfeitureSetup.dt_ForfeitureDocuments.Rows.Count > 0)
                    {
                        string s_FileToDelete = forfeitureGroupCreationUC.hdnFGCFileNameToDelete.Value.Trim();
                        foreach (DataRow o_row in ac_ForfeitureSetup.dt_ForfeitureDocuments.Rows)
                        {
                            if (Convert.ToString(o_row[1]).Equals(s_FileToDelete))
                            {
                                o_row.Delete();
                                ac_ForfeitureSetup.dt_ForfeitureDocuments.AcceptChanges();
                                return 3;
                            }
                        }
                    }
                    return 0;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid View forfeiture group row data bound event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="e">event args</param>
        /// <param name="n_Index">index</param>
        /// <param name="n_FGID">n_FGID</param>
        /// <param name="n_FGAID">n_FGAID</param>
        /// <param name="n_Group_Name">n_Group_Name</param>
        /// <param name="n_Forfeiture_Rate">n_Forfeiture_Rate</param>
        /// <param name="n_No_of_Employees">n_No_of_Employees</param>
        /// <param name="n_Applicable_From_Date">n_Applicable_From_Date</param>
        /// <param name="n_To_Date">n_To_Date</param>
        /// <param name="n_Approval_Status">n_Approval_Status</param>
        /// <param name="n_Action">n_Action</param>
        /// <param name="b_IsApprovalPage">b_IsApprovalPage</param>
        public void gvFGCForfeitureGroup_RowDataBound(ForfeitureGroupCreationUC forfeitureGroupCreationUC, GridViewRowEventArgs e, ref int n_Index, ref int n_FGID, ref int n_FGAID, ref int n_Group_Name, ref int n_Forfeiture_Rate, ref int n_No_of_Employees, ref int n_Applicable_From_Date, ref int n_To_Date, ref int n_Approval_Status, ref int n_Action, bool b_IsApprovalPage)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "FGID":
                                    n_FGID = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "FGAID":
                                    n_FGAID = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "GROUP NAME":
                                    n_Group_Name = n_Index;
                                    break;
                                case "FORFEITURE RATE (%)":
                                    n_Forfeiture_Rate = n_Index;
                                    break;
                                case "NO. OF EMPLOYEES":
                                    n_No_of_Employees = n_Index;
                                    break;
                                case "APPLICABLE FROM DATE":
                                    n_Applicable_From_Date = n_Index;
                                    break;
                                case "TO DATE":
                                    n_To_Date = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "APPROVAL STATUS":
                                    n_Approval_Status = n_Index;
                                    break;
                                case "ACTION":
                                    n_Action = n_Index;
                                    break;
                            }
                            n_Index++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_FGID].Visible = e.Row.Cells[n_FGAID].Visible = e.Row.Cells[n_To_Date].Visible = false;
                        e.Row.Cells[n_Applicable_From_Date].HorizontalAlign = e.Row.Cells[n_To_Date].HorizontalAlign = e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Forfeiture_Rate].HorizontalAlign = e.Row.Cells[n_No_of_Employees].HorizontalAlign = HorizontalAlign.Right;
                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Applicable_From_Date].Text.Trim()) && !e.Row.Cells[n_Applicable_From_Date].Text.Trim().Equals("&nbsp;"))
                            e.Row.Cells[n_Applicable_From_Date].Text = Convert.ToDateTime(e.Row.Cells[n_Applicable_From_Date].Text).ToString("dd/MMM/yyyy");
                        if (!string.IsNullOrEmpty(e.Row.Cells[n_To_Date].Text.Trim()) && !e.Row.Cells[n_To_Date].Text.Trim().Equals("&nbsp;"))
                            e.Row.Cells[n_To_Date].Text = Convert.ToDateTime(e.Row.Cells[n_To_Date].Text).ToString("dd/MMM/yyyy");
                        if (string.IsNullOrEmpty(e.Row.Cells[n_No_of_Employees].Text.Trim()) || e.Row.Cells[n_No_of_Employees].Text.Trim().Equals("&nbsp;"))
                            e.Row.Cells[n_No_of_Employees].Text = "0";
                        if (b_IsApprovalPage)
                        {
                            e.Row.Cells[n_Action].Controls.Add((Control)AddActionIcon("GROUP_VIEW", "", "", e.Row.Cells[n_FGAID].Text, e.Row.Cells[n_Applicable_From_Date].Text, string.Empty));
                        }
                        else
                        {
                            e.Row.Cells[n_Action].Controls.Add((Control)AddActionIcon("GROUP_EDIT", "", "", e.Row.Cells[n_FGAID].Text, e.Row.Cells[n_Applicable_From_Date].Text, Convert.ToString(CommonModel.CheckAgainstLockedAccountingReport(e.Row.Cells[n_Applicable_From_Date].Text, userSessionInfo) ? 1 : 0)));
                            e.Row.Cells[n_Action].Controls.Add((Control)AddActionIcon("GROUP_HISTORY", "", "", e.Row.Cells[n_FGAID].Text, e.Row.Cells[n_Applicable_From_Date].Text, string.Empty));
                            if (!e.Row.Cells[n_Group_Name].Text.Trim().ToUpper().Equals("DEFAULT"))
                                e.Row.Cells[n_Action].Controls.Add((Control)AddActionIcon("GROUP_DELETE", "", "", e.Row.Cells[n_FGAID].Text, e.Row.Cells[n_Applicable_From_Date].Text, Convert.ToString(CommonModel.CheckAgainstLockedAccountingReport(e.Row.Cells[n_Applicable_From_Date].Text, userSessionInfo) ? 1 : 0)));
                            e.Row.Cells[n_No_of_Employees].Controls.Add((Control)AddHyperLink("View employees", e.Row.Cells[n_FGAID].Text.Trim(), e.Row.Cells[n_No_of_Employees].Text, e.Row.Cells[n_Group_Name].Text));
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// method to add hyperlink to the Grid-view row
        /// </summary>
        /// <param name="s_ToolTip">s_ToolTip</param>
        /// <param name="s_FGAID">s_AFGAID</param>
        /// <param name="s_NoOfEmp">s_NoOfEmp</param>
        /// <param name="s_GroupName">s_GroupName</param>
        /// <returns>returns hyperlink control</returns>
        private HyperLink AddHyperLink(string s_ToolTip, string s_FGAID, string s_NoOfEmp, string s_GroupName)
        {
            try
            {
                using (HyperLink o_HyperLink = new HyperLink())
                {
                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        o_HyperLink.ToolTip = s_ToolTip;
                        o_HyperLink.Attributes.Add("style", "color: blue; text-decoration: underline; cursor: pointer;");
                        o_HyperLink.TabIndex = 7;
                        o_HyperLink.Text = s_NoOfEmp;
                        o_HyperLink.Attributes.Add("onclick", "return OpenForfeitureEmpListPopup('" + Convert.ToString(genericServiceClient.EncryptString("RptID=7").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("FGAID=" + s_FGAID).Replace("+", "%2B")) + "&" + genericServiceClient.EncryptString("FORFEITUREGROUP=" + s_GroupName).Replace("+", "%2B") + "')");
                        return o_HyperLink;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Forfeiture Group page index change event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="e">event args</param>
        internal void gvFGCForfeitureGroup_PageIndexChanging(ForfeitureGroupCreationUC forfeitureGroupCreationUC, GridViewPageEventArgs e)
        {
            try
            {
                forfeitureGroupCreationUC.gvFGCForfeitureGroup.PageIndex = e.NewPageIndex;
                forfeitureGroupCreationUC.gvFGCForfeitureGroup.DataSource = ac_ForfeitureSetup.dt_ForfeitureSetupDetails;
                forfeitureGroupCreationUC.gvFGCForfeitureGroup.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// uploaded forfeiture files grid-view page index change event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="e">event args</param>
        internal void gvFGCUploadedFiles_PageIndexChanging(ForfeitureGroupCreationUC forfeitureGroupCreationUC, GridViewPageEventArgs e)
        {
            try
            {
                forfeitureGroupCreationUC.gvFGCUploadedFiles.PageIndex = e.NewPageIndex;
                forfeitureGroupCreationUC.gvFGCUploadedFiles.DataSource = ac_ForfeitureSetup.dt_ForfeitureDocuments;
                forfeitureGroupCreationUC.gvFGCUploadedFiles.DataBind();

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Associated Employees grid-view page index change event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="e">event args</param>
        internal void gvFGCAssociatedEmployees_PageIndexChanging(ForfeitureGroupCreationUC forfeitureGroupCreationUC, GridViewPageEventArgs e)
        {
            try
            {
                forfeitureGroupCreationUC.gvFGCAssociatedEmployees.PageIndex = e.NewPageIndex;
                forfeitureGroupCreationUC.gvFGCAssociatedEmployees.DataSource = (ac_ForfeitureSetup.s_Type.Equals("PopupClose")) ? ac_ForfeitureSetup.dt_SelectedEmployeesList : ac_ForfeitureSetup.dt_AssociatedEmployeesList;
                //forfeitureGroupCreationUC.gvFGCAssociatedEmployees.DataSource = (ac_ForfeitureSetup.s_Type.Equals("PopupClose")) ? ac_ForfeitureSetup.dt_SelectedEmployeesList : !string.IsNullOrEmpty(ac_ForfeitureSetup.s_hdnFGCForfrGrpIDToEdit) ? ac_ForfeitureSetup.dt_SelectedFGEmployeesList : ac_ForfeitureSetup.dt_AssociatedEmployeesList;

                forfeitureGroupCreationUC.gvFGCAssociatedEmployees.DataBind();

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Associated Employees grid-view page index change event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="e">event args</param>
        internal void gvFGCHistory_PageIndexChanging(ForfeitureGroupCreationUC forfeitureGroupCreationUC, GridViewPageEventArgs e)
        {
            try
            {
                forfeitureGroupCreationUC.gvFGCHistory.PageIndex = e.NewPageIndex;
                forfeitureGroupCreationUC.gvFGCHistory.DataSource = ac_ForfeitureSetup.dt_ForfeitureHistoryData;
                forfeitureGroupCreationUC.gvFGCHistory.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// File upload button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="s_FolderPath">s_FolderPath</param>
        /// <returns></returns>
        internal int btnFGCFileUpload_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC, string s_FolderPath)
        {
            try
            {
                if (forfeitureGroupCreationUC.fileFGCUploadDoc.HasFile)
                {
                    if (forfeitureGroupCreationUC.fileFGCUploadDoc.FileName.EndsWith(".xlsx") || forfeitureGroupCreationUC.fileFGCUploadDoc.FileName.EndsWith(".xls") || forfeitureGroupCreationUC.fileFGCUploadDoc.FileName.EndsWith(".doc") || forfeitureGroupCreationUC.fileFGCUploadDoc.FileName.EndsWith(".docx") || forfeitureGroupCreationUC.fileFGCUploadDoc.FileName.EndsWith(".pdf"))
                    {
                        if (forfeitureGroupCreationUC.fileFGCUploadDoc.FileContent.Length <= 10485760)
                        {
                            if (ac_ForfeitureSetup.dt_ForfeitureDocuments.Columns.Count <= 0)
                            {
                                ac_ForfeitureSetup.dt_ForfeitureDocuments.Columns.Add("FGAID", typeof(int));
                                ac_ForfeitureSetup.dt_ForfeitureDocuments.Columns.Add("File Name", typeof(string));
                                ac_ForfeitureSetup.dt_ForfeitureDocuments.Columns.Add("File Path", typeof(string));
                                ac_ForfeitureSetup.dt_ForfeitureDocuments.Columns.Add("Download", typeof(string));
                                ac_ForfeitureSetup.dt_ForfeitureDocuments.Columns.Add("Delete", typeof(string));
                            }
                            string s_ReturnStr = SaveFileToServer(forfeitureGroupCreationUC, s_FolderPath + userSessionInfo.ACC_UserName + "\\", string.Empty, true);
                            if (!string.IsNullOrEmpty(s_ReturnStr))
                            {
                                string[] files = s_ReturnStr.Split('~');
                                DataRow dr1 = ac_ForfeitureSetup.dt_ForfeitureDocuments.NewRow();
                                dr1[0] = 0;
                                dr1[1] = files[1];
                                dr1[2] = files[0];
                                ac_ForfeitureSetup.dt_ForfeitureDocuments.Rows.Add(dr1);
                            }
                            if (string.IsNullOrEmpty(s_ReturnStr))
                                return 2;
                            else
                                return 1;
                        }
                        else return 5; //allowed file size - max 10MB
                    }
                    else return 4; //allowed file types - excel/word/pdf
                }
                else return 2;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Uploaded files grid-view row data bound event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="e">event args</param>
        /// <param name="n_DocIndex">n_DocIndex</param>
        /// <param name="n_Doc_FGAID">n_Doc_FGAID</param>
        /// <param name="n_Doc_File_Name">n_Doc_File_Name</param>
        /// <param name="n_Doc_File_Path">n_Doc_File_Path</param>
        /// <param name="n_Doc_Download">n_Doc_Download</param>
        /// <param name="n_Doc_Delete">n_Doc_Delete</param>
        /// <param name="b_IsApprovalPage">b_IsApprovalPage</param>
        internal void gvFGCUploadedFiles_RowDataBound(ForfeitureGroupCreationUC forfeitureGroupCreationUC, GridViewRowEventArgs e, ref int n_DocIndex, ref int n_Doc_FGAID, ref int n_Doc_File_Name, ref int n_Doc_File_Path, ref int n_Doc_Download, ref int n_Doc_Delete, bool b_IsApprovalPage)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "FGAID":
                                    perColumn.Visible = false;
                                    n_Doc_FGAID = n_DocIndex;
                                    break;
                                case "FILE NAME":
                                    n_Doc_File_Name = n_DocIndex;
                                    break;
                                case "FILE PATH":
                                    perColumn.Visible = false;
                                    n_Doc_File_Path = n_DocIndex;
                                    break;
                                case "DOWNLOAD":
                                    n_Doc_Download = n_DocIndex;
                                    break;
                                case "DELETE":
                                    if (b_IsApprovalPage)
                                        perColumn.Visible = false;
                                    n_Doc_Delete = n_DocIndex;
                                    break;
                            }
                            n_DocIndex++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        if (b_IsApprovalPage)
                            e.Row.Cells[n_Doc_Delete].Visible = false;
                        e.Row.Cells[n_Doc_FGAID].Visible = e.Row.Cells[n_Doc_File_Path].Visible = false;
                        e.Row.Cells[n_Doc_Delete].HorizontalAlign = e.Row.Cells[n_Doc_Download].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Doc_Download].Controls.Add((Control)AddActionIcon("DOC_DOWNLOAD", e.Row.Cells[n_Doc_File_Path].Text.Trim(), e.Row.Cells[n_Doc_File_Name].Text.Trim(), "", "", ""));
                        if (!b_IsApprovalPage)
                            e.Row.Cells[n_Doc_Delete].Controls.Add((Control)AddActionIcon("DOC_DELETE", e.Row.Cells[n_Doc_File_Path].Text.Trim(), e.Row.Cells[n_Doc_File_Name].Text.Trim(), e.Row.Cells[n_Doc_FGAID].Text.Trim(), "", ""));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Forfeiture group history grid-view row data bound event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="e">event args</param>
        /// <param name="n_His_Index">n_His_Index</param>
        /// <param name="n_His_FGAID">n_His_FGAID</param>
        /// <param name="n_His_Rate">n_His_Rate</param>
        /// <param name="n_His_Grp_Name">n_His_Grp_Name</param>
        /// <param name="n_His_From_Date">n_His_From_Date</param>
        /// <param name="n_His_To_Date">n_His_To_Date</param>
        /// <param name="n_His_Is_Approved">n_His_Is_Approved</param>
        /// <param name="n_His_Actions">n_His_Actions</param>
        internal void gvFGCHistory_RowDataBound(ForfeitureGroupCreationUC forfeitureGroupCreationUC, GridViewRowEventArgs e, ref int n_His_Index, ref int n_His_FGAID, ref int n_His_Rate, ref int n_His_Grp_Name, ref int n_His_From_Date, ref int n_His_To_Date, ref int n_His_Is_Approved, ref int n_His_Actions)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "FGAID":
                                    perColumn.Visible = false;
                                    n_His_FGAID = n_His_Index;
                                    break;
                                case "GROUP NAME":
                                    perColumn.Visible = false;
                                    n_His_Grp_Name = n_His_Index;
                                    break;
                                case "APPLICABLE FROM DATE":
                                    n_His_From_Date = n_His_Index;
                                    break;
                                case "TO DATE":
                                    n_His_To_Date = n_His_Index;
                                    break;
                                case "FORFEITURE RATE (%)":
                                    n_His_Rate = n_His_Index;
                                    break;
                                case "APPROVAL STATUS":
                                    n_His_Is_Approved = n_His_Index;
                                    break;
                                case "ACTIONS":
                                    n_His_Actions = n_His_Index;
                                    break;
                            }
                            n_His_Index++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_His_FGAID].Visible = e.Row.Cells[n_His_Grp_Name].Visible = false;
                        e.Row.Cells[n_His_Actions].HorizontalAlign = e.Row.Cells[n_His_From_Date].HorizontalAlign = e.Row.Cells[n_His_To_Date].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_His_Rate].HorizontalAlign = HorizontalAlign.Right;
                        if (!string.IsNullOrEmpty(e.Row.Cells[n_His_From_Date].Text.Trim()) && !e.Row.Cells[n_His_From_Date].Text.Trim().Equals("&nbsp;"))
                            e.Row.Cells[n_His_From_Date].Text = Convert.ToDateTime(e.Row.Cells[n_His_From_Date].Text).ToString("dd/MMM/yyyy");
                        if (!string.IsNullOrEmpty(e.Row.Cells[n_His_To_Date].Text.Trim()) && !e.Row.Cells[n_His_To_Date].Text.Trim().Equals("&nbsp;"))
                            e.Row.Cells[n_His_To_Date].Text = Convert.ToDateTime(e.Row.Cells[n_His_To_Date].Text).ToString("dd/MMM/yyyy");
                        e.Row.Cells[n_His_Actions].Controls.Add((Control)AddActionIcon("VIEW_DOCUMENTS", "", "", e.Row.Cells[n_His_FGAID].Text.Trim(), e.Row.Cells[n_His_From_Date].Text.Trim(), ""));
                        e.Row.Cells[n_His_Actions].Controls.Add((Control)AddActionIcon("VIEW_COMMENTS", "", "", e.Row.Cells[n_His_FGAID].Text.Trim(), e.Row.Cells[n_His_From_Date].Text.Trim(), ""));
                        e.Row.Cells[n_His_Actions].Controls.Add((Control)AddActionIcon("VIEW_HISTORY", "", "", e.Row.Cells[n_His_FGAID].Text.Trim(), e.Row.Cells[n_His_From_Date].Text.Trim(), ""));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add ImageButton to the grid row item
        /// </summary>
        /// <param name="s_Type">s_Type</param>
        /// <param name="s_ServerPath">s_ServerPath</param>
        /// <param name="s_FileName">s_FileName</param>
        /// <param name="s_FGAID">s_FGAID</param>
        /// <param name="s_FromDate">s_FromDate</param>
        /// <param name="s_IsLocked">s_IsLocked</param>
        /// <returns>returns ImageButton control object</returns>
        private ImageButton AddActionIcon(string s_Type, string s_ServerPath, string s_FileName, string s_FGAID, string s_FromDate, string s_IsLocked)
        {
            try
            {
                using (ImageButton o_ImageButton = new ImageButton())
                {
                    o_ImageButton.Attributes.Add("style", "cursor:pointer;padding-left:5px;");
                    switch (s_Type.ToUpper())
                    {
                        case "GROUP_VIEW":
                            o_ImageButton.ImageUrl = "~/View/App_Themes/images/View.png";
                            o_ImageButton.ToolTip = "Click here to view details";
                            o_ImageButton.Attributes.Add("onclick", "return ShowForfeitureEditSection('" + s_FGAID + "','" + s_FromDate + "')");
                            break;
                        case "GROUP_EDIT":
                            o_ImageButton.ImageUrl = "~/View/App_Themes/images/Edit.png";
                            o_ImageButton.ToolTip = "Click here to edit";
                            o_ImageButton.Attributes.Add("onclick", "return ShowForfeitureEditSection('" + s_FGAID + "','" + s_FromDate + "','" + s_IsLocked + "')");
                            o_ImageButton.Enabled = ac_ForfeitureSetup.b_IsEditRights;
                            break;
                        case "GROUP_DELETE":
                            o_ImageButton.ImageUrl = "~/View/App_Themes/images/Delete.png";
                            o_ImageButton.ToolTip = "Click here to delete";
                            o_ImageButton.Attributes.Add("onclick", "return DeleteForfeitureGrp('" + s_FGAID + "','" + s_FromDate + "','" + s_IsLocked + "')");
                            o_ImageButton.Enabled = ac_ForfeitureSetup.b_IsDeleteRights;
                            break;
                        case "GROUP_HISTORY":
                            o_ImageButton.ImageUrl = "~/View/App_Themes/images/history.png";
                            o_ImageButton.ToolTip = "Click here to view history";
                            o_ImageButton.Attributes.Add("onclick", "return ViewForfeitureGrpHistory('" + s_FGAID + "')");
                            break;
                        case "DOC_DOWNLOAD":
                            o_ImageButton.ImageUrl = "~/View/App_Themes/images/download.png";
                            o_ImageButton.ToolTip = "Click here to download";
                            o_ImageButton.Attributes.Add("onclick", "return ForfeitureFileDownload('" + s_ServerPath.Replace("\\", "~") + "','" + s_FileName + "')");
                            break;
                        case "DOC_DELETE":
                            o_ImageButton.ImageUrl = "~/View/App_Themes/images/Delete.png";
                            o_ImageButton.ToolTip = "Click here to delete";
                            o_ImageButton.Attributes.Add("onclick", "return DeleteForfeitureDocuments('" + s_FileName + "')");
                            o_ImageButton.Enabled = ac_ForfeitureSetup.b_IsDeleteRights;
                            break;
                        case "VIEW_DOCUMENTS":
                            o_ImageButton.ImageUrl = "~/View/App_Themes/images/View_Documents.png";
                            o_ImageButton.ToolTip = "Click here to view documents";
                            o_ImageButton.Attributes.Add("onclick", "return ViewFGHistoryData('" + s_FGAID + "','" + s_FromDate + "', 'DOCUMENTS' )");
                            break;
                        case "VIEW_COMMENTS":
                            o_ImageButton.ImageUrl = "~/View/App_Themes/images/View_Comments.png";
                            o_ImageButton.ToolTip = "Click here to view comments";
                            o_ImageButton.Attributes.Add("onclick", "return ViewFGHistoryData('" + s_FGAID + "','" + s_FromDate + "', 'COMMENTS' )");
                            break;
                        case "VIEW_HISTORY":
                            o_ImageButton.ImageUrl = "~/View/App_Themes/images/history.png";
                            o_ImageButton.ToolTip = "Click here to view history";
                            o_ImageButton.Attributes.Add("onclick", "return ViewFGHistoryData('" + s_FGAID + "','" + s_FromDate + "', 'HISTORY' )");
                            break;
                    }
                    return o_ImageButton;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to store/save file to the server
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="s_FolderPath_Temp">s_FolderPath_Temp</param>
        /// <param name="s_FolderPath">s_FolderPath</param>
        /// <param name="b_IsTemp">b_IsTemp</param>
        /// <returns>returns server path</returns>
        private string SaveFileToServer(ForfeitureGroupCreationUC forfeitureGroupCreationUC, string s_FolderPath_Temp, string s_FolderPath, bool b_IsTemp)
        {
            try
            {
                return UploadFile(forfeitureGroupCreationUC.fileFGCUploadDoc, s_FolderPath_Temp, s_FolderPath, b_IsTemp);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to upload file to the server's temp folder
        /// </summary>
        /// <param name="asyncFileUpload">AsyncFileUpload object</param>
        /// <param name="s_FolderPath_Temp">s_FolderPath_Temp</param>
        /// <param name="s_FolderPath">s_FolderPath</param>
        /// <param name="b_IsTemp">b_IsTemp</param>
        /// <returns>returns string object of file name</returns>
        private string UploadFile(AjaxControlToolkit.AsyncFileUpload asyncFileUpload, string s_FolderPath_Temp, string s_FolderPath, bool b_IsTemp)
        {
            try
            {
                if ((!asyncFileUpload.HasFile && !string.IsNullOrEmpty(asyncFileUpload.FileName)) && b_IsTemp)
                    return string.Empty;
                string s_FilePath = string.Empty, s_FileName = string.Empty;
                s_FileName = b_IsTemp ? Path.GetFileName(asyncFileUpload.FileName) : Path.GetFileName(s_FolderPath_Temp);
                s_FolderPath = b_IsTemp ? s_FolderPath_Temp : s_FolderPath;
                if (!Directory.Exists(s_FolderPath))
                {
                    Directory.CreateDirectory(s_FolderPath);
                    s_FilePath = s_FolderPath + s_FileName;
                }
                else if (!File.Exists(s_FolderPath + s_FileName))
                {
                    s_FilePath = s_FolderPath + s_FileName;
                }
                else if (File.Exists(s_FolderPath + s_FileName))
                {
                    for (int i = 1; i < 100; i++)
                    {
                        if (!File.Exists(s_FolderPath + i + "\\" + s_FileName))
                        {
                            if (!Directory.Exists(s_FilePath = s_FolderPath + i + "\\"))
                                Directory.CreateDirectory(s_FilePath = s_FolderPath + i + "\\");
                            s_FilePath = s_FolderPath + i + "\\" + s_FileName;
                            goto loopEnd;
                        }
                    }
                }
            loopEnd:
                if (!string.IsNullOrEmpty(s_FilePath))
                {
                    if (b_IsTemp)
                        asyncFileUpload.SaveAs(s_FilePath);
                    else
                    {
                        if (File.Exists(s_FolderPath_Temp))
                            File.Copy(s_FolderPath_Temp, s_FilePath, false);
                    }
                }
                asyncFileUpload.ClearAllFilesFromPersistedStore();
                return !string.IsNullOrEmpty(s_FileName) ? s_FilePath + "~" + s_FileName : string.Empty;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to download file from server folder
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        internal void DownloadFile(ForfeitureGroupCreationUC forfeitureGroupCreationUC)
        {
            try
            {
                using (WebClient o_WebClient = new WebClient())
                {
                    HttpResponse o_HttpResponse = HttpContext.Current.Response;
                    o_HttpResponse.Clear();
                    o_HttpResponse.ClearContent();
                    o_HttpResponse.ClearHeaders();
                    o_HttpResponse.Buffer = true;
                    forfeitureGroupCreationUC.Response.AddHeader("Content-Disposition", "attachment;filename=" + forfeitureGroupCreationUC.hdnFGCFileName.Value);
                    o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(forfeitureGroupCreationUC.hdnFGCFileServerPath.Value.Replace("~", "\\")));
                    // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.Flush();
                    // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.Response.SuppressContent = true;
                    // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.  
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Forfeiture group Associated Employees row data bound event
        /// </summary>
        /// <param name="e">event args</param>
        /// <param name="n_Ass_EmpIndex">n_Ass_EmpIndex</param>
        /// <param name="n_Ass_EmpSelect">n_Ass_EmpSelect</param>
        /// <param name="n_Ass_EMPID">n_Ass_EMPID</param>
        /// <param name="n_Ass_Employee_ID">n_Ass_Employee_ID</param>
        /// <param name="n_Ass_Employee_Name">n_Ass_Employee_Name</param>
        /// <param name="n_Ass_Emp_Group_Name">n_Ass_Emp_Group_Name</param>
        /// <param name="n_Ass_Emp_Deartment">n_Ass_Emp_Deartment</param>
        /// <param name="n_Ass_Emp_Grade">n_Ass_Emp_Grade</param>
        /// <param name="n_Ass_Emp_Designation">n_Ass_Emp_Designation</param>
        /// <param name="n_Ass_IS_APPROVAL_PENDING">n_Ass_IS_APPROVAL_PENDING</param>
        internal void gvFGCAssociatedEmployees_RowDataBound(GridViewRowEventArgs e, ref int n_Ass_EmpIndex, ref int n_Ass_EmpSelect, ref int n_Ass_EMPID, ref int n_Ass_Employee_ID, ref int n_Ass_Employee_Name, ref int n_Ass_Emp_Group_Name, ref int n_Ass_Emp_Deartment, ref int n_Ass_Emp_Grade, ref int n_Ass_Emp_Designation, ref int n_Ass_IS_APPROVAL_PENDING)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SELECT":
                                    perColumn.Visible = false;
                                    n_Ass_EmpSelect = n_Ass_EmpIndex;
                                    break;
                                case "EMPID":
                                    perColumn.Visible = false;
                                    n_Ass_EMPID = n_Ass_EmpIndex;
                                    break;
                                case "EMPLOYEE ID":
                                    n_Ass_Employee_ID = n_Ass_EmpIndex;
                                    break;
                                case "EMPLOYEE NAME":
                                    n_Ass_Employee_Name = n_Ass_EmpIndex;
                                    break;
                                case "GROUP NAME":
                                    perColumn.Visible = false;
                                    n_Ass_Emp_Group_Name = n_Ass_EmpIndex;
                                    break;
                                case "DEPARTMENT":
                                    perColumn.Visible = false;
                                    n_Ass_Emp_Deartment = n_Ass_EmpIndex;
                                    break;
                                case "GRADE":
                                    perColumn.Visible = false;
                                    n_Ass_Emp_Grade = n_Ass_EmpIndex;
                                    break;
                                case "DESIGNATION":
                                    perColumn.Visible = false;
                                    n_Ass_Emp_Designation = n_Ass_EmpIndex;
                                    break;
                                case "IS_APPROVAL_PENDING":
                                    perColumn.Visible = false;
                                    n_Ass_IS_APPROVAL_PENDING = n_Ass_EmpIndex;
                                    break;
                            }
                            n_Ass_EmpIndex++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_Ass_EmpSelect].Visible = e.Row.Cells[n_Ass_IS_APPROVAL_PENDING].Visible = e.Row.Cells[n_Ass_EMPID].Visible = e.Row.Cells[n_Ass_Emp_Group_Name].Visible = e.Row.Cells[n_Ass_Emp_Deartment].Visible = e.Row.Cells[n_Ass_Emp_Grade].Visible = e.Row.Cells[n_Ass_Emp_Designation].Visible = false;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Clear file content button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        internal void btnFGCClearFileContent_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC)
        {
            try
            {
                forfeitureGroupCreationUC.fileFGCUploadDoc.ClearAllFilesFromPersistedStore();
                forfeitureGroupCreationUC.hdnFGCAccordionIndex.Value = "1";
                forfeitureGroupCreationUC.h3FGCAddEdit.Style.Add("display", "");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind history data to grid
        /// </summary>
        /// <param name="o_FGAID">o_FGAID</param>
        /// <param name="o_FromDate">o_FromDate</param>
        /// <param name="o_Type">o_Type</param>
        /// <returns></returns>
        public AccountingProperties[] BindFGSHistoryGrid(object o_FGAID, object o_FromDate, object o_Type)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    List<AccountingProperties> o_Details = new List<AccountingProperties>();
                    accountingProperties = new AccountingProperties();
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "FGC_HISTORY_DATA";
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.FGAID = Convert.ToInt32(o_FGAID);
                    accountingProperties.HISTORY_TYPE = Convert.ToString(o_Type);
                    if (!string.IsNullOrEmpty(Convert.ToString(o_FromDate)))
                        accountingProperties.APPLICABLE_FROM_DATE = Convert.ToString(o_FromDate);
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    foreach (DataRow dtrow in accountingCRUDProperties.dt_Result.Rows)
                    {
                        accountingProperties = new AccountingProperties();
                        switch (Convert.ToString(o_Type))
                        {
                            case "HISTORY":
                                accountingProperties.FORFEITURE_GROUP_NAME = Convert.ToString(dtrow["FORFEITURE_GROUP_NAME"]);
                                if (!string.IsNullOrEmpty(Convert.ToString(dtrow["APPLICABLE_FROM_DATE"])))
                                    accountingProperties.APPLICABLE_FROM_DATE = Convert.ToDateTime(Convert.ToString(dtrow["APPLICABLE_FROM_DATE"])).ToString("dd/MMM/yyyy");
                                if (!string.IsNullOrEmpty(Convert.ToString(dtrow["APPLICABLE_TO_DATE"])))
                                    accountingProperties.APPLICABLE_TO_DATE = Convert.ToDateTime(Convert.ToString(dtrow["APPLICABLE_TO_DATE"])).ToString("dd/MMM/yyyy");
                                else accountingProperties.APPLICABLE_TO_DATE = string.Empty;
                                accountingProperties.FORFEITURE_RATE = Convert.ToDecimal(dtrow["FORFEITURE_RATE"]);
                                accountingProperties.APPROVAL_STATUS = Convert.ToString(dtrow["Approval Status"]);
                                break;

                            case "DOCUMENTS":
                                accountingProperties.FILE_PATH = Convert.ToString(dtrow["FILE_PATH"]).Replace("\\", "~");
                                accountingProperties.FILE_NAME = Convert.ToString(dtrow["FILE_NAME"]);
                                break;

                            case "COMMENTS":
                                accountingProperties.COMMENTS = Convert.ToString(dtrow["COMMENTS"]);
                                accountingProperties.ADDED_BY = Convert.ToString(dtrow["Added By"]);
                                accountingProperties.USER_TYPE = Convert.ToString(dtrow["User Type"]);
                                break;
                        }
                        o_Details.Add(accountingProperties);
                    }
                    return o_Details.ToArray();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Forfeiture Group approve button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <param name="b_IsApproved">b_IsApproved</param>
        /// <returns>returns integer value ( 0 - Error , 1 - Approved Successfully )</returns>
        internal int btnFGCApprove_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC, bool b_IsApproved)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_ForfeitureSetup;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.PopulateControls = CommonConstantModel.s_FGCUpdateStatus;
                    accountingProperties.IS_APPROVED = b_IsApproved;
                    if (!string.IsNullOrEmpty(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value))
                        accountingProperties.FGAID = Convert.ToInt32(forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value);
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    forfeitureGroupCreationUC.hdnFGCForfrGrpIDToEdit.Value = forfeitureGroupCreationUC.hdnFGCForFromDateToEdit.Value = forfeitureGroupCreationUC.hdnFGCForfrToDateToEdit.Value = string.Empty;
                    return accountingCRUDProperties.a_result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Forfeiture Group disapprove button click event
        /// </summary>
        /// <param name="forfeitureGroupCreationUC">ForfeitureGroupCreationUC page object</param>
        /// <returns>returns integer value ( 0 - Error , 1 - Disapproved )</returns>
        internal int btnFGCDisapprove_Click(ForfeitureGroupCreationUC forfeitureGroupCreationUC)
        {
            try
            {
                return btnFGCApprove_Click(forfeitureGroupCreationUC, false);
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Destructor
        /// <summary>
        /// Default Destructor
        /// </summary>
        ~ForfeitureGroupCreationModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}