﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Employee master Model Class.
    /// </summary>
    public class EmployeeMasterModel : BaseModel, IDisposable
    {
        /// <summary>
        /// This variable is used to set the Enable property of imagebuttons like "edit image button"
        /// </summary>
        internal static bool b_IsEnabled = false;

        /// <summary>
        /// This Variable is Used to set a Employee Delete Message
        /// </summary>
        public static string EmploYeeDeleteMsg = string.Empty;

        /// <summary>
        /// This DataRow is used to store filtered rows of filtered DataTable 
        /// </summary>
        DataRow[] dr = null;

        /// <summary>
        /// Default constructor
        /// </summary>
        public EmployeeMasterModel()
        {
            if (ac_EmployeeMaster == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_EmployeeMaster);
                ac_EmployeeMaster = (CommonModel.AC_EmployeeMaster)HttpContext.Current.Session[CommonConstantModel.s_AC_EmployeeMaster];
            }
        }

        /// <summary>
        /// This method loads the initial settings and data required for the page.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        public void LoadInitialSettings(EmployeeMaster employeeMaster)
        {
            try
            {
                CheckEmployeeRolePriviledges(employeeMaster);

                BindUI(employeeMaster);
                LoadDefault_ViewDropDowns(employeeMaster);

                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.PageName = CommonConstantModel.s_MnuEmployeeMaster;
                    genericProperties.CustomizeView_ID = Convert.ToString(employeeMaster.ddlDefaultView.SelectedValue);
                    ac_EmployeeMaster.dt_CustmizedViewEmpMaster = (DataTable)genericServiceClient.GetCustomizedViewTable(genericProperties);
                }


                LoadEmployeeGrid(employeeMaster);

                LoadAllEditDropDowns(employeeMaster);

                LoadAllEMployeeHistoryList(employeeMaster);

                LoadAllSearchDropDowns(employeeMaster);

                Load_ddlEM_ModifiedField(employeeMaster);

                LoadCountry_ForfeitureDropDowns(employeeMaster);

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Enables or disables control according to roles assigned to user.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page</param>
        internal void CheckEmployeeRolePriviledges(EmployeeMaster employeeMaster)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuEmployeeMaster;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    break;

                                case "ADD":
                                    employeeMaster.btnEM_AddNew.Enabled = true;
                                    employeeMaster.btnEM_Submit.Enabled = true;
                                    break;

                                case "EDIT":
                                    b_IsEnabled = true;
                                    break;

                                case "DELETE":
                                    employeeMaster.btnEM_Delete.Enabled = true;
                                    break;

                                case "APPROVE":
                                    if (userSessionInfo.ACC_UerTypeID == 5)
                                    {
                                        employeeMaster.btnEM_Approve.Visible = true;
                                    }
                                    break;

                                case "DISAPPROVE":
                                    if (userSessionInfo.ACC_UerTypeID == 5)
                                    {
                                        employeeMaster.btnEM_DisApprove.Visible = true;
                                    }
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to bind UI text to the Employee master page.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        internal void BindUI(EmployeeMaster employeeMaster)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                try
                {
                    ac_EmployeeMaster.dt_EmployeeMasterUIText = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_EmployeeMaster, CommonConstantModel.s_AccountingL10_UI);
                    if ((ac_EmployeeMaster.dt_EmployeeMasterUIText != null) && (ac_EmployeeMaster.dt_EmployeeMasterUIText.Rows.Count > 0))
                    {
                        foreach (Control control in employeeMaster.dvMain.Controls)
                        {
                            var a = (control.GetType().FullName.ToUpper());
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, employeeMaster, ac_EmployeeMaster.dt_EmployeeMasterUIText, (Label)control, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, employeeMaster, ac_EmployeeMaster.dt_EmployeeMasterUIText, null, (TextBox)control, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, employeeMaster, ac_EmployeeMaster.dt_EmployeeMasterUIText, null, null, (Button)control, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, employeeMaster, ac_EmployeeMaster.dt_EmployeeMasterUIText, null, null, null, null, (RadioButton)control, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, employeeMaster, ac_EmployeeMaster.dt_EmployeeMasterUIText, null, null, null, null, null, (BaseValidator)control, null, null);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, employeeMaster, ac_EmployeeMaster.dt_EmployeeMasterUIText, null, null, null, null, null, null, (BaseValidator)control, null);
                                    break;

                                case CommonConstantModel.s_wcRangeValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, employeeMaster, ac_EmployeeMaster.dt_EmployeeMasterUIText, null, null, null, null, null, null, (BaseValidator)control, null);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, employeeMaster, ac_EmployeeMaster.dt_EmployeeMasterUIText, null, null, null, null, null, null, null, (GridView)control);
                                    break;
                            }

                        }
                        employeeMaster.lblMMAccordEditHead.Text = Convert.ToString((ac_EmployeeMaster.dt_EmployeeMasterUIText.Select("LabelID='lblMMAccordEditHead'"))[0]["LabelName"]);
                        EmploYeeDeleteMsg = accountingServiceClient.GetAccounting_L10N("lblEMDeleteMsg", CommonConstantModel.s_EmployeeMaster, CommonConstantModel.s_AccountingL10);
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="employeeMaster">The DownloadTemplate class object</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="label">The label control object</param>
        /// <param name="textBox">The text-box control object</param>
        /// <param name="button">The button control object</param>
        /// <param name="checkBox">The CheckBox control object</param>
        /// <param name="radioButton">radiobutton control object</param>
        /// <param name="ReqValidator">validator control object</param>
        /// <param name="RegExpValidator">validator control object</param>
        /// <param name="gridView">gridview control object</param>
        private void BindPropertiesToControl(string s_cntrlType, EmployeeMaster employeeMaster, DataTable Dt_Get_L10N_UI, Label label, TextBox textBox, Button button, CheckBox checkBox, RadioButton radioButton, BaseValidator ReqValidator, BaseValidator RegExpValidator, GridView gridView)
        {
            switch (s_cntrlType)
            {

                case CommonConstantModel.s_cntrlTypeLabel:
                    try
                    {

                        label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                        label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                        break;
                    }
                    catch (Exception)
                    {

                        throw;
                    }

                case CommonConstantModel.s_cntrlTypeButton:
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRadioButton:
                    radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                    radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    gridView.EmptyDataText = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + gridView.ID + "'"))[0]["LabelName"]);
                    break;
            }
        }

        /// <summary>
        /// This method is used to load the gridview and then bind it.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        internal void LoadEmployeeGrid(EmployeeMaster employeeMaster)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "GET_EMP_LIST";
                    accountingProperties.PageName = CommonConstantModel.s_EmployeeMaster;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PopulateControls = "EMPDETAILS";
                    int CustomizeView_ID = 0;
                    int.TryParse(employeeMaster.ddlDefaultView.SelectedValue, out CustomizeView_ID);
                    accountingProperties.s_Customize_ViewName_ID = CustomizeView_ID;

                    ac_EmployeeMaster.dt_EmployeeDataList = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;

                    ac_EmployeeMaster.dt_EmployeeDataList.DefaultView.Sort = "Employee Source";
                    employeeMaster.gv.PageSize = ac_EmployeeMaster.dt_CustmizedViewEmpMaster != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count > 0 ? Convert.ToInt32(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows[0]["NO_OF_ROWS"].ToString()) : employeeMaster.gv.PageSize;
                    employeeMaster.gv.DataSource = ac_EmployeeMaster.dt_EmployeeDataList;
                    employeeMaster.gv.DataBind();
                    employeeMaster.btnEM_Delete.Visible = employeeMaster.gv.Rows.Count > 0 ? true : false;
                    employeeMaster.btnEM_ClearSearch.Visible = false;

                    if (userSessionInfo.ACC_UerTypeID == 5)
                    {
                        employeeMaster.btnEM_Approve.Visible = employeeMaster.gv.Rows.Count > 0 ? true : false;
                        employeeMaster.btnEM_DisApprove.Visible = employeeMaster.gv.Rows.Count > 0 ? true : false;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to load all the tracking field master dropdowns.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        internal void LoadAllEditDropDowns(EmployeeMaster employeeMaster)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "LOAD_ALL_EDIT_DDLs";
                    accountingProperties.PageName = CommonConstantModel.s_EmployeeMaster;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PopulateControls = "EMPDETAILS";
                    using (DataTable dt_LoadMasterDataToDropDown = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result)
                    {
                        if (dt_LoadMasterDataToDropDown.Rows.Count > 0)
                        {
                            DataTable dt_fetch_DropDownData = new DataTable();
                            try
                            {
                                dt_fetch_DropDownData = dt_LoadMasterDataToDropDown.Select("FIELD_NAME = 'SBU'").CopyToDataTable();
                                employeeMaster.ddlEM_AddSBU.DataSource = dt_fetch_DropDownData;
                                employeeMaster.ddlEM_AddSBU.DataTextField = "PARAM_VALUE";
                                employeeMaster.ddlEM_AddSBU.DataValueField = "ATMDID";
                                employeeMaster.ddlEM_AddSBU.DataBind();
                            }
                            catch (Exception Ex)
                            {
                                if (Ex.Message.Contains("no DataRows"))
                                {
                                    // Do Nothing.
                                }
                                else
                                {
                                    throw;
                                }
                            }
                            try
                            {
                                dt_fetch_DropDownData = dt_LoadMasterDataToDropDown.Select("FIELD_NAME = 'COST_CENTRE'").CopyToDataTable();
                                employeeMaster.ddlEM_AddCostCentre.DataSource = dt_fetch_DropDownData;
                                employeeMaster.ddlEM_AddCostCentre.DataTextField = "PARAM_VALUE";
                                employeeMaster.ddlEM_AddCostCentre.DataValueField = "ATMDID";
                                employeeMaster.ddlEM_AddCostCentre.DataBind();
                            }
                            catch (Exception Ex)
                            {
                                if (Ex.Message.Contains("no DataRows"))
                                {
                                    // Do Nothing.
                                }
                                else
                                {
                                    throw;
                                }
                            }
                            try
                            {
                                dt_fetch_DropDownData = dt_LoadMasterDataToDropDown.Select("FIELD_NAME = 'DEPARTMENT'").CopyToDataTable();
                                employeeMaster.ddlEM_AddDepartment.DataSource = dt_fetch_DropDownData;
                                employeeMaster.ddlEM_AddDepartment.DataTextField = "PARAM_VALUE";
                                employeeMaster.ddlEM_AddDepartment.DataValueField = "ATMDID";
                                employeeMaster.ddlEM_AddDepartment.DataBind();
                            }
                            catch (Exception Ex)
                            {
                                if (Ex.Message.Contains("no DataRows"))
                                {
                                    // Do Nothing.
                                }
                                else
                                {
                                    throw;
                                }
                            }

                            try
                            {
                                dt_fetch_DropDownData = dt_LoadMasterDataToDropDown.Select("FIELD_NAME = 'LOCATION'").CopyToDataTable();
                                employeeMaster.ddlEM_AddLocation.DataSource = dt_fetch_DropDownData;
                                employeeMaster.ddlEM_AddLocation.DataTextField = "PARAM_VALUE";
                                employeeMaster.ddlEM_AddLocation.DataValueField = "ATMDID";
                                employeeMaster.ddlEM_AddLocation.DataBind();
                            }
                            catch (Exception Ex)
                            {
                                if (Ex.Message.Contains("no DataRows"))
                                {
                                    // Do Nothing.
                                }
                                else
                                {
                                    throw;
                                }
                            }

                            try
                            {
                                dt_fetch_DropDownData = dt_LoadMasterDataToDropDown.Select("FIELD_NAME = 'ENTITY'").CopyToDataTable();
                                employeeMaster.ddlEM_AddEntity.DataSource = dt_fetch_DropDownData;
                                employeeMaster.ddlEM_AddEntity.DataTextField = "PARAM_VALUE";
                                employeeMaster.ddlEM_AddEntity.DataValueField = "ATMDID";
                                employeeMaster.ddlEM_AddEntity.DataBind();
                            }
                            catch (Exception Ex)
                            {
                                if (Ex.Message.Contains("no DataRows"))
                                {
                                    // Do Nothing.
                                }
                                else
                                {
                                    throw;
                                }
                            }
                        }

                        employeeMaster.ddlEM_AddSBU.Items.Insert(0, "--- Please Select ---");
                        employeeMaster.ddlEM_AddCostCentre.Items.Insert(0, "--- Please Select ---");
                        employeeMaster.ddlEM_AddDepartment.Items.Insert(0, "--- Please Select ---");
                        employeeMaster.ddlEM_AddLocation.Items.Insert(0, "--- Please Select ---");
                        employeeMaster.ddlEM_AddEntity.Items.Insert(0, "--- Please Select ---");
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method loads the tracking details of All employees.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        internal void LoadAllEMployeeHistoryList(EmployeeMaster employeeMaster)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "GET_EMP_HISTORY";
                    accountingProperties.PageName = CommonConstantModel.s_EmployeeMaster;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PopulateControls = "EMPDETAILS";
                    ac_EmployeeMaster.dt_EmployeeHistoryData = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method loads all the Search section dropdowns.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        internal void LoadAllSearchDropDowns(EmployeeMaster employeeMaster)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "LOAD_ALL_SEARCH_DDLs";
                    accountingProperties.PageName = CommonConstantModel.s_EmployeeMaster;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PopulateControls = "EMPDETAILS";
                    using (DataTable dt_LoadMasterDataToDropDown = ac_EmployeeMaster.dt_EmployeeDataList.Copy())
                    {
                        employeeMaster.UcEM_EmpID.chkMultiselect.Items.Clear();
                        employeeMaster.UcEM_EmpName.chkMultiselect.Items.Clear();
                        employeeMaster.UcEM_Grade.chkMultiselect.Items.Clear();
                        employeeMaster.UcEM_Country.chkMultiselect.Items.Clear();
                        employeeMaster.UcEM_Designation.chkMultiselect.Items.Clear();
                        employeeMaster.UcEM_ApprovalStatus.chkMultiselect.Items.Clear();
                        employeeMaster.UcEM_Location.chkMultiselect.Items.Clear();
                        employeeMaster.UcEM_Department.chkMultiselect.Items.Clear();
                        employeeMaster.UcEM_Entity.chkMultiselect.Items.Clear();
                        employeeMaster.UcEM_SBU.chkMultiselect.Items.Clear();
                        employeeMaster.UcEM_CostCentre.chkMultiselect.Items.Clear();

                        //LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_EmpID.chkMultiselect, "Employee Id");
                        //LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_EmpName.chkMultiselect, "Employee Name");
                        LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_Grade.chkMultiselect, "Grade");

                        LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_Country.chkMultiselect, "Country");
                        LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_Designation.chkMultiselect, "Designation");
                        LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_ApprovalStatus.chkMultiselect, "Approval Status");

                        LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_Location.chkMultiselect, "Location");
                        LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_Department.chkMultiselect, "Department");
                        LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_Entity.chkMultiselect, "Entity");
                        LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_SBU.chkMultiselect, "SBU");
                        LoadRows(dt_LoadMasterDataToDropDown, employeeMaster.UcEM_CostCentre.chkMultiselect, "Cost Centre");
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method creates a datatable based on the filtered row and adds the row in the datatable.
        /// </summary>
        /// <param name="dt">datatable to be filtered</param>
        /// <param name="chkbxList">checkboxlist which is used as a reference to filter as a parameter</param>
        /// <param name="s_col_Name">column name on which filtered is to be performed</param>
        internal void LoadRows(DataTable dt, CheckBoxList chkbxList, string s_col_Name)
        {
            DataTable datatable_temp = new DataTable();
            DataView view = new DataView(dt);
            datatable_temp = view.ToTable(true, s_col_Name);

            try
            {
                datatable_temp = datatable_temp.Select().Where(x => !x.IsNull(0)).Count() > 0 ? datatable_temp.Select().Where(x => !x.IsNull(0)).CopyToDataTable() : new DataTable();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            chkbxList.DataSource = datatable_temp;
            chkbxList.DataTextField = s_col_Name;
            chkbxList.DataBind();
            view.Dispose();
            datatable_temp.Dispose();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        internal void Load_ddlEM_ModifiedField(EmployeeMaster employeeMaster)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "LOAD_TRACKING_FIELD_NAMES";
                    accountingProperties.PageName = CommonConstantModel.s_EmployeeMaster;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PopulateControls = "EMPDETAILS";
                    using (DataTable dt_LoadMasterDataToDropDown = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result)
                    {
                        employeeMaster.ddlEM_ModifiedField.DataSource = dt_LoadMasterDataToDropDown;
                        employeeMaster.ddlEM_ModifiedField.DataTextField = "FIELD_NAME";
                        employeeMaster.ddlEM_ModifiedField.DataValueField = "ATMID";
                        employeeMaster.ddlEM_ModifiedField.DataBind();
                        employeeMaster.ddlEM_ModifiedField.Items.Insert(0, "--- Please Select ---");
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to load the dropdown of country of country and forfeiture.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        internal void LoadCountry_ForfeitureDropDowns(EmployeeMaster employeeMaster)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Action = "LOAD_COUNTRY_AND_FORFEITURE";
                    accountingProperties.PageName = CommonConstantModel.s_EmployeeMaster;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PopulateControls = "EMPDETAILS";
                    using (DataTable dt_LoadMasterDataToDropDown = accountingServiceClient.CRUDAccountingOperations(accountingProperties).dt_Result)
                    {
                        DataTable dt_fetch_DropDownData = dt_LoadMasterDataToDropDown.Select("PARAM_NAME = 'COUNTRY'").CopyToDataTable();
                        employeeMaster.ddlEM_EditCountry.DataSource = dt_fetch_DropDownData;
                        employeeMaster.ddlEM_EditCountry.DataTextField = "VALUE";
                        employeeMaster.ddlEM_EditCountry.DataValueField = "ID";
                        employeeMaster.ddlEM_EditCountry.DataBind();
                        employeeMaster.ddlEM_EditCountry.Items.Insert(0, "--- Please Select ---");

                        dt_fetch_DropDownData = dt_LoadMasterDataToDropDown.Select("PARAM_NAME = 'FORFEITURE'").CopyToDataTable();
                        employeeMaster.ddlEM_EditAssignForfeitureGrp.DataSource = dt_fetch_DropDownData;
                        employeeMaster.ddlEM_EditAssignForfeitureGrp.DataTextField = "VALUE";
                        employeeMaster.ddlEM_EditAssignForfeitureGrp.DataValueField = "ID";
                        employeeMaster.ddlEM_EditAssignForfeitureGrp.DataBind();

                        employeeMaster.UcEM_AssignForfeitureGrp.chkMultiselect.DataSource = dt_fetch_DropDownData;
                        employeeMaster.UcEM_AssignForfeitureGrp.chkMultiselect.DataTextField = "VALUE";
                        employeeMaster.UcEM_AssignForfeitureGrp.chkMultiselect.DataBind();

                        dt_fetch_DropDownData = dt_LoadMasterDataToDropDown.Select("PARAM_NAME = 'EMPLOYEE_SOURCE'").CopyToDataTable();
                        employeeMaster.UcEM_EmployeeSource.chkMultiselect.DataSource = dt_fetch_DropDownData;
                        employeeMaster.UcEM_EmployeeSource.chkMultiselect.DataTextField = "VALUE";
                        employeeMaster.UcEM_EmployeeSource.chkMultiselect.DataBind();

                        dt_fetch_DropDownData = dt_LoadMasterDataToDropDown.Select("PARAM_NAME = 'IS_SENIOR_MANAGEMENT'").CopyToDataTable();
                        employeeMaster.ddlSeniorManagement.DataSource = dt_fetch_DropDownData;
                        employeeMaster.ddlSeniorManagement.DataTextField = "VALUE";
                        employeeMaster.ddlSeniorManagement.DataBind();
                    }
                }
            }
            catch
            {
                throw;
            }

        }



        /// <summary>
        /// This method is used to load the default view for login user.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        internal void LoadDefault_ViewDropDowns(EmployeeMaster employeeMaster)
        {
            try
            {
                using (DataTable dtDefaultView = CommonModel.GetDefaultViewList(userSessionInfo, CommonConstantModel.s_Get_Default_View, CommonConstantModel.s_EM_ViewPageName))
                {
                    employeeMaster.ddlDefaultView.DataSource = dtDefaultView;
                    employeeMaster.ddlDefaultView.DataTextField = "VIEW_NAME";
                    employeeMaster.ddlDefaultView.DataValueField = "ID";
                    employeeMaster.ddlDefaultView.DataBind();
                    employeeMaster.ddlDefaultView.Items.Insert(0, new ListItem("--- Please Select ---", "0"));

                    if (dtDefaultView.Rows.Count > 0)
                    {
                        if (employeeMaster.ddlDefaultView.Items.Count > 0)
                        {
                            DataRow[] drr = dtDefaultView.Select("ISDEFAULT_VIEW=1");

                            if (drr.Length > 0)
                            {
                                employeeMaster.ddlDefaultView.SelectedValue = Convert.ToString(drr[0]["ID"]);
                                employeeMaster.hdnDefaultViewValue.Value = Convert.ToString(drr[0]["ID"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to load the selected view for login user.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        internal void LoadSelcted_View(EmployeeMaster employeeMaster)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.PageName = CommonConstantModel.s_MnuEmployeeMaster;
                    genericProperties.CustomizeView_ID = Convert.ToString(employeeMaster.ddlDefaultView.SelectedValue);
                    genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_EmployeeMaster.dt_CustmizedViewEmpMaster = (DataTable)genericServiceClient.GetCustomizedViewTable(genericProperties);
                }

                LoadEmployeeGrid(employeeMaster);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to load the selected view for login user.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        internal void SetDefaultView(EmployeeMaster employeeMaster)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    accountingProperties.PageName = CommonConstantModel.s_EmployeeMaster;
                    accountingProperties.Operation = "SETDEFAULTVIEW";
                    accountingProperties.s_CustomizeViewPageName = CommonConstantModel.s_MnuEmployeeMaster;
                    accountingProperties.s_ViewID = Convert.ToString(employeeMaster.ddlDefaultView.SelectedValue);
                    accountingProperties.IsDefault = true;

                    AccountingCRUDProperties accountingCRUDProperties = new AccountingCRUDProperties();
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            employeeMaster.ctrSuccessErrorMessage.lblMessage.Text = accountingServiceClient.GetAccounting_L10N("lblEMError", CommonConstantModel.s_EmployeeMaster, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.lblMessage.ForeColor = Color.Red;
                            break;

                        case 1:
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            employeeMaster.ctrSuccessErrorMessage.lblMessage.Text = accountingServiceClient.GetAccounting_L10N("lblCustViewApplied", CommonConstantModel.s_EmployeeMaster, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.lblMessage.ForeColor = Color.Blue;
                            break;
                    }

                }

                LoadEmployeeGrid(employeeMaster);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to Encrypt query string that has to pass on to report page  for report view.
        /// </summary>
        /// <param name="employeeMaster">object of employeeMaster page</param>
        internal void EncryptData(EmployeeMaster employeeMaster)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                employeeMaster.hdnQueryStringParams.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=6").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                employeeMaster.hdnQueryStringParams.Dispose();
            }
        }

        /// <summary>
        /// This Method binds row in gridview / hides some of the columns.
        /// </summary>
        /// <param name="e">e</param>
        /// <param name="n_index"></param>
        /// <param name="hash_EmpMaster"></param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref Hashtable hash_EmpMaster)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "EMPID":
                                hash_EmpMaster["n_ID"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "DELETE":
                                hash_EmpMaster["n_Delete"] = n_index;
                                e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Delete"].ToString())].Controls.Add(AddDeleteAllCheckBox());
                                break;

                            case "EMPLOYEE ID":
                                hash_EmpMaster["n_EmpID"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_ID'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_ID'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "EMPLOYEE NAME":
                                hash_EmpMaster["n_EmpName"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_NAME'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_NAME'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "GRADE":
                                hash_EmpMaster["n_Grade"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'GRADE'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'GRADE'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'GRADE'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'GRADE'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'GRADE'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "DEPARTMENT":
                                hash_EmpMaster["n_Department"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DEPARTMENT'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DEPARTMENT'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DEPARTMENT'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DEPARTMENT'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DEPARTMENT'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "SBU":
                                hash_EmpMaster["n_SBU"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'SBU'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'SBU'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'SBU'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'SBU'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'SBU'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "DESIGNATION":
                                hash_EmpMaster["n_Designation"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DESIGNATION'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DESIGNATION'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DESIGNATION'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DESIGNATION'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DESIGNATION'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "DATE OF JOINING":
                                hash_EmpMaster["n_DateOfJoining"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DATE_OF_JOINING'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DATE_OF_JOINING'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DATE_OF_JOINING'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DATE_OF_JOINING'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DATE_OF_JOINING'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "FORFEITURE GROUP":
                                hash_EmpMaster["n_ForFeitureGrp"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "LOCATION":
                                hash_EmpMaster["n_Location"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'LOCATION'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'LOCATION'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'LOCATION'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'LOCATION'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'LOCATION'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "COUNTRY":
                                hash_EmpMaster["n_Country"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'CountryName'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'CountryName'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'CountryName'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'CountryName'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'CountryName'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "EMPLOYEE SOURCE":
                                hash_EmpMaster["n_EmpSource"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_SOURCE'").Count() > 0;
                                break;

                            case "APPROVAL STATUS":
                                hash_EmpMaster["n_ApprovalStatus"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'APPROVAL_STATUS'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'APPROVAL_STATUS'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'APPROVAL_STATUS'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'APPROVAL_STATUS'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'APPROVAL_STATUS'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "COST CENTRE":
                                hash_EmpMaster["n_CostCentre"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'COST CENTRE'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'COST CENTRE'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'COST CENTRE'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'COST CENTRE'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'COST CENTRE'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "ENTITY":
                                hash_EmpMaster["n_Entity"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'ENTITY'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'ENTITY'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'ENTITY'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'ENTITY'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'ENTITY'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "IS SENIOR MANAGEMENT":
                                hash_EmpMaster["n_Is_SeniorMngmnt"] = n_index;
                                perColumn.Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'IS_SENIOR_MANAGEMENT'").Count() > 0;
                                dr = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? null : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'IS_SENIOR_MANAGEMENT'").Count() > 0 ? ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'IS_SENIOR_MANAGEMENT'") : null;
                                perColumn.Text = dr != null && ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'IS_SENIOR_MANAGEMENT'").Count() > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'IS_SENIOR_MANAGEMENT'")[0]["COLUMN_ALIAS"])) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "ACTION":
                                hash_EmpMaster["n_Action"] = n_index;
                                break;

                            case "DEPID":
                                hash_EmpMaster["n_Depid"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "SBUID":
                                hash_EmpMaster["n_Sbuid"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "LOCID":
                                hash_EmpMaster["n_Locid"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "COCID":
                                hash_EmpMaster["n_Cocid"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "ENTTID":
                                hash_EmpMaster["n_EnttId"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "CMID":
                                hash_EmpMaster["n_CmId"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "UPDATED_ON":
                                hash_EmpMaster["n_UpdatedOn"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "IS_ASSOCIATED":
                                hash_EmpMaster["n_IsAsscociated"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "DEP_APPL_DATE":
                                hash_EmpMaster["n_DEP_APPL_DATE"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "SBU_APPL_DATE":
                                hash_EmpMaster["n_SBU_APPL_DATE"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "LOC_APPL_DATE":
                                hash_EmpMaster["n_LOC_APPL_DATE"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "COC_APPL_DATE":
                                hash_EmpMaster["n_COC_APPL_DATE"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "ENT_APPL_DATE":
                                hash_EmpMaster["n_ENT_APPL_DATE"] = n_index;
                                perColumn.Visible = false;
                                break;
                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    try
                    {
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Depid"].ToString())].Visible =
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_DateOfJoining"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Sbuid"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Locid"].ToString())].Visible =
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Cocid"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EnttId"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_CmId"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_UpdatedOn"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_IsAsscociated"].ToString())].Visible = false;

                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_DEP_APPL_DATE"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_SBU_APPL_DATE"].ToString())].Visible =
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_LOC_APPL_DATE"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_COC_APPL_DATE"].ToString())].Visible =
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ENT_APPL_DATE"].ToString())].Visible = false;

                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EmpID"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE ID'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EmpName"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE NAME'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Grade"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'GRADE'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Department"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DEPARTMENT'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_SBU"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'SBU'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Designation"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DESIGNATION'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_DateOfJoining"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'DATE_OF_JOINING'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ForFeitureGrp"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'FORFEITURE_GROUP_NAME'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Location"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'LOCATION'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Country"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'CountryName'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EmpSource"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'EMPLOYEE_SOURCE'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ApprovalStatus"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'APPROVAL_STATUS'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_CostCentre"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'COST CENTRE'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Entity"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'ENTITY'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Is_SeniorMngmnt"].ToString())].Visible = ac_EmployeeMaster.dt_CustmizedViewEmpMaster == null || ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Rows.Count.Equals(0) ? true : ac_EmployeeMaster.dt_CustmizedViewEmpMaster.Select("COLUMN_NAME = 'IS_SENIOR_MANAGEMENT'").Count() > 0;

                        if (e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EmpSource"].ToString())].Text == "EDFinancials")
                        {
                            if (e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ID"].ToString())].Text != "1")
                            {
                                e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Action"].ToString())].Controls.Add(AddImageLink("Edit", b_IsEnabled, "~/View/App_Themes/images/Edit.png", e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EmpID"].ToString())].Text, e.Row.Cells[3].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Grade"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Designation"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_DateOfJoining"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Depid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Sbuid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Locid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Cocid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EnttId"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_CmId"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ForFeitureGrp"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Is_SeniorMngmnt"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ApprovalStatus"].ToString())].Text, "EDIT", e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_DEP_APPL_DATE"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_SBU_APPL_DATE"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_LOC_APPL_DATE"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_COC_APPL_DATE"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ENT_APPL_DATE"].ToString())].Text));

                                e.Row.Cells[1].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Delete"].ToString())].Text.Equals("1"), e.Row.Cells[25].Text, e.Row.Cells[3].Text));
                            }

                            e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Action"].ToString())].Controls.Add(AddImageLink("View History", true, "~/View/App_Themes/images/history.png", e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EmpID"].ToString())].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, e.Row.Cells[7].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_DateOfJoining"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Depid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Sbuid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Locid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Cocid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EnttId"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_CmId"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ForFeitureGrp"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Is_SeniorMngmnt"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ApprovalStatus"].ToString())].Text, "HISTORY", string.Empty, string.Empty, string.Empty, string.Empty, string.Empty));
                        }

                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Action"].ToString())].Controls.Add(AddImageLink("View Details", true, "~/View/App_Themes/images/ViewHistory.png", e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EmpID"].ToString())].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, e.Row.Cells[7].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_DateOfJoining"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Depid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Sbuid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Locid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Cocid"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_EnttId"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_CmId"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ForFeitureGrp"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Is_SeniorMngmnt"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ApprovalStatus"].ToString())].Text, "VIEW", string.Empty, string.Empty, string.Empty, string.Empty, string.Empty));

                        e.Row.Font.Italic = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ApprovalStatus"].ToString())].Text == "Pending" ? true : false;
                        e.Row.Font.Name = e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_ApprovalStatus"].ToString())].Text == "Pending" ? "Arial" : "Verdana";
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Delete"].ToString())].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[Convert.ToInt32(hash_EmpMaster["n_Action"].ToString())].HorizontalAlign = HorizontalAlign.Center;
                        break;
                    }
                    catch
                    {
                        throw;
                    }
            }
        }

        /// <summary>
        /// This method is used to re-order column names
        /// </summary>
        /// <param name="dataTable">orignal datatable</param>
        /// <param name="columnNames">array of column names</param>
        /// <returns>DataTable</returns>
        private DataTable SetColumnsOrder(DataTable dataTable, params String[] columnNames)
        {
            for (int columnIndex = 2; columnIndex < columnNames.Length; columnIndex++)
            {
                for (int j = 0; j < columnNames.Length;j++)
                { 
                    dataTable.Columns[columnNames[columnIndex]].SetOrdinal(j);
                }
            }
            return dataTable;
        }

        /// <summary>
        /// This method Adds 'Delete all' checkbox in the Header Part
        /// </summary>
        /// <returns>Returns Checkbox</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chkDeleteAll";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Text = string.Empty;
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }

        /// <summary>
        /// This method adds image button to gridview Action column at runtime .
        /// </summary>
        /// <param name="s_strToolTip">ToolTip for Button</param>
        /// <param name="b_IsEnabled">Enable status for image button</param>
        /// <param name="s_strUrl">Image Url</param>
        /// <param name="s_EMPID">EMPID</param>
        /// <param name="s_EmployeeId">Employee Id</param>
        /// <param name="s_EmployeeName">Employee Id</param>
        /// <param name="s_ForfeitureGrp">Employee Name</param>
        /// <param name="n_Is_SeniorMngmnt">Is SeniorMngmnt</param>
        /// <param name="s_ApprovalStatus">ApprovalStatus</param>
        /// <param name="s_Grade">Grade</param>
        /// <param name="s_Designation">Designation</param>
        /// <param name="Date_of_Joining">Date_of_Joining</param>
        /// <param name="s_DepId">Department Id</param>
        /// <param name="SbuId">Sbu Id</param>
        /// <param name="LocId">Location Id</param>
        /// <param name="CocId">Cost centre Id</param>
        /// <param name="EnttId">Entity Id</param>
        /// <param name="s_CMID">country id</param>
        /// <param name="s_ControlType">s_ControlType</param>
        /// <param name="s_DEP_APPL_DATE">s_DEP_APPL_DATE</param>
        /// <param name="s_SBU_APPL_DATE">s_SBU_APPL_DATE</param>
        /// <param name="s_LOC_APPL_DATE">s_LOC_APPL_DATE</param>
        /// <param name="s_COC_APPL_DATE">s_COC_APPL_DATE</param>
        /// <param name="s_ENT_APPL_DATE">s_ENT_APPL_DATE</param>
        /// <returns>Returns ImageButton</returns>
        private ImageButton AddImageLink(string s_strToolTip, bool b_IsEnabled, string s_strUrl, string s_EMPID, string s_EmployeeId, string s_EmployeeName, string s_Grade, string s_Designation, string Date_of_Joining, string s_DepId, string SbuId, string LocId, string CocId, string EnttId, string s_CMID, string s_ForfeitureGrp, string n_Is_SeniorMngmnt, string s_ApprovalStatus, string s_ControlType, string s_DEP_APPL_DATE, string s_SBU_APPL_DATE, string s_LOC_APPL_DATE, string s_COC_APPL_DATE, string s_ENT_APPL_DATE)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                bool b_Is_Pending = s_ApprovalStatus == "Pending" ? true : false;
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_ControlType == "EDIT" ? b_Is_Pending ? Convert.ToString((ac_EmployeeMaster.dt_EmployeeMasterUIText.Select("LabelID='EditBtnToolTipWhenStatusPending'"))[0]["LabelToolTip"]) : s_strToolTip : s_strToolTip;
                imgButton.Enabled = s_ControlType == "EDIT" ? b_IsEnabled ? !b_Is_Pending ? b_IsEnabled : false : b_IsEnabled : b_IsEnabled;
                imgButton.Style.Add("cursor", "pointer");
                if (!string.IsNullOrEmpty(s_EMPID))
                {
                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        switch (s_ControlType.ToUpper())
                        {
                            case "EDIT":
                                imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_EMPID + "','" + s_EmployeeId + "','" + s_EmployeeName + "','" + s_Grade + "','" + s_Designation + "','" + Date_of_Joining + "','" + s_DepId + "','" + SbuId + "','" + LocId + "','" + CocId + "','" + EnttId + "','" + s_CMID + "','" + s_ForfeitureGrp + "','" + n_Is_SeniorMngmnt + "','" + s_LOC_APPL_DATE + "','" + s_ENT_APPL_DATE + "','" + s_SBU_APPL_DATE + "','" + s_DEP_APPL_DATE + "','" + s_COC_APPL_DATE + "')");
                                break;
                            case "VIEW":
                                imgButton.Attributes.Add("onclick", "return ShowEmployeeDetails('" + s_EMPID + "','" + s_EmployeeId + "','" + s_EmployeeName + "','ViewEmployeeDetails')");
                                break;

                            case "HISTORY":
                                imgButton.Attributes.Add("onclick", "return ShowEmployeeDetails('" + s_EMPID + "','" + s_EmployeeId + "','" + s_EmployeeName + "','ViewEmployeeHistory')");
                                break;
                        }
                    }
                }
                return imgButton;
            }
        }

        /// <summary>
        /// This Method add checkboxes in the gridview first column.
        /// </summary>
        /// <param name="s_EmpID">s_EmpID</param>
        /// <param name="IsDeleted">IsDeleted</param>
        /// <param name="IsAssociate">IsAssociate</param>
        /// <param name="s_EmpName">s_EmpName</param>
        /// <returns>returns CheckBox</returns>
        private CheckBox AddCheckBox(string s_EmpID, bool IsDeleted, string IsAssociate, string s_EmpName)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_EmpID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");

                if (!string.IsNullOrEmpty(s_EmpID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_EmpID + "',this,'" + IsAssociate + "','" + s_EmpName + "')");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// This is the Main method that is used to filter the data based on the parameters selected from the multi select  dropdown. 
        /// Data filtered from first ddl is the base datatable for the next ddl to look for.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        public void FilterGridData(EmployeeMaster employeeMaster)
        {
            try
            {
                if (Convert.ToInt16(employeeMaster.hdnCalculations.Value) > 0)
                {
                    DataTable dt_FilterEmployeeData = ac_EmployeeMaster.dt_EmployeeDataList.Copy();
                    dt_FilterEmployeeData.Clear();
                    
                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_EmpID.chkMultiselect, dt_FilterEmployeeData, "[Employee Id]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_EmpID.chkMultiselect, employeeMaster.UcEM_EmpID.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_Country.chkMultiselect, dt_FilterEmployeeData, "[Country]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_Country.chkMultiselect, employeeMaster.UcEM_Country.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_EmpName.chkMultiselect, dt_FilterEmployeeData, "[Employee Name]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_EmpName.chkMultiselect, employeeMaster.UcEM_EmpName.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_Grade.chkMultiselect, dt_FilterEmployeeData, "[Grade]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_Grade.chkMultiselect, employeeMaster.UcEM_Grade.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_Location.chkMultiselect, dt_FilterEmployeeData, "[Location]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_Location.chkMultiselect, employeeMaster.UcEM_Location.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_Department.chkMultiselect, dt_FilterEmployeeData, "[Department]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_Department.chkMultiselect, employeeMaster.UcEM_Department.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_Entity.chkMultiselect, dt_FilterEmployeeData, "[Entity]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_Entity.chkMultiselect, employeeMaster.UcEM_Entity.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_SBU.chkMultiselect, dt_FilterEmployeeData, "[SBU]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_SBU.chkMultiselect, employeeMaster.UcEM_SBU.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_CostCentre.chkMultiselect, dt_FilterEmployeeData, "[Cost Centre]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_CostCentre.chkMultiselect, employeeMaster.UcEM_CostCentre.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_Designation.chkMultiselect, dt_FilterEmployeeData, "[Designation]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_Designation.chkMultiselect, employeeMaster.UcEM_Designation.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_AssignForfeitureGrp.chkMultiselect, dt_FilterEmployeeData, "[Forfeiture Group]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_AssignForfeitureGrp.chkMultiselect, employeeMaster.UcEM_AssignForfeitureGrp.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_EmployeeSource.chkMultiselect, dt_FilterEmployeeData, "[Employee Source]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_EmployeeSource.chkMultiselect, employeeMaster.UcEM_EmployeeSource.txtMultiselect);

                    dt_FilterEmployeeData = SearchEmployeeData(employeeMaster.UcEM_ApprovalStatus.chkMultiselect, dt_FilterEmployeeData, "[Approval Status]", ac_EmployeeMaster.IsFirstSelection);
                    AssignSearchFilterText(employeeMaster.UcEM_ApprovalStatus.chkMultiselect, employeeMaster.UcEM_ApprovalStatus.txtMultiselect);

                    dt_FilterEmployeeData = FilterOn_DateOfJoing_SeniorManagement(dt_FilterEmployeeData, employeeMaster);

                    employeeMaster.gv.DataSource = dt_FilterEmployeeData;
                    employeeMaster.gv.DataBind();
                    ac_EmployeeMaster.IsFirstSelection = true;
                    employeeMaster.btnEM_ClearSearch.Visible = true;
                    employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                }
                else
                {
                    employeeMaster.gv.DataSource = ac_EmployeeMaster.dt_EmployeeDataList;
                    employeeMaster.gv.DataBind();
                    employeeMaster.btnEM_ClearSearch.Visible = false;


                    ResetDropDown(employeeMaster, employeeMaster.UcEM_EmpID.chkMultiselect);
                    employeeMaster.UcEM_EmpID.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_Country.chkMultiselect);
                    employeeMaster.UcEM_Country.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_EmpName.chkMultiselect);
                    employeeMaster.UcEM_EmpName.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_Grade.chkMultiselect);
                    employeeMaster.UcEM_Grade.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_Location.chkMultiselect);
                    employeeMaster.UcEM_Location.txtMultiselect.Text = "--- Please Select ---";
                    
                    ResetDropDown(employeeMaster, employeeMaster.UcEM_Department.chkMultiselect);
                    employeeMaster.UcEM_Department.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_ApprovalStatus.chkMultiselect);
                    employeeMaster.UcEM_ApprovalStatus.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_Entity.chkMultiselect);
                    employeeMaster.UcEM_Entity.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_SBU.chkMultiselect);
                    employeeMaster.UcEM_SBU.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_CostCentre.chkMultiselect);
                    employeeMaster.UcEM_CostCentre.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_Designation.chkMultiselect);
                    employeeMaster.UcEM_Designation.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_AssignForfeitureGrp.chkMultiselect);
                    employeeMaster.UcEM_AssignForfeitureGrp.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(employeeMaster, employeeMaster.UcEM_EmployeeSource.chkMultiselect);
                    employeeMaster.UcEM_EmployeeSource.txtMultiselect.Text = "--- Please Select ---";

                    employeeMaster.txtEM_DateOfjoining.Text = "";
                    employeeMaster.ddlSeniorManagement.SelectedIndex = 0;

                    employeeMaster.hdnCalculations.Value = "0";
                }

                employeeMaster.btnEM_Delete.Visible = employeeMaster.gv.Rows.Count > 0 ? true : false;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// this method is used to assign text to dropdown list
        /// </summary>
        /// <param name="chk_CheckBoxList">CheckBoxList control</param>
        /// <param name="textBox">TextBox control</param>
        private void AssignSearchFilterText(CheckBoxList chk_CheckBoxList, TextBox textBox)
        {
            string s_SelectedValues = string.Join(",", chk_CheckBoxList.Items.Cast<ListItem>()
                                          .Where(li => li.Selected)
                                          .Select(li => li.Value)
                                          .ToArray());
            textBox.Text = !string.IsNullOrEmpty(s_SelectedValues) ? s_SelectedValues : "--- Please Select ---";
        }

        /// <summary>
        /// This method is used to reset dropdownlist
        /// </summary>
        /// <param name="employeeMaster">Employee master page object</param>
        /// <param name="checkBoxList">CheckBoxList object</param>
        private void ResetDropDown(EmployeeMaster employeeMaster, CheckBoxList checkBoxList)
        {
            (from i in checkBoxList.Items.Cast<ListItem>() select i).ToList().ForEach(i => i.Selected = false);
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt_FilterEmployeeData"></param>
        /// <param name="employeeMaster"></param>
        /// <returns></returns>
        internal DataTable FilterOn_DateOfJoing_SeniorManagement(DataTable dt_FilterEmployeeData, EmployeeMaster employeeMaster)
        {
            try
            {
                if (!string.IsNullOrEmpty(employeeMaster.txtEM_DateOfjoining.Text))
                {
                    if (ac_EmployeeMaster.IsFirstSelection)
                        dt_FilterEmployeeData = ac_EmployeeMaster.dt_EmployeeDataList.Select("Date_of_Joining = '" + employeeMaster.txtEM_DateOfjoining.Text + "'").CopyToDataTable();
                    else
                        dt_FilterEmployeeData = dt_FilterEmployeeData.Select("Date_of_Joining = '" + employeeMaster.txtEM_DateOfjoining.Text + "'").CopyToDataTable();
                    ac_EmployeeMaster.IsFirstSelection = false;
                }
            }
            catch
            {
                // Do Nothing.
            }
            try
            {
                if (employeeMaster.ddlSeniorManagement.SelectedIndex > 0)
                {
                    if (ac_EmployeeMaster.IsFirstSelection)
                        dt_FilterEmployeeData = ac_EmployeeMaster.dt_EmployeeDataList.Select("[IS_SENIOR_MANAGEMENT] = '" + employeeMaster.ddlSeniorManagement.SelectedValue + "'").CopyToDataTable();
                    else
                        dt_FilterEmployeeData = dt_FilterEmployeeData.Select("[IS_SENIOR_MANAGEMENT] = '" + employeeMaster.ddlSeniorManagement.SelectedValue + "'").CopyToDataTable();
                    ac_EmployeeMaster.IsFirstSelection = false;
                }
            }
            catch
            {
                // Do Nothing.
            }

            return dt_FilterEmployeeData;
        }


        /// <summary>
        /// This method is used to filter the data for particular multiselect dropdown and the filtered data is returned for another multi dropdown for search.
        /// </summary>
        /// <param name="chk_CheckBoxList"></param>
        /// <param name="dt_FilterEmployeeData"></param>
        /// <param name="s_columnName"></param>
        /// <param name="s_Status"></param>
        /// <returns>returns Datatable</returns>
        internal DataTable SearchEmployeeData(CheckBoxList chk_CheckBoxList, DataTable dt_FilterEmployeeData, string s_columnName, bool s_Status)
        {
            DataTable dt_temp = new DataTable();
            bool b_count = true;
            dt_temp = dt_FilterEmployeeData.Copy();

            foreach (ListItem CurrentItem in chk_CheckBoxList.Items)
            {
                try
                {
                    if (CurrentItem.Selected)
                    {
                        ac_EmployeeMaster.IsFirstSelection = false;
                        if (s_Status)
                        {
                            dt_temp = processDataTable(ac_EmployeeMaster.dt_EmployeeDataList.Select("" + s_columnName + " = '" + CurrentItem.Text.Replace("'", "''") + "'").CopyToDataTable(), dt_FilterEmployeeData);
                        }
                        else
                        {
                            if (b_count)
                            {
                                dt_FilterEmployeeData.Clear();
                                b_count = false;
                            }
                            dt_FilterEmployeeData = processDataTable(dt_temp.Select("" + s_columnName + " = '" + CurrentItem.Text.Replace("'", "''") + "'").CopyToDataTable(), dt_FilterEmployeeData);
                        }
                    }
                }
                catch
                {
                    // Do Nothing.
                }
            }
            dt_FilterEmployeeData = s_Status == true ? dt_temp : dt_FilterEmployeeData;
            dt_temp.Dispose();
            return dt_FilterEmployeeData;

        }

        /// <summary>
        /// This method is is used to centralise the loop for used for searching the row to be filtered.
        /// </summary>
        /// <param name="dt_temp">temporary dataTable</param>
        /// <param name="dt_CopyEmployeeRow">table from which data is to be copied</param>
        /// <returns>returns DataTable</returns>
        internal DataTable processDataTable(DataTable dt_temp, DataTable dt_CopyEmployeeRow)
        {
            foreach (DataRow dr in dt_temp.Rows)
            {
                var newDataRow = dt_CopyEmployeeRow.NewRow();
                newDataRow.ItemArray = dr.ItemArray;
                dt_CopyEmployeeRow.Rows.Add(newDataRow);
            }
            return dt_CopyEmployeeRow;
        }

        /// <summary>
        /// This method performs Create / update / delete / apporve / disapprove actions based on the action type provided.
        /// </summary>
        /// <param name="employeeMaster">employeeMaster page object</param>
        public void PerformCUD(EmployeeMaster employeeMaster)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.Id = employeeMaster.hdnEmpId.Value.Contains(",") ? 0 : employeeMaster.hdnEmpId.Value == "" ? 0 : Convert.ToInt32(employeeMaster.hdnEmpId.Value);
                    accountingProperties.Ids = employeeMaster.hdnEmpId.Value.TrimStart(',');

                    if (!(employeeMaster.hdnOperationType.Value == "DELETE_USER" || employeeMaster.hdnOperationType.Value == "APPROVE_DETAILS" || employeeMaster.hdnOperationType.Value == "DISAPPROVE_DETAILS"))
                    {
                        accountingProperties.Employee_Id = employeeMaster.txtEM_AddEmployeeId.Text;
                        accountingProperties.Employee_Name = CommonModel.ReplaceApostrophe(employeeMaster.txtEditEmployeeName.Text);
                        accountingProperties.Grade = employeeMaster.txtEditGrade.Text;
                        accountingProperties.Designation = employeeMaster.txtEM_Designation.Text;
                        accountingProperties.Country = Convert.ToInt16(employeeMaster.ddlEM_EditCountry.SelectedValue == "--- Please Select ---" ? "0" : employeeMaster.ddlEM_EditCountry.SelectedValue);
                        try
                        {
                            accountingProperties.Date_Of_Jointing = Convert.ToDateTime(employeeMaster.dpEM_AddDateofJoining.Text == "" ? "01/01/1900" : employeeMaster.dpEM_AddDateofJoining.Text == "dd/mmm/yyyy" ? "01/01/1900" : employeeMaster.dpEM_AddDateofJoining.Text);
                        }
                        catch (Exception)
                        {
                            employeeMaster.ctrSuccessErrorMessage.s_MessageText = Convert.ToString((ac_EmployeeMaster.dt_EmployeeMasterUIText.Select("LabelID='lblEM_DateOfjoining'"))[0]["ErrorText"]);
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            return;
                        }
                        accountingProperties.ForFeitureGrp = Convert.ToInt16(employeeMaster.ddlEM_EditAssignForfeitureGrp.SelectedValue);
                        accountingProperties.Is_SeniorManagement = employeeMaster.chkEM_EditSeniorManagement.Checked;

                        accountingProperties.SBU = Convert.ToInt16(employeeMaster.ddlEM_AddSBU.SelectedValue == "--- Please Select ---" ? "0" : employeeMaster.ddlEM_AddSBU.SelectedValue);
                        accountingProperties.CostCentre = Convert.ToInt16(employeeMaster.ddlEM_AddCostCentre.SelectedValue == "--- Please Select ---" ? "0" : employeeMaster.ddlEM_AddCostCentre.SelectedValue);
                        accountingProperties.Department = Convert.ToInt16(employeeMaster.ddlEM_AddDepartment.SelectedValue == "--- Please Select ---" ? "0" : employeeMaster.ddlEM_AddDepartment.SelectedValue);
                        accountingProperties.Location = Convert.ToInt16(employeeMaster.ddlEM_AddLocation.SelectedValue == "--- Please Select ---" ? "0" : employeeMaster.ddlEM_AddLocation.SelectedValue);
                        accountingProperties.Entity = Convert.ToInt16(employeeMaster.ddlEM_AddEntity.SelectedValue == "--- Please Select ---" ? "0" : employeeMaster.ddlEM_AddEntity.SelectedValue);
                    }
                    else
                    {
                        accountingProperties.Employee_Id = accountingProperties.Employee_Name = "0";
                        accountingProperties.Date_Of_Jointing = DateTime.Now;
                    }

                    accountingProperties.Coc_applicable_from = accountingProperties.Dep_applicable_from = accountingProperties.Sbu_applicable_from = accountingProperties.Loc_applicable_from = accountingProperties.Entt_applicable_from = (employeeMaster.dpEM_AddDateofJoining.Text == "dd/mmm/yyyy" || employeeMaster.dpEM_AddDateofJoining.Text == "") ? "01/01/1900" : employeeMaster.dpEM_AddDateofJoining.Text;

                    if (employeeMaster.hdnOperationType.Value == "UPDATE_USER")
                    {
                        accountingProperties.Is_SbuId_Modified = !employeeMaster.ddlEM_AddSBU.SelectedValue.Equals(employeeMaster.hdnCheckSBUEditValue.Value);
                        accountingProperties.Sbu_applicable_from = accountingProperties.Is_SbuId_Modified ? employeeMaster.txtEM_EditSBUFromDate.Text : "";

                        accountingProperties.Is_CocId_Modified = !employeeMaster.ddlEM_AddCostCentre.SelectedValue.Equals(employeeMaster.hdnCheckCocEditValue.Value);
                        accountingProperties.Coc_applicable_from = accountingProperties.Is_CocId_Modified ? employeeMaster.txtEM_EditCostCentre.Text : "";

                        accountingProperties.Is_DepId_Modified = !employeeMaster.ddlEM_AddDepartment.SelectedValue.Equals(employeeMaster.hdnCheckDepEditValue.Value);
                        accountingProperties.Dep_applicable_from = accountingProperties.Is_DepId_Modified ? employeeMaster.txtEM_EditDepartmentFromDate.Text : "";

                        accountingProperties.Is_LocId_Modified = !employeeMaster.ddlEM_AddLocation.SelectedValue.Equals(employeeMaster.hdnCheckLocEditValue.Value);
                        accountingProperties.Loc_applicable_from = accountingProperties.Is_LocId_Modified ? employeeMaster.txtEM_EditLocationFromDate.Text : "";

                        accountingProperties.Is_EnttId_Modified = !employeeMaster.ddlEM_AddEntity.SelectedValue.Equals(employeeMaster.hdnCheckEnttEditValue.Value);
                        accountingProperties.Entt_applicable_from = accountingProperties.Is_EnttId_Modified ? employeeMaster.txtEM_EditEntityFromDate.Text : "";

                        if (CommonModel.CheckAgainstLockedAccountingReport(Convert.ToString(accountingProperties.Sbu_applicable_from), userSessionInfo))
                        {
                            DisplayError_Message(employeeMaster, accountingServiceClient);
                            LoadControls(employeeMaster);
                            return;
                        }
                        else if (CommonModel.CheckAgainstLockedAccountingReport(Convert.ToString(accountingProperties.Coc_applicable_from), userSessionInfo))
                        {
                            DisplayError_Message(employeeMaster, accountingServiceClient);
                            LoadControls(employeeMaster);
                            return;
                        }
                        else if (CommonModel.CheckAgainstLockedAccountingReport(Convert.ToString(accountingProperties.Dep_applicable_from), userSessionInfo))
                        {
                            DisplayError_Message(employeeMaster, accountingServiceClient);
                            LoadControls(employeeMaster);
                            return;
                        }
                        else if (CommonModel.CheckAgainstLockedAccountingReport(Convert.ToString(accountingProperties.Loc_applicable_from), userSessionInfo))
                        {
                            DisplayError_Message(employeeMaster, accountingServiceClient);
                            LoadControls(employeeMaster);
                            return;
                        }
                        else if (CommonModel.CheckAgainstLockedAccountingReport(Convert.ToString(accountingProperties.Entt_applicable_from), userSessionInfo))
                        {
                            DisplayError_Message(employeeMaster, accountingServiceClient);
                            LoadControls(employeeMaster);
                            return;
                        }
                    }

                    accountingProperties.Action = employeeMaster.hdnOperationType.Value;
                    accountingProperties.PageName = CommonConstantModel.s_EmployeeMaster;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;

                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                    AccountingCRUDProperties accountingCRUDProperties = new AccountingCRUDProperties();
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            employeeMaster.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMMError", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            LoadControls(employeeMaster);
                            break;

                        case 1:
                            employeeMaster.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblEMAdded", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            LoadControls(employeeMaster);
                            break;

                        case 2:
                            employeeMaster.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblEMUpdated", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            LoadControls(employeeMaster);
                            break;

                        case 3:
                            employeeMaster.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblEMDeleted", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            LoadControls(employeeMaster);
                            break;

                        case 4:
                            employeeMaster.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblMAExists", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            LoadControls(employeeMaster);
                            break;

                        case 5:
                            employeeMaster.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblCanNotEditBeingUsed", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            LoadControls(employeeMaster);
                            break;

                        case 6:
                            employeeMaster.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblEMApproved", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            LoadControls(employeeMaster);
                            break;

                        case 7:
                            employeeMaster.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblEMDisApproved", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            LoadControls(employeeMaster);
                            break;

                        case 8:
                            employeeMaster.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblEMInvalidApplicableDate", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
                            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            LoadControls(employeeMaster);
                            break;

                    }


                }
            }
            catch
            {
                throw;
            }
        }

        private void DisplayError_Message(EmployeeMaster employeeMaster, AccountingServiceClient accountingServiceClient)
        {
            employeeMaster.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblCntEditAsReportLock", accountingProperties.PageName, CommonConstantModel.s_AccountingL10);
            employeeMaster.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
            employeeMaster.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="employeeMaster"></param>
        private void LoadControls(EmployeeMaster employeeMaster)
        {
            LoadEmployeeGrid(employeeMaster);
            LoadAllEMployeeHistoryList(employeeMaster);
            LoadAllSearchDropDowns(employeeMaster);
            employeeMaster.hdnEmpId.Value = "";
        }

        /// <summary>
        /// This method Filters the module list based on the database name provided.
        /// </summary>
        ///  <param name="s_EMPID">This is EmId</param>
        /// <param name="s_Employee_Id">This isEmployee Id</param>
        ///<param name="s_BtnId">This is button Id</param>
        ///<param name="s_ParameterType">This is the parameter that was modified</param>
        public DataTable View_EmployeeDetails(string s_EMPID, string s_Employee_Id, string s_BtnId, string s_ParameterType)
        {
            DataTable dtGetEmployeeData = null;

            try
            {
                switch (s_BtnId)
                {
                    case "ViewEmployeeDetails":
                        if (!(string.IsNullOrEmpty(s_Employee_Id)))
                            using (DataTable dt_selectedEmployeeDetails = ac_EmployeeMaster.dt_EmployeeDataList.Select("[Employee Id] = '" + s_Employee_Id + "'").CopyToDataTable())
                            {
                                dtGetEmployeeData = dt_selectedEmployeeDetails;
                            }

                        break;

                    case "ViewEmployeeHistory":
                        try
                        {
                            if (!(string.IsNullOrEmpty(s_ParameterType)))
                            {
                                using (DataTable dt_selectedEmployeeDetails = ac_EmployeeMaster.dt_EmployeeHistoryData.Select("[EMPID] = '" + s_EMPID + "' AND ATMID = '" + s_ParameterType + "'").CopyToDataTable())
                                {
                                    dtGetEmployeeData = dt_selectedEmployeeDetails;
                                }
                            }
                            else
                                dtGetEmployeeData = ac_EmployeeMaster.dt_EmployeeHistoryData.Select("[EMPID] = '" + s_EMPID + "'").CopyToDataTable();
                        }
                        catch (Exception)
                        {
                            dtGetEmployeeData = new DataTable();
                        }
                        break;
                }
                return dtGetEmployeeData;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Validate Employee Id.
        /// </summary>
        /// <param name="s_Employee_Id">string Employee_Id</param>
        /// <param name="s_ValidateType">string s_ValidateType</param>
        /// <param name="s_NewApplicableDate">string s_NewApplicableDate</param>
        internal string Validate_EmployeeId(string s_Employee_Id, string s_ValidateType, string s_NewApplicableDate)
        {
            string s_Result = "";
            try
            {
                if (!string.IsNullOrEmpty(s_Employee_Id))
                    switch (s_ValidateType)
                    {
                        case "VALIDATE_ID":

                            s_Result = Convert.ToString(ac_EmployeeMaster.dt_EmployeeDataList.Select("[Employee Id] = '" + s_Employee_Id + "'")[0]["Employee Name"]);
                            break;

                        case "VALIDATE_APPLICABLE_DATE":
                            s_Result = Convert.ToString(ac_EmployeeMaster.dt_EmployeeHistoryData.Select("[EMPID] = '" + s_Employee_Id + "' AND ATMID = 1")[0]["APPLICABLE_FROM"]);
                            s_Result = Convert.ToDateTime(s_NewApplicableDate) < Convert.ToDateTime(s_Result) ? "INVALID DATE" : "";

                            break;
                    }

            }
            catch (Exception ex)
            {
                s_Result = ex.Message.Contains("Index was outside the bounds") ? "" : "INVALID DATE";

            }
            return s_Result;
        }

        /// <summary>
        /// This method is used to change pages of gridview.
        /// </summary>
        /// <param name="e">gridview event arguement e</param>
        /// <param name="employeeMaster">employee master object</param>
        internal void PageIndexChanging(GridViewPageEventArgs e, EmployeeMaster employeeMaster)
        {
            try
            {
                employeeMaster.gv.PageIndex = e.NewPageIndex;
                employeeMaster.gv.DataSource = ac_EmployeeMaster.dt_EmployeeDataList;
                employeeMaster.gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~EmployeeMasterModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}