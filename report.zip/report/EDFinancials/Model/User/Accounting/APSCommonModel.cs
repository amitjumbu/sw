﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Accounting  Parameters setup common class
    /// </summary>
    public class APSCommonModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public APSCommonModel()
        {
            if (ac_AccountingParameter == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_AccountingParameter);
                ac_AccountingParameter = (CommonModel.AC_AccountingParameter)HttpContext.Current.Session[CommonConstantModel.s_AC_AccountingParameter];
            }
        }

        #region Common Methods


        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_ConfigID">The Id for which link should be displayed</param>
        /// <param name="s_FromDate">From Date parameter object</param>
        /// <param name="s_ToDate">To Date parameter ibject</param>
        /// <returns>Returns control HyperLink</returns>
        public HyperLink AddHistoryHyperLink(string s_ConfigID, string s_FromDate, string s_ToDate)
        {
            using (HyperLink hyperLink = new HyperLink())
            {
                hyperLink.Text = "View History";
                hyperLink.ToolTip = "Click here to view history data";
                hyperLink.ID = "hypHistory";
                hyperLink.ClientIDMode = ClientIDMode.Static;
                hyperLink.CssClass = "cHyperLinksp";
                hyperLink.TabIndex = 9;
                hyperLink.Attributes.Add("onclick", "return ViewHistoryData('" + s_ConfigID + "','" + s_FromDate.Trim() + "','" + s_ToDate.Trim() + "')");
                return hyperLink;
            }
        }

       
        /// <summary>
        /// Method is used to rebind all the grids on postback
        /// </summary>
        /// <param name="accountingParameters">accountingParameters page object</param>
        /// <param name="b_IsPageIndChange">boolean value as a input parameter</param>
        public void ReBindGridsOnPostBack(AccountingParameters accountingParameters, bool b_IsPageIndChange)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_AccountingParameter;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = CommonConstantModel.s_OperationRead;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_AccountingParameter.ds_AccountingParameters = (DataSet)accountingCRUDProperties.ds_Result;
                    accountingParameters.gv.DataSource = ac_AccountingParameter.ds_AccountingParameters.Tables[1];
                    accountingParameters.gv.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to trigger a mail to the reviewer
        /// </summary>
        /// <param name="s_Parameter">The parametrs name which are chnaged wll send to user</param>
        public void SendMailForApproval(string s_Parameter)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_AccountingParameter.dt_ReviewerDetails = genericServiceClient.GetReviewerDetails(genericProperties);
                    string s_EmailIds = string.Empty;
                    if (ac_AccountingParameter.dt_ReviewerDetails.Rows.Count > 0)
                    {
                        int i = 0;
                        foreach (DataRow row in ac_AccountingParameter.dt_ReviewerDetails.Rows)
                        {
                            if (string.IsNullOrEmpty(s_EmailIds))
                                s_EmailIds = ac_AccountingParameter.dt_ReviewerDetails.Rows[i][0].ToString();
                            else s_EmailIds += ", " + ac_AccountingParameter.dt_ReviewerDetails.Rows[i][0].ToString();
                            i = i + 1;
                        }
                    }
                    var s_MailBody = string.Empty;
                    emailProperties.s_MailBody = MailBody(s_Parameter);
                    string s_Subject = "@Company - Change in accounting parameter";
                    s_Subject = s_Subject.Replace("@Company", userSessionInfo.ACC_CompanyTitle);
                    emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                    emailProperties.b_IsBodyHtml = true;
                    emailProperties.s_MailTo = s_EmailIds;
                    emailProperties.s_MailCC = "";
                    emailProperties.s_MailBCC = "";
                    emailProperties.s_MailSubject = s_Subject;
                    genericServiceClient.SaveSendMail(emailProperties);
                }
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// Append parameters in MailBody
        /// </summary>
        /// <param name="s_Parameter">The parameters name</param>
        /// <returns>Mailbody in for of string</returns>
        public string MailBody(string s_Parameter)
        {
            try
            {
                StringBuilder s_MailBody = new StringBuilder();
                s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\ReviewerAccParamApprovalAlert.html"));
                s_MailBody.Replace("@UserName", userSessionInfo.ACC_UserName);
                s_MailBody.Replace("@Company", userSessionInfo.ACC_CompanyTitle);
                s_MailBody.Replace("@Database", userSessionInfo.ACC_CompanyName);
                s_MailBody.Replace("@Parameter", s_Parameter);
                s_MailBody.Replace("@Link", ConfigurationManager.AppSettings["SiteURL"]);
                s_MailBody.Replace("@ValCustSupport", ConfigurationManager.AppSettings["ValCustSupport"]);
                return s_MailBody.ToString();
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~APSCommonModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}