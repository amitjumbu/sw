﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting.UserControl;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// The model class for CorporateActionUpdRevertUC Page.
    /// </summary>
    public class CorporateActionUpdRevertUCModel : BaseModel, IDisposable
    {
        #region Default Constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public CorporateActionUpdRevertUCModel()
        {
            if (ac_CorporateActionAdjustment == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_CorporateActionAdjustment);
                ac_CorporateActionAdjustment = (CommonModel.AC_CorporateActionAdjustment)HttpContext.Current.Session[CommonConstantModel.s_AC_CorporateActionAdjustment];
            }
        }
        #endregion

        /// <summary>
        /// This method is used to Bind names to all controls of Page
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        internal void BindUI(CorporateActionUpdRevertUC corporateActionUpdRevertUC)
        {
            try
            {
                foreach (Control control in corporateActionUpdRevertUC.divCAAUpdateUpdRev.Controls)
                {
                    switch (control.GetType().FullName.ToUpper())
                    {
                        case CommonConstantModel.s_wcLabel:
                            CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_CorporateActionAdjustment.dt_CorpActionAdjUI, (Label)control, null, null, null, null, null, null, null, null, null);
                            break;

                        case CommonConstantModel.s_wcTextbox:
                            CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_CorporateActionAdjustment.dt_CorpActionAdjUI, null, (TextBox)control, null, null, null, null, null, null, null, null);
                            break;

                        case CommonConstantModel.s_wcButton:
                            CommonModel.BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_CorporateActionAdjustment.dt_CorpActionAdjUI, null, null, (Button)control, null, null, null, null, null, null, null);
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The method to Make Enable/Disable the Controls
        /// </summary>
        /// <param name="imageButton">ImageButton imageButton Control</param>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        private void EnableDisableControls(ImageButton imageButton, CorporateActionUpdRevertUC corporateActionUpdRevertUC)
        {
            try
            {
                using (ac_CorporateActionAdjustment.dt_RolePreviledges)
                {
                    if (ac_CorporateActionAdjustment.dt_RolePreviledges != null && ac_CorporateActionAdjustment.dt_RolePreviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in ac_CorporateActionAdjustment.dt_RolePreviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case CommonConstantModel.s_ADD:
                                    imageButton.Enabled = true;
                                    break;

                                case CommonConstantModel.s_EDIT:
                                    imageButton.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind gvCAAUpdateCorpAction GridView
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="s_EffectiveDate">Effective Date</param>
        internal void btnCAAUpdateCorpAct_Click(CorporateActionUpdRevertUC corporateActionUpdRevertUC, string s_EffectiveDate)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    corporateActionUpdRevertUC.hdnEffectiveDate.Value = s_EffectiveDate;

                    GetCorporateActionDataFromDB(s_EffectiveDate, accountingServiceClient);

                    /* Bind the data to the gvCAAUpdateCorpAction GridView */
                    BindgvCAAUpdateCorpActionGridView(corporateActionUpdRevertUC);

                    /* Enable/Disable of Apply Button */
                    corporateActionUpdRevertUC.btnCAAApply.Enabled = userSessionInfo.ACC_CalculationMethod.Equals(2) ? ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.Rows.Count != 0 && (ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.Rows.Count == ac_CorporateActionAdjustment.dt_SavedCorpActAdjVestwiseShadow.Select("IS_SAVED = 1").Count()) : ac_CorporateActionAdjustment.dt_UpdateCorpActAdj.Rows.Count != 0 && (ac_CorporateActionAdjustment.dt_UpdateCorpActAdj.Rows.Count == ac_CorporateActionAdjustment.dt_SavedCorpActAdjShadow.Rows.Count);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Get Corporate Action Data From DataBase.
        /// </summary>
        /// <param name="s_EffectiveDate">string Effective Date</param>
        /// <param name="accountingServiceClient">AccountingService accountingServiceClient Object</param>
        internal void GetCorporateActionDataFromDB(string s_EffectiveDate, AccountingServiceClient accountingServiceClient)
        {
            try
            {
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.PageName = CommonConstantModel.s_CorporateActionAdjustment;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingProperties.Effective_Date = Convert.ToDateTime(s_EffectiveDate);

                /* sending parameter accountingProperties.s_CaluationMethod = '1' in case if it grantwise client and accountingProperties.s_CaluationMethod = '1,2' in case if it is vestwise client */
                accountingProperties.s_CaluationMethod = Convert.ToString(userSessionInfo.ACC_CalculationMethod).Equals(1) ? "1" : "1,2";

                accountingProperties.PopulateControls = "GET_CORP_ACTION_GRANTS_DATA";

                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                ac_CorporateActionAdjustment.ds_UpdateCorpActAdj = (DataSet)accountingCRUDProperties.ds_Result;

                ac_CorporateActionAdjustment.dt_UpdateCorpActAdj = ac_CorporateActionAdjustment.ds_UpdateCorpActAdj.Tables[0].Copy();
                ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise = ac_CorporateActionAdjustment.ds_UpdateCorpActAdj.Tables[1].Copy();
                ac_CorporateActionAdjustment.dt_SavedCorpActAdjShadow = ac_CorporateActionAdjustment.ds_UpdateCorpActAdj.Tables[2].Copy();
                ac_CorporateActionAdjustment.dt_SavedCorpActAdjVestwiseShadow = ac_CorporateActionAdjustment.ds_UpdateCorpActAdj.Tables[3].Copy();
                ac_CorporateActionAdjustment.dt_DataUpdatedOn = ac_CorporateActionAdjustment.ds_UpdateCorpActAdj.Tables[4].Copy();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind the data to the gvCAAUpdateCorpAction GridView
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        private void BindgvCAAUpdateCorpActionGridView(CorporateActionUpdRevertUC corporateActionUpdRevertUC)
        {
            try
            {
                using (DataView dv_UpdateCorpActAdj = new DataView(ac_CorporateActionAdjustment.dt_UpdateCorpActAdj))
                {
                    if (dv_UpdateCorpActAdj.Count > 0)
                    {
                        using (DataTable dt_GrantData = dv_UpdateCorpActAdj.ToTable())
                        {
                            var var_GroupedData = dt_GrantData.AsEnumerable().GroupBy(item => item.Field<string>("Grant Option ID"));
                            var var_SortedRecords = var_GroupedData.Select(grp => grp.OrderBy(item => item.Field<string>("Grant Date")).First());

                            corporateActionUpdRevertUC.gvCAAUpdateCorpAction.DataSource = var_SortedRecords.CopyToDataTable();
                            corporateActionUpdRevertUC.gvCAAUpdateCorpAction.DataBind();
                        }
                    }
                    else
                    {
                        corporateActionUpdRevertUC.gvCAAUpdateCorpAction.DataSource = ac_CorporateActionAdjustment.dt_UpdateCorpActAdj != null && ac_CorporateActionAdjustment.dt_UpdateCorpActAdj.Rows.Count > 0 ? ac_CorporateActionAdjustment.dt_UpdateCorpActAdj : null;
                        corporateActionUpdRevertUC.gvCAAUpdateCorpAction.DataBind();
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Row Data Bound Event Of gvCAAUpdateCorpAction GridView
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="sender">gvCAAUpdateCorpAction GridView</param>
        /// <param name="e">e</param>
        /// <param name="n_indexgv">int n_indexgv parameter</param>
        /// <param name="hash_Table">Hashtable of ref int parameters</param>
        internal void gvCAAUpdateCorpAction_RowDataBound(CorporateActionUpdRevertUC corporateActionUpdRevertUC, object sender, GridViewRowEventArgs e, ref int n_indexgv, ref Hashtable hash_Table)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "AGRMID":
                                    hash_Table["n_AGRMID"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "EMPID":
                                    hash_Table["n_EmpID"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "GRANT DATE":
                                    hash_Table["n_GrantDate"] = n_indexgv;
                                    break;

                                case "GRANT OPTION ID":
                                    hash_Table["n_GrntOptID"] = n_indexgv;
                                    break;

                                case "VESTING DETAILS":
                                    hash_Table["n_ViewVestDetails"] = n_indexgv;
                                    perColumn.Visible = userSessionInfo.ACC_CalculationMethod.Equals(1) ? false : true;
                                    break;

                                case "OPTIONS GRANTED":
                                    hash_Table["n_OptGranted"] = n_indexgv;
                                    break;

                                case "OPTIONS CANCELLED":
                                    hash_Table["n_OptCancelled"] = n_indexgv;
                                    break;

                                case "OPTIONS UNVESTED CANCELLED":
                                    hash_Table["n_OptUnvestCancelled"] = n_indexgv;
                                    break;

                                case "OPTIONS VESTED CANCELLED":
                                    hash_Table["n_OptVestedCancelled"] = n_indexgv;
                                    break;

                                case "OPTIONS LAPSED":
                                    hash_Table["n_OptLapsed"] = n_indexgv;
                                    break;

                                case "OPTIONS EXERCISED":
                                    hash_Table["n_OptExercised"] = n_indexgv;
                                    break;

                                case "OPTIONS UNVESTED":
                                    hash_Table["n_OptUnvested"] = n_indexgv;
                                    break;

                                case "OPTIONS VESTED AND EXERCISABLE":
                                    hash_Table["n_OptVestedExercisable"] = n_indexgv;
                                    break;

                                case "OUTSTANDING OPTIONS":
                                    hash_Table["n_OutstandingOpt"] = n_indexgv;
                                    break;

                                case "FAIR VALUE":
                                    hash_Table["n_FairValue"] = n_indexgv;
                                    break;

                                case "INTRINSIC VALUE":
                                    hash_Table["n_IntrinsicValue"] = n_indexgv;
                                    break;

                                case "EXERCISE PRICE":
                                    hash_Table["n_ExercisePrc"] = n_indexgv;
                                    break;

                                case "IS_MU_FV":
                                    hash_Table["n_IS_MU_FV"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "IS_MU_IV":
                                    hash_Table["n_IS_MU_IV"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_OPTIONS GRANTED":
                                    hash_Table["n_PreOptGranted"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_OPTIONS CANCELLED":
                                    hash_Table["n_PreOptCancelled"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_OPTIONS UNVESTED CANCELLED":
                                    hash_Table["n_PreOptUnvestCancelled"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_OPTIONS VESTED CANCELLED":
                                    hash_Table["n_PreOptVestedCancelled"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_OPTIONS LAPSED":
                                    hash_Table["n_PreOptLapsed"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_OPTIONS EXERCISED":
                                    hash_Table["n_PreOptExercised"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_OPTIONS UNVESTED":
                                    hash_Table["n_PreOptUnvested"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_OPTIONS VESTED AND EXERCISABLE":
                                    hash_Table["n_PreOptVestedExercisable"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_OUTSTANDING OPTIONS":
                                    hash_Table["n_PreOutstandingOpt"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_FAIR VALUE":
                                    hash_Table["n_PreFairValue"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_INTRINSIC VALUE":
                                    hash_Table["n_PreIntrinsicValue"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_EXERCISE PRICE":
                                    hash_Table["n_PreExercisePrc"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_COMP COSTFV":
                                    hash_Table["n_PreCostFV"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "PRE_COMP COSTIV":
                                    hash_Table["n_PreCostIV"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_OPTIONS GRANTED":
                                    hash_Table["n_PostOptGranted"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_OPTIONS CANCELLED":
                                    hash_Table["n_PostOptCancelled"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_OPTIONS UNVESTED CANCELLED":
                                    hash_Table["n_PostOptUnvestCancelled"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_OPTIONS VESTED CANCELLED":
                                    hash_Table["n_PostOptVestedCancelled"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_OPTIONS LAPSED":
                                    hash_Table["n_PostOptLapsed"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_OPTIONS EXERCISED":
                                    hash_Table["n_PostOptExercised"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_OPTIONS UNVESTED":
                                    hash_Table["n_PostOptUnvested"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_OPTIONS VESTED AND EXERCISABLE":
                                    hash_Table["n_PostOptVestedExercisable"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_OUTSTANDING OPTIONS":
                                    hash_Table["n_PostOutstandingOpt"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_FAIR VALUE":
                                    hash_Table["n_PostFairValue"] = n_indexgv;
                                    perColumn.Text = "Fair Value";
                                    break;

                                case "POST_INTRINSIC VALUE":
                                    hash_Table["n_PostIntrinsicValue"] = n_indexgv;
                                    perColumn.Text = "Intrinsic Value";
                                    break;

                                case "POST_EXERCISE PRICE":
                                    hash_Table["n_PostExercisePrc"] = n_indexgv;
                                    perColumn.Text = "Exercise Price";
                                    break;

                                case "POST_COMP COSTFV":
                                    hash_Table["n_PostCostFV"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "POST_COMP COSTIV":
                                    hash_Table["n_PostCostIV"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "CANCELLATION DATE":
                                    hash_Table["n_CancellationDate"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "LAPSED DATE":
                                    hash_Table["n_LapsedDate"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "EXERCISED DATE":
                                    hash_Table["n_ExercisedDate"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "OPERATION_ID":
                                    hash_Table["n_OperationID"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "OPERATION_DATE":
                                    hash_Table["n_OperationDate"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "IS_LOCKED":
                                    hash_Table["n_IsLocked"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "IS_JOINT_MODIFICATION" :
                                    hash_Table["n_IsJointModification"] = n_indexgv;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTIONS":
                                    hash_Table["n_Actionsgv"] = n_indexgv;
                                    break;
                            }

                            n_indexgv = n_indexgv + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptGranted"].ToString())])) && !e.Row.Cells[Convert.ToInt32(hash_Table["n_OptGranted"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_OptGranted"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptGranted"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptGranted"].ToString())].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptGranted"].ToString())].Text, "0");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptCancelled"].ToString())])) && !e.Row.Cells[Convert.ToInt32(hash_Table["n_OptCancelled"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_OptCancelled"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptCancelled"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptCancelled"].ToString())].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptCancelled"].ToString())].Text, "0");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvestCancelled"].ToString())])) && !e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvestCancelled"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvestCancelled"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvestCancelled"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvestCancelled"].ToString())].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvestCancelled"].ToString())].Text, "0");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedCancelled"].ToString())])) && !e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedCancelled"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedCancelled"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedCancelled"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedCancelled"].ToString())].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedCancelled"].ToString())].Text, "0");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptLapsed"].ToString())])) && !e.Row.Cells[Convert.ToInt32(hash_Table["n_OptLapsed"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_OptLapsed"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptLapsed"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptLapsed"].ToString())].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptLapsed"].ToString())].Text, "0");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptExercised"].ToString())])) && !e.Row.Cells[Convert.ToInt32(hash_Table["n_OptExercised"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_OptExercised"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptExercised"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptExercised"].ToString())].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptExercised"].ToString())].Text, "0");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvested"].ToString())])) && !e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvested"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvested"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvested"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvested"].ToString())].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvested"].ToString())].Text, "0");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedExercisable"].ToString())])) && !e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedExercisable"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedExercisable"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedExercisable"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedExercisable"].ToString())].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedExercisable"].ToString())].Text, "0");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[Convert.ToInt32(hash_Table["n_OutstandingOpt"].ToString())])) && !e.Row.Cells[Convert.ToInt32(hash_Table["n_OutstandingOpt"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_OutstandingOpt"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_OutstandingOpt"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OutstandingOpt"].ToString())].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_OutstandingOpt"].ToString())].Text, "0");
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_FairValue"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_FairValue"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_FairValue"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_FairValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_FairValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_IntrinsicValue"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_IntrinsicValue"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_IntrinsicValue"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_IntrinsicValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_IntrinsicValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_ExercisePrc"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_ExercisePrc"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_ExercisePrc"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_ExercisePrc"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_ExercisePrc"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_PreFairValue"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_PreFairValue"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreFairValue"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreFairValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreFairValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_PreIntrinsicValue"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_PreIntrinsicValue"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreIntrinsicValue"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreIntrinsicValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreIntrinsicValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_PreExercisePrc"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_PreExercisePrc"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreExercisePrc"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreExercisePrc"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreExercisePrc"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_PostFairValue"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_PostFairValue"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_PostFairValue"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PostFairValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PostFairValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_PostIntrinsicValue"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_PostIntrinsicValue"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_PostIntrinsicValue"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PostIntrinsicValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PostIntrinsicValue"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_PostExercisePrc"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_Table["n_PostExercisePrc"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_Table["n_PostExercisePrc"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PostExercisePrc"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_Table["n_PostExercisePrc"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                        }
                        #endregion

                        e.Row.Cells[Convert.ToInt32(hash_Table["n_AGRMID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_EmpID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_OperationID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_OperationDate"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_IS_MU_FV"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_IS_MU_IV"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_PreOptGranted"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreOptCancelled"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreOptUnvestCancelled"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreOptVestedCancelled"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreOptLapsed"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreOptExercised"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreOptUnvested"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreOptVestedExercisable"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreOutstandingOpt"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreFairValue"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreIntrinsicValue"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreExercisePrc"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreCostFV"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PreCostIV"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_PostOptGranted"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostOptCancelled"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostOptUnvestCancelled"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostOptVestedCancelled"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostOptLapsed"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostOptExercised"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostOptUnvested"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostOptVestedExercisable"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostOutstandingOpt"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostCostFV"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostCostIV"].ToString())].Visible =
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_CancellationDate"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_LapsedDate"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_ExercisedDate"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_IsLocked"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_IsJointModification"].ToString())].Visible = false;
                        
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_ViewVestDetails"].ToString())].Visible = userSessionInfo.ACC_CalculationMethod.Equals(1) ? false : true;

                        e.Row.Cells[Convert.ToInt32(hash_Table["n_GrantDate"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_Actionsgv"].ToString())].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_OptGranted"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_OptCancelled"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvestCancelled"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedCancelled"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_OptLapsed"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_OptExercised"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_OptUnvested"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_OptVestedExercisable"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_OutstandingOpt"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_ExercisePrc"].ToString())].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_PostFairValue"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostIntrinsicValue"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_PostExercisePrc"].ToString())].HorizontalAlign = HorizontalAlign.Right;

                        if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                        {
                            corporateActionUpdRevertUC.hdnCalcMethod.Value = "2";
                            e.Row.Cells[Convert.ToInt32(hash_Table["n_ViewVestDetails"].ToString())].HorizontalAlign = HorizontalAlign.Center;

                            e.Row.Cells[Convert.ToInt32(hash_Table["n_ViewVestDetails"].ToString())].Controls.Add(AddControl(corporateActionUpdRevertUC, "LinkButton", "lnkBtn_ViewVests", "View Vests", "Click to View Vesting Details", "ViewVestingDetails", "View Vests", e.Row.Cells[Convert.ToInt32(hash_Table["n_GrntOptID"].ToString())].Text, string.Empty, string.Empty, string.Empty));
                        }

                        e.Row.Cells[Convert.ToInt32(hash_Table["n_Actionsgv"].ToString())].Controls.Add(AddControl(corporateActionUpdRevertUC, "ImageButton", "img_Update", "~/View/App_Themes/images/plus.png", "Click to Update Corporate Action", "UpdateCorporateActionEffect", string.Empty, e.Row.Cells[Convert.ToInt32(hash_Table["n_AGRMID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_EmpID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_GrntOptID"].ToString())].Text, string.Empty));

                        e.Row.Cells[Convert.ToInt32(hash_Table["n_FairValue"].ToString())].Controls.Add(AddControl(corporateActionUpdRevertUC, "LinkButton", "lnkBtn_ViewPreFVCalc", string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreFairValue"].ToString())].Text) || e.Row.Cells[Convert.ToInt32(hash_Table["n_PreFairValue"].ToString())].Text.Equals("&nbsp;") ? e.Row.Cells[Convert.ToInt32(hash_Table["n_FairValue"].ToString())].Text : e.Row.Cells[Convert.ToInt32(hash_Table["n_PreFairValue"].ToString())].Text, "Click to View Fair Value Details", "ViewFVIVCalc", "PreCorpActFairValue", e.Row.Cells[Convert.ToInt32(hash_Table["n_GrntOptID"].ToString())].Text, string.Empty, string.Empty, string.Empty));
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_IntrinsicValue"].ToString())].Controls.Add(AddControl(corporateActionUpdRevertUC, "LinkButton", "lnkBtn_ViewPreIVCalc", string.IsNullOrEmpty(e.Row.Cells[Convert.ToInt32(hash_Table["n_PreIntrinsicValue"].ToString())].Text) || e.Row.Cells[Convert.ToInt32(hash_Table["n_PreIntrinsicValue"].ToString())].Text.Equals("&nbsp;") ? e.Row.Cells[Convert.ToInt32(hash_Table["n_IntrinsicValue"].ToString())].Text : e.Row.Cells[Convert.ToInt32(hash_Table["n_PreIntrinsicValue"].ToString())].Text, "Click to View Intrinsic Value Details", "ViewFVIVCalc", "PreCorpActIntrinsicValue", e.Row.Cells[Convert.ToInt32(hash_Table["n_GrntOptID"].ToString())].Text, string.Empty, string.Empty, string.Empty));

                        if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_PostFairValue"].ToString())].Text.Equals("&nbsp;"))
                            e.Row.Cells[Convert.ToInt32(hash_Table["n_PostFairValue"].ToString())].Controls.Add(AddControl(corporateActionUpdRevertUC, "LinkButton", "lnkBtn_ViewPostFVCalc", e.Row.Cells[Convert.ToInt32(hash_Table["n_PostFairValue"].ToString())].Text, "Click to View Fair Value Details", "ViewFVIVCalc", "PostCorpActFairValue", e.Row.Cells[Convert.ToInt32(hash_Table["n_GrntOptID"].ToString())].Text, ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[Convert.ToInt32(hash_Table["n_IS_MU_FV"].ToString())].ToString(), "Value Manually Updated", string.Empty));

                        if (!e.Row.Cells[Convert.ToInt32(hash_Table["n_PostIntrinsicValue"].ToString())].Text.Equals("&nbsp;"))
                            e.Row.Cells[Convert.ToInt32(hash_Table["n_PostIntrinsicValue"].ToString())].Controls.Add(AddControl(corporateActionUpdRevertUC, "LinkButton", "lnkBtn_ViewPostIVCalc", e.Row.Cells[Convert.ToInt32(hash_Table["n_PostIntrinsicValue"].ToString())].Text, "Click to View Intrinsic Value Details", "ViewFVIVCalc", "PostCorpActIntrinsicValue", e.Row.Cells[Convert.ToInt32(hash_Table["n_GrntOptID"].ToString())].Text, ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[Convert.ToInt32(hash_Table["n_IS_MU_IV"].ToString())].ToString(), "Value Manually Updated", string.Empty));

                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Add Controls to the GridView
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="s_ControlName">Name of the Control</param>
        /// <param name="s_ControlID">ID of the Control</param>
        /// <param name="s_ControlText">Text of the Control</param>
        /// <param name="s_Tooltip">Tooltip of the Control</param>
        /// <param name="s_JavascriptMethodName">Javascript Method Name of the Control</param>
        /// <param name="s_EventName">Event Name  of the Control</param>
        /// <param name="s_ParameterOne">ParameterOne to be passed to the Control</param>
        /// <param name="s_ParameterTwo">ParameterTwo to be passed to the Control</param>
        /// <param name="s_ParameterThree">ParameterThree to be passed to the Control</param>
        /// <param name="s_ParameterFour">ParameterFour to be passed to the Control</param>
        /// <returns>Control ImageButton/LinkButton</returns>
        private Control AddControl(CorporateActionUpdRevertUC corporateActionUpdRevertUC, string s_ControlName, string s_ControlID, string s_ControlText, string s_Tooltip, string s_JavascriptMethodName, string s_EventName, string s_ParameterOne, string s_ParameterTwo, string s_ParameterThree, string s_ParameterFour)
        {
            try
            {
                switch (s_ControlName)
                {
                    case "ImageButton":
                        ImageButton imageButton = new ImageButton();
                        imageButton.ToolTip = s_Tooltip;
                        imageButton.ImageUrl = s_ControlText;
                        imageButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                        EnableDisableControls(imageButton, corporateActionUpdRevertUC);

                        switch (s_JavascriptMethodName)
                        {
                            case "UpdateCorporateActionEffect":
                                imageButton.Attributes.Add("onclick", "return UpdateCorporateActionEffect('" + s_ParameterOne + "','" + s_ParameterTwo + "','" + s_ParameterThree + "')");
                                break;
                        }

                        return imageButton;

                    case "LinkButton":
                        LinkButton linkButton = new LinkButton();
                        linkButton.ID = s_ControlID + "_" + s_ParameterOne;
                        linkButton.Text = s_EventName.Equals("View Vests") ? s_EventName : s_ControlText;
                        linkButton.ToolTip = s_Tooltip;
                        linkButton.ClientIDMode = ClientIDMode.Static;
                        linkButton.Style.Add("cursor", "pointer");

                        switch (s_JavascriptMethodName)
                        {
                            case "ViewVestingDetails":
                                linkButton.Attributes.Add("onclick", "return ViewVestingDetails(this)");
                                break;

                            case "ViewFVIVCalc":
                                linkButton.ForeColor = s_ParameterTwo.Equals("True") ? Color.Green : Color.FromName("0");
                                linkButton.ToolTip = s_ParameterTwo.Equals("True") ? s_ParameterThree : s_Tooltip;
                                linkButton.Attributes.Add("onclick", "return ViewFVIVCalc('" + s_EventName + "','" + s_ParameterOne + "')");
                                linkButton.Click += new EventHandler(corporateActionUpdRevertUC.LinkButtonFVIVValue_Click);
                                break;
                        }

                        return linkButton;
                }

                return new Control();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add ChildGridView to view vesting details of grant in case of vestwise client
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="sender">View Vest LinkButton</param>
        /// <param name="e">e</param>
        /// <param name="s_GrantRegID">Grant Registration ID</param>
        /// <param name="s_GrantOptID">Grant Option ID</param>
        /// <param name="n_rowIndex">int n_rowIndex Parameter</param>
        /// <param name="n_VestIndex">int n_VestIndex Parameter</param>
        /// <param name="n_VestID">Vesting Period Number/ID</param>
        /// <param name="n_VestDate">Vesting Date</param>
        /// <param name="n_VestExpiryDate">Expiry Date</param>
        /// <param name="n_VestPercent">Vest Percent</param>
        internal void AddChildGridView(CorporateActionUpdRevertUC corporateActionUpdRevertUC, object sender, GridViewRowEventArgs e, string s_GrantRegID, string s_GrantOptID, ref int n_rowIndex, ref int n_VestIndex, ref int n_VestID, ref int n_VestDate, ref int n_VestExpiryDate, ref int n_VestPercent)
        {
            try
            {
                GridView gv_ParentGrid = (GridView)sender;

                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                {
                    NewTotalRow.Font.Bold = true;
                    NewTotalRow.CssClass = "gridItems  gvChildGrid";
                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                    using (TableCell HeaderCell = new TableCell())
                    {
                        HeaderCell.Attributes.Add("Class", "gvChildGrid");
                        HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        HeaderCell.Height = 10;
                        HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                        HeaderCell.ColumnSpan = 21;

                        using (GridView gv_ChildGrid = new GridView())
                        {
                            gv_ChildGrid.CssClass = "Grid";
                            gv_ChildGrid.RowStyle.CssClass = "gridItems";
                            gv_ChildGrid.CellPadding = 3;
                            gv_ChildGrid.CellSpacing = 0;
                            gv_ChildGrid.HeaderStyle.CssClass = "HeaderStyle";
                            gv_ChildGrid.ID = "gv_ChildGrid" + n_rowIndex;
                            n_VestIndex = n_VestID = n_VestDate = n_VestExpiryDate = n_VestPercent = 0;

                            gv_ChildGrid.RowDataBound += corporateActionUpdRevertUC.gv_ChildGrid_RowDataBound;
                            gv_ChildGrid.DataSource = ac_CorporateActionAdjustment.dt_UpdateCorpActAdjVestwise.DefaultView.ToTable("DT", true, new string[] { "Grant Registration ID", "Vesting Period Number", "Vesting Date", "Expiry Date", "Vest Percent (%)", "Currency", "Vest_Fair Value", "Vest_Intrinsic Value", "Grant Option ID" }).Copy().Select("[Grant Option ID]='" + s_GrantOptID + "'" + "and [Grant Registration ID]='" + s_GrantRegID + "'").CopyToDataTable();
                            gv_ChildGrid.DataBind();

                            HeaderCell.Controls.Add(gv_ChildGrid);
                            NewTotalRow.Cells.Add(HeaderCell);
                            gv_ParentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + n_rowIndex, NewTotalRow);
                            n_rowIndex++;
                        }
                    }
                }

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Row Data Bound Event of gv_ChildGrid GridView
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="e">e</param>
        /// <param name="n_VestIndex">int n_VestIndex Parameter</param>
        /// <param name="n_VestID">int Vesting Period Number/ID Parameter</param>
        /// <param name="n_VestDate">int Vesting Date Parameter</param>
        /// <param name="n_VestExpiryDate">int Expiry Date Parameter</param>
        /// <param name="n_VestPercent">int Vest Percent Parameter</param>
        /// <param name="n_VestFairValue">int Vest Fair Value Parameter</param>
        /// <param name="n_VestIntrinsicValue">int Vest Intrinsic Value Parameter</param>
        /// <param name="n_VestGrtOptID">int Vest Grant Option ID Parameter</param>
        internal void gv_ChildGrid_RowDataBound(CorporateActionUpdRevertUC corporateActionUpdRevertUC, GridViewRowEventArgs e, ref int n_VestIndex, ref int n_VestID, ref int n_VestDate, ref int n_VestExpiryDate, ref int n_VestPercent, ref int n_VestFairValue, ref int n_VestIntrinsicValue, ref int n_VestGrtOptID)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "VESTING PERIOD NUMBER":
                                    n_VestID = n_VestIndex;
                                    break;

                                case "VESTING DATE":
                                    n_VestDate = n_VestIndex;
                                    break;

                                case "EXPIRY DATE":
                                    n_VestExpiryDate = n_VestIndex;
                                    break;

                                case "VEST PERCENT (%)":
                                    n_VestPercent = n_VestIndex;
                                    break;

                                case "VEST_FAIR VALUE":
                                    perColumn.Text = "Fair Value per vest";
                                    n_VestFairValue = n_VestIndex;
                                    break;

                                case "VEST_INTRINSIC VALUE":
                                    perColumn.Text = "Intrinsic Value per vest";
                                    n_VestIntrinsicValue = n_VestIndex;
                                    break;

                                case "GRANT OPTION ID":
                                    n_VestGrtOptID = n_VestIndex;
                                    perColumn.Visible = false;
                                    break;
                            }

                            n_VestIndex = n_VestIndex + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            e.Row.Cells[n_VestPercent].Text = e.Row.Cells[n_VestPercent].Text.Equals("&nbsp;") ? string.Empty : Convert.ToDouble(e.Row.Cells[n_VestPercent].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_VestPercent].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_VestPercent].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            e.Row.Cells[n_VestPercent].HorizontalAlign = HorizontalAlign.Right;

                            if (!e.Row.Cells[n_VestFairValue].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_VestFairValue].Text = Convert.ToDouble(e.Row.Cells[n_VestFairValue].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_VestFairValue].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_VestFairValue].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_VestFairValue].HorizontalAlign = HorizontalAlign.Right;
                            }

                            if (!e.Row.Cells[n_VestIntrinsicValue].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_VestIntrinsicValue].Text = Convert.ToDouble(e.Row.Cells[n_VestIntrinsicValue].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_VestIntrinsicValue].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_VestIntrinsicValue].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_VestIntrinsicValue].HorizontalAlign = HorizontalAlign.Right;
                            }
                        }
                        #endregion

                        e.Row.Cells[n_VestGrtOptID].Visible = false;

                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  Data Bound event of gvCAAUpdateCorpAction GridView
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="sender">gvCAAUpdateCorpAction GridView</param>
        /// <param name="e">e</param>
        internal void gvCAAUpdateCorpAction_DataBound(CorporateActionUpdRevertUC corporateActionUpdRevertUC, object sender, EventArgs e)
        {
            try
            {
                using (GridViewRow gvHeaderRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal))
                {
                    TableHeaderCell tbHeaderCell = new TableHeaderCell();
                    tbHeaderCell.Text = "";
                    tbHeaderCell.ColumnSpan = userSessionInfo.ACC_CalculationMethod.Equals(1) ? 7 : 8;
                    gvHeaderRow.Controls.Add(tbHeaderCell);

                    tbHeaderCell = new TableHeaderCell();
                    tbHeaderCell.Text = "Data Updated As On : " + (ac_CorporateActionAdjustment.dt_DataUpdatedOn != null ? ac_CorporateActionAdjustment.dt_DataUpdatedOn.Rows[0]["Data Updated As on"].ToString() : corporateActionUpdRevertUC.lblCAAEffectDateVal.Text);
                    tbHeaderCell.ColumnSpan = 9;
                    tbHeaderCell.Attributes.Add("style", "text-align:left");
                    gvHeaderRow.Controls.Add(tbHeaderCell);

                    tbHeaderCell = new TableHeaderCell();
                    tbHeaderCell.Text = "Pre-Corporate Action";
                    tbHeaderCell.ColumnSpan = 3;
                    tbHeaderCell.Attributes.Add("style", "text-align:left");
                    gvHeaderRow.Controls.Add(tbHeaderCell);

                    tbHeaderCell = new TableHeaderCell();
                    tbHeaderCell.Text = "Post-Corporate Action";
                    tbHeaderCell.ColumnSpan = 3;
                    tbHeaderCell.Attributes.Add("style", "text-align:left");
                    gvHeaderRow.Controls.Add(tbHeaderCell);

                    if (corporateActionUpdRevertUC.gvCAAUpdateCorpAction.HeaderRow != null)
                    {
                        corporateActionUpdRevertUC.gvCAAUpdateCorpAction.HeaderRow.Parent.Controls.AddAt(0, gvHeaderRow);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Page Index Change Event of gvCAAUpdateCorpAction GridView
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="e">e</param>
        internal void gvCAAUpdateCorpAction_PageIndexChanging(CorporateActionUpdRevertUC corporateActionUpdRevertUC, GridViewPageEventArgs e)
        {
            try
            {
                corporateActionUpdRevertUC.gvCAAUpdateCorpAction.PageIndex = e.NewPageIndex;

                /* Bind the data to the gvCAAUpdateCorpAction GridView */
                BindgvCAAUpdateCorpActionGridView(corporateActionUpdRevertUC);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// LinkButton Fair Value Click Event to Bind Fair Value FV PopUp window
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="s_EventName">string EventName whether it Pre-Corporate Action or Post-Corporate Action</param>
        /// <param name="s_GrantOptID">string Grant Option ID</param>
        internal void LinkButtonFVIVValue_Click(CorporateActionUpdRevertUC corporateActionUpdRevertUC, string s_EventName, string s_GrantOptID)
        {
            try
            {
                using (DataTable dt_CorpActFV = new DataTable())
                {
                    DataRow[] dr_Data = ac_CorporateActionAdjustment.dt_UpdateCorpActAdj.Select("[Grant Option ID] = '" + s_GrantOptID + "'");

                    if (s_EventName.Equals("PreCorpActFairValue") || s_EventName.Equals("PreCorpActIntrinsicValue"))
                    {
                        corporateActionUpdRevertUC.lblCAAPopUpPreCorpActFVIVTitle.Style.Add("display", "block");
                        corporateActionUpdRevertUC.lblCAAPopUpPostCorpActFVIVTitle.Style.Add("display", "none");

                        ac_CorporateActionAdjustment.s_PopUpEventName = "PreCorpAction";

                        dt_CorpActFV.Columns.Add(" ", typeof(string));
                        dt_CorpActFV.Columns.Add("Pre-Corporate Action", typeof(decimal));

                        dt_CorpActFV.Rows.Add("Options Granted", string.IsNullOrEmpty(dr_Data[0]["Pre_Options Granted"].ToString()) || dr_Data[0]["Pre_Options Granted"].ToString().Equals("&nbsp;") ? string.IsNullOrEmpty(dr_Data[0]["Options Granted"].ToString()) || dr_Data[0]["Options Granted"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Options Granted"].ToString()) : Convert.ToDecimal(dr_Data[0]["Pre_Options Granted"].ToString()));
                        dt_CorpActFV.Rows.Add("Options Cancelled", string.IsNullOrEmpty(dr_Data[0]["Pre_Options Cancelled"].ToString()) || dr_Data[0]["Pre_Options Cancelled"].ToString().Equals("&nbsp;") ? string.IsNullOrEmpty(dr_Data[0]["Options Cancelled"].ToString()) || dr_Data[0]["Options Cancelled"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Options Cancelled"].ToString()) : Convert.ToDecimal(dr_Data[0]["Pre_Options Cancelled"].ToString()));
                        dt_CorpActFV.Rows.Add("Options Exercised", string.IsNullOrEmpty(dr_Data[0]["Pre_Options Exercised"].ToString()) || dr_Data[0]["Pre_Options Exercised"].ToString().Equals("&nbsp;") ? string.IsNullOrEmpty(dr_Data[0]["Options Exercised"].ToString()) || dr_Data[0]["Options Exercised"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Options Exercised"].ToString()) : Convert.ToDecimal(dr_Data[0]["Pre_Options Exercised"].ToString()));
                        dt_CorpActFV.Rows.Add("Options Lapsed", string.IsNullOrEmpty(dr_Data[0]["Pre_Options Lapsed"].ToString()) || dr_Data[0]["Pre_Options Lapsed"].ToString().Equals("&nbsp;") ? string.IsNullOrEmpty(dr_Data[0]["Options Lapsed"].ToString()) || dr_Data[0]["Options Lapsed"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Options Lapsed"].ToString()) : Convert.ToDecimal(dr_Data[0]["Pre_Options Lapsed"].ToString()));
                        dt_CorpActFV.Rows.Add("Live Options for Compensation Cost", string.IsNullOrEmpty(dr_Data[0]["Pre_Options Vested And Exercisable"].ToString()) || dr_Data[0]["Pre_Options Vested And Exercisable"].ToString().Equals("&nbsp;") ? string.IsNullOrEmpty(dr_Data[0]["Options Vested And Exercisable"].ToString()) || dr_Data[0]["Options Vested And Exercisable"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Options Vested And Exercisable"].ToString()) : Convert.ToDecimal(dr_Data[0]["Pre_Options Vested And Exercisable"].ToString()));
                    }
                    else
                    {
                        corporateActionUpdRevertUC.lblCAAPopUpPreCorpActFVIVTitle.Style.Add("display", "none");
                        corporateActionUpdRevertUC.lblCAAPopUpPostCorpActFVIVTitle.Style.Add("display", "block");

                        ac_CorporateActionAdjustment.s_PopUpEventName = "PostCorpAction";

                        dt_CorpActFV.Columns.Add(" ", typeof(string));
                        dt_CorpActFV.Columns.Add("Pre-Corporate Action", typeof(decimal));
                        dt_CorpActFV.Columns.Add("Post-Corporate Action", typeof(decimal));

                        dt_CorpActFV.Rows.Add("Options Granted", string.IsNullOrEmpty(dr_Data[0]["Pre_Options Granted"].ToString()) || dr_Data[0]["Pre_Options Granted"].ToString().Equals("&nbsp;") ? string.IsNullOrEmpty(dr_Data[0]["Options Granted"].ToString()) || dr_Data[0]["Options Granted"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Options Granted"].ToString()) : Convert.ToDecimal(dr_Data[0]["Pre_Options Granted"].ToString()), string.IsNullOrEmpty(dr_Data[0]["Post_Options Granted"].ToString()) || dr_Data[0]["Post_Options Granted"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Post_Options Granted"].ToString()));
                        dt_CorpActFV.Rows.Add("Options Cancelled", string.IsNullOrEmpty(dr_Data[0]["Pre_Options Cancelled"].ToString()) || dr_Data[0]["Pre_Options Cancelled"].ToString().Equals("&nbsp;") ? string.IsNullOrEmpty(dr_Data[0]["Options Cancelled"].ToString()) || dr_Data[0]["Options Cancelled"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Options Cancelled"].ToString()) : Convert.ToDecimal(dr_Data[0]["Pre_Options Cancelled"].ToString()), string.IsNullOrEmpty(dr_Data[0]["Post_Options Cancelled"].ToString()) || dr_Data[0]["Post_Options Cancelled"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Post_Options Cancelled"].ToString()));
                        dt_CorpActFV.Rows.Add("Options Exercised", string.IsNullOrEmpty(dr_Data[0]["Pre_Options Exercised"].ToString()) || dr_Data[0]["Pre_Options Exercised"].ToString().Equals("&nbsp;") ? string.IsNullOrEmpty(dr_Data[0]["Options Exercised"].ToString()) || dr_Data[0]["Options Exercised"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Options Exercised"].ToString()) : Convert.ToDecimal(dr_Data[0]["Pre_Options Exercised"].ToString()), string.IsNullOrEmpty(dr_Data[0]["Post_Options Exercised"].ToString()) || dr_Data[0]["Post_Options Exercised"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Post_Options Exercised"].ToString()));
                        dt_CorpActFV.Rows.Add("Options Lapsed", string.IsNullOrEmpty(dr_Data[0]["Pre_Options Lapsed"].ToString()) || dr_Data[0]["Pre_Options Lapsed"].ToString().Equals("&nbsp;") ? string.IsNullOrEmpty(dr_Data[0]["Options Lapsed"].ToString()) || dr_Data[0]["Options Lapsed"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Options Lapsed"].ToString()) : Convert.ToDecimal(dr_Data[0]["Pre_Options Lapsed"].ToString()), string.IsNullOrEmpty(dr_Data[0]["Post_Options Lapsed"].ToString()) || dr_Data[0]["Post_Options Lapsed"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Post_Options Lapsed"].ToString()));
                        dt_CorpActFV.Rows.Add("Live Options for Compensation Cost", string.IsNullOrEmpty(dr_Data[0]["Pre_Options Vested And Exercisable"].ToString()) || dr_Data[0]["Pre_Options Vested And Exercisable"].ToString().Equals("&nbsp;") ? string.IsNullOrEmpty(dr_Data[0]["Options Vested And Exercisable"].ToString()) || dr_Data[0]["Options Vested And Exercisable"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Options Vested And Exercisable"].ToString()) : Convert.ToDecimal(dr_Data[0]["Pre_Options Vested And Exercisable"].ToString()), string.IsNullOrEmpty(dr_Data[0]["Post_Options Vested And Exercisable"].ToString()) || dr_Data[0]["Post_Options Vested And Exercisable"].ToString().Equals("&nbsp;") ? Convert.ToDecimal("0") : Convert.ToDecimal(dr_Data[0]["Post_Options Vested And Exercisable"].ToString()));
                    }

                    using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                    {
                        switch (s_EventName)
                        {
                            case "PreCorpActFairValue":
                                ac_CorporateActionAdjustment.s_PreCorpActFVIV = "Pre-Corporate Action Fair Value";
                                ac_CorporateActionAdjustment.s_PreCorpActFVIVVal = string.IsNullOrEmpty(dr_Data[0]["Fair Value"].ToString()) ? "0" : Convert.ToDouble(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Fair Value"].ToString()), 2)) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Fair Value"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Fair Value"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());

                                ac_CorporateActionAdjustment.s_ComCostPreCorpActByFVIV = "Compensation Cost Pre-Corporate Action";
                                ac_CorporateActionAdjustment.s_ComCostPreCorpActByFVIVVal = string.IsNullOrEmpty(dr_Data[0]["Pre_Comp CostFV"].ToString()) || dr_Data[0]["Pre_Comp CostFV"].ToString().Equals("&nbsp;") ? "0" : Convert.ToDouble(Decimal.Round(Convert.ToDecimal(Convert.ToDecimal(dt_CorpActFV.Rows[4]["Pre-Corporate Action"].ToString()) * Convert.ToDecimal(ac_CorporateActionAdjustment.s_PreCorpActFVIVVal)), 2)) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Convert.ToString(Convert.ToDecimal(dt_CorpActFV.Rows[4]["Pre-Corporate Action"].ToString()) * Convert.ToDecimal(ac_CorporateActionAdjustment.s_PreCorpActFVIVVal)), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(Convert.ToDecimal(dt_CorpActFV.Rows[4]["Pre-Corporate Action"].ToString()) * Convert.ToDecimal(ac_CorporateActionAdjustment.s_PreCorpActFVIVVal)), 2).ToString(), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());

                                break;

                            case "PreCorpActIntrinsicValue":
                                ac_CorporateActionAdjustment.s_PreCorpActFVIV = "Pre-Corporate Action Intrinsic Value";
                                ac_CorporateActionAdjustment.s_PreCorpActFVIVVal = string.IsNullOrEmpty(dr_Data[0]["Intrinsic Value"].ToString()) ? "0" : Convert.ToDouble(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Intrinsic Value"].ToString()), 2)) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Intrinsic Value"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Intrinsic Value"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());

                                ac_CorporateActionAdjustment.s_ComCostPreCorpActByFVIV = "Compensation Cost Pre-Corporate Action";
                                ac_CorporateActionAdjustment.s_ComCostPreCorpActByFVIVVal = string.IsNullOrEmpty(dr_Data[0]["Pre_Comp CostIV"].ToString()) || dr_Data[0]["Pre_Comp CostIV"].ToString().Equals("&nbsp;") ? "0" : Convert.ToDouble(Decimal.Round(Convert.ToDecimal(Convert.ToDecimal(dt_CorpActFV.Rows[4]["Pre-Corporate Action"].ToString()) * Convert.ToDecimal(ac_CorporateActionAdjustment.s_PreCorpActFVIVVal)), 2)) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(Convert.ToDecimal(dt_CorpActFV.Rows[4]["Pre-Corporate Action"].ToString()) * Convert.ToDecimal(ac_CorporateActionAdjustment.s_PreCorpActFVIVVal)), 2).ToString(), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(Convert.ToDecimal(dt_CorpActFV.Rows[4]["Pre-Corporate Action"].ToString()) * Convert.ToDecimal(ac_CorporateActionAdjustment.s_PreCorpActFVIVVal)), 2).ToString(), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());

                                break;

                            case "PostCorpActFairValue":
                                ac_CorporateActionAdjustment.s_PostCorpActFVIV = "Fair Value";
                                ac_CorporateActionAdjustment.s_PostCorpActFVIVVal = string.IsNullOrEmpty(dr_Data[0]["Post_Fair Value"].ToString()) || dr_Data[0]["Post_Fair Value"].ToString().Equals("&nbsp;") ? "0" : Convert.ToDouble(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Fair Value"].ToString()), 2)) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Fair Value"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Fair Value"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());

                                ac_CorporateActionAdjustment.s_ComCostPostCorpActByFVIV = "Compensation Cost By Fair Value";
                                ac_CorporateActionAdjustment.s_ComCostPostCorpActByFVIVVal = string.IsNullOrEmpty(dr_Data[0]["Post_Comp CostFV"].ToString()) || dr_Data[0]["Post_Comp CostFV"].ToString().Equals("&nbsp;") ? "0" : Convert.ToDouble(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Comp CostFV"].ToString()), 2)) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Comp CostFV"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Comp CostFV"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());

                                break;

                            case "PostCorpActIntrinsicValue":
                                ac_CorporateActionAdjustment.s_PostCorpActFVIV = "Intrinsic Value";
                                ac_CorporateActionAdjustment.s_PostCorpActFVIVVal = string.IsNullOrEmpty(dr_Data[0]["Post_Intrinsic Value"].ToString()) || dr_Data[0]["Post_Intrinsic Value"].ToString().Equals("&nbsp;") ? "0" : Convert.ToDouble(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Intrinsic Value"].ToString()), 2)) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Intrinsic Value"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Intrinsic Value"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());

                                ac_CorporateActionAdjustment.s_ComCostPostCorpActByFVIV = "Compensation Cost By Intrinsic Value";
                                ac_CorporateActionAdjustment.s_ComCostPostCorpActByFVIVVal = string.IsNullOrEmpty(dr_Data[0]["Post_Comp CostIV"].ToString()) || dr_Data[0]["Post_Comp CostIV"].ToString().Equals("&nbsp;") ? "0" : Convert.ToDouble(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Comp CostIV"].ToString()), 2)) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Comp CostIV"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(Decimal.Round(Convert.ToDecimal(dr_Data[0]["Post_Comp CostIV"].ToString()), 2).ToString(), DecimalLimitTable.Select("ADVSID = 10")[0]["ROUNDING_PLACE_VALUE"].ToString());

                                break;
                        }
                    }

                    corporateActionUpdRevertUC.gvPreCorpActFVIV.DataSource = dt_CorpActFV;
                    corporateActionUpdRevertUC.gvPreCorpActFVIV.DataBind();

                    corporateActionUpdRevertUC.hdnOpenPopUp.Value = "1";
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Row Data Bound Event Of gvPreCorpActFV GridView displayed in the PreCorporateAction FV PopUp window
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="sender">gvPreCorpActFV GridView</param>
        /// <param name="e">e</param>
        /// <param name="n_PopUpIndex">int parameter for PopUp</param>
        /// <param name="n_PreCorpAct">int parameter for Pre-Corporate Action</param>
        /// <param name="n_PostCorpAct">int parameter for Post-Corporate Action</param>
        internal void gvPreCorpActFVIV_RowDataBound(CorporateActionUpdRevertUC corporateActionUpdRevertUC, object sender, GridViewRowEventArgs e, ref int n_PopUpIndex, ref int n_PreCorpAct, ref int n_PostCorpAct)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "PRE-CORPORATE ACTION":
                                    n_PreCorpAct = n_PopUpIndex;
                                    break;

                                case "POST-CORPORATE ACTION":
                                    n_PostCorpAct = n_PopUpIndex;
                                    break;
                            }

                            n_PopUpIndex = n_PopUpIndex + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[n_PreCorpAct].Text)) || !e.Row.Cells[n_PreCorpAct].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_PreCorpAct].Text = Convert.ToDouble(e.Row.Cells[n_PreCorpAct].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_PreCorpAct].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[n_PreCorpAct].Text, "0");
                            }

                            if (n_PostCorpAct != 0 && (!string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[n_PostCorpAct].Text)) || !e.Row.Cells[n_PostCorpAct].Text.Equals("&nbsp;")))
                            {
                                e.Row.Cells[n_PostCorpAct].Text = Convert.ToDouble(e.Row.Cells[n_PostCorpAct].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_PostCorpAct].Text, "0"), "0") : CommonModel.GetRoundedValue(e.Row.Cells[n_PostCorpAct].Text, "0");
                            }
                        }
                        #endregion

                        e.Row.Cells[n_PreCorpAct].HorizontalAlign = HorizontalAlign.Right;

                        if (ac_CorporateActionAdjustment.s_PopUpEventName.Equals("PostCorpAction"))
                            e.Row.Cells[n_PostCorpAct].HorizontalAlign = HorizontalAlign.Right;

                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Data Bound Event Of gvPreCorpActFV GridView displayed in the PreCorporateAction FV PopUp window 
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="sender">gvPreCorpActFV GridView</param>
        /// <param name="e">e</param>
        internal void gvPreCorpActFVIV_DataBound(CorporateActionUpdRevertUC corporateActionUpdRevertUC, object sender, EventArgs e)
        {
            try
            {
                TableCell tb_Cell = new TableCell();

                if (ac_CorporateActionAdjustment.s_PopUpEventName.Equals("PreCorpAction"))
                {
                    using (GridViewRow gv_Row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
                    {
                        tb_Cell.Text = ac_CorporateActionAdjustment.s_PreCorpActFVIV;
                        tb_Cell.ColumnSpan = 1;
                        tb_Cell.Font.Bold = true;
                        tb_Cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        tb_Cell.HorizontalAlign = HorizontalAlign.Left;
                        gv_Row.Controls.Add(tb_Cell);

                        tb_Cell = new TableCell();

                        tb_Cell.Text = ac_CorporateActionAdjustment.s_PreCorpActFVIVVal;

                        tb_Cell.Font.Bold = true;
                        tb_Cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        tb_Cell.HorizontalAlign = HorizontalAlign.Right;
                        gv_Row.Controls.Add(tb_Cell);

                        corporateActionUpdRevertUC.gvPreCorpActFVIV.HeaderRow.Parent.Controls.AddAt(corporateActionUpdRevertUC.gvPreCorpActFVIV.Rows.Count + 2, gv_Row);
                    }

                    using (GridViewRow gv_Row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
                    {
                        tb_Cell = new TableCell();

                        tb_Cell.Text = ac_CorporateActionAdjustment.s_ComCostPreCorpActByFVIV;
                        tb_Cell.ColumnSpan = 1;
                        tb_Cell.Font.Bold = true;
                        tb_Cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        tb_Cell.HorizontalAlign = HorizontalAlign.Left;
                        gv_Row.Controls.Add(tb_Cell);

                        tb_Cell = new TableCell();

                        tb_Cell.Text = ac_CorporateActionAdjustment.s_ComCostPreCorpActByFVIVVal;
                        tb_Cell.Font.Bold = true;
                        tb_Cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        tb_Cell.HorizontalAlign = HorizontalAlign.Right;
                        gv_Row.Controls.Add(tb_Cell);

                        corporateActionUpdRevertUC.gvPreCorpActFVIV.HeaderRow.Parent.Controls.AddAt(corporateActionUpdRevertUC.gvPreCorpActFVIV.Rows.Count + 3, gv_Row);
                    }
                }
                else
                {
                    using (GridViewRow gv_Row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
                    {
                        tb_Cell.Text = ac_CorporateActionAdjustment.s_PostCorpActFVIV;
                        tb_Cell.ColumnSpan = 2;
                        tb_Cell.Font.Bold = true;
                        tb_Cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        tb_Cell.HorizontalAlign = HorizontalAlign.Left;
                        gv_Row.Controls.Add(tb_Cell);

                        tb_Cell = new TableCell();

                        tb_Cell.Text = ac_CorporateActionAdjustment.s_PostCorpActFVIVVal;

                        tb_Cell.Font.Bold = true;
                        tb_Cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        tb_Cell.HorizontalAlign = HorizontalAlign.Right;
                        gv_Row.Controls.Add(tb_Cell);

                        corporateActionUpdRevertUC.gvPreCorpActFVIV.HeaderRow.Parent.Controls.AddAt(corporateActionUpdRevertUC.gvPreCorpActFVIV.Rows.Count + 2, gv_Row);
                    }

                    using (GridViewRow gv_Row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
                    {
                        tb_Cell = new TableCell();

                        tb_Cell.Text = ac_CorporateActionAdjustment.s_ComCostPostCorpActByFVIV;
                        tb_Cell.ColumnSpan = 2;
                        tb_Cell.Font.Bold = true;
                        tb_Cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        tb_Cell.HorizontalAlign = HorizontalAlign.Left;
                        gv_Row.Controls.Add(tb_Cell);

                        tb_Cell = new TableCell();

                        tb_Cell.Text = ac_CorporateActionAdjustment.s_ComCostPostCorpActByFVIVVal;
                        tb_Cell.Font.Bold = true;
                        tb_Cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        tb_Cell.HorizontalAlign = HorizontalAlign.Right;
                        gv_Row.Controls.Add(tb_Cell);

                        corporateActionUpdRevertUC.gvPreCorpActFVIV.HeaderRow.Parent.Controls.AddAt(corporateActionUpdRevertUC.gvPreCorpActFVIV.Rows.Count + 3, gv_Row);
                    }
                }

                tb_Cell.Dispose();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Apply Button Click Event. This method is used to Apply the Corpoarte Action to the Data
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <returns>Apply Corporate Action Result n_Result</returns>
        internal int btnCAAApply_Click(CorporateActionUpdRevertUC corporateActionUpdRevertUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_CorporateActionAdjustment;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.PopulateControls = "Apply_Revert_Corporate_Action_To_Data";
                    accountingProperties.Action = "APPLY";
                    accountingProperties.Effective_Date = Convert.ToDateTime(corporateActionUpdRevertUC.hdnEffectiveDate.Value);
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;

                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    if (accountingCRUDProperties.a_result.Equals(1))
                        SendMailToUser(corporateActionUpdRevertUC, File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"Mails\AppliedCorporateAction.html"));

                    return accountingCRUDProperties.a_result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Send the Mail to the User after the Corporate Action has been applied to the Data
        /// </summary>
        /// <param name="corporateActionUpdRevertUC">corporateActionUpdRevertUC Page Object</param>
        /// <param name="s_MailBody">s_MailBody Mail Body</param>
        private void SendMailToUser(CorporateActionUpdRevertUC corporateActionUpdRevertUC, string s_MailBody)
        {
            try
            {
                if (!string.IsNullOrEmpty(s_MailBody))
                {
                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        emailProperties.s_MailBody = s_MailBody.Replace("@UserName", userSessionInfo.ACC_UserName).Replace("@CompanyName", userSessionInfo.ACC_CompanyName).Replace("@EffectiveDate", corporateActionUpdRevertUC.lblCAAEffectDateVal.Text).Replace("@CorporateActionType", corporateActionUpdRevertUC.lblCAACorpActVal.Text).Replace("@Ratio", corporateActionUpdRevertUC.lblCAACorpActRatioVal.Text).Replace("@ValCustSupportID", ConfigurationManager.AppSettings["ValCustSupport"]);
                        emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                        emailProperties.b_IsBodyHtml = true;
                        emailProperties.s_MailTo = userSessionInfo.ACC_EmailID;
                        emailProperties.s_MailCC = "";
                        emailProperties.s_MailBCC = "";
                        emailProperties.s_MailSubject = "Corporate Action Applied";

                        genericServiceClient.SaveSendMail(emailProperties);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CorporateActionUpdRevertUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}