﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting.UserControl;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Model used for OptionsDetailsProperties
    /// </summary>
    public class OptionsDetailsProperties
    {
        /// <summary>
        /// used to set Document Name
        /// </summary>
        public string s_DocName { get; set; }

        /// <summary>
        /// used to set Updated On date
        /// </summary>
        public string s_UpdatedOn { get; set; }
    }

    /// <summary>
    /// Model used for OptionsDetails
    /// </summary>
    public class OptionsDetailsModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Update all button name
        /// </summary>
        public static string s_UpdateAll = string.Empty;

        /// <summary>
        /// Get is report locked 
        /// </summary>
        public string s_IsLocked = string.Empty;

        #region Default constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public OptionsDetailsModel()
        {
            if (ac_GrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_GrantDetails);
                ac_GrantDetails = (CommonModel.AC_GrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_GrantDetails];
            }

            if (ac_SearchGrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_SearchGrantDetails);
                ac_SearchGrantDetails = (CommonModel.AC_SearchGrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_SearchGrantDetails];
            }
        }
        #endregion

        #region Common Bind Methods
        /// <summary>
        /// This method is used to Bind the all controls
        /// </summary>
        /// <param name="optionDetailsUC">Option Details user conrol page object</param>
        internal void PopulateAllControls(OptionDetailsUC optionDetailsUC)
        {
            try
            {
                BindUI(optionDetailsUC);
            }
            catch
            {
                throw;
            }
        }



        /// <summary>
        /// This method is used to Bind UI controls
        /// </summary>
        /// <param name="optionDetailsUC">Option Details user conrol page object</param>
        internal void BindUI(OptionDetailsUC optionDetailsUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_GrantDetails.dt_OptionDetailsUI == null || ac_GrantDetails.dt_OptionDetailsUI.Rows.Count.Equals(0))
                    {
                        ac_GrantDetails.dt_OptionDetailsUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10_UI);
                    }

                    s_UpdateAll = Convert.ToString(ac_GrantDetails.dt_OptionDetailsUI.Select("LabelID = 'btnUpdateAll'")[0]["LabelToolTip"]);

                    if ((ac_GrantDetails.dt_OptionDetailsUI != null) && (ac_GrantDetails.dt_OptionDetailsUI.Rows.Count > 0))
                    {
                        foreach (Control control in optionDetailsUC.dvMain.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_GrantDetails.dt_OptionDetailsUI, (Label)control);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_GrantDetails.dt_OptionDetailsUI, (TextBox)control);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_GrantDetails.dt_OptionDetailsUI, (Button)control);
                                    break;

                                case CommonConstantModel.s_wcCheckbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeCheckBox, ac_GrantDetails.dt_OptionDetailsUI, (CheckBox)control);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, ac_GrantDetails.dt_OptionDetailsUI, (RadioButton)control);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, ac_GrantDetails.dt_OptionDetailsUI, (BaseValidator)control);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, ac_GrantDetails.dt_OptionDetailsUI, (BaseValidator)control);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_GrantDetails.dt_OptionDetailsUI, (GridView)control);
                                    break;
                            }

                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="control">control</param>
        private void BindPropertiesToControl(string s_cntrlType, DataTable Dt_Get_L10N_UI, Control control)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    Label label = (Label)control;
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    Button button = (Button)control;
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeCheckBox:
                    CheckBox checkBox = (CheckBox)control;
                    checkBox.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelName"]);
                    checkBox.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRadioButton:
                    RadioButton radioButton = (RadioButton)control;
                    radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                    radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    RequiredFieldValidator ReqValidator = (RequiredFieldValidator)control;
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegularExpressionValidator RegExpValidator = (RegularExpressionValidator)control;
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    break;

                case CommonConstantModel.s_cntrlTypeTextBox:
                    break;
            }
        }

        #endregion

        #region Bind DropDown
        /// <summary>
        /// This method is used to get Updated As On Data
        /// </summary>
        /// <param name="optionDetailsUC"></param>
        public void BindDropDown(OptionDetailsUC optionDetailsUC)
        {
            GetData(optionDetailsUC);
            GetUploadedData(optionDetailsUC);
            DataTable dt_OptionDetailsDataTemp = new DataTable();

            if (!string.IsNullOrEmpty(optionDetailsUC.txtReportDate.Text) && !optionDetailsUC.txtReportDate.Text.Equals("dd/mmm/yyyy"))
            {
                dt_OptionDetailsDataTemp = ac_GrantDetails.dt_OptionDetailsData.Select("[Grant Date] <= '" + Convert.ToDateTime(optionDetailsUC.txtReportDate.Text).ToString("dd-MM-yyyy") + "'").Count() > 0 ? ac_GrantDetails.dt_OptionDetailsData.Select("[Grant Date] <= '" + Convert.ToDateTime(optionDetailsUC.txtReportDate.Text).ToString("dd-MM-yyyy") + "'").CopyToDataTable() : ac_GrantDetails.dt_OptionDetailsData;
            }

            if (dt_OptionDetailsDataTemp != null && dt_OptionDetailsDataTemp.Rows.Count > 0)
            {
                //Bind Scheme Name drop-down 
                optionDetailsUC.ddlSelectSchemeName.DataSource = (from b in dt_OptionDetailsDataTemp.AsEnumerable()
                                                                  where b.Field<string>("Scheme Name") != null
                                                                  select b.Field<string>("Scheme Name")).Distinct();
                optionDetailsUC.ddlSelectSchemeName.DataBind();

                //Bind GrantID drop-down 
                optionDetailsUC.ddlSelectGrantID.DataSource = (from b in dt_OptionDetailsDataTemp.AsEnumerable()
                                                               where b.Field<string>("Grant Registration ID") != null
                                                               select b.Field<string>("Grant Registration ID")).Distinct();
                optionDetailsUC.ddlSelectGrantID.DataBind();

                //Bind EmployeeName drop-down 
                optionDetailsUC.ddlSelectEmployeeName.DataSource = (from b in dt_OptionDetailsDataTemp.AsEnumerable()
                                                                    where b.Field<string>("Employee Name") != null
                                                                    select b.Field<string>("Employee Name")).Distinct();
                optionDetailsUC.ddlSelectEmployeeName.DataBind();

                //Bind EmployeeID drop-down 
                optionDetailsUC.ddlSelectEmployeeID.DataSource = (from b in dt_OptionDetailsDataTemp.AsEnumerable()
                                                                  where b.Field<string>("Employee ID") != null
                                                                  select b.Field<string>("Employee ID")).Distinct();
                optionDetailsUC.ddlSelectEmployeeID.DataBind();
            }
            dt_OptionDetailsDataTemp.Dispose();
            optionDetailsUC.ddlSelectSchemeName.Items.Insert(0, "--- Select All ---");
            optionDetailsUC.ddlSelectGrantID.Items.Insert(0, "--- Select All ---");
            optionDetailsUC.ddlSelectEmployeeName.Items.Insert(0, "--- Select All ---");
            optionDetailsUC.ddlSelectEmployeeID.Items.Insert(0, "--- Select All ---");
        }
        #endregion

        #region Get Data
        /// <summary>
        /// this method is used to get data of Options Details
        /// </summary>
        public void GetData(OptionDetailsUC optionDetailsUC)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                DateTime? dt = null;
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.PageName = optionDetailsUC.ddlSelectEmployeeID.Enabled.Equals(false) ? CommonConstantModel.s_GetOptionsDataOnDate : CommonConstantModel.s_GetOptionsDetails;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingProperties.ReportDate = string.IsNullOrEmpty(optionDetailsUC.hdnReportDate.Value) ? string.IsNullOrEmpty(optionDetailsUC.txtReportDate.Text) || optionDetailsUC.txtReportDate.Text.Equals("dd/mmm/yyyy") ? dt : Convert.ToDateTime(optionDetailsUC.txtReportDate.Text) : Convert.ToDateTime(optionDetailsUC.hdnReportDate.Value);
                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                ac_GrantDetails.dt_OptionDetailsData = accountingCRUDProperties.ds_Result.Tables[0];
                ac_GrantDetails.dt_OptionDetailsDataVestwise = accountingCRUDProperties.ds_Result.Tables[1];
            }
        }

        /// <summary>
        /// this method is used to get data of Options Details
        /// </summary>
        /// <param name="optionDetailsUC">OptionDetailsUC page object</param>
        public void GetUploadedData(OptionDetailsUC optionDetailsUC)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                DateTime? date = null;
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.PageName = CommonConstantModel.s_GetOptionsDataOnDate;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingProperties.ReportDate = string.IsNullOrEmpty(optionDetailsUC.txtReportDate.Text) ? date : Convert.ToDateTime(optionDetailsUC.txtReportDate.Text);
                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                ac_GrantDetails.dt_OptionDetailsUploadedData = accountingCRUDProperties.ds_Result.Tables[0];
            }
        }

        /// <summary>
        /// This method is used to select grant with no employee association
        /// </summary>
        /// <param name="optionDetailsUC">OptionDetailsUC page object</param>
        public void GetGrantsWithNoEmp(OptionDetailsUC optionDetailsUC)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.PageName = CommonConstantModel.s_GetGrantsWithNoEmp;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                ac_GrantDetails.s_GrantsWithNoEmp = string.Join(",", accountingCRUDProperties.dt_Result.AsEnumerable()
                                           .Select(b => b["GRS_GRANT_REGISTRATION_ID"])
                                           .ToArray().Distinct()).TrimEnd(',');
                if(!string.IsNullOrEmpty(ac_GrantDetails.s_GrantsWithNoEmp))
                {
                    optionDetailsUC.lblValidate.Text = string.Format(accountingServiceClient.GetAccounting_L10N("lblGrantWithNoEmp", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10).Replace("~", ac_GrantDetails.s_GrantsWithNoEmp));
                    optionDetailsUC.lblValidate.Visible = true;
                    optionDetailsUC.lblValidate.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
        #endregion

        #region Search
        /// <summary>
        /// Get data based on search parameters
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        public void SearchRecords(OptionDetailsUC optionDetailsUC)
        {
            if (!optionDetailsUC.hdnIsFileUploadOrEdit.Value.Equals("True") && !optionDetailsUC.hdnIsFileUploadOrEdit.Value.Equals("EditTrue"))
            {
                optionDetailsUC.txtReportDate.Enabled = true;
                optionDetailsUC.ddlSelectSchemeName.Enabled = true;
                optionDetailsUC.ddlSelectGrantID.Enabled = true;
                optionDetailsUC.ddlSelectEmployeeName.Enabled = true;
                optionDetailsUC.ddlSelectEmployeeID.Enabled = true;
                optionDetailsUC.btnODSearch.Enabled = true;
            }

            DataTable dt_FilteredRecords = new DataTable();
            GetData(optionDetailsUC);
            GetUploadedData(optionDetailsUC);
            GetGrantsWithNoEmp(optionDetailsUC);
            string s_SchemeName = optionDetailsUC.ddlSelectSchemeName.SelectedIndex.Equals(0) ? string.Empty : "[Scheme Name] = '" + optionDetailsUC.ddlSelectSchemeName.SelectedItem.Text.Replace("'", "''") + "'";
            string s_GrantID = optionDetailsUC.ddlSelectGrantID.SelectedIndex.Equals(0) ? string.Empty : "[Grant Registration ID] = '" + optionDetailsUC.ddlSelectGrantID.SelectedItem.Text.Replace("'", "''") + "'";
            string s_EmployeeName = optionDetailsUC.ddlSelectEmployeeName.SelectedIndex.Equals(0) ? string.Empty : "[Employee Name] = '" + optionDetailsUC.ddlSelectEmployeeName.SelectedItem.Text.Replace("'", "''") + "'";
            string s_EmployeeID = optionDetailsUC.ddlSelectEmployeeID.SelectedIndex.Equals(0) ? string.Empty : "[Employee ID] = '" + optionDetailsUC.ddlSelectEmployeeID.SelectedItem.Text.Replace("'", "''") + "'";

            dt_FilteredRecords = ac_GrantDetails.dt_OptionDetailsData.Copy();

            if (dt_FilteredRecords != null && dt_FilteredRecords.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(s_SchemeName))
                {
                    dt_FilteredRecords = (dt_FilteredRecords.Rows.Count > 0 && dt_FilteredRecords.Select(s_SchemeName).Count() > 0) ? dt_FilteredRecords.Select(s_SchemeName).CopyToDataTable() : new DataTable();
                }
                if (!string.IsNullOrEmpty(s_GrantID))
                {
                    dt_FilteredRecords = (dt_FilteredRecords.Rows.Count > 0 && dt_FilteredRecords.Select(s_GrantID).Count() > 0) ? dt_FilteredRecords.Select(s_GrantID).CopyToDataTable() : new DataTable();
                }
                if (!string.IsNullOrEmpty(s_EmployeeName))
                {
                    dt_FilteredRecords = (dt_FilteredRecords.Rows.Count > 0 && dt_FilteredRecords.Select(s_EmployeeName).Count() > 0) ? dt_FilteredRecords.Select(s_EmployeeName).CopyToDataTable() : new DataTable();
                }
                if (!string.IsNullOrEmpty(s_EmployeeID))
                {
                    dt_FilteredRecords = (dt_FilteredRecords.Rows.Count > 0 && dt_FilteredRecords.Select(s_EmployeeID).Count() > 0) ? dt_FilteredRecords.Select(s_EmployeeID).CopyToDataTable() : new DataTable();
                }


                DataView dv_OptionDetails = new DataView(dt_FilteredRecords);
                optionDetailsUC.gvOptionDetails.DataSource = dt_FilteredRecords.Rows.Count > 0 ? dv_OptionDetails.ToTable("DT", false, "Grant Option ID", "Grant Registration ID", "Grant Date", "Employee ID", "Employee Name", "Scheme Name", "Granted", "Cancelled", "Vested Cancelled", "Unvested Cancelled", "Lapsed", "Exercised", "Unvested", "Vested and Exercisable", "Outstanding", "Forfeiture Rate", "Action", "Rate", "OPERATION_DATE") : new DataTable();
                optionDetailsUC.gvOptionDetails.DataBind();
            }
            optionDetailsUC.btnODClearFilter.Visible = true;
            optionDetailsUC.lblODLastUpdatedDate.Text = Convert.ToString(ac_GrantDetails.dt_OptionDetailsUI.Select("LabelID = 'lblODLastUpdatedDate'")[0]["LabelToolTip"]) + ": " + ac_SearchGrantDetails.s_LatestOperationDate;
            optionDetailsUC.hdnIsFileUploadOrEdit.Value = optionDetailsUC.hdnIsFileUploadOrEdit.Value.Equals("EditTrue") ? optionDetailsUC.hdnIsFileUploadOrEdit.Value : string.Empty;
            optionDetailsUC.gvOptionDetails.Style.Add("display", "block");
            optionDetailsUC.tblHistory.Style.Add("display", "none");
            optionDetailsUC.dvMain.Style.Add("display", "block");
            optionDetailsUC.btnUpdateAll.Style.Remove("display");
        }

        /// <summary>
        /// Clear applies filtes
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        public void ClearFiltrs(OptionDetailsUC optionDetailsUC)
        {
            optionDetailsUC.btnODClearFilter.Visible = false;
            optionDetailsUC.btnUpdateAll.Style.Add("display", "none");
            optionDetailsUC.gvOptionDetails.Style.Add("display", "none");
            optionDetailsUC.ddlSelectSchemeName.Items.Insert(0, "--- Select All ---");
            optionDetailsUC.ddlSelectGrantID.Items.Insert(0, "--- Select All ---");
            optionDetailsUC.ddlSelectEmployeeName.Items.Insert(0, "--- Select All ---");
            optionDetailsUC.ddlSelectEmployeeID.Items.Insert(0, "--- Select All ---");
            optionDetailsUC.txtReportDate.Text = string.Empty;
        }
        #endregion

        #region Add/Delete/View document details
        /// <summary>
        /// This method is used to Upload Firl
        /// </summary>
        /// <param name="optionDetailsUC">Page object OptionDetailsUC</param>
        public void UploadFile(OptionDetailsUC optionDetailsUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (optionDetailsUC.fileODUploadDoc.HasFile)
                    {
                        if (optionDetailsUC.fileODUploadDoc.FileContent.Length <= 10485760)
                        {
                            //"Convert.ToString(optionDetailsUC.fileODUploadDoc.FileName.Split('.').Last())" used to get file extension
                            switch (Convert.ToString(optionDetailsUC.fileODUploadDoc.FileName.Split('.').Last()))
                            {
                                case "xlsx":
                                case "xls":
                                case "doc":
                                case "docx":
                                case "pdf":

                                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                    accountingProperties.PageName = CommonConstantModel.s_AddOptionsDocument;
                                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                                    accountingProperties.DocumentName = optionDetailsUC.fileODUploadDoc.FileName;
                                    accountingProperties.Opration_Date = string.IsNullOrEmpty(optionDetailsUC.hdnReportDate.Value) ? Convert.ToDateTime(optionDetailsUC.txtReportDate.Text).Add(DateTime.Now.TimeOfDay) : Convert.ToDateTime(optionDetailsUC.hdnReportDate.Value);
                                    accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                                    switch (accountingCRUDProperties.a_result)
                                    {
                                        case 0:
                                            ShowMsgAndBindGv(optionDetailsUC, accountingServiceClient, "lblODFileNameExists", "red");
                                            break;

                                        default:

                                            if (!Directory.Exists(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + "/" + userSessionInfo.ACC_CompanyName + "/OptionDetailsUP")))
                                            {
                                                Directory.CreateDirectory(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + "/" + userSessionInfo.ACC_CompanyName + "/OptionDetailsUP"));
                                            }

                                            string s_FilePath = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + "/" + userSessionInfo.ACC_CompanyName + "/OptionDetailsUP" + "/" + optionDetailsUC.fileODUploadDoc.FileName);
                                            optionDetailsUC.fileODUploadDoc.SaveAs(s_FilePath);

                                            CreateDataTableForDocDetails(optionDetailsUC);

                                            ShowMsgAndBindGv(optionDetailsUC, accountingServiceClient, "lblODFileUploaded", "blue");
                                            break;
                                    }
                                    optionDetailsUC.tblHistory.Style.Add("display", "none");
                                    optionDetailsUC.dvMain.Style.Add("display", "block");
                                    break;

                                default:
                                    ShowMsgAndBindGv(optionDetailsUC, accountingServiceClient, "lblODInvalidExtension", "red");
                                    break;
                            }
                        }
                        else
                        {
                            ShowMsgAndBindGv(optionDetailsUC, accountingServiceClient, "lblODInvalidSize", "red");
                        }
                    }
                    else
                    {
                        ShowMsgAndBindGv(optionDetailsUC, accountingServiceClient, "lblODInvalidFile", "red");
                    }
                }

                optionDetailsUC.hdnIsFileUploadOrEdit.Value = "True";
                bool b_IsDisables = false;
                b_IsDisables = CheckIsEdit(optionDetailsUC, b_IsDisables);
                BindGvUpdatedAsData(optionDetailsUC);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to check whether it is in update mode
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        /// <param name="b_IsDisables">is disabled record</param>
        /// <returns></returns>
        private bool CheckIsEdit(OptionDetailsUC optionDetailsUC, bool b_IsDisables)
        {
            foreach (var item in optionDetailsUC.txtReportDate.Attributes.Keys)
            {
                b_IsDisables = item.Equals("disabled");
            }

            if (!b_IsDisables)
            {
                SearchRecords(optionDetailsUC);
            }
            else
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_GetOptionsDataOnDate;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.ReportDate = Convert.ToDateTime(optionDetailsUC.txtReportDate.Text);
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    DataView dv_OptionDetails = new DataView(accountingCRUDProperties.ds_Result.Tables[0]);
                    optionDetailsUC.gvOptionDetails.DataSource = accountingCRUDProperties.ds_Result.Tables[0].Rows.Count > 0 ? dv_OptionDetails.ToTable("DT", false, "Grant Option ID", "Grant Registration ID", "Grant Date", "Employee ID", "Employee Name", "Scheme Name", "Granted", "Cancelled", "Vested Cancelled", "Unvested Cancelled", "Lapsed", "Exercised", "Unvested", "Vested and Exercisable", "Outstanding", "Forfeiture Rate", "Action", "Rate", "OPERATION_DATE") : new DataTable();
                    optionDetailsUC.gvOptionDetails.DataBind();

                    accountingProperties.PageName = CommonConstantModel.s_GetODDocNames;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    using (DataTable dt_UploadedFiles = accountingCRUDProperties.dt_Result.Copy().Select("[Updated On] = '" + optionDetailsUC.txtReportDate.Text + "'").Count() > 0 ? accountingCRUDProperties.dt_Result.Copy().Select("[Updated On] = '" + optionDetailsUC.txtReportDate.Text + "'").CopyToDataTable() : new DataTable())
                    {
                        ClearGvUploadedDocIndex(optionDetailsUC);
                        optionDetailsUC.gvODUploadedFiles.DataSource = dt_UploadedFiles;
                        optionDetailsUC.gvODUploadedFiles.DataBind();
                    }
                }
            }
            return b_IsDisables;
        }

        /// <summary>
        /// This method is used to Show Message and Bind GridView
        /// </summary>
        /// <param name="optionDetailsUC">Page object OptionDetailsUC</param>
        /// <param name="accountingServiceClient">AccountingServiceClient service object</param>
        /// <param name="s_MessageID">string MessageID</param>
        /// <param name="s_MessageColor">string MessageColor</param>
        private void ShowMsgAndBindGv(OptionDetailsUC optionDetailsUC, AccountingServiceClient accountingServiceClient, string s_MessageID, string s_MessageColor)
        {
            ClearGvUploadedDocIndex(optionDetailsUC);
            optionDetailsUC.gvODUploadedFiles.Style.Add("display", "block");
            optionDetailsUC.gvODUploadedFiles.DataSource = ac_GrantDetails.dt_OptionDetailsDocDetails;
            optionDetailsUC.gvODUploadedFiles.DataBind();
            System.Web.UI.ScriptManager.RegisterStartupScript(optionDetailsUC, GetType(), "myFunction", "ShowMessageDiv('" + accountingServiceClient.GetAccounting_L10N("" + s_MessageID + "", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10) + "', '" + s_MessageColor + "');", true);
            optionDetailsUC.fileODUploadDoc.ClearAllFilesFromPersistedStore();
        }

        /// <summary>
        /// Clear file content button click event
        /// </summary>
        /// <param name="optionDetailsUC">optionDetailsUC page object</param>
        internal void btnODClearFileContent_Click(OptionDetailsUC optionDetailsUC)
        {
            try
            {
                optionDetailsUC.fileODUploadDoc.ClearAllFilesFromPersistedStore();
                optionDetailsUC.hdnIsFileUploadOrEdit.Value = "True";
                bool b_IsDisables = false;
                b_IsDisables = CheckIsEdit(optionDetailsUC, b_IsDisables);
                BindGvUpdatedAsData(optionDetailsUC);
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_GetODDocNames;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    using (DataTable dt_UploadedFiles = accountingCRUDProperties.dt_Result.Copy().Select("[Updated On] = '" + optionDetailsUC.txtReportDate.Text + "'").Count() > 0 ? accountingCRUDProperties.dt_Result.Copy().Select("[Updated On] = '" + optionDetailsUC.txtReportDate.Text + "'").CopyToDataTable() : new DataTable())
                    {
                        ClearGvUploadedDocIndex(optionDetailsUC);
                        optionDetailsUC.gvODUploadedFiles.DataSource = dt_UploadedFiles;
                        optionDetailsUC.gvODUploadedFiles.DataBind();
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to upload comments
        /// </summary>
        /// <param name="optionDetailsUC">page object of OptionDetailsUC</param>
        public void UploadComments(OptionDetailsUC optionDetailsUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_AddOptionsComments;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.COMMENTS = optionDetailsUC.txtODComments.Text;
                    accountingProperties.Opration_Date = string.IsNullOrEmpty(optionDetailsUC.hdnReportDate.Value) ? Convert.ToDateTime(optionDetailsUC.txtReportDate.Text).Add(DateTime.Now.TimeOfDay) : Convert.ToDateTime(optionDetailsUC.hdnReportDate.Value);
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 1:
                            System.Web.UI.ScriptManager.RegisterStartupScript(optionDetailsUC, GetType(), "myFunction", "ShowMessageDiv('" + accountingServiceClient.GetAccounting_L10N("lblODCommentsUploaded", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10) + "', 'blue');", true);
                            break;

                        case 0:
                            System.Web.UI.ScriptManager.RegisterStartupScript(optionDetailsUC, GetType(), "myFunction", "ShowMessageDiv('" + accountingServiceClient.GetAccounting_L10N("lblODError", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10) + "', 'blue');", true);
                            break;
                    }

                    optionDetailsUC.tblHistory.Style.Add("display", "none");
                    optionDetailsUC.dvMain.Style.Add("display", "block");

                    optionDetailsUC.hdnIsFileUploadOrEdit.Value = "True";
                    SearchRecords(optionDetailsUC);

                    BindGvUpdatedAsData(optionDetailsUC);
                    ClearGvUploadedDocIndex(optionDetailsUC);
                    optionDetailsUC.gvODUploadedFiles.DataSource = ac_GrantDetails.dt_OptionDetailsDocDetails != null && ac_GrantDetails.dt_OptionDetailsDocDetails.Rows.Count > 0 ? ac_GrantDetails.dt_OptionDetailsDocDetails : new DataTable();
                    optionDetailsUC.gvODUploadedFiles.DataBind();

                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind updated as on data
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        private void BindGvUpdatedAsData(OptionDetailsUC optionDetailsUC)
        {
            optionDetailsUC.n_Index = 0;
            optionDetailsUC.n_ReportYear = 0;
            optionDetailsUC.n_DataUpdatedAsOn = 0;
            optionDetailsUC.n_Status = 0;
            optionDetailsUC.n_Comments = 0;
            optionDetailsUC.n_Documents = 0;
            optionDetailsUC.n_OprationDate = 0;
            GetUpdatedAsOnData(optionDetailsUC);
        }

        /// <summary>
        /// This method is used to bind updated as on data
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        private void ClearGvUploadedDocIndex(OptionDetailsUC optionDetailsUC)
        {
            optionDetailsUC.n_DocIndex = 0;
            optionDetailsUC.n_Doc_File_Name = 0;
            optionDetailsUC.n_Doc_Download = 0;
            optionDetailsUC.n_Doc_Delete = 0;
            optionDetailsUC.n_Doc_DataUpdatedAsOn = 0;
        }

        /// <summary>
        /// This method is used to set values to datatable
        /// </summary>
        /// <param name="optionDetailsUC">optionDetailsUC page object</param>
        private void CreateDataTableForDocDetails(OptionDetailsUC optionDetailsUC)
        {
            if (ac_GrantDetails.dt_OptionDetailsDocDetails.Columns.Count <= 0)
            {
                ac_GrantDetails.dt_OptionDetailsDocDetails.Columns.Add("Updated On", typeof(string));
                ac_GrantDetails.dt_OptionDetailsDocDetails.Columns.Add("File Name", typeof(string));
                ac_GrantDetails.dt_OptionDetailsDocDetails.Columns.Add("Download", typeof(string));
                ac_GrantDetails.dt_OptionDetailsDocDetails.Columns.Add("Delete", typeof(string));
            }

            DataRow dr = ac_GrantDetails.dt_OptionDetailsDocDetails.NewRow();
            dr["Updated On"] = string.IsNullOrEmpty(optionDetailsUC.hdnReportDate.Value) ? Convert.ToDateTime(optionDetailsUC.txtReportDate.Text).Add(DateTime.Now.TimeOfDay).ToString("dd/MMM/yyyy") : Convert.ToDateTime(optionDetailsUC.hdnReportDate.Value).ToString("dd/MMM/yyyy");
            dr["File Name"] = optionDetailsUC.fileODUploadDoc.FileName;
            ac_GrantDetails.dt_OptionDetailsDocDetails.Rows.Add(dr);
        }


        /// <summary>
        /// This method is used to get Updated As On Data
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        public void GetUpdatedAsOnData(OptionDetailsUC optionDetailsUC)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.PageName = CommonConstantModel.s_GetUpdatedAsOnData;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                ac_GrantDetails.dt_UpdatedAsOnData = accountingCRUDProperties.ds_Result.Tables[0];
                ac_GrantDetails.dt_UpdatedAsOnDataComments = accountingCRUDProperties.ds_Result.Tables[1];
                ac_GrantDetails.dt_UpdatedAsOnDataDocuments = accountingCRUDProperties.ds_Result.Tables[2];

                optionDetailsUC.gvHistory.DataSource = ac_GrantDetails.dt_UpdatedAsOnData;
                optionDetailsUC.gvHistory.DataBind();
            }
        }

        /// <summary>
        /// This method is used to get Uploaded Doc Name
        /// </summary>
        /// <param name="s_UpdatedOn">UpdatedOn date</param>
        public List<OptionsDetailsProperties> GetUploadedDocName(string s_UpdatedOn)
        {
            List<OptionsDetailsProperties> UploadedDocList = new List<OptionsDetailsProperties>();
            DataRow[] dr = ac_GrantDetails.dt_UpdatedAsOnDataDocuments.Select("[Updated On] = '" + s_UpdatedOn.ToString() + "'");
            UploadedDocList = dr.Count() > 0 ? dr.CopyToDataTable().AsEnumerable().Select(dataRow => new OptionsDetailsProperties { s_DocName = dataRow.Field<string>("UPLOADED_DOC_NAME"), s_UpdatedOn = dataRow.Field<string>("Updated On") }).ToList() : new List<OptionsDetailsProperties>();

            return UploadedDocList;
        }

        /// <summary>
        /// This method is used to delete file
        /// </summary>
        /// <param name="s_Operation">string Operation</param>
        /// <param name="s_DocName">string DocName</param>
        /// <param name="s_UploadedDate">string Uploaded Date</param>
        public void DeleteDocument(string s_Operation, string s_DocName, string s_UploadedDate)
        {
            switch (s_Operation)
            {
                case "imgDelete":
                    // Determine whether the directory exists. 
                    if (File.Exists(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + userSessionInfo.ACC_CompanyName + "/" + "OptionDetailsUP") + "\\" + s_DocName))
                    {
                        File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + userSessionInfo.ACC_CompanyName + "/" + "OptionDetailsUP") + "\\" + s_DocName);
                    }

                    using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                    {
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.PageName = CommonConstantModel.s_GetUpdatedAsOnData;
                        accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                        accountingProperties.DocUploadedOn = s_UploadedDate;
                        accountingProperties.DocumentName = s_DocName;
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    }

                    if (ac_GrantDetails.dt_OptionDetailsDocDetails.Rows.Count > 0)
                    {
                        foreach (DataRow perRow in ac_GrantDetails.dt_OptionDetailsDocDetails.Select("[File Name] = '" + s_DocName + "'"))
                        {
                            perRow.Delete();
                        }
                    }

                    break;
            }

        }
        #endregion

        #region Save Record
        /// <summary>
        /// This method is used to save option Details record
        /// </summary>
        /// <param name="s_ReportDate">string Report Date</param>
        /// <param name="s_GrantOptionID">string Granted Option ID</param>
        /// <param name="s_EmployeeID">string EmployeeID</param>
        /// <param name="s_EmployeeName">string Employee Name</param>
        /// <param name="s_GrantID">string GrantID</param>
        /// <param name="s_OptionDetails">string OptionDetails with comma seperated</param>
        /// <param name="s_OptionDetailsVestwise">string OptionDetailVestwise with comma seperated</param>
        /// <param name="s_IsUpdate">string Is update record</param>
        public string[] SaveOptionDetails(object s_ReportDate, object s_GrantOptionID, object s_EmployeeID, object s_EmployeeName, object s_GrantID, string s_OptionDetails, string s_OptionDetailsVestwise, string s_IsUpdate)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    DataTable dt_OptionDetails = CreateOptiondDetailDataTable(), dt_VestWise = CreateTableVestwise();
                    DataRow dr = dt_OptionDetails.NewRow(), dr_VestWise = dt_VestWise.NewRow();
                    string[] s_Result = new string[3];
                    string s_EmployeeForfeitureRate = Convert.ToString(GetEmployeeForfeitureRate().Select("EMPLOYEE_ID = '" + Convert.ToString(s_EmployeeID) + "'").Count() > 0 ? GetEmployeeForfeitureRate().Select("EMPLOYEE_ID = '" + Convert.ToString(s_EmployeeID) + "'")[0]["FORFEITURE_RATE"] : string.Empty);

                    AddValuesToDatatable(s_OptionDetails, Convert.ToString(s_ReportDate), dt_OptionDetails, dr, s_EmployeeForfeitureRate);
                    dt_OptionDetails.Rows[0]["OPERATION_ID"] = 5;
                    dt_OptionDetails.Rows[0]["OPERATION_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                    if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                    {
                        dt_VestWise.Columns["OPERATION_ID"].Expression = "5";
                        dt_VestWise.Columns["OPERATION_DATE"].DefaultValue = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);
                        AddValuesToDatatableVestWise(s_OptionDetailsVestwise, Convert.ToString(s_ReportDate), dt_VestWise, s_EmployeeForfeitureRate);
                    }
                    else
                    {
                        dt_VestWise.Rows.Add(dr_VestWise);
                    }

                    accountingProperties.Action = "C";
                    accountingProperties.s_SubAction = s_IsUpdate;
                    accountingProperties.Opration_Date = Convert.ToDateTime(s_ReportDate);
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.ODOpration = "UIOperatins";
                    accountingProperties.s_CaluationMethod = userSessionInfo.ACC_CalculationMethod.ToString();
                    accountingProperties.PageName = CommonConstantModel.s_OptionDetails;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.s_GrantOptionID = Convert.ToString(s_GrantOptionID);
                    accountingProperties.s_EmployeeID = Convert.ToString(s_EmployeeID);
                    accountingProperties.s_GrantOptionID = Convert.ToString(s_GrantOptionID);
                    accountingProperties.Grant_ID = Convert.ToString(s_GrantID);
                    accountingProperties.dt_OptionDetails = dt_OptionDetails;
                    accountingProperties.dt_OptionDetailsVestwise = dt_VestWise;
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    dt_OptionDetails.Dispose();
                    dt_VestWise.Dispose();

                    s_Result[0] = accountingCRUDProperties.a_result.ToString();

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblODError", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10);
                            break;

                        case 1:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblODCreated", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10);
                            break;

                        case 3:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblODDeleted", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10);
                            break;

                        case 5:
                            s_Result[1] = string.Format(accountingServiceClient.GetAccounting_L10N("lblODDataLocked", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10), s_ReportDate);
                            break;

                        case 6:
                            s_Result[1] = string.Format(accountingServiceClient.GetAccounting_L10N("lblODDataAlreadyExists", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10), s_ReportDate);
                            break;

                        case 7:
                            s_Result[1] = string.Format(accountingServiceClient.GetAccounting_L10N("lblODUpdated", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10), s_ReportDate);
                            break;

                    }

                    accountingProperties.PageName = CommonConstantModel.s_UpdateAllFlage;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    s_Result[2] = Convert.ToString(accountingCRUDProperties.a_result);

                    return s_Result;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to update all grants
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        internal void UpdateAllGrants(OptionDetailsUC optionDetailsUC)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.PageName = CommonConstantModel.s_UpdateAllFlage;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.Opration_Date = Convert.ToDateTime(optionDetailsUC.txtReportDate.Text);
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 1:
                            System.Web.UI.ScriptManager.RegisterStartupScript(optionDetailsUC, GetType(), "myFunction", "ShowMessageDiv('" + accountingServiceClient.GetAccounting_L10N("lblODUpdateAll", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10) + "', 'blue');", true);
                            break;

                        case 0:
                            System.Web.UI.ScriptManager.RegisterStartupScript(optionDetailsUC, GetType(), "myFunction", "ShowMessageDiv('" + accountingServiceClient.GetAccounting_L10N("lblODError", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10) + "', 'blue');", true);
                            break;

                        case 2:
                            System.Web.UI.ScriptManager.RegisterStartupScript(optionDetailsUC, GetType(), "myFunction", "ShowMessageDiv('" + accountingServiceClient.GetAccounting_L10N("lblGrantWithNoEmp", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10) + "', 'red');", true);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to get EmployeeWise ForfeitureRate
        /// </summary>
        /// <returns>DataTable</returns>
        private DataTable GetEmployeeForfeitureRate()
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accountingProperties.PageName = CommonConstantModel.s_EmpForfeitutreRate;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                using (DataTable dt_EmployeeForfeitureRate = accountingCRUDProperties.dt_Result)
                {
                    return dt_EmployeeForfeitureRate;
                }
            }
        }

        /// <summary>
        /// This method is used to set value to datatable
        /// </summary>
        /// <param name="s_OptionDetails">string OptionDetails</param>
        /// <param name="dt_OptionDetails">Datatable OptionDetails</param>
        /// <param name="s_ReportDate">Report Date</param>
        /// <param name="s_EmployeeForfeitureRate">s_EmployeeForfeitureRate</param>
        /// <param name="dr">DataRow</param>
        private void AddValuesToDatatable(string s_OptionDetails, string s_ReportDate, DataTable dt_OptionDetails, DataRow dr, string s_EmployeeForfeitureRate)
        {
            foreach (string item in s_OptionDetails.Split(','))
            {
                switch (item.Split('|')[0])
                {
                    case "OptionCancelled":
                        dr["CANCELLED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[1].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[1].Trim());
                        if (string.IsNullOrEmpty(item.Split('|')[1].Trim()))
                            dr["CANCELLATION_DATE"] = DBNull.Value;
                        else
                            dr["CANCELLATION_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                        break;

                    case "OptionUnvCancelled":
                        dr["UNVESTED_CANCELLED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[1].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[1].Trim());
                        if (string.IsNullOrEmpty(item.Split('|')[1].Trim()))
                            dr["CANCELLATION_DATE"] = DBNull.Value;
                        else
                            dr["CANCELLATION_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                        break;

                    case "OptionVestCancelled":
                        dr["VESTED_CANCELLED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[1].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[1].Trim());
                        if (string.IsNullOrEmpty(item.Split('|')[1].Trim()))
                            dr["CANCELLATION_DATE"] = DBNull.Value;
                        else
                            dr["CANCELLATION_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                        break;

                    case "OptionLapsed":
                        dr["LAPSED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[1].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[1].Trim());
                        if (string.IsNullOrEmpty(item.Split('|')[1].Trim()))
                            dr["LAPSED_DATE"] = DBNull.Value;
                        else
                            dr["LAPSED_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                        break;

                    case "OptionExcercised":
                        dr["EXERCISED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[1].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[1].Trim());
                        if (string.IsNullOrEmpty(item.Split('|')[1].Trim()))
                            dr["EXERCISED_DATE"] = DBNull.Value;
                        else
                            dr["EXERCISED_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                        break;

                    case "OptionUnvested":
                        dr["UNVESTED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[1].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[1].Trim());
                        break;

                    case "OptionVeAndExe":
                        dr["VESTED_AND_EXERCISABLE"] = string.IsNullOrEmpty(item.Split('|')[1].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[1].Trim());
                        break;

                    case "OptionOutstanding":
                        dr["OUTSTANDING_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[1].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[1].Trim());
                        break;

                    case "ForfeitureRate":
                        Decimal s_ForfeitureRate = string.IsNullOrEmpty(item.Split('|')[1].Trim()) ? 0 : Convert.ToDecimal(item.Split('|')[1].Trim());
                        if (s_ForfeitureRate.Equals(Convert.ToDecimal(s_EmployeeForfeitureRate)))
                        {
                           dr["FORFEITURE_RATE"] = DBNull.Value;
                        }
                        else
                        {
                            dr["FORFEITURE_RATE"] = Convert.ToDecimal(s_ForfeitureRate);
                        }
                        break;
                }
            }

            dt_OptionDetails.Rows.Add(dr);
        }

        /// <summary>
        /// This method is used to set value to datatable
        /// </summary>
        /// <param name="s_OptionDetailsVestwise">string s_OptionDetailsVestwise</param>
        /// <param name="s_ReportDate">Report Date</param>
        /// <param name="s_EmployeeForfeitureRate">EmployeeForfeitureRate</param>
        /// <param name="dt_VestWise">Datatable dt_VestWise</param>
        private void AddValuesToDatatableVestWise(string s_OptionDetailsVestwise, string s_ReportDate, DataTable dt_VestWise, string s_EmployeeForfeitureRate)
        {
            int n_count = s_OptionDetailsVestwise.Split('~')[0].Split('|').Count(), n_Index = 1;
            DataRow dr;
            while (n_count > 1)
            {
                dr = dt_VestWise.NewRow();
                foreach (string item in s_OptionDetailsVestwise.Split('~'))
                {
                    switch (item.Split('|')[0])
                    {
                        case "VestingDate":
                            dr["VPD_VESTING_DATE"] = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? DateTime.Now : Convert.ToDateTime(item.Split('|')[n_Index].Trim());
                            break;

                        case "OptionGranted":
                            dr["GRANTED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[n_Index].Trim());
                            break;

                        case "OptionCancelled":
                            dr["CANCELLED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[n_Index].Trim());
                            if (string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) && !Convert.ToString(item.Split('|')[n_Index].Trim()).Equals(0))
                                dr["CANCELLATION_DATE"] = DBNull.Value;
                            else
                                dr["CANCELLATION_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                            break;

                        case "OptionUnvCancelled":
                            dr["UNVESTED_CANCELLED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[n_Index].Trim());
                            if (string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) && !Convert.ToString(item.Split('|')[n_Index].Trim()).Equals(0))
                                dr["CANCELLATION_DATE"] = DBNull.Value;
                            else
                                dr["CANCELLATION_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                            break;

                        case "OptionVestCancelled":
                            dr["VESTED_CANCELLED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[n_Index].Trim());
                            if (string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) && !Convert.ToString(item.Split('|')[n_Index].Trim()).Equals(0))
                                dr["CANCELLATION_DATE"] = DBNull.Value;
                            else
                                dr["CANCELLATION_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                            break;

                        case "OptionLapsed":
                            dr["LAPSED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[n_Index].Trim());
                            if (string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) && !Convert.ToString(item.Split('|')[n_Index].Trim()).Equals(0))
                                dr["LAPSED_DATE"] = DBNull.Value;
                            else
                                dr["LAPSED_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                            break;

                        case "OptionExcercised":
                            dr["EXERCISED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[n_Index].Trim());
                            if (string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) && !Convert.ToString(item.Split('|')[n_Index].Trim()).Equals(0))
                                dr["EXERCISED_DATE"] = DBNull.Value;
                            else
                                dr["EXERCISED_DATE"] = Convert.ToDateTime(s_ReportDate).Add(DateTime.Now.TimeOfDay);

                            break;

                        case "OptionUnvested":
                            dr["UNVESTED_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[n_Index].Trim());
                            break;

                        case "OptionVeAndExe":
                            dr["VESTED_AND_EXERCISABLE"] = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[n_Index].Trim());
                            break;

                        case "OptionOutstanding":
                            dr["OUTSTANDING_OPTIONS"] = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? 0 : Convert.ToInt32(item.Split('|')[n_Index].Trim());
                            break;

                        case "ForfeitureRate":
                            Decimal s_ForfeitureRate = string.IsNullOrEmpty(item.Split('|')[n_Index].Trim()) ? 0 : Convert.ToDecimal(item.Split('|')[n_Index].Trim());
                            if (s_ForfeitureRate.Equals(Convert.ToDecimal(s_EmployeeForfeitureRate)))
                            {
                                dr["FORFEITURE_RATE"] = DBNull.Value;
                            }
                            else
                            {
                                dr["FORFEITURE_RATE"] = Convert.ToDecimal(s_ForfeitureRate);
                            }                           
                            break;
                    }
                }
                dr["VPD_VESTING_PERIOD_ID"] = n_Index;
                dt_VestWise.Rows.Add(dr);
                n_count--;
                n_Index++;
            }

        }

        /// <summary>
        /// This method is used to create grant wise DataTable
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable CreateOptiondDetailDataTable()
        {
            DataTable dt_OptionDetails = new DataTable("dt_OptionDetails");

            dt_OptionDetails.Columns.Add("AGRMID", typeof(int));
            dt_OptionDetails.Columns.Add("GRANT_OPTION_ID", typeof(string));
            dt_OptionDetails.Columns.Add("EMPID", typeof(int));
            dt_OptionDetails.Columns.Add("GRANTED_OPTIONS", typeof(int));
            dt_OptionDetails.Columns.Add("CANCELLED_OPTIONS", typeof(int));
            dt_OptionDetails.Columns.Add("VESTED_CANCELLED_OPTIONS", typeof(int));
            dt_OptionDetails.Columns.Add("UNVESTED_CANCELLED_OPTIONS", typeof(int));
            dt_OptionDetails.Columns.Add("CANCELLATION_DATE", typeof(DateTime));
            dt_OptionDetails.Columns.Add("LAPSED_OPTIONS", typeof(int));
            dt_OptionDetails.Columns.Add("LAPSED_DATE", typeof(DateTime));
            dt_OptionDetails.Columns.Add("EXERCISED_OPTIONS", typeof(int));
            dt_OptionDetails.Columns.Add("EXERCISED_DATE", typeof(DateTime));
            dt_OptionDetails.Columns.Add("UNVESTED_OPTIONS", typeof(int));
            dt_OptionDetails.Columns.Add("VESTED_AND_EXERCISABLE", typeof(int));
            dt_OptionDetails.Columns.Add("OUTSTANDING_OPTIONS", typeof(int));
            dt_OptionDetails.Columns.Add("FORFEITURE_RATE", typeof(decimal));
            dt_OptionDetails.Columns.Add("OPERATION_ID", typeof(int));
            dt_OptionDetails.Columns.Add("OPERATION_DATE", typeof(DateTime));


            return dt_OptionDetails;
        }

        /// <summary>
        /// This method is used to create vest wise DataTable
        /// </summary>
        /// <returns>DataTable</returns>
        private DataTable CreateTableVestwise()
        {
            DataTable dataTable = new DataTable("dt_VestwiseData");
            dataTable.Columns.Add("OPT_GRANTED_ID", typeof(string));
            dataTable.Columns.Add("AGRMID", typeof(Int32));
            dataTable.Columns.Add("GRANT_OPTION_ID", typeof(string));
            dataTable.Columns.Add("EMPID", typeof(Int32));
            dataTable.Columns.Add("VPD_VESTING_PERIOD_ID", typeof(Int32));
            dataTable.Columns.Add("VPD_VESTING_DATE", typeof(DateTime));
            dataTable.Columns.Add("GRANTED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("CANCELLED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("VESTED_CANCELLED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("UNVESTED_CANCELLED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("CANCELLATION_DATE", typeof(DateTime));
            dataTable.Columns.Add("LAPSED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("LAPSED_DATE", typeof(DateTime));
            dataTable.Columns.Add("EXERCISED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("EXERCISED_DATE", typeof(DateTime));
            dataTable.Columns.Add("UNVESTED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("VESTED_AND_EXERCISABLE", typeof(Int32));
            dataTable.Columns.Add("OUTSTANDING_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("FORFEITURE_RATE", typeof(Decimal));
            dataTable.Columns.Add("COST_AS_PER_SYSTEM", typeof(Decimal));
            dataTable.Columns.Add("H_COST_MANUALLY", typeof(Decimal));
            dataTable.Columns.Add("OPERATION_ID", typeof(Int32));
            dataTable.Columns.Add("OPERATION_DATE", typeof(DateTime));
            dataTable.Columns.Add("COST_AS_PER_SYSTEM_BY_FV", typeof(Decimal));
            dataTable.Columns.Add("COST_AS_PER_SYSTEM_BY_IV", typeof(Decimal));
            return dataTable;
        }

        /// <summary>
        /// This method is used to show message
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        /// <param name="s_LabelID">Label ID</param>
        public void ShowMessage(OptionDetailsUC optionDetailsUC, string s_LabelID)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                System.Web.UI.ScriptManager.RegisterStartupScript(optionDetailsUC, GetType(), "myFunction", "ShowMessageDiv('" + accountingServiceClient.GetAccounting_L10N(s_LabelID, CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10) + "', 'blue');", true);
            }
        }
        #endregion

        /// <summary>
        /// This method is used to get data based on Granted ID
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        /// <param name="sender">has some action perform on control</param>
        public void imgButton_Click(OptionDetailsUC optionDetailsUC, object sender)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                ImageButton imgButton = (ImageButton)sender;

                switch (imgButton.ID.Split('|').First().Replace("\\", ""))
                {
                    case "imgEdit":
                        GetDataToUpdateRecord(optionDetailsUC, accountingServiceClient, imgButton.ID.Split('|').Last().Replace("\\", ""));
                        break;

                    case "imgDelete":
                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.PageName = CommonConstantModel.s_DeleteOptionsDataOnDate;
                        accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                        accountingProperties.ReportDate = Convert.ToDateTime(imgButton.ID.Split('|').Last().Replace("\\", ""));
                        accountingProperties.SEN_CalculationMethod = userSessionInfo.ACC_CalculationMethod;
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                        optionDetailsUC.n_Index = 0;
                        optionDetailsUC.n_ReportYear = 0;
                        optionDetailsUC.n_DataUpdatedAsOn = 0;
                        optionDetailsUC.n_Status = 0;
                        optionDetailsUC.n_Comments = 0;
                        optionDetailsUC.n_Documents = 0;
                        optionDetailsUC.n_OprationDate = 0;

                        switch (accountingCRUDProperties.a_result)
                        {
                            case 1:
                                System.Web.UI.ScriptManager.RegisterStartupScript(optionDetailsUC, GetType(), "myFunction", "ShowMessageDiv('" + accountingServiceClient.GetAccounting_L10N("lblODDeleted", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10) + "', 'blue');", true);
                                break;

                            case 0:
                                System.Web.UI.ScriptManager.RegisterStartupScript(optionDetailsUC, GetType(), "myFunction", "ShowMessageDiv('" + accountingServiceClient.GetAccounting_L10N("lblODError", CommonConstantModel.s_OptionDetails, CommonConstantModel.s_AccountingL10) + "', 'blue');", true);
                                break;
                        }
                        optionDetailsUC.dvMain.Style.Add("display", "none");
                        optionDetailsUC.tblHistory.Style.Remove("display");
                        GetUpdatedAsOnData(optionDetailsUC);
                        break;
                }

            }
        }

        /// <summary>
        /// This method is used to get updated data
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        public void GetUpdateData(OptionDetailsUC optionDetailsUC)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                GetDataToUpdateRecord(optionDetailsUC, accountingServiceClient, optionDetailsUC.txtReportDate.Text);
            }
        }

        /// <summary>
        /// This method is used to get records to update
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        /// <param name="accountingServiceClient">AccountingServiceClient object</param>
        /// <param name="s_ReportDate">ReportDate</param>
        private void GetDataToUpdateRecord(OptionDetailsUC optionDetailsUC, AccountingServiceClient accountingServiceClient, string s_ReportDate)
        {
            accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
            accountingProperties.PageName = CommonConstantModel.s_GetOptionsDataOnDate;
            accountingProperties.Operation = CommonConstantModel.s_OperationRead;
            accountingProperties.ReportDate = Convert.ToDateTime(s_ReportDate);
            accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

            ac_GrantDetails.dt_OptionDetailsDataVestwise = accountingCRUDProperties.ds_Result.Tables[1];

            optionDetailsUC.tblHistory.Style.Add("display", "none");
            optionDetailsUC.dvMain.Style.Add("display", "block");
            optionDetailsUC.txtReportDate.Text = optionDetailsUC.hdnReportDate.Value = s_ReportDate;
            optionDetailsUC.txtReportDate.Attributes.Add("disabled", "disabled");
            optionDetailsUC.ddlSelectSchemeName.Attributes.Add("disabled", "disabled");
            optionDetailsUC.ddlSelectGrantID.Attributes.Add("disabled", "disabled");
            optionDetailsUC.ddlSelectEmployeeName.Attributes.Add("disabled", "disabled");
            optionDetailsUC.ddlSelectEmployeeID.Attributes.Add("disabled", "disabled");
            optionDetailsUC.btnODSearch.Attributes.Add("disabled", "disabled");
            optionDetailsUC.btnODClearFilter.Visible = false;
            optionDetailsUC.hdnIsUpdateRecord.Value = "Update";
            ac_GrantDetails.s_IsEditedRecordLocked = Convert.ToString(ac_GrantDetails.dt_UpdatedAsOnData.Select("[Data Updated As On] = '" + s_ReportDate + "'")[0]["Lock"]);
            DataView dv_OptionDetails = new DataView(accountingCRUDProperties.ds_Result.Tables[0]);
            optionDetailsUC.gvOptionDetails.DataSource = accountingCRUDProperties.ds_Result.Tables[0].Rows.Count > 0 ? dv_OptionDetails.ToTable("DT", false, "Grant Option ID", "Grant Registration ID", "Grant Date", "Employee ID", "Employee Name", "Scheme Name", "Granted", "Cancelled", "Vested Cancelled", "Unvested Cancelled", "Lapsed", "Exercised", "Unvested", "Vested and Exercisable", "Outstanding", "Forfeiture Rate", "Action", "Rate", "OPERATION_DATE") : new DataTable();
            optionDetailsUC.gvOptionDetails.DataBind();
            optionDetailsUC.hdnIsFileUploadOrEdit.Value = "EditTrue";
            ac_GrantDetails.s_IsEditedRecordLocked = string.Empty;
            accountingProperties.PageName = CommonConstantModel.s_GetODDocNames;
            accountingProperties.Operation = CommonConstantModel.s_OperationRead;
            accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
            using (DataTable dt_UploadedFiles = accountingCRUDProperties.dt_Result.Copy().Select("[Updated On] = '" + s_ReportDate + "'").Count() > 0 ? accountingCRUDProperties.dt_Result.Copy().Select("[Updated On] = '" + s_ReportDate + "'").CopyToDataTable() : new DataTable())
            {
                ClearGvUploadedDocIndex(optionDetailsUC);
                optionDetailsUC.gvODUploadedFiles.DataSource = dt_UploadedFiles;
                optionDetailsUC.gvODUploadedFiles.DataBind();
                optionDetailsUC.gvODUploadedFiles.Style.Add("display", "block");
            }
        }

        /// <summary>
        /// This method is used to bind dropdown based on Report Date
        /// </summary>
        /// <param name="optionDetailsUC">object of optionDetailsUC page</param>
        public void txtReportDate_TextChanged(OptionDetailsUC optionDetailsUC)
        {
            BindDropDown(optionDetailsUC);
            optionDetailsUC.gvODUploadedFiles.Style.Add("display", "none");
            ac_GrantDetails.dt_OptionDetailsDocDetails.Clear();
            optionDetailsUC.tblHistory.Style.Add("display", "none");
            optionDetailsUC.dvMain.Style.Add("display", "block");
            optionDetailsUC.btnODClearFilter.Visible = false;
            optionDetailsUC.txtReportDate.Attributes.Remove("disabled");
            optionDetailsUC.ddlSelectSchemeName.Attributes.Remove("disabled");
            optionDetailsUC.ddlSelectGrantID.Attributes.Remove("disabled");
            optionDetailsUC.ddlSelectEmployeeName.Attributes.Remove("disabled");
            optionDetailsUC.ddlSelectEmployeeID.Attributes.Remove("disabled");
            optionDetailsUC.btnODSearch.Attributes.Remove("disabled");
            optionDetailsUC.btnUpdateAll.Style.Add("display", "none");
            ClearGvUploadedDocIndex(optionDetailsUC);
            optionDetailsUC.gvODUploadedFiles.DataSource = new DataTable();
            optionDetailsUC.gvODUploadedFiles.DataBind();
        }

        #region RowDataBound event for gridview
        /// <summary>
        /// RowDataBound event for gvHistory
        /// </summary>
        /// <param name="optionDetailsUC">OptionDetailsUC page object</param>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="n_Index">int n_Index</param>
        /// <param name="n_ReportYear">int n_ReportYear</param>
        /// <param name="n_DataUpdatedAsOn">int n_DataUpdatedAsOn</param>
        /// <param name="n_Status">int n_Status</param>
        /// <param name="n_Comments">int n_Comments</param>
        /// <param name="n_Documents">int n_Documents</param>
        /// <param name="n_OprationDate">int n_OprationDate</param>
        /// <param name="n_Lock">int n_Lock</param>
        internal void gvHistory_RowDataBound(OptionDetailsUC optionDetailsUC, object sender, GridViewRowEventArgs e, ref int n_Index, ref int n_ReportYear, ref int n_DataUpdatedAsOn, ref int n_Status, ref int n_Comments, ref int n_Documents, ref int n_OprationDate, ref int n_Lock)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "TEMP_OPERATION_DATE":
                                    n_OprationDate = n_Index;
                                    perColumn.Visible = false;
                                    break;

                                case "REPORT YEAR":
                                    n_ReportYear = n_Index;
                                    break;

                                case "DATA UPDATED AS ON":
                                    n_DataUpdatedAsOn = n_Index;
                                    break;

                                case "STATUS":
                                    n_Status = n_Index;
                                    break;

                                case "COMMENTS":
                                    n_Comments = n_Index;
                                    break;

                                case "DOCUMENTS":
                                    n_Documents = n_Index;
                                    break;

                                case "LOCK":
                                    n_Lock = n_Index;
                                    break;

                            }
                            n_Index = n_Index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_OprationDate].Visible = false;

                        e.Row.Cells[n_Status].Controls.Add(AddImageButton(optionDetailsUC, e.Row.Cells[n_Lock].Text.ToUpper().Equals("TRUE") ? "Please unlock the data and then update" : "Click here to edit", "imgEdit\\|" + e.Row.RowIndex + "\\|" + e.Row.Cells[n_DataUpdatedAsOn].Text.Replace("/", "\\/"), "~/View/App_Themes/images/Edit.png", Convert.ToString(e.Row.Cells[n_DataUpdatedAsOn]), "gvHistory", string.Empty, string.Empty, string.Empty, e.Row.Cells[n_Lock].Text));
                        e.Row.Cells[n_Status].Controls.Add(AddImageButton(optionDetailsUC, e.Row.Cells[n_Lock].Text.ToUpper().Equals("TRUE") ? "Please unlock the data and then delete" : "Click here to delete", "imgDelete\\|" + e.Row.RowIndex + "\\|" + e.Row.Cells[n_DataUpdatedAsOn].Text.Replace("/", "\\/"), "~/View/App_Themes/images/Delete.png", Convert.ToString(e.Row.Cells[n_DataUpdatedAsOn]), "gvHistory", string.Empty, string.Empty, string.Empty, e.Row.Cells[n_Lock].Text));

                        e.Row.Cells[n_Status].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Comments].Controls.Add(AddImage(optionDetailsUC, Convert.ToString(e.Row.Cells[n_DataUpdatedAsOn].Text), e, n_Comments));
                        e.Row.Cells[n_Documents].Controls.Add(AddLinkButton("Click here to View Comments", "View Documents", "lbtnViewDocuments", Convert.ToString(e.Row.Cells[n_DataUpdatedAsOn].Text)));
                        e.Row.Cells[n_ReportYear].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Lock].Controls.Add(AddLockImage("This report is locked", "~/View/App_Themes/images/lock.png", e.Row.Cells[n_Lock].Text));
                        if (e.Row.RowIndex > 0)
                        {
                            int RowIndex = 1, Count = 1;

                            switch (Convert.ToString(((GridView)sender).ID))
                            {
                                case "gvHistory":
                                    MergeCells(optionDetailsUC.gvHistory, e, n_ReportYear, ref RowIndex, ref Count);
                                    e.Row.Cells[n_ReportYear].VerticalAlign = VerticalAlign.Middle;
                                    break;
                            }

                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add link button
        /// </summary>
        /// <param name="s_Tooltip">Tooltip</param>
        /// <param name="s_Text">Text of the control</param>
        /// <param name="s_ControlID">Dynamic control ID</param>
        /// <param name="s_UpdatedDate">Updated Date</param>
        /// <returns>Link Button</returns>
        private LinkButton AddLinkButton(string s_Tooltip, string s_Text, string s_ControlID, string s_UpdatedDate)
        {
            try
            {
                using (LinkButton linkButton = new LinkButton())
                {
                    linkButton.ToolTip = s_Tooltip;
                    linkButton.Text = s_Text;
                    linkButton.ID = s_ControlID;
                    linkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    linkButton.Style.Add("cursor", "pointer");
                    linkButton.Attributes.Add("onclick", "return ViewDocuments(this, '" + s_UpdatedDate + "')");
                    return linkButton;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add Image control and show comments in div
        /// </summary>
        /// <param name="optionDetailsUC">optionDetailsUC page object</param>
        /// <param name="s_OperationDate">OperationDate</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="n_Comments">Comments</param>
        /// <returns>Control</returns>
        private Control AddImage(OptionDetailsUC optionDetailsUC, string s_OperationDate, GridViewRowEventArgs e, int n_Comments)
        {
            try
            {
                using (GridView gvCommentsDetails = new GridView())
                {
                    if (ac_GrantDetails.dt_UpdatedAsOnDataComments.Rows.Count > 0 && !string.IsNullOrEmpty(s_OperationDate))
                    {
                        DataRow[] dr = ac_GrantDetails.dt_UpdatedAsOnDataComments.Select("[Updated On] = '" + s_OperationDate + "'");
                        if (dr.Count() > 0)
                        {
                            gvCommentsDetails.RowDataBound += optionDetailsUC.gvCommentsDetails_RowDataBound;
                            optionDetailsUC.n_ComIndex = 0;
                            optionDetailsUC.n_Com_DataUpdatedAsOn = 0;
                            gvCommentsDetails.DataSource = dr.Count() > 0 ? dr.CopyToDataTable() : new DataTable();
                            gvCommentsDetails.DataBind();
                            GridviewProperties(gvCommentsDetails);
                            System.Web.UI.HtmlControls.HtmlGenericControl div = new System.Web.UI.HtmlControls.HtmlGenericControl("div");
                            div.Attributes.Add("id", "divForRowNumber" + e.Row.RowIndex + s_OperationDate.Replace("/", ""));
                            div.Controls.Add(gvCommentsDetails);
                            div.Attributes.Add("style", "position:absolute;display:none;background-color: #4C0000; right: 1.5%; padding: 3px; width:475px;");

                            using (Image image = new Image())
                            {
                                image.ImageUrl = "~/View/App_Themes/images/View.png";
                                image.Attributes.Add("style", "cursor: pointer; cursor: hand;");
                                image.Attributes.Add("onmouseover", "document.getElementById('" + "divForRowNumber" + e.Row.RowIndex + s_OperationDate.Replace("/", "") + "').style.display = 'block'; ");
                                image.Attributes.Add("onmouseout", "document.getElementById('" + "divForRowNumber" + e.Row.RowIndex + s_OperationDate.Replace("/", "") + "').style.display = 'none'; ");
                                e.Row.Cells[n_Comments].Controls.Add(image);
                                e.Row.Cells[n_Comments].Controls.Add(div);
                                e.Row.Cells[n_Comments].HorizontalAlign = HorizontalAlign.Center;
                                e.Row.Cells[n_Comments].Attributes.Add("style", "word-break:break-all;word-wrap:break-word");
                                return image;
                            }
                        }
                    }
                }
                return new Control();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add lock image
        /// </summary>
        /// <param name="s_ToolTip">Tooltip text</param>
        /// <param name="s_ImagePath">Image path</param>
        /// <param name="s_IsLocked">Locked status</param>
        /// <returns>Image control</returns>
        private Control AddLockImage(string s_ToolTip, string s_ImagePath, string s_IsLocked)
        {
            if (s_IsLocked.Equals("TRUE"))
            {
                using (Image image = new Image())
                {
                    image.ImageUrl = s_ImagePath;
                    return image;
                }
            }
            return new Control();
        }

        /// <summary>
        /// This method is used to merge cells
        /// </summary>
        /// <param name="gridView">GridView</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="n_ReportYear">ReportYear cell index</param>
        /// <param name="RowIndex">RowIndex</param>
        /// <param name="Count">Count</param>
        private void MergeCells(GridView gridView, GridViewRowEventArgs e, int n_ReportYear, ref int RowIndex, ref int Count)
        {
            for (int intLoop = 1; intLoop <= e.Row.RowIndex; intLoop++)
            {
                Count++;
                if ((!gridView.Rows[e.Row.RowIndex - intLoop].Cells[n_ReportYear].Text.Equals(string.Empty)) && (e.Row.Cells[n_ReportYear].Text == gridView.Rows[e.Row.RowIndex - intLoop].Cells[n_ReportYear].Text))
                {
                    RowIndex = intLoop;
                    break;
                }

            }

            if (e.Row.Cells[n_ReportYear].Text == gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_ReportYear].Text)
            {
                e.Row.Cells[n_ReportYear].Text = e.Row.Cells[n_ReportYear].Text = "";
                e.Row.Cells[n_ReportYear].Visible = e.Row.Cells[n_ReportYear].Visible = false;
                gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_ReportYear].RowSpan = gridView.Rows[e.Row.RowIndex - RowIndex].Cells[n_ReportYear].RowSpan = Count;
            }
        }

        #region Common method to bind GridView CSS
        /// <summary>
        /// Common method to bind properties of gridview
        /// </summary>
        /// <param name="gv">GridView</param>
        private void GridviewProperties(GridView gv)
        {
            gv.CssClass = "Grid";
            gv.RowStyle.CssClass = "gridItems";
            gv.HeaderStyle.CssClass = "gridHeader";
            gv.SelectedRowStyle.CssClass = "gridItemsSelected";
            gv.CellPadding = 6;
            gv.CellSpacing = 0;
        }

        #endregion

        /// <summary>
        /// This method is used to add ImageButton in gridview
        /// </summary>
        /// <param name="optionDetailsUC">OptionDetailsUC page object</param>
        /// <param name="s_Tooltip">Tooltip</param>
        /// <param name="s_ControlID">ControlID</param>
        /// <param name="s_ImagePath">ImagePath</param>
        /// <param name="s_UpdatedDate">UpdatedDate</param>
        /// <param name="s_GridViewID">GridViewID</param>
        /// <param name="s_FRate">Forfeiture Rate</param>
        /// <param name="s_OptionDetailsPrevYear">s_OptionDetails Previous Year</param>
        /// <param name="s_DocumentName">Document Name</param>
        /// <param name="s_IsLocked">IsLocked</param>
        /// <returns>ImageButton</returns>
        private ImageButton AddImageButton(OptionDetailsUC optionDetailsUC, string s_Tooltip, string s_ControlID, string s_ImagePath, string s_UpdatedDate, string s_GridViewID, string s_FRate, string s_OptionDetailsPrevYear, string s_DocumentName, string s_IsLocked)
        {
            try
            {
                ImageButton imgButton = new ImageButton();
                imgButton.Enabled = s_IsLocked.Equals("FALSE");
                imgButton.ToolTip = s_Tooltip;
                imgButton.ID = s_ControlID;
                imgButton.ImageUrl = s_ImagePath;
                imgButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                switch (s_GridViewID)
                {
                    case "gvHistory":
                        if (s_ControlID.Split('|').First().Replace("\\", "").Equals("imgDelete"))
                        {
                            imgButton.Attributes.Add("onclick", "return DeleteRecord(this)");
                        }
                        imgButton.Click += optionDetailsUC.imgButton_Click;
                        break;

                    case "OptionDetails":
                        imgButton.ID = s_OptionDetailsPrevYear;
                        imgButton.Attributes.Add("onclick", "return ShowOptionDetail(this, '" + userSessionInfo.ACC_CalculationMethod + "', '" + s_FRate + "')");
                        break;

                    case "childGridView":
                        imgButton.ID = s_OptionDetailsPrevYear;
                        imgButton.Attributes.Add("onclick", "return ShowOptionDetail(this, '" + userSessionInfo.ACC_CalculationMethod + "', '" + s_FRate + "')");
                        break;

                    case "UpdatedAsOn":
                        imgButton.CssClass = s_ControlID;
                        imgButton.Attributes.Add("onclick", "return DownloadOrDeleteDoc(this, '" + s_DocumentName + "', '" + s_UpdatedDate + "', 'Code Behind')");
                        break;
                }
                return imgButton;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// RowDataBound event for gvOptionDetails
        /// </summary>
        /// <param name="optionDetailsUC">OptionDetailsUC page object</param>
        /// <param name="e">GridViewRowEventArgs of gvOptionDetails</param>
        /// <param name="n_OpIndex">int Index</param>
        /// <param name="n_EmployeeID">int EmployeeID</param>
        /// <param name="n_EmployeeName">int EmployeeName</param>
        /// <param name="n_SchemeName">int SchemeName</param>
        /// <param name="n_Granted">int Granted Options</param>
        /// <param name="n_Cancelled">int Cancelled Options</param>
        /// <param name="n_VCancelled">int Vested Cancelled Options</param>
        /// <param name="n_UCancelled">int Unvested Cancelled Options</param>
        /// <param name="n_Lapsed">int Lapsed Options</param>
        /// <param name="n_Execrised">int Execrised Options</param>
        /// <param name="n_Unvested">int Unvested Options</param>
        /// <param name="n_VestedExercisable">int Vested Exercisable Options</param>
        /// <param name="n_Outstanding">int Outstanding Options</param>
        /// <param name="n_ForfeitureRate">int ForfeitureRate</param>
        /// <param name="n_Action">int Action</param>
        /// <param name="sender">has some action perform on control</param>
        /// <param name="n_RowIndex">int RowIndex</param>
        /// <param name="n_Rate">int Rate</param>
        /// <param name="n_GrantOptionID">int GrantOptionID</param>
        internal void gvOptionDetails_RowDataBound(OptionDetailsUC optionDetailsUC, GridViewRowEventArgs e, ref int n_OpIndex, ref int n_EmployeeID, ref int n_EmployeeName, ref int n_SchemeName, ref int n_Granted, ref int n_Cancelled, ref int n_VCancelled, ref int n_UCancelled, ref int n_Lapsed, ref int n_Execrised, ref int n_Unvested, ref int n_VestedExercisable, ref int n_Outstanding, ref int n_ForfeitureRate, ref int n_Action, object sender, ref int n_RowIndex, ref int n_Rate, ref int n_GrantOptionID)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "GRANT OPTION ID":
                                    n_GrantOptionID = n_OpIndex;

                                    break;
                                case "EMPLOYEE ID":
                                    n_EmployeeID = n_OpIndex;
                                    break;

                                case "EMPLOYEE NAME":
                                    n_EmployeeName = n_OpIndex;
                                    break;

                                case "GRANTED":
                                    n_Granted = n_OpIndex;
                                    break;

                                case "CANCELLED":
                                    n_Cancelled = n_OpIndex;
                                    break;

                                case "VESTED CANCELLED":
                                    n_VCancelled = n_OpIndex;
                                    break;

                                case "UNVESTED CANCELLED":
                                    n_UCancelled = n_OpIndex;
                                    break;

                                case "LAPSED":
                                    n_Lapsed = n_OpIndex;
                                    break;

                                case "EXERCISED":
                                    n_Execrised = n_OpIndex;
                                    break;

                                case "UNVESTED":
                                    n_Unvested = n_OpIndex;
                                    break;

                                case "VESTED AND EXERCISABLE":
                                    n_VestedExercisable = n_OpIndex;
                                    break;

                                case "OUTSTANDING":
                                    n_Outstanding = n_OpIndex;
                                    break;

                                case "FORFEITURE RATE":
                                    n_ForfeitureRate = n_OpIndex;
                                    break;

                                case "ACTION":
                                    n_Action = n_OpIndex;
                                    break;

                                case "RATE":
                                    n_Rate = n_OpIndex;
                                    e.Row.Cells[n_Rate].Visible = false;
                                    break;
                            }
                            n_OpIndex = n_OpIndex + 1;
                        }
                        e.Row.Cells[18].Visible = false;
                        break;

                    case DataControlRowType.DataRow:
                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!e.Row.Cells[n_Granted].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_Granted].Text = Convert.ToDouble(e.Row.Cells[n_Granted].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Granted].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Granted].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_Granted].HorizontalAlign = HorizontalAlign.Right;
                            }

                            if (!e.Row.Cells[n_Cancelled].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_Cancelled].Text = Convert.ToDouble(e.Row.Cells[n_Cancelled].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Cancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Cancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_Cancelled].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_VCancelled].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_VCancelled].Text = Convert.ToDouble(e.Row.Cells[n_VCancelled].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_VCancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_VCancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_VCancelled].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_UCancelled].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_UCancelled].Text = Convert.ToDouble(e.Row.Cells[n_UCancelled].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_UCancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_UCancelled].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_UCancelled].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_Lapsed].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_Lapsed].Text = Convert.ToDouble(e.Row.Cells[n_Lapsed].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Lapsed].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Lapsed].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_Lapsed].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_Execrised].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_Execrised].Text = Convert.ToDouble(e.Row.Cells[n_Execrised].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Execrised].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Execrised].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_Execrised].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_Unvested].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_Unvested].Text = Convert.ToDouble(e.Row.Cells[n_Unvested].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Unvested].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Unvested].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_Unvested].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_VestedExercisable].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_VestedExercisable].Text = Convert.ToDouble(e.Row.Cells[n_VestedExercisable].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_VestedExercisable].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_VestedExercisable].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_VestedExercisable].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_Outstanding].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_Outstanding].Text = Convert.ToDouble(e.Row.Cells[n_Outstanding].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_Outstanding].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_Outstanding].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_Outstanding].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[n_ForfeitureRate].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_ForfeitureRate].Text = Convert.ToDouble(e.Row.Cells[n_ForfeitureRate].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_ForfeitureRate].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_ForfeitureRate].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_ForfeitureRate].HorizontalAlign = HorizontalAlign.Right;
                            }
                            else
                            {
                                e.Row.Cells[n_ForfeitureRate].Text = e.Row.Cells[n_Rate].Text;
                            }
                        }
                        #endregion

                        string s_EmployeeID = e.Row.Cells[n_EmployeeID].Text, s_GrantOptionID = e.Row.Cells[n_GrantOptionID].Text;

                        var UplodedDataCollection = ac_GrantDetails.dt_OptionDetailsUploadedData.AsEnumerable()
                                                   .Where
                                                   (
                                                       s => s.Field<DateTime>("OPERATION_DATE").Date == DateTime.Parse(optionDetailsUC.txtReportDate.Text).Date && 
                                                            s.Field<string>("Employee ID").Equals(s_EmployeeID) && 
                                                            s.Field<string>("Grant Option ID").Equals(s_GrantOptionID)
                                                    );

                        if (UplodedDataCollection.Count() > 0)
                        {
                            for (int i = 0; i < e.Row.Cells.Count; i++)
                                e.Row.Cells[i].BackColor = System.Drawing.ColorTranslator.FromHtml("#e6f2ff");

                            optionDetailsUC.lblDataUpdatedNote.Style.Remove("display");
                        }
                        e.Row.Cells[n_Rate].Visible = false;
                        e.Row.Cells[18].Visible = false;
                        e.Row.Cells[n_EmployeeID].HorizontalAlign = HorizontalAlign.Left;
                        e.Row.Cells[n_EmployeeName].HorizontalAlign = HorizontalAlign.Left;
                        e.Row.Cells[n_Granted].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_Cancelled].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_VCancelled].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_UCancelled].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_Lapsed].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_Execrised].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_Unvested].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_VestedExercisable].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_Outstanding].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_ForfeitureRate].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;

                        string s_OptionDetailsPrevYear = "OptionCancelled|" + e.Row.Cells[n_Cancelled].Text +
                                                         "|OptionUnvCancelled|" + e.Row.Cells[n_UCancelled].Text +
                                                         "|OptionVestCancelled|" + e.Row.Cells[n_VCancelled].Text +
                                                         "|OptionLapsed|" + e.Row.Cells[n_Lapsed].Text +
                                                         "|OptionExcercised|" + e.Row.Cells[n_Execrised].Text +
                                                         "|OptionUnvested|" + e.Row.Cells[n_Unvested].Text +
                                                         "|OptionVeAndExe|" + e.Row.Cells[n_VestedExercisable].Text +
                                                         "|OptionOutstanding|" + e.Row.Cells[n_Outstanding].Text +
                                                         "|ForfeitureRate|" + e.Row.Cells[n_ForfeitureRate].Text +
                                                         "|Date," + Convert.ToDateTime(e.Row.Cells[18].Text).ToString("dd/MMM/yyyy"); ;

                        e.Row.Cells[n_Action].Controls.Add(userSessionInfo.ACC_CalculationMethod.Equals(2) ? AddImageToCell() : AddImageButton(optionDetailsUC, "Click here to edit record", e.Row.Cells[n_EmployeeID].Text, "~/View/App_Themes/images/Edit.png", string.Empty, "OptionDetails", e.Row.Cells[n_Rate].Text, s_OptionDetailsPrevYear, string.Empty, "FALSE"));

                        if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                        {
                            GridView parentGrid = (GridView)sender;
                            using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                            {
                                NewTotalRow.Font.Bold = true;
                                NewTotalRow.CssClass = "gridItems gvChildGridOp gridData";
                                NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFE0CC");

                                using (TableCell HeaderCell = new TableCell())
                                {
                                    HeaderCell.Attributes.Add("Class", "gvChildGridOp");
                                    HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                    HeaderCell.Height = 10;
                                    HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                                    HeaderCell.ColumnSpan = 15;
                                    HeaderCell.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFECE0");

                                    using (GridView childGrid = new GridView())
                                    {
                                        childGrid.CssClass = "Grid gvChildGridOpDetails";
                                        childGrid.RowStyle.CssClass = "gridItems";
                                        childGrid.CellPadding = 3;
                                        childGrid.CellSpacing = 0;
                                        childGrid.HeaderStyle.CssClass = "HeaderStyle";

                                        childGrid.RowDataBound += optionDetailsUC.childGrid_RowDataBound;
                                        childGrid.DataSource = new System.Data.DataView(ac_GrantDetails.dt_OptionDetailsDataVestwise).ToTable("DT", true, new string[] { "Grant Option ID", "Vesting Date", "Vesting Period Number", "Granted", "Cancelled", "Vested Cancelled", "Unvested Cancelled", "Lapsed", "Exercised", "Unvested", "Vested and Exercisable", "Outstanding", "Forfeiture Rate", "Action", "Rate", "OPERATION_DATE" }).Copy().Select("[Grant Option ID]='" + e.Row.Cells[0].Text + "'").CopyToDataTable();
                                        childGrid.DataBind();

                                        HeaderCell.Controls.Add(childGrid);
                                        NewTotalRow.Cells.Add(HeaderCell);
                                        parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + n_RowIndex, NewTotalRow);
                                    }
                                }
                                using (TableCell HeaderCell = new TableCell())
                                {
                                    HeaderCell.Attributes.Add("Class", "gvChildGridOp");
                                    HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                    HeaderCell.Height = 10;
                                    HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                                    HeaderCell.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFECE0");

                                    using (Button button = new Button())
                                    {
                                        button.CssClass = "cButton";
                                        button.Visible = !string.IsNullOrEmpty(ac_GrantDetails.s_IsEditedRecordLocked) ? ac_GrantDetails.s_IsEditedRecordLocked.Equals("FALSE") : true;
                                        button.Text = "Save";
                                        button.Attributes.Add("onclick", "return SaveVestwiseData(this, " + userSessionInfo.ACC_CalculationMethod + ", '" + (string.IsNullOrEmpty(ac_SearchGrantDetails.s_LatestOperationDate) ? string.Empty : Convert.ToString(Convert.ToDateTime(ac_SearchGrantDetails.s_LatestOperationDate).Date.ToString("dd-MM-yyyy"))) + "')");
                                        HeaderCell.Controls.Add(button);
                                        NewTotalRow.Cells.Add(HeaderCell);

                                    }
                                }
                                parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + n_RowIndex, NewTotalRow);
                                n_RowIndex++;
                            }
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Uploaded files grid-view row data bound event
        /// </summary>
        /// <param name="optionDetailsUC">optionDetailsUC page object</param>
        /// <param name="e">event args</param>
        /// <param name="n_DocIndex">n_DocIndex</param>
        /// <param name="n_Doc_File_Name">n_Doc_File_Name</param>
        /// <param name="n_Doc_Download">n_Doc_Download</param>
        /// <param name="n_Doc_Delete">n_Doc_Delete</param>
        /// <param name="n_Doc_DataUpdatedAsOn">n_Doc_DataUpdatedAsOn</param>
        internal void gvODUploadedFiles_RowDataBound(OptionDetailsUC optionDetailsUC, GridViewRowEventArgs e, ref int n_DocIndex, ref int n_Doc_File_Name, ref int n_Doc_Download, ref int n_Doc_Delete, ref int n_Doc_DataUpdatedAsOn)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "UPDATED ON":
                                    n_Doc_DataUpdatedAsOn = n_DocIndex;
                                    break;

                                case "FILE NAME":
                                    n_Doc_File_Name = n_DocIndex;
                                    break;

                                case "DOWNLOAD":
                                    n_Doc_Download = n_DocIndex;
                                    break;

                                case "DELETE":
                                    n_Doc_Delete = n_DocIndex;
                                    break;
                            }
                            n_DocIndex++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_Doc_Download].Controls.Add(AddImageButton(optionDetailsUC, "Click here to edit", "imgDownload", "~/View/App_Themes/images/Download.png", Convert.ToString(e.Row.Cells[n_Doc_DataUpdatedAsOn].Text), "UpdatedAsOn", string.Empty, string.Empty, Convert.ToString(e.Row.Cells[n_Doc_File_Name].Text), "FALSE"));
                        e.Row.Cells[n_Doc_Delete].Controls.Add(AddImageButton(optionDetailsUC, "Click here to edit", "imgDelete", "~/View/App_Themes/images/Delete.png", Convert.ToString(e.Row.Cells[n_Doc_DataUpdatedAsOn].Text), "UpdatedAsOn", string.Empty, string.Empty, Convert.ToString(e.Row.Cells[n_Doc_File_Name].Text), "FALSE"));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// RowDataBound event for gvCommentsDetails
        /// </summary>
        /// <param name="optionDetailsUC">Page object OptionDetailsUC</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="n_ComIndex">int ComIndex</param>
        /// <param name="n_Com_DataUpdatedAsOn">int DataUpdatedAsOn</param>
        internal void gvCommentsDetails_RowDataBound(OptionDetailsUC optionDetailsUC, GridViewRowEventArgs e, ref int n_ComIndex, ref int n_Com_DataUpdatedAsOn)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "UPDATED ON":
                                    n_Com_DataUpdatedAsOn = n_ComIndex;
                                    break;
                            }
                            n_ComIndex++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_Com_DataUpdatedAsOn].Width = 100;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Row Data Bound Event Of Child GridView
        /// </summary>
        /// <param name="sender">Child GridView</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="optionDetailsUC">OptionDetailsUC object</param>
        internal void childGrid_RowDataBound(object sender, GridViewRowEventArgs e, OptionDetailsUC optionDetailsUC)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        e.Row.Cells[14].Visible = e.Row.Cells[15].Visible = false;
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!e.Row.Cells[3].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[3].Text = Convert.ToDouble(e.Row.Cells[3].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[3].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[3].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Right;
                            }

                            if (!e.Row.Cells[4].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[4].Text = Convert.ToDouble(e.Row.Cells[4].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[4].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[4].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[5].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[5].Text = Convert.ToDouble(e.Row.Cells[5].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[5].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[5].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[6].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[6].Text = Convert.ToDouble(e.Row.Cells[6].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[6].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[6].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[7].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[7].Text = Convert.ToDouble(e.Row.Cells[7].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[7].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[7].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[7].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[8].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[8].Text = Convert.ToDouble(e.Row.Cells[8].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[8].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[8].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[8].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[9].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[9].Text = Convert.ToDouble(e.Row.Cells[9].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[9].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[9].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[9].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[10].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[10].Text = Convert.ToDouble(e.Row.Cells[10].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[10].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[10].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[10].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[11].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[11].Text = Convert.ToDouble(e.Row.Cells[11].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[11].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[11].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[11].HorizontalAlign = HorizontalAlign.Right;
                            }
                            if (!e.Row.Cells[12].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[12].Text = Convert.ToDouble(e.Row.Cells[12].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[12].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[12].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[12].HorizontalAlign = HorizontalAlign.Right;
                            }
                            else
                            {
                                e.Row.Cells[12].Text = e.Row.Cells[14].Text;
                            }
                        }
                        #endregion

                        string s_OptionDetailsPrevYear = "OptionCancelled|" + e.Row.Cells[4].Text +
                                                         "|OptionUnvCancelled|" + e.Row.Cells[5].Text +
                                                         "|OptionVestCancelled|" + e.Row.Cells[6].Text +
                                                         "|OptionLapsed|" + e.Row.Cells[7].Text +
                                                         "|OptionExcercised|" + e.Row.Cells[8].Text +
                                                         "|OptionUnvested|" + e.Row.Cells[9].Text +
                                                         "|OptionVeAndExe|" + e.Row.Cells[10].Text +
                                                         "|OptionOutstanding|" + e.Row.Cells[11].Text +
                                                         "|ForfeitureRate|" + e.Row.Cells[12].Text +
                                                         "|Date|" + Convert.ToDateTime(e.Row.Cells[15].Text).ToString("dd/MMM/yyyy");

                        e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[7].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[8].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[9].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[10].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[11].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[12].HorizontalAlign = HorizontalAlign.Right;

                        e.Row.Cells[13].Controls.Add(AddImageButton(null, "Click here to add details", "lbtnAddDetails", "~/View/App_Themes/images/Edit.png", string.Empty, "childGridView", e.Row.Cells[14].Text, s_OptionDetailsPrevYear, string.Empty, "FALSE"));
                        e.Row.Cells[14].Visible = e.Row.Cells[15].Visible = false;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This metod is used to create image control
        /// </summary>
        /// <returns>Image control</returns>
        private Image AddImageToCell()
        {
            try
            {
                using (Image image = new Image())
                {
                    image.ImageUrl = "~/View/App_Themes/images/plus.png";
                    image.Attributes.Add("style", "cursor: pointer; cursor: hand;");
                    image.Attributes.Add("onclick", "return ShowDetailsOpt(this)");
                    return image;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to change pages of gridview.
        /// </summary>
        /// <param name="e">gridview event arguement e</param>
        /// <param name="optionDetailsUC">OptionDetailsUC master object</param>
        internal void PageIndexChanging(GridViewPageEventArgs e, OptionDetailsUC optionDetailsUC)
        {
            try
            {
                optionDetailsUC.gvOptionDetails.PageIndex = e.NewPageIndex;
                SearchRecords(optionDetailsUC);
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// This method is used to Encrypt query string that has to pass on to report page  for report view.
        /// </summary>
        /// <param name="optionDetailsUC">object of optionDetailsUC page</param>
        internal void EncryptData(OptionDetailsUC optionDetailsUC)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                optionDetailsUC.hdnQueryStringParams.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=10").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                optionDetailsUC.hdnQueryStringParams.Dispose();
            }
        }

        /// <summary>
        /// This method is used to show update all button
        /// </summary>
        /// <param name="optionDetailsUC">page object</param>
        internal void ShowUpdateAllButton(OptionDetailsUC optionDetailsUC)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accountingProperties.PageName = CommonConstantModel.s_UpdateAllFlage;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingProperties.Opration_Date = Convert.ToDateTime(optionDetailsUC.txtReportDate.Text);
                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                switch (accountingCRUDProperties.a_result)
                {
                    case 1:
                        optionDetailsUC.btnUpdateAll.Enabled = true;
                        optionDetailsUC.btnUpdateAll.ToolTip = "Click here to update all grants";
                        break;
                }
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~OptionsDetailsModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}