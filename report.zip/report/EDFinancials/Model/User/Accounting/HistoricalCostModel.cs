﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using System.Drawing;
using System.Collections.Generic;
using System.Collections;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// Historical Cost Model class
    /// </summary>
    public class HistoricalCostModel : BaseModel, IDisposable
    {

        /// <summary>
        /// This DataRow is used to store filtered rows of filtered DataTable 
        /// </summary>
        DataRow[] dr = null;
        DateTime? dt = null;
        #region Default constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public HistoricalCostModel()
        {
            if (ac_HistoricalCost == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_HistoricalCost);
                ac_HistoricalCost = (CommonModel.AC_HistoricalCost)HttpContext.Current.Session[CommonConstantModel.s_AC_HistoricalCost];
            }
        }
        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_CanNotEditSettingsMsg = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveToolTip = string.Empty, s_BtnUpdateText = string.Empty, s_BtnUpdateTooltip = string.Empty, s_BtnVUpdateText = string.Empty, s_BtnVUpdateTooltip = string.Empty, s_Search = string.Empty, s_Delete = string.Empty, s_BtnSNext = string.Empty, s_BtnSNextTooltip = string.Empty,
        s_CanNotDelete = string.Empty, s_CanNotAdd = string.Empty;

        #endregion

        #region Common Bind Methods

        /// <summary>
        /// Enables or disables control according to roles assigned to user.
        /// </summary>
        /// <param name="historicalCost">historical Cost</param>
        internal void CheckEmployeeRolePriviledges(HistoricalCost historicalCost)
        {
            try
            {

                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuEmployeeMaster;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    historicalCost.btnAdd.Enabled = false;
                                    historicalCost.btnDelete.Enabled = false;
                                    historicalCost.btnSave.Enabled = false;
                                    historicalCost.btnSearch.Enabled = true;
                                    break;

                                case "ADD":
                                    historicalCost.btnAdd.Enabled = true;
                                    historicalCost.btnSave.Enabled = true;
                                    historicalCost.btnCancel.Enabled = true;
                                    historicalCost.btnSearch.Enabled = true;
                                    historicalCost.btnDelete.Enabled = false;

                                    break;

                                case "EDIT":

                                    historicalCost.btnSearch.Enabled = true;
                                    historicalCost.btnAdd.Enabled = (from b in dt_RolePerviledges.AsEnumerable()
                                                                     where b.Field<string>("PRIVILEDGES") == "ADD"
                                                                     select b.Field<string>("PRIVILEDGES")).Distinct().Count() > 0 ? true : false;
                                    historicalCost.btnDelete.Enabled = false;
                                    break;

                                case "DELETE":
                                    historicalCost.btnDelete.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind UI controls
        /// </summary>
        /// <param name="historicalCost">Historical Cost page object</param>
        internal void BindUI(HistoricalCost historicalCost)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_HistoricalCost.dt_HistoricalCostUI == null || ac_HistoricalCost.dt_HistoricalCostUI.Rows.Count.Equals(0))
                    {
                        ac_HistoricalCost.dt_HistoricalCostUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10_UI);
                    }

                    if ((ac_HistoricalCost.dt_HistoricalCostUI != null) && (ac_HistoricalCost.dt_HistoricalCostUI.Rows.Count > 0))
                    {
                        foreach (Control control in historicalCost.dvMain.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, historicalCost, ac_HistoricalCost.dt_HistoricalCostUI, (Label)control, null, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, historicalCost, ac_HistoricalCost.dt_HistoricalCostUI, null, (TextBox)control, null, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, historicalCost, ac_HistoricalCost.dt_HistoricalCostUI, null, null, (Button)control, null, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcCheckbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeCheckBox, historicalCost, ac_HistoricalCost.dt_HistoricalCostUI, null, null, null, (CheckBox)control, null, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, historicalCost, ac_HistoricalCost.dt_HistoricalCostUI, null, null, null, null, (RadioButton)control, null, null, null);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, historicalCost, ac_HistoricalCost.dt_HistoricalCostUI, null, null, null, null, null, (BaseValidator)control, null, null);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, historicalCost, ac_HistoricalCost.dt_HistoricalCostUI, null, null, null, null, null, null, (BaseValidator)control, null);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, historicalCost, ac_HistoricalCost.dt_HistoricalCostUI, null, null, null, null, null, null, null, (GridView)control);
                                    break;
                            }

                        }
                        historicalCost.lblAHSHeader.Text = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID='lblAHSHeader'"))[0]["LabelName"]);
                        s_BtnUpdateText = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID = 'btnUpdate'"))[0]["LabelName"]);
                        s_BtnUpdateTooltip = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID = 'btnUpdate'"))[0]["LabelToolTip"]);
                        s_BtnVUpdateText = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID = 'btnUpdate'"))[0]["LabelName"]);
                        s_BtnVUpdateTooltip = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID = 'btnUpdate'"))[0]["LabelToolTip"]);
                        s_BtnSNext = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID='btnSNext'"))[0]["LabelName"]);
                        s_BtnSNextTooltip = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID='btnSNext'"))[0]["LabelToolTip"]);
                        historicalCost.lblVestPresent.Text = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID='lblVestPresent'"))[0]["LabelName"]);
                        historicalCost.lblVestClient.Text = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID='lblVestClient'"))[0]["LabelName"]);
                        s_CanNotEditSettingsMsg = accountingServiceClient.GetAccounting_L10N("lblHCULockedGrants", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                        s_CanNotDelete = accountingServiceClient.GetAccounting_L10N("lblHCDLockedGrants", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                        s_CanNotAdd = accountingServiceClient.GetAccounting_L10N("lblHCCanNotAddLockedGrants", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="historicalCost">The historical Cost class object</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="label">The label control object</param>
        /// <param name="textBox">The text-box control object</param>
        /// <param name="button">The button control object</param>
        /// <param name="checkBox">The CheckBox control object</param>
        /// <param name="radioButton">radiobutton control object</param>
        /// <param name="ReqValidator">validator control object</param>
        /// <param name="RegExpValidator">validator control object</param>
        /// <param name="gridView">gridview control object</param>
        private void BindPropertiesToControl(string s_cntrlType, HistoricalCost historicalCost, DataTable Dt_Get_L10N_UI, Label label, TextBox textBox, Button button, CheckBox checkBox, RadioButton radioButton, BaseValidator ReqValidator, BaseValidator RegExpValidator, GridView gridView)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeCheckBox:
                    checkBox.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelName"]);
                    checkBox.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRadioButton:
                    radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                    radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    gridView.EmptyDataText = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + gridView.ID + "'"))[0]["LabelName"]);
                    break;

                case CommonConstantModel.s_cntrlTypeTextBox:
                    break;
            }
        }

        #endregion

        #region Bind Controls
        /// <summary>
        /// This method is used to Bind Data to dropdowns
        /// </summary>
        /// <param name="historicalCost">Historical Cost page object</param>
        internal void BindControls(HistoricalCost historicalCost)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_HistoricalCost;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "POPULATE_CONTROLS";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_HistoricalCost.ds_HistoricalCost = accountingCRUDProperties.ds_Result;

                    if (ac_HistoricalCost.ds_HistoricalCost != null && ac_HistoricalCost.ds_HistoricalCost.Tables.Count > 0)
                    {
                        if (Convert.ToString(ac_HistoricalCost.ds_HistoricalCost.Tables[0].Rows[0]["Method"]).Trim().Equals("rdbVMCC01"))
                        {
                            historicalCost.rdbSVMCC01.Checked = true;
                            historicalCost.rdbVMCC01.Checked = true;
                        }
                        else
                        {
                            historicalCost.rdbSVMCC02.Checked = true;
                            historicalCost.rdbVMCC02.Checked = true;
                        }

                        BindSearchDDList(historicalCost, ac_HistoricalCost.ds_HistoricalCost);

                        ac_HistoricalCost.dt_temp_HC_details = ac_HistoricalCost.ds_HistoricalCost.Tables[4];
                        ac_HistoricalCost.dt_SP_HC_details = ac_HistoricalCost.ds_HistoricalCost.Tables[5];
                        ac_HistoricalCost.dt_Maintaind_HCost = ac_HistoricalCost.ds_HistoricalCost.Tables[6];
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// THis method is used to bind the Search Dropdown 
        /// </summary>
        /// <param name="historicalCost">historical Cost Page object</param>
        /// <param name="dataSet">dataSet object</param>
        private void BindSearchDDList(HistoricalCost historicalCost, DataSet dataSet)
        {
            //Bind EMP ID drop-down 
            ////historicalCost.MultiSelectSEmpID.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[1].AsEnumerable()
            ////                                                              where b.Field<string>("EMPID") != null
            ////                                                              select b.Field<string>("EMPID")).Distinct();
            ////historicalCost.MultiSelectSEmpID.DataBind();

            //////Bind search Emp Name drop-down 
            ////historicalCost.MultiSelectSEmpName.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[1].AsEnumerable()
            ////                                                                where b.Field<string>("EMPNAME") != null
            ////                                                                select b.Field<string>("EMPNAME")).Distinct(); ;
            ////historicalCost.MultiSelectSEmpName.DataBind();

            ////Bind GRANT OPTION ID drop-down 
            //historicalCost.MultiSelectSGrantOptionID.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[2].AsEnumerable()
            //                                                                      where b.Field<string>("GRANT OPTION ID") != null
            //                                                                      select b.Field<string>("GRANT OPTION ID")).Distinct(); ;
            //historicalCost.MultiSelectSGrantOptionID.DataBind();

            ////Bind GRANT REGISTRATION ID drop-down 
            //historicalCost.MultiSelectSGrantRegID.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[2].AsEnumerable()
            //                                                                   where b.Field<string>("GRANT REGISTRATION ID") != null
            //                                                                   select b.Field<string>("GRANT REGISTRATION ID")).Distinct();
            //historicalCost.MultiSelectSGrantRegID.DataBind();

            ////Bind Scheme Name drop-down 
            //historicalCost.MultiSelectSSchemeName.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[2].AsEnumerable()
            //                                                                   where b.Field<string>("Scheme Title") != null
            //                                                                   select b.Field<string>("Scheme Title")).Distinct();
            //historicalCost.MultiSelectSSchemeName.DataBind();

            ////Bind Location drop-down 
            //historicalCost.MultiSelectSLocation.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[3].AsEnumerable()
            //                                                                 where (b.Field<string>("FIELDNAME") != null && b.Field<string>("FIELDNAME").ToUpper() == "LOCATION")
            //                                                                 select b.Field<string>("PARAMVALUE")).Distinct(); ;
            //historicalCost.MultiSelectSLocation.DataBind();

            ////Bind Department drop-down 
            //historicalCost.MultiSelectSDepartment.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[3].AsEnumerable()
            //                                                                   where (b.Field<string>("FIELDNAME") != null && b.Field<string>("FIELDNAME").ToUpper() == "DEPARTMENT")
            //                                                                   select b.Field<string>("PARAMVALUE")).Distinct();
            //historicalCost.MultiSelectSDepartment.DataBind();

            ////Bind SBU drop-down 
            //historicalCost.MultiSelectSSBU.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[3].AsEnumerable()
            //                                                            where (b.Field<string>("FIELDNAME") != null && b.Field<string>("FIELDNAME").ToUpper() == "SBU")
            //                                                            select b.Field<string>("PARAMVALUE")).Distinct();
            //historicalCost.MultiSelectSSBU.DataBind();

            ////Bind ENTITY drop-down 
            //historicalCost.MultiSelectSEntity.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[3].AsEnumerable()
            //                                                               where (b.Field<string>("FIELDNAME") != null && b.Field<string>("FIELDNAME").ToUpper() == "ENTITY")
            //                                                               select b.Field<string>("PARAMVALUE")).Distinct();
            //historicalCost.MultiSelectSEntity.DataBind();

            ////Bind COST CENTRE drop-down 
            //historicalCost.MultiSelectSCostCentre.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[3].AsEnumerable()
            //                                                                   where (b.Field<string>("FIELDNAME") != null && b.Field<string>("FIELDNAME").ToUpper() == "COST_CENTRE")
            //                                                                   select b.Field<string>("PARAMVALUE")).Distinct();
            //historicalCost.MultiSelectSCostCentre.DataBind();


            //historicalCost.MultiSelectSParameter.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[7].AsEnumerable()
            //                                                                  where b.Field<string>("FIELD_NAME") != null
            //                                                                  select b.Field<string>("FIELD_NAME")).Distinct();
            //historicalCost.MultiSelectSParameter.DataBind();

            //historicalCost.MultiSelectCastAsonDate.chkMultiselect.DataSource = (from b in ac_HistoricalCost.ds_HistoricalCost.Tables[4].AsEnumerable()
            //                                                                    where b.Field<string>("OPDate") != null
            //                                                                    select b.Field<string>("OPDate")).Distinct();

            //historicalCost.MultiSelectCastAsonDate.DataBind();
        }

        #endregion

        #region Add/Filter Data
        /// <summary>
        /// Method is used to filter the data
        /// </summary>
        /// <param name="historicalCost">Historical Cost Page object</param>
        /// <param name="s_buttonName">buttonName object</param>
        public void FilterGridData(HistoricalCost historicalCost, string s_buttonName)
        {
            try
            {
                historicalCost.hdnShowGrid.Value = "Search";
                ac_HistoricalCost.b_IsLocked = false;
                ac_HistoricalCost.IsParameterCheck = string.Empty;
                switch (s_buttonName)
                {
                    case "btnSearch":
                        ac_HistoricalCost.dt_HCFiltered = ac_HistoricalCost.dt_temp_HC_details.Copy();
                        ac_HistoricalCost.dt_HCFiltered.Clear();

                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectSEmpID.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[Employee ID]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectSEmpID.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectSEmpName.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[Employee Name]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectSEmpName.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectSGrantOptionID.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[Grant Option ID]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectSGrantOptionID.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectSGrantRegID.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[Grant Registration ID]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectSGrantRegID.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectSSchemeName.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[SCHEME TITLE]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectSSchemeName.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectSLocation.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[Location]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectSLocation.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectSDepartment.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[Department]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectSDepartment.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectSSBU.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[SBU]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectSSBU.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectSEntity.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[Entity]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectSEntity.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectSCostCentre.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[Cost Centre]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectSCostCentre.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = SearchGrantData(historicalCost.MultiSelectCastAsonDate.chkMultiselect, ac_HistoricalCost.dt_HCFiltered, "[OPDate]", ac_HistoricalCost.IsFirstSelection, "Search", historicalCost.MultiSelectCastAsonDate.txtMultiselect);
                        ac_HistoricalCost.dt_HCFiltered = GrantDateFilter(ac_HistoricalCost.dt_HCFiltered, historicalCost, "Search");
                        ac_HistoricalCost.dt_HCFiltered = GrantDateFilter(ac_HistoricalCost.dt_HCFiltered, historicalCost, "Search_IVORFV");
                        Resetvalues(historicalCost);
                        if ((ac_HistoricalCost.dt_HCFiltered != null && ac_HistoricalCost.dt_HCFiltered.Rows.Count > 0))
                        {
                            historicalCost.gvHistoricalCost.DataSource = ac_HistoricalCost.dt_HCFiltered;
                            historicalCost.gvHistoricalCost.DataBind();
                            historicalCost.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "none");
                        }
                        else
                        {

                            DisplayMessage(historicalCost, "btnSearch");
                            historicalCost.btnDelete.Visible = false;
                            BindNullGrid(historicalCost, "gvHistoricalCost");
                        }
                        ac_HistoricalCost.IsFirstSelection = true;
                        historicalCost.h3AddEdit.Style.Add("display", "none");
                        break;

                    case "btnNext":
                        ac_HistoricalCost.dt_HCEditDetails = new DataTable();
                        ac_HistoricalCost.dt_FilterDetails = ac_HistoricalCost.dt_Add_HC_details.Copy();
                        ac_HistoricalCost.dt_FilterDetails.Clear();
                        ac_HistoricalCost.dt_FilterDetails = GrantDateFilter(ac_HistoricalCost.dt_FilterDetails, historicalCost, "A_Cost_AS_ON");
                        ac_HistoricalCost.dt_FilterDetails = SearchGrantData(historicalCost.MultiSelectEmpID.chkMultiselect, ac_HistoricalCost.dt_FilterDetails, "[Employee ID]", ac_HistoricalCost.IsFirstSelection, "Add", historicalCost.MultiSelectEmpID.txtMultiselect);
                        ac_HistoricalCost.dt_FilterDetails = SearchGrantData(historicalCost.MultiSelectEmpName.chkMultiselect, ac_HistoricalCost.dt_FilterDetails, "[Employee Name]", ac_HistoricalCost.IsFirstSelection, "Add", historicalCost.MultiSelectEmpName.txtMultiselect);
                        ac_HistoricalCost.dt_FilterDetails = SearchGrantData(historicalCost.MultiSelectGrantOptionID.chkMultiselect, ac_HistoricalCost.dt_FilterDetails, "[Grant Option ID]", ac_HistoricalCost.IsFirstSelection, "Add", historicalCost.MultiSelectGrantOptionID.txtMultiselect);
                        ac_HistoricalCost.dt_FilterDetails = SearchGrantData(historicalCost.MultiSelectGrantRegID.chkMultiselect, ac_HistoricalCost.dt_FilterDetails, "[Grant Registration ID]", ac_HistoricalCost.IsFirstSelection, "Add", historicalCost.MultiSelectGrantRegID.txtMultiselect);
                        ac_HistoricalCost.dt_FilterDetails = SearchGrantData(historicalCost.MultiSelectSchemeName.chkMultiselect, ac_HistoricalCost.dt_FilterDetails, "[SCHEME TITLE]", ac_HistoricalCost.IsFirstSelection, "Add", historicalCost.MultiSelectSchemeName.txtMultiselect);
                        ac_HistoricalCost.dt_FilterDetails = GrantDateFilter(ac_HistoricalCost.dt_FilterDetails, historicalCost, "Add");
                        //  ac_HistoricalCost.dt_FilterDetails = GrantDateFilter(ac_HistoricalCost.dt_FilterDetails, historicalCost, "Add_IVORFV");
                        ac_HistoricalCost.Rowcount = ac_HistoricalCost.dt_FilterDetails.Rows.Count;

                        Resetvalues(historicalCost);

                        if ((ac_HistoricalCost.dt_FilterDetails != null && ac_HistoricalCost.dt_FilterDetails.Rows.Count > 0))
                        {
                            historicalCost.gv.DataSource = ac_HistoricalCost.dt_FilterDetails;
                            historicalCost.gv.DataBind();
                            historicalCost.gv.Visible = true;
                            if (ac_HistoricalCost.b_IsLocked)
                            {
                                historicalCost.trVestPresent.Style.Add("display", "block");
                                historicalCost.lblVestPresent.Visible = true;

                            }

                            if (userSessionInfo.ACC_CalculationMethod.Equals(1))
                            {
                                historicalCost.trVestPresent.Style.Add("display", "none");
                                historicalCost.lblVestPresent.Visible = false;
                                historicalCost.lblVestClient.Visible = false;
                                historicalCost.lblVestClient.Font.Bold = false;
                            }
                            else
                            {
                                historicalCost.trVestPresent.Style.Add("display", "block");
                                historicalCost.lblVestClient.Visible = true;
                                historicalCost.lblVestClient.Font.Bold = false;
                            }
                            historicalCost.chkAPams.Enabled = true;
                            historicalCost.btnSave.Enabled = true;
                        }
                        else
                        {
                            BindNullGrid(historicalCost, "gv");
                            historicalCost.btnSave.Enabled = false;
                            ShowHideMessageDiv(historicalCost, "lblHCostFail", true, string.Empty); 
                        }
                        ac_HistoricalCost.IsFirstSelection = true;
                        historicalCost.h3AddEdit.Style.Add("display", "block");

                        if (CommonModel.CheckAgainstLockedAccountingReport(Convert.ToString(historicalCost.txtCostAsOn.Text), userSessionInfo))
                        {
                            historicalCost.hdnCantAddLockedData.Value = "1";
                        }
                        historicalCost.btnSave.Visible = true;
                        historicalCost.btnCancel.Visible = true;
                        ac_HistoricalCost.dt_SelectedParmsFilter = new DataTable("SelectedDataTables");
                        ac_HistoricalCost.dt_SelectedForVestwise = new DataTable("SelectedForVestwise");
                        ac_HistoricalCost.dt_Edit_Maintaind_HCost = new DataTable("Edit_Maintaind_HCost");
                        break;

                    case "btnSearchParams":
                        ac_HistoricalCost.dt_FilterMaintainedHCDetails = (ac_HistoricalCost.dt_Maintaind_HCost != null && ac_HistoricalCost.dt_Maintaind_HCost.Rows.Count > 0) ? ac_HistoricalCost.dt_Maintaind_HCost.Copy() : new DataTable();
                        ac_HistoricalCost.dt_FilterMaintainedHCDetails.Clear();
                        ac_HistoricalCost.dt_FilterMaintainedHCDetails = SearchGrantData(historicalCost.MultiSelectSParameter.chkMultiselect, ac_HistoricalCost.dt_FilterMaintainedHCDetails, "[Name]", ac_HistoricalCost.IsFirstSelection, "SearchParams", historicalCost.MultiSelectSParameter.txtMultiselect);
                        Resetvalues(historicalCost);
                        historicalCost.gvSerachParms.DataSource = ac_HistoricalCost.dt_FilterMaintainedHCDetails;
                        historicalCost.gvSerachParms.DataBind();
                        historicalCost.h3AddEdit.Style.Add("display", "none");
                        ac_HistoricalCost.IsFirstSelection = true;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// This method is used to show/hide message div
        /// </summary>
        /// <param name="historicalCost">historicalCost class object</param>
        /// <param name="s_Msg">s_Msg</param>
        /// <param name="b_IsError">b_IsError</param>
        /// <param name="is_Visible">is_Visible</param>
        public void ShowHideMessageDiv(HistoricalCost historicalCost, string s_Msg, bool b_IsError, string is_Visible)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                if (!string.IsNullOrEmpty(s_Msg))
                    historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N(s_Msg, CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                historicalCost.ctrSuccessErrorMessage.s_MsgBoxDisplay = is_Visible;
                historicalCost.ctrSuccessErrorMessage.s_MsgForeColor = b_IsError ? Color.Red : Color.Blue;
                historicalCost.ctrSuccessErrorMessage.lblMessage.Focus();
            }
        }

        /// <summary>
        /// This method is used to get the filter data against searched parameters.
        /// </summary>
        /// <param name="chk_CheckBoxList">CheckBoxList object</param>
        /// <param name="dt_FilterDetails">datatable used to fileterd the details</param>
        /// <param name="s_columnName">Column name against which data get filtered</param>
        /// <param name="b_Status">bool variable to check the status</param>
        /// <param name="s_Operation">the operation which is going to performed</param>
        /// <param name="textBox">the Textbox object</param>
        /// <returns></returns>
        internal DataTable SearchGrantData(CheckBoxList chk_CheckBoxList, DataTable dt_FilterDetails, string s_columnName, bool b_Status, string s_Operation, TextBox textBox)
        {
            DataTable dt_temp = new DataTable();
            bool b_count = true;
            dt_temp = dt_FilterDetails.Copy();
            string s_CheckedItems = string.Empty, s_SetTextBoxVal = string.Empty;
            foreach (ListItem CurrentItem in chk_CheckBoxList.Items)
            {
                try
                {
                    if (CurrentItem.Selected)
                    {
                        ac_HistoricalCost.IsFirstSelection = false;
                        if (b_Status)
                        {
                            switch (s_Operation)
                            {
                                case "Search":
                                    if (s_columnName.Equals("[OPDate]"))
                                    {
                                        string s_CostAsOn = "[OPDate] = '" + CurrentItem.Text + "'";
                                        dt_temp = processDataTable((ac_HistoricalCost.dt_temp_HC_details != null && ac_HistoricalCost.dt_temp_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_temp_HC_details.Select(s_CostAsOn).Count() > 0) ? ac_HistoricalCost.dt_temp_HC_details.Select("" + s_CostAsOn + "").CopyToDataTable() : new DataTable(), dt_FilterDetails);
                                    }
                                    else
                                        dt_temp = processDataTable((ac_HistoricalCost.dt_temp_HC_details != null && ac_HistoricalCost.dt_temp_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_temp_HC_details.Select("" + s_columnName + " = '" + CurrentItem.Text + "'").Count() > 0) ? ac_HistoricalCost.dt_temp_HC_details.Select("" + s_columnName + " = '" + CurrentItem.Text + "'").CopyToDataTable() : new DataTable(), dt_FilterDetails);
                                    break;
                                case "Add":
                                    dt_temp = processDataTable((ac_HistoricalCost.dt_Add_HC_details != null && ac_HistoricalCost.dt_Add_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_Add_HC_details.Select("" + s_columnName + " = '" + CurrentItem.Text + "'").Count() > 0) ? ac_HistoricalCost.dt_Add_HC_details.Select("" + s_columnName + " = '" + CurrentItem.Text + "'").CopyToDataTable() : new DataTable(), dt_FilterDetails);
                                    break;
                                case "SearchParams":
                                    dt_temp = processDataTable((ac_HistoricalCost.dt_Maintaind_HCost != null && ac_HistoricalCost.dt_Maintaind_HCost.Rows.Count > 0 && ac_HistoricalCost.dt_Maintaind_HCost.Select("" + s_columnName + " = '" + CurrentItem.Text + "'").Count() > 0) ? ac_HistoricalCost.dt_Maintaind_HCost.Select("" + s_columnName + " = '" + CurrentItem.Text + "'").CopyToDataTable() : new DataTable(), dt_FilterDetails);
                                    break;
                            }

                        }
                        else
                        {
                            if (b_count)
                            {
                                dt_FilterDetails.Clear();
                                b_count = false;
                            }
                            dt_FilterDetails = processDataTable(dt_temp.Select("" + s_columnName + " = '" + CurrentItem.Text + "'").CopyToDataTable(), dt_FilterDetails);
                        }
                        if (string.IsNullOrEmpty(s_SetTextBoxVal))
                            s_SetTextBoxVal = CurrentItem.Text.Trim();
                        else
                            s_SetTextBoxVal += "," + CurrentItem.Text.Trim();
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            dt_FilterDetails = b_Status == true ? dt_temp : dt_FilterDetails;
            dt_temp.Dispose();

            if (!string.IsNullOrEmpty(s_SetTextBoxVal))
                textBox.Text = s_SetTextBoxVal;
            else textBox.Text = "--- Please Select ---";

            return dt_FilterDetails;

        }

        /// <summary>
        /// This method is used to filter the grant date
        /// </summary>
        /// <param name="dt_HCFiltered">Datatable object used to filter the data</param>
        /// <param name="historicalCost">Historical Cost page object</param>
        /// <param name="s_Operation">Operation which wants to perform </param>
        /// <returns>returns datatble</returns>
        internal DataTable GrantDateFilter(DataTable dt_HCFiltered, HistoricalCost historicalCost, string s_Operation)
        {
            try
            {
                string s_CostAsOn = string.IsNullOrEmpty(historicalCost.txtCostAsOn.Text) || historicalCost.txtCostAsOn.Text.Equals("dd/mmm/yyyy") ? string.Empty : "[Date] <= '" + Convert.ToDateTime(historicalCost.txtCostAsOn.Text).Date + "'";
                switch (s_Operation)
                {
                    case "Search":
                        string s_SFromDate = string.IsNullOrEmpty(historicalCost.txtSGrantFromDate.Text) || historicalCost.txtSGrantFromDate.Text.Equals("dd/mmm/yyyy") ? string.Empty : historicalCost.txtSGrantFromDate.Text;
                        string s_SToDate = string.IsNullOrEmpty(historicalCost.txtSGrantToDate.Text) || historicalCost.txtSGrantToDate.Text.Equals("dd/mmm/yyyy") ? string.Empty : historicalCost.txtSGrantToDate.Text;
                        string s_SDateCompare = string.Empty;
                        if ((!(string.IsNullOrEmpty(s_SFromDate))) && (!(string.IsNullOrEmpty(s_SToDate))))
                        {
                            s_SDateCompare = "[Date] >= #" + Convert.ToDateTime(s_SFromDate).Date + "# AND [Date] <= #" + Convert.ToDateTime(s_SToDate).Date + "# ";
                        }
                        if (!string.IsNullOrEmpty(s_SDateCompare))
                        {
                            dt_HCFiltered = ac_HistoricalCost.dt_temp_HC_details != null && ac_HistoricalCost.dt_temp_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_temp_HC_details.Select("" + s_SDateCompare + "").Count() > 0 ? ac_HistoricalCost.dt_temp_HC_details.Select("" + s_SDateCompare + "").CopyToDataTable() : new DataTable();
                        }
                        /* Grant Date From Date Filter :- it will filter data that has grant date greater than or equal to 'Grant Date'*/
                        if (string.IsNullOrEmpty(s_SDateCompare) && !string.IsNullOrEmpty(s_SFromDate))
                        {
                            if (ac_HistoricalCost.IsFirstSelection)
                                dt_HCFiltered = ac_HistoricalCost.dt_temp_HC_details != null && ac_HistoricalCost.dt_temp_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_temp_HC_details.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_SFromDate).Date).Count() > 0 ? ac_HistoricalCost.dt_temp_HC_details.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_SFromDate).Date).CopyToDataTable() : new DataTable();
                            else
                                dt_HCFiltered = dt_HCFiltered != null && dt_HCFiltered.Rows.Count > 0 && dt_HCFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_SFromDate).Date).Count() > 0 ? dt_HCFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_SFromDate).Date).CopyToDataTable() : new DataTable();
                            ac_HistoricalCost.IsFirstSelection = false;
                        }
                        /* Grant Date To Date Filter :- it will filter data that has grant date less than or equal to 'Grant Date' */
                        if (string.IsNullOrEmpty(s_SDateCompare) && !string.IsNullOrEmpty(s_SToDate))
                        {
                            if (ac_HistoricalCost.IsFirstSelection)
                                dt_HCFiltered = ac_HistoricalCost.dt_temp_HC_details != null && ac_HistoricalCost.dt_temp_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_temp_HC_details.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_SToDate).Date).Count() > 0 ? ac_HistoricalCost.dt_temp_HC_details.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_SToDate).Date).CopyToDataTable() : new DataTable();
                            else
                                dt_HCFiltered = dt_HCFiltered != null && dt_HCFiltered.Rows.Count > 0 && dt_HCFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_SToDate).Date).Count() > 0 ? dt_HCFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_SToDate).Date).CopyToDataTable() : new DataTable();
                            ac_HistoricalCost.IsFirstSelection = false;
                        }
                        break;

                    case "Add":
                        string s_FromDate = string.IsNullOrEmpty(historicalCost.txtGrantFromDate.Text) || historicalCost.txtGrantFromDate.Text.Equals("dd/mmm/yyyy") ? string.Empty : historicalCost.txtGrantFromDate.Text;
                        string s_ToDate = string.IsNullOrEmpty(historicalCost.txtGrantToDate.Text) || historicalCost.txtGrantToDate.Text.Equals("dd/mmm/yyyy") ? string.Empty : historicalCost.txtGrantToDate.Text;
                        string s_DateCompare = string.Empty;

                        if ((!(string.IsNullOrEmpty(s_FromDate))) && (!(string.IsNullOrEmpty(s_ToDate))))
                        {
                            s_DateCompare = "[Date] >= #" + Convert.ToDateTime(s_FromDate).Date + "# AND [Date] <= #" + Convert.ToDateTime(s_ToDate).Date + "# ";
                        }
                        if (!string.IsNullOrEmpty(s_DateCompare))
                        {
                            dt_HCFiltered = ac_HistoricalCost.dt_Add_HC_details != null && ac_HistoricalCost.dt_Add_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_Add_HC_details.Select("" + s_DateCompare + "").Count() > 0 ? ac_HistoricalCost.dt_Add_HC_details.Select("" + s_DateCompare + "").CopyToDataTable() : new DataTable();
                        }
                        /* Grant Date From Date Filter :- it will filter data that has grant date greater than or equal to 'Grant Date'*/
                        if (string.IsNullOrEmpty(s_DateCompare) && !string.IsNullOrEmpty(s_FromDate))
                        {
                            if (ac_HistoricalCost.IsFirstSelection)
                                dt_HCFiltered = ac_HistoricalCost.dt_Add_HC_details != null && ac_HistoricalCost.dt_Add_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_Add_HC_details.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_FromDate).Date).Count() > 0 ? ac_HistoricalCost.dt_Add_HC_details.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_FromDate).Date).CopyToDataTable() : new DataTable();
                            else
                                dt_HCFiltered = dt_HCFiltered != null && dt_HCFiltered.Rows.Count > 0 && dt_HCFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_FromDate).Date).Count() > 0 ? dt_HCFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_FromDate).Date).CopyToDataTable() : new DataTable();
                            ac_HistoricalCost.IsFirstSelection = false;
                        }
                        /* Grant Date To Date Filter :- it will filter data that has grant date less than or equal to 'Grant Date' */
                        if (string.IsNullOrEmpty(s_DateCompare) && !string.IsNullOrEmpty(s_ToDate))
                        {
                            if (ac_HistoricalCost.IsFirstSelection)
                                dt_HCFiltered = ac_HistoricalCost.dt_Add_HC_details != null && ac_HistoricalCost.dt_Add_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_Add_HC_details.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_ToDate).Date).Count() > 0 ? ac_HistoricalCost.dt_Add_HC_details.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_ToDate).Date).CopyToDataTable() : new DataTable();
                            else
                                dt_HCFiltered = dt_HCFiltered != null && dt_HCFiltered.Rows.Count > 0 && dt_HCFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_ToDate).Date).Count() > 0 ? dt_HCFiltered.AsEnumerable().Where(r => DateTime.Parse(r["Date"].ToString()).Date >= Convert.ToDateTime(s_ToDate).Date).CopyToDataTable() : new DataTable();
                            ac_HistoricalCost.IsFirstSelection = false;
                        }
                        break;

                    case "A_Cost_AS_ON":
                        if (!string.IsNullOrEmpty(s_CostAsOn))
                        {
                            if (ac_HistoricalCost.IsFirstSelection)
                                dt_HCFiltered = ac_HistoricalCost.dt_Add_HC_details != null && ac_HistoricalCost.dt_Add_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_Add_HC_details.Select(s_CostAsOn).Count() > 0 ? ac_HistoricalCost.dt_Add_HC_details.Select(s_CostAsOn).CopyToDataTable() : new DataTable();
                            else
                                dt_HCFiltered = dt_HCFiltered != null && dt_HCFiltered.Rows.Count > 0 && dt_HCFiltered.Select(s_CostAsOn).Count() > 0 ? dt_HCFiltered.Select(s_CostAsOn).CopyToDataTable() : new DataTable();
                            ac_HistoricalCost.IsFirstSelection = false;
                        }
                        break;

                    case "Search_IVORFV":
                        string s_Val_Method = historicalCost.rdbSVMCC01.Checked ? historicalCost.rdbSVMCC01.Text : historicalCost.rdbSVMCC02.Text;

                        if (!string.IsNullOrEmpty(s_Val_Method))
                        {
                            if (ac_HistoricalCost.IsFirstSelection)
                                dt_HCFiltered = ac_HistoricalCost.dt_temp_HC_details != null && ac_HistoricalCost.dt_temp_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_temp_HC_details.Select("[IV/FV]  = '" + s_Val_Method + "'").Count() > 0 ? ac_HistoricalCost.dt_temp_HC_details.Select("[IV/FV]  = '" + s_Val_Method + "'").CopyToDataTable() : new DataTable();
                            else
                                dt_HCFiltered = dt_HCFiltered != null && dt_HCFiltered.Rows.Count > 0 && dt_HCFiltered.Select("[IV/FV]  = '" + s_Val_Method + "'").Count() > 0 ? dt_HCFiltered.Select("[IV/FV]  = '" + s_Val_Method + "'").CopyToDataTable() : new DataTable();
                            ac_HistoricalCost.IsFirstSelection = false;
                        }
                        break;

                    case "Add_IVORFV":
                        string s_AVal_Method = historicalCost.rdbVMCC01.Checked ? historicalCost.rdbVMCC01.Text : historicalCost.rdbVMCC02.Text;
                        if (!string.IsNullOrEmpty(s_AVal_Method))
                        {
                            if (ac_HistoricalCost.IsFirstSelection)
                                dt_HCFiltered = ac_HistoricalCost.dt_Add_HC_details != null && ac_HistoricalCost.dt_Add_HC_details.Rows.Count > 0 && ac_HistoricalCost.dt_Add_HC_details.Select("[IV/FV]  = '" + s_AVal_Method + "'").Count() > 0 ? ac_HistoricalCost.dt_Add_HC_details.Select("[IV/FV]  = '" + s_AVal_Method + "'").CopyToDataTable() : new DataTable();
                            else
                                dt_HCFiltered = dt_HCFiltered != null && dt_HCFiltered.Rows.Count > 0 && dt_HCFiltered.Select("[IV/FV]  = '" + s_AVal_Method + "'").Count() > 0 ? dt_HCFiltered.Select("[IV/FV]  = '" + s_AVal_Method + "'").CopyToDataTable() : new DataTable();
                            ac_HistoricalCost.IsFirstSelection = false;
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt_HCFiltered;
        }

        /// <summary>
        /// This method is used to Bind the drop down
        /// </summary>
        /// <param name="historicalCost">Historical Cost page object</param>
        internal void BindDropDowns(HistoricalCost historicalCost)
        {
            try
            {
                if (ac_HistoricalCost.ds_HistoricalCost.Tables[7].Rows.Count > 0)
                {
                    {
                        using (DataTable dt_TMDetails = ac_HistoricalCost.ds_HistoricalCost.Tables[7])
                        {
                            historicalCost.ddlAParms.DataSource = dt_TMDetails;
                            historicalCost.ddlAParms.DataTextField = "FIELD_NAME";
                            historicalCost.ddlAParms.DataValueField = "ATMID";
                            historicalCost.ddlAParms.DataBind();
                            using (HCCommonModel hCCommonModel = new HCCommonModel())
                            {
                                hCCommonModel.BindToolTip(historicalCost.ddlAParms);
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  This method is used to ad  row in datatble 
        /// </summary>
        /// <param name="dt_temp">temp datatable object</param>
        /// <param name="dt_CopyRow">The row whci want to copy</param>
        /// <returns>returns datatble</returns>
        internal DataTable processDataTable(DataTable dt_temp, DataTable dt_CopyRow)
        {
            foreach (DataRow dr in dt_temp.Rows)
            {
                var newDataRow = dt_CopyRow.NewRow();
                newDataRow.ItemArray = dr.ItemArray;
                dt_CopyRow.Rows.Add(newDataRow);
            }
            return dt_CopyRow;
        }

        #endregion

        #region Bind Search/Default GridView
        /// <summary>
        /// This method is used to bind grid view
        /// </summary>
        /// <param name="historicalCost">Historical Cost page Object</param>
        internal void BindGridView(HistoricalCost historicalCost)
        {
            try
            {
                if (ac_HistoricalCost.dt_temp_HC_details != null && ac_HistoricalCost.dt_temp_HC_details.Rows.Count > 0)
                {
                    Resetvalues(historicalCost);
                    historicalCost.gvHistoricalCost.PageSize = ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 ? Convert.ToInt32(ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows[0]["NO_OF_ROWS"].ToString()) : historicalCost.gvHistoricalCost.PageSize;
                    historicalCost.gvHistoricalCost.DataSource = ac_HistoricalCost.dt_temp_HC_details;
                    historicalCost.gvHistoricalCost.DataBind();
                    historicalCost.btnDelete.Visible = true;
                }
                else
                {
                    BindNullGrid(historicalCost, "gvHistoricalCost");
                    historicalCost.btnDelete.Visible = false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind the null grid
        /// </summary>
        /// <param name="historicalCost">Historical Cost Page Object</param>
        /// <param name="s_ConntolName">Conntol Name Page Object</param>
        internal void BindNullGrid(HistoricalCost historicalCost, string s_ConntolName)
        {
            try
            {
                DataTable dt = new DataTable("DT");
                switch (s_ConntolName)
                {
                    case "gvHistoricalCost":
                        historicalCost.gvHistoricalCost.DataSource = dt;
                        historicalCost.gvHistoricalCost.DataBind();
                        historicalCost.gvHistoricalCost.Visible = true;
                        break;

                    case "gvSerachParms":
                        historicalCost.gvSerachParms.DataSource = dt;
                        historicalCost.gvSerachParms.DataBind();
                        historicalCost.gvSerachParms.Visible = true;
                        break;

                    case "gv":
                        historicalCost.gv.DataSource = dt;
                        historicalCost.gv.DataBind();
                        historicalCost.gv.Visible = true;
                        break;

                    case "gvAParmsHCost":
                        historicalCost.gvAParmsHCost.DataSource = dt;
                        historicalCost.gvAParmsHCost.DataBind();
                        historicalCost.gvAParmsHCost.Visible = true;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region assign TextBox values in from dynamically created GridView to DataTable
        /// <summary>
        /// This method is used to assign TextBox values in from dynamically created GridView to DataTable
        /// </summary>
        /// <param name="nameValueCollection"></param>
        /// <param name="historicalCost">Historical Cost page object</param>
        internal void AssignValuesFromTextbox(System.Collections.Specialized.NameValueCollection nameValueCollection, HistoricalCost historicalCost)
        {
            try
            {
                if (ac_HistoricalCost.dt_SelectedDataTables != null)
                {
                    if (ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0)
                    {
                        ac_HistoricalCost.dt_SelectedDataTables = new DataTable("SelectedDataTables");
                    }
                }

                if (ac_HistoricalCost.dt_SelectedForParameter != null)
                {
                    if (ac_HistoricalCost.dt_SelectedForParameter.Rows.Count > 0)
                    {
                        ac_HistoricalCost.dt_SelectedForParameter = new DataTable("SelectedForDataTables");
                    }
                }

                if (ac_HistoricalCost.dt_SelectedDataTables != null)
                {
                    if (ac_HistoricalCost.dt_SelectedDataTables.Columns.Count < 2)
                    {
                        DataTable dataTable = new DataTable("SelectedDataTables");
                        CreateGrantDatatable(ac_HistoricalCost.dt_SelectedDataTables);
                    }
                }

                if (ac_HistoricalCost.dt_SelectedForParameter != null)
                {
                    if (ac_HistoricalCost.dt_SelectedForParameter.Columns.Count < 2)
                    {
                        DataTable dataTable = new DataTable("SelectedForDataTables");
                        CreateDatatableByParameter(ac_HistoricalCost.dt_SelectedForParameter);
                    }
                }

                foreach (var item in nameValueCollection.AllKeys)
                {
                    //e.g.: TextBox control name = ctl00$MainContent$txt|1|2
                    if (item != null && Convert.ToString(item).Contains("txtUpdateCost"))
                    {
                        /* use below condition when pagination is present */
                        //if (item.Replace("\\", "").Split('$').Last().Split('|')[10].Equals("1"))
                        if (item.Split('$').Last().Split('|')[10].Equals("1"))
                        {
                            DataRow dr = ac_HistoricalCost.dt_SelectedDataTables.NewRow();
                            dr["OPERATION_ID"] = item.Split('$').Last().Split('|')[1];
                            if (!(nameValueCollection[item].Equals("")))
                            {
                                dr["UpdateCost"] = Convert.ToDecimal(nameValueCollection[item]);
                            }
                            else
                            {
                                return;
                            }
                            dr["OPT_GRANTED_ID"] = item.Split('$').Last().Split('|')[2];
                            dr["Location"] = item.Split('$').Last().Split('|')[3];
                            dr["Department"] = item.Split('$').Last().Split('|')[4];
                            dr["SBU"] = item.Split('$').Last().Split('|')[5];
                            dr["ENTITY"] = item.Split('$').Last().Split('|')[6];
                            dr["COST_CENTRE"] = item.Split('$').Last().Split('|')[7];
                            dr["EMPID"] = item.Split('$').Last().Split('|')[8];
                            dr["COST_AS_PER_SYSTEM"] = !string.IsNullOrEmpty(item.Split('$').Last().Split('|')[9].Trim()) ? item.Split('$').Last().Split('|')[9].Trim() : "0";
                            dr["ADJUSTMENT_ENTRY"] = 0;
                            dr["COST_AS_PER_SYSTEM_BY_FV"] = !string.IsNullOrEmpty(item.Split('$').Last().Split('|')[11].Trim()) ? item.Split('$').Last().Split('|')[11].Trim() : "0";
                            ac_HistoricalCost.dt_SelectedDataTables.Rows.Add(dr);
                            HttpContext.Current.Session["GrantData"] = ac_HistoricalCost.dt_SelectedDataTables.Copy();
                            if (!(ac_HistoricalCost.dt_SelectedDataTables.Rows.Count == ac_HistoricalCost.dt_SelectedParmsFilter.Rows.Count))
                            {
                                ac_HistoricalCost.dt_SelectedParmsFilter = ac_HistoricalCost.dt_SelectedDataTables.Copy();
                            }
                        }
                    }
                    if (item != null && Convert.ToString(item).Contains("txtAdjustment"))
                    {
                        if (!(nameValueCollection[item].Equals("")))
                        {
                            if (ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0)
                            {
                                ac_HistoricalCost.dt_SelectedDataTables.Columns["ADJUSTMENT_ENTRY"].Expression = nameValueCollection[item];
                            }
                            HttpContext.Current.Session["ADJUSTMENT_ENTRY"] = nameValueCollection[item];
                        }
                    }

                    if (item != null && Convert.ToString(item).Contains("txtSPAdjustmtEntry"))
                    {
                        if (!(nameValueCollection[item].Equals("")))
                        {
                            DataRow drSelected = ac_HistoricalCost.dt_SelectedForParameter.NewRow();
                            drSelected["ATMDID"] = item.Split('$').Last().Split('|')[1];
                            drSelected["ADJUSTMENT_ENTRY"] = nameValueCollection[item];
                            drSelected["FINAL_COST"] = item.Split('$').Last().Split('|')[2];
                            drSelected["PARAM_VALUE"] = item.Split('$').Last().Split('|')[3];
                            drSelected["EMPID"] = item.Split('$').Last().Split('|')[4];
                            ac_HistoricalCost.dt_SelectedForParameter.Rows.Add(drSelected);
                            ac_HistoricalCost.dt_SelectedDataTables = ac_HistoricalCost.dt_SelectedParmsFilter.Copy();
                            if (HttpContext.Current.Session["ADJUSTMENT_ENTRY"] != null && ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0)
                                ac_HistoricalCost.dt_SelectedDataTables.Columns["ADJUSTMENT_ENTRY"].Expression = HttpContext.Current.Session["ADJUSTMENT_ENTRY"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to Create Parameter's table
        /// </summary>
        /// <param name="dtParameter">This object used to return the dadatble</param>
        private void CreateDatatableByParameter(DataTable dtParameter)
        {
            dtParameter.Columns.Add("EMPID", typeof(int));
            dtParameter.Columns.Add("ATMDID", typeof(int));
            dtParameter.Columns.Add("COST_AS_PER_SYSTEM", typeof(decimal));
            dtParameter.Columns.Add("ADJUSTMENT_ENTRY", typeof(decimal));
            dtParameter.Columns.Add("UPDATECOST", typeof(decimal));
            dtParameter.Columns.Add("FINAL_COST", typeof(decimal));
            dtParameter.Columns.Add("PARAM_VALUE", typeof(string));
            dtParameter.Columns.Add("HC_PID", typeof(int));
        }

        /// <summary>
        /// This method is used to Create Grant data table
        /// </summary>
        /// <param name="dtGrantWise">This object used to return the dadatble</param>
        private void CreateGrantDatatable(DataTable dtGrantWise)
        {
            dtGrantWise.Columns.Add("AGRMID", typeof(int));
            dtGrantWise.Columns.Add("EMPLOYEE_ID", typeof(string));
            dtGrantWise.Columns.Add("EMPLOYEE_NAME", typeof(string));
            dtGrantWise.Columns.Add("GRS_GRANT_REGISTRATION_ID", typeof(string));
            dtGrantWise.Columns.Add("GRANT DATE", typeof(DateTime));
            dtGrantWise.Columns.Add("GRANT_OPTION_ID", typeof(string));
            dtGrantWise.Columns.Add("OUTSTANDING_OPTIONS", typeof(string));
            dtGrantWise.Columns.Add("Location", typeof(string));
            dtGrantWise.Columns.Add("Department", typeof(string));
            dtGrantWise.Columns.Add("SBU", typeof(string));
            dtGrantWise.Columns.Add("ENTITY", typeof(string));
            dtGrantWise.Columns.Add("COST_CENTRE", typeof(string));
            dtGrantWise.Columns.Add("COST_AS_PER_SYSTEM", typeof(decimal));
            dtGrantWise.Columns.Add("SCHEME_TITLE", typeof(string));
            dtGrantWise.Columns.Add("VESTING_PERIOD_ID", typeof(int));
            dtGrantWise.Columns.Add("GRANTED_OPTIONS", typeof(int));
            dtGrantWise.Columns.Add("CANCELLED_OPTIONS", typeof(int));
            dtGrantWise.Columns.Add("VESTED_CANCELLED_OPTIONS", typeof(int));
            dtGrantWise.Columns.Add("UNVESTED_CANCELLED_OPTIONS", typeof(int));
            dtGrantWise.Columns.Add("LAPSED_OPTIONS", typeof(int));
            dtGrantWise.Columns.Add("EXERCISED_OPTIONS", typeof(string));
            dtGrantWise.Columns.Add("UNVESTED_OPTIONS", typeof(int));
            dtGrantWise.Columns.Add("VESTED_AND_EXERCISABLE", typeof(int));
            dtGrantWise.Columns.Add("FORFEITURE_RATE", typeof(string));
            dtGrantWise.Columns.Add("EmpID", typeof(int));
            dtGrantWise.Columns.Add("OPERATION_ID", typeof(int));
            dtGrantWise.Columns.Add("OPT_GRANTED_ID", typeof(int));
            dtGrantWise.Columns.Add("UPDATECOST", typeof(decimal));
            dtGrantWise.Columns.Add("REVERSAL_DATE", typeof(DateTime));
            dtGrantWise.Columns.Add("REVERSAL_COST", typeof(decimal));
            dtGrantWise.Columns.Add("ADJUSTMENT_ENTRY", typeof(decimal));
            dtGrantWise.Columns.Add("CANCELLATION_DATE", typeof(DateTime));
            dtGrantWise.Columns.Add("LAPSED_DATE", typeof(DateTime));
            dtGrantWise.Columns.Add("EXERCISED_DATE", typeof(DateTime));
            dtGrantWise.Columns.Add("COST_AS_PER_SYSTEM_BY_FV", typeof(decimal));
        }
        #endregion

        #region Bind/Add rows into GridView and page index changed event
        /// <summary>
        /// This Method binds row in gridview / hides some of the columns.
        /// </summary>
        /// <param name="e">event args object</param>
        /// <param name="n_index">index value object</param>
        /// <param name="hash_HCList">Hash List object</param>
        /// <param name="historicalCost">Historical Cost Page Object</param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref Hashtable hash_HCList, HistoricalCost historicalCost)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "DELETE":
                                hash_HCList["n_Delete"] = n_index;
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_Delete"].ToString())].Controls.Add(AddControl(historicalCost, "CheckBox", "SelectAllCheckBoxes", "", "", "chkDeleteAll", "", "", "", "", "", "", "", "", "", "", " ", " ", ""));
                                break;

                            case "ID":
                                hash_HCList["n_ID"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "EMPLOYEE ID":
                                hash_HCList["n_EmpID"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_ID'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "EMPLOYEE NAME":
                                hash_HCList["n_EmpName"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_NAME'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "GRANT REGISTRATION ID":
                                hash_HCList["n_GRegID"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "GRANT DATE":
                                hash_HCList["n_GrantDate"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRS_GRANT_DATE'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRS_GRANT_DATE'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRS_GRANT_DATE'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRS_GRANT_DATE'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "GRANT OPTION ID":
                                hash_HCList["n_GrantOptioID"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRANT_OPTION_ID'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRANT_OPTION_ID'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRANT_OPTION_ID'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRANT_OPTION_ID'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "OUTSTANDING OPTIONS":
                                hash_HCList["n_OutstandingOpt"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "IV/FV":
                                hash_HCList["n_IVORFV"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'IV/FV'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'IV/FV'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'IV/FV'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'IV/FV'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "LOCATION":
                                hash_HCList["n_Location"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'LOCATION'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'LOCATION'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'LOCATION'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'LOCATION'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "DEPARTMENT":
                                hash_HCList["n_Dept"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'DEPARTMENT'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'DEPARTMENT'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'DEPARTMENT'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'DEPARTMENT'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "SBU":
                                hash_HCList["n_SBU"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'SBU'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'SBU'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'SBU'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'SBU'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "ENTITY":
                                hash_HCList["n_Entity"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'ENTITY'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'ENTITY'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'ENTITY'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'ENTITY'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "COST CENTRE":
                                hash_HCList["n_CostCentre"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'COST CENTRE'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'COST CENTRE'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'COST CENTRE'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'COST CENTRE'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "COST AS PER SYSTEM BY IV/FV":
                                hash_HCList["n_CostBySystem"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'Cost as per System'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'Cost as per System'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'Cost as per System'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'Cost as per System'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "UPDATE COST":
                                hash_HCList["n_HCostManulally"] = n_index;
                                perColumn.Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'H_COST_MANUALLY'").Count() > 0;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'H_COST_MANUALLY'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'H_COST_MANUALLY'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'H_COST_MANUALLY'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;


                            case "SCHEME TITLE":
                                hash_HCList["n_Scheme"] = n_index;
                                perColumn.Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'SCH_SCHEME_TITLE'").Count() > 0) ? true : false;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'SCH_SCHEME_TITLE'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'SCH_SCHEME_TITLE'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'SCH_SCHEME_TITLE'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "OPGID":
                                hash_HCList["n_OPT_GRANTED_ID"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "OPID":
                                hash_HCList["n_OPID"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "EID":
                                hash_HCList["n_EID"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "DATE":
                                hash_HCList["n_Date"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "OPDATE":
                                hash_HCList["n_OPDate"] = n_index;
                                perColumn.Text = "Cost as on Date";
                                break;

                            case "LOCID":
                                hash_HCList["n_LocID"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "DEPTID":
                                hash_HCList["n_DepID"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "SBUID":
                                hash_HCList["n_SBUID"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "ENTID":
                                hash_HCList["n_ENTID"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "CTRID":
                                hash_HCList["n_COCID"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "ADJUSTMENT ENTRY":
                                hash_HCList["n_AdjustmtEntry"] = n_index;
                                break;

                            case "REVERSAL COST":
                                hash_HCList["n_ReversalCost"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "REVERSAL DATE":
                                hash_HCList["n_ReversalDate"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "EXERCISE PRICE":
                                hash_HCList["n_ExerPrice"] = n_index;
                                perColumn.Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EXERCISE_PRICE'").Count() > 0) ? true : false;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EXERCISE_PRICE'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EXERCISE_PRICE'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EXERCISE_PRICE'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "VESTED CANCELLED":
                                hash_HCList["n_VestedCancelled"] = n_index;
                                perColumn.Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'").Count() > 0) ? true : false;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "UNVESTED CANCELLED":
                                hash_HCList["n_UnvestedCancelled"] = n_index;
                                perColumn.Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'").Count() > 0) ? true : false;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "LAPSED":
                                hash_HCList["n_Lapsed"] = n_index;
                                perColumn.Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'LAPSED_OPTIONS'").Count() > 0) ? true : false;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'LAPSED_OPTIONS'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'LAPSED_OPTIONS'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'LAPSED_OPTIONS'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "EXERCISED":
                                hash_HCList["n_ExeOptions"] = n_index;
                                perColumn.Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'").Count() > 0) ? true : false;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "FORFEITURE RATE":
                                hash_HCList["n_FRate"] = n_index;
                                perColumn.Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'FORFEITURE_RATE'").Count() > 0) ? true : false;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'FORFEITURE_RATE'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'FORFEITURE_RATE'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'FORFEITURE_RATE'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "NET OPTIONS":
                                hash_HCList["n_GOptions"] = n_index;
                                perColumn.Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRANTED_OPTIONS'").Count() > 0) ? true : false;
                                dr = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? null : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRANTED_OPTIONS'").Count() > 0 ? ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRANTED_OPTIONS'") : null;
                                perColumn.Text = (dr != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRANTED_OPTIONS'").Count() > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("[COLUMN_ALIAS] is null").Length > 0) ?
                                                 dr[0]["COLUMN_ALIAS"].ToString()
                                                : perColumn.Text;
                                break;

                            case "ACTION":
                                hash_HCList["n_Action"] = n_index;
                                break;

                            case "COSTBYFV":
                                hash_HCList["n_CostBYFV"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "COSTBYIV":
                                hash_HCList["n_CostBYIV"] = n_index;
                                perColumn.Visible = false;
                                break;

                            case "ISLOCKED":
                                hash_HCList["n_IsLocked"] = n_index;
                                perColumn.Visible = false;
                                break;
                        }
                        n_index = n_index + 1;
                    }
                    break;

                case DataControlRowType.DataRow:
                    try
                    {
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Delete"].ToString())].Controls.Add(AddControl(historicalCost, "CheckBox", "SelectAllCheckBoxes", e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPID"].ToString())].Text, "", "chkHistory", "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Text, "", "", "", "", "", "", "", "", "", Convert.ToString(CommonModel.CheckAgainstLockedAccountingReport(e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPDate"].ToString())].Text, userSessionInfo) ? 1 : 0), ""));
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_IsLocked"].ToString())].Visible =
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_ID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_LocID"].ToString())].Visible =
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Date"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_DepID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_SBUID"].ToString())].Visible =
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_ENTID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_COCID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_EID"].ToString())].Visible =
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_ReversalDate"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_ReversalCost"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBYFV"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBYIV"].ToString())].Visible = false;

                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_EmpID"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_ID'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_EmpName"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EMPLOYEE_NAME'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_GRegID"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantDate"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRS_GRANT_DATE'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRANT_OPTION_ID'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_OutstandingOpt"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'OUTSTANDING_OPTIONS'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_IVORFV"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'IV/FV'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Location"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'LOCATION'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Dept"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'DEPARTMENT'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_SBU"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'SBU'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Entity"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'ENTITY'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostCentre"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'COST CENTRE'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'Cost as per System'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Visible = ac_HistoricalCost.dt_CustmizedViewHistoricalCost == null || ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count.Equals(0) ? true : ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'H_COST_MANUALLY'").Count() > 0;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Scheme"].ToString())].Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'SCH_SCHEME_TITLE'").Count() > 0) ? true : false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_ExerPrice"].ToString())].Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EXERCISE_PRICE'").Count() > 0) ? true : false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_VestedCancelled"].ToString())].Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'VESTED_CANCELLED_OPTIONS'").Count() > 0) ? true : false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_UnvestedCancelled"].ToString())].Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'UNVESTED_CANCELLED_OPTIONS'").Count() > 0) ? true : false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Lapsed"].ToString())].Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'LAPSED_OPTIONS'").Count() > 0) ? true : false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_ExeOptions"].ToString())].Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'EXERCISED_OPTIONS'").Count() > 0) ? true : false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_FRate"].ToString())].Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'FORFEITURE_RATE'").Count() > 0) ? true : false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_GOptions"].ToString())].Visible = (ac_HistoricalCost.dt_CustmizedViewHistoricalCost != null && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Rows.Count > 0 && ac_HistoricalCost.dt_CustmizedViewHistoricalCost.Select("COLUMN_NAME = 'GRANTED_OPTIONS'").Count() > 0) ? true : false;

                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Controls.Add(AddControl(historicalCost, "Label", "", "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Text, "lblGOPID", "", "", "", "", "", "", "", "", "", "", "", "", ""));
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPDate"])].Text = string.IsNullOrEmpty(Convert.ToString(e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPDate"])].Text)) ? string.Empty : Convert.ToDateTime(e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPDate"])].Text).ToString("dd/MMM/yyyy");
                        //If vestwise client is present
                        if (userSessionInfo.ACC_CalculationMethod.Equals(2) && (!e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Text.Equals("&nbsp;")))
                        {
                            e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Controls.Add(AddControl(historicalCost, "HyperLink", "", "", "", "lnkViewVest", "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Text, "", "", "", "", "", "", "", "", "", "", ""));
                        }

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].HorizontalAlign = HorizontalAlign.Right;
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Controls.Add(AddControl(historicalCost, "Label", "", "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text, "lblHistory", "", "", "", "", "", "", "", "", "", "", "", "", ""));
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Controls.Add(AddControl(historicalCost, "HyperLink", "", "", "", "lnkVHistory", "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Text, "", "", "", "", "", "", "", "", "", "", ""));
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].HorizontalAlign = HorizontalAlign.Right;
                            }
                        }
                        #endregion
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Action"].ToString())].Controls.Add((Control)new HCCommonModel().AddImageLink(historicalCost, "Click here to Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Text, Convert.ToString(CommonModel.CheckAgainstLockedAccountingReport(e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPDate"].ToString())].Text, userSessionInfo) ? 1 : 0)));
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Action"].ToString())].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Delete"].ToString())].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_OutstandingOpt"].ToString())].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantDate"].ToString())].HorizontalAlign = HorizontalAlign.Center;
                        SetIDsToHdnFields(e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPID"].ToString())].Text, historicalCost, "");
                    }
                    catch
                    {
                        throw;
                    }
                    break;
            }
        }

        /// <summary>
        ///  this method binds row to Add HC gridview
        /// </summary>
        /// <param name="e">event args object</param>
        /// <param name="n_index">Index number</param>
        /// <param name="hash_HCList">Hash List of all objects</param>
        /// <param name="historicalCost">Historical Cost Page Object</param>
        public void BindgvRows(GridViewRowEventArgs e, ref int n_index, ref Hashtable hash_HCList, HistoricalCost historicalCost)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "DELETE":
                                    hash_HCList["n_Delete"] = n_index;
                                    e.Row.Cells[Convert.ToInt32(hash_HCList["n_Delete"].ToString())].Controls.Add(AddControl(historicalCost, "CheckBox", "SelectAllCheckBoxes", "", "", "SelectAll", "", "", "", "", "", "", "", "", "", "", "", "", ""));
                                    break;

                                case "ID":
                                    hash_HCList["n_ID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "EMPLOYEE ID":
                                    hash_HCList["n_EmpID"] = n_index;
                                    break;

                                case "EID":
                                    hash_HCList["n_EID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "EMPLOYEE NAME":
                                    hash_HCList["n_EmpName"] = n_index;
                                    break;

                                case "GRANT REGISTRATION ID":
                                    hash_HCList["n_GRegID"] = n_index;
                                    break;

                                case "GRANT DATE":
                                    hash_HCList["n_GrantDate"] = n_index;
                                    break;

                                case "GRANT OPTION ID":
                                    hash_HCList["n_GrantOptioID"] = n_index;
                                    break;

                                case "OUTSTANDING OPTIONS":
                                    hash_HCList["n_OutstandingOpt"] = n_index;
                                    break;

                                case "IV/FV":
                                    hash_HCList["n_IVORFV"] = n_index;
                                    break;

                                case "LOCATION":
                                    hash_HCList["n_Location"] = n_index;
                                    break;

                                case "DEPARTMENT":
                                    hash_HCList["n_Dept"] = n_index;
                                    break;

                                case "SBU":
                                    hash_HCList["n_SBU"] = n_index;
                                    break;

                                case "ENTITY":
                                    hash_HCList["n_Entity"] = n_index;
                                    break;

                                case "COST CENTRE":
                                    hash_HCList["n_CostCentre"] = n_index;
                                    break;

                                case "COST AS PER SYSTEM BY IV/FV":
                                    hash_HCList["n_CostBySystem"] = n_index;
                                    break;

                                case "UPDATE COST":
                                    hash_HCList["n_HCostManulally"] = n_index;
                                    break;

                                case "SCHEME TITLE":
                                    hash_HCList["n_Scheme"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPGID":
                                    hash_HCList["n_OPT_GRANTED_ID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPID":
                                    hash_HCList["n_OPID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DATE":
                                    hash_HCList["n_Date"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPDATE":
                                    hash_HCList["n_OPDate"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "LOCID":
                                    hash_HCList["n_LocID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DEPTID":
                                    hash_HCList["n_DepID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "SBUID":
                                    hash_HCList["n_SBUID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ENTID":
                                    hash_HCList["n_ENTID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "CTRID":
                                    hash_HCList["n_COCID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ADJUSTMENT ENTRY":
                                    hash_HCList["n_AdjustmtEntry"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "REVERSAL COST":
                                    hash_HCList["n_ReversalCost"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "REVERSAL DATE":
                                    hash_HCList["n_ReversalDate"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "EXERCISE PRICE":
                                    hash_HCList["n_ExerPrice"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "VESTED CANCELLED":
                                    hash_HCList["n_VestedCancelled"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "UNVESTED CANCELLED":
                                    hash_HCList["n_UnvestedCancelled"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "LAPSED":
                                    hash_HCList["n_Lapsed"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "EXERCISED":
                                    hash_HCList["n_ExeOptions"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "FORFEITURE RATE":
                                    hash_HCList["n_FRate"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "NET OPTIONS":
                                    hash_HCList["n_GOptions"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "COSTBYFV":
                                    hash_HCList["n_CostBYFV"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    hash_HCList["n_Action"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "COSTBYIV":
                                    hash_HCList["n_CostBYIV"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ISLOCKED":
                                    hash_HCList["n_IsLocked"] = n_index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;
                    case DataControlRowType.DataRow:
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Delete"].ToString())].Controls.Add(AddControl(historicalCost, "CheckBox", "SelectAllCheckBoxes", e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPID"].ToString())].Text, "", "chkAdd", "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Text, "", "", "", "", "", "", "", "", "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_IsLocked"].ToString())].Text, ""));
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Action"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Scheme"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_LocID"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_ID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Date"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_DepID"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_SBUID"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_ENTID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_COCID"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_EID"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPID"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPDate"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_AdjustmtEntry"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_ReversalDate"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_ReversalCost"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_IVORFV"].ToString())].Text = historicalCost.rdbVMCC01.Checked ? historicalCost.rdbVMCC01.Text : historicalCost.rdbVMCC02.Text;
                        if (!e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Text.Equals("") && !e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Controls.Add(AddControl(historicalCost, "TextBox", "", "", "", "txtUpdateCost", e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_LocID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_DepID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_SBUID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_ENTID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_COCID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_EID"].ToString())].Text, (accountingProperties.VAL_METH_CAL_CC_LABEL_ID.Equals("rdbVMCC01") ? e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBYIV"].ToString())].Text : e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBYFV"].ToString())].Text), "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBYFV"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_IsLocked"].ToString())].Text, ""));
                            e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Controls.Add(AddControl(historicalCost, "Label", "", "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Text, "", "", "", "", "", "", "", "", "", "", "", "", "", ""));
                        }
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_ExerPrice"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_VestedCancelled"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_UnvestedCancelled"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_Lapsed"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_ExeOptions"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_FRate"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_GOptions"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBYFV"].ToString())].Visible = false;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBYIV"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_HCList["n_IsLocked"].ToString())].Visible = false;

                        //If vestwise client is present
                        if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                        {
                            e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Controls.Add(AddControl(historicalCost, "HyperLink", "", "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_ID"].ToString())].Text, "lnkAddVest", e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Text, "", "", "", "", "", "", "", "", "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_IsLocked"].ToString())].Text, ""));
                        }

                        if (e.Row.Cells[Convert.ToInt32(hash_HCList["n_IsLocked"].ToString())].Text.Equals("1"))
                            historicalCost.hdnisLocked.Value = "1";

                        SetIDsToHdnFields("", historicalCost, e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Text);

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text.Equals("&nbsp;") && (!e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Text.Equals("") && !e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantOptioID"].ToString())].Text.Equals("&nbsp;")))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].Controls.Add(AddControl(historicalCost, "TextBox", "", "", "", "txtUpdateCost", e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_OPT_GRANTED_ID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_LocID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_DepID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_SBUID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_ENTID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_COCID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_EID"].ToString())].Text, (accountingProperties.VAL_METH_CAL_CC_LABEL_ID.Equals("rdbVMCC01") ? e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBYIV"].ToString())].Text : e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBYFV"].ToString())].Text), "", e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBYFV"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_HCList["n_IsLocked"].ToString())].Text, ""));
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_HCostManulally"].ToString())].HorizontalAlign = HorizontalAlign.Right;
                            }

                            if (!e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Text = Convert.ToDouble(e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[Convert.ToInt32(hash_HCList["n_CostBySystem"].ToString())].HorizontalAlign = HorizontalAlign.Right;
                            }
                        }
                        #endregion

                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_OutstandingOpt"].ToString())].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[Convert.ToInt32(hash_HCList["n_GrantDate"].ToString())].HorizontalAlign = HorizontalAlign.Center;
                        break;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to set Config ID's to hidden fields
        /// </summary>
        /// <param name="s_PID">PID: primary key</param>
        /// <param name="historicalCost">historicalCost page object</param>
        /// <param name="s_OGID">string OPt_Granted ID object</param>
        private void SetIDsToHdnFields(string s_PID, HistoricalCost historicalCost, string s_OGID)
        {
            if (!string.IsNullOrEmpty(s_OGID) || !s_PID.Equals("&nbsp;"))
            {
                historicalCost.hdnSelectedToSaveRecords.Value = s_OGID;
            }
        }

        #region Add Control/New row to gridview
        /// <summary>
        /// This method is used to add the control in gridview
        /// </summary>
        /// <param name="historicalCost">Historical Cost Page object</param>
        /// <param name="s_ControlName">ControlName object</param>
        /// <param name="s_Name">Control Name Object</param>
        /// <param name="s_OPID">OPID Object</param>
        /// <param name="s_GOPID">GOPID Object</param>
        /// <param name="s_ControlID">Control ID object</param>
        /// <param name="s_OID">OID object</param>
        /// <param name="s_OPT_GRANTED_ID">OPT_GRANTED_ID object</param>
        /// <param name="s_LOCID">LOCID object</param>
        /// <param name="s_DeptID">DEPT object</param>
        /// <param name="s_SBUID">SBU object</param>
        /// <param name="s_ENTID">ENT object</param>
        /// <param name="s_CoCID">CoCID object</param>
        /// <param name="s_EID">EID object</param>
        /// <param name="s_CostBySystem">Cost By System object</param>
        /// <param name="s_FinalCost">Final Cost object</param>
        /// <param name="s_CostBYFV">Cost BY FV object</param>
        /// <param name="s_IsLocked">IsLocked object</param>
        /// <param name="s_ParamValue">ParamValue object</param>
        /// <returns>return the control</returns>
        private Control AddControl(HistoricalCost historicalCost, string s_ControlName, string s_Name, string s_OPID, string s_GOPID, string s_ControlID, string s_OID, string s_OPT_GRANTED_ID, string s_LOCID, string s_DeptID, string s_SBUID, string s_ENTID, string s_CoCID, string s_EID, string s_CostBySystem, string s_FinalCost, string s_CostBYFV, string s_IsLocked, string s_ParamValue)
        {
            switch (s_ControlName)
            {
                case "CheckBox":
                    CheckBox checkBox = new CheckBox();

                    checkBox.Text = string.Empty;
                    checkBox.AutoPostBack = false;
                    checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    checkBox.Style.Add("cursor", "pointer");
                    if (s_ControlID.Equals("chkAdd"))
                    {
                        checkBox.ID = "chkAdd";
                        checkBox.InputAttributes.Add("Value", "0");
                        if (ac_HistoricalCost.dt_HCEditDetails != null && ac_HistoricalCost.dt_HCEditDetails.Rows.Count > 0)
                        {
                            checkBox.Checked = (ac_HistoricalCost.dt_HCEditDetails != null && ac_HistoricalCost.dt_HCEditDetails.Select("OPID = '" + s_OPID + "'").Count() > 0) ? true : false;
                        }
                        else
                            checkBox.Checked = (ac_HistoricalCost.dt_SelectedDataTables != null && ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0 && ac_HistoricalCost.dt_SelectedDataTables.Select("OPT_GRANTED_ID = '" + s_OPT_GRANTED_ID + "'").Count() > 0) ? true : false;
                        checkBox.Attributes.Add("onclick", "return SelectRecords(this,'" + userSessionInfo.ACC_CalculationMethod + "','" + s_IsLocked + "')");
                        if (!string.IsNullOrEmpty(s_IsLocked) && s_IsLocked.Equals("1"))
                        {
                            checkBox.Enabled = false;
                            ac_HistoricalCost.b_IsLocked = true;
                        }
                    }
                    else if (s_ControlID.Equals("chkHistory"))
                    {
                        checkBox.ID = "chkHistory";
                        checkBox.InputAttributes.Add("Value", s_OPT_GRANTED_ID);
                        if (s_IsLocked.Equals("1"))
                            checkBox.InputAttributes.Add("Class", "Locked");
                        if (!string.IsNullOrEmpty(s_OPT_GRANTED_ID))
                        {
                            checkBox.Attributes.Add("onclick", "return DeleteRecords('" + s_OPT_GRANTED_ID + "',this, '" + s_IsLocked + "')");
                        }
                        else
                        {
                            if (s_Name.Equals("SelectAllCheckBoxes"))
                                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                        }
                    }
                    else if (s_ControlID.Equals("chkDeleteAll"))
                    {
                        checkBox.ID = "chkDeleteAll";
                        checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                    }
                    else if (s_ControlID.Equals("SelectAll"))
                    {
                        checkBox.ID = "chkSelectAll";
                        checkBox.Attributes.Add("onclick", "return SelectAllRecords(this,'" + userSessionInfo.ACC_CalculationMethod + "')");
                    }
                    return checkBox;

                case "HyperLink":
                    HyperLink hyperLink = new HyperLink();
                    hyperLink.ClientIDMode = ClientIDMode.Static;
                    hyperLink.CssClass = "cHyperLinksp";
                    hyperLink.TabIndex = 9;
                    switch (s_ControlID)
                    {
                        case "lnkAddVest":
                            hyperLink.Text = "View Details";
                            hyperLink.ToolTip = "Click here to View Vest Details";
                            hyperLink.ID = "lnkAddVest";
                            hyperLink.Attributes.Add("onclick", "return VestDetails('" + s_OPT_GRANTED_ID + "', '" + s_OID + "','Add',this,'" + s_IsLocked + "')");
                            if (!string.IsNullOrEmpty(s_IsLocked) && s_IsLocked.Equals("1"))
                                hyperLink.Enabled = false;
                            break;

                        case "lnkVHistory":
                            hyperLink.Text = "View History";
                            hyperLink.ToolTip = "Click here to View History";
                            hyperLink.ID = "lnkVHistory";
                            hyperLink.Attributes.Add("onclick", "return ViewHistory('" + s_OPT_GRANTED_ID + "',this)");
                            break;

                        case "lnkViewVest":
                            hyperLink.Text = "View Vest";
                            hyperLink.ToolTip = "Click here to View Vest Details";
                            hyperLink.ID = "lnkViewVest";
                            hyperLink.Attributes.Add("onclick", "return VestDetails('" + s_OPT_GRANTED_ID + "', '" + s_OID + "','View',this)");
                            break;
                    }
                    return hyperLink;

                case "Label":
                    Label label = new Label();
                    label.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                    if ((s_ControlID.Equals("lblGOPID")))
                    {
                        label.Text = s_GOPID + "  ";
                        label.ID = "lblGOPID";
                    }
                    else if (s_ControlID.Equals("lblSPFinalCost"))
                    {
                        label.ID = "lblSPFinalCost";
                        label.CssClass = "lblSPFinalCost";
                        label.Text = (ac_HistoricalCost.dt_Edit_Maintaind_HCost != null && ac_HistoricalCost.dt_Edit_Maintaind_HCost.Rows.Count > 0 && ac_HistoricalCost.dt_Edit_Maintaind_HCost.Select("ID = '" + s_Name + "'").Count() > 0) ? (Convert.ToString(ac_HistoricalCost.dt_Edit_Maintaind_HCost.Select("ID = '" + s_Name + "'")[0]["Final Cost"])) : string.Empty;
                    }
                    else
                    {
                        label.Text = s_GOPID + "  ";
                        label.ID = "lblHistory";
                    }
                    return label;

                case "TextBox":
                    TextBox textBox = new TextBox();
                    if (s_ControlID.Equals("txtHCostManually"))
                    {
                        textBox.ID = "txtHCostManually";
                        textBox.CssClass = "txtHCostManually";
                        textBox.Attributes.Add("OnKeyUp", "javascript:return Calculate(this,'')");
                        textBox.Attributes.Add("onkeypress", "javascript:return isNumber(event)");
                    }
                    else if (s_ControlID.Equals("txtUpdateCost"))
                    {
                        string s_IsChecked = (ac_HistoricalCost.dt_SelectedDataTables != null && ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0 && ac_HistoricalCost.dt_SelectedDataTables.Select("OPT_GRANTED_ID = '" + s_OPT_GRANTED_ID + "'").Count() > 0) ? "1" : "0";
                        string s_IsCheckedAtEdit = (ac_HistoricalCost.dt_HCEditDetails != null && ac_HistoricalCost.dt_HCEditDetails.Rows.Count > 0 && ac_HistoricalCost.dt_HCEditDetails.Select("OPGID = '" + s_OPT_GRANTED_ID + "'").Count() > 0) ? "1" : "0";
                        string s_IsPresent = string.IsNullOrEmpty(historicalCost.hdnEdit.Value) ? s_IsChecked : s_IsCheckedAtEdit;
                        /* use below ID when pagination is present 
                        textBox.ID = "txtUpdateCost" + "\\|\\" + s_OID + "\\|\\" + s_OPT_GRANTED_ID + "\\|\\" + s_LOCID + "\\|\\" + s_DeptID + "\\|\\" + s_SBUID + "\\|\\" + s_ENTID + "\\|\\" + s_CoCID + "\\|\\" + s_EID + "\\|\\" + s_CostBySystem + "\\|\\" + s_IsPresent + "";
                         textBox.EnableViewState = false; */
                        textBox.ID = "txtUpdateCost" + "|" + s_OID + "|" + s_OPT_GRANTED_ID + "|" + s_LOCID + "|" + s_DeptID + "|" + s_SBUID + "|" + s_ENTID + "|" + s_CoCID + "|" + s_EID + "|" + s_CostBySystem + "|" + s_IsPresent + "|" + s_CostBYFV + "";
                        textBox.CssClass = "txtUpdateCost";

                        textBox.Enabled = false;
                        textBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        if (ac_HistoricalCost.dt_HCEditDetails != null && ac_HistoricalCost.dt_HCEditDetails.Rows.Count > 0 && (ac_HistoricalCost.dt_HCEditDetails.Select("OPGID = '" + s_OPT_GRANTED_ID + "'").Count() > 0))
                        {
                            textBox.Text = (Convert.ToString(ac_HistoricalCost.dt_HCEditDetails.Select("OPGID = '" + s_OPT_GRANTED_ID + "'")[0]["Update Cost"]));
                            textBox.Enabled = userSessionInfo.ACC_CalculationMethod.Equals(2) ? false : true;
                            textBox.Attributes.Add("OnKeyUp", "javascript:return CalculateAtEdit(this)");
                        }
                        else if (ac_HistoricalCost.dt_SelectedDataTables != null && ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0 && ac_HistoricalCost.dt_SelectedDataTables.Select("OPT_GRANTED_ID = '" + s_OPT_GRANTED_ID + "'").Count() > 0)
                        {
                            textBox.Text = (ac_HistoricalCost.dt_SelectedDataTables != null && ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0 && ac_HistoricalCost.dt_SelectedDataTables.Select("OPT_GRANTED_ID = '" + s_OPT_GRANTED_ID + "'").Count() > 0) ? Convert.ToString(ac_HistoricalCost.dt_SelectedDataTables.Select("OPT_GRANTED_ID = '" + s_OPT_GRANTED_ID + "'")[0]["UpdateCost"]) : string.Empty;
                            textBox.Enabled = true;
                            textBox.Attributes.Add("OnKeyUp", "javascript:return Calculate(this,'')");
                        }
                        else
                        {
                            textBox.Text = (ac_HistoricalCost.dt_FilterDetails != null && ac_HistoricalCost.dt_FilterDetails.Select("OPGID = '" + s_OPT_GRANTED_ID + "'").Count() > 0) ? Convert.ToString(ac_HistoricalCost.dt_FilterDetails.Select("OPGID = '" + s_OPT_GRANTED_ID + "'")[0]["Update Cost"]) : string.Empty;
                            textBox.Attributes.Add("OnKeyUp", "javascript:return Calculate(this,'')");
                        }
                        textBox.Attributes.Add("onkeypress", "javascript:return isNumber(event)");
                    }
                    else if (s_ControlID.Equals("txtVestwise"))
                    {
                        textBox.ID = "txtVestwise";
                        textBox.CssClass = "txtVestwise";
                        if (ac_HistoricalCost.dt_HCEditVestWise != null && ac_HistoricalCost.dt_HCEditVestWise.Rows.Count > 0 && ac_HistoricalCost.dt_HCEditVestWise.Select("GID = '" + s_OPT_GRANTED_ID + "'").Count() > 0)
                            textBox.Text = (Convert.ToString(ac_HistoricalCost.dt_HCEditVestWise.Select("GID = '" + s_OPT_GRANTED_ID + "'")[0]["UpdatedCost"]));
                    }
                    else if (s_ControlID.Equals("txtSPAdjustmtEntry"))
                    {
                        textBox.ID = "txtSPAdjustmtEntry";
                        textBox.ID = "txtSPAdjustmtEntry" + "|" + s_Name + "|" + s_FinalCost + "|" + s_ParamValue + "|" + s_EID;
                        textBox.CssClass = "txtSPAdjustmtEntry";
                        if (ac_HistoricalCost.dt_Edit_Maintaind_HCost != null && ac_HistoricalCost.dt_Edit_Maintaind_HCost.Rows.Count > 0 && ac_HistoricalCost.dt_Edit_Maintaind_HCost.Select("ID = '" + s_Name + "'").Count() > 0)
                            textBox.Text = (Convert.ToString(ac_HistoricalCost.dt_Edit_Maintaind_HCost.Select("ID = '" + s_Name + "'")[0]["Adjustment Entry"]));
                        textBox.Attributes.Add("OnKeyUp", "javascript:return CalculateByParameter(this)");
                        textBox.Attributes.Add("onkeypress", "javascript:return isNumber(event)");
                    }
                    else
                    {
                        textBox.ID = "txtAdjustment";
                        textBox.CssClass = "txtAdjustment";

                    }
                    return textBox;
            }
            return new Control();
        }


        /// <summary>
        /// This method is used to add the new row in gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="historicalCost"></param>
        /// <param name="e"></param>
        /// <param name="s_ControlName"></param>
        /// <param name="gv"></param>
        internal void AddNewRow(object sender, HistoricalCost historicalCost, EventArgs e, string s_ControlName, GridView gv)
        {
            switch (s_ControlName)
            {
                case "gv":
                    if (ac_HistoricalCost.Rowcount > 0)
                    {
                        using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
                        {
                            TableCell cell = new TableCell();
                            cell.Text = "Total";
                            cell.ColumnSpan = 14;
                            cell.Font.Bold = true;
                            cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                            cell.HorizontalAlign = HorizontalAlign.Left;
                            row.Controls.Add(cell);

                            cell = new TableCell();
                            Label lblTotal = new Label();
                            lblTotal.ID = "lblTotal";
                            lblTotal.Text = (ac_HistoricalCost.dt_HCEditDetails != null && ac_HistoricalCost.dt_HCEditDetails.Rows.Count > 0 && ac_HistoricalCost.dt_HCEditDetails.Select("OPGID = '" + ac_HistoricalCost.OPT_Granted_ID + "'").Count() > 0) ?Convert.ToString(ac_HistoricalCost.dt_HCEditDetails.Select("OPGID = '" + ac_HistoricalCost.OPT_Granted_ID + "'")[0]["Update Cost"]) : (ac_HistoricalCost.dt_SelectedDataTables != null && ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0 && ac_HistoricalCost.dt_SelectedDataTables.Select("[UpdateCost] is not null").Length > 0) ?Convert.ToString(ac_HistoricalCost.dt_SelectedDataTables.AsEnumerable().Sum(x => x.Field<decimal?>("UpdateCost"))) :historicalCost.hdnTotal.Value.Replace(",0", string.Empty);
                            cell.Controls.Add(lblTotal);
                            row.Controls.Add(cell);
                            gv.HeaderRow.Parent.Controls.AddAt(ac_HistoricalCost.Rowcount + 1, row);
                            cell.Dispose();
                        }
                        using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
                        {
                            TableCell cell = new TableCell();

                            cell.Text = "Adjustment";
                            cell.ColumnSpan = 14;
                            cell.Font.Bold = true;
                            cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                            cell.HorizontalAlign = HorizontalAlign.Left;
                            row.Controls.Add(cell);

                            cell = new TableCell();
                            TextBox txtAdjustment = new TextBox();
                            txtAdjustment.ID = "txtAdjustment";
                            if (ac_HistoricalCost.dt_HCEditDetails != null && ac_HistoricalCost.dt_HCEditDetails.Rows.Count > 0 && ac_HistoricalCost.dt_HCEditDetails.Select("OPGID = '" + ac_HistoricalCost.OPT_Granted_ID + "'").Count() > 0)
                                txtAdjustment.Text = Convert.ToString(ac_HistoricalCost.dt_HCEditDetails.Select("OPGID = '" + ac_HistoricalCost.OPT_Granted_ID + "'")[0]["Adjustment Entry"]);
                            else if (ac_HistoricalCost.dt_FilterDetails != null && ac_HistoricalCost.dt_FilterDetails.Rows.Count > 0 && ac_HistoricalCost.dt_FilterDetails.Select("[Update Cost] is not null").Length > 0 && ac_HistoricalCost.dt_SelectedDataTables.Rows.Count.Equals(0))
                            {
                                var groupedRecords = ac_HistoricalCost.dt_FilterDetails.AsEnumerable().GroupBy(item => item.Field<int>("OPGID"));
                                var selRecords = groupedRecords.Select(grp => grp.OrderBy(item => item.Field<int>("OPGID")).First());
                                var Result = Convert.ToString(selRecords.CopyToDataTable().AsEnumerable().Where(b => b["Adjustment Entry"].ToString() != "").Sum(x => x.Field<decimal?>("Adjustment Entry")));
                                txtAdjustment.Text = Result.ToString();
                            }
                            else
                                txtAdjustment.Text = historicalCost.hdnAdjustValue.Value.Replace(",0", string.Empty);

                            historicalCost.txtReversalCost.Text = (!string.IsNullOrEmpty(txtAdjustment.Text) && txtAdjustment.Text.IndexOf("-").Equals(-1)) ? "-" + txtAdjustment.Text : txtAdjustment.Text.IndexOf("-") < 1 ? txtAdjustment.Text.Replace("-", "") : txtAdjustment.Text;

                            cell.Controls.Add(txtAdjustment);
                            row.Controls.Add(cell);

                            gv.HeaderRow.Parent.Controls.AddAt(ac_HistoricalCost.Rowcount + 2, row);
                            txtAdjustment.CssClass = "txtAdjustment";
                            txtAdjustment.Attributes.Add("OnKeyUp", "javascript:return CalculateFinalCost(this)");
                            txtAdjustment.Attributes.Add("onkeypress", "javascript:return AllowForAdjustment(event)");
                            cell.Dispose();
                        }
                        using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
                        {
                            TableCell cell = new TableCell();

                            cell.Text = "Final Cost";
                            cell.ColumnSpan = 14;
                            cell.Font.Bold = true;
                            cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                            cell.HorizontalAlign = HorizontalAlign.Left;
                            row.Controls.Add(cell);

                            cell = new TableCell();
                            Label lblFinalCost = new Label();
                            lblFinalCost.ID = "lblFinalCost";
                            lblFinalCost.Text = ac_HistoricalCost.dt_HCEditDetails != null && ac_HistoricalCost.dt_HCEditDetails.Rows.Count > 0 && ac_HistoricalCost.dt_HCEditDetails.Select("OPGID = '" + ac_HistoricalCost.OPT_Granted_ID + "'").Count() > 0 ? Convert.ToString(Convert.ToInt64(ac_HistoricalCost.dt_HCEditDetails.Select("OPGID = '" + ac_HistoricalCost.OPT_Granted_ID + "'")[0]["Adjustment Entry"]) + Convert.ToInt64(ac_HistoricalCost.dt_HCEditDetails.Select("OPGID = '" + ac_HistoricalCost.OPT_Granted_ID + "'")[0]["Update Cost"])) : (ac_HistoricalCost.dt_SelectedDataTables != null && ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0 && ac_HistoricalCost.dt_SelectedDataTables.Select("[UpdateCost] is not null").Length > 0 && ac_HistoricalCost.dt_SelectedDataTables.Select("[ADJUSTMENT_ENTRY] is not null").Length > 0) ? Convert.ToString(Convert.ToDecimal(ac_HistoricalCost.dt_SelectedDataTables.AsEnumerable().Sum(x => x.Field<decimal?>("ADJUSTMENT_ENTRY"))) + Convert.ToDecimal(ac_HistoricalCost.dt_SelectedDataTables.AsEnumerable().Sum(x => x.Field<decimal?>("UpdateCost")))) : historicalCost.hdnFinalCost.Value.Replace(",0", string.Empty);
                            cell.Controls.Add(lblFinalCost);
                            row.Controls.Add(cell);

                            gv.HeaderRow.Parent.Controls.AddAt(ac_HistoricalCost.Rowcount + 3, row);
                            cell.Dispose();
                        }
                    }
                    break;
            }
        }

        #endregion

        /// <summary>
        /// This method is used to add the search parameter gridview
        /// </summary>
        /// <param name="historicalCost">Historical Cost page object</param>
        internal void BindAddParmsGrid(HistoricalCost historicalCost)
        {
            try
            {
                string s_result = string.Join(",", GetParameter(historicalCost.ddlAParms.SelectedItem.Text, "PValue").Split(',').Select(s => s.Insert(0, "'") + "'").Distinct().ToArray());
                ac_HistoricalCost.s_OPGlist = GetParameter("", "OPGList");
                if (!string.IsNullOrEmpty(s_result))
                {
                    ac_HistoricalCost.PARAMETER_NAME = historicalCost.ddlAParms.SelectedItem.Text.Equals("Please Select") ? string.Empty : historicalCost.ddlAParms.SelectedItem.Text;
                    string s_parameter = string.Empty;
                    switch (historicalCost.ddlAParms.SelectedItem.Text)
                    {
                        case "LOCATION":
                            s_parameter = "LOCATION";
                            break;

                        case "COST_CENTRE":
                            s_parameter = "COST_CENTRE";
                            break;
                        case "ENTITY":
                            s_parameter = "ENTITY";
                            break;
                        case "DEPARTMENT":
                            s_parameter = "DEPARTMENT";
                            break;
                        case "SBU":
                            s_parameter = "SBU";
                            break;
                    }
                    var O_sells = ac_HistoricalCost.dt_FilterDetails.AsEnumerable()
                                .GroupBy(row => row[s_parameter].ToString())
                                .Select(a => new
                                {
                                    Amount = 0,
                                    CostAmt = a.Sum(b => string.IsNullOrEmpty(b["Cost as per System By IV/FV"].ToString()) ? 0 : Convert.ToDecimal(b["Cost as per System By IV/FV"])),
                                    Name = a.Key
                                })
                                .OrderByDescending(a => a.Amount)
                                .ToList();
                    if (ac_HistoricalCost.ds_HCDetails.Tables[2].Rows.Count > 0)
                    {
                        using (DataTable dt_TMDetails = ac_HistoricalCost.ds_HCDetails.Tables[2])
                        {
                            string s_FieldName = "[Name] = '" + historicalCost.ddlAParms.SelectedItem.Text.ToString() + "'";
                            DataTable dt_TMDFiltered = new DataTable();
                            dt_TMDetails.DefaultView.RowFilter = "" + s_FieldName + " AND " + " [Parameter Value] IN (" + s_result + ") ";
                            dt_TMDFiltered = dt_TMDetails.DefaultView.ToTable();

                            dt_TMDFiltered.AcceptChanges();

                            foreach (DataRow perRow in dt_TMDFiltered.Rows)
                            {
                                foreach (var PItem in O_sells)
                                {
                                    if (Convert.ToString(perRow["Parameter Value"]).Equals(PItem.Name))
                                    {
                                        perRow["Updated Cost"] = Convert.ToDecimal(PItem.Amount);
                                        perRow["Cost as per System"] = Convert.ToDecimal(PItem.CostAmt);
                                    }
                                }
                            }

                            /*If Search filter contains data*/
                            if ((dt_TMDFiltered != null && dt_TMDFiltered.Rows.Count > 0))
                            {
                                ac_HistoricalCost.dt_Add_SParms_details = dt_TMDFiltered;
                                ac_HistoricalCost.AParmsRowcount = ac_HistoricalCost.dt_Add_SParms_details.Rows.Count;
                                ac_HistoricalCost.AParmsColcount = ac_HistoricalCost.dt_Add_SParms_details.Columns.Count;
                                Resetvalues(historicalCost);
                                historicalCost.gvAParmsHCost.DataSource = ac_HistoricalCost.dt_Add_SParms_details;
                                historicalCost.gvAParmsHCost.DataBind();
                                historicalCost.gvAParmsHCost.Visible = true;
                                historicalCost.lblMsg.Visible = true;
                                if (ac_HistoricalCost.IsParameterCheck.Equals("1"))
                                {
                                    ac_HistoricalCost.dt_Add_SParms_details.Columns.Remove("Name");
                                }
                            }
                            else
                            {
                                BindNullGrid(historicalCost, "gvAParmsHCost");
                                historicalCost.lblMsg.Visible = false;
                            }
                        }
                    }
                }
                else
                {
                    DisplayMessage(historicalCost, "ParameterPresent");
                    ReBindGridsOnPostBack(historicalCost, false);
                    ac_HistoricalCost.IsParameterCheck = "0";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        /// <summary>
        /// This method is used to add the search parameter gridview
        /// </summary>
        /// <param name="historicalCost">Historical Cost page object</param>
        internal void BindAddParmsGridView(HistoricalCost historicalCost)
        {
            try
            {
                ac_HistoricalCost.dt_SelectedDataTables = ac_HistoricalCost.dt_SelectedParmsFilter.Copy();
                if (ac_HistoricalCost.dt_SelectedDataTables != null && ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0)
                {
                    ac_HistoricalCost.dt_SelectedDataTables.Columns["ADJUSTMENT_ENTRY"].Expression = (HttpContext.Current.Session["ADJUSTMENT_ENTRY"] != null) ? HttpContext.Current.Session["ADJUSTMENT_ENTRY"].ToString() : "0";
                    string s_result = string.Join(",", GetParameter(historicalCost.ddlAParms.SelectedItem.Text, "PValue").Split(',').Select(s => s.Insert(0, "'") + "'").Distinct().ToArray());
                    if (!string.IsNullOrEmpty(s_result))
                    {
                        ac_HistoricalCost.PARAMETER_NAME = historicalCost.ddlAParms.SelectedItem.Text.Equals("Please Select") ? string.Empty : historicalCost.ddlAParms.SelectedItem.Text;
                        string s_parameter = string.Empty;
                        switch (historicalCost.ddlAParms.SelectedItem.Text)
                        {
                            case "LOCATION":
                                s_parameter = "LOCATION";
                                break;

                            case "COST_CENTRE":
                                s_parameter = "COST_CENTRE";
                                break;
                            case "ENTITY":
                                s_parameter = "ENTITY";
                                break;
                            case "DEPARTMENT":
                                s_parameter = "DEPARTMENT";
                                break;
                            case "SBU":
                                s_parameter = "SBU";
                                break;
                        }
                        var O_sells = ac_HistoricalCost.dt_SelectedDataTables.AsEnumerable()
                                    .GroupBy(row => row[s_parameter].ToString())
                                    .Select(a => new
                                    {
                                        Amount = a.Sum(b => string.IsNullOrEmpty(b["UpdateCost"].ToString()) ? 0 : Convert.ToDecimal(b["UpdateCost"])),
                                        CostAmt = a.Sum(b => string.IsNullOrEmpty(b["COST_AS_PER_SYSTEM"].ToString()) ? 0 : Convert.ToDecimal(b["COST_AS_PER_SYSTEM"])),
                                        Name = a.Key
                                    })
                                        .OrderByDescending(a => a.Amount)
                                        .ToList();

                        var O_Fsells = ac_HistoricalCost.dt_FilterDetails.AsEnumerable().
                                                         Where(b => b[s_parameter].ToString() != "")
                                                        .GroupBy(row => row[s_parameter].ToString())
                                                        .Select(a => new
                                                        {
                                                            FAmount = a.Sum(b => string.IsNullOrEmpty(b["Update Cost"].ToString()) ? 0 : Convert.ToDecimal(b["Update Cost"])),
                                                            FCostAmt = a.Sum(b => string.IsNullOrEmpty(b["Cost as per System By IV/FV"].ToString()) ? 0 : Convert.ToDecimal(b["Cost as per System By IV/FV"])),
                                                            Name = a.Key
                                                        })
                                                        .OrderByDescending(a => a.FAmount)
                                                        .ToList();

                        if (ac_HistoricalCost.ds_HCDetails.Tables[2].Rows.Count > 0)
                        {
                            using (DataTable dt_TMDetails = ac_HistoricalCost.ds_HCDetails.Tables[2])
                            {
                                string s_FieldName = "[Name] = '" + historicalCost.ddlAParms.SelectedItem.Text.ToString() + "'";
                                DataTable dt_TMDFiltered = new DataTable();
                                dt_TMDetails.DefaultView.RowFilter = "" + s_FieldName + " AND " + " [Parameter Value] IN (" + s_result + ")";
                                dt_TMDFiltered = dt_TMDetails.DefaultView.ToTable();

                                dt_TMDFiltered.AcceptChanges();

                                foreach (DataRow perRow in dt_TMDFiltered.Rows)
                                {
                                    foreach (var PItem in O_sells)
                                    {
                                        if (Convert.ToString(perRow["ID"]).Equals(PItem.Name))
                                        {
                                            perRow["Updated Cost"] = Convert.ToDecimal(PItem.Amount);
                                            perRow["Cost as per System"] = Convert.ToDecimal(PItem.CostAmt);
                                        }
                                        else
                                        {
                                            foreach (var PItems in O_Fsells.Where(x => x.Name.Equals(Convert.ToString(perRow["Parameter Value"]))))
                                            {
                                                perRow["Cost as per System"] = Convert.ToDecimal(PItems.FCostAmt);
                                            }
                                        }
                                    }
                                }

                                /*If Search filter contains data*/
                                if ((dt_TMDFiltered != null && dt_TMDFiltered.Rows.Count > 0))
                                {
                                    ac_HistoricalCost.dt_Add_SParms_details = dt_TMDFiltered;
                                    ac_HistoricalCost.AParmsRowcount = ac_HistoricalCost.dt_Add_SParms_details.Rows.Count;
                                    ac_HistoricalCost.AParmsColcount = ac_HistoricalCost.dt_Add_SParms_details.Columns.Count;
                                    Resetvalues(historicalCost);
                                    historicalCost.gvAParmsHCost.DataSource = ac_HistoricalCost.dt_Add_SParms_details;
                                    historicalCost.gvAParmsHCost.DataBind();
                                    historicalCost.gvAParmsHCost.Visible = true;
                                    historicalCost.lblMsg.Visible = true;
                                }
                                else
                                {
                                    BindNullGrid(historicalCost, "gvAParmsHCost");
                                    historicalCost.lblMsg.Visible = false;
                                }
                            }
                        }
                    }
                    else
                    {
                        DisplayMessage(historicalCost, "ParameterPresent");
                        ReBindGridsOnPostBack(historicalCost, false);
                        ac_HistoricalCost.IsParameterCheck = "0";
                    }
                }
                else
                {
                    BindAddParmsGrid(historicalCost);
                }
                historicalCost.ddlAParms.Visible = true;
                historicalCost.btnSNext.Visible = true;
                ReBindGridsOnPostBack(historicalCost, false);
                historicalCost.divASPToCalacHCost.Visible = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// This method is used to get Comma seprated list 
        /// </summary>
        /// <param name="s_parameter">parameter page object</param>
        /// <param name="s_ColName">Column name Object</param>
        /// <returns></returns>
        internal string GetParameter(string s_parameter, string s_ColName)
        {
            string s_result = string.Empty;
            if (ac_HistoricalCost.dt_FilterDetails != null && ac_HistoricalCost.dt_FilterDetails.Rows.Count > 0)
            {
                switch (s_ColName)
                {
                    case "PValue":
                        s_result = string.Join(",", ac_HistoricalCost.dt_FilterDetails.AsEnumerable().Where(b => b[s_parameter].ToString() != "")
                                    .Select(row => row[s_parameter].ToString()));

                        break;

                    case "OPGList":

                        s_result = string.Join(",", ac_HistoricalCost.dt_FilterDetails.AsEnumerable()
                                       .Where(b => b["OPGID"].ToString() != "")
                                       .Select(b => b["OPGID"])
                                       .ToArray());

                        break;
                }
            }

            return s_result.Trim();
        }


        /// <summary>
        ///  This method is used to bind the search parameter gridview row where u want to add the HC Cost
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="historicalCost">historical Cost</param>
        /// <param name="e">event</param>
        /// <param name="n_index">index number</param>
        /// <param name="n_ID">ID of table</param>
        /// <param name="n_Name">Name object</param>
        /// <param name="n_CostBySystem">Cost By System object</param>
        /// <param name="n_HCostManulally">HCostManulally object</param>
        /// <param name="n_AdjustmtEntry">Adjustmt Entry object</param>
        /// <param name="n_FinalCost">Final Cost object</param>
        /// <param name="d_Total">total object</param>
        /// <param name="d_UCTotal"> Update cost total</param>
        /// <param name="n_PValue">Parameter Value</param>
        /// <param name="n_PID">PID object</param>
        /// <param name="d_AdjustMent"> AdjustMent object</param>
        /// <param name="d_FCost">FCost object</param>
        /// <param name="n_EMPID">EMPID object</param>
        /// <param name="n_HC_PID">HC_PID object</param>
        internal void BindgvAParmsRows(object sender, HistoricalCost historicalCost, GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Name, ref int n_CostBySystem, ref int n_HCostManulally, ref int n_AdjustmtEntry, ref int n_FinalCost, ref decimal d_Total, ref decimal d_UCTotal, ref int n_PValue, ref int n_PID, ref decimal d_AdjustMent, ref decimal d_FCost, ref int n_EMPID, ref int n_HC_PID)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "NAME":
                                    n_Name = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "PARAMETER VALUE":
                                    n_PValue = n_index;
                                    break;
                                case "COST AS PER SYSTEM":
                                    n_CostBySystem = n_index;
                                    break;

                                case "UPDATED COST":
                                    n_HCostManulally = n_index;
                                    break;

                                case "ADJUSTMENT ENTRY":
                                    n_AdjustmtEntry = n_index;
                                    break;

                                case "FINAL COST":
                                    n_FinalCost = n_index;
                                    break;

                                case "ID":
                                    n_PID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "EMPID":
                                    n_EMPID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "HC_PID":
                                    n_HC_PID = n_index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;
                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_Name].Visible = e.Row.Cells[n_PID].Visible = e.Row.Cells[n_EMPID].Visible = e.Row.Cells[n_HC_PID].Visible = false;
                        e.Row.Cells[n_AdjustmtEntry].Controls.Add(AddControl(historicalCost, "TextBox", e.Row.Cells[n_PID].Text, "", "", "txtSPAdjustmtEntry", "", "", "", "", "", "", "", e.Row.Cells[n_EMPID].Text, "", e.Row.Cells[n_FinalCost].Text, "", "", e.Row.Cells[n_PValue].Text));
                        e.Row.Cells[n_FinalCost].Controls.Add(AddControl(historicalCost, "Label", e.Row.Cells[n_PID].Text, "", "", "lblSPFinalCost", "", "", "", "", "", "", "", e.Row.Cells[n_EMPID].Text, "", "", "", "", e.Row.Cells[n_PValue].Text));
                        decimal d_totalPrice = (string.IsNullOrEmpty(e.Row.Cells[n_CostBySystem].Text) || e.Row.Cells[n_CostBySystem].Text.Equals("&nbsp;")) ? 0 : Convert.ToDecimal(e.Row.Cells[n_CostBySystem].Text);
                        d_Total = d_Total + d_totalPrice;
                        decimal d_totalUPrice = (string.IsNullOrEmpty(e.Row.Cells[n_HCostManulally].Text) || e.Row.Cells[n_HCostManulally].Text.Equals("&nbsp;")) ? 0 : Convert.ToDecimal(e.Row.Cells[n_HCostManulally].Text);
                        d_UCTotal = d_UCTotal + d_totalUPrice;

                        decimal d_Adjustmt = (string.IsNullOrEmpty(e.Row.Cells[n_AdjustmtEntry].Text) || e.Row.Cells[n_AdjustmtEntry].Text.Equals("&nbsp;")) ? 0 : Convert.ToDecimal(e.Row.Cells[n_AdjustmtEntry].Text);
                        d_AdjustMent = d_AdjustMent + d_Adjustmt;

                        decimal d_FinalCost = (string.IsNullOrEmpty(e.Row.Cells[n_FinalCost].Text) || e.Row.Cells[n_FinalCost].Text.Equals("&nbsp;")) ? 0 : Convert.ToDecimal(e.Row.Cells[n_FinalCost].Text);
                        d_FCost = d_FCost + d_FinalCost;
                        break;

                    case DataControlRowType.Footer:
                        e.Row.Cells[0].Text = "Total";
                        e.Row.Cells[0].Font.Bold = true;
                        e.Row.Cells[1].Font.Bold = true;
                        e.Row.Cells[2].Font.Bold = true;
                        e.Row.Cells[3].Font.Bold = true;
                        e.Row.Cells[4].Font.Bold = true;
                        e.Row.Cells[0].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[1].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[2].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[3].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[4].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[5].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[5].Visible = e.Row.Cells[6].Visible = e.Row.Cells[7].Visible = false;
                        e.Row.Cells[8].Visible = false;
                        e.Row.Cells[1].Text = d_Total.ToString("#.000");
                        e.Row.Cells[2].Text = d_UCTotal.ToString("#.000");
                        e.Row.Cells[2].ID = "LblUpdateCost";
                        e.Row.Cells[3].ID = "LblAdjustmt";
                        e.Row.Cells[5].ID = "LblFinalCostByParameter";
                        e.Row.Cells[3].Text = d_AdjustMent.ToString("#.000");
                        e.Row.Cells[4].Text = d_FCost.ToString("#.000");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        ///  This method is used to bind the search parameter gridview row where we  display history of  Historical Cost
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="historicalCost">historical Cost</param>
        /// <param name="e">event</param>
        /// <param name="n_index">index number</param>
        /// <param name="n_ID">ID of table</param>
        /// <param name="n_Name">Name object</param>
        /// <param name="n_CostBySystem">Cost By System object</param>
        /// <param name="n_HCostManulally">HCostManulally object</param>
        /// <param name="n_AdjustmtEntry">Adjustmt Entry object</param>
        /// <param name="n_FinalCost">Final Cost object</param>
        /// <param name="d_total">total object</param>
        /// <param name="d_UCTotal"> Update cost total</param>
        /// <param name="n_PValue">Parameter Value</param>
        /// <param name="n_PID">PID Value</param>
        /// <param name="d_AdjustMent">AdjustMent Value</param>
        /// <param name="d_FCost">FCost Value</param>
        /// <param name="n_Date">Date Value</param>
        /// <param name="n_EMPID">EmpID Value</param>
        /// <param name="n_HC_PID">HC_PID Value</param>
        internal void BindgvSearchParmsRows(object sender, HistoricalCost historicalCost, GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Name, ref int n_CostBySystem, ref int n_HCostManulally, ref int n_AdjustmtEntry, ref int n_FinalCost, ref decimal d_total, ref decimal d_UCTotal, ref int n_PValue, ref int n_PID, ref decimal d_AdjustMent, ref decimal d_FCost, ref int n_Date, ref int n_EMPID, ref int n_HC_PID)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "NAME":
                                    n_Name = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "PARAMETER VALUE":
                                    n_PValue = n_index;
                                    break;

                                case "COST AS PER SYSTEM":
                                    n_CostBySystem = n_index;
                                    break;

                                case "UPDATED COST":
                                    n_HCostManulally = n_index;
                                    break;

                                case "ADJUSTMENT ENTRY":
                                    n_AdjustmtEntry = n_index;
                                    break;

                                case "FINAL COST":
                                    n_FinalCost = n_index;
                                    break;

                                case "ID":
                                    n_PID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "EMPID":
                                    n_EMPID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "HC_PID":
                                    n_HC_PID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPERATION_DATE":
                                    n_Date = n_index;
                                    break;

                            }
                            n_index = n_index + 1;
                        }
                        break;
                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_Name].Visible = e.Row.Cells[n_PID].Visible =
                         e.Row.Cells[n_EMPID].Visible = e.Row.Cells[n_HC_PID].Visible = false;
                        decimal d_totalPrice = Convert.ToDecimal(e.Row.Cells[n_CostBySystem].Text);
                        d_total = d_total + d_totalPrice;
                        decimal d_totalUPrice = !string.IsNullOrEmpty(e.Row.Cells[n_HCostManulally].Text) ? Convert.ToDecimal(e.Row.Cells[n_HCostManulally].Text) : 0;
                        d_UCTotal = d_UCTotal + d_totalUPrice;

                        decimal d_Adjustmt = e.Row.Cells[n_AdjustmtEntry].Text.Equals("&nbsp;") ? 0 : Convert.ToDecimal(e.Row.Cells[n_AdjustmtEntry].Text);
                        d_AdjustMent = d_AdjustMent + d_Adjustmt;

                        decimal d_FinalCost = e.Row.Cells[n_FinalCost].Text.Equals("&nbsp;") ? 0 : Convert.ToDecimal(e.Row.Cells[n_FinalCost].Text);
                        d_FCost = d_FCost + d_FinalCost;
                        break;

                    case DataControlRowType.Footer:
                        e.Row.Cells[0].Text = "Total";
                        e.Row.Cells[0].Font.Bold = true;
                        e.Row.Cells[0].ColumnSpan = 2;
                        e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[1].Font.Bold = true;
                        e.Row.Cells[2].Font.Bold = true;
                        e.Row.Cells[3].Font.Bold = true;
                        e.Row.Cells[4].Font.Bold = true;
                        e.Row.Cells[0].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[1].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[2].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[3].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[4].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[5].BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                        e.Row.Cells[5].Visible = e.Row.Cells[6].Visible = false;
                        e.Row.Cells[7].Visible = e.Row.Cells[8].Visible = e.Row.Cells[9].Visible = false;
                        e.Row.Cells[1].Text = d_total.ToString("#.000");
                        e.Row.Cells[2].Text = d_UCTotal.ToString("#.000");
                        e.Row.Cells[3].Text = d_AdjustMent.ToString("#.000");
                        e.Row.Cells[4].Text = d_FCost.ToString("#.000");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Display Message Box
        /// <summary>
        /// This Method is used to Display Message Box
        /// </summary>
        /// <param name="historicalCost">Historical Cost Page Object</param>
        /// <param name="s_ButtonID">Button ID</param>
        public void DisplayMessage(HistoricalCost historicalCost, string s_ButtonID)
        {
            try
            {
                historicalCost.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "block");
                historicalCost.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    switch (s_ButtonID)
                    {
                        case "btnSearch":
                            historicalCost.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCErrorSearch", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            break;

                        case "btnReset":
                            historicalCost.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "none");
                            break;

                        case "btnSNext":
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCostSearch", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            break;

                        case "btnSave":
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCostSearch", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            break;

                        case "ParameterPresent":
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCostFail", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            break;

                        case "btnRNFound":
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCNotFound", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Rebind gridview on postback/Rest values
        /// <summary>
        /// Method is used to rebind all the grids on postback
        /// </summary>
        /// <param name="historicalCost">Historical Cost page object</param>
        /// <param name="b_IsPageIndChange">bool variable to check page index changed</param>
        public void ReBindGridsOnPostBack(HistoricalCost historicalCost, bool b_IsPageIndChange)
        {
            try
            {
                Resetvalues(historicalCost);
                historicalCost.gv.DataSource = ac_HistoricalCost.dt_FilterDetails;
                historicalCost.gv.DataBind();

            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", userSessionInfo.ACC_CompanyName).Replace("*", userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
            }
        }

        /// <summary>
        /// Method is used to reset values
        /// </summary>
        /// <param name="historicalCost">Historical Cost page object</param>
        private void Resetvalues(HistoricalCost historicalCost)
        {
            historicalCost.n_index = 0;
            historicalCost.n_PID = historicalCost.n_ID = 0;
            historicalCost.n_EMPID = 0;
            historicalCost.n_HC_PID = historicalCost.n_OPGID = 0;

            historicalCost.HC_HashTable["n_ID"] = 0;
            historicalCost.HC_HashTable["n_Delete"] = 0;
            historicalCost.HC_HashTable["n_Action"] = 0;
            historicalCost.HC_HashTable["n_EmpID"] = 0;
            historicalCost.HC_HashTable["n_EmpName"] = 0;
            historicalCost.HC_HashTable["n_GRegID"] = 0;
            historicalCost.HC_HashTable["n_GrantDate"] = 0;
            historicalCost.HC_HashTable["n_GrantOptioID"] = 0;
            historicalCost.HC_HashTable["n_IVORFV"] = 0;
            historicalCost.HC_HashTable["n_Location"] = 0;
            historicalCost.HC_HashTable["n_Dept"] = 0;
            historicalCost.HC_HashTable["n_SBU"] = 0;
            historicalCost.HC_HashTable["n_CostCentre"] = 0;
            historicalCost.HC_HashTable["n_Entity"] = 0;
            historicalCost.HC_HashTable["n_Scheme"] = 0;
            historicalCost.HC_HashTable["n_OutstandingOpt"] = 0;
            historicalCost.HC_HashTable["n_VestDate"] = 0;
            historicalCost.HC_HashTable["n_OPDate"] = 0;
            historicalCost.HC_HashTable["n_Date"] = 0;
            historicalCost.HC_HashTable["n_CostBySystem"] = 0;
            historicalCost.HC_HashTable["n_HCostManulally"] = 0;
            historicalCost.HC_HashTable["n_Row"] = 0;
            historicalCost.HC_HashTable["n_AdjustmtEntry"] = 0;
            historicalCost.HC_HashTable["n_FinalCost"] = 0;
            historicalCost.HC_HashTable["n_EID"] = 0;
            historicalCost.HC_HashTable["n_VPID"] = 0;
            historicalCost.HC_HashTable["n_GOptions"] = 0;
            historicalCost.HC_HashTable["n_CancelOptions"] = 0;
            historicalCost.HC_HashTable["n_VestedCancelled"] = 0;
            historicalCost.HC_HashTable["n_UnvestedCancelled"] = 0;
            historicalCost.HC_HashTable["n_Lapsed"] = 0;
            historicalCost.HC_HashTable["n_ExeOptions"] = 0;
            historicalCost.HC_HashTable["n_UnvestedOptions"] = 0;
            historicalCost.HC_HashTable["n_VEOptions"] = 0;
            historicalCost.HC_HashTable["n_FRate"] = 0;
            historicalCost.HC_HashTable["n_OPT_GRANTED_ID"] = 0;
            historicalCost.HC_HashTable["n_OPID"] = 0;
            historicalCost.HC_HashTable["n_LocID"] = 0;
            historicalCost.HC_HashTable["n_COCID"] = 0;
            historicalCost.HC_HashTable["n_ENTID"] = 0;
            historicalCost.HC_HashTable["n_DepID"] = 0;
            historicalCost.HC_HashTable["n_SBUID"] = 0;
            historicalCost.HC_HashTable["n_ReversalDate"] = 0;
            historicalCost.HC_HashTable["n_ReversalCost"] = 0;
            historicalCost.HC_HashTable["n_ExerPrice"] = 0;

        }

        #endregion

        #region Save the details
        /// <summary>
        /// This method is used to save the details.
        /// </summary>
        /// <param name="historicalCost">HistoricalCost Page object</param>
        /// <param name="s_Action">Acxtion which want to performed</param>
        public void SaveDetails(HistoricalCost historicalCost, string s_Action)
        {
            try
            {
                string[] s_Result = new string[2];

                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    string s_OperationDate = ((string.IsNullOrEmpty(historicalCost.txtCostAsOn.Text) || historicalCost.txtCostAsOn.Text.Equals("dd/mmm/yyyy")) ? string.Empty : historicalCost.txtCostAsOn.Text);
                    string s_ReversalDate = ((string.IsNullOrEmpty(historicalCost.txtReversalDate.Text) || historicalCost.txtCostAsOn.Text.Equals("dd/mmm/yyyy")) ? string.Empty : historicalCost.txtReversalDate.Text);
                    string s_ReversalCost = ((string.IsNullOrEmpty(historicalCost.txtReversalCost.Text)) ? "0" : historicalCost.txtReversalCost.Text);
                    string s_OPTGID = (string.IsNullOrEmpty(historicalCost.hdnSelectedRecords.Value.TrimStart(',')) ? "0" : historicalCost.hdnSelectedRecords.Value.TrimStart(','));
                    string s_ValMethod = historicalCost.rdbVMCC01.Checked ? historicalCost.rdbVMCC01.ID : historicalCost.rdbVMCC02.ID;

                    if (!s_Action.Equals("D"))
                    {
                        DataColumnCollection columns = ac_HistoricalCost.dt_SelectedParmsFilter.Columns;
                        if (columns.Contains("ATMDID") || (columns.Contains("FINAL_COST")))
                        {
                            ac_HistoricalCost.dt_SelectedParmsFilter.Columns.Remove("ATMDID");
                            ac_HistoricalCost.dt_SelectedParmsFilter.Columns.Remove("FINAL_COST");
                        }
                        ac_HistoricalCost.dt_SelectedParmsFilter.Columns.Add("ATMDID", typeof(int));
                        ac_HistoricalCost.dt_SelectedParmsFilter.Columns.Add("FINAL_COST", typeof(string));

                        if (ac_HistoricalCost.dt_SelectedForParameter.Rows.Count > 0)
                        {
                            foreach (DataRow perRow in ac_HistoricalCost.dt_SelectedForParameter.Rows)
                            {
                                if (ac_HistoricalCost.dt_Edit_Maintaind_HCost.Rows.Count > 0 && ac_HistoricalCost.dt_Edit_Maintaind_HCost != null)
                                {
                                    foreach (DataRow perRow2 in ac_HistoricalCost.dt_Edit_Maintaind_HCost.Select("[Parameter Value] ='" + Convert.ToString(perRow["PARAM_VALUE"]) + "' AND EMPID = '" + Convert.ToString(perRow["EMPID"]) + "'"))
                                    {
                                        perRow["COST_AS_PER_SYSTEM"] = Convert.ToDecimal(perRow2["Cost as per System"]);
                                        perRow["UPDATECOST"] = (!DBNull.Value.Equals(perRow2["Updated Cost"])) ? Convert.ToDecimal(perRow2["Updated Cost"]) : 0;
                                        perRow["HC_PID"] = perRow2["HC_PID"];
                                    }
                                }
                                else
                                {
                                    var O_sells = ac_HistoricalCost.dt_Add_SParms_details.AsEnumerable()
                                        .GroupBy(row => row["Parameter Value"].ToString())
                                        .Select(a => new
                                        {
                                            Amount = a.Sum(b => string.IsNullOrEmpty(b["Updated Cost"].ToString()) ? 0 : Convert.ToDecimal(b["Updated Cost"])),
                                            CostAmt = a.Sum(b => string.IsNullOrEmpty(b["Cost as per System"].ToString()) ? 0 : Convert.ToDecimal(b["Cost as per System"])),
                                            Name = a.Key
                                        })
                                        .OrderByDescending(a => a.Amount)
                                        .ToList();

                                    foreach (var PItem in O_sells)
                                    {
                                        if (Convert.ToString(perRow["PARAM_VALUE"]).Equals(PItem.Name))
                                        {
                                            perRow["UPDATECOST"] = Convert.ToDecimal(PItem.Amount);
                                            perRow["COST_AS_PER_SYSTEM"] = Convert.ToDecimal(PItem.CostAmt);
                                        }
                                    }
                                }
                            }
                            ac_HistoricalCost.dt_SelectedParmameter = new DataView(ac_HistoricalCost.dt_SelectedForParameter.Copy()).ToTable(false, ac_HistoricalCost.selectedColumnsForHC);
                            ac_HistoricalCost.dt_SelectedParmameter.AcceptChanges();
                        }
                    }
                    s_Result = PerformCUDOperation(0, string.Empty, string.Empty, historicalCost.hdnEdit.Value.Replace(",", "").Equals("U") ? "U" : historicalCost.hdnDeletedRecords.Value.TrimEnd(',').Equals("D") ? "D" : "C", "btnSaveClick", s_OperationDate, s_ReversalDate, s_ReversalCost, s_OPTGID, s_ValMethod);
                    switch (s_Result[0])
                    {
                        case "1":
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCCreated", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            historicalCost.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            historicalCost.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            historicalCost.h3AddEdit.Style.Add("display", "none");
                            ac_HistoricalCost.dt_FilterDetails.Clear();
                            historicalCost.hdnSelectedRecords.Value = string.Empty;
                            ac_HistoricalCost.dt_SelectedForVestwise = new DataTable("dt_SelectedForVestwise");
                            ac_HistoricalCost.IsParameterCheck = string.Empty;
                            historicalCost.hdnSearch.Value = string.Empty;
                            historicalCost.hdnDeletedRecords.Value = string.Empty;
                            ClearValues(historicalCost);
                            ac_HistoricalCost.dt_Edit_Maintaind_HCost = new DataTable();
                            BindControls(historicalCost);
                            BindGridView(historicalCost);
                            ClearAll(historicalCost);
                            break;

                        case "2":
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCUpdated", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            historicalCost.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            historicalCost.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            historicalCost.h3AddEdit.Style.Add("display", "none");
                            ac_HistoricalCost.dt_FilterDetails.Clear();
                            ac_HistoricalCost.dt_HCEditDetails.Clear();
                            Resetvalues(historicalCost);
                            historicalCost.hdnSelectedRecords.Value = string.Empty;
                            historicalCost.hdnSearch.Value = string.Empty;
                            historicalCost.btnSave.Visible = false;
                            historicalCost.btnCancel.Visible = false;
                            ac_HistoricalCost.IsParameterCheck = string.Empty;
                            ac_HistoricalCost.dt_HCEditDetails = new DataTable();
                            ac_HistoricalCost.dt_Edit_Maintaind_HCost = new DataTable();
                            ac_HistoricalCost.dt_Add_VestWise_details = new DataTable();
                            ac_HistoricalCost.dt_SelectedForVestwise = new DataTable("dt_SelectedForVestwise");
                            historicalCost.hdnDeletedRecords.Value = string.Empty;
                            ClearValues(historicalCost);
                            BindControls(historicalCost);
                            BindGridView(historicalCost);
                            ClearAll(historicalCost);
                            break;

                        case "3":
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCDeleted", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            historicalCost.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            historicalCost.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            historicalCost.h3AddEdit.Style.Add("display", "none");
                            ac_HistoricalCost.dt_FilterDetails.Clear();
                            Resetvalues(historicalCost);
                            ClearValues(historicalCost);
                            BindControls(historicalCost);
                            BindGridView(historicalCost);
                            ClearAll(historicalCost);
                            break;

                        case "4":
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCULockedGrants", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            historicalCost.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            historicalCost.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case "5":
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCDLockedGrants", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            historicalCost.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            historicalCost.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case "6":
                            historicalCost.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblHCCanNotAddLockedGrants", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            historicalCost.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            historicalCost.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to clear the respective values
        /// </summary>
        /// <param name="historicalCost">Historical Cost page object</param>
        private void ClearValues(HistoricalCost historicalCost)
        {
            ac_HistoricalCost.dt_SelectedParmsFilter = new DataTable("SelectedDataTables");
            historicalCost.hdnTotal.Value = string.Empty;
            historicalCost.hdnAdjustValue.Value = string.Empty;
            historicalCost.hdnRCTotal.Value = string.Empty;
            historicalCost.hdnFinalCost.Value = string.Empty;
            ac_HistoricalCost.b_IsLocked = false;
            historicalCost.hdnDeleteLocked.Value = string.Empty;
            historicalCost.hdnisLocked.Value = string.Empty;
        }

        /// <summary>
        /// This method is used to perform CUD OPeration
        /// </summary>
        /// <param name="n_GID">int OPT_Granted_ID</param>
        /// <param name="s_OID">int Operation ID</param>
        /// <param name="a_HCCost">object HCCost</param>
        /// <param name="s_Action">string Action which wants to perform</param>
        /// <param name="s_MethodName">the method name from which the function called</param>
        /// <param name="s_OperationDate">string operation date</param>
        /// <param name="s_ReversalDate">string Reversal Date</param>
        /// <param name="s_ReversalCost">string Reversal Cost</param>
        /// <param name="s_OPTGID">List of OPT_Granted_ID</param>
        /// <param name="s_ValMethod">string Val Method</param>
        /// <returns></returns>
        internal string[] PerformCUDOperation(int n_GID, string s_OID, object a_HCCost, string s_Action, string s_MethodName, string s_OperationDate, string s_ReversalDate, string s_ReversalCost, string s_OPTGID, string s_ValMethod)
        {
            string[] s_Result = new string[2];
            DateTime? dt = null;
            DataTable dt_Grantdata = new DataTable("dt_Grantdata");
            dt_Grantdata = (DataTable)HttpContext.Current.Session["GrantData"];

            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                try
                {
                    accountingProperties = new AccountingProperties();
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_HistoricalCost;
                    accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                    accountingProperties.Action = s_Action;
                    accountingProperties.DT_HC_DATA = !s_Action.Equals("D") ? (ac_HistoricalCost.dt_SelectedDataTables.Rows.Count > 0) ? ac_HistoricalCost.dt_SelectedDataTables : CreateGrantEmptyTable() : CreateGrantEmptyTable();
                    if (accountingProperties.DT_HC_DATA.Select("[OPT_GRANTED_ID] is not null").Length.Equals(0) && (!s_Action.Equals("D")))
                    {
                        accountingProperties.DT_HC_DATA.Columns["ADJUSTMENT_ENTRY"].Expression = (HttpContext.Current.Session["ADJUSTMENT_ENTRY"] != null) ? HttpContext.Current.Session["ADJUSTMENT_ENTRY"].ToString() : "0";
                        accountingProperties.DT_HC_DATA.Columns["OPT_GRANTED_ID"].Expression = (ac_HistoricalCost.dt_HCEditDetails != null && ac_HistoricalCost.dt_HCEditDetails.Rows.Count > 0) ? ac_HistoricalCost.dt_HCEditDetails.Rows[0]["OPGID"].ToString() : "0";
                    }
                    accountingProperties.DT_HC_VWiseDATA = (userSessionInfo.ACC_CalculationMethod.Equals(2) && !s_Action.Equals("D")) ? (ac_HistoricalCost.dt_SelectedForVestwise != null && ac_HistoricalCost.dt_SelectedForVestwise.Rows.Count > 0) ? ac_HistoricalCost.dt_SelectedForVestwise : CreateEmptyTable() : CreateEmptyTable();
                    accountingProperties.SEN_CalculationMethod = userSessionInfo.ACC_CalculationMethod;
                    accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    accountingProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    accountingProperties.OPERATION_DATE = !string.IsNullOrEmpty(s_OperationDate) ? Convert.ToDateTime(s_OperationDate.ToString()) : dt;
                    accountingProperties.REVERSAL_DATE = !string.IsNullOrEmpty(s_ReversalDate) ? Convert.ToDateTime(s_ReversalDate.ToString()) : dt;
                    accountingProperties.REVERSAL_COST = !string.IsNullOrEmpty(s_ReversalCost) ? Convert.ToDecimal(s_ReversalCost) : 0;
                    accountingProperties.List_OPGID = !string.IsNullOrEmpty(s_OPTGID) ? s_OPTGID : string.Empty;
                    accountingProperties.IS_PARAMETER_CHECK = !string.IsNullOrEmpty(ac_HistoricalCost.IsParameterCheck) ? ac_HistoricalCost.IsParameterCheck : string.Empty;

                    accountingProperties.DT_HC_PARAMETER = (!string.IsNullOrEmpty(ac_HistoricalCost.IsParameterCheck) && ac_HistoricalCost.IsParameterCheck.Equals("1")) ? ac_HistoricalCost.dt_SelectedParmameter : CreateEmptyParameterTable();
                    accountingProperties.PARAMETER_NAME = !string.IsNullOrEmpty(ac_HistoricalCost.PARAMETER_NAME) ? ac_HistoricalCost.PARAMETER_NAME : string.Empty;
                    accountingProperties.VAL_METH_CAL_CC_LABEL_ID = !string.IsNullOrEmpty(s_ValMethod) ? s_ValMethod : string.Empty;
                    if ((!CommonModel.CheckAgainstLockedAccountingReport((!string.IsNullOrEmpty(s_OperationDate)) ? Convert.ToString(s_OperationDate) : string.Empty, userSessionInfo)))
                    {
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                        s_Result[0] = accountingCRUDProperties.a_result.ToString();
                    }
                    else
                    {
                        //set accountingProperties.a_result = 6  if accounting report is locked for AppDate
                        s_Result[0] = "6";
                        accountingCRUDProperties.a_result = 6;
                    }
                    switch (accountingCRUDProperties.a_result)
                    {
                        case 1:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblHCVestCreated", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            break;

                        case 2:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblHCUpdated", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            break;

                        case 4:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblHCULockedGrants", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            break;

                        case 5:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblHCUnlockLockedGrants", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            break;

                        case 6:
                            s_Result[1] = accountingServiceClient.GetAccounting_L10N("lblHCCanNotAddLockedGrants", CommonConstantModel.s_HistoricalCost, CommonConstantModel.s_AccountingL10);
                            break;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return s_Result;
            }
        }

        #region Create Empty Table

        /// <summary>
        ///  This method is used to add new blank row in datatble for grant wise
        /// </summary>
        /// <returns>return the datatble</returns>
        private DataTable CreateGrantEmptyTable()
        {
            DataTable dataTable = new DataTable("DT");
            CreateGrantDatatable(dataTable);
            DataRow row = dataTable.NewRow();
            dataTable.Rows.Add(row);
            return dataTable;
        }

        /// <summary>
        /// This method is used to add new blank row in datatble for vestwise
        /// </summary>
        /// <returns></returns>
        private DataTable CreateEmptyTable()
        {
            DataTable dataTable = new DataTable("dt_SelectedForVestwise");
            CreateDatatable(dataTable);
            DataRow row = dataTable.NewRow();
            dataTable.Rows.Add(row);
            return dataTable;
        }

        /// <summary>
        /// This method is used to add new blank row in datatble for vestwise
        /// </summary>
        /// <returns></returns>
        private DataTable CreateEmptyParameterTable()
        {
            DataTable dataTable = new DataTable("dt_SelectedForParameter");
            dataTable.Columns.Add("COST_AS_PER_SYSTEM", typeof(Decimal));
            dataTable.Columns.Add("EMPID", typeof(int));
            dataTable.Columns.Add("H_COST_MANUALLY", typeof(Decimal));
            dataTable.Columns.Add("ADJUSTMENT_ENTRY", typeof(Decimal));
            dataTable.Columns.Add("ATMDID", typeof(int));
            dataTable.Columns.Add("FINAL_COST", typeof(Decimal));
            dataTable.Columns.Add("HC_PID", typeof(int));
            DataRow row = dataTable.NewRow();
            dataTable.Rows.Add(row);
            return dataTable;
        }
        #endregion

        /// <summary>
        /// This method is used to save the detils in  datatble for Vest wise wise
        /// </summary>
        /// <param name="n_GID">GID Object</param>
        /// <param name="a_HCCost">HC Cost Object</param>
        /// <param name="s_OID">OID Object</param>
        /// <param name="a_CCost">CC Cost Object</param>
        /// <param name="a_CCostFV">CC FV Cost Object</param>
        /// <param name="IsDataFound">IsDataFound Object</param>
        /// <param name="a_TotalCost">Total Cost Object</param>
        /// <param name="a_VestingDate">Vesting Date Object</param>
        /// <returns></returns>
        public DataTable CreateTable(int n_GID, object a_HCCost, string s_OID, object a_CCost, object a_CCostFV, ref bool IsDataFound, object a_TotalCost, object a_VestingDate)
        {
            string[] s_HCCosts = Array.ConvertAll(Convert.ToString(a_HCCost).Split(','), Convert.ToString);
            string[] s_CCosts = Array.ConvertAll(Convert.ToString(a_CCost).Split(','), Convert.ToString);
            string[] s_CCostFV = Array.ConvertAll(Convert.ToString(a_CCostFV).Split(','), Convert.ToString);
            string[] s_TCosts = Array.ConvertAll(Convert.ToString(a_TotalCost).Split(','), Convert.ToString);
            string[] s_VDates = Array.ConvertAll(Convert.ToString(a_VestingDate).Split(','), Convert.ToString);

            if (Array.TrueForAll(s_HCCosts, string.IsNullOrEmpty))
            {
                IsDataFound = false;
                return new DataTable();
            }
            DataRow dr_GrantedOptionsVestwise;
            if (ac_HistoricalCost.dt_SelectedForVestwise.Columns.Count < 2)
            {
                DataTable dataTable = new DataTable("dt_SelectedForVestwise");
                CreateDatatable(ac_HistoricalCost.dt_SelectedForVestwise);
            }

            int n_count = 1, cnt = 0, cntCCost = 0, cntCCostFV = 0, cntTCost = 0, cntDate = 0;
            decimal n_Sum = 0;
            foreach (DataRow perItem in ac_HistoricalCost.dt_SelectedForVestwise.Select("OPT_GRANTED_ID ='" + n_GID + "'"))
            {
                perItem["OPT_GRANTED_ID"] = n_GID;
                perItem["H_COST_MANUALLY"] = string.IsNullOrEmpty(s_HCCosts[cnt]) ? 0 : Convert.ToDecimal(s_HCCosts[cnt]);
                perItem["VPD_VESTING_PERIOD_ID"] = n_count;
                perItem["COST_AS_PER_SYSTEM_BY_IV"] = string.IsNullOrEmpty(s_CCosts[cnt]) ? 0 : Convert.ToDecimal(s_CCosts[cnt]);
                perItem["COST_AS_PER_SYSTEM_BY_FV"] = string.IsNullOrEmpty(s_CCostFV[cnt]) ? 0 : Convert.ToDecimal(s_CCostFV[cnt]);
                perItem["COST_AS_PER_SYSTEM"] = string.IsNullOrEmpty(s_TCosts[cnt]) ? 0 : Convert.ToDecimal(s_TCosts[cnt]);
                perItem["VPD_VESTING_DATE"] = string.IsNullOrEmpty(s_VDates[cnt]) ? string.Empty : s_VDates[cnt];
                n_Sum = n_Sum + (string.IsNullOrEmpty(s_HCCosts[cnt]) ? 0 : Convert.ToDecimal(s_HCCosts[cnt]));
                n_count++;
                cnt++;
            }
            foreach (var perItem in s_HCCosts)
            {
                if (cnt.Equals(0))
                {
                    dr_GrantedOptionsVestwise = ac_HistoricalCost.dt_SelectedForVestwise.NewRow();
                    dr_GrantedOptionsVestwise["OPT_GRANTED_ID"] = n_GID;
                    dr_GrantedOptionsVestwise["H_COST_MANUALLY"] = string.IsNullOrEmpty(perItem) ? 0 : Convert.ToDecimal(perItem);
                    dr_GrantedOptionsVestwise["VPD_VESTING_PERIOD_ID"] = n_count;
                    dr_GrantedOptionsVestwise["COST_AS_PER_SYSTEM_BY_IV"] = string.IsNullOrEmpty(s_CCosts[cntCCost]) ? 0 : Convert.ToDecimal(s_CCosts[cntCCost]);
                    dr_GrantedOptionsVestwise["COST_AS_PER_SYSTEM_BY_FV"] = string.IsNullOrEmpty(s_CCostFV[cntCCostFV]) ? 0 : Convert.ToDecimal(s_CCostFV[cntCCostFV]);
                    dr_GrantedOptionsVestwise["COST_AS_PER_SYSTEM"] = string.IsNullOrEmpty(s_TCosts[cntTCost]) ? 0 : Convert.ToDecimal(s_TCosts[cntTCost]);
                    dr_GrantedOptionsVestwise["VPD_VESTING_DATE"] = string.IsNullOrEmpty(s_VDates[cntDate]) ? string.Empty : (s_VDates[cntDate]);
                    n_count++;
                    n_Sum = n_Sum + (string.IsNullOrEmpty(perItem) ? 0 : Convert.ToDecimal(perItem));
                    ac_HistoricalCost.dt_SelectedForVestwise.Rows.Add(dr_GrantedOptionsVestwise);
                }
                cntCCost++;
                cntCCostFV++;
                cntTCost++;
                cntDate++;
            }
            cnt = 0;
            foreach (DataRow perItem in ac_HistoricalCost.dt_SelectedDataTables.Select("OPT_GRANTED_ID ='" + n_GID + "'"))
            {
                perItem["UPDATECOST"] = n_Sum;
                perItem["OPT_GRANTED_ID"] = n_GID;
                perItem["OPERATION_ID"] = s_OID;
                cnt++;
            }
            if (cnt.Equals(0))
            {
                dr_GrantedOptionsVestwise = ac_HistoricalCost.dt_SelectedDataTables.NewRow();
                dr_GrantedOptionsVestwise["UPDATECOST"] = n_Sum;
                dr_GrantedOptionsVestwise["OPT_GRANTED_ID"] = n_GID;
                dr_GrantedOptionsVestwise["OPERATION_ID"] = s_OID;
                ac_HistoricalCost.dt_SelectedDataTables.Rows.Add(dr_GrantedOptionsVestwise);
            }

            return ac_HistoricalCost.dt_SelectedForVestwise;
        }

        /// <summary>
        /// This method is used to add bcolumns in datatble
        /// </summary>
        /// <param name="dataTable"> datatable object</param>
        private void CreateDatatable(DataTable dataTable)
        {
            dataTable.Columns.Add("OPT_GRANTED_ID", typeof(string));
            dataTable.Columns.Add("AGRMID", typeof(Int32));
            dataTable.Columns.Add("GRANT_OPTION_ID", typeof(string));
            dataTable.Columns.Add("EMPID", typeof(Int32));
            dataTable.Columns.Add("VPD_VESTING_PERIOD_ID", typeof(Int32));
            dataTable.Columns.Add("VPD_VESTING_DATE", typeof(DateTime));
            dataTable.Columns.Add("GRANTED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("CANCELLED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("VESTED_CANCELLED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("UNVESTED_CANCELLED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("CANCELLATION_DATE", typeof(DateTime));
            dataTable.Columns.Add("LAPSED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("LAPSED_DATE", typeof(DateTime));
            dataTable.Columns.Add("EXERCISED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("EXERCISED_DATE", typeof(DateTime));
            dataTable.Columns.Add("UNVESTED_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("VESTED_AND_EXERCISABLE", typeof(Int32));
            dataTable.Columns.Add("OUTSTANDING_OPTIONS", typeof(Int32));
            dataTable.Columns.Add("FORFEITURE_RATE", typeof(string));
            dataTable.Columns.Add("COST_AS_PER_SYSTEM", typeof(Decimal));
            dataTable.Columns.Add("H_COST_MANUALLY", typeof(Decimal));
            dataTable.Columns.Add("OPERATION_ID", typeof(Int32));
            dataTable.Columns.Add("OPERATION_DATE", typeof(DateTime));
            dataTable.Columns.Add("COST_AS_PER_SYSTEM_BY_FV", typeof(Decimal));
            dataTable.Columns.Add("COST_AS_PER_SYSTEM_BY_IV", typeof(Decimal));
        }

        #endregion

        #region Methods
        /// <summary>
        /// method is used to bind Vest wise data or add vest details
        /// </summary>
        /// <param name="s_GID">The id for which vest details should be display</param>
        /// <param name="s_BtnId">Button ID Object</param>
        /// <param name="IsEditVest">IsEditVest Object</param>
        /// <returns>returns the datatable</returns>
        public DataTable BindVestDetailsByID(string s_GID, string s_BtnId, string IsEditVest)
        {
            try
            {
                if (!(string.IsNullOrEmpty(s_GID)))
                {
                    using (DataTable dt_selectedVestDetails = (ac_HistoricalCost.dt_SP_HC_details != null && ac_HistoricalCost.dt_SP_HC_details.Rows.Count > 0 && s_BtnId.Equals("View") && ac_HistoricalCost.dt_SP_HC_details.Select("GID = '" + s_GID + "'").Count() > 0 ? ac_HistoricalCost.dt_SP_HC_details.Select("GID = '" + s_GID + "'").CopyToDataTable() :
                    (ac_HistoricalCost.dt_Add_VestWise_details != null && ac_HistoricalCost.dt_Add_VestWise_details.Rows.Count > 0 && s_BtnId.Equals("Add") && ac_HistoricalCost.dt_Add_VestWise_details.Select("GID = '" + s_GID + "'").Count() > 0) ? ac_HistoricalCost.dt_Add_VestWise_details.Select("GID = '" + s_GID + "'").CopyToDataTable() :
                    (ac_HistoricalCost.dt_SP_HC_details != null && ac_HistoricalCost.dt_SP_HC_details.Rows.Count > 0 && IsEditVest.Equals("U") && ac_HistoricalCost.dt_SP_HC_details.Select("GID = '" + s_GID + "'").Count() > 0) ? ac_HistoricalCost.dt_SP_HC_details.Select("GID = '" + s_GID + "'").CopyToDataTable() : new DataTable()))
                    {
                        if (ac_HistoricalCost.dt_SelectedForVestwise != null && ac_HistoricalCost.dt_SelectedForVestwise.Rows.Count > 0 && ac_HistoricalCost.dt_SelectedForVestwise.Select("OPT_GRANTED_ID = '" + s_GID + "'").Count() > 0)
                        {
                            using (DataTable dtVestPresent = new DataView(ac_HistoricalCost.dt_SelectedForVestwise.Copy()).ToTable(false, ac_HistoricalCost.selectedColumnsForVest))
                            {
                                dtVestPresent.Columns["OPT_GRANTED_ID"].ColumnName = "GID";
                                dtVestPresent.Columns["VPD_VESTING_PERIOD_ID"].ColumnName = "VestID";
                                dtVestPresent.Columns["VPD_VESTING_DATE"].ColumnName = "Vesting Date";
                                dtVestPresent.Columns["COST_AS_PER_SYSTEM"].ColumnName = "CostBySystem";
                                dtVestPresent.Columns["H_COST_MANUALLY"].ColumnName = "UpdatedCost";
                                dtVestPresent.Columns["COST_AS_PER_SYSTEM_BY_FV"].ColumnName = "CostByFV";
                                dtVestPresent.Columns["COST_AS_PER_SYSTEM_BY_IV"].ColumnName = "CostByIV";
                                dtVestPresent.AcceptChanges();
                                DataTable dt_selectedVest = dtVestPresent.Select("GID = '" + s_GID + "'").CopyToDataTable();
                                return dt_selectedVest;
                            }
                        }
                        return dt_selectedVestDetails;
                    }
                }
                else
                    return null;
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        ///  method is used to bind the History data for HC Cost
        /// </summary>
        /// <param name="s_OPTGID">OPTGID Against which data should be display</param>
        /// <returns>returns the list</returns>
        internal AccountingProperties[] BindHistoryGridByID(object s_OPTGID)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    List<AccountingProperties> lstaccountingProperties = new List<AccountingProperties>();
                    accountingProperties = new AccountingProperties();
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_HistoricalCost;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.OPGID = Convert.ToInt32(s_OPTGID);
                    accountingProperties.PopulateControls = "HISTORYDATA";
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    foreach (DataRow dtrow in accountingCRUDProperties.dt_Result.Rows)
                    {
                        accountingProperties = new AccountingProperties();
                        accountingProperties.Employee_Id = Convert.ToString(dtrow["Employee ID"]);
                        accountingProperties.Employee_Name = Convert.ToString(dtrow["Employee Name"]);
                        accountingProperties.GrantRegistrationID = Convert.ToString(dtrow["Grant Registration ID"]);
                        accountingProperties.GrDate = !string.IsNullOrEmpty(Convert.ToString(dtrow["Grant Date"])) ? Convert.ToDateTime(dtrow["Grant Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                        accountingProperties.GrantOptionID = Convert.ToString(dtrow["Grant Option ID"]);
                        accountingProperties.OutstandingOptions = Convert.ToString(dtrow["OutstandingOptions"]);
                        if (!string.IsNullOrEmpty(dtrow["IV/FV"].ToString()) && !dtrow["IV/FV"].ToString().Equals("&nbsp;"))
                            accountingProperties.IVORFV = Convert.ToString(dtrow["IV/FV"].ToString());
                        else
                            accountingProperties.IVORFV = "NA";
                        accountingProperties.HLocation = Convert.ToString(dtrow["Location"]);
                        accountingProperties.HDepartment = Convert.ToString(dtrow["Department"]);
                        accountingProperties.HSBU = Convert.ToString(dtrow["SBU"]);
                        accountingProperties.HEntity = Convert.ToString(dtrow["Entity"]);
                        accountingProperties.HCostCentre = Convert.ToString(dtrow["Cost Centre"]);
                        if (!DBNull.Value.Equals(dtrow["Cost as per System"]))
                            accountingProperties.CostAsSystem = Convert.ToString(dtrow["Cost as per System"]);
                        else
                            accountingProperties.CostAsSystem = "0";
                        if (!DBNull.Value.Equals(dtrow["Update Cost"]))
                            accountingProperties.UpdateCost = Convert.ToString(dtrow["Update Cost"]);
                        else
                            accountingProperties.UpdateCost = "0";
                        accountingProperties.CostDate = !string.IsNullOrEmpty(Convert.ToString(dtrow["Update Cost Date"])) ? Convert.ToDateTime(dtrow["Update Cost Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                        accountingProperties.s_HCAID = Convert.ToString(dtrow["HCAID"]);
                        accountingProperties.s_AdjustmentEntry = Convert.ToString(dtrow["ADJUSTMENT_ENTRY"]);
                        lstaccountingProperties.Add(accountingProperties);
                    }
                    return lstaccountingProperties.ToArray();
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion

        #region Bind vest details grid
        /// <summary>
        ///  Method is used to bind the vest details gird.
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="historicalCost">Historical Cost page object</param>
        /// <param name="e">e</param>
        /// <param name="n_index">index number</param>
        /// <param name="n_OPT_GRANTED_ID">OPT_GRANTED_ID object</param>
        /// <param name="n_VPID">VPID object</param>
        /// <param name="n_VestDate">VestDate object</param>
        /// <param name="n_CostBySystem">Cost By System object</param>
        /// <param name="n_HCostManulally">HCost Manulally object</param>
        internal void BindgvVestDetailRows(object sender, HistoricalCost historicalCost, GridViewRowEventArgs e, ref int n_index, ref int n_OPT_GRANTED_ID, ref int n_VPID, ref int n_VestDate, ref int n_CostBySystem, ref int n_HCostManulally)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "GID":
                                    n_OPT_GRANTED_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "VestID":
                                    n_VPID = n_index;
                                    break;

                                case "Vesting Date":
                                    n_VestDate = n_index;
                                    break;

                                case "COST AS PER SYSTEM":
                                    n_CostBySystem = n_index;
                                    break;

                                case "UPDATED COST":
                                    n_HCostManulally = n_index;
                                    break;

                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_OPT_GRANTED_ID].Visible = false;
                        e.Row.Cells[n_HCostManulally].Controls.Add(AddControl(historicalCost, "TextBox", "", "", "", "txtVestwise", "", "", "", "", "", "", "", "", "", "", "", "", ""));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Edit Details
        /// <summary>
        /// Method is used to edit the details
        /// </summary>
        /// <param name="historicalCost">Historical Cost Page object</param>
        /// <param name="s_OPerationID">OPerationID object</param>
        /// <param name="s_OPID">OPID object</param>
        /// <param name="s_Action">Action object</param>
        internal void ShowEditDetails(HistoricalCost historicalCost, string s_OPerationID, string s_OPID, string s_Action)
        {
            try
            {
                if (ac_HistoricalCost.dt_temp_HC_details != null && ac_HistoricalCost.dt_temp_HC_details.Rows.Count > 0)
                {
                    historicalCost.hdnBackonCancel.Value = string.Empty;
                    historicalCost.hdnBackonCancel.Value = string.Empty;
                    ac_HistoricalCost.dt_HCEditDetails = ac_HistoricalCost.dt_temp_HC_details;
                    if (!string.IsNullOrEmpty(s_OPID))
                    {
                        ac_HistoricalCost.dt_HCEditDetails = (ac_HistoricalCost.dt_temp_HC_details.AsEnumerable()
                             .Where(b => b.Field<int>("OPGID") == Convert.ToInt32(s_OPID))).CopyToDataTable();
                        ac_HistoricalCost.OPT_Granted_ID = s_OPID;
                        historicalCost.txtReversalDate.Text = !string.IsNullOrEmpty(Convert.ToString(ac_HistoricalCost.dt_HCEditDetails.Rows[0]["Reversal Date"])) ? Convert.ToDateTime(ac_HistoricalCost.dt_HCEditDetails.Rows[0]["Reversal Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                        historicalCost.txtReversalCost.Text = !string.IsNullOrEmpty(Convert.ToString(ac_HistoricalCost.dt_HCEditDetails.Rows[0]["Reversal Cost"])) ? Convert.ToString(ac_HistoricalCost.dt_HCEditDetails.Rows[0]["Reversal Cost"]) : "0";
                        historicalCost.txtCostAsOn.Text = !string.IsNullOrEmpty(Convert.ToString(ac_HistoricalCost.dt_HCEditDetails.Rows[0]["OPDate"])) ? Convert.ToDateTime(ac_HistoricalCost.dt_HCEditDetails.Rows[0]["OPDate"]).ToString("dd/MMM/yyyy") : string.Empty;
                        accountingProperties.VAL_METH_CAL_CC_LABEL_ID = !string.IsNullOrEmpty(Convert.ToString(ac_HistoricalCost.dt_HCEditDetails.Rows[0]["IV/FV"])) ? ac_HistoricalCost.dt_HCEditDetails.Rows[0]["IV/FV"].Equals("IV") ? "RDBVMCC01" : "RDBVMCC02" : string.Empty;
                    }
                    historicalCost.hdnEdit.Value = "U";
                    ac_HistoricalCost.dt_HCEditDetails.TableName = "HCEditDetails";
                    ac_HistoricalCost.Rowcount = ac_HistoricalCost.dt_HCEditDetails.Rows.Count;
                    historicalCost.h3AddEdit.Style.Add("display", "block");
                    Resetvalues(historicalCost);
                    historicalCost.gv.Visible = true;
                    historicalCost.gv.DataSource = ac_HistoricalCost.dt_HCEditDetails;
                    historicalCost.gv.DataBind();
                    GetMaintainedHCDetails(s_OPID, historicalCost, "U");
                    historicalCost.btnSNext.Enabled = false;
                    if (userSessionInfo.ACC_CalculationMethod.Equals(2))
                    {
                        historicalCost.hdnEditVest.Value = "U";
                    }

                    if (ac_HistoricalCost.IsParameterCheck.Equals("1"))
                    {
                        historicalCost.ddlAParms.Visible = true;
                        historicalCost.btnSNext.Visible = true;
                        historicalCost.ddlAParms.Enabled = false;
                    }
                    historicalCost.MultiSelectEmpID.txtMultiselect.Enabled = false;
                    historicalCost.MultiSelectEmpName.txtMultiselect.Enabled = false;
                    historicalCost.MultiSelectGrantRegID.txtMultiselect.Enabled = false;
                    historicalCost.MultiSelectGrantOptionID.txtMultiselect.Enabled = false;
                    historicalCost.MultiSelectSchemeName.txtMultiselect.Enabled = false;
                    historicalCost.btnSNext.Text = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID='btnSNext'"))[0]["LabelName"]);
                    historicalCost.btnSNext.ToolTip = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID='btnSNext'"))[0]["LabelToolTip"]);
                    historicalCost.txtCostAsOn.Enabled = false;
                    historicalCost.btnNext.Enabled = false;
                    historicalCost.chkAPams.Enabled = true;
                    historicalCost.btnSave.Visible = true;
                    historicalCost.btnCancel.Visible = true;
                    historicalCost.hdnSelectedRecords.Value = string.Empty;


                    BindDropDowns(historicalCost);
                    historicalCost.chkAPams.Enabled = false;
                    if (ac_HistoricalCost.dt_HCEditDetails.Rows[0]["IV/FV"].Equals("rdbVMCC01"))
                    {
                        historicalCost.rdbVMCC01.Checked = true;
                        historicalCost.rdbVMCC01.Enabled = false;
                        historicalCost.rdbVMCC02.Enabled = false;
                    }
                    else
                    {
                        historicalCost.rdbVMCC02.Checked = true;
                        historicalCost.rdbVMCC02.Enabled = false;
                        historicalCost.rdbVMCC01.Enabled = false;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// used to get Maintained HC Details
        /// </summary>
        /// <param name="s_OPID">OPID Object</param>
        /// <param name="historicalCost">historicalCost page object</param>
        /// <param name="s_Action">Action object</param>
        internal void GetMaintainedHCDetails(string s_OPID, HistoricalCost historicalCost, string s_Action)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_HistoricalCost;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "MAINTAINED_HCOST";
                    accountingProperties.OPGID = Convert.ToInt32(s_OPID);
                    accountingProperties.Action = s_Action;

                    using (DataSet dsMaintaind_HCost = (accountingServiceClient.CRUDAccountingOperations(accountingProperties).ds_Result))
                    {
                        if ((dsMaintaind_HCost.Tables[1] != null && dsMaintaind_HCost.Tables[1].Rows.Count > 0) && (dsMaintaind_HCost.Tables[0] != null && dsMaintaind_HCost.Tables[0].Rows.Count > 0))
                        {
                            ac_HistoricalCost.dt_Edit_Maintaind_HCost = dsMaintaind_HCost.Tables[0];
                            Resetvalues(historicalCost);
                            historicalCost.gvAParmsHCost.DataSource = ac_HistoricalCost.dt_Edit_Maintaind_HCost;
                            historicalCost.gvAParmsHCost.DataBind();
                            historicalCost.gvAParmsHCost.Visible = true;
                            historicalCost.ddlAParms.SelectedIndex = historicalCost.ddlAParms.Items.IndexOf(historicalCost.ddlAParms.Items.FindByText(Convert.ToString(dsMaintaind_HCost.Tables[1].Rows[0]["Parameter Value"])));
                            ac_HistoricalCost.PARAMETER_NAME = Convert.ToString(dsMaintaind_HCost.Tables[1].Rows[0]["Parameter Value"]);
                            ac_HistoricalCost.IsParameterCheck = "1";
                            historicalCost.chkAPams.Checked = true;
                            historicalCost.ddlAParms.Enabled = false;
                            historicalCost.divASPToCalacHCost.Style.Add("display", "block");
                            historicalCost.lblMsg.Visible = true;
                            historicalCost.ddlAParms.Visible = true;
                            historicalCost.btnSNext.Visible = true;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Bind the controls in case of add New HC Cost
        /// <summary>
        /// This method is used to bind the controls in case of adding new Historical Cost
        /// </summary>
        /// <param name="historicalCost">Historical Cost Page object</param>
        /// <param name="s_txtCostAsOn">Cost as on date value against the control will bind</param>
        /// <param name="s_BtnName">BtnName object</param>
        internal void BindAddControls(HistoricalCost historicalCost, string s_txtCostAsOn, string s_BtnName)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.PageName = CommonConstantModel.s_HistoricalCost;
                    accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                    accountingProperties.PopulateControls = "HC_DETAILS";
                    accountingProperties.OPERATION_DATE = (!string.IsNullOrEmpty(historicalCost.txtCostAsOn.Text) || historicalCost.txtCostAsOn.Text.Equals("dd/mmm/yyyy")) ? Convert.ToDateTime(historicalCost.txtCostAsOn.Text.ToString()) : dt;
                    accountingProperties.SEN_CalculationMethod = userSessionInfo.ACC_CalculationMethod;
                    accountingProperties.VAL_METH_CAL_CC_LABEL_ID = historicalCost.rdbVMCC01.Checked.Equals(true) ? historicalCost.rdbVMCC01.ID : historicalCost.rdbVMCC02.ID;
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                    ac_HistoricalCost.ds_HCDetails = accountingCRUDProperties.ds_Result;

                    if (ac_HistoricalCost.ds_HCDetails != null && ac_HistoricalCost.ds_HCDetails.Tables.Count > 0)
                    {
                        ac_HistoricalCost.dt_Add_HC_details = ac_HistoricalCost.ds_HCDetails.Tables[0].Copy();
                        ac_HistoricalCost.dt_Add_VestWise_details = userSessionInfo.ACC_CalculationMethod.Equals(2) ? ac_HistoricalCost.ds_HCDetails.Tables[1].Copy() : new DataTable();
                        if (!s_BtnName.Equals("btnNext"))
                        {
                            //Bind Emp ID in Add functionality
                            historicalCost.MultiSelectEmpID.chkMultiselect.DataSource = (from b in ac_HistoricalCost.dt_Add_HC_details.AsEnumerable()
                                                                                         where b.Field<string>("Employee ID") != null
                                                                                         select b.Field<string>("Employee ID")).Distinct();
                            historicalCost.MultiSelectEmpID.DataBind();
                            //Bind Add Emp Name drop-down 
                            historicalCost.MultiSelectEmpName.chkMultiselect.DataSource = (from b in ac_HistoricalCost.dt_Add_HC_details.AsEnumerable()
                                                                                           where b.Field<string>("Employee Name") != null
                                                                                           select b.Field<string>("Employee Name")).Distinct(); ;
                            historicalCost.MultiSelectEmpName.DataBind();

                            //Bind Add GRANT OPTION ID drop-down 
                            historicalCost.MultiSelectGrantOptionID.chkMultiselect.DataSource = (from b in ac_HistoricalCost.dt_Add_HC_details.AsEnumerable()
                                                                                                 where b.Field<string>("GRANT OPTION ID") != null
                                                                                                 select b.Field<string>("GRANT OPTION ID")).Distinct(); ;
                            historicalCost.MultiSelectGrantOptionID.DataBind();

                            //Bind Add GRANT REGISTRATION ID drop-down 
                            historicalCost.MultiSelectGrantRegID.chkMultiselect.DataSource = (from b in ac_HistoricalCost.dt_Add_HC_details.AsEnumerable()
                                                                                              where b.Field<string>("GRANT REGISTRATION ID") != null
                                                                                              select b.Field<string>("GRANT REGISTRATION ID")).Distinct();
                            historicalCost.MultiSelectGrantRegID.DataBind();

                            //Bind Add Scheme Name drop-down 
                            historicalCost.MultiSelectSchemeName.chkMultiselect.DataSource = (from b in ac_HistoricalCost.dt_Add_HC_details.AsEnumerable()
                                                                                              where b.Field<string>("Scheme Title") != null
                                                                                              select b.Field<string>("Scheme Title")).Distinct();
                            historicalCost.MultiSelectSchemeName.DataBind();
                        }
                        historicalCost.h3AddEdit.Style.Add("display", "block");
                    }
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// This method is used to visible the control on check changed
        /// </summary>
        internal void VisibleTheControl(HistoricalCost historicalCost)
        {
            if (historicalCost.chkAPams.Checked)
            {
                historicalCost.btnSNext.Text = Convert.ToString((ac_HistoricalCost.dt_HistoricalCostUI.Select("LabelID='btnSNext'"))[0]["LabelName"]);

                historicalCost.divASPToCalacHCost.Style.Add("display", "block");
                ac_HistoricalCost.IsParameterCheck = "1";
            }
            else
            {
                historicalCost.divASPToCalacHCost.Style.Add("display", "none");
            }
        }

        #endregion

        #region Page index changing method
        /// <summary>
        /// gridview page index change event method
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="historicalCost">historicalCost page object</param>
        /// <param name="s_ControlName">Control Name object</param>
        public void PageIndexChangingvHCost(int NewPageIndex, HistoricalCost historicalCost, string s_ControlName)
        {
            try
            {
                switch (s_ControlName)
                {
                    case "gvHistoricalCost":
                        historicalCost.gvHistoricalCost.PageIndex = NewPageIndex;
                        BindGridView(historicalCost);
                        break;

                    case "gv":
                        historicalCost.gv.PageIndex = NewPageIndex;
                        ReBindGridsOnPostBack(historicalCost, true);
                        break;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// This method is used to Encrypt query string that has to pass on to report page  for report view.
        /// </summary>
        /// <param name="historicalCost">object of historical Cost page</param>
        internal void EncryptData(HistoricalCost historicalCost)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                historicalCost.hdnQueryStringParams.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=11").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                historicalCost.hdnQueryStringParams.Dispose();
            }
        }

        /// <summary>
        /// To reset the control
        /// </summary>
        /// <param name="historicalCost">Historical Cost Page object</param>
        internal void ResetControl(HistoricalCost historicalCost)
        {
            BindGridView(historicalCost);
            historicalCost.btnCancel.Visible = false;
            historicalCost.btnSave.Visible = false;
            ClearFilters(historicalCost.MultiSelectSEmpID.chkMultiselect, historicalCost.MultiSelectSEmpID.txtMultiselect, "btnReset");
            ClearFilters(historicalCost.MultiSelectSEmpName.chkMultiselect, historicalCost.MultiSelectSEmpName.txtMultiselect, "btnReset");
            ClearFilters(historicalCost.MultiSelectSGrantOptionID.chkMultiselect, historicalCost.MultiSelectSGrantOptionID.txtMultiselect, "btnReset");
            ClearFilters(historicalCost.MultiSelectSSchemeName.chkMultiselect, historicalCost.MultiSelectSSchemeName.txtMultiselect, "btnReset");
            ClearFilters(historicalCost.MultiSelectSGrantRegID.chkMultiselect, historicalCost.MultiSelectSGrantRegID.txtMultiselect, "btnReset");
        }

        /// <summary>
        /// Clear the Controls value
        /// </summary>
        /// <param name="historicalCost">historicalCost page object</param>
        internal void ClearAll(HistoricalCost historicalCost)
        {
            historicalCost.hdnBackonCancel.Value = "C";
            historicalCost.hdnSetDefaultControls.Value = string.Empty;
            ClearFilters(historicalCost.MultiSelectEmpID.chkMultiselect, historicalCost.MultiSelectEmpID.txtMultiselect, "Cancel");
            ClearFilters(historicalCost.MultiSelectEmpName.chkMultiselect, historicalCost.MultiSelectEmpName.txtMultiselect, "Cancel");
            ClearFilters(historicalCost.MultiSelectGrantOptionID.chkMultiselect, historicalCost.MultiSelectGrantOptionID.txtMultiselect, "Cancel");
            ClearFilters(historicalCost.MultiSelectSchemeName.chkMultiselect, historicalCost.MultiSelectSchemeName.txtMultiselect, "Cancel");
            ClearFilters(historicalCost.MultiSelectGrantRegID.chkMultiselect, historicalCost.MultiSelectGrantRegID.txtMultiselect, "Cancel");
            ac_HistoricalCost.dt_FilterDetails.Clear();
            historicalCost.gv.Visible = false;
            historicalCost.txtCostAsOn.Text = "dd/mmm/yyyy";
            historicalCost.txtCostAsOn.Enabled = true;
            historicalCost.h3AddEdit.Style.Add("display", "none");
            EnableControls(historicalCost);
            historicalCost.hdnSearch.Value = string.Empty;
            historicalCost.hdnEdit.Value = string.Empty;
            ac_HistoricalCost.IsParameterCheck = "0";
            ac_HistoricalCost.dt_HCEditDetails = new DataTable();
            ac_HistoricalCost.dt_Edit_Maintaind_HCost = new DataTable();
            ac_HistoricalCost.dt_Add_VestWise_details = new DataTable();
            ac_HistoricalCost.dt_SelectedForVestwise = new DataTable("dt_SelectedForVestwise");
        }

        /// <summary>
        /// This method is used to enable the controls.
        /// </summary>
        /// <param name="historicalCost">HistoricalCost page object</param>
        private void EnableControls(HistoricalCost historicalCost)
        {
            historicalCost.MultiSelectEmpID.txtMultiselect.Enabled = true;
            historicalCost.MultiSelectEmpName.txtMultiselect.Enabled = true;
            historicalCost.MultiSelectGrantRegID.txtMultiselect.Enabled = true;
            historicalCost.MultiSelectGrantOptionID.txtMultiselect.Enabled = true;
            historicalCost.MultiSelectSchemeName.txtMultiselect.Enabled = true;
            historicalCost.txtCostAsOn.Enabled = true;
            historicalCost.btnNext.Enabled = true;
            historicalCost.btnSNext.Enabled = true;
            historicalCost.chkAPams.Enabled = false;
            historicalCost.rdbVMCC01.Enabled = true;
            historicalCost.rdbVMCC02.Enabled = true;
            historicalCost.txtReversalCost.Text = string.Empty;
            historicalCost.txtReversalDate.Text = "dd/mmm/yyyy";
            historicalCost.txtCostAsOn.Enabled = true;
            historicalCost.txtGrantFromDate.Enabled = true;
            historicalCost.txtGrantToDate.Enabled = true;
            historicalCost.chkAPams.Checked = false;
            historicalCost.divASPToCalacHCost.Visible = false;
            historicalCost.lblMsg.Visible = false;
            historicalCost.gvAParmsHCost.Visible = false;
        }


        /// <summary>
        /// This method is used to clear filters
        /// </summary>
        /// <param name="checkBoxList">checkBoxList object</param>
        /// <param name="textBox">textBox object</param>
        /// <param name="s_ControlName">ControlName object</param>
        private void ClearFilters(CheckBoxList checkBoxList, TextBox textBox, string s_ControlName)
        {
            try
            {
                switch (s_ControlName)
                {
                    case "Cancel":
                        foreach (ListItem CurrentItem in checkBoxList.Items)
                        {
                            CurrentItem.Selected = false;
                        }
                        textBox.Text = "--- Please Select ---";
                        break;

                    case "btnReset":
                        foreach (ListItem CurrentItem in checkBoxList.Items)
                        {
                            CurrentItem.Selected = false;
                        }
                        textBox.Text = "--- Please Select ---";
                        break;
                }

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  This method is used to create customize gridview
        /// </summary>
        /// <param name="historicalCost">Historical Cost page object</param>
        internal void CreateCustomizeView(HistoricalCost historicalCost)
        {

            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                genericProperties.PageName = CommonConstantModel.s_MnuHistoricalCost;

                ac_HistoricalCost.dt_CustmizedViewHistoricalCost = (DataTable)genericServiceClient.GetCustomizedViewTable(genericProperties);
            }
        }


        /// <summary>
        /// This method is used to create hashtable of int parameters 
        /// </summary>
        /// <param name="hashTable">Hashtable object</param>
        internal void CreateHashTable(Hashtable hashTable)
        {
            try
            {
                hashTable.Add("n_ID", 0);
                hashTable.Add("n_Delete", 0);
                hashTable.Add("n_Action", 0);
                hashTable.Add("n_EmpID", 0);
                hashTable.Add("n_EmpName", 0);
                hashTable.Add("n_GRegID", 0);
                hashTable.Add("n_GrantDate", 0);
                hashTable.Add("n_GrantOptioID", 0);
                hashTable.Add("n_IVORFV", 0);
                hashTable.Add("n_Location", 0);
                hashTable.Add("n_Dept", 0);
                hashTable.Add("n_SBU", 0);
                hashTable.Add("n_CostCentre", 0);
                hashTable.Add("n_Entity", 0);
                hashTable.Add("n_Scheme", 0);
                hashTable.Add("n_OutstandingOpt", 0);
                hashTable.Add("n_VestDate", 0);
                hashTable.Add("n_OPDate", 0);
                hashTable.Add("n_Date", 0);
                hashTable.Add("n_CostBySystem", 0);
                hashTable.Add("n_HCostManulally", 0);
                hashTable.Add("n_Row", 0);
                hashTable.Add("n_AdjustmtEntry", 0);
                hashTable.Add("n_FinalCost", 0);
                hashTable.Add("n_EID", 0);
                hashTable.Add("n_VPID", 0);
                hashTable.Add("n_GOptions", 0);
                hashTable.Add("n_CancelOptions", 0);
                hashTable.Add("n_VestedCancelled", 0);
                hashTable.Add("n_UnvestedCancelled", 0);
                hashTable.Add("n_Lapsed", 0);
                hashTable.Add("n_ExeOptions", 0);
                hashTable.Add("n_UnvestedOptions", 0);
                hashTable.Add("n_VEOptions", 0);
                hashTable.Add("n_FRate", 0);
                hashTable.Add("n_OPT_GRANTED_ID", 0);
                hashTable.Add("n_OPID", 0);
                hashTable.Add("n_LocID", 0);
                hashTable.Add("n_COCID", 0);
                hashTable.Add("n_ENTID", 0);
                hashTable.Add("n_DepID", 0);
                hashTable.Add("n_SBUID", 0);
                hashTable.Add("n_ReversalDate", 0);
                hashTable.Add("n_ReversalCost", 0);
                hashTable.Add("n_ExerPrice", 0);
                hashTable.Add("n_CostBYFV", 0);
                hashTable.Add("n_CostBYIV", 0);
                hashTable.Add("n_IsLocked", 0);
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~HistoricalCostModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}