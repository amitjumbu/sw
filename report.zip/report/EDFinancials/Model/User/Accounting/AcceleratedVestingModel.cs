﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Accounting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Accounting
{
    /// <summary>
    /// AcceleratedVestingModel class
    /// </summary>
    public class AcceleratedVestingModel : BaseModel, IDisposable
    {

        #region Default constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public AcceleratedVestingModel()
        {
            if (ac_AcceleratedVesting == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_AcceleratedVesting);
                ac_AcceleratedVesting = (CommonModel.AC_AcceleratedVesting)HttpContext.Current.Session[CommonConstantModel.s_AC_AcceleratedVesting];
            }
        }


        #endregion

        #region Common Bind Methods
        /// <summary>
        /// This method is used to Bind the all controls
        /// </summary>
        /// <param name="acceleratedVesting">Accelerated Vesting page object</param>
        internal void PopulateAllControls(AcceleratedVesting acceleratedVesting)
        {
            try
            {
                BindUI(acceleratedVesting);
            }
            catch
            {
                throw;
            }
        }



        /// <summary>
        /// This method is used to Bind UI controls
        /// </summary>
        /// <param name="acceleratedVesting">Accelerated Vesting page object</param>
        internal void BindUI(AcceleratedVesting acceleratedVesting)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (ac_AcceleratedVesting.dt_AcceleratedVestingUI == null || ac_AcceleratedVesting.dt_AcceleratedVestingUI.Rows.Count.Equals(0))
                    {
                        ac_AcceleratedVesting.dt_AcceleratedVestingUI = accountingServiceClient.GetAccounting_L10N_UI(CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10_UI);
                    }

                    acceleratedVesting.lblAVAddOrEditHead.Text = Convert.ToString((ac_AcceleratedVesting.dt_AcceleratedVestingUI.Select("LabelID = 'lblAVAddOrEditHead'"))[0]["LabelName"]);
                    acceleratedVesting.lblAVAddOrEditHead.ToolTip = Convert.ToString((ac_AcceleratedVesting.dt_AcceleratedVestingUI.Select("LabelID = 'lblAVAddOrEditHead'"))[0]["LabelToolTip"]);

                    acceleratedVesting.lblAVAddGrantID.Text = acceleratedVesting.lblAVGrantID.Text = Convert.ToString((ac_AcceleratedVesting.dt_AcceleratedVestingUI.Select("LabelID = 'lblAVAddGrantID'"))[0]["LabelName"]);
                    acceleratedVesting.lblAVAddGrantID.ToolTip = acceleratedVesting.lblAVGrantID.ToolTip = Convert.ToString((ac_AcceleratedVesting.dt_AcceleratedVestingUI.Select("LabelID = 'lblAVAddGrantID'"))[0]["LabelToolTip"]);

                    acceleratedVesting.lblAVAddGrantDate.Text = acceleratedVesting.lblAVGrantDate.Text = Convert.ToString((ac_AcceleratedVesting.dt_AcceleratedVestingUI.Select("LabelID = 'lblAVGrantDate'"))[0]["LabelName"]);
                    acceleratedVesting.lblAVAddGrantDate.ToolTip = acceleratedVesting.lblAVGrantDate.ToolTip = Convert.ToString((ac_AcceleratedVesting.dt_AcceleratedVestingUI.Select("LabelID = 'lblAVGrantDate'"))[0]["LabelToolTip"]);

                    if ((ac_AcceleratedVesting.dt_AcceleratedVestingUI != null) && (ac_AcceleratedVesting.dt_AcceleratedVestingUI.Rows.Count > 0))
                    {
                        foreach (Control control in acceleratedVesting.dvMain.Controls)
                        {
                            switch (control.GetType().FullName.ToUpper())
                            {
                                case CommonConstantModel.s_wcLabel:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeLabel, ac_AcceleratedVesting.dt_AcceleratedVestingUI, (Label)control);
                                    break;

                                case CommonConstantModel.s_wcTextbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeTextbox, ac_AcceleratedVesting.dt_AcceleratedVestingUI, (TextBox)control);
                                    break;

                                case CommonConstantModel.s_wcButton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeButton, ac_AcceleratedVesting.dt_AcceleratedVestingUI, (Button)control);
                                    break;

                                case CommonConstantModel.s_wcCheckbox:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeCheckBox, ac_AcceleratedVesting.dt_AcceleratedVestingUI, (CheckBox)control);
                                    break;

                                case CommonConstantModel.s_wcRadiobutton:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRadioButton, ac_AcceleratedVesting.dt_AcceleratedVestingUI, (RadioButton)control);
                                    break;

                                case CommonConstantModel.s_wcRequiredFieldValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRFValidator, ac_AcceleratedVesting.dt_AcceleratedVestingUI, (BaseValidator)control);
                                    break;

                                case CommonConstantModel.s_wcRugularExpressionValidator:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeRExprValidator, ac_AcceleratedVesting.dt_AcceleratedVestingUI, (BaseValidator)control);
                                    break;

                                case CommonConstantModel.s_wcGridview:
                                    BindPropertiesToControl(CommonConstantModel.s_cntrlTypeGridView, ac_AcceleratedVesting.dt_AcceleratedVestingUI, (GridView)control);
                                    break;
                            }

                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This private method is used to Bind controls with their properties.
        /// </summary>
        /// <param name="s_cntrlType">s_cntrlType will be UI/LABEL/TEXTBOX/BUTTON/ERROR</param>
        /// <param name="Dt_Get_L10N_UI">this datatable contains the data of the XML UI</param>
        /// <param name="control">control</param>
        private void BindPropertiesToControl(string s_cntrlType, DataTable Dt_Get_L10N_UI, Control control)
        {
            switch (s_cntrlType)
            {
                case CommonConstantModel.s_cntrlTypeLabel:
                    Label label = (Label)control;
                    label.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelName"]);
                    label.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + label.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeButton:
                    Button button = (Button)control;
                    button.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelName"]);
                    button.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + button.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeCheckBox:
                    CheckBox checkBox = (CheckBox)control;
                    checkBox.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelName"]);
                    checkBox.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + checkBox.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRadioButton:
                    RadioButton radioButton = (RadioButton)control;
                    radioButton.Text = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelName"]);
                    radioButton.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + radioButton.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRFValidator:
                    RequiredFieldValidator ReqValidator = (RequiredFieldValidator)control;
                    ReqValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + ReqValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeRExprValidator:
                    RegularExpressionValidator RegExpValidator = (RegularExpressionValidator)control;
                    RegExpValidator.ToolTip = Convert.ToString((Dt_Get_L10N_UI.Select("LabelID = '" + RegExpValidator.ID + "'"))[0]["LabelToolTip"]);
                    break;

                case CommonConstantModel.s_cntrlTypeGridView:
                    break;

                case CommonConstantModel.s_cntrlTypeTextBox:
                    break;
            }
        }

        #endregion

        #region Bind DropDown
        /// <summary>
        /// This method is used to get Updated As On Data
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        public void BindDropDown(AcceleratedVesting acceleratedVesting)
        {
            GetDataAcceleratedVesting(acceleratedVesting);
            GetDataOptionDetails(acceleratedVesting);
            LoadDefault_ViewDropDowns(acceleratedVesting);

            if (ac_AcceleratedVesting.dt_AcceleratedVestingData != null && ac_AcceleratedVesting.dt_AcceleratedVestingData.Rows.Count > 0)
            {
                ////Bind Employee ID drop-down 
                //acceleratedVesting.MultiSelectEmployeeID.chkMultiselect.DataSource = (from b in ac_AcceleratedVesting.dt_AcceleratedVestingData.AsEnumerable()
                //                                                                      where b.Field<string>("Employee ID") != null
                //                                                                      select b.Field<string>("Employee ID")).Distinct();
                //acceleratedVesting.MultiSelectEmployeeID.chkMultiselect.DataBind();

                ////Bind Employee Name drop-down 
                //acceleratedVesting.MultiSelectEmployeeName.chkMultiselect.DataSource = (from b in ac_AcceleratedVesting.dt_AcceleratedVestingData.AsEnumerable()
                //                                                                        where b.Field<string>("Employee Name") != null
                //                                                                        select b.Field<string>("Employee Name")).Distinct();
                //acceleratedVesting.MultiSelectEmployeeName.chkMultiselect.DataBind();

                ////Bind Scheme Name drop-down 
                //acceleratedVesting.MultiSelectSchemeName.chkMultiselect.DataSource = (from b in ac_AcceleratedVesting.dt_AcceleratedVestingData.AsEnumerable()
                //                                                                      where b.Field<string>("Scheme Name") != null
                //                                                                      select b.Field<string>("Scheme Name")).Distinct();
                //acceleratedVesting.MultiSelectSchemeName.chkMultiselect.DataBind();

                ////Bind Grant Registration ID drop-down 
                //acceleratedVesting.MultiSelectGrantID.chkMultiselect.DataSource = (from b in ac_AcceleratedVesting.dt_AcceleratedVestingData.AsEnumerable()
                //                                                                   where b.Field<string>("Grant Registration ID") != null
                //                                                                   select b.Field<string>("Grant Registration ID")).Distinct();
                //acceleratedVesting.MultiSelectGrantID.chkMultiselect.DataBind();

                ////Bind Grant Registration ID drop-down 
                //acceleratedVesting.MultiSelectGrantDate.chkMultiselect.DataSource = (from b in ac_AcceleratedVesting.dt_AcceleratedVestingData.AsEnumerable()
                //                                                                     where b.Field<DateTime>("Grant Date") != null
                //                                                                     select b.Field<DateTime>("Grant Date").ToString("dd/MMM/yyy")).Distinct();
                //acceleratedVesting.MultiSelectGrantDate.chkMultiselect.DataBind();
            }

            if (ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise != null && ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise.Rows.Count > 0)
            {
                ////Bind Employee ID drop-down 
                //acceleratedVesting.MultiSelectAddEmpID.chkMultiselect.DataSource = (from b in ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise.AsEnumerable()
                //                                                                    where b.Field<string>("Employee ID") != null
                //                                                                    select b.Field<string>("Employee ID")).Distinct();
                //acceleratedVesting.MultiSelectAddEmpID.chkMultiselect.DataBind();

                ////Bind Employee Name drop-down 
                //acceleratedVesting.MultiSelectAddEmpName.chkMultiselect.DataSource = (from b in ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise.AsEnumerable()
                //                                                                      where b.Field<string>("Employee Name") != null
                //                                                                      select b.Field<string>("Employee Name")).Distinct();
                //acceleratedVesting.MultiSelectAddEmpName.chkMultiselect.DataBind();

                ////Bind Grant Registration ID drop-down 
                //acceleratedVesting.MultiSelectAddGrantID.chkMultiselect.DataSource = (from b in ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise.AsEnumerable()
                //                                                                      where b.Field<string>("Grant Registration ID") != null
                //                                                                      select b.Field<string>("Grant Registration ID")).Distinct();
                //acceleratedVesting.MultiSelectAddGrantID.chkMultiselect.DataBind();

                ////Bind Grant Registration ID drop-down 
                //acceleratedVesting.MultiSelectAddGrantDate.chkMultiselect.DataSource = (from b in ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise.AsEnumerable()
                //                                                                        where b.Field<string>("Grant Date") != null
                //                                                                        select b.Field<string>("Grant Date")).Distinct();
                //acceleratedVesting.MultiSelectAddGrantDate.chkMultiselect.DataBind();
            }
        }
        #endregion

        #region Bind GridView
        /// <summary>
        /// This method is used to bind GridView
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        public void BindGridView(AcceleratedVesting acceleratedVesting)
        {
            try
            {
                ResetDictionaryValues(acceleratedVesting);
                DataView dv_AcceleratedVestingData = new DataView(ac_AcceleratedVesting.dt_AcceleratedVestingData);
                acceleratedVesting.gvSearch.DataSource = dv_AcceleratedVestingData.ToTable("DT", false, "ID", "Select", "Employee ID", "Employee Name", "Scheme Name", "Grant Registration ID", "Grant Option ID", "Option Details", "Accelerated Quantity", "Accelerated Date", "OPERATION DATE", "OPERATION_ID", "Action");
                acceleratedVesting.gvSearch.DataBind();
                acceleratedVesting.btnAVDelete.Visible = ac_AcceleratedVesting.dt_AcceleratedVestingData.Rows.Count > 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to bind GridView: Add section
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        public void BindGridViewAddSection(AcceleratedVesting acceleratedVesting)
        {
            DataView dv_AcceleratedVestingData = new DataView(ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise);
            acceleratedVesting.gvAddOrUpdate.DataSource = dv_AcceleratedVestingData.ToTable("DT", false, "OPT GRANTED ID", "Select", "Employee ID", "Employee Name", "Scheme Name", "Grant Registration ID", "Grant Option ID", "Option Details", "Accelerated Quantity", "Accelerated Date", "Granted", "Grant Date");
            acceleratedVesting.gvAddOrUpdate.DataBind();
        }

        /// <summary>
        /// This method is used to add column to datatable
        /// </summary>
        /// <param name="Operation">Operation to be perform</param>
        /// <param name="columnName">ColumnName</param>
        /// <param name="table">datatable</param>
        private void AddOrRenameColumn(string Operation, string columnName, DataTable table)
        {
            DataColumnCollection columns = table.Columns;

            switch (Operation)
            {
                case "Add":
                    if (!columns.Contains(columnName))
                        table.Columns.Add(columnName, typeof(string));
                    break;

                case "Rename":
                    table.Columns[columnName].ColumnName = "Action";
                    break;
            }
        }
        #endregion

        #region Search and Reset Filter
        /// <summary>
        /// Get data based on search parameters
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        /// <param name="sender">has some action perform on control</param>
        public void btnAVSearch_Click(AcceleratedVesting acceleratedVesting, object sender)
        {
            Button btn = (Button)sender;

            switch (btn.ID)
            {
                case "btnAVSearch":
                    SearchSection(acceleratedVesting);
                    acceleratedVesting.h3AddEdit.Style.Add("display", "none");
                    acceleratedVesting.hdnSearchData.Value = string.Empty;
                    break;

                case "btnAVAddSearch":
                    ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Clear();
                    ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Clear();
                    SearchSectionOptionDetail(acceleratedVesting);
                    acceleratedVesting.h3AddEdit.Style.Add("display", "block");
                    acceleratedVesting.hdnSearchData.Value = "True";
                    acceleratedVesting.hdnAccordionIndex.Value = "1";
                    break;
            }
        }

        /// <summary>
        /// This method is used to aply filters on search section
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        private void SearchSection(AcceleratedVesting acceleratedVesting)
        {
            DataTable dt_FilteredRecords = ac_AcceleratedVesting.dt_AcceleratedVestingData.Copy();

            if (dt_FilteredRecords != null && dt_FilteredRecords.Rows.Count > 0)
            {
                dt_FilteredRecords = ApplyFilters(acceleratedVesting, acceleratedVesting.MultiSelectEmployeeID.chkMultiselect, dt_FilteredRecords, "[Employee ID]", "CheckBoxFilter");
                AssignSearchFilterText(acceleratedVesting.MultiSelectEmployeeID.chkMultiselect, acceleratedVesting.MultiSelectEmployeeID.txtMultiselect);

                dt_FilteredRecords = ApplyFilters(acceleratedVesting, acceleratedVesting.MultiSelectEmployeeName.chkMultiselect, dt_FilteredRecords, "[Employee Name]", "CheckBoxFilter");
                AssignSearchFilterText(acceleratedVesting.MultiSelectEmployeeName.chkMultiselect, acceleratedVesting.MultiSelectEmployeeName.txtMultiselect);

                dt_FilteredRecords = ApplyFilters(acceleratedVesting, acceleratedVesting.MultiSelectGrantID.chkMultiselect, dt_FilteredRecords, "[Grant Registration ID]", "CheckBoxFilter");
                AssignSearchFilterText(acceleratedVesting.MultiSelectGrantID.chkMultiselect, acceleratedVesting.MultiSelectGrantID.txtMultiselect);

                dt_FilteredRecords = ApplyFilters(acceleratedVesting, acceleratedVesting.MultiSelectGrantDate.chkMultiselect, dt_FilteredRecords, "[Grant Date]", "CheckBoxFilter");
                AssignSearchFilterText(acceleratedVesting.MultiSelectGrantDate.chkMultiselect, acceleratedVesting.MultiSelectGrantDate.txtMultiselect);

                dt_FilteredRecords = ApplyFilters(acceleratedVesting, null, dt_FilteredRecords, "[Accelerated Date]", "FromAndToDateFilter");

                dt_FilteredRecords = ApplyFilters(acceleratedVesting, acceleratedVesting.MultiSelectSchemeName.chkMultiselect, dt_FilteredRecords, "[Scheme Name]", "CheckBoxFilter");
                AssignSearchFilterText(acceleratedVesting.MultiSelectSchemeName.chkMultiselect, acceleratedVesting.MultiSelectSchemeName.txtMultiselect);

                acceleratedVesting.btnAVReset.Visible = true;
            }

            ResetDictionaryValues(acceleratedVesting);
            acceleratedVesting.btnAVDelete.Visible = dt_FilteredRecords.Rows.Count > 0;
            DataView dv_AcceleratedVestingData = new DataView(dt_FilteredRecords);
            acceleratedVesting.gvSearch.DataSource = dv_AcceleratedVestingData.ToTable("DT", false, "ID", "Select", "Employee ID", "Employee Name", "Scheme Name", "Grant Registration ID", "Grant Option ID", "Option Details", "Accelerated Quantity", "Accelerated Date", "OPERATION DATE", "OPERATION_ID", "Action");
            acceleratedVesting.gvSearch.DataBind();
            dt_FilteredRecords.Dispose();
            if (acceleratedVesting.rdbAVSpecificGrants.Checked)
            {
                acceleratedVesting.divGrantAdd.Style.Add("display", "block");
            }
            else
            {
                acceleratedVesting.divGrantAdd.Style.Add("display", "none");
            }
        }

        /// <summary>
        /// this method is used to assign text to dropdown list
        /// </summary>
        /// <param name="chk_CheckBoxList">CheckBoxList control</param>
        /// <param name="textBox">TextBox control</param>
        private void AssignSearchFilterText(CheckBoxList chk_CheckBoxList, TextBox textBox)
        {
            string s_SelectedValues = string.Join(",", chk_CheckBoxList.Items.Cast<ListItem>()
                                          .Where(li => li.Selected)
                                          .Select(li => li.Value)
                                          .ToArray());
            textBox.Text = !string.IsNullOrEmpty(s_SelectedValues) ? s_SelectedValues : "--- Please Select ---";
        }

        /// <summary>
        /// This method is used to apply filters on Add section 
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        private void SearchSectionOptionDetail(AcceleratedVesting acceleratedVesting)
        {
            GetDataOptionDetails(acceleratedVesting);
            DataTable dt_FilteredRecords = ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise.Copy();

            if (dt_FilteredRecords != null && dt_FilteredRecords.Rows.Count > 0)
            {
                dt_FilteredRecords = ApplyFilters(acceleratedVesting, acceleratedVesting.MultiSelectAddEmpID.chkMultiselect, dt_FilteredRecords, "[Employee ID]", "CheckBoxFilter");
                AssignSearchFilterText(acceleratedVesting.MultiSelectAddEmpID.chkMultiselect, acceleratedVesting.MultiSelectAddEmpID.txtMultiselect);

                dt_FilteredRecords = ApplyFilters(acceleratedVesting, acceleratedVesting.MultiSelectAddEmpName.chkMultiselect, dt_FilteredRecords, "[Employee Name]", "CheckBoxFilter");
                AssignSearchFilterText(acceleratedVesting.MultiSelectAddEmpName.chkMultiselect, acceleratedVesting.MultiSelectAddEmpName.txtMultiselect);

                dt_FilteredRecords = ApplyFilters(acceleratedVesting, acceleratedVesting.MultiSelectAddGrantID.chkMultiselect, dt_FilteredRecords, "[Grant Registration ID]", "CheckBoxFilter");
                AssignSearchFilterText(acceleratedVesting.MultiSelectAddGrantID.chkMultiselect, acceleratedVesting.MultiSelectAddGrantID.txtMultiselect);

                dt_FilteredRecords = ApplyFilters(acceleratedVesting, acceleratedVesting.MultiSelectAddGrantDate.chkMultiselect, dt_FilteredRecords, "[Grant Date]", "CheckBoxFilter");
                AssignSearchFilterText(acceleratedVesting.MultiSelectAddGrantDate.chkMultiselect, acceleratedVesting.MultiSelectAddGrantDate.txtMultiselect);

                acceleratedVesting.btnAVAddReset.Visible = true;
            }

            ResetDictionaryValues(acceleratedVesting);
            acceleratedVesting.MultiSelectAddEmpID.txtMultiselect.Enabled = acceleratedVesting.MultiSelectAddEmpName.txtMultiselect.Enabled = true;
            if (acceleratedVesting.rdbAVAddSpecificGrants.Checked)
            {
                acceleratedVesting.divGrant.Style.Add("display", "block");
            }
            else
            {
                acceleratedVesting.divGrant.Style.Add("display", "none");
            }
            DataView dv_AcceleratedVestingData = new DataView(dt_FilteredRecords);
            acceleratedVesting.gvAddOrUpdate.DataSource = dv_AcceleratedVestingData.ToTable("DT", false, "OPT GRANTED ID", "Select", "Employee ID", "Employee Name", "Scheme Name", "Grant Registration ID", "Grant Option ID", "Option Details", "Accelerated Quantity", "Accelerated Date", "Granted", "Grant Date");
            acceleratedVesting.gvAddOrUpdate.DataBind();
            dt_FilteredRecords.Dispose();
        }

        /// <summary>
        /// This method is used to ApplyFilters on DataTable
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        /// <param name="chk_CheckBoxList">CheckBoxList object</param>
        /// <param name="dt_FilterDatatable">orignal/filtered DataTable</param>
        /// <param name="s_FieldName">Filed name for which filter to be applied</param>
        /// <param name="s_FilterType">Filter type to be applied</param>
        /// <returns>Filtered DataTable</returns>
        private DataTable ApplyFilters(AcceleratedVesting acceleratedVesting, CheckBoxList chk_CheckBoxList, DataTable dt_FilterDatatable, string s_FieldName, string s_FilterType)
        {
            string s_Query = string.Empty;

            switch (s_FilterType)
            {
                case "CheckBoxFilter":

                    string s_SelectedValues = string.Join(",", chk_CheckBoxList.Items.Cast<ListItem>()
                                              .Where(li => li.Selected)
                                              .Select(li => li.Value.Replace("'", "''").Insert(0, "'") + "'")
                                              .ToArray());

                    if (!string.IsNullOrEmpty(s_SelectedValues))
                    {
                        s_Query = s_FieldName + " IN (" + s_SelectedValues + ")";
                        dt_FilterDatatable.DefaultView.RowFilter = s_Query;
                        dt_FilterDatatable = dt_FilterDatatable.DefaultView.ToTable();
                    }

                    break;

                case "FromAndToDateFilter":

                    string s_FromDate = string.IsNullOrEmpty(acceleratedVesting.txtAVAcceleratedFromDate.Text) || acceleratedVesting.txtAVAcceleratedFromDate.Text.Equals("dd/mmm/yyyy") ? string.Empty : "[Accelerated Date] >= '" + Convert.ToDateTime(acceleratedVesting.txtAVAcceleratedFromDate.Text) + "'";
                    string s_ToDate = string.IsNullOrEmpty(acceleratedVesting.txtAVAcceleratedToDate.Text) || acceleratedVesting.txtAVAcceleratedToDate.Text.Equals("dd/mmm/yyyy") ? string.Empty : "[Accelerated Date] <= '" + Convert.ToDateTime(acceleratedVesting.txtAVAcceleratedToDate.Text) + "'";

                    if ((!(string.IsNullOrEmpty(s_FromDate))) && (!(string.IsNullOrEmpty(s_ToDate))))
                    {
                        if ((Convert.ToDateTime(acceleratedVesting.txtAVAcceleratedFromDate.Text) > Convert.ToDateTime(acceleratedVesting.txtAVAcceleratedToDate.Text)))
                        {
                            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                            {
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                acceleratedVesting.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAVDateValidate", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            }
                        }
                        else
                        {
                            s_Query = s_FromDate + " AND " + s_ToDate;
                            dt_FilterDatatable.DefaultView.RowFilter = s_Query;
                        }

                    }
                    else if (string.IsNullOrEmpty(s_Query) && !string.IsNullOrEmpty(s_FromDate))
                    {
                        dt_FilterDatatable.DefaultView.RowFilter = s_FromDate;
                    }
                    else if (string.IsNullOrEmpty(s_Query) && !string.IsNullOrEmpty(s_ToDate))
                    {
                        dt_FilterDatatable.DefaultView.RowFilter = s_ToDate;
                    }
                    dt_FilterDatatable = dt_FilterDatatable.DefaultView.ToTable();

                    break;
            }


            return dt_FilterDatatable;
        }

        /// <summary>
        /// This method is used to reset filters
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        /// <param name="sender">has some action perform on control</param>
        public void btnAVReset_Click(AcceleratedVesting acceleratedVesting, object sender)
        {
            Button btn = (Button)sender;

            switch (btn.ID)
            {
                case "btnAVReset":
                    ResetDictionaryValues(acceleratedVesting);
                    BindGridView(acceleratedVesting);

                    ResetDropDown(acceleratedVesting, acceleratedVesting.MultiSelectEmployeeID.chkMultiselect);
                    acceleratedVesting.MultiSelectEmployeeID.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(acceleratedVesting, acceleratedVesting.MultiSelectEmployeeName.chkMultiselect);
                    acceleratedVesting.MultiSelectEmployeeName.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(acceleratedVesting, acceleratedVesting.MultiSelectGrantDate.chkMultiselect);
                    acceleratedVesting.MultiSelectGrantDate.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(acceleratedVesting, acceleratedVesting.MultiSelectGrantID.chkMultiselect);
                    acceleratedVesting.MultiSelectGrantID.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(acceleratedVesting, acceleratedVesting.MultiSelectSchemeName.chkMultiselect);
                    acceleratedVesting.MultiSelectSchemeName.txtMultiselect.Text = "--- Please Select ---";

                    acceleratedVesting.txtAVAcceleratedFromDate.Text = string.Empty;
                    acceleratedVesting.txtAVAcceleratedToDate.Text = string.Empty;
                    acceleratedVesting.btnAVReset.Visible = false;
                    break;

                case "btnAVAddReset":
                    ResetDictionaryValues(acceleratedVesting);
                    BindGridViewAddSection(acceleratedVesting);

                    ResetDropDown(acceleratedVesting, acceleratedVesting.MultiSelectAddEmpID.chkMultiselect);
                    acceleratedVesting.MultiSelectAddEmpID.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(acceleratedVesting, acceleratedVesting.MultiSelectAddEmpName.chkMultiselect);
                    acceleratedVesting.MultiSelectAddEmpName.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(acceleratedVesting, acceleratedVesting.MultiSelectAddGrantID.chkMultiselect);
                    acceleratedVesting.MultiSelectAddGrantID.txtMultiselect.Text = "--- Please Select ---";

                    ResetDropDown(acceleratedVesting, acceleratedVesting.MultiSelectAddGrantDate.chkMultiselect);
                    acceleratedVesting.MultiSelectAddGrantDate.txtMultiselect.Text = "--- Please Select ---";

                    acceleratedVesting.divGrantAdd.Style.Add("display", "none");
                    acceleratedVesting.divGrant.Style.Add("display", "none");
                    acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    acceleratedVesting.btnAVAddReset.Visible = false;
                    break;
            }
        }

        /// <summary>
        /// This method is used to reset dropdownlist
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        /// <param name="chk_CheckBoxList">CheckBoxList object</param>
        private static void ResetDropDown(AcceleratedVesting acceleratedVesting, CheckBoxList chk_CheckBoxList)
        {
            (from i in chk_CheckBoxList.Items.Cast<ListItem>() select i).ToList().ForEach(i => i.Selected = false);
        }

        #endregion

        #region Get Data
        /// <summary>
        /// this method is used to get data of Options Details
        /// </summary>
        public void GetDataOptionDetails(AcceleratedVesting acceleratedVesting)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                DateTime? dt = null;
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.PageName = CommonConstantModel.s_GetOptionsDetails;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;
                accountingProperties.ReportDate = dt;
                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                //ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise = accountingCRUDProperties.ds_Result.Tables[0] != null && accountingCRUDProperties.ds_Result.Tables[0].Rows.Count > 0 ? accountingCRUDProperties.ds_Result.Tables[0].Select("OPERATION_ID <> 6").Count() > 0 ? accountingCRUDProperties.ds_Result.Tables[0].Select("OPERATION_ID <> 6").CopyToDataTable() : accountingCRUDProperties.ds_Result.Tables[0] : accountingCRUDProperties.ds_Result.Tables[0];
                ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise = accountingCRUDProperties.ds_Result.Tables[0];
                AddOrRenameColumn("Add", "Select", ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise);
                AddOrRenameColumn("Add", "Option Details", ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise);
                //ac_AcceleratedVesting.dt_ODAcceleratedVestingVestWise = accountingCRUDProperties.ds_Result.Tables[1] != null && accountingCRUDProperties.ds_Result.Tables[1].Rows.Count > 0 ? accountingCRUDProperties.ds_Result.Tables[1].Select("OPERATION_ID <> 6").Count() > 0 ? accountingCRUDProperties.ds_Result.Tables[1].Select("OPERATION_ID <> 6").CopyToDataTable() : accountingCRUDProperties.ds_Result.Tables[1] : accountingCRUDProperties.ds_Result.Tables[1];
                ac_AcceleratedVesting.dt_ODAcceleratedVestingVestWise = accountingCRUDProperties.ds_Result.Tables[1];
            }
        }

        /// <summary>
        /// this method is used to get data of Accelerated Vesting
        /// </summary>
        public void GetDataAcceleratedVesting(AcceleratedVesting acceleratedVesting)
        {
            using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
            {
                accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                accountingProperties.PageName = CommonConstantModel.s_AcceleratedVesting;
                accountingProperties.Operation = CommonConstantModel.s_OperationRead;

                accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);
                ac_AcceleratedVesting.dt_AcceleratedVestingData = accountingCRUDProperties.ds_Result.Tables[0];
                ac_AcceleratedVesting.dt_AcceleratedVestingDataVestwise = accountingCRUDProperties.ds_Result.Tables[1];
            }
        }
        #endregion

        #region Reset Dictionary values
        /// <summary>
        /// This method is used to reset values of Dictionary
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        private void ResetDictionaryValues(AcceleratedVesting acceleratedVesting)
        {
            acceleratedVesting.dictionary["n_Index"] = 0;
            acceleratedVesting.dictionary["n_RowIndex"] = 1;
            acceleratedVesting.dictionary["n_ID"] = 0;
            acceleratedVesting.dictionary["n_Select"] = 0;
            acceleratedVesting.dictionary["n_OptionDetails"] = 0;
            acceleratedVesting.dictionary["n_AcceleratedQty"] = 0;
            acceleratedVesting.dictionary["n_AcceleratedDate"] = 0;
            acceleratedVesting.dictionary["n_Operation_Date"] = 0;
            acceleratedVesting.dictionary["n_Operation_ID"] = 0;
            acceleratedVesting.dictionary["n_EmployeeName"] = 0;
            acceleratedVesting.dictionary["n_EmployeeID"] = 0;
            acceleratedVesting.dictionary["n_SchemeName"] = 0;
            acceleratedVesting.dictionary["n_GrantRegistrationID"] = 0;
            acceleratedVesting.dictionary["n_GrantOptionID"] = 0;
            acceleratedVesting.dictionary["n_Granted"] = 0;
            acceleratedVesting.dictionary["n_GrantDate"] = 0;
            acceleratedVesting.dictionary["n_Action"] = 0;
        }
        #endregion

        /// <summary>
        /// This method is used to show records 
        /// </summary>
        /// <param name="acceleratedVesting"></param>
        /// <param name="sender">has some action perform on control</param>
        public void imgButton_Click(AcceleratedVesting acceleratedVesting, object sender)
        {
            ResetDictionaryValues(acceleratedVesting);

            ImageButton imageButton = (ImageButton)sender;
            ac_AcceleratedVesting.b_IsEdit = true;
            DataView dv_AcceleratedVestingData = new DataView(ac_AcceleratedVesting.dt_AcceleratedVestingData.Select("[OPT GRANTED ID] = '" + imageButton.ID.Split('_')[1] + "'").Count() > 0 ? ac_AcceleratedVesting.dt_AcceleratedVestingData.Select("[OPT GRANTED ID] = '" + imageButton.ID.Split('_')[1] + "'").CopyToDataTable() : ac_AcceleratedVesting.dt_AcceleratedVestingData);
            acceleratedVesting.gvAddOrUpdate.DataSource = dv_AcceleratedVestingData.ToTable("DT", false, "OPT GRANTED ID", "Select", "Employee ID", "Employee Name", "Scheme Name", "Grant Registration ID", "Grant Option ID", "Option Details", "Accelerated Quantity", "Accelerated Date", "Granted", "Grant Date");
            acceleratedVesting.gvAddOrUpdate.DataBind();

            acceleratedVesting.MultiSelectAddEmpID.txtMultiselect.Enabled = acceleratedVesting.MultiSelectAddEmpName.txtMultiselect.Enabled = false;
            acceleratedVesting.rdbAVAddSelectAll.InputAttributes.Add("disabled", "disabled");
            acceleratedVesting.rdbAVAddSpecificGrants.InputAttributes.Add("disabled", "disabled");
            acceleratedVesting.btnAVAddSearch.Attributes.Add("disabled", "disabled");

            acceleratedVesting.h3AddEdit.Style.Add("display", "block");
            acceleratedVesting.hdnSearchData.Value = "True";
            acceleratedVesting.hdnAccordionIndex.Value = "1";
            ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Clear();
            ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Clear();

            imageButton.Dispose();
            ac_AcceleratedVesting.b_IsEdit = false;
        }

        /// <summary>
        /// Perform CRUD operation
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        public void btnAVSave_Click(AcceleratedVesting acceleratedVesting)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    if (!ValidateData() || !string.IsNullOrEmpty(acceleratedVesting.hdnDeletedRecords.Value))
                    {
                        string s_deleteDates = string.IsNullOrEmpty(acceleratedVesting.hdnOperationDates.Value) ? string.Empty :
                                                           string.Join(",", acceleratedVesting.hdnOperationDates.Value.TrimStart(',').Split(',')
                                                           .Select(li => li.Insert(0, "'") + "'")
                                                           .ToArray());

                        accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        accountingProperties.PageName = CommonConstantModel.s_AcceleratedVesting;
                        accountingProperties.Operation = CommonConstantModel.s_OperationCUD;
                        accountingProperties.Action = !acceleratedVesting.hdnEditResord.Value.Equals("0") ? "U" : !string.IsNullOrEmpty(acceleratedVesting.hdnDeletedRecords.Value) ? "D" : "C";
                        accountingProperties.s_OptGrantedIdDelete = string.IsNullOrEmpty(acceleratedVesting.hdnDeletedRecords.Value) ? string.Empty : acceleratedVesting.hdnDeletedRecords.Value.TrimStart(',');
                        accountingProperties.s_OptOperationDates = string.IsNullOrEmpty(acceleratedVesting.hdnOperationDates.Value) ? string.Empty : s_deleteDates;
                        accountingProperties.dt_Opt_Details_AV = userSessionInfo.ACC_CalculationMethod.Equals(1) ? ac_AcceleratedVesting.dt_SaveAcceleratedVesting : CreateDatatbleGratwise();
                        accountingProperties.dt_Opt_Details_AV_VestWise = userSessionInfo.ACC_CalculationMethod.Equals(2) ? ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise : CreateBlankDatatbleVestwise();
                        accountingProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        accountingProperties.SEN_CalculationMethod = userSessionInfo.ACC_CalculationMethod;
                        accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                        acceleratedVesting.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;

                        switch (accountingCRUDProperties.a_result)
                        {
                            case 0:
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                acceleratedVesting.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAVError", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                break;

                            case 1:
                                acceleratedVesting.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAVCreated", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                acceleratedVesting.h3AddEdit.Style.Add("display", "none");
                                acceleratedVesting.hdnSearchData.Value = string.Empty;
                                BindDropDown(acceleratedVesting);
                                acceleratedVesting.hdnAccordionIndex.Value = "0";
                                break;

                            case 2:
                                acceleratedVesting.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAVUpdated", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                acceleratedVesting.h3AddEdit.Style.Add("display", "none");
                                acceleratedVesting.hdnSearchData.Value = string.Empty;
                                acceleratedVesting.hdnAccordionIndex.Value = "0";
                                break;

                            case 3:
                                acceleratedVesting.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAVDeleted", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                break;

                            case 6:
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                acceleratedVesting.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAVLocked", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                acceleratedVesting.h3AddEdit.Style.Add("display", "none");
                                acceleratedVesting.hdnSearchData.Value = string.Empty;
                                BindDropDown(acceleratedVesting);
                                acceleratedVesting.hdnAccordionIndex.Value = "0";
                                break;

                            case 7:
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                acceleratedVesting.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAVExceedQty", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                                acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                acceleratedVesting.h3AddEdit.Style.Add("display", "none");
                                acceleratedVesting.hdnSearchData.Value = string.Empty;
                                BindDropDown(acceleratedVesting);
                                acceleratedVesting.hdnAccordionIndex.Value = "0";
                                break;
                        }
                    }
                    else
                    {
                        acceleratedVesting.ctrSuccessErrorMessage.s_MessageText = accountingServiceClient.GetAccounting_L10N("lblAVValidate", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                        acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        acceleratedVesting.h3AddEdit.Style.Add("display", "block");
                        acceleratedVesting.hdnSearchData.Value = string.Empty;
                        acceleratedVesting.hdnAccordionIndex.Value = "1";
                        ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Clear();
                        ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Clear();
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Clear();
                throw ex;
            }
            finally
            {
                acceleratedVesting.hdnEditResord.Value = "0";
                acceleratedVesting.hdnDeletedRecords.Value = string.Empty;
                acceleratedVesting.hdnOperationDates.Value = string.Empty;
                ResetDictionaryValues(acceleratedVesting);
                SearchSectionOptionDetail(acceleratedVesting);
                GetDataAcceleratedVesting(acceleratedVesting);
                SearchSection(acceleratedVesting);
            }
        }

        /// <summary>
        /// This method is used to check wheather Qty or Date is blank
        /// </summary>
        /// <returns></returns>
        private bool ValidateData()
        {
            switch (userSessionInfo.ACC_CalculationMethod)
            {
                case 1:
                    return ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Select("ACCELERATED_QUANTITY IS NULL").Length > 0 || ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Select("ACCELERATED_DATE IS NULL").Length > 0;

                case 2:
                    if (ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Select("ACCELERATED_QUANTITY IS NULL").Count().Equals(ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Rows.Count) && ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Select("ACCELERATED_DATE IS NULL").Count().Equals(ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Rows.Count))
                    {
                        return true;
                    }

                    foreach (DataRow perRow in ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Rows)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(perRow["ACCELERATED_QUANTITY"])) && string.IsNullOrEmpty(Convert.ToString(perRow["ACCELERATED_DATE"])))
                        {
                            return true;
                        }
                    }
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Create Datatble for Gratwise
        /// </summary>
        /// <returns>DataTable</returns>
        internal DataTable CreateDatatbleGratwise()
        {
            DataRow drGratwise;

            var SaveAcceleratedVesting = from r in ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Select("ACCELERATED_QUANTITY IS NOT NULL").AsEnumerable()
                                         group r by new
                                         {
                                             OPT_GRANTED_ID = r.Field<int>("OPT_GRANTED_ID"),
                                         } into g
                                         select new
                                         {
                                             OPT_GRANTED_ID = g.Key.OPT_GRANTED_ID,
                                             ACCELERATED_QUANTITY = g.Sum(x => x.Field<int>("ACCELERATED_QUANTITY"))
                                         };

            foreach (var item in SaveAcceleratedVesting)
            {
                drGratwise = ac_AcceleratedVesting.dt_SaveAcceleratedVesting.NewRow();
                drGratwise["OPT_GRANTED_ID"] = item.OPT_GRANTED_ID;
                drGratwise["ACCELERATED_QUANTITY"] = item.ACCELERATED_QUANTITY;
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Rows.Add(drGratwise);
            }


            return ac_AcceleratedVesting.dt_SaveAcceleratedVesting;
        }

        #region Show Option Details using JSON
        /// <summary>
        /// This method is used to get Options Details based on OptGrantID
        /// </summary>
        /// <param name="s_OptGrantID">OptGrantedID is primary key in GrantedOptions table</param>
        /// <param name="s_ButtonName">s_ButtonName is button name</param>
        /// <returns>Serializered string</returns>
        public string GetOptionsDetails_JSON(string s_OptGrantID, string s_ButtonName)
        {
            switch (s_ButtonName)
            {
                case "lbtn":
                    DataView dv_ODAcceleratedVestingData = new DataView(ac_AcceleratedVesting.dt_AcceleratedVestingData.Select("[OPT GRANTED ID] = '" + s_OptGrantID + "'").Count() > 0 ? ac_AcceleratedVesting.dt_AcceleratedVestingData.Select("ID = '" + s_OptGrantID + "'").CopyToDataTable() : new DataTable());
                    return DataSetToJSON(null, dv_ODAcceleratedVestingData.ToTable("DT", false, "Grant Option ID", "Granted", "Cancelled", "Vested Cancelled", "Unvested Cancelled", "Lapsed", "Exercised", "Unvested", "Vested and Exercisable", "Outstanding"), "DataTable");


                case "lbtnAdd":
                    DataView dv_AcceleratedVestingData = new DataView(ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise.Select("[OPT GRANTED ID] = '" + s_OptGrantID + "'").Count() > 0 ? ac_AcceleratedVesting.dt_ODAcceleratedVestingGrantWise.Select("[OPT GRANTED ID] = '" + s_OptGrantID + "'").CopyToDataTable() : new DataTable());
                    return DataSetToJSON(null, dv_AcceleratedVestingData.ToTable("DT", false, "Grant Option ID", "Granted", "Cancelled", "Vested Cancelled", "Unvested Cancelled", "Lapsed", "Exercised", "Unvested", "Vested and Exercisable", "Outstanding"), "DataTable");
            }
            return string.Empty;
        }

        /// <summary>
        /// This method is used to Serialize Json object
        /// </summary>
        /// <param name="dataSet">Dataset used to convert to string/Serializer</param>
        /// <param name="dataTable">DataTable used to convert to string/Serializer</param>
        /// <param name="s_SelectType">Type which want to convert i.e. DataSet/DataTable</param>
        /// <returns>string</returns>
        private string DataSetToJSON(DataSet dataSet, DataTable dataTable, string s_SelectType)
        {
            JavaScriptSerializer json = new JavaScriptSerializer();
            Dictionary<string, object> dictionary = new Dictionary<string, object>();

            switch (s_SelectType)
            {
                case "DataSet":
                    foreach (DataTable dt in dataSet.Tables)
                    {
                        object[] arr = new object[dt.Rows.Count + 1];

                        for (int i = 0; i <= dt.Rows.Count - 1; i++)
                        {
                            arr[i] = dt.Rows[i].ItemArray;
                        }

                        dictionary.Add(dt.TableName, arr);
                    }
                    break;

                case "DataTable":
                    object[] arr_Dt = new object[dataTable.Rows.Count + 1];

                    for (int i = 0; i <= dataTable.Rows.Count - 1; i++)
                    {
                        arr_Dt[i] = dataTable.Rows[i].ItemArray;
                    }

                    dictionary.Add(dataTable.TableName, arr_Dt);
                    break;
            }

            return json.Serialize(dictionary);
        }
        #endregion

        #region Set values to datatable during postback
        /// <summary>
        /// This method is used to assign TextBox values in from dynamically created GridView to DataTable
        /// </summary>
        /// <param name="nameValueCollection">NameValueCollection values get using Request.Form)</param>
        /// <param name="acceleratedVesting">AcceleratedVesting Cost page object</param>
        internal void AssignValuesFromTextbox(System.Collections.Specialized.NameValueCollection nameValueCollection, AcceleratedVesting acceleratedVesting)
        {
            try
            {
                int n_OPT_GRANTED_ID = 0, n_VPD_VESTING_PERIOD_ID = 0, n_Vest_ID = 0;

                foreach (var item in nameValueCollection.AllKeys)
                {
                    //e.g.: TextBox control name = ctl00$MainContent$gvAddOrUpdate$ctl02$\|txtDate\|9\|1
                    if (item != null && Convert.ToString(item).Contains("txtQty") && item.Replace("\\", "").Split('$').Last().Split('|').Last().Equals("1"))
                    {
                        switch (userSessionInfo.ACC_CalculationMethod)
                        {
                            case 1:
                                DataRow dr = ac_AcceleratedVesting.dt_SaveAcceleratedVesting.NewRow();
                                dr["OPT_GRANTED_ID"] = n_OPT_GRANTED_ID = Convert.ToInt32(item.Replace("\\", "").Split('$').Last().Split('|')[item.Replace("\\", "").Split('$').Last().Split('|').Count() - 2]);
                                if (!string.IsNullOrEmpty(Convert.ToString(nameValueCollection[item])))
                                {
                                    dr["ACCELERATED_QUANTITY"] = string.IsNullOrEmpty(Convert.ToString(nameValueCollection[item])) ? 0 : Convert.ToInt32(nameValueCollection[item]);
                                }
                                else
                                {
                                    dr["ACCELERATED_QUANTITY"] = DBNull.Value;
                                }
                                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Rows.Add(dr);
                                break;

                            case 2:
                                DataRow dr_Vestwise;
                                foreach (DataRow perRow in ac_AcceleratedVesting.dt_ODAcceleratedVestingVestWise.Select("[OPT GRANTED ID] = '" + Convert.ToInt32(item.Replace("\\", "").Split('$').Last().Split('|')[item.Replace("\\", "").Split('$').Last().Split('|').Count() - 2]) + "' AND [VESTING PERIOD NUMBER] = '" + Convert.ToInt32((item.Replace("\\", "").Split('$').Last().Split('|'))[2]) + "'"))
                                {
                                    dr_Vestwise = ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.NewRow();
                                    dr_Vestwise["OPT_GRANTED_ID"] = Convert.ToInt32(item.Replace("\\", "").Split('$').Last().Split('|')[item.Replace("\\", "").Split('$').Last().Split('|').Count() - 2]);
                                    dr_Vestwise["VPD_VESTING_PERIOD_ID"] = Convert.ToInt32(perRow["VESTING PERIOD NUMBER"]).Equals(Convert.ToInt32((item.Replace("\\", "").Split('$').Last().Split('|'))[2])) ? Convert.ToInt32((item.Replace("\\", "").Split('$').Last().Split('|'))[2]) : Convert.ToInt32(perRow["VESTING PERIOD NUMBER"]);
                                    dr_Vestwise["OPT_VEST_ID"] = Convert.ToInt32(perRow["OPT_VEST_ID"]).Equals(Convert.ToInt32((item.Replace("\\", "").Split('$').Last().Split('|'))[3])) ? Convert.ToInt32((item.Replace("\\", "").Split('$').Last().Split('|'))[3]) : Convert.ToInt32(perRow["OPT_VEST_ID"]);
                                    if (!string.IsNullOrEmpty(Convert.ToString(nameValueCollection[item])))
                                    {
                                        dr_Vestwise["ACCELERATED_QUANTITY"] = string.IsNullOrEmpty(Convert.ToString(nameValueCollection[item])) ? 0 : Convert.ToInt32(nameValueCollection[item]);
                                    }
                                    else
                                    {
                                        dr_Vestwise["ACCELERATED_QUANTITY"] = DBNull.Value;
                                    }
                                    ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Rows.Add(dr_Vestwise);
                                }
                                n_OPT_GRANTED_ID = Convert.ToInt32(item.Replace("\\", "").Split('$').Last().Split('|')[item.Replace("\\", "").Split('$').Last().Split('|').Count() - 2]);
                                n_VPD_VESTING_PERIOD_ID = Convert.ToInt32((item.Replace("\\", "").Split('$').Last().Split('|'))[2]);
                                n_Vest_ID = Convert.ToInt32((item.Replace("\\", "").Split('$').Last().Split('|'))[3]);

                                break;

                        }

                    }
                    if (item != null && Convert.ToString(item).Contains("txtDate") && item.Replace("\\", "").Split('$').Last().Split('|').Last().Equals("1"))
                    {
                        switch (userSessionInfo.ACC_CalculationMethod)
                        {
                            case 1:
                                foreach (var perRow in ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Select("OPT_GRANTED_ID = '" + n_OPT_GRANTED_ID + "'"))
                                {
                                    if (string.IsNullOrEmpty(Convert.ToString(nameValueCollection[item])) || Convert.ToString(nameValueCollection[item]).Equals("dd/mmm/yyyy"))
                                    {
                                        perRow["ACCELERATED_DATE"] = DBNull.Value;
                                    }
                                    else
                                    {
                                        perRow["ACCELERATED_DATE"] = Convert.ToDateTime(nameValueCollection[item]);
                                    }
                                }
                                break;
                            case 2:
                                foreach (var perRow in ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Select("OPT_GRANTED_ID = '" + n_OPT_GRANTED_ID + "' AND VPD_VESTING_PERIOD_ID = '" + n_VPD_VESTING_PERIOD_ID + "' AND OPT_VEST_ID = '" + n_Vest_ID + "'"))
                                {
                                    if (string.IsNullOrEmpty(Convert.ToString(nameValueCollection[item])) || Convert.ToString(nameValueCollection[item]).Equals("dd/mmm/yyyy"))
                                    {
                                       // perRow["ACCELERATED_DATE"] = ac_AcceleratedVesting.dt_ODAcceleratedVestingVestWise.Select("[OPT GRANTED ID] = '" + Convert.ToInt32(item.Replace("\\", "").Split('$').Last().Split('|')[item.Replace("\\", "").Split('$').Last().Split('|').Count() - 2]) + "'").Count() > 0 ? (ac_AcceleratedVesting.dt_ODAcceleratedVestingVestWise.Select("[OPT GRANTED ID] = '" + Convert.ToInt32(item.Replace("\\", "").Split('$').Last().Split('|')[item.Replace("\\", "").Split('$').Last().Split('|').Count() - 2]) + "'")[0]["Accelerated Date"]) : DBNull.Value;
                                        perRow["ACCELERATED_DATE"] = DBNull.Value;
                                    }
                                    else
                                    {
                                        perRow["ACCELERATED_DATE"] = Convert.ToDateTime(nameValueCollection[item]);
                                    }
                                }
                                break;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region RowDataBound event
        /// <summary>
        /// This method is used to bind controls to gridview
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        /// <param name="e">GridViewRowEventArgs for gvSearch</param>
        /// <param name="dictionary">Dictionary contains rows and index</param>
        /// <param name="sender">has some action perform on control</param>
        public void gvSearch_RowDataBound(AcceleratedVesting acceleratedVesting, GridViewRowEventArgs e, ref Dictionary<string, int> dictionary, object sender)
        {
            try
            {
                bool b_IsRowExists = IsNullOrEmptyDataTable();
                int n_RowCount = 0;
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    dictionary["n_ID"] = dictionary["n_Index"];
                                    perColumn.Visible = false;
                                    break;

                                case "EMPLOYEE NAME":
                                    dictionary["n_EmployeeName"] = dictionary["n_Index"];
                                    n_RowCount = CheckDataTableCount("EMPLOYEE_NAME");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'EMPLOYEE_NAME'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'EMPLOYEE_NAME'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "EMPLOYEE ID":
                                    dictionary["n_EmployeeID"] = dictionary["n_Index"];
                                    n_RowCount = CheckDataTableCount("EMPLOYEE_ID");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'EMPLOYEE_ID'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'EMPLOYEE_ID'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "SCHEME NAME":
                                    dictionary["n_SchemeName"] = dictionary["n_Index"];
                                    n_RowCount = CheckDataTableCount("SCH_SCHEME_TITLE");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'SCH_SCHEME_TITLE'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'SCH_SCHEME_TITLE'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "GRANT REGISTRATION ID":
                                    dictionary["n_GrantRegistrationID"] = dictionary["n_Index"];
                                    n_RowCount = CheckDataTableCount("GRS_GRANT_REGISTRATION_ID");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'GRS_GRANT_REGISTRATION_ID'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "GRANT OPTION ID":
                                    dictionary["n_GrantOptionID"] = dictionary["n_Index"];
                                    n_RowCount = CheckDataTableCount("GRANT_OPTION_ID");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'GRANT_OPTION_ID'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'GRANT_OPTION_ID'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "SELECT":
                                    dictionary["n_Select"] = dictionary["n_Index"];
                                    e.Row.Cells[dictionary["n_Select"]].Controls.Add(AddControlToGridView(acceleratedVesting, "CheckBoxSelectAll", e.Row.Cells[dictionary["n_ID"]].Text, string.Empty, "chk", string.Empty, string.Empty, e.Row.Cells[dictionary["n_Select"]].Text.Equals("1"), string.Empty));
                                    break;

                                case "OPTION DETAILS":
                                    dictionary["n_OptionDetails"] = dictionary["n_Index"];
                                    break;

                                case "ACCELERATED QUANTITY":
                                    dictionary["n_AcceleratedQty"] = dictionary["n_Index"];
                                    n_RowCount = CheckDataTableCount("ACCELERATED_QUANTITY");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'ACCELERATED_QUANTITY'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'ACCELERATED_QUANTITY'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "ACCELERATED DATE":
                                    dictionary["n_AcceleratedDate"] = dictionary["n_Index"];
                                    n_RowCount = CheckDataTableCount("ACCELERATED_DATE");
                                    perColumn.Visible = b_IsRowExists ? true : n_RowCount > 0;
                                    perColumn.Text = !b_IsRowExists && n_RowCount > 0 ?
                                                     string.IsNullOrEmpty(ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'ACCELERATED_DATE'")[0]["COLUMN_ALIAS"].ToString()) ?
                                                     perColumn.Text : ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = 'ACCELERATED_DATE'")[0]["COLUMN_ALIAS"].ToString() : perColumn.Text;
                                    break;

                                case "OPERATION DATE":
                                    dictionary["n_Operation_Date"] = dictionary["n_Index"];
                                    perColumn.Visible = false;
                                    break;

                                case "OPERATION_ID":
                                    dictionary["n_Operation_ID"] = dictionary["n_Index"];
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    dictionary["n_Action"] = dictionary["n_Index"];
                                    break;
                            }
                            dictionary["n_Index"] = dictionary["n_Index"] + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:

                        n_RowCount = CheckDataTableCount("EMPLOYEE_ID");
                        e.Row.Cells[dictionary["n_EmployeeID"]].Visible = b_IsRowExists ? true : n_RowCount > 0;
                        n_RowCount = CheckDataTableCount("EMPLOYEE_NAME");
                        e.Row.Cells[dictionary["n_EmployeeName"]].Visible = b_IsRowExists ? true : n_RowCount > 0;
                        n_RowCount = CheckDataTableCount("SCH_SCHEME_TITLE");
                        e.Row.Cells[dictionary["n_SchemeName"]].Visible = b_IsRowExists ? true : n_RowCount > 0;
                        n_RowCount = CheckDataTableCount("GRS_GRANT_REGISTRATION_ID");
                        e.Row.Cells[dictionary["n_GrantRegistrationID"]].Visible = b_IsRowExists ? true : n_RowCount > 0;
                        n_RowCount = CheckDataTableCount("GRANT_OPTION_ID");
                        e.Row.Cells[dictionary["n_GrantOptionID"]].Visible = b_IsRowExists ? true : n_RowCount > 0;
                        n_RowCount = CheckDataTableCount("ACCELERATED_QUANTITY");
                        e.Row.Cells[dictionary["n_AcceleratedQty"]].Visible = b_IsRowExists ? true : n_RowCount > 0;
                        n_RowCount = CheckDataTableCount("ACCELERATED_DATE");
                        e.Row.Cells[dictionary["n_AcceleratedDate"]].Visible = b_IsRowExists ? true : n_RowCount > 0;

                        e.Row.Cells[dictionary["n_ID"]].Visible = false;
                        e.Row.Cells[dictionary["n_Operation_Date"]].Visible = false;
                        e.Row.Cells[dictionary["n_Operation_ID"]].Visible = false;
                        e.Row.Cells[dictionary["n_Action"]].Controls.Add(AddControlToGridView(acceleratedVesting, "ImageButton", "img_" + e.Row.Cells[dictionary["n_ID"]].Text, "~/View/App_Themes/images/Edit.png", "imgButton", "Click here to edit record", string.Empty, false, string.Empty));
                        e.Row.Cells[dictionary["n_Action"]].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[dictionary["n_Select"]].Controls.Add(AddControlToGridView(acceleratedVesting, "CheckBox", e.Row.Cells[dictionary["n_ID"]].Text, string.Empty, "chkClassSearch", e.Row.Cells[dictionary["n_Operation_Date"]].Text, string.Empty, e.Row.Cells[dictionary["n_Select"]].Text.Equals("1"), string.Empty));
                        e.Row.Cells[dictionary["n_Select"]].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[dictionary["n_OptionDetails"]].Controls.Add(AddControlToGridView(acceleratedVesting, "LinkButton", "lbtn_" + e.Row.Cells[dictionary["n_ID"]].Text, string.Empty, "chkClass", "", "View", e.Row.Cells[dictionary["n_Select"]].Text.Equals("1"), string.Empty));
                        e.Row.Cells[dictionary["n_OptionDetails"]].HorizontalAlign = HorizontalAlign.Center;

                        switch (userSessionInfo.ACC_CalculationMethod)
                        {
                            case 1:
                                e.Row.Cells[dictionary["n_AcceleratedQty"]].HorizontalAlign = HorizontalAlign.Left;
                                e.Row.Cells[dictionary["n_AcceleratedDate"]].HorizontalAlign = HorizontalAlign.Center;
                                break;

                            case 2:
                                e.Row.Cells[dictionary["n_AcceleratedQty"]].ColumnSpan = 2;
                                e.Row.Cells[dictionary["n_AcceleratedQty"]].HorizontalAlign = e.Row.Cells[dictionary["n_AcceleratedDate"]].HorizontalAlign = HorizontalAlign.Center;
                                e.Row.Cells[dictionary["n_AcceleratedDate"]].Visible = !e.Row.Cells[dictionary["n_AcceleratedQty"]].Visible;
                                e.Row.Cells[!e.Row.Cells[dictionary["n_AcceleratedQty"]].Visible ? dictionary["n_AcceleratedDate"] : dictionary["n_AcceleratedQty"]].Controls.Add(AddControlToGridView(acceleratedVesting, "LinkButtonAV", e.Row.Cells[dictionary["n_ID"]].Text, string.Empty, "lbtnViewAccVesting", "", "View", e.Row.Cells[dictionary["n_Select"]].Text.Equals("1"), string.Empty));

                                GridView parentGrid = (GridView)sender;
                                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                                {
                                    NewTotalRow.Font.Bold = true;
                                    NewTotalRow.CssClass = "gridItems gvChildGridAV gridData";
                                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                    NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFE0CC");

                                    using (TableCell HeaderCell = new TableCell())
                                    {
                                        HeaderCell.Attributes.Add("Class", "gvChildGridAV");
                                        HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                        HeaderCell.Height = 10;
                                        HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                                        HeaderCell.ColumnSpan = 15;
                                        HeaderCell.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFECE0");

                                        using (GridView childGrid = new GridView())
                                        {
                                            childGrid.CssClass = "Grid gvChildGridDetails";
                                            childGrid.RowStyle.CssClass = "gridItems";
                                            childGrid.CellPadding = 3;
                                            childGrid.CellSpacing = 0;
                                            childGrid.HeaderStyle.CssClass = "HeaderStyle";

                                            childGrid.RowDataBound += acceleratedVesting.childGridAV_RowDataBound;
                                            childGrid.DataSource = new System.Data.DataView(ac_AcceleratedVesting.dt_AcceleratedVestingDataVestwise).ToTable("DT", true, new string[] { "OPT_GRANTED_ID", "Grant Option ID", "Vesting Date", "Vesting Period Number", "Accelerated Quantity", "Accelerated Date", "OPERATION_ID", "OPERATION DATE" }).Copy().Select("[OPT_GRANTED_ID]='" + e.Row.Cells[dictionary["n_ID"]].Text + "' AND OPERATION_ID ='" + e.Row.Cells[dictionary["n_Operation_ID"]].Text + "' AND [OPERATION DATE] = '" + e.Row.Cells[dictionary["n_Operation_Date"]].Text + "'").CopyToDataTable();
                                            childGrid.DataBind();

                                            HeaderCell.Controls.Add(childGrid);
                                            NewTotalRow.Cells.Add(HeaderCell);
                                            parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + dictionary["n_RowIndex"], NewTotalRow);
                                        }
                                    }
                                    parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + dictionary["n_RowIndex"], NewTotalRow);
                                    dictionary["n_RowIndex"]++;
                                    break;
                                }
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to check datatable is null 
        /// </summary>
        /// <returns>bool</returns>
        private bool IsNullOrEmptyDataTable()
        {
            return ac_AcceleratedVesting.dt_CustmizedViewAcceVesting == null || ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Rows.Count.Equals(0);
        }

        /// <summary>
        /// This method is used to get filtered column count
        /// </summary>
        /// <param name="s_ColumnName">string column name</param>
        /// <returns>int</returns>
        private int CheckDataTableCount(string s_ColumnName)
        {
            return ac_AcceleratedVesting.dt_CustmizedViewAcceVesting.Select("COLUMN_NAME = '" + s_ColumnName + "'").Count();
        }

        /// <summary>
        /// This method is used to bind controls to gridview
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        /// <param name="e">GridViewRowEventArgs for gvSearch</param>
        /// <param name="dictionary">Dictionary contains rows and index</param>
        /// <param name="sender">has some action perform on control</param>
        public void gvAddOrUpdate_RowDataBound(AcceleratedVesting acceleratedVesting, GridViewRowEventArgs e, ref Dictionary<string, int> dictionary, object sender)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "OPT GRANTED ID":
                                    dictionary["n_ID"] = dictionary["n_Index"];
                                    perColumn.Visible = false;
                                    break;

                                case "SELECT":
                                    dictionary["n_Select"] = dictionary["n_Index"];
                                    break;

                                case "OPTION DETAILS":
                                    dictionary["n_OptionDetails"] = dictionary["n_Index"];
                                    break;

                                case "ACCELERATED QUANTITY":
                                    dictionary["n_AcceleratedQty"] = dictionary["n_Index"];
                                    break;

                                case "ACCELERATED DATE":
                                    dictionary["n_AcceleratedDate"] = dictionary["n_Index"];
                                    e.Row.Cells[dictionary["n_AcceleratedDate"]].Controls.Add(AddControlToGridView(acceleratedVesting, "Label", perColumn.Text, string.Empty, "lbl", string.Empty, string.Empty, false, string.Empty));
                                    e.Row.Cells[dictionary["n_AcceleratedDate"]].Controls.Add(AddControlToGridView(acceleratedVesting, "CheckBoxSelectAll", "chkMain", string.Empty, "chkAcceleratedVest", string.Empty, string.Empty, false, "Apply date for all"));
                                    e.Row.Cells[dictionary["n_AcceleratedDate"]].Controls.Add(AddControlToGridView(acceleratedVesting, "TextBox", "txtMain", string.Empty, " datepickerControl txtAcceleratedDate HeaderTextBox", string.Empty, string.Empty, false, string.Empty));
                                    break;

                                case "GRANTED":
                                    dictionary["n_Granted"] = dictionary["n_Index"];
                                    perColumn.Visible = false;
                                    break;

                                case "GRANT DATE":
                                    dictionary["n_GrantDate"] = dictionary["n_Index"];
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    dictionary["n_Action"] = dictionary["n_Index"];
                                    break;
                            }
                            dictionary["n_Index"] = dictionary["n_Index"] + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[dictionary["n_ID"]].Visible = e.Row.Cells[dictionary["n_Granted"]].Visible = e.Row.Cells[dictionary["n_GrantDate"]].Visible = false;
                        e.Row.Cells[dictionary["n_Action"]].Controls.Add(AddControlToGridView(acceleratedVesting, "ImageButton", "img_" + e.Row.Cells[dictionary["n_ID"]].Text, "~/View/App_Themes/images/Edit.png", "imgButton", "Click here to edit record", string.Empty, false, string.Empty));
                        e.Row.Cells[dictionary["n_Action"]].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[dictionary["n_Select"]].Controls.Add(AddControlToGridView(acceleratedVesting, "CheckBox", "\\|" + e.Row.Cells[dictionary["n_Granted"]].Text + "\\|" + Convert.ToDateTime(e.Row.Cells[dictionary["n_GrantDate"]].Text).ToString("dd/MMM/yyy").Replace("-", "/") + "\\|" + e.Row.Cells[dictionary["n_ID"]].Text, string.Empty, "chkClassODSearch", "", string.Empty, ac_AcceleratedVesting.b_IsEdit, string.Empty));
                        e.Row.Cells[dictionary["n_Select"]].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[dictionary["n_OptionDetails"]].Controls.Add(AddControlToGridView(acceleratedVesting, "LinkButton", "lbtnAdd_" + e.Row.Cells[dictionary["n_ID"]].Text, string.Empty, "chkClass", "", "View", e.Row.Cells[dictionary["n_Select"]].Text.Equals("1"), string.Empty));
                        e.Row.Cells[dictionary["n_OptionDetails"]].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[dictionary["n_AcceleratedDate"]].Width = 200;

                        switch (userSessionInfo.ACC_CalculationMethod)
                        {
                            case 1:
                                e.Row.Cells[dictionary["n_AcceleratedQty"]].Controls.Add(AddControlToGridView(acceleratedVesting, "TextBox", e.Row.Cells[dictionary["n_ID"]].Text, string.Empty, " txtAcceleratedQty", e.Row.Cells[dictionary["n_AcceleratedQty"]].Text, "View", ac_AcceleratedVesting.b_IsEdit, string.Empty));
                                e.Row.Cells[dictionary["n_AcceleratedQty"]].HorizontalAlign = HorizontalAlign.Center;
                                e.Row.Cells[dictionary["n_AcceleratedDate"]].Controls.Add(AddControlToGridView(acceleratedVesting, "TextBox", e.Row.Cells[dictionary["n_ID"]].Text, string.Empty, " txtAcceleratedDate datepickerControl", e.Row.Cells[dictionary["n_AcceleratedDate"]].Text, "View", ac_AcceleratedVesting.b_IsEdit, string.Empty));
                                e.Row.Cells[dictionary["n_AcceleratedDate"]].HorizontalAlign = HorizontalAlign.Center;
                                break;

                            case 2:
                                GridView parentGrid = (GridView)sender;
                                using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                                {
                                    NewTotalRow.Font.Bold = true;
                                    NewTotalRow.CssClass = "gridItems gvChildGrid gridData";
                                    NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                    NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFE0CC");

                                    using (TableCell HeaderCell = new TableCell())
                                    {
                                        HeaderCell.Attributes.Add("Class", "gvChildGrid");
                                        HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                                        HeaderCell.Height = 10;
                                        HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                                        HeaderCell.ColumnSpan = 15;
                                        HeaderCell.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFECE0");

                                        using (GridView childGrid = new GridView())
                                        {
                                            childGrid.CssClass = "Grid gvChildGridDetails";
                                            childGrid.RowStyle.CssClass = "gridItems";
                                            childGrid.CellPadding = 3;
                                            childGrid.CellSpacing = 0;
                                            childGrid.HeaderStyle.CssClass = "HeaderStyle";

                                            childGrid.RowDataBound += acceleratedVesting.childGrid_RowDataBound;
                                            childGrid.DataSource = new System.Data.DataView(ac_AcceleratedVesting.dt_ODAcceleratedVestingVestWise).ToTable("DT", true, new string[] { "OPT_VEST_ID", "OPT GRANTED ID", "Grant Option ID", "Vesting Date", "Vesting Period Number", "Granted", "Accelerated Quantity", "Accelerated Date" }).Copy().Select("[OPT GRANTED ID]='" + e.Row.Cells[dictionary["n_ID"]].Text + "'").CopyToDataTable();
                                            childGrid.DataBind();

                                            HeaderCell.Controls.Add(childGrid);
                                            NewTotalRow.Cells.Add(HeaderCell);
                                            parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + dictionary["n_RowIndex"], NewTotalRow);
                                        }
                                    }
                                    parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + dictionary["n_RowIndex"], NewTotalRow);
                                    dictionary["n_RowIndex"]++;
                                    break;
                                }
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Row Data Bound Event Of Child GridView
        /// </summary>
        /// <param name="sender">Child GridView</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="acceleratedVesting">AcceleratedVesting object</param>
        internal void childGrid_RowDataBound(object sender, GridViewRowEventArgs e, AcceleratedVesting acceleratedVesting)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        e.Row.Cells[0].Visible = false;
                        e.Row.Cells[1].Visible = false;
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[0].Visible = e.Row.Cells[1].Visible = false;
                        e.Row.Cells[6].Controls.Add(AddControlToGridView(acceleratedVesting, "TextBox", e.Row.Cells[4].Text + "\\|" + e.Row.Cells[0].Text + "\\|" + e.Row.Cells[1].Text, string.Empty, " txtAcceleratedQtyVestWise", e.Row.Cells[6].Text, "View", ac_AcceleratedVesting.b_IsEdit, string.Empty));
                        e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[7].Controls.Add(AddControlToGridView(acceleratedVesting, "TextBox", e.Row.Cells[4].Text + "\\|" + e.Row.Cells[0].Text + "\\|" + e.Row.Cells[1].Text, string.Empty, " txtAcceleratedDateVestWise datepickerControl", e.Row.Cells[7].Text, "View", ac_AcceleratedVesting.b_IsEdit, string.Empty));
                        e.Row.Cells[7].Width = 200;
                        e.Row.Cells[7].HorizontalAlign = HorizontalAlign.Center;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Row Data Bound Event Of Child GridView
        /// </summary>
        /// <param name="sender">Child GridView</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="acceleratedVesting">AcceleratedVesting object</param>
        internal void childGridAV_RowDataBound(object sender, GridViewRowEventArgs e, AcceleratedVesting acceleratedVesting)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        e.Row.Cells[0].Visible = e.Row.Cells[6].Visible = e.Row.Cells[7].Visible = false;
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[0].Visible = e.Row.Cells[6].Visible = e.Row.Cells[7].Visible = false;
                        e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
                        e.Row.Cells[5].Width = 200;
                        e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Center;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// This method is used add controls in GridView
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        /// <param name="s_ControlName">Name of the control which added in GridView</param>
        /// <param name="s_ControlID">Control ID</param>
        /// <param name="s_ImagePath">Image path of the control</param>
        /// <param name="s_CssClass">Css class to be applied</param>
        /// <param name="s_Tooltip">Tooltip for the control</param>
        /// <param name="s_ControlText">Text for the control</param>
        /// <param name="IsDeletedOrEdit">Is Delete checkbox checked or not</param>
        /// <param name="s_CheckBoxText">CheckBox Text</param>
        /// <returns>Control</returns>
        private Control AddControlToGridView(AcceleratedVesting acceleratedVesting, string s_ControlName, string s_ControlID, string s_ImagePath, string s_CssClass, string s_Tooltip, string s_ControlText, bool IsDeletedOrEdit, string s_CheckBoxText)
        {
            switch (s_ControlName)
            {
                case "ImageButton":
                    ImageButton imgButton = new ImageButton();
                    imgButton.ToolTip = s_Tooltip;
                    imgButton.ID = s_ControlID;
                    imgButton.ImageUrl = s_ImagePath;
                    imgButton.ClientIDMode = ClientIDMode.Static;
                    imgButton.Click += acceleratedVesting.imgButton_Click;
                    imgButton.Attributes.Add("Onclick", "javascript : return EditRecord('" + s_ControlID + "', this, '" + userSessionInfo.ACC_CalculationMethod + "');");
                    return imgButton;

                case "CheckBoxSelectAll":
                    using (CheckBox checkBox = new CheckBox())
                    {
                        checkBox.ID = "chk";
                        checkBox.InputAttributes.Add("Value", "0");
                        checkBox.Checked = false;
                        checkBox.InputAttributes["class"] = s_CssClass;
                        checkBox.Text = s_CheckBoxText;
                        checkBox.ClientIDMode = ClientIDMode.Static;
                        checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this, '" + userSessionInfo.ACC_CalculationMethod + "');");
                        return checkBox;
                    }

                case "CheckBox":
                    using (CheckBox checkBox = new CheckBox())
                    {
                        //s_Tooltip contains OperationDate
                        checkBox.InputAttributes.Add("Value", s_ControlID + "\\|" + s_Tooltip);
                        checkBox.ID = "chk";
                        checkBox.Checked = IsDeletedOrEdit;
                        checkBox.InputAttributes["class"] = s_CssClass;
                        checkBox.Attributes.Add("name", "Types");
                        //s_Tooltip contains OperationDate
                        checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_ControlID + "', this, '" + userSessionInfo.ACC_CalculationMethod + "', '" + s_Tooltip + "')");
                        return checkBox;
                    }

                case "LinkButton":
                    using (LinkButton linkButton = new LinkButton())
                    {
                        linkButton.ID = s_ControlID;
                        linkButton.Text = s_ControlText;
                        linkButton.Attributes.Add("onclick", "return ShowOptionDetailsData('" + s_ControlID + "', this)");
                        return linkButton;
                    }

                case "LinkButtonAV":
                    using (LinkButton linkButton = new LinkButton())
                    {
                        linkButton.ID = s_ControlID;
                        linkButton.CssClass = s_CssClass;
                        linkButton.Text = s_ControlText;
                        return linkButton;
                    }

                case "TextBox":
                    using (TextBox textBox = new TextBox())
                    {
                        int Is_Selected = IsDeletedOrEdit ? 1 : 0;
                        textBox.ID = (s_CssClass.Equals(" txtAcceleratedQty") || s_CssClass.Equals(" txtAcceleratedQtyVestWise")) ? "\\|txtQty\\|" + s_ControlID + "\\|" + Is_Selected + "" : "\\|txtDate\\|" + s_ControlID + "\\|" + Is_Selected + "";
                        textBox.CssClass = "cTextBox" + s_CssClass;
                        textBox.Width = 100;
                        textBox.Text = IsDeletedOrEdit ? s_Tooltip.Equals("&nbsp;") ? string.Empty : s_Tooltip : string.Empty;
                        textBox.Enabled = IsDeletedOrEdit;
                        return textBox;
                    }

                case "Label":
                    using (Label label = new Label())
                    {
                        label.Text = s_ControlID + "<br/>";
                        return label;
                    }

            }
            return new Control();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <param name="gv"></param>
        /// <param name="s_CurrencyID"></param>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_CurrencyID)
        {
            try
            {
                string[] s_CurrencyIDs = s_CurrencyID.TrimStart(',').Split(',');

                ac_ManageCurrency.dt_Currencies.Columns["Delete"].Expression = string.Empty;
                ac_ManageCurrency.dt_Currencies.AcceptChanges();

                foreach (string perID in s_CurrencyIDs)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_ManageCurrency.dt_Currencies.Select("ID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_ManageCurrency.dt_Currencies;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to handle Page index change event
        /// </summary>
        /// <param name="acceleratedVesting">acceleratedVesting model</param>
        /// <param name="e">event args object</param>
        /// <param name="dictionary">dictionary</param>
        /// <param name="sender">sender's object</param>
        internal void gvAddOrUpdate_PageIndexChanging(AcceleratedVesting acceleratedVesting, GridViewPageEventArgs e, ref Dictionary<string, int> dictionary, object sender)
        {
            acceleratedVesting.gvAddOrUpdate.PageIndex = e.NewPageIndex;
            SearchSectionOptionDetail(acceleratedVesting);
        }
        #endregion

        #region Create columns and blank rows for datatable(used to pass as a Type to SP)
        /// <summary>
        /// This method is used to create columns for dt_SaveAcceleratedVesting datatable
        /// </summary>
        internal void CreateDatatbleColumnsGratwise()
        {
            if (!ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Count.Equals(30))
            {
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("OPT_GRANTED_ID", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("AGRMID", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("GRANT_OPTION_ID", typeof(string));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("EMPID", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("VPD_VESTING_PERIOD_ID", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("GRANTED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("CANCELLED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("VESTED_CANCELLED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("UNVESTED_CANCELLED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("LAPSED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("EXERCISED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("UNVESTED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("VESTED_AND_EXERCISABLE", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("OUTSTANDING_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("FORFEITURE_RATE", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("COST_AS_PER_SYSTEM_BY_IV", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("COST_AS_PER_SYSTEM_BY_FV", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("H_COST_MANUALLY", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("IS_MU_FV", typeof(bool));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("IS_MU_IV", typeof(bool));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("REVERSAL_DATE", typeof(DateTime));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("REVERSAL_COST", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("ADJUSTMENT_ENTRY", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("VALUATION_METHOD", typeof(string));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("IS_ACCELERATED_VESTING", typeof(bool));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("ACCELERATED_QUANTITY", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("ACCELERATED_DATE", typeof(DateTime));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("INTRINSIC_VALUE", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("FAIR_VALUE", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVesting.Columns.Add("EXERCISE_PRICE", typeof(decimal));
            }
        }

        /// <summary>
        /// This method is used to create columns for dt_SaveAcceleratedVesting - Vestwise datatable
        /// </summary>
        internal void CreateDatatbleColumnsVestwise()
        {
            if (!ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Count.Equals(32))
            {
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("OPT_VEST_ID", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("OPT_GRANTED_ID", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("AGRMID", typeof(string));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("GRANT_OPTION_ID", typeof(string));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("EMPID", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("VPD_VESTING_PERIOD_ID", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("VPD_VESTING_DATE", typeof(DateTime));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("VPD_EXPIRY_DATE", typeof(DateTime));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("GRANTED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("CANCELLED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("VESTED_CANCELLED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("UNVESTED_CANCELLED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("LAPSED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("EXERCISED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("UNVESTED_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("VESTED_AND_EXERCISABLE", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("OUTSTANDING_OPTIONS", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("FORFEITURE_RATE", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("COST_AS_PER_SYSTEM_BY_IV", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("COST_AS_PER_SYSTEM_BY_FV", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("H_COST_MANUALLY", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("IS_MU_FV", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("IS_MU_IV", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("REVERSAL_DATE", typeof(DateTime));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("REVERSAL_COST", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("ADJUSTMENT_ENTRY", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("IS_ACCELERATED_VESTING", typeof(bool));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("ACCELERATED_QUANTITY", typeof(int));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("ACCELERATED_DATE", typeof(DateTime));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("INTRINSIC_VALUE", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("FAIR_VALUE", typeof(decimal));
                ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Columns.Add("EXERCISE_PRICE", typeof(decimal));
            }
        }

        /// <summary>
        /// Create Blank Datatble for Vestwise
        /// </summary>
        /// <returns>DataTable</returns>
        internal DataTable CreateBlankDatatbleVestwise()
        {
            DataRow drVestwise = ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.NewRow();
            ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise.Rows.Add(drVestwise);
            return ac_AcceleratedVesting.dt_SaveAcceleratedVestingVestWise;
        }

        /// <summary>
        /// This method is used to get customize view details
        /// </summary>
        /// <param name="acceleratedVesting">object of AcceleratedVesting page</param>
        internal void GetCustomizeViewData(AcceleratedVesting acceleratedVesting)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                genericProperties.PageName = CommonConstantModel.s_MnuAcceleratedVesting;
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                genericProperties.CustomizeView_ID = Convert.ToString(acceleratedVesting.ddlDefaultView.SelectedValue);
                ac_AcceleratedVesting.dt_CustmizedViewAcceVesting = (DataTable)genericServiceClient.GetCustomizedViewTable(genericProperties);
            }
        }

        /// <summary>
        /// This method is used to load the selected view for login user.
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        internal void LoadSelcted_View(AcceleratedVesting acceleratedVesting)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.PageName = CommonConstantModel.s_MnuAcceleratedVesting;
                    genericProperties.CustomizeView_ID = Convert.ToString(acceleratedVesting.ddlDefaultView.SelectedValue);
                    genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_AcceleratedVesting.dt_CustmizedViewAcceVesting = (DataTable)genericServiceClient.GetCustomizedViewTable(genericProperties);
                }
                BindGridView(acceleratedVesting);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// This method is used to load the selected view for login user.
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        internal void SetDefaultView(AcceleratedVesting acceleratedVesting)
        {
            try
            {
                using (AccountingServiceClient accountingServiceClient = new AccountingServiceClient())
                {
                    accountingProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    accountingProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    accountingProperties.PageName = CommonConstantModel.s_AcceleratedVesting;
                    accountingProperties.Operation = "SETDEFAULTVIEW";
                    accountingProperties.s_CustomizeViewPageName = CommonConstantModel.s_MnuAcceleratedVesting;
                    accountingProperties.s_ViewID = Convert.ToString(acceleratedVesting.ddlDefaultView.SelectedValue);
                    accountingProperties.IsDefault = true;

                    AccountingCRUDProperties accountingCRUDProperties = new AccountingCRUDProperties();
                    accountingCRUDProperties = accountingServiceClient.CRUDAccountingOperations(accountingProperties);

                    switch (accountingCRUDProperties.a_result)
                    {
                        case 0:
                            acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            acceleratedVesting.ctrSuccessErrorMessage.lblMessage.Text = accountingServiceClient.GetAccounting_L10N("lblAVError", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                            acceleratedVesting.ctrSuccessErrorMessage.lblMessage.ForeColor = Color.Red;
                            break;

                        case 1:

                            acceleratedVesting.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            acceleratedVesting.ctrSuccessErrorMessage.lblMessage.Text = accountingServiceClient.GetAccounting_L10N("lblAVUpdated", CommonConstantModel.s_AcceleratedVesting, CommonConstantModel.s_AccountingL10);
                            acceleratedVesting.ctrSuccessErrorMessage.lblMessage.ForeColor = Color.Blue;
                            break;
                    }
                }

                BindGridView(acceleratedVesting);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// This method is used to load the default view for login user.
        /// </summary>
        /// <param name="acceleratedVesting">AcceleratedVesting page object</param>
        internal void LoadDefault_ViewDropDowns(AcceleratedVesting acceleratedVesting)
        {
            try
            {

                using (DataTable dtDefaultView = CommonModel.GetDefaultViewList(userSessionInfo, CommonConstantModel.s_Get_Default_View, CommonConstantModel.s_MnuAcceleratedVesting))
                {
                    acceleratedVesting.ddlDefaultView.DataSource = dtDefaultView;
                    acceleratedVesting.ddlDefaultView.DataTextField = "VIEW_NAME";
                    acceleratedVesting.ddlDefaultView.DataValueField = "ID";
                    acceleratedVesting.ddlDefaultView.DataBind();
                    acceleratedVesting.ddlDefaultView.Items.Insert(0, new ListItem("--- Please Select ---", "0"));

                    if (dtDefaultView.Rows.Count > 0)
                    {
                        if (acceleratedVesting.ddlDefaultView.Items.Count > 0)
                        {
                            DataRow[] drr = dtDefaultView.Select("ISDEFAULT_VIEW=1");

                            if (drr.Length > 0)
                            {
                                acceleratedVesting.ddlDefaultView.SelectedValue = Convert.ToString(drr[0]["ID"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~AcceleratedVestingModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}