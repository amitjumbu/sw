﻿using EDFinancials.Model.Generic;
using EDFinancials.UserControl.User.Valuation;
using EDFinancials.View.Valuation;
using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Market Price user control Model
    /// </summary>
    public class MarketPriceUCModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public MarketPriceUCModel()
        {
            if (ac_ValuationParameter == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationParameter);
                ac_ValuationParameter = (CommonModel.AC_ValuationParameter)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationParameter];
            }
        }

        #region Market Price

        /// <summary>
        /// This method is used to bind all the dropdowns
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        public void BindDropDowns(ValuationParameters valuationParametersSetup)
        {
            try
            {
                if (ac_ValuationParameter.ds_ValuationParameters.Tables[14].Rows.Count > 0)
                {
                    using (DataTable dt_SEDetails = ac_ValuationParameter.ds_ValuationParameters.Tables[14])
                    {
                        valuationParametersSetup.ctrMarketPrice.ddlIVStockExchange.DataSource = dt_SEDetails;
                        valuationParametersSetup.ctrMarketPrice.ddlIVStockExchange.DataTextField = "Short Name";
                        valuationParametersSetup.ctrMarketPrice.ddlIVStockExchange.DataValueField = "SEID";
                        valuationParametersSetup.ctrMarketPrice.ddlIVStockExchange.DataBind();
                        using (VPSCommonModel vPSCommonModel = new VPSCommonModel())
                        {
                            vPSCommonModel.BindToolTip(valuationParametersSetup.ctrMarketPrice.ddlIVStockExchange);
                        }
                        if (valuationParametersSetup.ctrMarketPrice.ddlIVStockExchange.Items.FindByText("NSE") != null)
                            valuationParametersSetup.ctrMarketPrice.ddlIVStockExchange.Items.FindByText("NSE").Selected = true;

                        valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.DataSource = dt_SEDetails;
                        valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.DataTextField = "Short Name";
                        valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.DataValueField = "SEID";
                        valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.DataBind();
                        using (VPSCommonModel vPSCommonModel = new VPSCommonModel())
                        {
                            vPSCommonModel.BindToolTip(valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange);
                        }
                        if (valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.Items.FindByText("NSE") != null)
                            valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.Items.FindByText("NSE").Selected = true;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all the 'Market Price' tab controls on page load
        /// </summary>
        /// <param name="ds_ValuationParameters">DataSet object</param>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        /// <param name="s_GrantDate"></param>
        /// <param name="s_GrantID"></param>
        public void BindMarketPriceControls(DataSet ds_ValuationParameters, ValuationParameters valuationParametersSetup, string s_GrantDate, string s_GrantID)
        {
            try
            {
                /* Set IV Controls */
                ac_ValuationParameter.dt_MarketPriceIV = ac_ValuationParameter.ds_ValuationParameters.Tables[1];
                valuationParametersSetup.ctrMarketPrice.gvMarketPriceIV.DataSource = ac_ValuationParameter.dt_MarketPriceIV;
                valuationParametersSetup.ctrMarketPrice.gvMarketPriceIV.DataBind();
                BindIVControls(valuationParametersSetup);

                /* Set FV Controls */
                ac_ValuationParameter.dt_MarketPriceFV = ac_ValuationParameter.ds_ValuationParameters.Tables[3];
                valuationParametersSetup.ctrMarketPrice.gvMarketPriceFV.DataSource = ac_ValuationParameter.dt_MarketPriceFV;
                valuationParametersSetup.ctrMarketPrice.gvMarketPriceFV.DataBind();
                BindFVControls(valuationParametersSetup, s_GrantDate, s_GrantID);
                SetApprovalHiddenField(valuationParametersSetup);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to set hidden field to check approval status
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        public void SetApprovalHiddenField(ValuationParameters valuationParametersSetup)
        {
            try
            {
                bool s_IsApprovedIV = (from query in ac_ValuationParameter.dt_MarketPriceIV.AsEnumerable()
                                       where query.Field<string>("Approval Status") == "Pending"
                                       select query.Field<string>("Approval Status")).Distinct().Count() > 0 ? false : true;
                valuationParametersSetup.ctrMarketPrice.hdnVPS_IsApproved_IV.Value = s_IsApprovedIV ? "1" : "0";
                bool s_IsApprovedFV = (from query in ac_ValuationParameter.dt_MarketPriceFV.AsEnumerable()
                                       where query.Field<string>("Approval Status") == "Pending"
                                       select query.Field<string>("Approval Status")).Distinct().Count() > 0 ? false : true;
                valuationParametersSetup.ctrMarketPrice.hdnVPS_IsApproved_FV.Value = s_IsApprovedFV ? "1" : "0";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind FV controls
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup control object</param>
        /// <param name="s_GrantDate"></param>
        /// <param name="s_GranID"></param>
        public void BindFVControls(ValuationParameters valuationParametersSetup, string s_GrantDate, string s_GranID)
        {
            try
            {
                #region This is used to bind controls at time of redirect from Valuation Report page
                if (!string.IsNullOrEmpty(s_GrantDate))
                {
                    foreach (DataRow perRow in ac_ValuationParameter.ds_ValuationParameters.Tables[3].Select("[To Date] IS NULL"))
                    {
                        perRow["To Date"] = DateTime.Now.Date;
                    }
                }
                #endregion

                DataRow[] dr_GrantLevelSettings = null;
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    if (!string.IsNullOrEmpty(s_GrantDate))
                    {
                        valuationProperties.PageName = CommonConstantModel.s_ValuationParameters;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        dr_GrantLevelSettings = valuationCRUDProperties.ds_Result.Tables[3].Select("GRANT_GRANT_REG_ID_FV = '" + s_GranID + "'");
                    }
                }

                using (DataTable dt_ValuationParameters = string.IsNullOrEmpty(s_GrantDate) ? ac_ValuationParameter.ds_ValuationParameters.Tables[2] : (dr_GrantLevelSettings != null && dr_GrantLevelSettings.Count() > 0) ? dr_GrantLevelSettings.CopyToDataTable() : ac_ValuationParameter.ds_ValuationParameters.Tables[3].Select("[Applicable From Date] <= #" + Convert.ToDateTime(s_GrantDate).Date + "# AND [To Date] >= #" + Convert.ToDateTime(s_GrantDate).Date + "#").CopyToDataTable())
                {
                    #region This is used to bind controls at time of redirect from Valuation Report page
                    if (!string.IsNullOrEmpty(s_GrantDate) && dr_GrantLevelSettings.Count().Equals(0))
                    {
                        dt_ValuationParameters.Columns["Stock Exchange"].ColumnName = "STOCK_EX_LABEL_ID";
                        dt_ValuationParameters.Columns["Date of Market Price"].ColumnName = "MARKET_PRICE_DT_LABEL_ID";
                        dt_ValuationParameters.Columns["Remark"].ColumnName = "REMARK";
                        dt_ValuationParameters.Columns["Applicable From Date"].ColumnName = "APPLICABLE_FROM_DATE";
                    }
                    else if (dr_GrantLevelSettings != null && dr_GrantLevelSettings.Count() > 0)
                    {
                        dt_ValuationParameters.Columns["GRANT_STOCK_EX_LABEL_ID_FV"].ColumnName = "STOCK_EX_LABEL_ID";
                        dt_ValuationParameters.Columns["GRANT_MARKET_PRICE_LABEL_ID_FV"].ColumnName = "MARKET_PRICE_DT_LABEL_ID";
                    }
                    #endregion

                    ac_ValuationParameter.b_IsListed = userSessionInfo.ACC_IsListed.Equals(1) ? true : false;
                    if (ac_ValuationParameter.b_IsListed)
                    {
                        valuationParametersSetup.ctrMarketPrice.lblFVDMP02.Style.Add("display", "");
                        valuationParametersSetup.ctrMarketPrice.trVPSStockExchangeFV.Style.Add("display", "");
                    }
                    else
                    {
                        valuationParametersSetup.ctrMarketPrice.lblFVDMP02.Style.Add("display", "none");
                        valuationParametersSetup.ctrMarketPrice.trVPSStockExchangeFV.Style.Add("display", "none");
                    }
                    if (dt_ValuationParameters.Rows.Count > 0)
                    {
                        if (Convert.ToString(dt_ValuationParameters.Rows[0]["STOCK_EX_LABEL_ID"]).Trim().Equals("lblFVSE01"))
                        {
                            valuationParametersSetup.ctrMarketPrice.lblFVSE01.Checked = true;

                            if (string.IsNullOrEmpty(s_GrantDate))
                            {
                                if (valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.Items.FindByValue(Convert.ToString(dt_ValuationParameters.Rows[0]["SEID"]).Trim()) != null)
                                {
                                    valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.ClearSelection();
                                    valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.Items.FindByValue(Convert.ToString(dt_ValuationParameters.Rows[0]["SEID"]).Trim()).Selected = true;
                                }
                            }
                            else if (dr_GrantLevelSettings != null && dr_GrantLevelSettings.Count() > 0)
                            {
                                if (valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.Items.FindByText(Convert.ToString(dt_ValuationParameters.Rows[0]["GRANT_STOCK_EXCHANGE_FV"]).Trim()) != null)
                                {
                                    valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.ClearSelection();
                                    valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.Items.FindByText(Convert.ToString(dt_ValuationParameters.Rows[0]["GRANT_STOCK_EXCHANGE_FV"]).Trim()).Selected = true;
                                }
                            }
                            else
                            {
                                if (valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.Items.FindByText(Convert.ToString(dt_ValuationParameters.Rows[0]["SHORT_NAME"]).Trim()) != null)
                                {
                                    valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.ClearSelection();
                                    valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.Items.FindByText(Convert.ToString(dt_ValuationParameters.Rows[0]["SHORT_NAME"]).Trim()).Selected = true;
                                }
                            }
                        }
                        else
                            valuationParametersSetup.ctrMarketPrice.lblFVSE02.Checked = true;

                        if (Convert.ToString(dt_ValuationParameters.Rows[0]["MARKET_PRICE_DT_LABEL_ID"]).Trim().Equals("lblFVDMP01"))
                            valuationParametersSetup.ctrMarketPrice.lblFVDMP01.Checked = true;
                        else
                        {
                            if (ac_ValuationParameter.b_IsListed)
                                valuationParametersSetup.ctrMarketPrice.lblFVDMP02.Checked = true;
                        }

                        if (string.IsNullOrEmpty(s_GrantDate))
                        {
                            valuationParametersSetup.ctrMarketPrice.txtFVRemark.Text = Convert.ToString(dt_ValuationParameters.Rows[0]["REMARK"]).Trim();
                            valuationParametersSetup.ctrMarketPrice.hdnVPSAppFromDate_FV.Value = valuationParametersSetup.ctrMarketPrice.txtFVApplFromDate.Text = !string.IsNullOrEmpty(Convert.ToString(dt_ValuationParameters.Rows[0]["APPLICABLE_FROM_DATE"])) ? Convert.ToDateTime(dt_ValuationParameters.Rows[0]["APPLICABLE_FROM_DATE"]).ToString("dd/MMM/yyyy") : string.Empty; 
                        }
                        using (ValuationModel valuationModel = new ValuationModel())
                        {
                            valuationModel.SetButtonText(valuationParametersSetup.ctrMarketPrice.btnVPSSaveFV);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind IV controls
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup control object</param>
        public void BindIVControls(ValuationParameters valuationParametersSetup)
        {
            try
            {
                ac_ValuationParameter.b_IsListed = userSessionInfo.ACC_IsListed.Equals(1) ? true : false;
                if (ac_ValuationParameter.b_IsListed)
                {
                    valuationParametersSetup.ctrMarketPrice.lblIVDMP02.Style.Add("display", "");
                    valuationParametersSetup.ctrMarketPrice.trVPSStockExchangeIV.Style.Add("display", "");
                }
                else
                {
                    valuationParametersSetup.ctrMarketPrice.lblIVDMP02.Style.Add("display", "none");
                    valuationParametersSetup.ctrMarketPrice.trVPSStockExchangeIV.Style.Add("display", "none");
                }
                if (ac_ValuationParameter.ds_ValuationParameters.Tables[0].Rows.Count > 0)
                {
                    if (Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[0].Rows[0]["STOCK_EX_LABEL_ID"]).Trim().Equals("lblIVSE01"))
                    {
                        valuationParametersSetup.ctrMarketPrice.lblIVSE01.Checked = true;

                        if (valuationParametersSetup.ctrMarketPrice.ddlIVStockExchange.Items.FindByValue(Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[0].Rows[0]["SEID"]).Trim()) != null)
                        {
                            valuationParametersSetup.ctrMarketPrice.ddlIVStockExchange.ClearSelection();
                            valuationParametersSetup.ctrMarketPrice.ddlIVStockExchange.Items.FindByValue(Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[0].Rows[0]["SEID"]).Trim()).Selected = true;
                        }
                    }
                    else
                        valuationParametersSetup.ctrMarketPrice.lblIVSE02.Checked = true;

                    if (Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[0].Rows[0]["MARKET_PRICE_DT_LABEL_ID"]).Trim().Equals("lblIVDMP01"))
                        valuationParametersSetup.ctrMarketPrice.lblIVDMP01.Checked = true;
                    else
                    {
                        if (ac_ValuationParameter.b_IsListed)
                            valuationParametersSetup.ctrMarketPrice.lblIVDMP02.Checked = true;
                    }
                    valuationParametersSetup.ctrMarketPrice.txtIVRemark.Text = Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[0].Rows[0]["REMARK"]).Trim();

                    valuationParametersSetup.ctrMarketPrice.hdnVPSAppFromDate_IV.Value = valuationParametersSetup.ctrMarketPrice.txtIVApplFromDate.Text = !string.IsNullOrEmpty(Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[0].Rows[0]["APPLICABLE_FROM_DATE"])) ? Convert.ToDateTime(ac_ValuationParameter.ds_ValuationParameters.Tables[0].Rows[0]["APPLICABLE_FROM_DATE"]).ToString("dd/MMM/yyyy") : string.Empty;
                    using (ValuationModel valuationModel = new ValuationModel())
                    {
                        valuationModel.SetButtonText(valuationParametersSetup.ctrMarketPrice.btnVPSSaveIV);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to update 'Market Price' config data
        /// </summary>
        /// <param name="marketPriceUC">MarketPriceUC control object</param>
        /// <param name="s_Type">CUD action type</param>
        /// <returns>returns 1 for insert, 2 for update and 3 for delete operation</returns>
        public int UpdateMarketPriceConfigData(MarketPriceUC marketPriceUC, string s_Type)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    int n_RetValue = 0;
                    valuationProperties = new ValuationProperties();
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                    valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    if (userSessionInfo.ACC_UerTypeID.Equals(5))
                        valuationProperties.MPC_IS_APPROVED = true;
                    else valuationProperties.MPC_IS_APPROVED = false;

                    switch (s_Type)
                    {
                        case "MPC_IV":
                            valuationProperties.PopulateControls = "MPC";
                            valuationProperties.MPC_MARKET_PRICE_TYPE = "IV";

                            if (userSessionInfo.ACC_IsListed.Equals(1))
                            {
                                if (marketPriceUC.lblIVSE01.Checked)
                                {
                                    valuationProperties.MPC_STOCK_EX_LABEL_ID = marketPriceUC.lblIVSE01.ID;
                                    valuationProperties.MPC_SEID = Convert.ToInt32(marketPriceUC.ddlIVStockExchange.SelectedItem.Value);
                                }
                                else
                                    valuationProperties.MPC_STOCK_EX_LABEL_ID = marketPriceUC.lblIVSE02.ID;
                            }

                            if (marketPriceUC.lblIVDMP01.Checked)
                                valuationProperties.MPC_MARKET_PRICE_DT_LABEL_ID = marketPriceUC.lblIVDMP01.ID;
                            else
                                valuationProperties.MPC_MARKET_PRICE_DT_LABEL_ID = marketPriceUC.lblIVDMP02.ID;

                            valuationProperties.MPC_REMARK = marketPriceUC.txtIVRemark.Text;

                            valuationProperties.MPC_APPLICABLE_FROM_DATE = marketPriceUC.txtIVApplFromDate.Text;
                            valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                            n_RetValue = valuationCRUDProperties.a_result;

                            if (n_RetValue.Equals(1))
                            {
                                ParamChange(marketPriceUC);
                                
								using (ValuationModel valuationModel = new ValuationModel())
                                {
                                    valuationModel.SetButtonText(marketPriceUC.btnVPSSaveIV);
                                }
                                marketPriceUC.hdnVPSAppFromDate_IV.Value = marketPriceUC.txtIVApplFromDate.Text;
                            }
                            break;

                        case "MPC_FV":
                            valuationProperties.PopulateControls = "MPC";
                            valuationProperties.MPC_MARKET_PRICE_TYPE = "FV";

                            if (userSessionInfo.ACC_IsListed.Equals(1))
                            {
                                if (marketPriceUC.lblFVSE01.Checked)
                                {
                                    valuationProperties.MPC_STOCK_EX_LABEL_ID = marketPriceUC.lblFVSE01.ID;
                                    valuationProperties.MPC_SEID = Convert.ToInt32(marketPriceUC.ddlFVStockExchange.SelectedItem.Value);
                                }
                                else
                                    valuationProperties.MPC_STOCK_EX_LABEL_ID = marketPriceUC.lblFVSE02.ID;
                            }
                            if (marketPriceUC.lblFVDMP01.Checked)
                                valuationProperties.MPC_MARKET_PRICE_DT_LABEL_ID = marketPriceUC.lblFVDMP01.ID;
                            else
                                valuationProperties.MPC_MARKET_PRICE_DT_LABEL_ID = marketPriceUC.lblFVDMP02.ID;

                            valuationProperties.MPC_REMARK = marketPriceUC.txtFVRemark.Text;

                            valuationProperties.MPC_APPLICABLE_FROM_DATE = marketPriceUC.txtFVApplFromDate.Text;
                            valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                            n_RetValue = valuationCRUDProperties.a_result;

                            if (n_RetValue.Equals(1))
                            {                                
                                using (ValuationModel valuationModel = new ValuationModel())
                                {
                                    valuationModel.SetButtonText(marketPriceUC.btnVPSSaveFV);
                                }
                                marketPriceUC.hdnVPSAppFromDate_FV.Value = marketPriceUC.txtFVApplFromDate.Text;
                            }
                            break;

                        default:
                            break;
                    }
                    return n_RetValue;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid-view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="n_Index_IV">n_Index_IV</param>
        /// <param name="n_Stock_Exchange_IV">n_Stock_Exchange_IV</param>
        /// <param name="n_SHORT_NAME_IV">n_SHORT_NAME_IV</param>
        /// <param name="n_Date_of_Market_Price_IV">n_Date_of_Market_Price_IV</param>
        /// <param name="n_Remark_IV">n_Remark_IV</param>
        /// <param name="n_Applicable_From_Date_IV">n_Applicable_From_Date_IV</param>
        /// <param name="n_To_Date_IV">n_To_Date_IV</param>
        /// <param name="n_AMPCID_IV">n_AMPCID_IV</param>
        /// <param name="n_Approval_Status_IV">n_Approval_Status_IV</param>
        /// <param name="n_View_History_Data_IV">n_View_History_Data_IV</param>
        public void RowDataBindForGVMPIV(GridViewRowEventArgs e, ref int n_Index_IV, ref int n_Stock_Exchange_IV, ref int n_SHORT_NAME_IV, ref int n_Date_of_Market_Price_IV, ref int n_Remark_IV,
                        ref int n_Applicable_From_Date_IV, ref int n_To_Date_IV, ref int n_AMPCID_IV, ref int n_Approval_Status_IV, ref int n_View_History_Data_IV)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "STOCK EXCHANGE":
                                    n_Stock_Exchange_IV = n_Index_IV;
                                    break;
                                case "SHORT_NAME":
                                    n_SHORT_NAME_IV = n_Index_IV;
                                    perColumn.Visible = false;
                                    break;
                                case "DATE OF MARKET PRICE":
                                    n_Date_of_Market_Price_IV = n_Index_IV;
                                    break;
                                case "REMARK":
                                    n_Remark_IV = n_Index_IV;
                                    break;
                                case "APPLICABLE FROM DATE":
                                    n_Applicable_From_Date_IV = n_Index_IV;
                                    break;
                                case "TO DATE":
                                    n_To_Date_IV = n_Index_IV;
                                    break;
                                case "AMPCID":
                                    n_AMPCID_IV = n_Index_IV;
                                    perColumn.Visible = false;
                                    break;
                                case "APPROVAL STATUS":
                                    n_Approval_Status_IV = n_Index_IV;
                                    break;
                                case "VIEW HISTORY DATA":
                                    n_View_History_Data_IV = n_Index_IV;
                                    break;
                            }
                            n_Index_IV++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_SHORT_NAME_IV].Visible = e.Row.Cells[n_AMPCID_IV].Visible = false;
                        e.Row.Cells[n_Applicable_From_Date_IV].HorizontalAlign = e.Row.Cells[n_To_Date_IV].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Applicable_From_Date_IV].Text) && !e.Row.Cells[n_Applicable_From_Date_IV].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_Applicable_From_Date_IV].Text = Convert.ToDateTime(e.Row.Cells[n_Applicable_From_Date_IV].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_To_Date_IV].Text) && !e.Row.Cells[n_To_Date_IV].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_To_Date_IV].Text = Convert.ToDateTime(e.Row.Cells[n_To_Date_IV].Text).ToString("dd/MMM/yyyy");

                        e.Row.Cells[n_Remark_IV].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;");

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Stock_Exchange_IV].Text) && !e.Row.Cells[n_Stock_Exchange_IV].Text.Equals("&nbsp;"))
                        {
                            if (e.Row.Cells[n_Stock_Exchange_IV].Text.Trim().Equals("lblIVSE01"))
                                e.Row.Cells[n_Stock_Exchange_IV].Text = e.Row.Cells[n_SHORT_NAME_IV].Text;
                            else
                                e.Row.Cells[n_Stock_Exchange_IV].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_Stock_Exchange_IV].Text.Trim() + "'" + ""))[0]["LabelName"]); ;
                        }
                        else e.Row.Cells[n_Stock_Exchange_IV].Text = "NA";

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Date_of_Market_Price_IV].Text) && !e.Row.Cells[n_Date_of_Market_Price_IV].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_Date_of_Market_Price_IV].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_Date_of_Market_Price_IV].Text.Trim() + "'" + ""))[0]["LabelName"]);
                        else
                            e.Row.Cells[n_Date_of_Market_Price_IV].Text = "NA";

                        e.Row.Cells[n_View_History_Data_IV].Controls.Add((Control)new VPSCommonModel().AddHistoryHyperLink(e.Row.Cells[n_AMPCID_IV].Text, e.Row.Cells[n_Applicable_From_Date_IV].Text, e.Row.Cells[n_To_Date_IV].Text, "MPC_IV"));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="marketPriceUC">marketPriceUC page object</param>
        public void PageIndexChangingForGVMPIV(int NewPageIndex, MarketPriceUC marketPriceUC)
        {
            try
            {
                marketPriceUC.gvMarketPriceIV.PageIndex = NewPageIndex;
                marketPriceUC.gvMarketPriceIV.DataSource = ac_ValuationParameter.dt_MarketPriceIV;
                marketPriceUC.gvMarketPriceIV.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid-view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="n_Index_FV">n_Index_FV</param>
        /// <param name="n_Stock_Exchange_FV">n_Stock_Exchange_FV</param>
        /// <param name="n_SHORT_NAME_FV">n_SHORT_NAME_FV</param>
        /// <param name="n_Date_of_Market_Price_FV">n_Date_of_Market_Price_FV</param>
        /// <param name="n_Remark_FV">n_Remark_FV</param>
        /// <param name="n_Applicable_From_Date_FV">n_Applicable_From_Date_FV</param>
        /// <param name="n_To_Date_FV">n_To_Date_FV</param>
        /// <param name="n_AMPCID_FV">n_AMPCID_FV</param>
        /// <param name="n_Approval_Status_FV">n_Approval_Status_FV</param>
        /// <param name="n_View_History_Data_FV">n_View_History_Data_FV</param>
        public void RowDataBindForGVMPFV(GridViewRowEventArgs e, ref int n_Index_FV, ref int n_Stock_Exchange_FV, ref int n_SHORT_NAME_FV, ref int n_Date_of_Market_Price_FV, ref int n_Remark_FV,
                        ref int n_Applicable_From_Date_FV, ref int n_To_Date_FV, ref int n_AMPCID_FV, ref int n_Approval_Status_FV, ref int n_View_History_Data_FV)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "STOCK EXCHANGE":
                                    n_Stock_Exchange_FV = n_Index_FV;
                                    break;
                                case "SHORT_NAME":
                                    n_SHORT_NAME_FV = n_Index_FV;
                                    perColumn.Visible = false;
                                    break;
                                case "DATE OF MARKET PRICE":
                                    n_Date_of_Market_Price_FV = n_Index_FV;
                                    break;
                                case "REMARK":
                                    n_Remark_FV = n_Index_FV;
                                    break;
                                case "APPLICABLE FROM DATE":
                                    n_Applicable_From_Date_FV = n_Index_FV;
                                    break;
                                case "TO DATE":
                                    n_To_Date_FV = n_Index_FV;
                                    break;
                                case "AMPCID":
                                    n_AMPCID_FV = n_Index_FV;
                                    perColumn.Visible = false;
                                    break;
                                case "APPROVAL STATUS":
                                    n_Approval_Status_FV = n_Index_FV;
                                    break;
                                case "VIEW HISTORY DATA":
                                    n_View_History_Data_FV = n_Index_FV;
                                    break;
                            }
                            n_Index_FV++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_SHORT_NAME_FV].Visible = e.Row.Cells[n_AMPCID_FV].Visible = false;
                        e.Row.Cells[n_Applicable_From_Date_FV].HorizontalAlign = e.Row.Cells[n_To_Date_FV].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Applicable_From_Date_FV].Text) && !e.Row.Cells[n_Applicable_From_Date_FV].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_Applicable_From_Date_FV].Text = Convert.ToDateTime(e.Row.Cells[n_Applicable_From_Date_FV].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_To_Date_FV].Text) && !e.Row.Cells[n_To_Date_FV].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_To_Date_FV].Text = Convert.ToDateTime(e.Row.Cells[n_To_Date_FV].Text).ToString("dd/MMM/yyyy");

                        e.Row.Cells[n_Remark_FV].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;");

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Stock_Exchange_FV].Text) && !e.Row.Cells[n_Stock_Exchange_FV].Text.Equals("&nbsp;"))
                        {
                            if (e.Row.Cells[n_Stock_Exchange_FV].Text.Trim().Equals("lblFVSE01"))
                                e.Row.Cells[n_Stock_Exchange_FV].Text = e.Row.Cells[n_SHORT_NAME_FV].Text;
                            else
                                e.Row.Cells[n_Stock_Exchange_FV].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_Stock_Exchange_FV].Text.Trim() + "'" + ""))[0]["LabelName"]); ;
                        }
                        else e.Row.Cells[n_Stock_Exchange_FV].Text = "NA";

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Date_of_Market_Price_FV].Text) && !e.Row.Cells[n_Date_of_Market_Price_FV].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_Date_of_Market_Price_FV].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_Date_of_Market_Price_FV].Text.Trim() + "'" + ""))[0]["LabelName"]);
                        else
                            e.Row.Cells[n_Date_of_Market_Price_FV].Text = "NA";

                        e.Row.Cells[n_View_History_Data_FV].Controls.Add((Control)new VPSCommonModel().AddHistoryHyperLink(e.Row.Cells[n_AMPCID_FV].Text, e.Row.Cells[n_Applicable_From_Date_FV].Text, e.Row.Cells[n_To_Date_FV].Text, "MPC_FV"));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="marketPriceUC">marketPriceUC page object</param>
        public void PageIndexChangingForGVMPFV(int NewPageIndex, MarketPriceUC marketPriceUC)
        {
            try
            {
                marketPriceUC.gvMarketPriceFV.PageIndex = NewPageIndex;
                marketPriceUC.gvMarketPriceFV.DataSource = ac_ValuationParameter.dt_MarketPriceFV;
                marketPriceUC.gvMarketPriceFV.DataBind();
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// This method is used to check changes in Parameter. 
        /// </summary>
        /// <param name="marketPriceUC"></param>
        public void ParamChange(MarketPriceUC marketPriceUC)
        {
            CommonModel.IsParamChange("UPDATE", userSessionInfo);            
        }

        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~MarketPriceUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}