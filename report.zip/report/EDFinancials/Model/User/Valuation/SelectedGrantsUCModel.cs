﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation.UserControl;
using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class SelectedGrantsUCModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SelectedGrantsUCModel()
        {
            if (ac_ValuationReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationReport);
                ac_ValuationReport = (CommonModel.AC_ValuationReport)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationReport];
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectedGrants"></param>
        /// <param name="e"></param>
        /// <param name="n_index"></param>
        /// <param name="n_Action"></param>
        /// <param name="n_ExerPrice">n_ExerPrice</param>
        /// <param name="n_IntrinsicValue">n_IntrinsicValue</param>
        /// <param name="n_FairVal">n_FairVal</param>
        public void BindRows(SelectedGrants selectedGrants, GridViewRowEventArgs e, ref int n_index, ref int n_Action, ref int n_ExerPrice, ref int n_IntrinsicValue, ref int n_FairVal)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ACTION":
                                    n_Action = n_index;
                                    break;

                                     case "EXERCISE PRICE":
                                    n_ExerPrice = n_index;
                                    break;

                                     case "INTRINSIC VALUE":
                                    n_IntrinsicValue = n_index;
                                    break;

                                     case "FAIR VALUE":
                                    n_FairVal = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        //e.Row.Cells[n_Action].Controls.Add(AddControl(e.Row.Cells[1].Text, e.Row.Cells[1].Text.Equals(ac_ValuationReport.s_CompareGrantID)));

                        // The following code implements thousand formatting and decimal rounding functionality
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {

                            e.Row.Cells[n_ExerPrice].Text = e.Row.Cells[n_ExerPrice].Text.Equals("&nbsp;") ? string.Empty : Convert.ToDouble(e.Row.Cells[n_ExerPrice].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_ExerPrice].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_ExerPrice].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            e.Row.Cells[n_ExerPrice].HorizontalAlign = HorizontalAlign.Right;

                            e.Row.Cells[n_IntrinsicValue].Text = e.Row.Cells[n_IntrinsicValue].Text.Equals("&nbsp;") ? string.Empty : Convert.ToDouble(e.Row.Cells[n_IntrinsicValue].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_IntrinsicValue].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_IntrinsicValue].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            e.Row.Cells[n_IntrinsicValue].HorizontalAlign = HorizontalAlign.Right;

                            e.Row.Cells[n_FairVal].Text = e.Row.Cells[n_FairVal].Text.Equals("&nbsp;") ? string.Empty : Convert.ToDouble(e.Row.Cells[n_FairVal].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_FairVal].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_FairVal].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            e.Row.Cells[n_FairVal].HorizontalAlign = HorizontalAlign.Right;
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="s_GrantID"></param>
        /// <param name="b_IsChecked"></param>
        /// <returns></returns>
        private CheckBox AddControl(string s_GrantID, bool b_IsChecked)
        {
            CheckBox checkBox = new CheckBox();

            checkBox.ToolTip = "Please select Grant";
            checkBox.ID = "chk" + s_GrantID;
            checkBox.InputAttributes.Add("Value", s_GrantID);
            checkBox.Text = string.Empty;
            checkBox.AutoPostBack = false;
            checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
            checkBox.InputAttributes["class"] = "rdbGrant";
            
			if(b_IsChecked)
            {
                checkBox.Checked = b_IsChecked;
            }

            checkBox.Attributes.Add("onclick", "javascript : return ViewDetailsSelectGrant('" + s_GrantID + "', this)");
            return checkBox;
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~SelectedGrantsUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}