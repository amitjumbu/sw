﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Company Information model class
    /// </summary>
    public class CompanyInformationModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public CompanyInformationModel()
        {
            if (ac_CompanyInformation == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_CompanyInformation);
                ac_CompanyInformation = (CommonModel.AC_CompanyInformation)HttpContext.Current.Session[CommonConstantModel.s_AC_CompanyInformation];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Static Variables 
        /// </summary>
        public static string s_ShareCapHeader = string.Empty, s_FaceValHeader = string.Empty;

        #endregion

        #region Common Methods
        /// <summary>
        /// This method is used to populated all the controls 
        /// </summary>
        /// <param name="companyInformation">CompanyInformation page object</param>
        public void PopulateAllControls(CompanyInformation companyInformation)
        {
            try
            {
                BindUI(companyInformation);
                BindAllGrids(companyInformation);
                PopulateControls(companyInformation);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all labels to the UI from XML
        /// </summary>
        /// <param name="companyInformation">CompanyInformation page object</param>
        public void BindUI(CompanyInformation companyInformation)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    ac_CompanyInformation.dt_CompanyInfoSetupUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_CompanyInformation, CommonConstantModel.s_ValuationL10_UI);
                    companyInformation.lblCIPageHeader.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIPageHeader'"))[0]["LabelName"]);
                    companyInformation.lblCIListingStatus.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIListingStatus'"))[0]["LabelName"]);
                    companyInformation.lblCIListingStatus.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIListingStatus'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIIssuedShares.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIIssuedShares'"))[0]["LabelName"]);
                    companyInformation.lblCIIssuedShares.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIIssuedShares'"))[0]["LabelToolTip"]);
                    companyInformation.btnCIViewIssuedShares.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'btnCIViewIssuedShares'"))[0]["LabelName"]);
                    companyInformation.btnCIViewIssuedShares.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'btnCIViewIssuedShares'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIFaceValPerShare.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIFaceValPerShare'"))[0]["LabelName"]);
                    companyInformation.lblCIFaceValPerShare.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIFaceValPerShare'"))[0]["LabelName"]);
                    companyInformation.btnCIViewFaceValue.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'btnCIViewFaceValue'"))[0]["LabelName"]);
                    companyInformation.btnCIViewFaceValue.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'btnCIViewFaceValue'"))[0]["LabelToolTip"]);
                    companyInformation.gvCIStockExchange.EmptyDataText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'btnCIEmptyDataText'"))[0]["LabelName"]);
                    companyInformation.gvCIShareCapDetails.EmptyDataText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'btnCIEmptyDataText'"))[0]["LabelName"]);
                    companyInformation.gvCIFaceValueDetails.EmptyDataText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'btnCIEmptyDataText'"))[0]["LabelName"]);
                    companyInformation.lblCIListingDetails.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIListingDetails'"))[0]["LabelName"]);
                    companyInformation.lblCIListingDetails.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIListingDetails'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIDateOfListing.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIDateOfListing'"))[0]["LabelName"]);
                    companyInformation.lblCIDateOfListing.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIDateOfListing'"))[0]["LabelToolTip"]);
                    companyInformation.lblCICompanyType.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCICompanyType'"))[0]["LabelName"]);
                    companyInformation.lblCICompanyType.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCICompanyType'"))[0]["LabelToolTip"]);
                    s_ShareCapHeader = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIShareCapHeader'"))[0]["LabelName"]);
                    s_FaceValHeader = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIFaceValHeader'"))[0]["LabelName"]);
                    companyInformation.lblCIAddress.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIAddress'"))[0]["LabelName"]);
                    companyInformation.lblCIAddress.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIAddress'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIContactPerson.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIContactPerson'"))[0]["LabelName"]);
                    companyInformation.lblCIContactPerson.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIContactPerson'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIDesignation.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIDesignation'"))[0]["LabelName"]);
                    companyInformation.lblCIDesignation.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIDesignation'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIPhoneNo.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIPhoneNo'"))[0]["LabelName"]);
                    companyInformation.lblCIPhoneNo.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIPhoneNo'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIEmailID.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIEmailID'"))[0]["LabelName"]);
                    companyInformation.lblCIEmailID.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIEmailID'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIAuditor.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIAuditor'"))[0]["LabelName"]);
                    companyInformation.lblCIAuditor.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIAuditor'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIAuditorInternal.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIAuditorInternal'"))[0]["LabelName"]);
                    companyInformation.lblCIAuditorInternal.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIAuditorInternal'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIAuditorExternal.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIAuditorExternal'"))[0]["LabelName"]);
                    companyInformation.lblCIAuditorExternal.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIAuditorExternal'"))[0]["LabelToolTip"]);
                    companyInformation.lblCICurrency.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCICurrency'"))[0]["LabelName"]);
                    companyInformation.lblCICurrency.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCICurrency'"))[0]["LabelToolTip"]);
                    companyInformation.lblCICountry.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCICountry'"))[0]["LabelName"]);
                    companyInformation.lblCICountry.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCICountry'"))[0]["LabelToolTip"]);
                    companyInformation.lblCISearchPanel.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCISearchPanel'"))[0]["LabelName"]);
                    companyInformation.lblCISearchPanel.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCISearchPanel'"))[0]["LabelToolTip"]);
                    companyInformation.lblCIAddEditPanel.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIAddEditPanel'"))[0]["LabelName"]);
                    companyInformation.lblCIAddEditPanel.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCIAddEditPanel'"))[0]["LabelToolTip"]);
                    companyInformation.lblCICompanyName.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCICompanyName'"))[0]["LabelName"]);
                    companyInformation.lblCICompanyName.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoSetupUI.Select("LabelID = 'lblCICompanyName'"))[0]["LabelToolTip"]);
                    companyInformation.lblCICompanyNameVal.Text = userSessionInfo.ACC_CompanyTitle;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all grids
        /// </summary>
        /// <param name="companyInformation">CompanyInformation page object</param>
        public void BindAllGrids(CompanyInformation companyInformation)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_CompanyInformation;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    valuationProperties.PopulateControls = CommonConstantModel.s_OperationRead;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    ac_CompanyInformation.ds_CompanyInfo = valuationCRUDProperties.ds_Result;

                    /* Company Info. */
                    ac_CompanyInformation.dt_CompanyInfo = ac_CompanyInformation.ds_CompanyInfo.Tables[0];

                    /* Share Cap. */
                    ac_CompanyInformation.dt_ShareCapDetails = ac_CompanyInformation.ds_CompanyInfo.Tables[1];
                    companyInformation.gvCIShareCapDetails.DataSource = ac_CompanyInformation.dt_ShareCapDetails;
                    companyInformation.gvCIShareCapDetails.DataBind();

                    /* Face Value */
                    ac_CompanyInformation.dt_FaceValueDetails = ac_CompanyInformation.ds_CompanyInfo.Tables[4];
                    companyInformation.gvCIFaceValueDetails.DataSource = ac_CompanyInformation.dt_FaceValueDetails;
                    companyInformation.gvCIFaceValueDetails.DataBind();

                    /* Stock Exchange */
                    ac_CompanyInformation.dt_AssociatedStockExchange = ac_CompanyInformation.ds_CompanyInfo.Tables[7];
                    companyInformation.gvCIStockExchange.DataSource = ac_CompanyInformation.dt_AssociatedStockExchange;
                    companyInformation.gvCIStockExchange.DataBind();

                    /* bind Company type dropdown */
                    ac_CompanyInformation.dt_CompanyType = ac_CompanyInformation.ds_CompanyInfo.Tables[8];
                    companyInformation.ddlCICompanyType.DataSource = ac_CompanyInformation.dt_CompanyType;
                    companyInformation.ddlCICompanyType.DataTextField = "COMPANY_TYPE";
                    companyInformation.ddlCICompanyType.DataValueField = "CTID";
                    companyInformation.ddlCICompanyType.DataBind();
                    BindToolTip(companyInformation.ddlCICompanyType);

                    /* bind Associated modules */
                    ac_CompanyInformation.dt_AssociatedModules = ac_CompanyInformation.ds_CompanyInfo.Tables[10];
                    companyInformation.gvAssociatedParams.DataSource = ac_CompanyInformation.dt_AssociatedModules;
                    companyInformation.gvAssociatedParams.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to populate all the controls on page load
        /// </summary>
        /// <param name="companyInformation">CompanyInformation page object</param>
        private void PopulateControls(CompanyInformation companyInformation)
        {
            try
            {
                if (ac_CompanyInformation.dt_CompanyInfo.Rows.Count > 0)
                {
                    if (Convert.ToBoolean(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["IS_LISTED"]))
                    {
                        companyInformation.lblCIDateOfListingText.Text = Convert.ToDateTime(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["Listing Date"]).ToString("dd/MMM/yyyy");
                        companyInformation.lblCICurrentListingStatus.Text = "Listed";
                        companyInformation.trListedSection.Style.Add("display", "");
                    }
                    else
                    {
                        companyInformation.lblCICurrentListingStatus.Text = "Unlisted";
                        companyInformation.trListedSection.Style.Add("display", "none");
                    }
                    companyInformation.ddlCICompanyType.SelectedValue = Convert.ToBoolean(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["IS_MYESOPS_CLIENT"]) ? "1" : "0";

                    companyInformation.txtCIAddress.Text = Convert.ToString(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["ADDRESS"]);
                    companyInformation.txtCIContactPerson.Text = Convert.ToString(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["CONTACT_PERSON"]);
                    companyInformation.txtCIAuditorInternal.Text = Convert.ToString(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["INTERNAL_AUDITOR"]);
                    companyInformation.txtCIAuditorExternal.Text = Convert.ToString(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["EXTERNAL_AUDITOR"]);
                    companyInformation.txtCIDesignation.Text = Convert.ToString(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["DESIGNATION"]);
                    companyInformation.txtCIEmailID.Text = Convert.ToString(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["EMAIL_ID"]);
                    companyInformation.txtCIPhoneNo.Text = Convert.ToString(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["PHONE_NO"]);
                    companyInformation.txtCICountry.Text = Convert.ToString(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["DEFAULT_COUNTRY"]);
                    companyInformation.txtCICurrency.Text = Convert.ToString(ac_CompanyInformation.dt_CompanyInfo.Rows[0]["DEFAULT_CURRENCY"]);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Used to bind tool tips to drop-down items
        /// </summary>
        /// <param name="list">ListControl object</param>
        public void BindToolTip(ListControl list)
        {
            try
            {
                foreach (ListItem item in list.Items)
                {
                    item.Attributes.Add("title", item.Text);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Reset all control values on popup close
        /// </summary>
        /// <param name="companyInformation">CompanyInformation page object</param>
        public void SetControlValuesOnPopupClose(CompanyInformation companyInformation)
        {
            try
            {
                companyInformation.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "none");
                BindAllGrids(companyInformation);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid-view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindCIShareCapDetails(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SCID":
                                    perColumn.Visible = false;
                                    break;
                                case "ACTIONS":
                                    perColumn.Visible = false;
                                    break;
                                case "TO DATE":
                                    perColumn.Visible = false;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[3].Visible = e.Row.Cells[1].Visible = e.Row.Cells[4].Visible = false;
                        e.Row.Cells[0].HorizontalAlign = e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[0].Width = e.Row.Cells[2].Width = 150;
                        if (!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                            e.Row.Cells[0].Text = Convert.ToDateTime(e.Row.Cells[0].Text).ToString("dd/MMM/yyyy");
                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            e.Row.Cells[2].Text = Convert.ToDouble(e.Row.Cells[2].Text) > 999 ? CommonModel.ThousandFormating(e.Row.Cells[2].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()) : e.Row.Cells[2].Text;
                        }
                        #endregion
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid-view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindCIFaceValueDetails(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "TO DATE":
                                    perColumn.Visible = false;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[1].Visible = false;
                        e.Row.Cells[0].HorizontalAlign = e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[0].Width = e.Row.Cells[2].Width = e.Row.Cells[3].Width = 150;

                        if (!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                            e.Row.Cells[0].Text = Convert.ToDateTime(e.Row.Cells[0].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            e.Row.Cells[2].Text = Convert.ToDouble(e.Row.Cells[2].Text) > 999 ? CommonModel.ThousandFormating(e.Row.Cells[2].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()) : e.Row.Cells[2].Text;
                        }
                        #endregion
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// grid-view page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="companyInformation">CompanyInformation page object</param>
        internal void PageIndexChanging(int NewPageIndex, CompanyInformation companyInformation)
        {
            try
            {
                companyInformation.gvCIStockExchange.PageIndex = NewPageIndex;
                companyInformation.gvCIStockExchange.DataSource = ac_CompanyInformation.dt_AssociatedStockExchange;
                companyInformation.gvCIStockExchange.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// grid-view page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="companyInformation">CompanyInformation page object</param>
        internal void gvAssociatedParams_PageIndexChanging(int NewPageIndex, CompanyInformation companyInformation)
        {
            try
            {
                companyInformation.gvAssociatedParams.PageIndex = NewPageIndex;
                companyInformation.gvAssociatedParams.DataSource = ac_CompanySetup.dt_AssociatedParameters;
                companyInformation.gvAssociatedParams.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CompanyInformationModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}