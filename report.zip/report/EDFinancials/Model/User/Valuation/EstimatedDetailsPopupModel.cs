﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Estimate date details popup model
    /// </summary>
    public class EstimatedDetailsPopupModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public EstimatedDetailsPopupModel()
        {
            if (ac_ValuationParameter == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationParameter);
                ac_ValuationParameter = (CommonModel.AC_ValuationParameter)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationParameter];
            }
        }

        #endregion

        #region Control events

        /// <summary>
        /// This method is used to bind all the controls 
        /// </summary>
        /// <param name="estimatedDateDetailsPopup">EstimatedDateDetailsPopup page object</param>
        public void PopulateAllControls(EstimatedDateDetailsPopup estimatedDateDetailsPopup)
        {
            try
            {
                BindUI(estimatedDateDetailsPopup);
                CheckEmployeeRolePriviledges(estimatedDateDetailsPopup);
                BindAllGrids(estimatedDateDetailsPopup);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all the labels from L10N_UI.xml file
        /// </summary>
        /// <param name="estimatedDateDetailsPopup">estimatedDateDetailsPopup page object</param>
        public void BindUI(EstimatedDateDetailsPopup estimatedDateDetailsPopup)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    ac_ValuationParameter.dt_EstDateDetailsUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10_UI);
                    estimatedDateDetailsPopup.lblCIDataUpdatedOn.Text = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'lblCIDataUpdatedOn'"))[0]["LabelName"]);
                    estimatedDateDetailsPopup.lblCIDataUpdatedOn.ToolTip = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'lblCIDataUpdatedOn'"))[0]["LabelToolTip"]);
                    estimatedDateDetailsPopup.rfvCIDataUpdatedOn.ToolTip = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'rfvCIDataUpdatedOn'"))[0]["LabelName"]);
                    estimatedDateDetailsPopup.lblCIEstDataofLisng.Text = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'lblCIEstDataofLisng'"))[0]["LabelName"]);
                    estimatedDateDetailsPopup.lblCIEstDataofLisng.ToolTip = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'lblCIEstDataofLisng'"))[0]["LabelToolTip"]);
                    estimatedDateDetailsPopup.rfvCIEstDataofLisng.ToolTip = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'rfvCIEstDataofLisng'"))[0]["LabelName"]);
                    estimatedDateDetailsPopup.rfvCIGrantsFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'rfvCIGrantsFromDate'"))[0]["LabelName"]);
                    estimatedDateDetailsPopup.lblCIFinancialYr.Text = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'lblCIFinancialYr'"))[0]["LabelName"]);
                    estimatedDateDetailsPopup.lblCIFinancialYr.ToolTip = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'lblCIFinancialYr'"))[0]["LabelToolTip"]);
                    estimatedDateDetailsPopup.lblCIGrantsFromDate.Text = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'lblCIGrantsFromDate'"))[0]["LabelName"]);
                    estimatedDateDetailsPopup.lblCIGrantsFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'lblCIGrantsFromDate'"))[0]["LabelToolTip"]);
                    estimatedDateDetailsPopup.btnCIListgDetailsSave.Text = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'btnCIListgDetailsSave'"))[0]["LabelName"]);
                    estimatedDateDetailsPopup.btnCIListgDetailsSave.ToolTip = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'btnCIListgDetailsSave'"))[0]["LabelToolTip"]);
                    estimatedDateDetailsPopup.btnCIListgDetailsReset.Text = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'btnCIListgDetailsReset'"))[0]["LabelName"]);
                    estimatedDateDetailsPopup.btnCIListgDetailsReset.ToolTip = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'btnCIListgDetailsReset'"))[0]["LabelToolTip"]);
                    estimatedDateDetailsPopup.gvCIListgDetails.EmptyDataText = Convert.ToString((ac_ValuationParameter.dt_EstDateDetailsUI.Select("LabelID = 'gvCIListgDetails'"))[0]["LabelName"]);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to check employee role priviledges
        /// </summary>
        /// <param name="estimatedDateDetailsPopup">estimatedDateDetailsPopup page object</param>
        private void CheckEmployeeRolePriviledges(EstimatedDateDetailsPopup estimatedDateDetailsPopup)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuValuationParameter;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    estimatedDateDetailsPopup.btnCIListgDetailsSave.Enabled = false;
                                    break;

                                case "ADD":
                                    estimatedDateDetailsPopup.btnCIListgDetailsSave.Enabled = true;
                                    break;

                                case "EDIT":
                                    estimatedDateDetailsPopup.btnCIListgDetailsSave.Enabled = true;
                                    ac_ValuationParameter.b_IsEditRights = true;
                                    break;

                                case "DELETE":
                                    estimatedDateDetailsPopup.btnCIListingDetailsDelete.Enabled = true;
                                    ac_ValuationParameter.b_IsDeleteRights = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all the grids
        /// </summary>
        /// <param name="estimatedDateDetailsPopup">estimatedDateDetailsPopup page object</param>
        public void BindAllGrids(EstimatedDateDetailsPopup estimatedDateDetailsPopup)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    ac_ValuationParameter.dt_EstimatedDOLDetails = ac_ValuationParameter.ds_ValuationParameters.Tables[16];
                    estimatedDateDetailsPopup.gvCIListgDetails.DataSource = ac_ValuationParameter.dt_EstimatedDOLDetails;
                    estimatedDateDetailsPopup.gvCIListgDetails.DataBind();

                    estimatedDateDetailsPopup.ddlCIFinancialYr.DataSource = ac_ValuationParameter.ds_ValuationParameters.Tables[17];
                    estimatedDateDetailsPopup.ddlCIFinancialYr.DataTextField = "FINC_YEAR";
                    estimatedDateDetailsPopup.ddlCIFinancialYr.DataValueField = "AFYMID";
                    estimatedDateDetailsPopup.ddlCIFinancialYr.DataBind();

                    estimatedDateDetailsPopup.ddlCIFinancialYr.SelectedIndex = Convert.ToInt32(ac_ValuationParameter.ds_ValuationParameters.Tables[17].Compute("max(AFYMID)", string.Empty)) - 15;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to perform CUD operation for estimated date of listing
        /// </summary>
        /// <param name="estimatedDateDetailsPopup">EstimatedDateDetailsPopup page object</param>
        /// <param name="s_Action">CUD action type</param>
        /// <returns>returns integer value of CUD operation</returns>
        public int CUDEstimatedDOL(EstimatedDateDetailsPopup estimatedDateDetailsPopup, string s_Action)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties = new ValuationProperties();
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                    valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                    valuationProperties.PopulateControls = "ESTIMATED_DATE";
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationProperties.ModifiedBy = userSessionInfo.ACC_UserID;

                    if (!string.IsNullOrEmpty(estimatedDateDetailsPopup.hdnCIListingDetailsID.Value.Trim()))
                        valuationProperties.CI_EDLID = Convert.ToInt32(estimatedDateDetailsPopup.hdnCIListingDetailsID.Value);

                    if (s_Action.Equals("D"))
                        valuationProperties.Action = s_Action;
                    else
                    {
                        valuationProperties.CI_DATA_UPDATED_ON = (string.IsNullOrEmpty(estimatedDateDetailsPopup.txtCIDataUpdatedOn.Text) || estimatedDateDetailsPopup.txtCIDataUpdatedOn.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(estimatedDateDetailsPopup.txtCIDataUpdatedOn.Text).ToString("MM/dd/yyyy");
                        valuationProperties.CI_ESTIMATED_DATE_OF_LISTING = (string.IsNullOrEmpty(estimatedDateDetailsPopup.txtCIEstDataofLisng.Text) || estimatedDateDetailsPopup.txtCIEstDataofLisng.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(estimatedDateDetailsPopup.txtCIEstDataofLisng.Text).ToString("MM/dd/yyyy");
                        valuationProperties.CI_FINANCIAL_YEAR = estimatedDateDetailsPopup.ddlCIFinancialYr.SelectedItem.Text;

                        if (!string.IsNullOrEmpty(estimatedDateDetailsPopup.txtCIGrantsFromDate.Text) && !estimatedDateDetailsPopup.txtCIGrantsFromDate.Text.Equals("dd/mmm/yyyy"))
                            valuationProperties.CI_GRANTS_FROM_DATE = Convert.ToDateTime(estimatedDateDetailsPopup.txtCIGrantsFromDate.Text).ToString("MM/dd/yyyy");

                        valuationProperties.CMID = userSessionInfo.ACC_CMID;
                    }

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    estimatedDateDetailsPopup.hdnCIListingDetailsID.Value = "0";
                    estimatedDateDetailsPopup.txtCIDataUpdatedOn.Text = estimatedDateDetailsPopup.txtCIEstDataofLisng.Text =
                    estimatedDateDetailsPopup.txtCIGrantsFromDate.Text = string.Empty;

                    return valuationCRUDProperties.a_result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to show/hide message div
        /// </summary>
        /// <param name="estimatedDateDetailsPopup">estimatedDateDetailsPopup page object</param>
        /// <param name="n_result">input parameter</param>
        public int ShowMsgDiv(EstimatedDateDetailsPopup estimatedDateDetailsPopup, int n_result)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                    estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;

                    estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                    estimatedDateDetailsPopup.hdnCIAccordionIndex.Value = "0";

                    switch (n_result)
                    {
                        case 1:
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblVPSSaveEstDateOfLstg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                            break;

                        case 2:
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblVPSUpdateEstDateOfLstg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                            break;

                        case 3:
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblVPSDateleEstDateOfLstg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                            break;

                        case 4:
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblVPSDataUpdOnLessGrntFrom", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                            break;

                        case 5:
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblVPSEDLDateOutOfRange", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                            break;

                        case 6:
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblVPSInValidDataUpdOn", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                            break;

                        case 7:
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblVPSInValidEstDateOfLstg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                            break;

                        case 8:
                            estimatedDateDetailsPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblVPSInValidGrntFrom", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                            break;

                        default:
                            break;
                    }
                }

                return n_result;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to rebind all the grids on post-back
        /// </summary>
        /// <param name="estimatedDateDetailsPopup"></param>
        public void ReBindAllGrids(EstimatedDateDetailsPopup estimatedDateDetailsPopup)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    valuationProperties.PopulateControls = CommonConstantModel.s_OperationRead;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    ac_ValuationParameter.ds_ValuationParameters = (DataSet)valuationCRUDProperties.ds_Result;
                    BindAllGrids(estimatedDateDetailsPopup);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void gvCIListgDetails_RowDataBound(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "EDLID":
                                    perColumn.Visible = false;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[0].Visible = false;
                        e.Row.Cells[1].HorizontalAlign = e.Row.Cells[2].HorizontalAlign = e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[2].Text) && !e.Row.Cells[2].Text.Equals("&nbsp;"))
                            e.Row.Cells[2].Text = Convert.ToDateTime(e.Row.Cells[2].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[4].Text) && !e.Row.Cells[4].Text.Equals("&nbsp;"))
                            e.Row.Cells[4].Text = Convert.ToDateTime(e.Row.Cells[4].Text).ToString("dd/MMM/yyyy");

                        e.Row.Cells[5].Controls.Add((Control)AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[1].Text, e.Row.Cells[2].Text, e.Row.Cells[4].Text, e.Row.Cells[3].Text, ""));
                        e.Row.Cells[5].Controls.Add((Control)AddImageLink("Delete", "~/View/App_Themes/images/Delete.png", e.Row.Cells[0].Text, e.Row.Cells[1].Text, e.Row.Cells[2].Text, e.Row.Cells[4].Text, e.Row.Cells[3].Text, ""));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_BtnEditText">image button text</param>
        /// <param name="s_Url">image URL</param>
        /// <param name="s_FromDate">from date</param>
        /// <param name="s_ToDate">to date</param>
        /// <param name="c_TextVal">image text value</param>
        /// <param name="c_ID">image ID</param>
        /// <param name="s_GRANTS_FROM_DATE">grants from date</param>
        /// <param name="s_CRMID">currency master ID</param>
        /// <returns>returns image button control object</returns>
        public ImageButton AddImageLink(string s_BtnEditText, string s_Url, string s_FromDate, string s_ToDate, string c_TextVal, string c_ID, string s_GRANTS_FROM_DATE, string s_CRMID)
        {
            try
            {
                using (ImageButton img = new ImageButton())
                {
                    img.ImageUrl = s_Url;
                    if (s_BtnEditText.Equals("Edit"))
                        img.Enabled = ac_ValuationParameter.b_IsEditRights;
                    else if (s_BtnEditText.Equals("Delete"))
                        img.Enabled = ac_ValuationParameter.b_IsDeleteRights;

                    img.ToolTip = s_BtnEditText;
                    img.Style.Add("cursor", "pointer");
                    img.Style.Add("text-align", "center");
                    img.TabIndex = 8;
                    s_ToDate = (!string.IsNullOrEmpty(s_ToDate) && !s_ToDate.Equals("&nbsp;")) ? s_ToDate : string.Empty;
                    string s_Code = (string.IsNullOrEmpty(c_ID) || c_ID.Equals("&nbsp;")) ? string.Empty : c_ID;
                    s_GRANTS_FROM_DATE = (string.IsNullOrEmpty(s_GRANTS_FROM_DATE) || s_GRANTS_FROM_DATE.Equals("&nbsp;")) ? string.Empty : s_GRANTS_FROM_DATE;
                    img.Attributes.Add("onclick", "return EditEstimatedDate('" + s_ToDate + "','" + c_TextVal + "','" + s_Code + "','" + s_FromDate + "','Update','" + s_GRANTS_FROM_DATE + "','" + s_BtnEditText + "')");
                    return img;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="estimatedDateDetailsPopup">EstimatedDateDetailsPopup page object</param>
        public void gvCIListgDetails_PageIndexChanging(int NewPageIndex, EstimatedDateDetailsPopup estimatedDateDetailsPopup)
        {
            try
            {
                estimatedDateDetailsPopup.gvCIListgDetails.PageIndex = NewPageIndex;
                estimatedDateDetailsPopup.gvCIListgDetails.DataSource = ac_ValuationParameter.dt_EstimatedDOLDetails;
                estimatedDateDetailsPopup.gvCIListgDetails.DataBind();
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// This Method is used to Validate the Dates entered in EDL PopUp
        /// </summary>
        /// <param name="estimatedDateDetailsPopup">estimatedDateDetailsPopup Page Object</param>
        /// <returns>returns n_IsValid</returns>
        internal int ValidateEDLDates(EstimatedDateDetailsPopup estimatedDateDetailsPopup)
        {
            try
            {
                int n_IsValid = 0;

                if (Convert.ToDateTime(estimatedDateDetailsPopup.txtCIDataUpdatedOn.Text) <= Convert.ToDateTime(estimatedDateDetailsPopup.txtCIGrantsFromDate.Text))
                    n_IsValid = 4;
                else if (!(Convert.ToDateTime(estimatedDateDetailsPopup.txtCIEstDataofLisng.Text) >= Convert.ToDateTime(estimatedDateDetailsPopup.txtCIGrantsFromDate.Text) && Convert.ToDateTime(estimatedDateDetailsPopup.txtCIEstDataofLisng.Text) <= Convert.ToDateTime(estimatedDateDetailsPopup.txtCIDataUpdatedOn.Text)))
                    n_IsValid = 5;

                if (ac_ValuationParameter.dt_EstimatedDOLDetails != null && ac_ValuationParameter.dt_EstimatedDOLDetails.Rows.Count > 0 && n_IsValid == 0)
                {
                    var v_MaxDataUpdatedOn = ac_ValuationParameter.dt_EstimatedDOLDetails.Select("[Data Updated On] = MAX([Data Updated On])")[0].ItemArray[1];
                    var v_MaxEDL = ac_ValuationParameter.dt_EstimatedDOLDetails.Select("[Estimated Date of Listing] = MAX([Estimated Date of Listing])")[0].ItemArray[2];
                    var v_MaxGrantsFromDate = ac_ValuationParameter.dt_EstimatedDOLDetails.Select("[Grants From Date] = MAX([Grants From Date])")[0].ItemArray[4];

                    if (Convert.ToDateTime(v_MaxDataUpdatedOn) >= Convert.ToDateTime(estimatedDateDetailsPopup.txtCIDataUpdatedOn.Text))
                        n_IsValid = 6;
                    else if (Convert.ToDateTime(v_MaxEDL) >= Convert.ToDateTime(estimatedDateDetailsPopup.txtCIEstDataofLisng.Text))
                        n_IsValid = 7;
                    else if (Convert.ToDateTime(v_MaxGrantsFromDate) >= Convert.ToDateTime(estimatedDateDetailsPopup.txtCIGrantsFromDate.Text))
                        n_IsValid = 8;
                }

                return n_IsValid;
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~EstimatedDetailsPopupModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}