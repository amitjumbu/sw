﻿using EDFinancials.Model.Generic;
using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class HelpDocModel : BaseModel, IDisposable
    {
        /// <summary>
        /// This method is used to load the treeview
        /// </summary>
        /// <param name="helpDoc">helpDoc</param>
        internal void LoadTreeview(View.User.Valuation.HelpDoc helpDoc)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PopulateControls = "BindTreeView";
                    valuationProperties.PageName = CommonConstantModel.s_Help;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    DataTable dt = (DataTable)valuationCRUDProperties.dt_Result;

                    PopulateTreeView(helpDoc, dt);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Populate TreeView
        /// </summary>
        /// <param name="helpDoc">helpDoc</param>
        /// <param name="dt_AllPages">DataTable All Pages</param>
        private void PopulateTreeView(View.User.Valuation.HelpDoc helpDoc, DataTable dt_AllPages)
        {
            try
            {
                if (dt_AllPages != null)
                {
                    foreach (DataRow dataRow in dt_AllPages.Rows)
                    {
                        if (Convert.ToInt32(dataRow["PARENT_MMID"]) == 0)
                        {
                            TreeNode treeRoot = new TreeNode();
                            treeRoot.Text = dataRow["MENU_NAME"].ToString();
                            treeRoot.Value = dataRow["MMID"].ToString();
                            treeRoot.SelectAction = TreeNodeSelectAction.None;
                            treeRoot.ExpandAll();

                            helpDoc.tvHelp.Nodes.Add(treeRoot);
                            helpDoc.tvHelp.NodeStyle.Font.Size = 8;
                            helpDoc.tvHelp.NodeStyle.ForeColor = Color.Black;

                            foreach (TreeNode childnode in GetChildNode(Convert.ToInt32(dataRow["MMID"]), dt_AllPages))
                            {
                                treeRoot.ChildNodes.Add(childnode);
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to create a child node
        /// </summary>
        /// <param name="n_ParentMMID">Parent_MMID of ParentNode</param>
        /// <param name="dt_Parent">Datatable ParentNode</param>
        /// <returns>childtreenodes</returns>
        private TreeNodeCollection GetChildNode(int n_ParentMMID, DataTable dt_Parent)
        {
            try
            {
                TreeNodeCollection childtreenodes = new TreeNodeCollection();

                DataTable dt_Child = new DataTable();

                dt_Child = dt_Parent.AsEnumerable().Where(r => r.Field<int>("PARENT_MMID") == n_ParentMMID).Count() > 0 ? dt_Parent.AsEnumerable().Where(r => r.Field<int>("PARENT_MMID") == n_ParentMMID).CopyToDataTable() : new DataTable();

                if (dt_Child.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in dt_Child.Rows)
                    {
                        TreeNode childNode = new TreeNode();
                        childNode.Text = dataRow[1].ToString();
                        childNode.Value = dataRow[0].ToString();
                        childNode.ExpandAll();

                        foreach (TreeNode cnode in GetChildNode(Convert.ToInt32(dataRow[0]), dt_Child))
                        {
                            childNode.ChildNodes.Add(cnode);
                        }
                        childtreenodes.Add(childNode);
                    }
                }
                return childtreenodes;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// TreeView tvHelp Select Node Chaged Event
        /// </summary>
        /// <param name="helpDoc">helpDoc</param>
        internal void tvHelp_SelectedNodeChanged(View.User.Valuation.HelpDoc helpDoc)
        {
            try
            {
                if (Convert.ToString(helpDoc.tvHelp.SelectedNode.Text).Contains('.'))
                {
                    helpDoc.ifrmHelpDoc.Src = "~/HelpDocs/" + "Others/" + helpDoc.tvHelp.SelectedNode.Text;

                    helpDoc.tvHelp.SelectedNodeStyle.ForeColor = Color.Blue;
                }

                else
                {
                    string s_SrcFilePath = helpDoc.tvHelp.SelectedNode.Text + "\\" + "PageWise\\" + Convert.ToString(helpDoc.tvHelp.SelectedNode.Text).Replace(" ", "") + ".htm";

                    string s_DirectoryPath = helpDoc.Server.MapPath("~/HelpDocs/" + helpDoc.tvHelp.SelectedNode.Text + "\\" + "PageWise");

                    DirectoryInfo diInfo = new DirectoryInfo(s_DirectoryPath);

                    if (diInfo.Exists)
                    {
                        FileInfo[] HTMFiles = diInfo.GetFiles("*.htm");

                        if (HTMFiles.Length == 0)
                        {
                            helpDoc.ifrmHelpDoc.Src = "../../PageNotFound.aspx";
                        }
                        else
                        {
                            helpDoc.ifrmHelpDoc.Src = "~/HelpDocs/" + s_SrcFilePath;

                            helpDoc.tvHelp.SelectedNodeStyle.ForeColor = Color.Blue;
                        }
                    }
                    else
                        helpDoc.ifrmHelpDoc.Src = "../../PageNotFound.aspx";
                }
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~HelpDocModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}