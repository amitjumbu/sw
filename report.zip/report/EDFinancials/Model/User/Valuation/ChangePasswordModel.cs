﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using System;
using System.Data;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Model file for Valuation's changePassword Page.
    /// </summary>
    public class ChangePasswordModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Enables or disables control according to roles assigned to user.
        /// </summary>
        /// <param name="changePassword"></param>
        internal void CheckEmployeeRolePriviledges(ChangePassword changePassword)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuChangePassword;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    break;

                                case "ADD":
                                    changePassword.btnCPSubmit.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to fetch messages from L10N xml via Valuation WCF service.
        /// </summary>
        /// <param name="MessegeId"></param>
        /// <returns>string as the message</returns>
        public string Valuation_L10N(string MessegeId)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                try
                {
                    return valuationServiceClient.GetValuation_L10N(MessegeId, CommonConstantModel.s_ChangePassword, CommonConstantModel.s_ValuationL10);
                }
                catch
                {
                    throw;
                }
            }

        }

        /// <summary>
        /// This method is used to load all label text from L10N_UI via wcf service
        /// </summary>
        /// <param name="changePassword">Entire page is sent to module using 'this' keyword</param>
        public void BindPageUI(EDFinancials.View.User.Valuation.ChangePassword changePassword)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (DataTable dt_ChangPWEUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_ChangePassword, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if ((dt_ChangPWEUI != null) && (dt_ChangPWEUI.Rows.Count > 0))
                        {
                            changePassword.lblCPHeader.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPHeader'"))[0]["LabelName"]);
                            changePassword.lblCPoldPassword.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPoldPassword'"))[0]["LabelName"]);
                            changePassword.lblCPoldPassword.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPoldPassword'"))[0]["LabelToolTip"]);
                            changePassword.RqdOldpswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPoldPassword'"))[0]["LabelToolTip"]);

                            changePassword.lblCPnewPassword.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPnewPassword'"))[0]["LabelName"]);
                            changePassword.lblCPnewPassword.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPnewPassword'"))[0]["LabelToolTip"]);
                            changePassword.rqdnewpswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPnewPassword'"))[0]["LabelToolTip"]);

                            changePassword.lblCPconfirmPassword.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["LabelName"]);
                            changePassword.lblCPconfirmPassword.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["LabelToolTip"]);
                            changePassword.rqdcnfmpswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["ErrorText2"]);
                            changePassword.cmpConfmpswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["ErrorText"]);

                            changePassword.btnCPSubmit.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='btnCPSubmit'"))[0]["LabelName"]);
                            changePassword.btnCPSubmit.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='btnCPSubmit'"))[0]["LabelToolTip"]);
                            changePassword.btnCPCancel.Value = Convert.ToString((dt_ChangPWEUI.Select("LabelID='btnCPCancel'"))[0]["LabelName"]);
                            changePassword.lblPasswordpattern.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='PasswordPatternHelp'"))[0]["LabelName"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to perform CUD actions
        /// </summary>
        internal void PerformCUD(EDFinancials.View.User.Valuation.ChangePassword changePassword)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                valuationProperties.Id = userSessionInfo.ACC_UserID;

                valuationProperties.LoginPassword = changePassword.txtCPoldPassword.Text;
                valuationProperties.NewPassword = changePassword.txtCPnewPassword.Text;
                valuationProperties.Action = "P";

                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                valuationProperties.PageName = CommonConstantModel.s_ChangePassword;

                try
                {
                    switch (valuationServiceClient.CRUDValuationOperations(valuationProperties).a_result)
                    {
                        case 0:
                            changePassword.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblError", CommonConstantModel.s_ChangePassword, CommonConstantModel.s_ValuationL10);
                            changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;

                        case 4:
                            changePassword.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCPNoMatch", CommonConstantModel.s_ChangePassword, CommonConstantModel.s_ValuationL10);
                            changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;


                        case 2:
                            changePassword.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCPUpdated", CommonConstantModel.s_ChangePassword, CommonConstantModel.s_ValuationL10);
                            changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            break;

                    }
                    changePassword.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    changePassword.txtCPoldPassword.Text = string.Empty;
                    changePassword.txtCPnewPassword.Text = string.Empty;
                    changePassword.txtCPconfirmPassword.Text = string.Empty;
                }
                catch
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// This method validates the new password string according to the predefined password standard.
        /// </summary>
        /// <param name="changePassword">object of change password page</param>
        /// <returns>returns boolean</returns>
        internal bool ValidatePasswordPattern(ChangePassword changePassword)
        {
            bool b_Flag = false;
            try
            {
                string[] s_IsInValidPassword = new string[2];
                s_IsInValidPassword = CommonModel.ValidatePasswordPattern(changePassword.txtCPconfirmPassword.Text);
                if (!(string.IsNullOrEmpty(s_IsInValidPassword[0])))
                {
                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        changePassword.ctrSuccessErrorMessage.s_MessageText = genericServiceClient.Get_L10N(s_IsInValidPassword[0], "Message", "COMMON_L10N.xml");
                        changePassword.ctrSuccessErrorMessage.s_MessageText = changePassword.ctrSuccessErrorMessage.s_MessageText + s_IsInValidPassword[1].ToString() + genericServiceClient.Get_L10N(s_IsInValidPassword[2], "Message", "COMMON_L10N.xml");
                    }
                    changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                    changePassword.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    b_Flag = false;
                }
                else
                {
                    b_Flag = true;
                }
            }
            catch
            {
                throw;
            }
            return b_Flag;
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ChangePasswordModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}