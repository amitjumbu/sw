﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation.UserControl;
using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// The Model Class ModificationEDLUCModel of ModificationEDLUC Page
    /// </summary>
    public class ModificationEDLUCModel : BaseModel, IDisposable
    {
        #region Default Constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public ModificationEDLUCModel()
        {
            if (ac_SearchGrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_SearchGrantDetails);
                ac_SearchGrantDetails = (CommonModel.AC_SearchGrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_SearchGrantDetails];
            }
        }
        #endregion

        /// <summary>
        /// This method is used to check whether the ModificationEDL tab to be visible or not.
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        /// <returns>DataTable of Grant Details</returns>
        internal DataTable GetModEDLData(ModificationEDLUC modificationEDLUC)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                    valuationProperties.Operation_Param = CommonConstantModel.s_ModEDL;

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    modificationEDLUC.hdnIsModEDLVisible.Value = valuationCRUDProperties.ds_Result.Tables[0].Copy().Select("OPERATION_ID = 2 OR OPERATION_ID = 3").Count() > 0 ? "True" : "False";

                    return valuationCRUDProperties.dt_Result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The method for the bind names to the controls
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        internal void BindUI(ModificationEDLUC modificationEDLUC)
        {
            try
            {
                if ((ac_SearchGrantDetails.dt_GrantDetailUI != null) && (ac_SearchGrantDetails.dt_GrantDetailUI.Rows.Count > 0))
                {
                    modificationEDLUC.lblMETypeOfOperation.Text = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'lblMETypeOfOperation'")[0]["LabelName"]);
                    modificationEDLUC.lblMETypeOfOperation.ToolTip = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'lblMETypeOfOperation'")[0]["LabelToolTip"]);

                    modificationEDLUC.lblMESelectModEDL.Text = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'lblMESelectModEDL'")[0]["LabelName"]);
                    modificationEDLUC.lblMESelectModEDL.ToolTip = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'lblMESelectModEDL'")[0]["LabelToolTip"]);

                    modificationEDLUC.btnMEVeiw.Text = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'btnMEVeiw'")[0]["LabelName"]);
                    modificationEDLUC.btnMEVeiw.ToolTip = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'btnMEVeiw'")[0]["LabelToolTip"]);

                    modificationEDLUC.btnMEViewAll.Text = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'btnMEViewAll'")[0]["LabelName"]);
                    modificationEDLUC.btnMEViewAll.ToolTip = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'btnMEViewAll'")[0]["LabelToolTip"]);

                    modificationEDLUC.btnMEReprocess.Text = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'btnMEReprocess'")[0]["LabelName"]);
                    modificationEDLUC.btnMEReprocess.ToolTip = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'btnMEReprocess'")[0]["LabelToolTip"]);

                    modificationEDLUC.btnMEReset.Text = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'btnMEReset'")[0]["LabelName"]);
                    modificationEDLUC.btnMEReset.ToolTip = Convert.ToString(ac_SearchGrantDetails.dt_GrantDetailUI.Select("LabelID = 'btnMEReset'")[0]["LabelToolTip"]);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The method used to bind Dropdowns
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        internal void BindDropDown(ModificationEDLUC modificationEDLUC)
        {
            try
            {
                using (ac_SearchGrantDetails.dt_all_Grants = GetModEDLData(modificationEDLUC))
                {
                    using (DataTable dt_EDL = ac_SearchGrantDetails.dt_all_Grants.Copy())
                    {
                        var var_DistinctVal = (from b in dt_EDL.AsEnumerable()
                                               where b.Field<int>("OPERATION_ID") == 2 || b.Field<int>("OPERATION_ID") == 3
                                               select b).Distinct();

                        DataTable dt_BindDDL = var_DistinctVal.Count() > 0 ? var_DistinctVal.CopyToDataTable() : null;

                        if (dt_BindDDL != null && dt_BindDDL.Rows.Count > 0)
                        {
                            DataView dv_BindDDL = new DataView(dt_BindDDL.DefaultView.ToTable(true, "OPERATION_ID", "OPERATION_DATE"));
                            dv_BindDDL.Sort = "OPERATION_DATE DESC";
                            dt_BindDDL = dv_BindDDL.ToTable();

                            modificationEDLUC.ddlMESelectModEDL.DataSource = dt_BindDDL;
                            modificationEDLUC.ddlMESelectModEDL.DataTextField = "OPERATION_DATE";
                            modificationEDLUC.ddlMESelectModEDL.DataValueField = "OPERATION_DATE";
                            modificationEDLUC.ddlMESelectModEDL.DataBind();

                            modificationEDLUC.ddlMETypeOfOperation.Items.Clear();
                            modificationEDLUC.ddlMETypeOfOperation.Items.Insert(0, "Modification");
                            modificationEDLUC.ddlMETypeOfOperation.Items.Insert(1, "Estimated Date Of Listing");

                            modificationEDLUC.ddlMETypeOfOperation.SelectedIndex = Convert.ToInt32(dt_BindDDL.Rows[0][0].ToString()) == 2 ? 1 : 0;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind gvModEDL GridView and also performs View Button Functionality and Reset Button Functionality
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        internal void BindGrid(ModificationEDLUC modificationEDLUC)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    DataView dv_ModEDLGrants = null;

                    dv_ModEDLGrants = new DataView(GetModEDLData(modificationEDLUC));

                    ac_SearchGrantDetails.dt_ModEDLGrants = dv_ModEDLGrants.Count > 0 ? dv_ModEDLGrants.ToTable("DT", true, new string[] { "Action", "ID", "Grant Registration ID", "Grant Date", "Scheme Title", "Exercise Price", "Vesting Schedule", "Currency", "Intrinsic Value", "Fair Value", "Group Number", "Status", "AGRMID", "IS_MU_FV", "IS_MU_IV", "OPERATION_ID", "OPERATION_DATE" }).Copy() : null;

                    if (string.IsNullOrEmpty(Convert.ToString(modificationEDLUC.hdnMEViewClicked.Value)))
                    {
                        BindDropDown(modificationEDLUC);

                        modificationEDLUC.hdnMEViewClicked.Value = modificationEDLUC.hdnMEDropDownIndexChanged.Value = string.Empty;
                    }

                    btnMEVeiw_Click(modificationEDLUC);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Row Bound Event of gvModEDL GridView
        /// </summary>
        /// <param name="sender">gvModEDL GridView</param>
        /// <param name="e">e</param>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        /// <param name="n_index">int n_index</param>
        /// <param name="n_Action">int n_Action Parameter</param>
        /// <param name="n_ID">int n_ID Parameter</param>
        /// <param name="n_GrantID">int n_GrantID Grant ID</param>
        /// <param name="n_GrantDate">int n_GrantDate Grant Date</param>
        /// <param name="n_ExerPrc">int n_ExerPrc Exercise Price</param>
        /// <param name="n_VestSchedule">int n_VestSchedule Vesting Schedule</param>
        /// <param name="n_FairValue">int n_FairValue Fair Value</param>
        /// <param name="n_IntrinsicValue">int n_IntrinsicValue Intrinsic Value</param>
        /// <param name="n_Status">int n_Status Report Status</param>
        /// <param name="n_AGRMID">int n_AGRMID Grant Registration Master ID</param>
        /// <param name="n_GrpNum">int n_GrpNum Group Number</param>
        /// <param name="n_IsMUFV">int n_IsMUFV If Fair Value manually updated</param>
        /// <param name="n_IsMUIV">int n_IsMUIV If Intrinsic Value manually updated</param>
        /// <param name="n_Opt_ID">int n_Opt_ID Operation ID whether Modification/EDL</param>
        /// <param name="n_Opt_Date">int n_Opt_Date Operation Date whether Modification/EDL</param>
        internal void gvModEDL_RowDataBound(object sender, GridViewRowEventArgs e, ModificationEDLUC modificationEDLUC, ref int n_index, ref int n_Action, ref int n_ID, ref int n_GrantID, ref int n_GrantDate, ref int n_ExerPrc, ref int n_VestSchedule, ref int n_FairValue, ref int n_IntrinsicValue, ref int n_Status, ref int n_AGRMID, ref int n_GrpNum, ref int n_IsMUFV, ref int n_IsMUIV, ref int n_Opt_ID, ref int n_Opt_Date)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ACTION":
                                    n_Action = n_index;
                                    e.Row.Cells[n_Action].Controls.Add(AddControl(modificationEDLUC, "CheckBox", string.Empty, "chkBoxAll", string.Empty, string.Empty, "SelectAllCheckBoxesME", string.Empty, string.Empty, string.Empty, string.Empty));
                                    break;

                                case "ID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "GRANT REGISTRATION ID":
                                    n_GrantID = n_index;
                                    break;

                                case "GRANT DATE":
                                    n_GrantDate = n_index;
                                    break;

                                case "EXERCISE PRICE":
                                    n_ExerPrc = n_index;
                                    break;

                                case "VESTING SCHEDULE":
                                    n_VestSchedule = n_index;
                                    break;

                                case "FAIR VALUE":
                                    n_FairValue = n_index;
                                    break;

                                case "INTRINSIC VALUE":
                                    n_IntrinsicValue = n_index;
                                    break;

                                case "STATUS":
                                    n_Status = n_index;
                                    break;

                                case "AGRMID":
                                    n_AGRMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "GROUP NUMBER":
                                    n_GrpNum = n_index;
                                    break;

                                case "IS_MU_FV":
                                    n_IsMUFV = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "IS_MU_IV":
                                    n_IsMUIV = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPERATION_ID":
                                    n_Opt_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "OPERATION_DATE":
                                    n_Opt_Date = n_index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            if (!e.Row.Cells[n_FairValue].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_FairValue].Text = Convert.ToDouble(e.Row.Cells[n_FairValue].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_FairValue].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_FairValue].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            if (!e.Row.Cells[n_IntrinsicValue].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_IntrinsicValue].Text = Convert.ToDouble(e.Row.Cells[n_IntrinsicValue].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_IntrinsicValue].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_IntrinsicValue].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }

                            e.Row.Cells[n_ExerPrc].Text = Convert.ToDouble(e.Row.Cells[n_ExerPrc].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_ExerPrc].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_ExerPrc].Text, DecimalLimitTable.Select("ADVSID = 4")[0]["ROUNDING_PLACE_VALUE"].ToString());
                        }
                        #endregion

                        e.Row.Cells[n_ID].Visible = e.Row.Cells[n_AGRMID].Visible = e.Row.Cells[n_IsMUFV].Visible = e.Row.Cells[n_IsMUIV].Visible = e.Row.Cells[n_Opt_ID].Visible = e.Row.Cells[n_Opt_Date].Visible = false;

                        e.Row.Cells[n_Action].HorizontalAlign = e.Row.Cells[n_GrantDate].HorizontalAlign = e.Row.Cells[n_VestSchedule].HorizontalAlign = e.Row.Cells[n_GrpNum].HorizontalAlign = e.Row.Cells[n_Status].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_ExerPrc].HorizontalAlign = e.Row.Cells[n_IntrinsicValue].HorizontalAlign = e.Row.Cells[n_FairValue].HorizontalAlign = HorizontalAlign.Right;

                        e.Row.Cells[n_Action].Controls.Add(AddControl(modificationEDLUC, "CheckBox", string.Empty, "chkBox", string.Empty, string.Empty, "DeleteSelectedRecordsME", e.Row.Cells[n_AGRMID].Text, string.Empty, string.Empty, string.Empty));
                        e.Row.Cells[n_GrantID].Controls.Add(AddControl(modificationEDLUC, "LinkButton", "Click here to view valuation parameters", "lblGrantID", e.Row.Cells[n_GrantID].Text, "GrantID", "ViewMEDetails", e.Row.Cells[n_GrantID].Text, string.Empty, e.Row.Cells[n_Opt_Date].Text, string.Empty));
                        e.Row.Cells[n_VestSchedule].Controls.Add(AddControl(modificationEDLUC, "LinkButton", "Click here to view vestwise details", "lnkViewDetails", "View Details", "VestSchedule", string.Empty, e.Row.Cells[n_GrantID].Text, string.Empty, string.Empty, string.Empty));
                        e.Row.Cells[n_IntrinsicValue].Controls.Add(AddControl(modificationEDLUC, "LinkButton", "Click here to view Intrinsic Value details", "lnkIV", e.Row.Cells[n_IntrinsicValue].Text, "IV", "ViewMEDetails", e.Row.Cells[n_GrantID].Text, e.Row.Cells[n_Opt_ID].Text, e.Row.Cells[n_Opt_Date].Text, string.Empty));
                        e.Row.Cells[n_FairValue].Controls.Add(AddControl(modificationEDLUC, "LinkButton", "Click here to view Fair Value details", "lnkFV", e.Row.Cells[n_FairValue].Text, "FV", "ViewMEDetails", e.Row.Cells[n_GrantID].Text, e.Row.Cells[n_Opt_ID].Text, e.Row.Cells[n_Opt_Date].Text, string.Empty));

                        if (e.Row.RowIndex > 0)
                        {
                            int n_RowIndex = 1, n_Count = 1;

                            MergeCells(modificationEDLUC.gvModEDL, e, n_Status, ref n_RowIndex, ref n_Count);
                        }

                        if (e.Row.Cells[n_GrpNum].Text.Equals("0"))
                            e.Row.Cells[n_GrpNum].Text = "-";

                        string s_StatusText = !string.IsNullOrEmpty(e.Row.Cells[n_Status].Text) && !e.Row.Cells[n_Status].Text.Equals("&nbsp;") && e.Row.Cells[n_Status].Text.Equals("Select Grant") ? "Not Processed" : !string.IsNullOrEmpty(e.Row.Cells[n_Status].Text) && e.Row.Cells[n_Status].Text.Equals("Locked") ? "Locked" : "Pending";

                        if (s_StatusText.Equals("Not Processed"))
                            e.Row.Cells[n_Status].Text = s_StatusText;
                        else if (s_StatusText.Equals("Locked"))
                            e.Row.Cells[n_Status].Controls.Add(AddControl(modificationEDLUC, "LinkButton", string.Empty, "lnkStatus", "Click here to view Versions or Unlock Grants", "GotoStepME", string.Empty, e.Row.Cells[n_Status].Text, e.Row.Cells[n_GrantID].Text, string.Empty, e.Row.Cells[n_AGRMID].Text));
                        else
                            e.Row.Cells[n_Status].Controls.Add(AddControl(modificationEDLUC, "LinkButton", string.Empty, "lnkStatus", s_StatusText, "GotoStepME", string.Empty, e.Row.Cells[n_Status].Text, e.Row.Cells[n_GrantID].Text, string.Empty, e.Row.Cells[n_AGRMID].Text));

                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add controls to the gvModEDL GridView
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        /// <param name="s_ControlName">Name of the Control</param>
        /// <param name="s_ControlTooltip">Tooltip of The Control</param>
        /// <param name="s_ControlID">ID of the Control</param>
        /// <param name="s_ControlText">Text of the Control</param>
        /// <param name="s_EventName">Event Name of The Control</param>
        /// <param name="s_JScriptName">JavaScript Name of the Control</param>
        /// <param name="s_ParamOne">Parameter One</param>
        /// <param name="s_ParamTwo">Parameter Two</param>
        /// <param name="s_OperationDate">Parameter Operation Date</param>
        /// <param name="s_AGRMID">Parameter AGRMID</param>
        /// <returns>Control</returns>
        private Control AddControl(ModificationEDLUC modificationEDLUC, string s_ControlName, string s_ControlTooltip, string s_ControlID, string s_ControlText, string s_EventName, string s_JScriptName, string s_ParamOne, string s_ParamTwo, string s_OperationDate, string s_AGRMID)
        {
            try
            {
                switch (s_ControlName)
                {
                    case "CheckBox":
                        using (CheckBox checkBox = new CheckBox())
                        {
                            checkBox.InputAttributes.Add("Value", s_ParamOne);
                            checkBox.Checked = false;
                            checkBox.ID = s_ControlID;
                            checkBox.Attributes.Add("name", "Types");
                            checkBox.InputAttributes["class"] = "CheckBoxClass";
                            checkBox.EnableViewState = false;
                            checkBox.AutoPostBack = false;
                            checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                            if (s_JScriptName.Equals("DeleteSelectedRecordsME"))
                                checkBox.Attributes.Add("onclick", "return DeleteSelectedRecordsME('" + s_ParamOne + "',this)");

                            else
                                checkBox.Attributes.Add("onclick", "return SelectAllCheckBoxesME(this)");

                            return checkBox;
                        }
                    case "LinkButton":
                        LinkButton linkButton = new LinkButton();
                        linkButton.ID = s_ControlID;
                        linkButton.ToolTip = s_ControlTooltip;
                        linkButton.Text = s_ControlText;
                        linkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        linkButton.Style.Add("cursor", "pointer");

                        if (!string.IsNullOrEmpty(s_JScriptName) && !s_EventName.Equals("GotoStepME"))
                            linkButton.Attributes.Add("onclick", "return ViewMEDetails('" + s_ParamOne + "','" + s_ParamTwo + "','" + s_OperationDate + "')");
                        else
                            linkButton.Attributes.Add("onclick", "return GotoStepME('" + s_ParamOne + "','" + s_ParamTwo + "','" + s_AGRMID + "')");

                        switch (s_EventName)
                        {
                            case "GrantID":
                                linkButton.Click += modificationEDLUC.lnkBtnGrantID_Click;
                                break;

                            case "VestSchedule":
                                if (!string.IsNullOrEmpty(s_ParamOne))
                                {
                                    linkButton.Attributes.Add("onclick", "return ShowMEDetails(this)");
                                }
                                break;

                            case "IV":
                                linkButton.Click += new EventHandler(modificationEDLUC.lnkBtnIntrinsicValue_Click);
                                break;

                            case "FV":
                                linkButton.Click += new EventHandler(modificationEDLUC.lnkBtnFairValue_Click);
                                break;

                            case "GotoStepME":
                                linkButton.Text = s_ParamOne.Equals("Locked") ? s_ParamOne : s_ControlText;
                                linkButton.ToolTip = s_ParamOne.Equals("Locked") ? s_ControlText : s_ControlText + " for " + s_ParamOne;
                                linkButton.Click += new EventHandler(modificationEDLUC.lnkBtnGotoStepME_Click);
                                break;
                        }
                        return linkButton;
                }
                return new Control();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Merge the Group Number and Status Fielda of selected Grants
        /// </summary>
        /// <param name="gvModEDL">GridView gvModEDL</param>
        /// <param name="e">e</param>
        /// <param name="n_Status">int n_Status Report Status</param>
        /// <param name="n_RowIndex">int n_RowIndex GridView RowIndex</param>
        /// <param name="n_Count">int n_Count Count varible</param>
        private void MergeCells(GridView gvModEDL, GridViewRowEventArgs e, int n_Status, ref int n_RowIndex, ref int n_Count)
        {
            try
            {
                for (int intLoop = 1; intLoop <= e.Row.RowIndex; intLoop++)
                {
                    n_Count++;
                    if ((!gvModEDL.Rows[e.Row.RowIndex - intLoop].Cells[10].Text.Equals(string.Empty)) && (e.Row.Cells[10].Text == gvModEDL.Rows[e.Row.RowIndex - intLoop].Cells[10].Text))
                    {
                        n_RowIndex = intLoop;
                        break;
                    }
                }

                if (e.Row.Cells[10].Text == gvModEDL.Rows[e.Row.RowIndex - n_RowIndex].Cells[10].Text)
                {
                    e.Row.Cells[10].Text = e.Row.Cells[n_Status].Text = "";
                    e.Row.Cells[10].Visible = e.Row.Cells[n_Status].Visible = false;
                    gvModEDL.Rows[e.Row.RowIndex - n_RowIndex].Cells[10].RowSpan = gvModEDL.Rows[e.Row.RowIndex - n_RowIndex].Cells[n_Status].RowSpan = n_Count;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The method to add Vest Details GridView within Main Grant(s) GridView
        /// </summary>
        /// <param name="sender">Parent GridView</param>
        /// <param name="e">e</param>
        /// <param name="s_GrantID">string s_GrantID Grant ID</param>
        /// <param name="n_VestIndex">int n_VestIndex Vest Index</param>
        /// <param name="n_VestID">int n_VestID Vest ID</param>
        /// <param name="n_VestAction">int n_VestAction Vest Action</param>
        /// <param name="n_VestGrantDate">int n_VestGrantDate Vest Date</param>
        /// <param name="n_rowIndex">int n_rowIndex RowIndex of GridView</param>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        internal void AddChildGrid(object sender, GridViewRowEventArgs e, string s_GrantID, ref int n_VestIndex, ref int n_VestID, ref int n_VestAction, ref int n_VestGrantDate, ref int n_rowIndex, ModificationEDLUC modificationEDLUC)
        {
            try
            {
                try
                {
                    GridView parentGrid = (GridView)sender;

                    using (GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert))
                    {
                        NewTotalRow.Font.Bold = true;
                        NewTotalRow.CssClass = "gridItems  gvChildGrid";
                        NewTotalRow.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                        NewTotalRow.BackColor = System.Drawing.ColorTranslator.FromHtml("#EBF5FF");

                        using (TableCell HeaderCell = new TableCell())
                        {
                            HeaderCell.Attributes.Add("Class", "gvChildGrid");
                            HeaderCell.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                            HeaderCell.Height = 10;
                            HeaderCell.HorizontalAlign = HorizontalAlign.Center;
                            HeaderCell.ColumnSpan = 9;

                            using (GridView childGrid = new GridView())
                            {
                                childGrid.CssClass = "Grid";
                                childGrid.RowStyle.CssClass = "gridItems";
                                childGrid.CellPadding = 3;
                                childGrid.CellSpacing = 0;
                                childGrid.HeaderStyle.CssClass = "HeaderStyle";
                                childGrid.ID = "childGrid_" + n_rowIndex;
                                n_VestIndex = n_VestID = n_VestAction = n_VestGrantDate = 0;

                                childGrid.RowDataBound += modificationEDLUC.gvchildGrid_RowDataBound;
                                childGrid.DataSource = ac_SearchGrantDetails.dt_all_Grants != null && ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 ? new System.Data.DataView(ac_SearchGrantDetails.dt_all_Grants).ToTable("DT", true, new string[] { "ID", "Grant Registration ID", "Vesting Period Number", "Vesting Date", "Expiry Date", "Vest Percent (%)", "Currency", "Fair Value per vest", "Intrinsic Value per vest", "Action", "OPERATION_ID" }).Copy().Select("OPERATION_ID = 2 OR OPERATION_ID = 3 AND [Grant Registration ID]='" + s_GrantID + "'").CopyToDataTable() : ac_SearchGrantDetails.dt_all_Grants != null && ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0 ? new System.Data.DataView(ac_SearchGrantDetails.dt_all_Grants).ToTable("DT", true, new string[] { "ID", "Grant Registration ID", "Vesting Period Number", "Vesting Date", "Expiry Date", "Vest Percent (%)", "Currency", "Fair Value per vest", "Intrinsic Value per vest", "Action", "OPERATION_ID" }).Copy().Select("OPERATION_ID = 2 OR OPERATION_ID = 3 AND [Grant Registration ID]='" + s_GrantID + "'").CopyToDataTable() : null;
                                childGrid.DataBind();

                                HeaderCell.Controls.Add(childGrid);
                                NewTotalRow.Cells.Add(HeaderCell);
                                parentGrid.Controls[0].Controls.AddAt(e.Row.RowIndex + 1 + n_rowIndex, NewTotalRow);
                                n_rowIndex++;
                            }
                        }
                    }
                }
                catch
                {
                    throw;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The View Button Click Event and also performs View Button Functionality and Reset Button Functionality
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        internal void btnMEVeiw_Click(ModificationEDLUC modificationEDLUC)
        {
            try
            {
                DataTable dt_ModEDLGrants = null, dt_FilterModEDL = null;

                using (dt_ModEDLGrants = ac_SearchGrantDetails.dt_ModEDLGrants != null && ac_SearchGrantDetails.dt_ModEDLGrants.Rows.Count > 0 ? ac_SearchGrantDetails.dt_ModEDLGrants.Copy() : new DataTable())
                {
                    if (dt_ModEDLGrants.Rows.Count > 0 && dt_ModEDLGrants != null)
                    {
                        DataRow[] dr_SelectIndex = dt_ModEDLGrants.Select("OPERATION_DATE = '" + modificationEDLUC.ddlMESelectModEDL.SelectedItem.Text.ToString() + "'" + "and OPERATION_ID ='" + Convert.ToInt32(modificationEDLUC.ddlMETypeOfOperation.SelectedItem.Text.Equals("Modification") ? 3 : 2) + "'").Count() > 0 ? dt_ModEDLGrants.Select("OPERATION_DATE = '" + modificationEDLUC.ddlMESelectModEDL.SelectedItem.Text.ToString() + "'" + "and OPERATION_ID ='" + Convert.ToInt32(modificationEDLUC.ddlMETypeOfOperation.SelectedItem.Text.Equals("Modification") ? 3 : 2) + "'") : null;

                        if (dt_ModEDLGrants != null && dt_ModEDLGrants.Rows.Count > 0 && dr_SelectIndex != null)
                        {
                            dt_ModEDLGrants = dt_ModEDLGrants.Select("OPERATION_DATE ='" + modificationEDLUC.ddlMESelectModEDL.SelectedItem.Text + "'" + "and OPERATION_ID='" + Convert.ToInt32(dr_SelectIndex[0].ItemArray[15].ToString()) + "'").Distinct().CopyToDataTable();
                            var v_groupedData = dt_ModEDLGrants.AsEnumerable().GroupBy(item => item.Field<string>("Grant Registration ID"));
                            var v_SortedData = v_groupedData.Select(grp => grp.OrderBy(item => item.Field<string>("Grant Date")).First());
                            dt_FilterModEDL = v_SortedData.CopyToDataTable();
                        }

                        modificationEDLUC.gvModEDL.DataSource = dt_FilterModEDL;
                        modificationEDLUC.gvModEDL.DataBind();

                        modificationEDLUC.btnMEReprocess.Visible = dt_FilterModEDL != null && dt_FilterModEDL.Rows.Count > 0;
                        modificationEDLUC.btnMEReset.Visible = modificationEDLUC.hdnMEDropDownIndexChanged.Value.Equals("Set") ? true : false;

                        ac_SearchGrantDetails.s_ModEDLset = "Set";
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The ViewAll Button Click Event to Open SSRS Report for Modification/EDL
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        internal void btnMEViewAll_Click(ModificationEDLUC modificationEDLUC)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    modificationEDLUC.hdnMEReportParams.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=9").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                    modificationEDLUC.hdnMEReportParams.Dispose();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Grant ID LinkButton Pop up to show parameters
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        internal void GetValuationParameters(ModificationEDLUC modificationEDLUC)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameters;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    modificationEDLUC.lblMENote.Visible = false;
                    modificationEDLUC.lblMEManuallyEntered.Visible = false;
                    modificationEDLUC.lblMEDiffrentThanCompLevel.Visible = false;

                    using (GetValuationParameters getValuationParameters = new GetValuationParameters())
                    {
                        using (DataTable dt_ValuationParameter = getValuationParameters.CreateDataTable("SelectGrants"))
                        {
                            dt_ValuationParameter.TableName = "dtValuationParameter";

                            modificationEDLUC.gvMEValuationParameters.DataSource = getValuationParameters.CreateValuationParamDataTable(valuationServiceClient, dt_ValuationParameter, valuationCRUDProperties.ds_Result, modificationEDLUC.hdnMEGrantID.Value);
                            modificationEDLUC.gvMEValuationParameters.DataBind();

                            modificationEDLUC.gv2ME.Visible = false;
                            modificationEDLUC.gvMEValuationParameters.Visible = true;

                            modificationEDLUC.hdnMEShowGrid.Value = "1";
                        }
                    }
                    modificationEDLUC.lblMEViewDocument.Text = Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblValuationParameters'"))[0]["LabelName"]);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Row DataBound Event of child GridView within Parent GridView
        /// </summary>
        /// <param name="e">e</param>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        /// <param name="n_VestIndex">int n_VestIndex Vest Index</param>
        /// <param name="n_VestID">int n_VestID Vest ID</param>
        /// <param name="n_VestAction">int n_VestAction Vest Action</param>
        /// <param name="n_VestGrantDate">int n_VestGrantDate Vest Date</param>
        /// <param name="n_VestPercent">int n_VestPercent Vest Percent</param>
        /// <param name="n_FairValVest">int n_FairValVest Fair Value Per vest</param>
        /// <param name="n_IntrsicValVest">int n_IntrsicValVest Intrinsic Value Per Vest</param>
        /// <param name="n_VestOptID">int n_VestOptID Vest Operation ID</param>
        internal void gvchildGrid_RowDataBound(GridViewRowEventArgs e, ModificationEDLUC modificationEDLUC, ref int n_VestIndex, ref int n_VestID, ref int n_VestAction, ref int n_VestGrantDate, ref int n_VestPercent, ref int n_FairValVest, ref int n_IntrsicValVest, ref int n_VestOptID)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    n_VestID = n_VestIndex;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    n_VestAction = n_VestIndex;
                                    perColumn.Visible = false;
                                    break;

                                case "VEST PERCENT (%)":
                                    n_VestPercent = n_VestIndex;
                                    break;

                                case "FAIR VALUE PER VEST":
                                    n_FairValVest = n_VestIndex;
                                    break;

                                case "INTRINSIC VALUE PER VEST":
                                    n_IntrsicValVest = n_VestIndex;
                                    break;

                                case "OPERATION_ID":
                                    n_VestOptID = n_VestIndex;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_VestIndex = n_VestIndex + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_VestID].Visible = e.Row.Cells[n_VestOptID].Visible = e.Row.Cells[n_VestAction].Visible = false;

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.

                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {

                            e.Row.Cells[n_VestPercent].Text = e.Row.Cells[n_VestPercent].Text.Equals("&nbsp;") ? string.Empty : Convert.ToDouble(e.Row.Cells[n_VestPercent].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_VestPercent].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_VestPercent].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            e.Row.Cells[n_VestPercent].HorizontalAlign = HorizontalAlign.Right;

                            if (!e.Row.Cells[n_FairValVest].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_FairValVest].Text = Convert.ToDouble(e.Row.Cells[n_FairValVest].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_FairValVest].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_FairValVest].Text, DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_FairValVest].HorizontalAlign = HorizontalAlign.Right;
                            }


                            if (!e.Row.Cells[n_IntrsicValVest].Text.Equals("&nbsp;"))
                            {
                                e.Row.Cells[n_IntrsicValVest].Text = Convert.ToDouble(e.Row.Cells[n_IntrsicValVest].Text) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[n_IntrsicValVest].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(e.Row.Cells[n_IntrsicValVest].Text, DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[n_IntrsicValVest].HorizontalAlign = HorizontalAlign.Right;
                            }

                        }
                        #endregion
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Row Bound of gv2ME GridView
        /// </summary>
        /// <param name="e">e</param>
        /// <param name="n_index">int n_index</param>
        /// <param name="n_DatList">int n_DatList Variable Index</param>
        /// <param name="n_MarketValue">int n_MarketValue Variable Index</param>
        internal void gv2ME_RowDataBound(GridViewRowEventArgs e, ref int n_index, ref int n_DatList, ref int n_MarketValue)
        {
            try
            {
                string s_roundingLimit = string.Empty;
                using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                {
                    for (int i = 0; i < e.Row.Cells.Count; i++)
                    {
                        try
                        {
                            s_roundingLimit = e.Row.Cells[0].Text.Contains("Intrinsic Value") ? "1" : e.Row.Cells[0].Text.Contains("Fair Value") ? "2" : e.Row.Cells[0].Text.Contains("Market Price") ? "3" : e.Row.Cells[0].Text.Contains("Exercise Price") ? "4" : e.Row.Cells[0].Text.Contains("Expected Life ") ? "5" : e.Row.Cells[0].Text.Contains("Volatility") ? "6" : e.Row.Cells[0].Text.Contains("Riskfree Rate") ? "7" : e.Row.Cells[0].Text.Contains("Dividend yield") ? "8" : "11";

                            e.Row.Cells[i].Text = e.Row.Cells[i].Text;

                            if (Convert.ToDouble(e.Row.Cells[i].Text) > 999)
                            {

                                e.Row.Cells[i].Text = CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[i].Text, DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Right;

                            }
                            else
                                e.Row.Cells[i].Text = CommonModel.GetRoundedValue(e.Row.Cells[i].Text, DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Right;
                        }
                        catch
                        {
                            // Do nothing
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Row Data Bound event of gvMEValuationParameters GridView
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        /// <param name="e">e</param>
        /// <param name="n_CompanyLevel">int n_CompanyLevel Parameter Index</param>
        /// <param name="n_GrantLevel">int n_GrantLevel Parameter Index</param>
        /// <param name="n_ValIndex">int n_ValIndex Parameter Index</param>
        /// <param name="n_ManuallyUploaded">int n_ManuallyUploaded Parameter Index</param>
        internal void gvMEValuationParameters_RowDataBound(ModificationEDLUC modificationEDLUC, GridViewRowEventArgs e, ref int n_CompanyLevel, ref int n_GrantLevel, ref int n_ValIndex, ref int n_ManuallyUploaded)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "COMPANY LEVEL":
                                    n_CompanyLevel = n_ValIndex;
                                    break;

                                case "PRESENT GRANT PARAMETERS":
                                    n_GrantLevel = n_ValIndex;
                                    break;

                                case "IS MANUAL UPLOADED":
                                    n_ManuallyUploaded = n_ValIndex;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_ValIndex = n_ValIndex + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:

                        BulletedList bulletedList = new BulletedList();
                        BulletedList bulletedListNote = new BulletedList();

                        e.Row.Cells[n_ManuallyUploaded].Visible = false;

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_GrantLevel].Text) && !e.Row.Cells[n_GrantLevel].Text.Equals("&nbsp;") && !e.Row.Cells[n_GrantLevel].Text.Equals(e.Row.Cells[n_CompanyLevel].Text))
                        {
                            modificationEDLUC.lblMENote.Visible = modificationEDLUC.lblMEDiffrentThanCompLevel.Visible = true;
                            modificationEDLUC.lblMEDiffrentThanCompLevel.Text = Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblDiffrentThanCompLevel'"))[0]["LabelName"]);
                            e.Row.Cells[n_GrantLevel].BackColor = System.Drawing.ColorTranslator.FromHtml("#D6FFD6");
                        }

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_GrantLevel].Text) && !e.Row.Cells[n_GrantLevel].Text.Equals("&nbsp;"))
                        {
                            bulletedList.BulletStyle = System.Web.UI.WebControls.BulletStyle.Square;
                            e.Row.Cells[n_GrantLevel].Text = e.Row.Cells[n_GrantLevel].Text.Contains("&#39;") ? e.Row.Cells[n_GrantLevel].Text.Replace("&#39;", "'") : e.Row.Cells[n_GrantLevel].Text;
                            bulletedList.DataSource = e.Row.Cells[n_GrantLevel].Text.Split(',');
                            bulletedList.DataBind();
                            e.Row.Cells[n_GrantLevel].Controls.Add(bulletedList);
                        }

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_CompanyLevel].Text) && !e.Row.Cells[n_CompanyLevel].Text.Equals("&nbsp;"))
                        {
                            bulletedList = new BulletedList();
                            bulletedList.BulletStyle = System.Web.UI.WebControls.BulletStyle.Square;
                            e.Row.Cells[n_CompanyLevel].Text = e.Row.Cells[n_CompanyLevel].Text.Contains("&#39;") ? e.Row.Cells[n_CompanyLevel].Text.Replace("&#39;", "'") : e.Row.Cells[n_CompanyLevel].Text;
                            bulletedList.DataSource = e.Row.Cells[n_CompanyLevel].Text.Split(',');
                            bulletedList.DataBind();
                            e.Row.Cells[n_CompanyLevel].Controls.Add(bulletedList);
                        }
                        if (!string.IsNullOrEmpty(e.Row.Cells[n_ManuallyUploaded].Text) && e.Row.Cells[n_ManuallyUploaded].Text.Equals("True"))
                        {
                            modificationEDLUC.lblMENote.Visible = modificationEDLUC.lblMEManuallyEntered.Visible = true;
                            modificationEDLUC.lblMEManuallyEntered.Text = Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblManuallyEntered'"))[0]["LabelName"]);
                            e.Row.Cells[n_GrantLevel].BackColor = System.Drawing.ColorTranslator.FromHtml("#E0F0FF");
                            e.Row.Cells[n_GrantLevel].Text = "Manually entered data";

                        }
                        if (string.IsNullOrEmpty(e.Row.Cells[n_GrantLevel].Text) || e.Row.Cells[n_GrantLevel].Text.Equals("&nbsp;"))
                        {
                            e.Row.Cells[n_GrantLevel].Text = "Same as company level";
                        }
                        bulletedList.Dispose();
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind IV / FV pop up
        /// </summary>
        /// <param name="s_FVIV">string s_FVIV whether FV or IV</param>
        /// <param name="n_OptID">int n_OptID Operation ID</param>
        /// <param name="s_OperationDate">string s_OperationDate Operation Date</param>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        internal void BindIVFV(string s_FVIV, int n_OptID, string s_OperationDate, ModificationEDLUC modificationEDLUC)
        {
            try
            {
                using (ModificationEDLUCModel modificationEDLUCModel = new ModificationEDLUCModel())
                {
                    if (modificationEDLUCModel.ac_SearchGrantDetails.dt_ModEDLGrants.Rows.Count > 0)
                    {
                        modificationEDLUCModel.ac_SearchGrantDetails.dt_all_Grants = GetModEDLData(modificationEDLUC);

                        DataTable dataTable = modificationEDLUCModel.ac_SearchGrantDetails.dt_all_Grants.Select("[Grant Registration ID] = '" + modificationEDLUC.hdnMEGrantID.Value + "'" + "and OPERATION_ID = '" + n_OptID + "'" + "and OPERATION_DATE = '" + s_OperationDate + "'").CopyToDataTable();

                        using (GetValuationParameters getValuationParameters = new GetValuationParameters())
                        {
                            using (DataTable outputTable = getValuationParameters.GetCalculationsIVnFV(ref dataTable, s_FVIV))
                            {
                                modificationEDLUC.lblMEViewDocument.Text = s_FVIV.Equals("FairValue") ? Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblFairValueDetails'"))[0]["LabelName"]) :
                                                                              Convert.ToString((ac_SearchGrantDetails.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblIntrinsicValueDetails'"))[0]["LabelName"]);

                                modificationEDLUC.gv2ME.Visible = true;
                                modificationEDLUC.gvMEValuationParameters.Visible = false;
                                modificationEDLUC.lblMENote.Visible = false;
                                modificationEDLUC.lblMEManuallyEntered.Visible = false;
                                modificationEDLUC.lblMEDiffrentThanCompLevel.Visible = false;

                                modificationEDLUC.gv2ME.DataSource = outputTable;
                                modificationEDLUC.gv2ME.DataBind();

                                modificationEDLUCModel.ac_SearchGrantDetails.s_StepNumber = "0";
                                modificationEDLUC.hdnMEShowGrid.Value = "1";
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Reprocess Button Click Event
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        internal void btnMEReprocess_Click(ModificationEDLUC modificationEDLUC)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    bool b_IsGrpNoExists = false;
                    if (!modificationEDLUC.hdnMEProceed.Value.Equals("True"))
                    {
                        foreach (var item in modificationEDLUC.hdnMESelectedGrants.Value.ToString().TrimStart(',').Split(','))
                        {
                            foreach (DataRow perRow in ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'"))
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(perRow["Group Number"])) && !Convert.ToString(perRow["Group Number"]).Equals("0"))
                                {
                                    b_IsGrpNoExists = true;
                                    ScriptManager.RegisterStartupScript(modificationEDLUC, GetType(), "alertMessage", "if (confirm('" + valuationServiceClient.GetValuation_L10N("lblReCreateGroup", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10) + "')){ document.getElementById('hdnMEProceed').value = 'True'; document.getElementById('btnMEReprocess').click();  } else { document.getElementById('hdnMEProceed').value = 'False';  document.getElementById('hdnMESelectedGrants').value = '';}", true);
                                }
                            }
                        }
                    }

                    modificationEDLUC.hdnMEProceed.Value = b_IsGrpNoExists.ToString();

                    if (!modificationEDLUC.hdnMEProceed.Value.Equals("True"))
                    {
                        modificationEDLUC.hdnMEProceed.Value = "False";

                        valuationProperties.PageName = CommonConstantModel.s_WorkflowStatus;
                        valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        valuationProperties.AWFID = 2;
                        valuationProperties.GrantDetailsIDList = modificationEDLUC.hdnMESelectedGrants.Value.TrimStart(',');

                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        ac_SearchGrantDetails.s_StepNumber = "2";

                        ac_SearchGrantDetails.s_SelectedGrants = string.Empty;
                        ac_SearchGrantDetails.s_SelectedGrants = modificationEDLUC.hdnMESelectedGrants.Value;
                        modificationEDLUC.hdnMESelectedGrants.Value = string.Empty;
                        modificationEDLUC.hdnbtnMEProceed.Value = "True";
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Status Link Button Click Event to gor to the respective step of Grant(s) to process it
        /// </summary>
        /// <param name="modificationEDLUC">modificationEDLUC Page Object</param>
        internal void lnkBtnGotoStepME_Click(ModificationEDLUC modificationEDLUC)
        {
            try
            {
                switch (modificationEDLUC.hdnMEGDStepNumber.Value)
                {
                    case "Select Grant":
                        ac_SearchGrantDetails.s_StepNumber = "0";
                        break;

                    case "Compare Grant":
                        ac_SearchGrantDetails.s_StepNumber = "1";
                        break;

                    case "Select Template":
                        ac_SearchGrantDetails.s_StepNumber = "2";
                        break;

                    case "Download and Send for Review":
                        ac_SearchGrantDetails.s_StepNumber = "3";
                        break;

                    case "Reviewer Feedback":
                        ac_SearchGrantDetails.s_StepNumber = userSessionInfo.ACC_UerTypeID.Equals(5) ? "4" : "3";
                        break;

                    case "Final Report":
                        ac_SearchGrantDetails.s_StepNumber = "5";
                        break;

                    case "Locked":
                        ac_SearchGrantDetails.s_StepNumber = "5";
                        break;
                }

                using (ac_SearchGrantDetails.dt_all_Grants = GetModEDLData(modificationEDLUC))
                {
                    ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report = ac_SearchGrantDetails.dt_main_Unlocked_Valuation_Report = ac_SearchGrantDetails.dt_all_Grants.Select("Is_Locked = 0").Count() > 0 ? ac_SearchGrantDetails.dt_all_Grants.Select("Is_Locked = 0").CopyToDataTable() : null;
                    ac_SearchGrantDetails.dt_temp_Locked_Valuation_Report = ac_SearchGrantDetails.dt_main_Locked_Valuation_Report = ac_SearchGrantDetails.dt_all_Grants.Select("Is_Locked = 1").Count() > 0 ? ac_SearchGrantDetails.dt_all_Grants.Select("Is_Locked = 1 ").CopyToDataTable() : null;

                    Int32[] n_GroupId = ac_SearchGrantDetails.dt_all_Grants.AsEnumerable()
                                            .Where(s => s.Field<string>("Status") == modificationEDLUC.hdnMEGDStepNumber.Value && s.Field<string>("Grant Registration ID") == modificationEDLUC.hdnMEGrantID.Value && s.Field<int>("AGRMID") == Convert.ToInt32(modificationEDLUC.hdnMEAGRMID.Value))
                                            .Select(s => s.Field<Int32>("Group Number"))
                                            .ToArray();
                    Int32[] n_SelectedGrants = ac_SearchGrantDetails.dt_all_Grants.AsEnumerable()
                                                    .Where(s => s.Field<Int32>("Group Number") == n_GroupId[0])
                                                    .Select(s => s.Field<Int32>("AGRMID")).Distinct()
                                                    .ToArray();
                    ac_SearchGrantDetails.s_SelectedGrants = string.Join(",", n_SelectedGrants);
                }
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ModificationEDLUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}