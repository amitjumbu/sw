﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// DownloadAddins Model class
    /// </summary>
    public class DownloadAddinsModel : BaseModel, IDisposable
    {
        /// <summary>
        /// This is used to bind all the controls
        /// </summary>
        /// <param name="downloadAddins">DownloadAddins page object</param>
        public void BindControls(DownloadAddins downloadAddins)
        {
            BindUI(downloadAddins);
            downloadAddins.gv.DataSource = GetAddins();
            downloadAddins.gv.DataBind();
        }

        /// <summary>
        /// This method is used to bind UI from xml
        /// </summary>
        /// <param name="downloadAddins">DownloadAddins page object</param>
        private void BindUI(DownloadAddins downloadAddins)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (DataTable dt_DownloadAddinsUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_DownloadAddins, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if ((dt_DownloadAddinsUI != null) && (dt_DownloadAddinsUI.Rows.Count > 0))
                        {
                            downloadAddins.lblDAHeader.Text = Convert.ToString(dt_DownloadAddinsUI.Select("LabelID = 'lblDAHeader'")[0]["LabelName"]);
                            downloadAddins.gv.EmptyDataText = Convert.ToString(dt_DownloadAddinsUI.Select("LabelID = 'gvDAEmptyDataText'")[0]["LabelName"]);
                            downloadAddins.lblAddInNotes.Text = Convert.ToString(dt_DownloadAddinsUI.Select("LabelID = 'lblAddInNotes'")[0]["LabelName"]).Replace("~", "</br>").Replace("^", "</br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// TThis method is used to get all the add-ins from specified folder 
        /// </summary>
        /// <returns>returns dataTable - list of all add-ins</returns>
        private DataTable GetAddins()
        {
            using (DataTable dt_Addins = new DataTable())
            {
                dt_Addins.Columns.Add("Sr. No.", typeof(string));
                dt_Addins.Columns.Add("Add-in", typeof(string));
                dt_Addins.Columns.Add("Download", typeof(string));
                dt_Addins.Columns.Add("FilePath", typeof(string));

                if (Directory.Exists(ConfigurationManager.AppSettings["AddInnsPath"]))
                {
                    int n_SrNo = 0;

                    foreach (string perFile in Directory.GetFiles(ConfigurationManager.AppSettings["AddInnsPath"]))
                    {
                        dt_Addins.Rows.Add(Convert.ToString(n_SrNo + 1), Path.GetFileName(perFile), "Download", perFile);
                        n_SrNo++;
                    }
                }
                return dt_Addins;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid-view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="n_index">index</param>
        /// <param name="n_Download">download</param>
        /// <param name="n_FileName">file name</param>
        /// <param name="n_FilePath">file path</param>
        /// <param name="n_SrNo">n_SrNo</param>
        public void gv_RowDataBound(GridViewRowEventArgs e, ref int n_index, ref int n_Download, ref int n_FileName, ref int n_FilePath, ref int n_SrNo)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SR. NO.":
                                    n_SrNo = n_index;
                                    break;
                                case "ADD-IN":
                                    n_FileName = n_index;
                                    break;
                                case "DOWNLOAD":
                                    n_Download = n_index;
                                    break;
                                case "FILEPATH":
                                    n_FilePath = n_index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_SrNo].HorizontalAlign = e.Row.Cells[n_Download].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_FilePath].Visible = false;
                        e.Row.Cells[n_SrNo].Width = 100;
                        e.Row.Cells[n_Download].Controls.Add((Control)AddImageLink(e.Row.Cells[n_FileName].Text, e.Row.Cells[n_FilePath].Text));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_FileName">File name</param>
        /// <param name="s_ServerPath">file path</param>
        /// <returns>returns image object</returns>
        private ImageButton AddImageLink(string s_FileName, string s_ServerPath)
        {
            using (ImageButton img = new ImageButton())
            {
                img.ImageUrl = "~/View/App_Themes/images/download.png";
                img.ToolTip = "Click here to download";
                img.Style.Add("cursor", "pointer");
                img.TabIndex = 8;
                img.Attributes.Add("onclick", "return SetHiddenFields('" + s_ServerPath.Replace("\\", "~") + "','" + s_FileName + "')");
                return img;
            }
        }

        /// <summary>
        /// This method is used to download file from server folder
        /// </summary>
        /// <param name="downloadAddins">DownloadAddins page object</param>
        public void DownloadFile(DownloadAddins downloadAddins)
        {
            try
            {
                using (WebClient o_WebClient = new WebClient())
                {
                    HttpResponse o_HttpResponse = HttpContext.Current.Response;
                    o_HttpResponse.Clear();
                    o_HttpResponse.ClearContent();
                    o_HttpResponse.ClearHeaders();
                    o_HttpResponse.Buffer = true;
                    downloadAddins.Response.AddHeader("Content-Disposition", "attachment;filename=" + downloadAddins.hdnFileName.Value);
                    o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(downloadAddins.hdnFileServerPath.Value.Replace("~", "\\")));
                    // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.Flush();
                    // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.Response.SuppressContent = true;
                    // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch
            {
                // Do Nothing
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~DownloadAddinsModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}