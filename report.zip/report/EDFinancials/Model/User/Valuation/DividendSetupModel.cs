﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class DividendSetupModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public DividendSetupModel()
        {
            if(ac_DividendSetUp == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_DividendSetUp);
                ac_DividendSetUp = (CommonModel.AC_DividendSetUp)HttpContext.Current.Session[CommonConstantModel.s_AC_DividendSetUp];
            }
        }

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="dividendSetupUI">View.User.Valuation.DividendSetup</param>
        internal void ReadL10N_UI(DividendSetup dividendSetupUI)
        {
            try
            {
                using(ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using(DataTable dt_valuationL10N_UI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if((dt_valuationL10N_UI != null) && (dt_valuationL10N_UI.Rows.Count > 0))
                        {
                            dividendSetupUI.lblDSFincYear.Text = dividendSetupUI.lblDSFinancialYear.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSFincYear'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSFincYear.ToolTip = dividendSetupUI.lblDSFinancialYear.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSFincYear'"))[0]["LabelToolTip"]);

                            dividendSetupUI.btnDSApplyFilter.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSApplyFilter'"))[0]["LabelName"]);
                            dividendSetupUI.btnDSApplyFilter.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSApplyFilter'"))[0]["LabelToolTip"]);

                            dividendSetupUI.btnDSClearFilter.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSClearFilter'"))[0]["LabelName"]);
                            dividendSetupUI.btnDSClearFilter.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSClearFilter'"))[0]["LabelToolTip"]);

                            dividendSetupUI.btnDSCreateNew.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSCreateNew'"))[0]["LabelName"]);
                            dividendSetupUI.btnDSCreateNew.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSCreateNew'"))[0]["LabelToolTip"]);

                            dividendSetupUI.btnDSDelete.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSDelete'"))[0]["LabelName"]);
                            dividendSetupUI.btnDSDelete.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSDelete'"))[0]["LabelToolTip"]);

                            dividendSetupUI.lblDSAnnouncementDate.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSAnnouncementDate'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSAnnouncementDate.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSAnnouncementDate'"))[0]["LabelToolTip"]);
                            dividendSetupUI.reqDSAnnouncementDate.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSAnnouncementDate'"))[0]["ErrorText"]);
                            dividendSetupUI.regexValAnnounceDate.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'regexValAnnounceDate'"))[0]["LabelToolTip"]);

                            dividendSetupUI.lblDSSearchAnnDate.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSAnnouncementDate'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSSearchAnnDate.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSAnnouncementDate'"))[0]["LabelToolTip"]);

                            dividendSetupUI.lblDSEffectiveDate.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSEffectiveDate'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSEffectiveDate.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSEffectiveDate'"))[0]["LabelToolTip"]);
                            dividendSetupUI.reqDSEffectiveDate.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSEffectiveDate'"))[0]["ErrorText"]);
                            dividendSetupUI.regexEffectiveDate.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'regexEffectiveDate'"))[0]["LabelToolTip"]);

                            dividendSetupUI.lblDSSearchEffDate.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSEffectiveDate'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSSearchEffDate.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSEffectiveDate'"))[0]["LabelToolTip"]);

                            dividendSetupUI.lblDSDividendType.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendType'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSDividendType.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendType'"))[0]["LabelToolTip"]);
                            dividendSetupUI.reqDSDividendType.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendType'"))[0]["ErrorText"]);

                            dividendSetupUI.lblDSSearchDivType.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendType'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSSearchDivType.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendType'"))[0]["LabelToolTip"]);

                            dividendSetupUI.lblDSDividendPerShare.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendPerShare'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSDividendPerShare.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendPerShare'"))[0]["LabelToolTip"]);
                            dividendSetupUI.reqDivPerShr.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendPerShare'"))[0]["ErrorText"]);

                            dividendSetupUI.lblDSDividendPercentage.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendPercentage'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSDividendPercentage.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendPercentage'"))[0]["LabelToolTip"]);
                            dividendSetupUI.reqDSDividendPercentage.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSDividendPercentage'"))[0]["ErrorText"]);
                            dividendSetupUI.regexPercentage.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'regexPercentage'"))[0]["LabelToolTip"]);

                            dividendSetupUI.lblDSRemark.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSRemark'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSRemark.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSRemark'"))[0]["LabelToolTip"]);

                            dividendSetupUI.btnDSSave.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSSave'"))[0]["LabelName"]);
                            dividendSetupUI.btnDSSave.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSSave'"))[0]["LabelToolTip"]);

                            dividendSetupUI.btnDSCancel.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSCancel'"))[0]["LabelName"]);
                            dividendSetupUI.btnDSCancel.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'btnDSCancel'"))[0]["LabelToolTip"]);

                            dividendSetupUI.lblDSHeader1.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSHeader1'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSHeader2.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSHeader2'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSHeader3.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSHeader3'"))[0]["LabelName"]);

                            dividendSetupUI.lblDSCurrencyName.Text = dividendSetupUI.lblDSSearchCurrency.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSCurrencyName'"))[0]["LabelName"]);
                            dividendSetupUI.lblDSCurrencyName.ToolTip = dividendSetupUI.lblDSSearchCurrency.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSCurrencyName'"))[0]["LabelToolTip"]);
                            dividendSetupUI.reqCurrencyName.ToolTip = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblDSCurrencyName'"))[0]["ErrorText"]);

                            dividendSetupUI.btnBackToGD.Text = Convert.ToString(dt_valuationL10N_UI.Select("LabelID = 'btnBackToGD'")[0]["LabelName"]);
                            dividendSetupUI.btnBackToGD.ToolTip = Convert.ToString(dt_valuationL10N_UI.Select("LabelID = 'btnBackToGD'")[0]["LabelToolTip"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  Method to check employee role privileges
        /// </summary>
        /// <param name="dividendSetupUI">Page object</param>
        public void CheckEmployeeRolePriviledges(View.User.Valuation.DividendSetup dividendSetupUI)
        {
            userSessionInfo = SessionContext.GetUserSessionInfoValues();
            GenericProperties genericProperties = new GenericProperties();
            genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
            genericProperties.PageName = CommonConstantModel.s_MnuDividendSetup;
            genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
            using(DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
            {
                if(dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                {
                    foreach(DataRow rowPriviledge in dt_RolePerviledges.Rows)
                    {
                        switch(Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                        {
                            case "VIEW":
                                dividendSetupUI.btnDSSave.Enabled = false;
                                dividendSetupUI.btnDSCreateNew.Enabled = false;
                                dividendSetupUI.btnDSDelete.Enabled = false;
                                break;

                            case "ADD":
                                dividendSetupUI.btnDSCreateNew.Enabled = true;
                                dividendSetupUI.btnDSSave.Enabled = true;
                                break;

                            case "EDIT":
                                ac_DividendSetUp.b_IsEditRights = true;
                                break;

                            case "DELETE":
                                dividendSetupUI.btnDSDelete.Enabled = true;
                                break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// This method is used to Read data
        /// </summary>
        /// <param name="dividendSetupUI">DividendSetupUI</param>
        internal void ReadDividendSetup(DividendSetup dividendSetupUI)
        {
            try
            {
                using(ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.PageName = CommonConstantModel.s_DividendSetup;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    if(dividendSetupUI.hdnIsBindDropdown.Value.Equals("0"))
                    {

                        dividendSetupUI.ddlDSDividendType.DataSource = dividendSetupUI.ddlDSSearchDivType.DataSource = valuationCRUDProperties.ds_Result.Tables["Table1"];
                        dividendSetupUI.ddlDSDividendType.DataTextField = dividendSetupUI.ddlDSSearchDivType.DataTextField = "DATATEXTFIELD";
                        dividendSetupUI.ddlDSDividendType.DataValueField = dividendSetupUI.ddlDSSearchDivType.DataValueField = "DATAVALUEFIELD";

                        dividendSetupUI.ddlDSSearchDivType.DataBind();
                        dividendSetupUI.ddlDSDividendType.DataBind();
                    }
                    dividendSetupUI.ddlDSCurrencyName.DataSource = dividendSetupUI.ddlDSSearchCurrency.DataSource = valuationCRUDProperties.ds_Result.Tables["Table2"];
                    dividendSetupUI.ddlDSCurrencyName.DataTextField = dividendSetupUI.ddlDSSearchCurrency.DataTextField = dividendSetupUI.ddlDSSearchCurrency.DataValueField = "CURRENCY_NAME";
                    dividendSetupUI.ddlDSCurrencyName.DataValueField = "CRMID";
                    dividendSetupUI.ddlDSCurrencyName.DataBind();

                    dividendSetupUI.ddlDSSearchCurrency.DataBind();
                    dividendSetupUI.ddlDSSearchCurrency.Items.Insert(0, "--- Please Select ---");
                    ac_DividendSetUp.dt_temp_DividendDate = valuationCRUDProperties.ds_Result.Tables["Table"];

                    DataView dataView = new DataView(valuationCRUDProperties.ds_Result.Tables["Table"]);

                    dividendSetupUI.btnDSDelete.Visible = (valuationCRUDProperties.ds_Result.Tables["Table"] != null && valuationCRUDProperties.ds_Result.Tables["Table"].Rows.Count > 0);
                    dividendSetupUI.btnDSClearFilter.Visible = false;

                    dividendSetupUI.gv.DataSource = valuationCRUDProperties.ds_Result.Tables["Table"] != null && valuationCRUDProperties.ds_Result.Tables["Table"].Rows.Count > 0 ? dataView.ToTable("DT", false, new string[] { "ID", "Delete", "Announcement Date", "Effective Date", "From Date", "To Date", "Type", "Dividend Per Share", "Percentage", "Currency", "Remark", "Action" }).Copy() : new DataTable();
                    dividendSetupUI.gv.DataBind();


                    ac_DividendSetUp.dt_DivdFinanYr = valuationCRUDProperties.ds_Result.Tables["Table3"] != null && valuationCRUDProperties.ds_Result.Tables["Table3"].Rows.Count > 0 ? (DataTable)valuationCRUDProperties.ds_Result.Tables[3].Copy() : null;
                    dividendSetupUI.ddlDSFincYear.DataSource = dividendSetupUI.ddlDSFinancialYear.DataSource = ac_DividendSetUp.dt_DivdFinanYr.DefaultView.ToTable(true, "AFYMID", "FINC_YEAR");
                    dividendSetupUI.ddlDSFincYear.DataTextField = dividendSetupUI.ddlDSFinancialYear.DataTextField = "FINC_YEAR";
                    dividendSetupUI.ddlDSFincYear.DataValueField = dividendSetupUI.ddlDSFinancialYear.DataValueField = "AFYMID";
                    dividendSetupUI.ddlDSFincYear.DataBind();
                    dividendSetupUI.ddlDSFinancialYear.DataBind();

                    dividendSetupUI.ddlDSFincYear.SelectedIndex = dividendSetupUI.ddlDSFinancialYear.SelectedIndex = Convert.ToInt32(ac_DividendSetUp.dt_DivdFinanYr.Compute("max(AFYMID)", string.Empty)) - 15;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to apply filters
        /// </summary>
        /// <param name="dividendSetupUI">DividendSetup</param>
        /// <param name="Is_Reset">Is_Reset</param>
        public void ApplyFilters(DividendSetup dividendSetupUI, bool Is_Reset)
        {
            try
            {
                dividendSetupUI.hdnAccordionIndex.Value = "0";
                dividendSetupUI.btnDSDelete.Visible = (ac_DividendSetUp.dt_temp_DividendDate != null && ac_DividendSetUp.dt_temp_DividendDate.Rows.Count > 0);
                DataView dataView = new DataView();
                dividendSetupUI.btnDSClearFilter.Visible = true;
                DataTable temp_dt = ac_DividendSetUp.dt_temp_DividendDate;

                dividendSetupUI.btnDSDelete.Visible = ac_DividendSetUp.dt_temp_DividendDate.Rows.Count > 0;

                if(!Is_Reset)
                {
                    string s_DivType = dividendSetupUI.ddlDSSearchDivType.SelectedIndex > 0 ? "[Type] = '" + Convert.ToString(dividendSetupUI.ddlDSSearchDivType.SelectedItem.Text) + "'" : string.Empty;
                    string s_Currency = dividendSetupUI.ddlDSSearchCurrency.SelectedIndex > 0 ? "[Currency] = '" + Convert.ToString(dividendSetupUI.ddlDSSearchCurrency.SelectedItem.Text) + "'" : string.Empty;
                    string s_SearchAnnDate = string.IsNullOrEmpty(dividendSetupUI.txtDSSearchAnnDate.Text) || dividendSetupUI.txtDSSearchAnnDate.Text.Equals("dd/mmm/yyyy") ? string.Empty : dividendSetupUI.txtDSSearchAnnDate.Text;
                    string s_SearchEffDate = string.IsNullOrEmpty(dividendSetupUI.txtDSSearchEffDate.Text) || dividendSetupUI.txtDSSearchEffDate.Text.Equals("dd/mmm/yyyy") ? string.Empty : dividendSetupUI.txtDSSearchEffDate.Text;
                    string s_DateCompair = string.Empty;

                    string[] s_FincYr = dividendSetupUI.ddlDSFincYear.SelectedItem.Text.Split('-');
                    string s_FromDate = "1/Jan/" + s_FincYr[0]; string s_ToDate = "31/Dec/"  + s_FincYr[1];

                    s_DateCompair = "FINANCIAL_YEAR_FROM >= #" + Convert.ToDateTime(s_FromDate).Date + "# AND FINANCIAL_YEAR_TO <= #" + Convert.ToDateTime(s_ToDate).Date + "# ";

                    if(!string.IsNullOrEmpty(s_DivType))
                    {
                        temp_dt = temp_dt.Rows.Count != 0 && temp_dt.Select("" + s_DivType + "").Count() > 0 ? temp_dt.Select("" + s_DivType + "").CopyToDataTable() : new DataTable();
                    }
                    if(!string.IsNullOrEmpty(s_SearchAnnDate))
                    {
                        temp_dt = temp_dt.Rows.Count != 0 && temp_dt.Select("ANNOUNCEMENT_DATE = #" + Convert.ToDateTime(s_SearchAnnDate).Date + "#").Count() > 0 ? temp_dt.Select("ANNOUNCEMENT_DATE = #" + Convert.ToDateTime(s_SearchAnnDate).Date + "#").CopyToDataTable() : new DataTable();
                    }
                    if(!string.IsNullOrEmpty(s_SearchEffDate))
                    {
                        temp_dt = temp_dt.Rows.Count != 0 && temp_dt.Select("EFFECTIVE_DATE = #" + Convert.ToDateTime(s_SearchEffDate).Date + "#").Count() > 0 ? temp_dt.Select("EFFECTIVE_DATE = #" + Convert.ToDateTime(s_SearchEffDate).Date + "#").CopyToDataTable() : new DataTable();
                    }
                    if(!string.IsNullOrEmpty(s_DateCompair))
                    {
                        temp_dt = temp_dt.Rows.Count != 0 && temp_dt.Select("" + s_DateCompair + "").Count() > 0 ? temp_dt.Select("" + s_DateCompair + "").CopyToDataTable() : new DataTable();
                    }
                    if(!string.IsNullOrEmpty(s_Currency))
                    {
                        temp_dt = temp_dt.Rows.Count != 0 && temp_dt.Select("" + s_Currency + "").Count() > 0 ? temp_dt.Select("" + s_Currency + "").CopyToDataTable() : new DataTable();
                    }

                    dataView = new DataView(temp_dt.Rows.Count <= 0 ? null : temp_dt);
                    dividendSetupUI.gv.DataSource = dataView.Count != 0 ? dataView.ToTable("DT", false, new string[] { "ID", "Delete", "Announcement Date", "Effective Date", "From Date", "To Date", "Type", "Dividend Per Share", "Percentage", "Currency", "Remark", "Action" }).Copy() : null;

                    dividendSetupUI.btnDSClearFilter.Visible = true;
                    dividendSetupUI.gv.DataBind();
                }
                else
                {
                    dataView = new DataView(temp_dt.Rows.Count <= 0 ? null : temp_dt);
                    dividendSetupUI.gv.DataSource = dataView.Count != 0 ? dataView.ToTable("DT", false, new string[] { "ID", "Delete", "Announcement Date", "Effective Date", "From Date", "To Date", "Type", "Dividend Per Share", "Percentage", "Currency", "Remark", "Action" }).Copy() : null;
                    dividendSetupUI.gv.DataBind();
                    dividendSetupUI.hdnDividendID.Value = string.Empty;
                    dividendSetupUI.hdnDeletedRecords.Value = string.Empty;
                    dividendSetupUI.ddlDSSearchDivType.SelectedIndex = -1;
                    dividendSetupUI.ddlDSSearchCurrency.SelectedIndex = -1;
                    dividendSetupUI.txtDSSearchAnnDate.Text = string.Empty;
                    dividendSetupUI.txtDSSearchEffDate.Text = string.Empty;
                    dividendSetupUI.hdnAccordionIndex.Value = "0";
                    dividendSetupUI.btnDSClearFilter.Visible = false;
                }

                dataView.Dispose();
                temp_dt.Dispose();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to perform CUD operations
        /// </summary>
        /// <param name="dividendSetupUI">DividendSetupUI</param>
        internal void CUDDividendSetup(DividendSetup dividendSetupUI)
        {
            Nullable<DateTime> nulldateTime = null;
            Nullable<decimal> nullDecimal = null;

            try
            {
                using(ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    string s_Condition = string.Empty;

                    string[] s_FincYr = dividendSetupUI.ddlDSFinancialYear.SelectedItem.Text.Split('-');
                    string s_FromDate = "1/Jan/" + s_FincYr[0]; string s_ToDate = "31/Dec/"  + s_FincYr[1];

                    s_Condition = (string.IsNullOrEmpty(dividendSetupUI.txtDSEffectiveDate.Text) || dividendSetupUI.txtDSEffectiveDate.Text.Equals("dd/mmm/yyyy")) && (string.IsNullOrEmpty(dividendSetupUI.txtDSAnnouncementDate.Text) || dividendSetupUI.txtDSAnnouncementDate.Text.Equals("dd/mmm/yyyy")) ? "CUD" :
                                  !(Convert.ToDateTime(dividendSetupUI.txtDSEffectiveDate.Text) > Convert.ToDateTime(dividendSetupUI.txtDSAnnouncementDate.Text)) ? "InValid_EffectiveDate" :
                                  !(Convert.ToDateTime(s_FromDate).Date <= Convert.ToDateTime(dividendSetupUI.txtDSAnnouncementDate.Text).Date && Convert.ToDateTime(dividendSetupUI.txtDSAnnouncementDate.Text).Date <= Convert.ToDateTime(s_ToDate).Date) ? "OutOfRange_AnnDate" :
                                  !(Convert.ToDateTime(s_FromDate).Date <= Convert.ToDateTime(dividendSetupUI.txtDSEffectiveDate.Text).Date && Convert.ToDateTime(dividendSetupUI.txtDSEffectiveDate.Text).Date <= Convert.ToDateTime(s_ToDate).Date) ? "OutOfRange_EffDate" : "CUD";

                    switch(s_Condition)
                    {
                        case "CUD":
                            DataTable dt_FincYr = ac_DividendSetUp.dt_DivdFinanYr.Select("FINC_YEAR='" + Convert.ToString(dividendSetupUI.ddlDSFinancialYear.SelectedItem.Text) + "'").CopyToDataTable();

                            if(string.IsNullOrEmpty(dividendSetupUI.hdnDividendID.Value) && !string.IsNullOrEmpty(dividendSetupUI.hdnDeletedRecords.Value))
                                valuationProperties.Action = "D";
                            else
                                valuationProperties.Action = string.IsNullOrEmpty(dividendSetupUI.hdnDividendID.Value) ? "C" : "U";

                            valuationProperties.ADMID = string.IsNullOrEmpty(dividendSetupUI.hdnDividendID.Value) ? 0 : Convert.ToInt32(dividendSetupUI.hdnDividendID.Value);
                            valuationProperties.List_DMid = string.IsNullOrEmpty(dividendSetupUI.hdnDeletedRecords.Value) ? string.Empty : dividendSetupUI.hdnDeletedRecords.Value.TrimStart(',');
                            valuationProperties.Announcement_Date = (string.IsNullOrEmpty(dividendSetupUI.txtDSAnnouncementDate.Text) || dividendSetupUI.txtDSAnnouncementDate.Text.Trim().Equals("dd/mmm/yyyy")) ? nulldateTime : Convert.ToDateTime(dividendSetupUI.txtDSAnnouncementDate.Text);
                            valuationProperties.Effective_Date = (string.IsNullOrEmpty(dividendSetupUI.txtDSEffectiveDate.Text) || dividendSetupUI.txtDSAnnouncementDate.Text.Trim().Equals("dd/mmm/yyyy")) ? nulldateTime : Convert.ToDateTime(dividendSetupUI.txtDSEffectiveDate.Text);

                            valuationProperties.Financial_Year_From = Convert.ToDateTime(dt_FincYr.Rows[0]["FINC_YEAR_FROM_DATE"].ToString());
                            valuationProperties.Financial_Year_To = Convert.ToDateTime(dt_FincYr.Rows[3]["FINC_YEAR_TO_DATE"].ToString());
                            valuationProperties.Dividend_Type = dividendSetupUI.ddlDSDividendType.SelectedItem.Text;
                            valuationProperties.CRMID = dividendSetupUI.ddlDSCurrencyName.SelectedValue;
                            valuationProperties.Dividend_Per_Share = string.IsNullOrEmpty(dividendSetupUI.txtDSDividendPerShare.Text) ? nullDecimal : Convert.ToDecimal(dividendSetupUI.txtDSDividendPerShare.Text);
                            valuationProperties.Devidend_Percentage = string.IsNullOrEmpty(dividendSetupUI.txtDSDividendPercentage.Text) ? nullDecimal : Convert.ToDecimal(dividendSetupUI.txtDSDividendPercentage.Text);
                            valuationProperties.Remark = dividendSetupUI.txtDSRemark.Text;
                            valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;

                            valuationProperties.PageName = CommonConstantModel.s_DividendSetup;
                            valuationProperties.Operation = CommonConstantModel.s_OperationCUD;

                            dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                            valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                            switch(Convert.ToInt16(valuationCRUDProperties.a_result))
                            {
                                case 0:
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblDSError", CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10);
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    dividendSetupUI.h3AddEdit.Style.Add("display", "none");
                                    dividendSetupUI.hdnAccordionIndex.Value = "0";
                                    break;

                                case 1:
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblDSCreated", CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10);
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    dividendSetupUI.h3AddEdit.Style.Add("display", "none");
                                    dividendSetupUI.hdnAccordionIndex.Value = dividendSetupUI.hdnIsBindDropdown.Value = "0";
                                    dividendSetupUI.hdnDeletedRecords.Value = string.Empty;
                                    dividendSetupUI.hdnDividendID.Value = string.Empty;
                                    break;

                                case 2:
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblDSUpdated", CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10);
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    dividendSetupUI.h3AddEdit.Style.Add("display", "none");
                                    dividendSetupUI.hdnAccordionIndex.Value = dividendSetupUI.hdnIsBindDropdown.Value = "0";
                                    dividendSetupUI.hdnDeletedRecords.Value = string.Empty;
                                    dividendSetupUI.hdnDividendID.Value = string.Empty;
                                    break;

                                case 3:
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblDSDeleted", CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10);
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    dividendSetupUI.h3AddEdit.Style.Add("display", "none");
                                    dividendSetupUI.hdnAccordionIndex.Value = dividendSetupUI.hdnIsBindDropdown.Value = "0";
                                    dividendSetupUI.hdnDeletedRecords.Value = string.Empty;
                                    dividendSetupUI.hdnDividendID.Value = string.Empty;
                                    break;

                                case 4:
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblDSIsExist", CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10);
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    dividendSetupUI.hdnAccordionIndex.Value = dividendSetupUI.hdnIsBindDropdown.Value = "1";
                                    break;

                                case 5:
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblDSReactive", CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10);
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    dividendSetupUI.h3AddEdit.Style.Add("display", "none");
                                    break;

                                case 6:
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblDSCanNotEditSettings", CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10);
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    dividendSetupUI.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                    dividendSetupUI.hdnAccordionIndex.Value = dividendSetupUI.hdnIsBindDropdown.Value = "1";
                                    break;
                            }
                            break;

                        case "InValid_EffectiveDate":
                            dividendSetupUI.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblDSInvalidEffDate", CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10);
                            dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            dividendSetupUI.h3AddEdit.Style.Add("display", "block");
                            dividendSetupUI.hdnAccordionIndex.Value = dividendSetupUI.hdnIsBindDropdown.Value = "1";
                            break;

                        case "OutOfRange_AnnDate":
                            dividendSetupUI.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblDSOutOfRange_AnnDate", CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10);
                            dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            dividendSetupUI.h3AddEdit.Style.Add("display", "block");
                            dividendSetupUI.hdnAccordionIndex.Value = dividendSetupUI.hdnIsBindDropdown.Value = "1";
                            break;

                        case "OutOfRange_EffDate":
                            dividendSetupUI.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblDSOutOfRange_EffDate", CommonConstantModel.s_DividendSetup, CommonConstantModel.s_ValuationL10);
                            dividendSetupUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            dividendSetupUI.h3AddEdit.Style.Add("display", "block");
                            dividendSetupUI.hdnAccordionIndex.Value = dividendSetupUI.hdnIsBindDropdown.Value = "1";
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        #region Bind/Hide rows into GridView gv
        /// <summary>
        /// Bind GridView Rows
        /// </summary>
        /// <param name="e"></param>
        /// <param name="n_index">index</param>
        /// <param name="n_ID">ID</param>
        /// <param name="n_Delete">Delete column index</param>
        /// <param name="n_Action">Action</param>
        /// <param name="n_Remark">This is remark</param>
        /// <param name="n_DivPerShare">Div Per Share</param>
        /// <param name="Percentage">Percentage</param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action, ref int n_Remark, ref int n_DivPerShare, ref int Percentage)
        {
            try
            {
                switch(e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach(DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch(perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    n_Delete = n_index;
                                    e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    break;

                                case "REMARK":
                                    n_Remark = n_index;
                                    break;

                                case "DIVIDEND PER SHARE":
                                    n_DivPerShare = n_index;
                                    break;

                                case "PERCENTAGE":
                                    Percentage = n_index;
                                    break;

                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_Remark].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 300px;");
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, e.Row.Cells[5].Text, e.Row.Cells[6].Text, e.Row.Cells[7].Text, e.Row.Cells[8].Text, e.Row.Cells[9].Text, e.Row.Cells[10].Text));
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_DivPerShare].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[Percentage].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[1].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method creates Image button control in gridview for edit purpose.
        /// </summary>
        /// <param name="s_strToolTip">this is tooltip for the image button</param>
        /// <param name="s_strUrl">this is image url</param>
        /// <param name="s_ADSID">this is ADSId</param>
        /// <param name="s_Announcement_date">this is announcement date string</param>
        /// <param name="s_Effective_date">this is effective date string</param>
        /// <param name="s_Financial_year_from">this variable has finacial from date</param>
        /// <param name="s_Financial_year_to">this variable has financial to date</param>
        /// <param name="s_Dividend_type">this is dividend type string</param>
        /// <param name="s_Dividend_per_share">this has dividend per share string</param>
        /// <param name="s_Dividend_percentage">this is dividend percentage</param>
        /// <param name="s_CurrncyID"></param>
        /// <param name="s_Remark">this is remark</param>
        /// <returns>returns Image button control</returns>        
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_ADSID, string s_Announcement_date, string s_Effective_date, string s_Financial_year_from, string s_Financial_year_to, string s_Dividend_type, string s_Dividend_per_share, string s_Dividend_percentage, string s_CurrncyID, string s_Remark)
        {
            using(ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");

                if(!string.IsNullOrEmpty(s_Announcement_date))
                {
                    imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_ADSID + "','" + s_Announcement_date + "','" + s_Effective_date + "','" + s_Financial_year_from + "','" + s_Financial_year_to + "','" + s_Dividend_type + "','" + s_Dividend_per_share + "','" + s_Dividend_percentage + "','" + s_CurrncyID + "','" + s_Remark + "')");
                }
                imgButton.Enabled = ac_DividendSetUp.b_IsEditRights;
                return imgButton;
            }
        }

        /// <summary>
        /// Bind CheckBox for delete multiple records
        /// </summary>
        /// <param name="s_AMID">CountryID</param>
        /// <param name="IsDeleted">IsDeleted</param>
        /// <returns>CheckBox control</returns>
        private CheckBox AddCheckBox(string s_AMID, bool IsDeleted)
        {
            using(CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_AMID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");

                if(!string.IsNullOrEmpty(s_AMID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_AMID + "',this)");
                }

                return checkBox;
            }
        }

        /// <summary>
        /// Add Delete all checkbox
        /// </summary>
        /// <returns>CheckBox control</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using(CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chk";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Text = string.Empty;
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }

        }

        /// <summary>
        /// Bind next page data
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">GridViewPageEventArgs</param>
        /// <param name="gv">GridView</param>
        /// <param name="s_DividendIDs">This variable has Dividend Ids</param>
        /// <param name="dividendSetupUI"></param>       
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_DividendIDs, DividendSetup dividendSetupUI)
        {
            try
            {
                string[] s_DividendID = s_DividendIDs.TrimStart(',').Split(',');

                ac_DividendSetUp.dt_temp_DividendDate.Columns["Delete"].Expression = string.Empty;
                ac_DividendSetUp.dt_temp_DividendDate.AcceptChanges();

                foreach(string perID in s_DividendID)
                {
                    if(!perID.Equals(string.Empty))
                    {
                        foreach(DataRow perRow in ac_DividendSetUp.dt_temp_DividendDate.Select("ID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }

                gv.PageIndex = e.NewPageIndex;
                ReadDividendSetup(dividendSetupUI);
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~DividendSetupModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}