﻿using EDFinancials.Model.Generic;
using EDFinancials.UserControl.User.Valuation;
using EDFinancials.View.Valuation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Risk Free Interest Rate user control Model
    /// </summary>
    public class RiskFreeInterestRateUCModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public RiskFreeInterestRateUCModel()
        {
            if (ac_ValuationParameter == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationParameter);
                ac_ValuationParameter = (CommonModel.AC_ValuationParameter)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationParameter];
            }
        }

        #region RFIR

        /// <summary>
        /// This method is used to bind all the dropdowns on page load
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        public void BindDropDowns(ValuationParameters valuationParametersSetup)
        {
            try
            {
                using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                {
                    superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                    superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    superAdminProperties.PageName = CommonConstantModel.s_ManageCountries;
                    superAdminProperties.IsActive = 1;
                    superAdminProperties.CMID = 0;
                    superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);

                    using (DataTable dt_CountryList = superAdminCRUDProperties.dt_Result)
                    {
                        string s_DefaultCountry = string.Empty;
                        IEnumerable<string> query = from CountryList in dt_CountryList.AsEnumerable()
                                                    where CountryList.Field<string>("Default Country") == "Yes"
                                                    select CountryList.Field<string>("Country Name");
                        foreach (string countryName in query)
                        {
                            s_DefaultCountry = countryName;
                        }

                        valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.ClearSelection();
                        valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.DataSource = dt_CountryList;

                        if (dt_CountryList.Rows.Count > 0)
                        {
                            valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.DataTextField = "Country Name";
                            valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.DataValueField = "Country Name";
                        }

                        valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.DataBind();
                        valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.Items.Insert(0, new ListItem("--- Please Select ---", "0"));
                        using (VPSCommonModel vPSCommonModel = new VPSCommonModel())
                        {
                            vPSCommonModel.BindToolTip(valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList);
                        }
                        if (!string.IsNullOrEmpty(s_DefaultCountry) && valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.Items.FindByValue(s_DefaultCountry) != null)
                        {
                            valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.Items.FindByValue(s_DefaultCountry).Selected = true;
                            VPSRFIRCountrySelIndChanged(valuationParametersSetup.ctrRiskFreeInterestRate, "");
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Country drop-down selected index changed event
        /// </summary>
        /// <param name="riskFreeInterestRateUC">RiskFreeInterestRateUC control object</param>
        /// <param name="s_Type">s_Type input variable</param>
        public void VPSRFIRCountrySelIndChanged(RiskFreeInterestRateUC riskFreeInterestRateUC, string s_Type)
        {
            try
            {
                riskFreeInterestRateUC.btnRFIRDeleteAll.Visible = false;

                if (riskFreeInterestRateUC.ddlVPSRFIRCountryList.SelectedItem.Value.Equals("0") || s_Type.Equals("Reset"))
                {
                    riskFreeInterestRateUC.ddlVPSRFIRCountryList.ClearSelection();
                    riskFreeInterestRateUC.tdlblVPSRFIRFileName.Style.Add("display", "none");
                    riskFreeInterestRateUC.tdtxtVPSRFIRFileName.Style.Add("display", "none");
                    riskFreeInterestRateUC.divVPSRFIRGrid.Style.Add("display", "none");
                    riskFreeInterestRateUC.trVPSRFIRFromToDateNonInd.Style.Add("display", "none");
                    riskFreeInterestRateUC.btnRFIRClearFilter.Style.Add("display", "none");

                    riskFreeInterestRateUC.ddlVPSRFIRCountryList.Items.FindByValue("0").Selected = true;
                    riskFreeInterestRateUC.btnRFIRCreateNew.Visible = false;
                    riskFreeInterestRateUC.gvVPSRFIR.DataSource = null;

                    riskFreeInterestRateUC.gvVPSRFIR.DataBind();

                    riskFreeInterestRateUC.txtVPSRFIRFileName.Text = riskFreeInterestRateUC.txtVPSRFIRFromDate.Text = riskFreeInterestRateUC.txtVPSRFIRToDate.Text = string.Empty;
                    riskFreeInterestRateUC.tdddlVPSRFIRCountryList.ColSpan = 3;
                    riskFreeInterestRateUC.tdddlVPSRFIRCountryList.Width = "75%";
                }
                else
                {
                    bool isIndia = false;
                    isIndia = (string.IsNullOrEmpty(riskFreeInterestRateUC.ddlVPSRFIRCountryList.SelectedItem.Value) || riskFreeInterestRateUC.ddlVPSRFIRCountryList.SelectedItem.Value.Equals("0") || riskFreeInterestRateUC.ddlVPSRFIRCountryList.SelectedItem.Value.ToUpper().Equals("INDIA")) ? true : false;

                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        riskFreeInterestRateUC.divVPSRFIRGrid.Style.Add("display", "");
                        riskFreeInterestRateUC.btnRFIRClearFilter.Style.Add("display", "");
                        riskFreeInterestRateUC.trVPSRFIRFromToDateNonInd.Style.Add("display", "");
                        if (isIndia)
                        {
                            riskFreeInterestRateUC.tdlblVPSRFIRFileName.Style.Add("display", "");
                            riskFreeInterestRateUC.tdtxtVPSRFIRFileName.Style.Add("display", "");
                            riskFreeInterestRateUC.btnRFIRCreateNew.Visible = false;
                            superAdminProperties.FILE_NAME = riskFreeInterestRateUC.txtVPSRFIRFileName.Text.Trim();
                            riskFreeInterestRateUC.tdddlVPSRFIRCountryList.ColSpan = 1;
                            riskFreeInterestRateUC.tdddlVPSRFIRCountryList.Width = "25%";
                        }
                        else
                        {
                            riskFreeInterestRateUC.tdlblVPSRFIRFileName.Style.Add("display", "none");
                            riskFreeInterestRateUC.tdtxtVPSRFIRFileName.Style.Add("display", "none");
                            riskFreeInterestRateUC.btnRFIRCreateNew.Visible = true;
                            riskFreeInterestRateUC.tdddlVPSRFIRCountryList.ColSpan = 3;
                            riskFreeInterestRateUC.tdddlVPSRFIRCountryList.Width = "75%";
                        }
                        superAdminProperties.FROM_DATE = (string.IsNullOrEmpty(riskFreeInterestRateUC.txtVPSRFIRFromDate.Text) || riskFreeInterestRateUC.txtVPSRFIRFromDate.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(riskFreeInterestRateUC.txtVPSRFIRFromDate.Text).ToString("MM/dd/yyyy");
                        superAdminProperties.TO_DATE = (string.IsNullOrEmpty(riskFreeInterestRateUC.txtVPSRFIRToDate.Text) || riskFreeInterestRateUC.txtVPSRFIRToDate.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(riskFreeInterestRateUC.txtVPSRFIRToDate.Text).ToString("MM/dd/yyyy");

                        superAdminProperties.COUNTRY_NAME = riskFreeInterestRateUC.ddlVPSRFIRCountryList.SelectedItem.Value.ToUpper();
                        superAdminProperties.PageName = CommonConstantModel.s_ManageRFIR;
                        superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                        superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                        superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                        ac_ValuationParameter.dt_RFIRDetails = superAdminCRUDProperties.dt_Result;
                        ac_ValuationParameter.dt_RFIRDetails.AcceptChanges();

                        riskFreeInterestRateUC.gvVPSRFIR.DataSource = ac_ValuationParameter.dt_RFIRDetails;
                        riskFreeInterestRateUC.gvVPSRFIR.DataBind();

                        if (ac_ValuationParameter.dt_RFIRDetails.Rows.Count > 0 && !isIndia)
                            riskFreeInterestRateUC.btnRFIRDeleteAll.Visible = true;

                        riskFreeInterestRateUC.hdnVPSRFIRID.Value = string.Empty;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="IsIndia">IsIndia country bool value</param>
        public void RowDataBindForGVRFIR(GridViewRowEventArgs e, bool IsIndia)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SELECT ALL":
                                    e.Row.Cells[0].Controls.Add(AddSelectAllCheckBox());
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "RFIRID":
                                    perColumn.Visible = false;
                                    break;

                                case "SERVER_PATH":
                                    perColumn.Visible = false;
                                    break;

                                case "FILE NAME":
                                    perColumn.Visible = IsIndia;
                                    break;

                                case "DATE":
                                    perColumn.Visible = IsIndia;
                                    break;

                                case "DOWNLOAD":
                                    perColumn.Visible = IsIndia;
                                    break;

                                case "REFERENCE URL":
                                    perColumn.Visible = IsIndia;
                                    break;

                                case "COUNTRY":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "FROM DATE":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "1 - 3 YEARS":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "3 - 5 YEARS":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "5 - 10 YEARS":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "MORE THAN 10 YEARS":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "TO DATE":
                                    perColumn.Visible = !IsIndia;
                                    break;

                                case "ACTION":
                                    perColumn.Visible = !IsIndia;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[1].Visible = e.Row.Cells[2].Visible = false;
                        e.Row.Cells[3].Visible = e.Row.Cells[4].Visible = e.Row.Cells[5].Visible = e.Row.Cells[6].Visible = IsIndia;
                        e.Row.Cells[14].Visible = e.Row.Cells[0].Visible = e.Row.Cells[7].Visible = e.Row.Cells[8].Visible = e.Row.Cells[9].Visible = e.Row.Cells[10].Visible = e.Row.Cells[11].Visible = e.Row.Cells[12].Visible = e.Row.Cells[13].Visible = !IsIndia;
                        e.Row.Cells[0].HorizontalAlign = e.Row.Cells[14].HorizontalAlign = e.Row.Cells[0].HorizontalAlign = e.Row.Cells[5].HorizontalAlign = e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Center;
                        if (!string.IsNullOrEmpty(e.Row.Cells[6].Text) && !e.Row.Cells[6].Text.EndsWith("&nbsp;"))
                            e.Row.Cells[6].Controls.Add((Control)AddHyperLink("Click here to download", e.Row.Cells[6].Text));
                        if (IsIndia)
                        {
                            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Center;
                            e.Row.Cells[4].Text = Convert.ToDateTime(e.Row.Cells[4].Text).ToString("dd/MMM/yyyy");
                            e.Row.Cells[5].Controls.Add((Control)AddImageLink("Click here to download", "~/View/App_Themes/images/download.png", e.Row.Cells[2].Text, e.Row.Cells[3].Text));
                        }
                        else
                        {
                            e.Row.Cells[8].HorizontalAlign = e.Row.Cells[13].HorizontalAlign = HorizontalAlign.Center;
                            e.Row.Cells[9].HorizontalAlign = e.Row.Cells[10].HorizontalAlign = e.Row.Cells[11].HorizontalAlign = e.Row.Cells[12].HorizontalAlign = HorizontalAlign.Right;
                            if (!string.IsNullOrEmpty(e.Row.Cells[8].Text))
                                e.Row.Cells[8].Text = Convert.ToDateTime(e.Row.Cells[8].Text).ToString("dd/MMM/yyyy");
                            if (!string.IsNullOrEmpty(e.Row.Cells[9].Text))
                                e.Row.Cells[9].Text = e.Row.Cells[9].Text + "%";
                            if (!string.IsNullOrEmpty(e.Row.Cells[10].Text))
                                e.Row.Cells[10].Text = e.Row.Cells[10].Text + "%";
                            if (!string.IsNullOrEmpty(e.Row.Cells[11].Text))
                                e.Row.Cells[11].Text = e.Row.Cells[11].Text + "%";
                            if (!string.IsNullOrEmpty(e.Row.Cells[12].Text))
                                e.Row.Cells[12].Text = e.Row.Cells[12].Text + "%";
                            if (!string.IsNullOrEmpty(e.Row.Cells[13].Text) && !e.Row.Cells[13].Text.Equals("&nbsp;"))
                                e.Row.Cells[13].Text = Convert.ToDateTime(e.Row.Cells[13].Text).ToString("dd/MMM/yyyy");
                            e.Row.Cells[14].Controls.Add((Control)AddActionImageLink("Update", "~/View/App_Themes/images/Edit.png", e.Row.Cells[1].Text, e.Row.Cells[8].Text, e.Row.Cells[9].Text, e.Row.Cells[10].Text, e.Row.Cells[11].Text, e.Row.Cells[12].Text, e.Row.Cells[13].Text));
                            e.Row.Cells[0].Controls.Add(AddCheckBox(e.Row.Cells[1].Text, e.Row.Cells[0].Text.Equals("1")));
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add delete all checkbox to gridview header
        /// </summary>
        /// <returns>returns CheckBox control</returns>
        private CheckBox AddSelectAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chk";
                checkBox.Attributes.Add("name", "Types");
                checkBox.TabIndex = 6;
                checkBox.Style.Add("cursor", "pointer");
                checkBox.Attributes.Add("onclick", "SelectAllCheckBoxes(this)");
                return checkBox;
            }
        }

        /// <summary>
        /// This method is used to add delete checkbox to gridview rows
        /// </summary>
        /// <param name="s_RFIRID">RFIRID</param>
        /// <param name="b_IsDeleted">Delete check</param>
        /// <returns>return CheckBox control</returns>
        private CheckBox AddCheckBox(string s_RFIRID, bool b_IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_RFIRID);
                checkBox.ID = "chk";
                checkBox.ClientIDMode = ClientIDMode.Static;
                checkBox.Checked = b_IsDeleted;
                checkBox.TabIndex = 7;
                checkBox.Style.Add("cursor", "pointer");
                checkBox.Attributes.Add("name", "Types");
                if (!string.IsNullOrEmpty(s_RFIRID))
                {
                    checkBox.Attributes.Add("onclick", "DeleteSelectedRecords('" + s_RFIRID + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_ToolTip">image tooltip</param>
        /// <param name="s_Url">image URL</param>
        /// <param name="n_ID">image ID</param>
        /// <param name="s_FromDate">From Date</param>
        /// <param name="s_Slot1to3">input parameter</param>
        /// <param name="s_Slot3to5">input parameter</param>
        /// <param name="s_Slot5to10">input parameter</param>
        /// <param name="s_Slot10Plus">input parameter</param>
        /// <param name="s_ToDate">input parameter</param>
        /// <returns>returns ImageButton control</returns>
        private ImageButton AddActionImageLink(string s_ToolTip, string s_Url, string n_ID, string s_FromDate, string s_Slot1to3, string s_Slot3to5, string s_Slot5to10, string s_Slot10Plus, string s_ToDate)
        {
            using (ImageButton img = new ImageButton())
            {
                img.ImageUrl = s_Url;
                img.ToolTip = s_ToolTip;
                img.Style.Add("cursor", "pointer");
                img.TabIndex = 8;
                img.Attributes.Add("onclick", "return ShowEditPanel('" + n_ID + "','" + s_FromDate + "','" + s_Slot1to3 + "','" + s_Slot3to5 + "','" + s_Slot5to10 + "','" + s_Slot10Plus + "','" + s_ToDate + "')");
                return img;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="riskFreeInterestRateUC">riskFreeInterestRateUC page object</param>
        public void PageIndexChangingForGVRFIR(int NewPageIndex, RiskFreeInterestRateUC riskFreeInterestRateUC)
        {
            try
            {
                riskFreeInterestRateUC.divVPSRFIRGrid.Style.Add("display", "");
                riskFreeInterestRateUC.btnRFIRClearFilter.Style.Add("display", "");

                riskFreeInterestRateUC.gvVPSRFIR.PageIndex = NewPageIndex;
                riskFreeInterestRateUC.gvVPSRFIR.DataSource = ac_ValuationParameter.dt_RFIRDetails;
                riskFreeInterestRateUC.gvVPSRFIR.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to download file from server folder
        /// </summary>
        /// <param name="riskFreeInterestRateUC">RiskFreeInterestRateUC page object</param>
        public void DownloadFile(RiskFreeInterestRateUC riskFreeInterestRateUC)
        {
            try
            {
                using (WebClient o_WebClient = new WebClient())
                {
                    HttpResponse o_HttpResponse = HttpContext.Current.Response;
                    o_HttpResponse.Clear();
                    o_HttpResponse.ClearContent();
                    o_HttpResponse.ClearHeaders();
                    o_HttpResponse.Buffer = true;
                    riskFreeInterestRateUC.Response.AddHeader("Content-Disposition", "attachment;filename=" + riskFreeInterestRateUC.hdnVPSRFIRFileName.Value);
                    o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(riskFreeInterestRateUC.hdnVPSRFIRFileServerPath.Value.Replace("~", "\\")));
                    // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.Flush();
                    // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.Response.SuppressContent = true;
                    // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_ToolTip">image tooltip</param>
        /// <param name="s_Url">image URL</param>
        /// <param name="s_ServerPath">server path to download file</param>
        /// <param name="s_FileName">File name</param>
        /// <returns>returns image button control</returns>
        private ImageButton AddImageLink(string s_ToolTip, string s_Url, string s_ServerPath, string s_FileName)
        {
            using (ImageButton img = new ImageButton())
            {
                img.ImageUrl = s_Url;
                img.ToolTip = s_ToolTip;
                img.Style.Add("cursor", "pointer");
                img.TabIndex = 8;
                img.Attributes.Add("onclick", "return SetRFIRFileDownloadHdnFields('" + s_ServerPath.Replace("\\", "~") + "','" + s_FileName + "')");
                return img;
            }
        }

        /// <summary>
        /// This is used to add hyperlink to gridview rows
        /// </summary>
        /// <param name="s_ToolTip">control tooltip</param>
        /// <param name="s_Url">hyperlink URL</param>
        /// <returns>returns hyper link control</returns>
        private HyperLink AddHyperLink(string s_ToolTip, string s_Url)
        {
            using (HyperLink hyperLink = new HyperLink())
            {
                hyperLink.NavigateUrl = s_Url;
                hyperLink.Text = s_Url;
                hyperLink.ToolTip = s_ToolTip;
                hyperLink.TabIndex = 9;
                return hyperLink;
            }
        }

        /// <summary>
        /// This Method is used to save/update data
        /// </summary>
        /// <param name="riskFreeInterestRateUC">ManageRFIR page object</param>
        /// <param name="s_Action">CUD action</param>
        public int SaveRFIRDetails(RiskFreeInterestRateUC riskFreeInterestRateUC, string s_Action)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        superAdminProperties = new SuperAdminProperties();
                        superAdminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                        superAdminProperties.Action = s_Action;
                        superAdminProperties.RDFIRIDs = string.IsNullOrEmpty(riskFreeInterestRateUC.hdnVPSRFIRID.Value) ? string.Empty : riskFreeInterestRateUC.hdnVPSRFIRID.Value.TrimStart();

                        if (s_Action.Equals("C") || s_Action.Equals("U"))
                        {
                            superAdminProperties.COUNTRY_NAME = riskFreeInterestRateUC.ddlVPSRFIRCountryList.SelectedItem.Value;
                            superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                            superAdminProperties.IsDeleted = false;
                            superAdminProperties.FROM_DATE = (string.IsNullOrEmpty(riskFreeInterestRateUC.txtRFIREditFromDate.Text) || riskFreeInterestRateUC.txtRFIREditFromDate.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(riskFreeInterestRateUC.txtRFIREditFromDate.Text).ToString("MM/dd/yyyy");
                            superAdminProperties.SLOT_1TO3YEARS = Convert.ToDecimal(riskFreeInterestRateUC.txtRFIREditSlot1to3Yrs.Text);
                            superAdminProperties.SLOT_3TO5YEARS = Convert.ToDecimal(riskFreeInterestRateUC.txtRFIREditSlot3to5Yrs.Text);
                            superAdminProperties.SLOT_5TO10YEARS = Convert.ToDecimal(riskFreeInterestRateUC.txtRFIREditSlot5to10Yrs.Text);
                            superAdminProperties.SLOT_MORETHAN10YEARS = Convert.ToDecimal(riskFreeInterestRateUC.txtRFIREditSlot10PlusYrs.Text);
                        }

                        superAdminProperties.PageName = CommonConstantModel.s_ManageRFIR;
                        superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                        superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                        superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                        int n_RetValue = superAdminCRUDProperties.a_result;

                        riskFreeInterestRateUC.hdnVPSRFIRID.Value = string.Empty;

                        if (n_RetValue.Equals(1))
                        {
                            ParamChange(riskFreeInterestRateUC);
                        }

                        if (n_RetValue.Equals(4))
                        {                            
                            riskFreeInterestRateUC.divRFIRSearch.Style.Add("display", "none");
                            riskFreeInterestRateUC.accordion.Style.Add("display", "");
                        }

                        return n_RetValue;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to check changes in Parameter.
        /// </summary>
        /// <param name="riskFreeInterestRateUC"></param>
        public void ParamChange(RiskFreeInterestRateUC riskFreeInterestRateUC)
        {
            CommonModel.IsParamChange("UPDATE", userSessionInfo);
        }

        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~RiskFreeInterestRateUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}