﻿using EDFinancials.Model.Generic;
using EDFinancials.UserControl.User.Valuation;
using EDFinancials.View.Valuation;
using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Volatility User Control Model
    /// </summary>
    public class VolatilityUCModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public VolatilityUCModel()
        {
            if(ac_ValuationParameter == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationParameter);
                ac_ValuationParameter = (CommonModel.AC_ValuationParameter)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationParameter];
            }
        }

        #region Volatility

        /// <summary>
        /// This method is used to bind all the dropdowns
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        public void BindDropDowns(ValuationParameters valuationParametersSetup)
        {
            try
            {
                if(ac_ValuationParameter.ds_ValuationParameters.Tables[14].Rows.Count > 0)
                {
                    using(DataTable dt_SEDetails = ac_ValuationParameter.ds_ValuationParameters.Tables[14])
                    {
                        valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.DataSource = dt_SEDetails;
                        valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.DataTextField = "Short Name";
                        valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.DataValueField = "SEID";
                        valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.DataBind();
                        using(VPSCommonModel vPSCommonModel = new VPSCommonModel())
                        {
                            vPSCommonModel.BindToolTip(valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC);
                        }
                        if(Convert.ToInt32(valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.SelectedItem.Value) > 0)
                            valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Items.FindByValue(valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.SelectedItem.Value).Selected = true;
                        else if(valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Items.FindByText("NSE") != null)
                            valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Items.FindByText("NSE").Selected = true;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind Volatility controls
        /// </summary>
        /// <param name="ds_ValuationParameters">DataSet object</param>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        /// <param name="s_GrantDate"></param>
        /// <param name="s_GrantID"></param>
        public void BindVolatilityControls(DataSet ds_ValuationParameters, ValuationParameters valuationParametersSetup, string s_GrantDate, string s_GrantID)
        {
            try
            {
                DataRow[] dr_GrantLevelSettings = null;
                DataTable dt_GrantLevelPeerCompany = new DataTable();
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    if (!string.IsNullOrEmpty(s_GrantDate))
                    {
                        valuationProperties.PageName = CommonConstantModel.s_ValuationParameters;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                        dr_GrantLevelSettings = valuationCRUDProperties.ds_Result.Tables[7].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'");
                        if (valuationCRUDProperties.ds_Result.Tables[13].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").Count() > 0)
                        {
                            using (DataTable dt_PeerCompanyDetails = valuationCRUDProperties.ds_Result.Tables[13].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'").CopyToDataTable())
                            {
                                dt_PeerCompanyDetails.Columns.Remove("GRANT_GRANT_REG_ID");
                                dt_GrantLevelPeerCompany = dt_PeerCompanyDetails;
                            }
                        }
                    }

                    ac_ValuationParameter.dt_Volatility = ac_ValuationParameter.ds_ValuationParameters.Tables[7];
                    valuationParametersSetup.ctrVolatility.gvVolatility.DataSource = ac_ValuationParameter.dt_Volatility;
                    valuationParametersSetup.ctrVolatility.gvVolatility.DataBind();

                    ac_ValuationParameter.dt_PeerCompanies = ac_ValuationParameter.ds_ValuationParameters.Tables[10];
                    valuationParametersSetup.ctrVolatility.gvVPSVCPeerCompaniesGrid.DataSource = dt_GrantLevelPeerCompany.Rows.Count > 0 ? dt_GrantLevelPeerCompany : ac_ValuationParameter.dt_PeerCompanies;
                    valuationParametersSetup.ctrVolatility.gvVPSVCPeerCompaniesGrid.DataBind();

                    valuationParametersSetup.ctrVolatility.hdnVPSVolPeerCompCount.Value = Convert.ToString(ac_ValuationParameter.dt_PeerCompanies.Rows.Count);
                    ac_ValuationParameter.dt_VolExcludeDetails = ac_ValuationParameter.ds_ValuationParameters.Tables[11];
                    valuationParametersSetup.ctrVolatility.gvVPSExcludeVolDetails.DataSource = ac_ValuationParameter.dt_VolExcludeDetails;
                    valuationParametersSetup.ctrVolatility.gvVPSExcludeVolDetails.DataBind();

                    BindControls(valuationParametersSetup, s_GrantDate, s_GrantID, dr_GrantLevelSettings);
                    SetApprovalHiddenField(valuationParametersSetup);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to set hidden field to check approval status
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        public void SetApprovalHiddenField(ValuationParameters valuationParametersSetup)
        {
            try
            {
                bool s_IsApproved = (from query in ac_ValuationParameter.dt_Volatility.AsEnumerable()
                                     where query.Field<string>("Approval Status") == "Pending"
                                     select query.Field<string>("Approval Status")).Distinct().Count() > 0 ? false : true;
                valuationParametersSetup.ctrVolatility.hdnVPS_IsApproved_VC.Value = s_IsApproved ? "1" : "0";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all the controls on page load
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        /// <param name="s_GrantDate"></param>
        /// <param name="s_GrantID"></param>
        /// <param name="dr_GrantLevelSettings"></param>
        private void BindControls(ValuationParameters valuationParametersSetup, string s_GrantDate, string s_GrantID, DataRow[] dr_GrantLevelSettings)
        {
            try
            {
                #region This is used to bind controls at time of redirect from Valuation Report page
                if(!string.IsNullOrEmpty(s_GrantDate))
                {
                    foreach(DataRow perRow in ac_ValuationParameter.ds_ValuationParameters.Tables[7].Select("[To Date] IS NULL"))
                    {
                        perRow["To Date"] = DateTime.Now.Date;
                    }
                }
                #endregion

                using (DataTable dt_ValuationParameters = string.IsNullOrEmpty(s_GrantDate) ? ac_ValuationParameter.ds_ValuationParameters.Tables[6] : (dr_GrantLevelSettings != null && dr_GrantLevelSettings.Count() > 0) ? dr_GrantLevelSettings.CopyToDataTable() : ac_ValuationParameter.ds_ValuationParameters.Tables[7].Rows.Count.Equals(0) ? ac_ValuationParameter.ds_ValuationParameters.Tables[7] : ac_ValuationParameter.ds_ValuationParameters.Tables[7].Select("[Applicable From Date] <= #" + Convert.ToDateTime(s_GrantDate).Date + "# AND [To Date] >= #" + Convert.ToDateTime(s_GrantDate).Date + "#").CopyToDataTable())
                {
                    #region This is used to bind controls at time of redirect from Valuation Report page
                    if (!string.IsNullOrEmpty(s_GrantDate) && dr_GrantLevelSettings.Count().Equals(0))
                    {
                        dt_ValuationParameters.Columns["Volatility of"].ColumnName = "VOLATILITY_OF_LABEL_ID";
                        dt_ValuationParameters.Columns["Market Price to Calculate Volatility"].ColumnName = "MP_CALC_VOLATILITY_LABEL_ID";
                        dt_ValuationParameters.Columns["Periods to Calculate Volatility"].ColumnName = "PRD_CALC_VOLATILITY_LABEL_ID";
                        dt_ValuationParameters.Columns["Remark"].ColumnName = "REMARK";
                        dt_ValuationParameters.Columns["Applicable From Date"].ColumnName = "APPLICABLE_FROM_DATE";
                    }
                    else if (dr_GrantLevelSettings != null && dr_GrantLevelSettings.Count() > 0)
                    {
                        dt_ValuationParameters.Columns["GRANT_VOL_OF_LABEL_ID"].ColumnName = "VOLATILITY_OF_LABEL_ID";
                        dt_ValuationParameters.Columns["GRANT_MP_CALC_VOLATILITY"].ColumnName = "MP_CALC_VOLATILITY_LABEL_ID";
                        dt_ValuationParameters.Columns["GRANT_PRD_CALC_VOL_LABEL"].ColumnName = "PRD_CALC_VOLATILITY_LABEL_ID";
                        dt_ValuationParameters.Columns["GRANT_TRADING_DAYS_LABEL"].ColumnName = "TRADING_DAYS_LABEL_ID";
                        dt_ValuationParameters.Columns["GRANT_TRADING_DAYS"].ColumnName = "TRADING_DAYS";
                        dt_ValuationParameters.Columns["GRANT_CONSIDER_PERIOD_IN"].ColumnName = "CONSIDER_PERIOD_IN";
                        dt_ValuationParameters.Columns["GRANT_CONSIDER_VALUE"].ColumnName = "CONSIDER_VALUE";
                    }
                    #endregion

                    ac_ValuationParameter.b_IsListed = userSessionInfo.ACC_IsListed.Equals(1) ? true : false;

                    if(ac_ValuationParameter.b_IsListed)
                    {
                        valuationParametersSetup.ctrVolatility.lblVOL01.Style.Add("display", "");
                        valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Style.Add("display", "");
                        valuationParametersSetup.ctrVolatility.lblVOL03.Style.Add("display", "none");
                        valuationParametersSetup.ctrVolatility.trVPSMPToCalcVolatility.Style.Add("display", "");
                        valuationParametersSetup.ctrVolatility.trVPSPrdsToCalcVolatility.Style.Add("display", "");
                    }
                    else
                    {
                        valuationParametersSetup.ctrVolatility.lblVOL01.Style.Add("display", "none");
                        valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Style.Add("display", "none");
                        valuationParametersSetup.ctrVolatility.lblVOL03.Style.Add("display", "");
                        valuationParametersSetup.ctrVolatility.trVPSMPToCalcVolatility.Style.Add("display", "none");
                        valuationParametersSetup.ctrVolatility.trVPSPrdsToCalcVolatility.Style.Add("display", "none");
                    }

                    if(dt_ValuationParameters.Rows.Count > 0)
                    {
                        if(Convert.ToString(dt_ValuationParameters.Rows[0]["VOLATILITY_OF_LABEL_ID"]).Trim().Equals("lblVOL01") && ac_ValuationParameter.b_IsListed)
                        {
                            valuationParametersSetup.ctrVolatility.lblVOL01.Checked = true;

                            if(string.IsNullOrEmpty(s_GrantDate))
                            {
                                if(!string.IsNullOrEmpty(Convert.ToString(dt_ValuationParameters.Rows[0]["SEID"]).Trim()))
                                {
                                    if(valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Items.FindByValue(Convert.ToString(dt_ValuationParameters.Rows[0]["SEID"]).Trim()) != null)
                                    {
                                        valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.ClearSelection();
                                        valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Items.FindByValue(Convert.ToString(dt_ValuationParameters.Rows[0]["SEID"]).Trim()).Selected = true;
                                    }
                                }
                            }
                            else
                            {
                                if(!string.IsNullOrEmpty(Convert.ToString(dt_ValuationParameters.Rows[0]["SHORT_NAME"]).Trim()))
                                {
                                    if(valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Items.FindByText(Convert.ToString(dt_ValuationParameters.Rows[0]["SHORT_NAME"]).Trim()) != null)
                                    {
                                        valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.ClearSelection();
                                        valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Items.FindByText(Convert.ToString(dt_ValuationParameters.Rows[0]["SHORT_NAME"]).Trim()).Selected = true;
                                    }
                                }
                            }

                        }
                        else if(Convert.ToString(dt_ValuationParameters.Rows[0]["VOLATILITY_OF_LABEL_ID"]).Trim().Equals("lblVOL02"))
                        {
                            valuationParametersSetup.ctrVolatility.divVPSVCPeerCompaniesGrid.Style.Add("display", "");
                            valuationParametersSetup.ctrVolatility.lblVOL02.Checked = true;
                        }
                        else if(Convert.ToString(dt_ValuationParameters.Rows[0]["VOLATILITY_OF_LABEL_ID"]).Trim().Equals("lblVOL03") && !ac_ValuationParameter.b_IsListed)
                            valuationParametersSetup.ctrVolatility.lblVOL03.Checked = true;

                        if(ac_ValuationParameter.b_IsListed || Convert.ToString(dt_ValuationParameters.Rows[0]["VOLATILITY_OF_LABEL_ID"]).Trim().Equals("lblVOL02"))
                        {
                            if(Convert.ToString(dt_ValuationParameters.Rows[0]["MP_CALC_VOLATILITY_LABEL_ID"]).Trim().Equals("lblMPTCV01"))
                            {
                                valuationParametersSetup.ctrVolatility.lblMPTCV01.Checked = true;

                                if(Convert.ToString(dt_ValuationParameters.Rows[0]["TRADING_DAYS_LABEL_ID"]).Trim().Equals("lblTDD01"))
                                    valuationParametersSetup.ctrVolatility.lblTDD01.Checked = true;
                                if(Convert.ToString(dt_ValuationParameters.Rows[0]["TRADING_DAYS_LABEL_ID"]).Trim().Equals("lblTDD02"))
                                    valuationParametersSetup.ctrVolatility.lblTDD02.Checked = true;
                                if(Convert.ToString(dt_ValuationParameters.Rows[0]["TRADING_DAYS_LABEL_ID"]).Trim().Equals("lblTDD03"))
                                {
                                    valuationParametersSetup.ctrVolatility.lblTDD03.Checked = true;
                                    valuationParametersSetup.ctrVolatility.txtVPSSpecifyDaysDaily.Text = Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows[0]["TRADING_DAYS"]).Trim();
                                }
                            }
                            //else if (Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows[0]["MP_CALC_VOLATILITY_LABEL_ID"]).Trim().Equals("lblMPTCV02"))
                            //{
                            //    valuationParametersSetup.ctrVolatility.lblMPTCV02.Checked = true;
                            //    if (Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows[0]["TRADING_DAYS_LABEL_ID"]).Trim().Equals("lblTDW01"))
                            //        valuationParametersSetup.ctrVolatility.lblTDW01.Checked = true;
                            //    if (Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows[0]["TRADING_DAYS_LABEL_ID"]).Trim().Equals("lblTDW02"))
                            //    {
                            //        valuationParametersSetup.ctrVolatility.lblTDW02.Checked = true;
                            //        valuationParametersSetup.ctrVolatility.txtVPSSpecifyDaysWeekly.Text = Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows[0]["TRADING_DAYS"]).Trim();
                            //    }
                            //}
                            //else
                            //{
                            //    valuationParametersSetup.ctrVolatility.lblMPTCV03.Checked = true;
                            //    if (Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows[0]["TRADING_DAYS_LABEL_ID"]).Trim().Equals("lblTDA01"))
                            //        valuationParametersSetup.ctrVolatility.lblTDA01.Checked = true;
                            //    if (Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows[0]["TRADING_DAYS_LABEL_ID"]).Trim().Equals("lblTDA02"))
                            //    {
                            //        valuationParametersSetup.ctrVolatility.lblTDA02.Checked = true;
                            //        valuationParametersSetup.ctrVolatility.txtVPSSpecifyDaysAnnual.Text = Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows[0]["TRADING_DAYS"]).Trim();
                            //    }
                            //}

                            if(Convert.ToString(dt_ValuationParameters.Rows[0]["PRD_CALC_VOLATILITY_LABEL_ID"]).Trim().Equals("lblPTCV01"))
                                valuationParametersSetup.ctrVolatility.lblPTCV01.Checked = true;
                            else if(Convert.ToString(dt_ValuationParameters.Rows[0]["PRD_CALC_VOLATILITY_LABEL_ID"]).Trim().Equals("lblPTCV02"))
                                valuationParametersSetup.ctrVolatility.lblPTCV02.Checked = true;
                            else if(Convert.ToString(dt_ValuationParameters.Rows[0]["PRD_CALC_VOLATILITY_LABEL_ID"]).Trim().Equals("lblPTCV03"))
                            {
                                valuationParametersSetup.ctrVolatility.lblPTCV03.Checked = true;

                                if(Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_PERIOD_IN"]).Trim().Equals("Y"))
                                {
                                    valuationParametersSetup.ctrVolatility.rdoVolatilityYears.Checked = true;
                                    valuationParametersSetup.ctrVolatility.txtVolatilityYears.Text = Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_VALUE"]).Trim();
                                }
                                else if(Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_PERIOD_IN"]).Trim().Equals("M"))
                                {
                                    valuationParametersSetup.ctrVolatility.rdoVolatilityMonths.Checked = true;
                                    valuationParametersSetup.ctrVolatility.txtVolatilityMonths.Text = Convert.ToString(Convert.ToInt32(dt_ValuationParameters.Rows[0]["CONSIDER_VALUE"]));
                                }
                                else if(Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_PERIOD_IN"]).Trim().Equals("D"))
                                {
                                    valuationParametersSetup.ctrVolatility.rdoVolatilityDays.Checked = true;
                                    valuationParametersSetup.ctrVolatility.txtVolatilityDays.Text = Convert.ToString(Convert.ToInt32(dt_ValuationParameters.Rows[0]["CONSIDER_VALUE"]));
                                }
                            }
                        }

                        if (string.IsNullOrEmpty(s_GrantDate))
                        {
                            valuationParametersSetup.ctrVolatility.txtVolatilityRemark.Text = Convert.ToString(dt_ValuationParameters.Rows[0]["REMARK"]).Trim();
                            valuationParametersSetup.ctrVolatility.hdnVPSAppFromDate_VC.Value = valuationParametersSetup.ctrVolatility.txtVolatilityApplFromDate.Text = !string.IsNullOrEmpty(Convert.ToString(dt_ValuationParameters.Rows[0]["APPLICABLE_FROM_DATE"])) ? Convert.ToDateTime(ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows[0]["APPLICABLE_FROM_DATE"]).ToString("dd/MMM/yyyy") : string.Empty; 
                        }
                        using(ValuationModel valuationModel = new ValuationModel())
                        {
                            valuationModel.SetButtonText(valuationParametersSetup.ctrVolatility.btnVPSVolatilitySave);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Update Volatility Config Data
        /// </summary>
        /// <param name="volatilityUC">VolatilityUC control object</param>
        /// <param name="s_Type">CUD action type</param>
        /// <returns>returns 1 for insert, 2 for update and 3 for delete opration</returns>
        public int UpdateVolatilityConfigData(VolatilityUC volatilityUC, string s_Type)
        {
            try
            {
                using(ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using(SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        valuationProperties = new ValuationProperties();
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                        valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                        valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        valuationProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                        valuationProperties.PopulateControls = s_Type;
                        if(userSessionInfo.ACC_UerTypeID.Equals(5))
                            valuationProperties.VC_IS_APPROVED = true;
                        else valuationProperties.VC_IS_APPROVED = false;

                        switch(s_Type)
                        {
                            case "VC":
                                if(volatilityUC.lblVOL01.Checked)
                                {
                                    valuationProperties.VC_VOLATILITY_OF_LABEL_ID = volatilityUC.lblVOL01.ID;
                                    valuationProperties.VC_SEID = Convert.ToInt32(volatilityUC.ddlVPSStockExchge_VC.SelectedItem.Value);
                                }
                                else if(volatilityUC.lblVOL02.Checked)
                                    valuationProperties.VC_VOLATILITY_OF_LABEL_ID = volatilityUC.lblVOL02.ID;
                                else if(volatilityUC.lblVOL03.Checked)
                                    valuationProperties.VC_VOLATILITY_OF_LABEL_ID = volatilityUC.lblVOL03.ID;

                                if(volatilityUC.lblMPTCV01.Checked)
                                {
                                    valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID = volatilityUC.lblMPTCV01.ID;

                                    if(volatilityUC.lblTDD01.Checked)
                                        valuationProperties.VC_TRADING_DAYS_LABEL_ID = volatilityUC.lblTDD01.ID;
                                    else if(volatilityUC.lblTDD02.Checked)
                                        valuationProperties.VC_TRADING_DAYS_LABEL_ID = volatilityUC.lblTDD02.ID;
                                    else if(volatilityUC.lblTDD03.Checked)
                                    {
                                        valuationProperties.VC_TRADING_DAYS_LABEL_ID = volatilityUC.lblTDD03.ID;
                                        valuationProperties.VC_TRADING_DAYS = Convert.ToInt32(volatilityUC.txtVPSSpecifyDaysDaily.Text);
                                    }
                                }
                                //else if (volatilityUC.lblMPTCV02.Checked)
                                //{
                                //    valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID = volatilityUC.lblMPTCV02.ID;
                                //    if (volatilityUC.lblTDW01.Checked)
                                //        valuationProperties.VC_TRADING_DAYS_LABEL_ID = volatilityUC.lblTDW01.ID;
                                //    else if (volatilityUC.lblTDW02.Checked)
                                //    {
                                //        valuationProperties.VC_TRADING_DAYS_LABEL_ID = volatilityUC.lblTDW01.ID;
                                //        valuationProperties.VC_TRADING_DAYS = Convert.ToInt32(volatilityUC.txtVPSSpecifyDaysDaily.Text);
                                //    }
                                //}
                                //else if (volatilityUC.lblMPTCV03.Checked)
                                //{
                                //    valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID = volatilityUC.lblMPTCV03.ID;
                                //    if (volatilityUC.lblTDA01.Checked)
                                //        valuationProperties.VC_TRADING_DAYS_LABEL_ID = volatilityUC.lblTDA01.ID;
                                //    else if (volatilityUC.lblTDA02.Checked)
                                //    {
                                //        valuationProperties.VC_TRADING_DAYS_LABEL_ID = volatilityUC.lblTDA02.ID;
                                //        valuationProperties.VC_TRADING_DAYS = Convert.ToInt32(volatilityUC.txtVPSSpecifyDaysAnnual.Text);
                                //    }
                                //}

                                if(volatilityUC.lblPTCV01.Checked)
                                    valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID = volatilityUC.lblPTCV01.ID;
                                else if(volatilityUC.lblPTCV02.Checked)
                                    valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID = volatilityUC.lblPTCV02.ID;
                                else if(volatilityUC.lblPTCV03.Checked)
                                {
                                    valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID = volatilityUC.lblPTCV03.ID;

                                    if(volatilityUC.rdoVolatilityYears.Checked)
                                    {
                                        valuationProperties.VC_CONSIDER_PERIOD_IN = "Y";
                                        valuationProperties.VC_CONSIDER_VALUE = Math.Round(Convert.ToDecimal(volatilityUC.txtVolatilityYears.Text), 2);
                                    }
                                    else if(volatilityUC.rdoVolatilityMonths.Checked)
                                    {
                                        valuationProperties.VC_CONSIDER_PERIOD_IN = "M";
                                        valuationProperties.VC_CONSIDER_VALUE = Convert.ToInt32(volatilityUC.txtVolatilityMonths.Text);
                                    }
                                    if(volatilityUC.rdoVolatilityDays.Checked)
                                    {
                                        valuationProperties.VC_CONSIDER_PERIOD_IN = "D";
                                        valuationProperties.VC_CONSIDER_VALUE = Convert.ToInt32(volatilityUC.txtVolatilityDays.Text);
                                    }
                                }
                                valuationProperties.VC_REMARK = volatilityUC.txtVolatilityRemark.Text;
                                valuationProperties.VC_APPLICABLE_FROM_DATE = volatilityUC.txtVolatilityApplFromDate.Text;
                                break;
                            case "VC_EXCLUDEVOL":
                                valuationProperties.VC_EXCLUDE_FROM_DATE = volatilityUC.txtVPSExcludeFromDate.Text;
                                valuationProperties.VC_EXCLUDE_TO_DATE = volatilityUC.txtVPSExcludeToDate.Text;
                                valuationProperties.EVC_REMARK = volatilityUC.txtVPSExcludeRemark.Text;
                                break;
                        }

                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        if (valuationCRUDProperties.a_result.Equals(1))
                        {
                            ParamChange(volatilityUC);
                        }

                        if(valuationCRUDProperties.a_result.Equals(1) && s_Type.Equals("VC_EXCLUDEVOL"))
                        {                           
                            if(s_Type.Equals("VC_EXCLUDEVOL"))
                            {
                                volatilityUC.txtVPSExcludeFromDate.Text = string.Empty;
                                volatilityUC.txtVPSExcludeToDate.Text = string.Empty;
                                volatilityUC.txtVPSExcludeRemark.Text = string.Empty;
                            }
                            else
                            {
                                using(ValuationModel valuationModel = new ValuationModel())
                                {
                                    valuationModel.SetButtonText(volatilityUC.btnVPSVolatilitySave);
                                }
                                volatilityUC.hdnVPSAppFromDate_VC.Value = volatilityUC.txtVolatilityApplFromDate.Text;
                            }
                        }
                        return valuationCRUDProperties.a_result;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindForGVVol(GridViewRowEventArgs e)
        {
            try
            {
                switch(e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach(DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch(perColumn.Text.ToUpper())
                            {
                                case "SHORT_NAME":
                                    perColumn.Visible = false;
                                    break;
                                case "TRADING_DAYS_LABEL_ID":
                                    perColumn.Visible = false;
                                    break;
                                case "TRADING_DAYS":
                                    perColumn.Visible = false;
                                    break;
                                case "CONSIDER_PERIOD_IN":
                                    perColumn.Visible = false;
                                    break;
                                case "CONSIDER_VALUE":
                                    perColumn.Visible = false;
                                    break;
                                case "AVCID":
                                    perColumn.Visible = false;
                                    break;
                                case "SEID":
                                    perColumn.Visible = false;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[9].HorizontalAlign = e.Row.Cells[10].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[1].Visible = e.Row.Cells[3].Visible = e.Row.Cells[4].Visible = e.Row.Cells[6].Visible = e.Row.Cells[7].Visible = e.Row.Cells[11].Visible = e.Row.Cells[14].Visible = false;

                        if(!string.IsNullOrEmpty(e.Row.Cells[9].Text) && !e.Row.Cells[9].Text.Equals("&nbsp;"))
                            e.Row.Cells[9].Text = Convert.ToDateTime(e.Row.Cells[9].Text).ToString("dd/MMM/yyyy");

                        if(!string.IsNullOrEmpty(e.Row.Cells[10].Text) && !e.Row.Cells[10].Text.Equals("&nbsp;"))
                            e.Row.Cells[10].Text = Convert.ToDateTime(e.Row.Cells[10].Text).ToString("dd/MMM/yyyy");

                        if(!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                        {
                            if(e.Row.Cells[0].Text.Trim().Equals("lblVOL01") && !string.IsNullOrEmpty(e.Row.Cells[1].Text.Trim()) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                                e.Row.Cells[0].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[0].Text.Trim() + "'" + ""))[0]["LabelName"]) + " : " + e.Row.Cells[1].Text.Trim();
                            else
                                e.Row.Cells[0].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[0].Text.Trim() + "'" + ""))[0]["LabelName"]);
                        }

                        e.Row.Cells[8].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;");

                        if(!string.IsNullOrEmpty(e.Row.Cells[2].Text) && !e.Row.Cells[2].Text.Equals("&nbsp;"))
                        {
                            if(e.Row.Cells[2].Text.Trim().Equals("lblMPTCV01"))
                            {
                                if(e.Row.Cells[3].Text.Trim().Equals("lblTDD03"))
                                    e.Row.Cells[2].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[2].Text.Trim() + "'" + ""))[0]["LabelName"]) + " : " + e.Row.Cells[4].Text + " Day(s)";
                                else
                                    e.Row.Cells[2].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[2].Text.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[3].Text.Trim() + "'" + ""))[0]["LabelName"]) + " Day(s)";
                            }
                            //else if (e.Row.Cells[2].Text.Trim().Equals("lblMPTCV02"))
                            //{
                            //    if (e.Row.Cells[3].Text.Trim().Equals("lblTDW02"))
                            //        e.Row.Cells[2].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[2].Text.Trim() + "'" + ""))[0]["LabelName"]) + " : " + e.Row.Cells[4].Text + " Day(s)";
                            //    else e.Row.Cells[2].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[2].Text.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[3].Text.Trim() + "'" + ""))[0]["LabelName"]) + " Day(s)";
                            //}
                            //else if (e.Row.Cells[2].Text.Trim().Equals("lblMPTCV03"))
                            //{
                            //    if (e.Row.Cells[3].Text.Trim().Equals("lblTDA02"))
                            //        e.Row.Cells[2].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[2].Text.Trim() + "'" + ""))[0]["LabelName"]) + " : " + e.Row.Cells[4].Text + " Day(s)";
                            //    else e.Row.Cells[2].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[2].Text.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[3].Text.Trim() + "'" + ""))[0]["LabelName"]) + " Day(s)";
                            //}
                        }

                        if(!string.IsNullOrEmpty(e.Row.Cells[5].Text) && !e.Row.Cells[5].Text.Equals("&nbsp;"))
                        {
                            if(e.Row.Cells[5].Text.Trim().Equals("lblPTCV01"))
                                e.Row.Cells[5].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[5].Text.Trim() + "'" + ""))[0]["LabelName"]);
                            else if(e.Row.Cells[5].Text.Trim().Equals("lblPTCV02"))
                                e.Row.Cells[5].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[5].Text.Trim() + "'" + ""))[0]["LabelName"]);
                            else if(e.Row.Cells[5].Text.Trim().Equals("lblPTCV03"))
                            {
                                string s_PrdIn = string.Empty;
                                if(e.Row.Cells[6].Text.Trim() == "Y")
                                    s_PrdIn = Convert.ToDecimal(e.Row.Cells[7].Text.Trim()).ToString("#0.00") + " Year(s)";
                                else if(e.Row.Cells[6].Text.Trim() == "M")
                                    s_PrdIn = Convert.ToDecimal(e.Row.Cells[7].Text.Trim()).ToString("N0") + " Month(s)";
                                else if(e.Row.Cells[6].Text.Trim() == "D")
                                    s_PrdIn = Convert.ToDecimal(e.Row.Cells[7].Text.Trim()).ToString("N0") + " Day(s)";
                                e.Row.Cells[5].Text = s_PrdIn;
                            }
                        }
                        e.Row.Cells[13].Controls.Add((Control)new VPSCommonModel().AddHistoryHyperLink(e.Row.Cells[11].Text, e.Row.Cells[9].Text, e.Row.Cells[10].Text, "VC"));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindForGVExcludeVol(GridViewRowEventArgs e)
        {
            try
            {
                switch(e.Row.RowType)
                {
                    case DataControlRowType.DataRow:
                        e.Row.Cells[0].HorizontalAlign = e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;

                        if(!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                            e.Row.Cells[0].Text = Convert.ToDateTime(e.Row.Cells[0].Text).ToString("dd/MMM/yyyy");

                        if(!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="volatilityUC">volatilityUC page object</param>
        public void PageIndexChangingForGVVol(int NewPageIndex, VolatilityUC volatilityUC)
        {
            try
            {
                volatilityUC.gvVolatility.PageIndex = NewPageIndex;
                volatilityUC.gvVolatility.DataSource = ac_ValuationParameter.dt_Volatility;
                volatilityUC.gvVolatility.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="volatilityUC">volatilityUC page object</param>
        public void PageIndexChangForGVExclVol(int NewPageIndex, VolatilityUC volatilityUC)
        {
            try
            {
                volatilityUC.gvVPSExcludeVolDetails.PageIndex = NewPageIndex;
                volatilityUC.gvVPSExcludeVolDetails.DataSource = ac_ValuationParameter.dt_VolExcludeDetails;
                volatilityUC.gvVPSExcludeVolDetails.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="volatilityUC">volatilityUC page object</param>
        public void PageIndexChangingForGVVolPeerComp(int NewPageIndex, VolatilityUC volatilityUC)
        {
            try
            {
                volatilityUC.gvVPSVCPeerCompaniesGrid.PageIndex = NewPageIndex;
                volatilityUC.gvVPSVCPeerCompaniesGrid.DataSource = ac_ValuationParameter.dt_PeerCompanies;
                volatilityUC.gvVPSVCPeerCompaniesGrid.DataBind();

                if(volatilityUC.lblVOL02.Checked)
                    volatilityUC.divVPSVCPeerCompaniesGrid.Style.Add("display", "");
                else
                    volatilityUC.divVPSVCPeerCompaniesGrid.Style.Add("display", "none");
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// This method is used to check changes in Parameter.
        /// </summary>
        /// <param name="volatilityUC"></param>        
        public void ParamChange(VolatilityUC volatilityUC)
        {
            CommonModel.IsParamChange("UPDATE", userSessionInfo);
        }     

        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~VolatilityUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}