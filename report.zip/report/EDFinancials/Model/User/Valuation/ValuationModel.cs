﻿using EDFinancials.Model.Generic;
using EDFinancials.View.Valuation;
using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Valuation Model class
    /// </summary>
    public class ValuationModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public ValuationModel()
        {
            if (ac_ValuationParameter == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationParameter);
                ac_ValuationParameter = (CommonModel.AC_ValuationParameter)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationParameter];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnVPSSaveIVText = string.Empty, s_BtnVPSSaveIVToolTip = string.Empty, s_BtnVPSUpdateIVText = string.Empty, s_BtnVPSUpdateIVTooltip = string.Empty
                            , s_BtnVPSSaveFVText = string.Empty, s_BtnVPSSaveFVToolTip = string.Empty, s_BtnVPSUpdateFVText = string.Empty, s_BtnVPSUpdateFVTooltip = string.Empty
                            , s_BtnVPSExpectedLifeSaveText = string.Empty, s_BtnVPSExpectedLifeSaveToolTip = string.Empty, s_BtnVPSExpectedLifeUpdateText = string.Empty, s_BtnVPSExpectedLifeUpdateTooltip = string.Empty
                            , s_BtnVPSVolatilitySaveText = string.Empty, s_BtnVPSVolatilitySaveToolTip = string.Empty, s_BtnVPSVolatilityUpdateText = string.Empty, s_BtnVPSVolatilityUpdateTooltip = string.Empty
                            , s_BtnVPSDividendSaveText = string.Empty, s_BtnVPSDividendSaveToolTip = string.Empty, s_BtnVPSDividendUpdateText = string.Empty, s_BtnVPSDividendUpdateTooltip = string.Empty
                            , s_BtnRFIRUpdateText = string.Empty, s_BtnRFIRUpdateToolTip = string.Empty, s_BtnRFIRSaveText = string.Empty, s_BtnRFIRSaveTooltip = string.Empty
                            , s_SelectSEMsg = string.Empty, s_SelectDateOfMPMsg = string.Empty, s_CanNotEditSettingsMsg = string.Empty, s_SelectOptionForPastExerMsg = string.Empty, s_EnterMonthsMsg = string.Empty
                            , s_EnterYearsMsg = string.Empty, s_EnterDaysMsg = string.Empty, s_SelectOptionForSpPrdMsg = string.Empty, s_EstDateMandatoryMsg = string.Empty
                            , s_SelectMthdForCalcELMsg = string.Empty, s_SelectTradingDaysMsg = string.Empty, s_SelectoptionForVolmsg = string.Empty, s_SpecifyPrdMsg = string.Empty
                            , s_SelectOpForPrdToCalcVolMsg = string.Empty, s_SelectOpForMPTOCalcVolMsg = string.Empty, s_FromToDateErrorMsg = string.Empty, s_incorrectseqOfRankMsg = string.Empty
                            , s_incorrectseqOfRankWithCondnMsg = string.Empty, s_SelectOpForVolOfMsg = string.Empty, s_SelectOwnCompOrSetupPeerMsg = string.Empty;

        #endregion

        #region Page Load

        /// <summary>
        /// Method to bind all the labels from L10N_UI.xml
        /// </summary>
        /// <param name="valuationParametersSetup">This is object of Valuation Parameter setup page</param>
        /// <param name="s_PageName"></param>
        public void BindAllLabelsFromL10N_UI(ValuationParameters valuationParametersSetup, string s_PageName)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    ac_ValuationParameter.dt_ValuParaSetupUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10_UI);

                    #region Headers
                    valuationParametersSetup.lblVPSPageHeader.Text = (s_PageName.ToUpper().Equals("RPT_PARM")) ? Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRPPPageHeader'"))[0]["LabelName"]) : Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSPageHeader'"))[0]["LabelName"]);
                    valuationParametersSetup.lblVPSMarketPrice.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMarketPrice'"))[0]["LabelName"]);
                    valuationParametersSetup.lblVPSExpectedLife.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSExpectedLife'"))[0]["LabelName"]);
                    valuationParametersSetup.lblVPSVolatility.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSVolatility'"))[0]["LabelName"]);
                    valuationParametersSetup.lblVPSRiskFreeIntRate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRiskFreeIntRate'"))[0]["LabelName"]);
                    valuationParametersSetup.lblVPSDividend.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDividend'"))[0]["LabelName"]);
                    #endregion
                    #region MarketPrice
                    valuationParametersSetup.ctrMarketPrice.lblVPSIntrinsicValue.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSIntrinsicValue'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblVPSFairValue.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSFairValue'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblVPSStockExchange.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSStockExchange'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblVPSStockExchange.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSStockExchange'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.lblVPSStockExchange1.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSStockExchange'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblVPSStockExchange1.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSStockExchange'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.lblVPSDateOfMarketPrice.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDateOfMarketPrice'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblVPSDateOfMarketPrice.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDateOfMarketPrice'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.lblVPSDateOfMarketPrice1.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDateOfMarketPrice'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblVPSDateOfMarketPrice1.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDateOfMarketPrice'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.lblIVSE01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblIVSE01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblIVSE02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblIVSE02'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblIVDMP01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblIVDMP01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblIVDMP02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblIVDMP02'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblFVSE01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblFVSE01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblFVSE02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblFVSE02'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblFVDMP01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblFVDMP01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblFVDMP02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblFVDMP02'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.btnVPSResetIV.Value = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSReset'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.btnVPSResetFV.Value = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSReset'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblIVRemark.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRemark'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblIVRemark.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRemark'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.lblFVRemark.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRemark'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblFVRemark.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRemark'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.lblIVApplFromDate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSApplFromDate'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblIVApplFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSApplFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.lblFVApplFromDate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSApplFromDate'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.lblFVApplFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSApplFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.rfvFVApplFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'rfvFVApplFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.rfvIVApplFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'rfvIVApplFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.btnVPSSaveIV.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSSaveIV'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.btnVPSSaveFV.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSSaveFV'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrMarketPrice.btnVPSSaveIV.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSSaveIV'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrMarketPrice.btnVPSSaveFV.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSSaveFV'"))[0]["LabelToolTip"]);
                    s_BtnVPSSaveIVText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSSaveIV'"))[0]["LabelName"]);
                    s_BtnVPSSaveIVToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSSaveIV'"))[0]["LabelToolTip"]);
                    s_BtnVPSUpdateIVText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSUpdateIV'"))[0]["LabelName"]);
                    s_BtnVPSUpdateIVTooltip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSUpdateIV'"))[0]["LabelToolTip"]);
                    s_BtnVPSSaveFVText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSSaveFV'"))[0]["LabelName"]);
                    s_BtnVPSSaveFVToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSSaveFV'"))[0]["LabelToolTip"]);
                    s_BtnVPSUpdateFVText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSUpdateFV'"))[0]["LabelName"]);
                    s_BtnVPSUpdateFVTooltip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSUpdateFV'"))[0]["LabelToolTip"]);

                    #endregion
                    #region ExpectedLife
                    valuationParametersSetup.ctrExpectedLife.lblVPSMethodForCEL.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMethodForCEL'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblVPSMethodForCEL.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMethodForCEL'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.lblMCEL01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMCEL01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblMCEL02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMCEL02'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblMCEL03.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMCEL03'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblMCEL04.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMCEL04'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblExpLifeYears.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSYears'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblExpLifeYears.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSYears'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.lblExpLifeMonths.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMonths'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblExpLifeMonths.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMonths'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.lblExpLifeDays.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDays'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblExpLifeDays.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDays'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.lblVPSApplicableValFromDate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSApplicableValFromDate'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblVPSApplicableValFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSApplicableValFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeReset.Value = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSReset'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.rfvVPSApplicableValFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'rfvVPSApplicableValFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.lblExpectedLifeRemark.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblExpectedLifeRemark'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblExpectedLifeRemark.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblExpectedLifeRemark'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.btnVPSELEstimatedDateOfLstg.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSELEstimatedDateOfLstg'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.btnVPSELEstimatedDateOfLstg.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSELEstimatedDateOfLstg'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.gvVPSCurrEstDtOfListing.EmptyDataText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'gvVPSCurrEstDtOfListing'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeSave.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSExpectedLifeSave'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeSave.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSExpectedLifeSave'"))[0]["LabelToolTip"]);
                    s_BtnVPSExpectedLifeSaveText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSExpectedLifeSave'"))[0]["LabelName"]);
                    s_BtnVPSExpectedLifeSaveToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSExpectedLifeSave'"))[0]["LabelToolTip"]);
                    s_BtnVPSExpectedLifeUpdateText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSExpectedLifeUpdate'"))[0]["LabelName"]);
                    s_BtnVPSExpectedLifeUpdateTooltip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSExpectedLifeUpdate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.lblELPastExerBehaviorYrs.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSYears'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblELPastExerBehaviorYrs.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSYears'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.lblELPastExerBehaviorMnts.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMonths'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblELPastExerBehaviorMnts.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMonths'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.lblELPastExerBehaviorDays.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDays'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.lblELPastExerBehaviorDays.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDays'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.btnClearFilePastExerBehavior.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnClearFilePastExerBehavior'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.btnClearFilePastExerBehavior.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnClearFilePastExerBehavior'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrExpectedLife.btnClearFileSpecPrdFromVD.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnClearFileSpecPrdFromVD'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrExpectedLife.btnClearFileSpecPrdFromVD.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnClearFileSpecPrdFromVD'"))[0]["LabelToolTip"]);
                    #endregion
                    #region Volatility
                    valuationParametersSetup.ctrVolatility.lblVolatilityYears.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSYears'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVolatilityYears.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSYears'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.lblVolatilityMonths.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMonths'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVolatilityMonths.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMonths'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.lblVolatilityDays.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDays'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVolatilityDays.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDays'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.lblVPSVolatility1.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSVolatility'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVPSVolatilityOf.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSVolatilityOf'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVPSVolatilityOf.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSVolatilityOf'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.lblVPSMPToCalcVolatility.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMPToCalcVolatility'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVPSMPToCalcVolatility.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMPToCalcVolatility'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.lblVOL01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVOL01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVOL02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVOL02'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVOL03.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVOL03'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblMPTCV01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMPTCV01'"))[0]["LabelName"]);
                    //  valuationParametersSetup.ctrVolatility.lblMPTCV02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMPTCV02'"))[0]["LabelName"]);
                    // valuationParametersSetup.ctrVolatility.lblMPTCV03.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMPTCV03'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVPSTradingDays.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSTradingDays'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVPSTradingDays.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSTradingDays'"))[0]["LabelToolTip"]);
                    //  valuationParametersSetup.ctrVolatility.lblVPSTradingDays1.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSTradingDays'"))[0]["LabelName"]);
                    //  valuationParametersSetup.ctrVolatility.lblVPSTradingDays2.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSTradingDays'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblTDD03.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSSpecifyDays'"))[0]["LabelName"]);
                    // valuationParametersSetup.ctrVolatility.lblTDW02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSSpecifyDays'"))[0]["LabelName"]);
                    //  valuationParametersSetup.ctrVolatility.lblTDA02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSSpecifyDays'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVPSPrdsToCalcVolatility.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSPrdsToCalcVolatility'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVPSPrdsToCalcVolatility.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSPrdsToCalcVolatility'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.lblPTCV01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblPTCV01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblPTCV02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblPTCV02'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblPTCV03.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblPTCV03'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.btnVPSVolatilityReset.Value = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSReset'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVolatilityRemark.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRemark'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVolatilityRemark.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRemark'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.lblVolatilityApplFromDate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSApplFromDate'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblTDD01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblTDD01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblTDD02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblTDD02'"))[0]["LabelName"]);
                    //  valuationParametersSetup.ctrVolatility.lblTDW01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblTDW01'"))[0]["LabelName"]);
                    //  valuationParametersSetup.ctrVolatility.lblTDA01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblTDA01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.rfvVolatilityApplFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'rfvVolatilityApplFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.rfvVPSExcludeFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'rfvVolatilityApplFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.rfvVPSExcludeToDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'rfvVPSExcludeToDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.lblVolatilityRemark.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVolatilityRemark'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVolatilityRemark.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVolatilityRemark'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.lblVPSExcludeRemark.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSExcludeRemark'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.lblVPSExcludeRemark.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSExcludeRemark'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrVolatility.btnVPSVolatilitySave.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSVolatilitySave'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrVolatility.btnVPSVolatilitySave.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSVolatilitySave'"))[0]["LabelToolTip"]);
                    s_BtnVPSVolatilitySaveText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSVolatilitySave'"))[0]["LabelName"]);
                    s_BtnVPSVolatilitySaveToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSVolatilitySave'"))[0]["LabelToolTip"]);
                    s_BtnVPSVolatilityUpdateText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSVolatilityUpdate'"))[0]["LabelName"]);
                    s_BtnVPSVolatilityUpdateTooltip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSVolatilityUpdate'"))[0]["LabelToolTip"]);


                    #endregion
                    #region Dividend
                    valuationParametersSetup.ctrDividend.lblDIV01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblDIV01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblDIV02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblDIV02'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblDIV03.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblDIV03'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblDIV04.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblDIV04'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblDIV05.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblDIV05'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblMPTCD01.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMPTCD01'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblMPTCD02.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMPTCD02'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblVPSMPTCDiv.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSMPTCDiv'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblVPSDivToBeConsidered.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDivToBeConsidered'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblVPSDivToBeConsidered.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDivToBeConsidered'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.lblVPSDividendYield.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDividendYield'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblVPSDividendYield.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDividendYield'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.lblVPSLast.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSLast'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblVPSLast.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSLast'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.lblVPSYears2.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSYears'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblVPSYears2.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSYears'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.btnVPSDividendReset.Value = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSReset'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblDividendRemark.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRemark'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblDividendRemark.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRemark'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.lblDividendApplFromDate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSApplFromDate'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblDividendApplFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSApplFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.rfvDividendApplFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'rfvDividendApplFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.rfvVPSDivDividend.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'rfvVPSDivDividend'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.rfvVPSDivFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'rfvVPSDivFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.rfvVPSDivToDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'rfvVPSDivToDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.lblVPSDivFromDate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDivFromDate'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblVPSDivFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDivFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.lblVPSDivToDate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDivToDate'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblVPSDivToDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDivToDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.lblVPSDivDividend.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDivDividend'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblVPSDivDividend.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSDivDividend'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.btnVPSIncorpDividend.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSIncorpDividend'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.btnVPSIncorpDividend.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSIncorpDividend'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.lblDividendRemark.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblDividendRemark'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.lblDividendRemark.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblDividendRemark'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrDividend.btnDividendSave.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSDividendSave'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrDividend.btnDividendSave.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSDividendSave'"))[0]["LabelToolTip"]);
                    s_BtnVPSDividendSaveText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSDividendSave'"))[0]["LabelName"]);
                    s_BtnVPSDividendSaveToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSDividendSave'"))[0]["LabelToolTip"]);
                    s_BtnVPSDividendUpdateText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSDividendUpdate'"))[0]["LabelName"]);
                    s_BtnVPSDividendUpdateTooltip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVPSDividendUpdate'"))[0]["LabelToolTip"]);
                    #endregion
                    #region RFIR
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIREditFromDate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditFromDate'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIREditFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblVPSRFIRHeader.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRFIRHeader'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIRCountry.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIRCountry'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIRCountry.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIRCountry'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblVPSRFIRFileName.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRFIRFileName'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblVPSRFIRFileName.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRFIRFileName'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblVPSRFIRFromDate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRFIRFromDate'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblVPSRFIRFromDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRFIRFromDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblVPSRFIRToDate.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRFIRToDate'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblVPSRFIRToDate.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVPSRFIRToDate'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRApplyFilter.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRApplyFilter'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRApplyFilter.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRApplyFilter'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRClearFilter.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRClearFilter'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRClearFilter.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRClearFilter'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIREditSlot1to3Yrs.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot1to3Yrs'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIREditSlot1to3Yrs.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot1to3Yrs'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIREditSlot3to5Yrs.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot3to5Yrs'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIREditSlot3to5Yrs.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot3to5Yrs'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIREditSlot5to10Yrs.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot5to10Yrs'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIREditSlot5to10Yrs.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot5to10Yrs'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIREditSlot10PlusYrs.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot10PlusYrs'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.lblRFIREditSlot10PlusYrs.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot10PlusYrs'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.rfvRFIREditSlot1to3Yrs.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot1to3Yrs'"))[0]["ErrorText"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.rfvRFIREditSlot3to5Yrs.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot3to5Yrs'"))[0]["ErrorText"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.rfvRFIREditSlot5to10Yrs.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot5to10Yrs'"))[0]["ErrorText"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.rfvRFIREditSlot10PlusYrs.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIREditSlot10PlusYrs'"))[0]["ErrorText"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRCreateNew.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRCreateNew'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRSave.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRSave'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRCancel.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRCancel'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRDeleteAll.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRDeleteAll'"))[0]["LabelName"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRCreateNew.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRCreateNew'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRSave.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRSave'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRCancel.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRCancel'"))[0]["LabelToolTip"]);
                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRDeleteAll.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRDeleteAll'"))[0]["LabelToolTip"]);

                    #region Used when page redirected from Valuation Report -- added by Akhilesh
                    valuationParametersSetup.btnBackToValReport.Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnBackToValReport'"))[0]["LabelName"]);
                    valuationParametersSetup.btnBackToValReport.ToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnBackToValReport'"))[0]["LabelToolTip"]);
                    #endregion
                    s_BtnRFIRUpdateText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRUpdate'"))[0]["LabelName"]);
                    s_BtnRFIRUpdateToolTip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRUpdate'"))[0]["LabelToolTip"]);
                    s_BtnRFIRSaveText = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRSave'"))[0]["LabelName"]);
                    s_BtnRFIRSaveTooltip = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRSave'"))[0]["LabelToolTip"]);
                    #endregion

                    #region Static Variables (Messages)

                    s_SelectSEMsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectSEMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SelectDateOfMPMsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectDateOfMPMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_CanNotEditSettingsMsg = valuationServiceClient.GetValuation_L10N("lblVPSCanNotEditSettingsMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SelectOptionForPastExerMsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectOptionForPastExerMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_EnterMonthsMsg = valuationServiceClient.GetValuation_L10N("lblVPSEnterMonthsMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_EnterYearsMsg = valuationServiceClient.GetValuation_L10N("lblVPSEnterYearsMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_EnterDaysMsg = valuationServiceClient.GetValuation_L10N("lblVPSEnterDaysMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SelectOptionForSpPrdMsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectOptionForSpPrdMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_EstDateMandatoryMsg = valuationServiceClient.GetValuation_L10N("lblVPSEstDateMandatoryMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SelectMthdForCalcELMsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectMthdForCalcELMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SelectTradingDaysMsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectTradingDaysMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SelectoptionForVolmsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectoptionForVolmsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SpecifyPrdMsg = valuationServiceClient.GetValuation_L10N("lblVPSSpecifyPrdMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SelectOpForPrdToCalcVolMsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectOpForPrdToCalcVolMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SelectOpForMPTOCalcVolMsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectOpForMPTOCalcVolMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_FromToDateErrorMsg = valuationServiceClient.GetValuation_L10N("lblVPSFromToDateErrorMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_incorrectseqOfRankMsg = valuationServiceClient.GetValuation_L10N("lblVPSincorrectseqOfRankMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_incorrectseqOfRankWithCondnMsg = valuationServiceClient.GetValuation_L10N("lblVPSincorrectseqOfRankWithCondnMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SelectOpForVolOfMsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectOpForVolOfMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                    s_SelectOwnCompOrSetupPeerMsg = valuationServiceClient.GetValuation_L10N("lblVPSSelectOwnCompOrSetupPeerMsg", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);

                    #endregion
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to set button text and tool-tip
        /// </summary>
        /// <param name="o_Button">Button object</param>
        public void SetButtonText(Button o_Button)
        {
            switch (o_Button.ID.ToUpper())
            {
                case "BTNVPSSAVEIV": o_Button.Text = s_BtnVPSUpdateIVText; o_Button.ToolTip = s_BtnVPSUpdateIVTooltip; break;
                case "BTNVPSSAVEFV": o_Button.Text = s_BtnVPSUpdateFVText; o_Button.ToolTip = s_BtnVPSUpdateFVTooltip; break;
                case "BTNVPSEXPECTEDLIFESAVE": o_Button.Text = s_BtnVPSExpectedLifeUpdateText; o_Button.ToolTip = s_BtnVPSExpectedLifeUpdateTooltip; break;
                case "BTNVPSVOLATILITYSAVE": o_Button.Text = s_BtnVPSVolatilityUpdateText; o_Button.ToolTip = s_BtnVPSVolatilityUpdateTooltip; break;
                case "BTNDIVIDENDSAVE": o_Button.Text = s_BtnVPSDividendUpdateText; o_Button.ToolTip = s_BtnVPSDividendUpdateTooltip; break;
            }
        }

        /// <summary>
        /// Method is used to populate dropdowns on page load
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        public void BindDropdowns(ValuationParameters valuationParametersSetup)
        {
            try
            {
                using (RiskFreeInterestRateUCModel riskFreeInterestRateUCModel = new RiskFreeInterestRateUCModel())
                { 
                    riskFreeInterestRateUCModel.BindDropDowns(valuationParametersSetup); 
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to populate all the controls on page load
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        /// <param name="s_GrantDate"></param>
        /// <param name="s_GrantID"></param>
        public void PopulateAllControls(ValuationParameters valuationParametersSetup, string s_GrantDate, string s_GrantID)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationParametersSetup.hdnVPSIsListed.Value = Convert.ToString(userSessionInfo.ACC_IsListed);
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    valuationProperties.PopulateControls = CommonConstantModel.s_OperationRead;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    ac_ValuationParameter.ds_ValuationParameters = (DataSet)valuationCRUDProperties.ds_Result;

                    using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                    {
                        marketPriceUCModel.BindDropDowns(valuationParametersSetup);
                        marketPriceUCModel.BindMarketPriceControls(ac_ValuationParameter.ds_ValuationParameters, valuationParametersSetup, s_GrantDate, s_GrantID);
                    }

                    using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                    {
                        expectedLifeUCModel.BindExpectedLifeControls(ac_ValuationParameter.ds_ValuationParameters, valuationParametersSetup, s_GrantDate, s_GrantID);
                    }

                    using (VolatilityUCModel volatilityUCModel = new VolatilityUCModel())
                    {
                        volatilityUCModel.BindDropDowns(valuationParametersSetup);
                        volatilityUCModel.BindVolatilityControls(ac_ValuationParameter.ds_ValuationParameters, valuationParametersSetup, s_GrantDate, s_GrantID);
                    }

                    using (DividendUCModel dividendUCModel = new DividendUCModel())
                    {
                        dividendUCModel.BindDropDowns(valuationParametersSetup);
                        dividendUCModel.BindDividendControls(ac_ValuationParameter.ds_ValuationParameters, valuationParametersSetup, s_GrantDate, string.Empty, s_GrantID);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to check employee role privileges
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        public void CheckEmployeeRolePriviledges(ValuationParameters valuationParametersSetup)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuValuationParameter;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    valuationParametersSetup.ctrDividend.btnDividendSave.Enabled = false;
                                    valuationParametersSetup.ctrDividend.btnVPSDividendReset.Disabled = true;
                                    valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeSave.Enabled = false;
                                    valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeReset.Disabled = true;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSResetFV.Disabled = true;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSResetIV.Disabled = true;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSSaveFV.Enabled = false;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSSaveIV.Enabled = false;
                                    valuationParametersSetup.ctrVolatility.btnVPSExcludeVolAdd.Enabled = false;
                                    valuationParametersSetup.ctrVolatility.btnVPSVolatilityReset.Disabled = true;
                                    valuationParametersSetup.ctrVolatility.btnVPSVolatilitySave.Enabled = false;
                                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRDeleteAll.Enabled = false;
                                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRSave.Enabled = false;
                                    break;

                                case "ADD":
                                    valuationParametersSetup.ctrDividend.btnDividendSave.Enabled = true;
                                    valuationParametersSetup.ctrDividend.btnVPSDividendReset.Disabled = false;
                                    valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeSave.Enabled = true;
                                    valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeReset.Disabled = false;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSResetFV.Disabled = false;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSResetIV.Disabled = false;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSSaveFV.Enabled = true;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSSaveIV.Enabled = true;
                                    valuationParametersSetup.ctrVolatility.btnVPSExcludeVolAdd.Enabled = true;
                                    valuationParametersSetup.ctrVolatility.btnVPSVolatilityReset.Disabled = true;
                                    valuationParametersSetup.ctrVolatility.btnVPSVolatilitySave.Enabled = true;
                                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRDeleteAll.Enabled = true;
                                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRSave.Enabled = true;
                                    break;

                                case "EDIT":
                                    valuationParametersSetup.ctrDividend.btnDividendSave.Enabled = true;
                                    valuationParametersSetup.ctrDividend.btnVPSDividendReset.Disabled = false;
                                    valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeSave.Enabled = true;
                                    valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeReset.Disabled = false;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSResetFV.Disabled = false;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSResetIV.Disabled = false;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSSaveFV.Enabled = true;
                                    valuationParametersSetup.ctrMarketPrice.btnVPSSaveIV.Enabled = true;
                                    valuationParametersSetup.ctrVolatility.btnVPSExcludeVolAdd.Enabled = true;
                                    valuationParametersSetup.ctrVolatility.btnVPSVolatilityReset.Disabled = false;
                                    valuationParametersSetup.ctrVolatility.btnVPSVolatilitySave.Enabled = true;
                                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRDeleteAll.Enabled = true;
                                    valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRSave.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// this method is used to get logged in user type ID
        /// </summary>
        /// <returns></returns>
        public int GetLoggedInUserType()
        {
            return userSessionInfo.ACC_UerTypeID;
        }

        /// <summary>
        /// This method is used to default selected tab when page redirects from ValuationReport
        /// </summary>
        /// <param name="valuationParametersSetup">page object</param>
        /// <param name="s_Session">session name</param>
        /// <param name="b_IsPreviousPage">Is previous page name is valuationReport</param>
        internal void SetSelectedTab(ValuationParameters valuationParametersSetup, string s_Session, bool b_IsPreviousPage)
        {
            if(!string.IsNullOrEmpty(s_Session) && b_IsPreviousPage)
            {
                valuationParametersSetup.hdnVPSEnabledTab.Value = Convert.ToString(s_Session);
                switch(Convert.ToString(s_Session))
                {
                    case "Market":
                        valuationParametersSetup.ctrMarketPrice.divIV.Visible = valuationParametersSetup.btnBackToValReport.Visible = valuationParametersSetup.ctrMarketPrice.divFV.Visible = true;
                        valuationParametersSetup.ctrMarketPrice.btnVPSSaveFV.Visible = valuationParametersSetup.ctrMarketPrice.btnVPSResetFV.Visible = valuationParametersSetup.ctrMarketPrice.MPrice_tr1.Visible = valuationParametersSetup.ctrMarketPrice.MPrice_tr2.Visible = false;
                        valuationParametersSetup.ctrMarketPrice.MPrice_tr4.Visible = valuationParametersSetup.ctrMarketPrice.MPrice_tr5.Visible = valuationParametersSetup.ctrMarketPrice.gvMarketPriceFV.Visible = valuationParametersSetup.ctrMarketPrice.gvMarketPriceIV.Visible = false;
                        valuationParametersSetup.ctrMarketPrice.trVPSFairValue.Style.Add("display", "block");
                        break;

                    case "Expected":
                        valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeSave.Visible = valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeReset.Visible = valuationParametersSetup.ctrExpectedLife.ExpLife_tr2.Visible = valuationParametersSetup.ctrExpectedLife.ExpLife_tr1.Visible = valuationParametersSetup.ctrExpectedLife.gvExpectedLife.Visible = false;
                        valuationParametersSetup.hdnTabActiveIndex.Value = "1";
                        valuationParametersSetup.btnBackToValReport.Visible = true;
                        break;

                    case "Volatility":
                        valuationParametersSetup.ctrVolatility.btnVPSVolatilitySave.Visible = valuationParametersSetup.ctrVolatility.btnVPSVolatilityReset.Visible = valuationParametersSetup.ctrVolatility.txtVolatilityRemark.Visible = valuationParametersSetup.ctrVolatility.lblVolatilityRemark.Visible = false;
                        valuationParametersSetup.ctrVolatility.txtVolatilityApplFromDate.Visible = valuationParametersSetup.ctrVolatility.lblVolatilityApplFromDate.Visible = valuationParametersSetup.ctrVolatility.gvVolatility.Visible = false;
                        valuationParametersSetup.hdnTabActiveIndex.Value = "2";
                        valuationParametersSetup.btnBackToValReport.Visible = true;
                        break;

                    case "Dividend":
                        valuationParametersSetup.ctrDividend.btnDividendSave.Visible = valuationParametersSetup.ctrDividend.btnVPSDividendReset.Visible = valuationParametersSetup.ctrDividend.Dividend_tr1.Visible = valuationParametersSetup.ctrDividend.Dividend_tr2.Visible = valuationParametersSetup.ctrDividend.gvDividend.Visible = false;
                        valuationParametersSetup.hdnTabActiveIndex.Value = "4";
                        valuationParametersSetup.btnBackToValReport.Visible = true;
                        break;
                }
                valuationParametersSetup.btnBackToValReport.Visible = true;
                valuationParametersSetup.hdnSelectedTab.Value = s_Session;
            }
        }
        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ValuationModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}