﻿using System;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using System.Web;
using System.Collections;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class CorporateActionModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public CorporateActionModel()
        {
            if (ac_CorporateAction == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_CorporateAction);
                ac_CorporateAction = (CommonModel.AC_CorporateAction)HttpContext.Current.Session[CommonConstantModel.s_AC_CorporateAction];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty;

        #endregion

        /// <summary>
        /// 
        /// </summary>
        public string s_CompanyTitle;

        /// <summary>
        /// Method is used to check emplyee role previledge
        /// </summary>
        /// <param name="corporateAction">Page object as Parameter</param>
        internal void CheckEmployeeRolePriviledges(CorporateAction corporateAction)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuCorporateAction;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    corporateAction.btnAdd.Enabled = false;
                                    corporateAction.btnSave.Enabled = false;
                                    corporateAction.btnDelete.Enabled = false;
                                    ac_CorporateAction.Is_Edit = false;
                                    break;

                                case "ADD":
                                    corporateAction.btnAdd.Enabled = true;
                                    corporateAction.btnSave.Enabled = true;
                                    break;

                                case "EDIT":
                                    ac_CorporateAction.Is_Edit = true;
                                    corporateAction.btnSave.Enabled = true;
                                    break;

                                case "DELETE":
                                    corporateAction.btnDelete.Enabled = true;
                                    break;

                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used bind UI for Corporate Action Page
        /// </summary>
        /// <param name="corporateAction">CorporateAction Page object as Parameter</param>        
        internal void BindPageUI(CorporateAction corporateAction)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (DataTable dt_CorporateActionUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if ((dt_CorporateActionUI != null) && (dt_CorporateActionUI.Rows.Count > 0))
                        {
                            // Search Panel UI
                            corporateAction.lblCAPageHeader.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCAPageHeader.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCASearch.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASearch.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCCHeaderCURD.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCCHeaderCURD.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCASFromDate.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASFromDate.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCASFromDate.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASFromDate.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.lblCASToDate.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASToDate.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCASToDate.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASToDate.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.lblCASCompanyName.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASCompanyName.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCASCompanyName.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASCompanyName.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.lblCASCorporateActionType.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASCorporateActionType.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCASCorporateActionType.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASCorporateActionType.ID + "'"))[0]["LabelToolTip"]);

                            // CUD Operation UI
                            corporateAction.lblCUDCompanyName.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASCompanyName.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCUDCompanyName.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASCompanyName.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.lblCUDCorporateActionType.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASCorporateActionType.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCUDCorporateActionType.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCASCorporateActionType.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.lblCUDRatioMultiplier.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCUDRatioMultiplier.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCUDRatioMultiplier.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCUDRatioMultiplier.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.lblCUDRatioDivisor.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCUDRatioDivisor.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCUDRatioDivisor.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCUDRatioDivisor.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.lblCUDEffectiveDate.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCUDEffectiveDate.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCUDEffectiveDate.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCUDEffectiveDate.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.lblCUDApplyTo.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCUDApplyTo.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblCUDApplyTo.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblCUDApplyTo.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.lblRemark.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblRemark.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblRemark.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblRemark.ID + "'"))[0]["LabelToolTip"]);

                            // Validation UI
                            corporateAction.valReqCompanyName.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.valReqCompanyName.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.valReqCorporateActionType.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.valReqCorporateActionType.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.valReqRatioMultiplier.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.valReqRatioMultiplier.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.valReqRatioDivisor.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.valReqRatioDivisor.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.valRegRatioMultiplier.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.valRegRatioMultiplier.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.valRegRatioDivisor.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.valRegRatioDivisor.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.valReqEffectiveDate.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.valReqEffectiveDate.ID + "'"))[0]["LabelToolTip"]);

                            // Button UI
                            corporateAction.btnCASearch.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.btnCASearch.ID + "'"))[0]["LabelName"]);
                            corporateAction.btnClearFilter.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.btnClearFilter.ID + "'"))[0]["LabelName"]);
                            corporateAction.btnAdd.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.btnAdd.ID + "'"))[0]["LabelName"]);
                            corporateAction.btnSave.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.btnSave.ID + "'"))[0]["LabelName"]);
                            corporateAction.btnCancel.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.btnCancel.ID + "'"))[0]["LabelName"]);
                            corporateAction.btnDelete.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.btnDelete.ID + "'"))[0]["LabelName"]);
                            corporateAction.btnBackToGD.Text = Convert.ToString(dt_CorporateActionUI.Select("LabelID = 'btnBackToGD'")[0]["LabelName"]);
                            corporateAction.btnBackToGD.ToolTip = Convert.ToString(dt_CorporateActionUI.Select("LabelID = 'btnBackToGD'")[0]["LabelToolTip"]);
                            s_BtnUpdateText = Convert.ToString((dt_CorporateActionUI.Select("LabelID = 'btnUpdate'"))[0]["LabelName"]);
                            s_BtnUpdateToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = 'btnUpdate'"))[0]["LabelToolTip"]);
                            s_BtnSaveText = Convert.ToString((dt_CorporateActionUI.Select("LabelID = 'btnSave'"))[0]["LabelName"]);
                            s_BtnSaveTooltip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = 'btnSave'"))[0]["LabelToolTip"]);

                            // For Peer Compnay Model Popup
                            corporateAction.lblHeaderPeerCompany.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblHeaderPeerCompany.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblPeerCompanyList.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblPeerCompanyList.ID + "'"))[0]["LabelName"]);
                            corporateAction.lblPeerCompanyList.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.lblPeerCompanyList.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.btnDivOk.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.btnDivOk.ID + "'"))[0]["LabelName"]);
                            corporateAction.reqValPeerCompany.Text = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.reqValPeerCompany.ID + "'"))[0]["LabelToolTip"]);
                            corporateAction.reqValPeerCompany.ToolTip = Convert.ToString((dt_CorporateActionUI.Select("LabelID = '" + corporateAction.reqValPeerCompany.ID + "'"))[0]["LabelToolTip"]);

                            corporateAction.btnClearFilter.Visible = false;

                            corporateAction.ddlCASCoroprateAction.Items.Insert(0, "--- Please Select ---");
                            corporateAction.ddlCURDCoroprateAction.Items.Insert(0, "--- Please Select ---");
                            corporateAction.ddlPeerCompanyList.Items.Insert(0, "--- Please Select ---");

                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to show validation message
        /// </summary>
        /// <param name="corporateAction">CorporateAction Page object as Parameter</param>
        /// <returns></returns>
        internal string BindValidationMessage(CorporateAction corporateAction)
        {
            string s_ValidationMessage = string.Empty;

            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (DataTable dt_CorporateActionUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if ((dt_CorporateActionUI != null) && (dt_CorporateActionUI.Rows.Count > 0))
                        {

                            s_ValidationMessage = valuationServiceClient.GetValuation_L10N("lblCanNotEditCA", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                        }
                    }
                }


            }
            catch
            {
                throw;
            }

            return s_ValidationMessage;
        }

        /// <summary>
        /// Method is used bind default controls on the page
        /// </summary>
        /// <param name="corporateAction">CorporateAction Page object as Parameter</param>     
        internal void BindControls(CorporateAction corporateAction)
        {
            #region Bind Action type drop down list
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    corporateAction.txtCUDCompanyName.Text = userSessionInfo.ACC_CompanyTitle;
                    corporateAction.hdnCompanyTitle.Value = userSessionInfo.ACC_CompanyTitle;

                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_CorporateAction;
                    valuationProperties.PopulateControls = "GET_CORPORATE_ACTION_TYPE";
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    corporateAction.ddlCASCoroprateAction.DataSource = valuationCRUDProperties.dt_Result;
                    corporateAction.ddlCASCoroprateAction.DataTextField = "ACTION_NAME";
                    corporateAction.ddlCASCoroprateAction.DataValueField = "ACTION_TYPE";
                    corporateAction.ddlCASCoroprateAction.DataBind();
                    corporateAction.ddlCASCoroprateAction.Items.Insert(0, "--- Please Select ---");

                    corporateAction.ddlCURDCoroprateAction.DataSource = valuationCRUDProperties.dt_Result;
                    corporateAction.ddlCURDCoroprateAction.DataTextField = "ACTION_NAME";
                    corporateAction.ddlCURDCoroprateAction.DataValueField = "ACTION_TYPE";
                    corporateAction.ddlCURDCoroprateAction.DataBind();
                    corporateAction.ddlCURDCoroprateAction.Items.Insert(0, "--- Please Select ---");
                }
            }
            catch
            {
                throw;
            }

            #endregion

            #region Bind Corporate Search Grid
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_CorporateAction;
                    valuationProperties.PopulateControls = "GET_CORPORATE_ACTION_DETAILS";
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    ac_CorporateAction.dt_CorporateAction = valuationCRUDProperties.dt_Result;

                    corporateAction.gv.DataSource = ac_CorporateAction.dt_CorporateAction;
                    corporateAction.gv.DataBind();

                    corporateAction.btnDelete.Visible = valuationCRUDProperties.dt_Result.Rows.Count > 0 ? true : false;
                }
            }
            catch
            {
                throw;
            }
            #endregion

            #region Peer Company List
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_CorporateAction;
                    valuationProperties.PopulateControls = "GET_PEER_COMPANY_DETAILS";
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    corporateAction.ddlPeerCompanyList.DataSource = valuationCRUDProperties.dt_Result;
                    corporateAction.ddlPeerCompanyList.DataTextField = "PEER_COMPANY_NAME";
                    corporateAction.ddlPeerCompanyList.DataValueField = "PEER_COMPANY_NAME";
                    corporateAction.ddlPeerCompanyList.DataBind();

                    corporateAction.ddlPeerCompanyList.Items.Insert(0, "--- Please Select ---");
                }
            }
            catch
            {
                throw;
            }
            #endregion
        }

        /// <summary>
        /// Method is used to filter grid view
        /// </summary>
        /// <param name="corporateAction">Page object as Parameter</param>
        internal void ApplyFilter(CorporateAction corporateAction)
        {
            try
            {
                string s_CompanyName = string.IsNullOrEmpty(corporateAction.txtCASCompanyName.Text) ? string.Empty : "[Company Name] = '" + Convert.ToString(corporateAction.txtCASCompanyName.Text) + "'";
                string s_CorporateActionType = corporateAction.ddlCASCoroprateAction.SelectedIndex > 0 ? "[Corporate Action Type] = '" + Convert.ToString(corporateAction.ddlCASCoroprateAction.SelectedItem.Text) + "'" : string.Empty;
                string s_FromDate = string.IsNullOrEmpty(corporateAction.datepickerFromDate.Value) || corporateAction.datepickerFromDate.Value.Equals("dd/mmm/yyyy") ? string.Empty : "[EFFECTIVE_DATE] = '" + Convert.ToDateTime(corporateAction.datepickerFromDate.Value).Date + "'";
                string s_ToDate = string.IsNullOrEmpty(corporateAction.datepickerToDate.Value) || corporateAction.datepickerToDate.Value.Equals("dd/mmm/yyyy") ? string.Empty : "[EFFECTIVE_DATE] = '" + Convert.ToDateTime(corporateAction.datepickerToDate.Value).Date + "'";
                string s_DateCompair = string.Empty;

                if ((!(string.IsNullOrEmpty(s_FromDate))) && (!(string.IsNullOrEmpty(s_ToDate))))
                {
                    s_DateCompair = "[EFFECTIVE_DATE] >= #" + Convert.ToDateTime(corporateAction.datepickerFromDate.Value).Date + "# AND [EFFECTIVE_DATE] <= #" + Convert.ToDateTime(corporateAction.datepickerToDate.Value).Date + "# ";
                }

                if ((!(string.IsNullOrEmpty(s_CompanyName))) || (!(string.IsNullOrEmpty(s_CorporateActionType))) || (!(string.IsNullOrEmpty(s_DateCompair))) || !string.IsNullOrEmpty(s_FromDate) || !string.IsNullOrEmpty(s_ToDate))
                {
                    corporateAction.btnClearFilter.Visible = true;
                }

                ac_CorporateAction.dt_TempCorporateAction = ac_CorporateAction.dt_CorporateAction;

                try
                {
                    if (!(string.IsNullOrEmpty(s_CompanyName)))
                        ac_CorporateAction.dt_TempCorporateAction = ac_CorporateAction.dt_TempCorporateAction.Select("" + s_CompanyName + "").CopyToDataTable();

                    if (!(string.IsNullOrEmpty(s_CorporateActionType)))
                        ac_CorporateAction.dt_TempCorporateAction = ac_CorporateAction.dt_TempCorporateAction.Select("" + s_CorporateActionType + "").CopyToDataTable();

                    if ((!(string.IsNullOrEmpty(s_FromDate))) && (!(string.IsNullOrEmpty(s_ToDate))))
                    {
                        ac_CorporateAction.dt_TempCorporateAction = ac_CorporateAction.dt_TempCorporateAction.Select("" + s_DateCompair + "").CopyToDataTable();
                    }
                    else
                    {
                        if (!(string.IsNullOrEmpty(s_FromDate)))
                            ac_CorporateAction.dt_TempCorporateAction = ac_CorporateAction.dt_TempCorporateAction.Select("" + s_FromDate + "").CopyToDataTable();

                        if (!(string.IsNullOrEmpty(s_ToDate)))
                            ac_CorporateAction.dt_TempCorporateAction = ac_CorporateAction.dt_TempCorporateAction.Select("" + s_ToDate + "").CopyToDataTable();
                    }
                }
                catch
                {
                    ac_CorporateAction.dt_TempCorporateAction = new DataTable();
                }

                corporateAction.gv.DataSource = ac_CorporateAction.dt_TempCorporateAction;
                corporateAction.gv.DataBind();
                corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                corporateAction.h3AddEdit.Style.Add("display", "none");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to Clear filter from grid
        /// </summary>
        /// <param name="corporateAction">Page object as Parameter</param>
        internal void ResetFilter(CorporateAction corporateAction)
        {
            try
            {
                corporateAction.ddlCASCoroprateAction.SelectedIndex = -1;
                corporateAction.txtCASCompanyName.Text = string.Empty;
                corporateAction.datepickerFromDate.Value = corporateAction.datepickerToDate.Value = string.Empty;

                corporateAction.gv.DataSource = ac_CorporateAction.dt_CorporateAction;
                corporateAction.gv.DataBind();

                ac_CorporateAction.dt_TempCorporateAction = ac_CorporateAction.dt_CorporateAction;
                corporateAction.btnClearFilter.Visible = false;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used boud grid view data
        /// </summary>
        /// <param name="corporateAction">corporateAction Page Object</param>
        /// <param name="e">e</param>
        /// <param name="n_index">int n_index Parameter</param>
        /// <param name="hash_Table">hashtable of all ref int parameters</param>
        internal void GridViewRowDataBound(CorporateAction corporateAction, GridViewRowEventArgs e, ref int n_index, ref Hashtable hash_Table)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    hash_Table["n_ID"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    hash_Table["n_Delete"] = n_index;
                                    e.Row.Cells[Convert.ToInt32(hash_Table["n_Delete"].ToString())].Controls.Add(AddDeleteAllCheckBox());
                                    break;

                                case "COMPANY NAME":
                                    hash_Table["n_CompanyName"] = n_index;
                                    break;

                                case "ACTION_TYPE":
                                    hash_Table["n_Action_Type"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "EFFECTIVE_DATE":
                                    hash_Table["n_Effective_Date"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "EFFECTIVE DATE":
                                    hash_Table["n_Effective_Date_Show"] = n_index;
                                    break;

                                case "RATIO_MULTIPLIER":
                                    hash_Table["n_RATIO_MULTIPLIER"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "RATIO_DIVISOR":
                                    hash_Table["n_RATIO_DIVISOR"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "RATIO":
                                    hash_Table["n_Ratio"] = n_index;
                                    break;

                                case "APPLIED_EDIT":
                                    hash_Table["n_APPLIED_EDIT"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "APPLIED":
                                    hash_Table["n_Applied"] = n_index;
                                    break;

                                case "APPLYTO":
                                    hash_Table["n_ApplyTo"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "COMMENTS":
                                    hash_Table["n_Comments"] = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTION":
                                    hash_Table["n_Action"] = n_index;
                                    break;

                                case "ACTIONS":
                                    hash_Table["n_Actions"] = n_index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_ID"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_Action_Type"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_Effective_Date"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_RATIO_MULTIPLIER"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_RATIO_DIVISOR"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_APPLIED_EDIT"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_ApplyTo"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_Comments"].ToString())].Visible = e.Row.Cells[Convert.ToInt32(hash_Table["n_Actions"].ToString())].Visible = false;

                        e.Row.Cells[Convert.ToInt32(hash_Table["n_Delete"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_Action"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_Effective_Date_Show"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_Ratio"].ToString())].HorizontalAlign = e.Row.Cells[Convert.ToInt32(hash_Table["n_Applied"].ToString())].HorizontalAlign = HorizontalAlign.Center;

                        if (e.Row.Cells[Convert.ToInt32(hash_Table["n_Comments"].ToString())].Text.Equals("&nbsp;"))
                            e.Row.Cells[Convert.ToInt32(hash_Table["n_Comments"].ToString())].Text = string.Empty;

                        e.Row.Cells[Convert.ToInt32(hash_Table["n_Comments"].ToString())].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 350px;");

                        e.Row.Cells[Convert.ToInt32(hash_Table["n_Action"].ToString())].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[Convert.ToInt32(hash_Table["n_ID"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_CompanyName"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_Action_Type"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_Effective_Date_Show"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_RATIO_MULTIPLIER"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_RATIO_DIVISOR"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_ApplyTo"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_Comments"].ToString())].Text, "Edit"));
                        e.Row.Cells[Convert.ToInt32(hash_Table["n_Delete"].ToString())].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_Delete"].ToString())].Text.Equals("1"), e.Row.Cells[Convert.ToInt32(hash_Table["n_Applied"].ToString())].Text, e.Row.Cells[Convert.ToInt32(hash_Table["n_Effective_Date_Show"].ToString())].Text, Convert.ToString(CommonModel.CheckAgainstLockedAccountingReport(e.Row.Cells[Convert.ToInt32(hash_Table["n_Effective_Date"].ToString())].Text, userSessionInfo) ? 1 : 0)));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to create Image link
        /// </summary>
        /// <param name="s_ToolTip">Tool tip as parameter</param>
        /// <param name="s_Url">Image url as paramter</param>
        /// <param name="s_ID">Corportae Action master table Id as Parameter</param>
        /// <param name="s_CompanyName">Corporate Action Company Name as Paramter</param>
        /// <param name="s_ActionType">Corporate Action Type as Parameter</param>
        /// <param name="s_EffectiveDate">Effective date as Parameter</param>
        /// <param name="s_RatioMultiplier">Ratio Multiplier as Parameter</param>
        /// <param name="s_RatioDivisor">Ration Divisior as Parameter</param>
        /// <param name="s_ApplyTo">Corporate Action Applied to All Options or Outstanding Options</param>
        /// <param name="s_Remark">Remark as Paramter</param>
        /// <param name="s_Action">CUD Operation varaiable as Parameter</param>
        /// <returns>Return image button object</returns>
        private ImageButton AddImageLink(string s_ToolTip, string s_Url, string s_ID, string s_CompanyName, string s_ActionType, string s_EffectiveDate, string s_RatioMultiplier, string s_RatioDivisor, string s_ApplyTo, string s_Remark, string s_Action)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_Url;
                imgButton.ToolTip = s_ToolTip;
                imgButton.Style.Add("cursor", "pointer");
                s_Remark = s_Remark.Equals("&nbsp;") ? "" : s_Remark;

                if (!string.IsNullOrEmpty(s_CompanyName))
                {
                    imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_ID + "','" + s_CompanyName + "','" + s_ActionType + "','" + s_EffectiveDate + "','" + s_RatioMultiplier + "','" + s_RatioDivisor + "','" + s_ApplyTo + "','" + s_Remark + "', this)");
                }

                imgButton.Enabled = ac_CorporateAction.Is_Edit;
                return imgButton;
            }
        }

        /// <summary>
        /// This Method is used to add checkboxes to all grid rows
        /// </summary>
        /// <returns>Return check box objects</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chk";
                checkBox.Text = string.Empty;
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }

        /// <summary>
        /// Add check box to the grid
        /// </summary>
        /// <param name="s_CAID">Corporate Action Master table Id as Parameter</param>
        /// <param name="IsDeleted">Deleted flag as Parameter</param>
        /// <param name="s_IsApplied">Is Applied</param>
        /// <param name="s_EffectiveDate">Effective Date</param>
        /// <param name="s_Islocked">s_Islocked</param>
        /// <returns>Checkbox</returns>
        private CheckBox AddCheckBox(string s_CAID, bool IsDeleted, string s_IsApplied, string s_EffectiveDate, string s_Islocked)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_CAID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.AutoPostBack = false;
                checkBox.Attributes.Add("name", "Types");
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                if (!string.IsNullOrEmpty(s_CAID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_CAID + "','" + s_IsApplied + "','" + s_EffectiveDate + "',this,'" + s_Islocked + "')");
                }

                return checkBox;
            }
        }

        /// <summary>
        /// Method is used to perform CUD operation
        /// </summary>
        /// <param name="corporateAction">Page object as Parameter</param>
        internal void CUDCorporateAction(CorporateAction corporateAction)
        {
            try
            {
                bool IsValidEffectiveDate = false, IsPostCorpActAvailable = false;
                string s_EffectiveDate = string.Empty;

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_CorporateAction;
                    valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                    valuationProperties.CA_EffectiveDate = null;

                    if (!string.IsNullOrEmpty(corporateAction.hdnDeletedRecords.Value))
                    {
                        valuationProperties.Action = "DEL";
                        valuationProperties.CA_CAID = corporateAction.hdnDeletedRecords.Value.TrimStart(',');
                    }
                    else if (!string.IsNullOrEmpty(corporateAction.hdnCAID.Value))
                    {
                        valuationProperties.Action = "UPD";
                        valuationProperties.CA_CAID = corporateAction.hdnCAID.Value;
                    }
                    else if (string.IsNullOrEmpty(corporateAction.hdnCAID.Value))
                    {
                        valuationProperties.Action = "INS";
                        valuationProperties.CA_CAID = string.Empty;
                    }

                    if ((!(valuationProperties.Action.Equals("DEL"))) && (string.IsNullOrEmpty(corporateAction.hdnCAID.Value)))
                    {
                        IsValidEffectiveDate = CheckEffectiveDateRange(corporateAction.dpEffectiveDate.Value, corporateAction.ddlCURDCoroprateAction.SelectedValue, ac_CorporateAction.dt_CorporateAction);
                    }
                    else if (valuationProperties.Action.Equals("DEL"))
                    {
                        if (ac_CorporateAction.dt_CorporateAction.Rows.Count > 0)
                        {
                            foreach (string item in valuationProperties.CA_CAID.Split(','))
                            {
                                s_EffectiveDate = ac_CorporateAction.dt_CorporateAction.Select("ID = '" + item + "'")[0]["EFFECTIVE_DATE"].ToString();
                                foreach (DataRow perRow in ac_CorporateAction.dt_CorporateAction.Rows)
                                {
                                    if ((Convert.ToDateTime(s_EffectiveDate).Date < Convert.ToDateTime(perRow["EFFECTIVE_DATE"]).Date))
                                    {
                                        IsPostCorpActAvailable = true;
                                        break;
                                    }
                                }
                            }

                        }
                        valuationProperties.CA_EffectiveDate = string.IsNullOrEmpty(Convert.ToString(corporateAction.hdnEffectiveDate.Value)) ? Convert.ToDateTime("1/1/1800 12:00:00 AM") : Convert.ToDateTime(corporateAction.hdnEffectiveDate.Value);
                    }

                    if (!IsValidEffectiveDate)
                    {
                        if (!IsPostCorpActAvailable)
                        {
                            valuationProperties.CA_CompanyName = corporateAction.txtCUDCompanyName.Text;
                            valuationProperties.CA_CorporateActionType = (corporateAction.ddlCURDCoroprateAction.SelectedIndex > 0) ? corporateAction.ddlCURDCoroprateAction.SelectedValue : string.Empty;
                            valuationProperties.CA_RatioMultiplier = (string.IsNullOrEmpty(corporateAction.txtCUDRatioMultiplier.Text)) ? 0 : Convert.ToInt32(corporateAction.txtCUDRatioMultiplier.Text);
                            valuationProperties.CA_RatioDivisor = (string.IsNullOrEmpty(corporateAction.txtCUDRatioDivisor.Text)) ? 0 : Convert.ToInt32(corporateAction.txtCUDRatioDivisor.Text);
                            valuationProperties.CA_EffectiveDate = !string.IsNullOrEmpty(Convert.ToString(valuationProperties.CA_EffectiveDate)) ? valuationProperties.CA_EffectiveDate : ((string.IsNullOrEmpty(corporateAction.dpEffectiveDate.Value)) || (corporateAction.dpEffectiveDate.Value.Equals("dd/mmm/yyyy"))) ? DateTime.Now.Date : Convert.ToDateTime(corporateAction.dpEffectiveDate.Value);
                            valuationProperties.CA_ApplyTo = corporateAction.rdbCUDApplyTo.SelectedValue;
                            valuationProperties.CA_Remark = (string.IsNullOrEmpty(corporateAction.txtCUDRemark.Text)) ? string.Empty : corporateAction.txtCUDRemark.Text;
                            valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;

                            if (Convert.ToDateTime(valuationProperties.CA_EffectiveDate) > DateTime.Now.Date)
                            {
                                throw new EDFinancialsException(valuationServiceClient.GetValuation_L10N("INVALID_DATE", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10));
                            }

                            ValuationCRUDProperties valuationCRUDProperties = new ValuationCRUDProperties();

                            //Check whether report is locked or not for entered CA_EffectiveDate
                            if (!CommonModel.CheckAgainstLockedAccountingReport(Convert.ToString(valuationProperties.CA_EffectiveDate), userSessionInfo))
                            {
                                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                            }
                            else
                            {
                                //set valuationCRUDProperties.a_result = 7 if accounting report is locked for CA_EffectiveDate
                                valuationCRUDProperties.a_result = 7;
                            }

                            switch (valuationCRUDProperties.a_result)
                            {
                                case 0:
                                    corporateAction.h3AddEdit.Style.Add("display", "block");
                                    corporateAction.hdnIsPanelExpand.Value = valuationProperties.Action.Equals("DEL") ? "0" : "1";
                                    corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    corporateAction.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("FAIL_MSG", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                                    corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    break;

                                case 1:
                                    corporateAction.h3AddEdit.Style.Add("display", "none");
                                    corporateAction.hdnIsPanelExpand.Value = "0";
                                    corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    corporateAction.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("SUCCESS_MSG", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                                    corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                                    break;

                                case 3:
                                    corporateAction.h3AddEdit.Style.Add("display", "none");
                                    corporateAction.hdnIsPanelExpand.Value = "0";
                                    corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    corporateAction.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("SUCCESS_MSG_WITH_CA", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                                    corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                                    break;

                                case 4:
                                    corporateAction.h3AddEdit.Style.Add("display", "block");
                                    corporateAction.hdnIsPanelExpand.Value = "1";
                                    corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    corporateAction.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("ALREADY_EXIST", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                                    corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                                    break;

                                case 5:
                                    corporateAction.h3AddEdit.Style.Add("display", "none");
                                    corporateAction.hdnIsPanelExpand.Value = "0";
                                    corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    corporateAction.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("DELETE_DATA", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                                    corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                                    break;

                                case 6:
                                    if (valuationProperties.Action.Equals("DEL"))
                                        corporateAction.h3AddEdit.Style.Add("display", "none");
                                    else
                                        corporateAction.h3AddEdit.Style.Add("display", "block");

                                    corporateAction.hdnDeletedRecords.Value = string.Empty;
                                    corporateAction.hdnIsPanelExpand.Value = valuationProperties.Action.Equals("DEL") ? "0" : "1";
                                    corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    corporateAction.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCACanNotEditSettings", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                                    corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    break;

                                case 7:
                                    corporateAction.h3AddEdit.Style.Add("display", "none");
                                    corporateAction.hdnIsPanelExpand.Value = "0";
                                    corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    corporateAction.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("LOCKED_REPORT", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                                    corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    break;

                                case 8:
                                    corporateAction.h3AddEdit.Style.Add("display", "none");
                                    corporateAction.hdnIsPanelExpand.Value = "0";
                                    corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    corporateAction.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCanNotEditCAApplied", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                                    corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    break;
                            }
                        }
                        else
                        {
                            corporateAction.h3AddEdit.Style.Add("display", "none");
                            corporateAction.hdnIsPanelExpand.Value = "0";
                            corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            corporateAction.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCanNotDeleteCA", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                            corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                        }
                        corporateAction.hdnCAID.Value = corporateAction.hdnDeletedRecords.Value = string.Empty;
                    }
                    else
                    {
                        corporateAction.h3AddEdit.Style.Add("display", "block");
                        corporateAction.hdnIsPanelExpand.Value = "1";
                        corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                        corporateAction.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("CA_APPLY_ALREADY", CommonConstantModel.s_CorporateAction, CommonConstantModel.s_ValuationL10);
                        corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    }
                    BindControls(corporateAction);
                }
            }
            catch (EDFinancialsException Ex)
            {
                corporateAction.h3AddEdit.Style.Add("display", "block");
                corporateAction.hdnIsPanelExpand.Value = "1";
                corporateAction.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                corporateAction.ctrSuccessErrorMessage.s_MessageText = Ex.Message.ToString();
                corporateAction.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        /// <summary>
        /// Check effective date is earler or not
        /// </summary>
        /// <param name="s_EffectvieDate">Effective date as Parameter</param>
        /// <param name="s_CaActionType">Corporte Action type as Parameter</param>
        /// <param name="dt_CorporateActionDetails">Corporate Action details as Parameter</param>
        /// <returns>Return type As Boolean</returns>
        private bool CheckEffectiveDateRange(string s_EffectvieDate, string s_CaActionType, DataTable dt_CorporateActionDetails)
        {
            try
            {
                bool is_Effective_date = false;

                if (dt_CorporateActionDetails.Rows.Count > 0)
                {
                    foreach (DataRow perRow in dt_CorporateActionDetails.Rows)
                    {
                        if ((Convert.ToDateTime(s_EffectvieDate).Date <= Convert.ToDateTime(perRow["EFFECTIVE_DATE"]).Date) && (Convert.ToString(perRow["ACTION_TYPE"]) == s_CaActionType))
                        {
                            is_Effective_date = true;
                            break;
                        }
                    }
                }
                return is_Effective_date;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method used to work when grid view paging
        /// </summary>
        /// <param name="sender">Object Parameter</param>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="corporateAction">Pass parameter as page</param>
        internal void gv_PageIndexChanging(object sender, GridViewPageEventArgs e, CorporateAction corporateAction)
        {
            try
            {
                corporateAction.gv.PageIndex = e.NewPageIndex;
                corporateAction.gv.DataSource = ac_CorporateAction.dt_CorporateAction;
                corporateAction.gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CorporateActionModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}