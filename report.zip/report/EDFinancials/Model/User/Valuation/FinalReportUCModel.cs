﻿using EDFinancials.Model.Generic;
using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.IO;
using System.Web;
using Ionic.Zip;
using Microsoft.Office.Interop.Word;
using EDFinancials.View.User.Valuation.UserControl;
using EDFinancials.Model.User.Valuation.UserControl_Model;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// FinalReportUCModel
    /// </summary>
    public class FinalReportUCModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public FinalReportUCModel()
        {
            if (ac_ValuationReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationReport);
                ac_ValuationReport = (CommonModel.AC_ValuationReport)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationReport];
            }
        }

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="finalReportUC">reviewerFeedback page object</param>
        internal void ReadL10N_UI(FinalReportUC finalReportUC)
        {
            try
            {
                if ((ac_ValuationReport.dt_Valuation_Report_UI_Text != null) && (ac_ValuationReport.dt_Valuation_Report_UI_Text.Rows.Count > 0))
                {
                    finalReportUC.lblStatus.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblReportStatus'"))[0]["LabelName"]);
                    finalReportUC.lblStatus.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblReportStatus'"))[0]["LabelToolTip"]);

                    finalReportUC.lblUploadSignedReport.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblUploadSignedReport'"))[0]["LabelName"]);
                    finalReportUC.lblUploadSignedReport.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblUploadSignedReport'"))[0]["LabelToolTip"]);

                    finalReportUC.lblUserComments.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblUserComments'"))[0]["LabelName"]);
                    finalReportUC.lblUserComments.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblUserComments'"))[0]["LabelToolTip"]);

                    finalReportUC.btnSave.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSave'"))[0]["LabelName"]);
                    finalReportUC.btnSave.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSave'"))[0]["LabelToolTip"]);

                    finalReportUC.btnUpload.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnUpload'"))[0]["LabelName"]);
                    finalReportUC.btnUpload.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnUpload'"))[0]["LabelToolTip"]);

                    finalReportUC.btnDownloadUplDoc.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnDownloadUplDoc'"))[0]["LabelName"]);
                    finalReportUC.btnDownloadUplDoc.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnDownloadUplDoc'"))[0]["LabelToolTip"]);

                    finalReportUC.lblAgreeByClient.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblAgreeByClient'"))[0]["LabelName"]);
                    finalReportUC.lblAgreeByClient.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblAgreeByClient'"))[0]["LabelToolTip"]);

                    finalReportUC.btnAgree.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnAgree'"))[0]["LabelName"]);
                    finalReportUC.btnAgree.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnAgree'"))[0]["LabelToolTip"]);

                    finalReportUC.btnDisagree.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnDisagree'"))[0]["LabelName"]);
                    finalReportUC.btnDisagree.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnDisagree'"))[0]["LabelToolTip"]);

                    finalReportUC.btnSendToClient.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSendToClient'"))[0]["LabelName"]);
                    finalReportUC.btnSendToClient.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSendToClient'"))[0]["LabelToolTip"]);

                    finalReportUC.lblInvoiceNumber.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblInvoiceNumber'"))[0]["LabelName"]);
                    finalReportUC.lblInvoiceNumber.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblInvoiceNumber'"))[0]["LabelToolTip"]);

                    finalReportUC.btnUnlockGrants.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnUnlockGrants'"))[0]["LabelName"]);
                    finalReportUC.btnUnlockGrants.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnUnlockGrants'"))[0]["LabelToolTip"]);

                    finalReportUC.lblGeneratedDocVersion.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblGeneratedDocVersion'"))[0]["LabelName"]);
                    finalReportUC.lblGeneratedDocVersion.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblGeneratedDocVersion'"))[0]["LabelToolTip"]);

                    finalReportUC.lblFRCommentHistory.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblFRCommentHistory'"))[0]["LabelName"]);
                    finalReportUC.lblFRCommentHistory.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblFRCommentHistory'"))[0]["LabelToolTip"]);

                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Dropdown for lock record
        /// </summary>
        /// <param name="finalReportUC">Page object</param>
        internal void BindStatus(FinalReportUC finalReportUC)
        {
            using (System.Data.DataTable dataTable = new System.Data.DataTable())
            {
                dataTable.Columns.Add("STATUS_ID", typeof(string));
                dataTable.Columns.Add("STATUS", typeof(string));

                DataRow dataRow = null;
                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "1";
                dataRow["STATUS"] = "Lock";
                dataTable.Rows.Add(dataRow);

                finalReportUC.ddlStatus.DataSource = dataTable;
                finalReportUC.ddlStatus.DataTextField = "STATUS";
                finalReportUC.ddlStatus.DataValueField = "STATUS_ID";
                finalReportUC.ddlStatus.DataBind();

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    try
                    {
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                        valuationProperties.PageName = CommonConstantModel.s_MaintainVersion;
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.Action = "R";
                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        ac_ValuationReport.dt_VersionDetails = valuationCRUDProperties.dt_Result;

                        ac_ValuationReport.dt_VersionDetails.Columns["DOCUMENT_NAME"].ColumnName = "Document Name";
                        ac_ValuationReport.dt_VersionDetails.Columns["VERSION_NUMBER"].ColumnName = "Version Number";
                        ac_ValuationReport.dt_VersionDetails.Columns["SIGNED_COPY_NAME"].ColumnName = "Signed Copy";
                        ac_ValuationReport.dt_VersionDetails.Columns.Add("Action", typeof(string));

                        finalReportUC.tblApproved.Visible = false;

                    }
                    catch
                    {
                        //Do Nothing
                    }
                }
            }
        }

        /// <summary>
        /// This method is used to hide TR
        /// </summary>
        /// <param name="finalReportUC">Page object</param>
        internal void HideTR(FinalReportUC finalReportUC)
        {
            finalReportUC.trDisapprove.Visible = false;
            finalReportUC.tblUnlockGrants.Visible = false;
        }

        /// <summary>
        /// This method is used to hide TR
        /// </summary>
        /// <param name="finalReportUC">Page object</param>
        internal void BindGrid(FinalReportUC finalReportUC)
        {

            if (ac_ValuationReport.dt_VersionDetails != null && ac_ValuationReport.dt_VersionDetails.Rows.Count > 0)
            {
                DataRow[] dr = ac_ValuationReport.dt_VersionDetails.Select("GROUP_ID = '" + finalReportUC.hdnGroupNo.Value + "'");

                if (dr.Count() > 0)
                {
                    DataView dv_VersionDetails = new DataView(dr.CopyToDataTable());

                    using (System.Data.DataTable dt = dv_VersionDetails.ToTable("DT", true, "Document Name", "Version Number", "GROUP_ID", "Action").Copy())
                    {
                        finalReportUC.gvVersionDetails.DataSource = dt;
                        finalReportUC.gvVersionDetails.DataBind();
                    }
                }
            }
        }

        /// <summary>
        /// Download Reports
        /// </summary>
        /// <param name="finalReportUC">object of the report format page</param>
        /// <param name="s_ButtonID">Button ID</param>
        public void Save_FinalTemplate(FinalReportUC finalReportUC, string s_ButtonID)
        {
            try
            {
                string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
                string s_SelectedTemplateName = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["TEMPLATE_NAME"].ToString() + ".pdf";
                string s_GroupNumber = Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]);
                decimal d_VersionNumber = 1;

                if (ac_ValuationReport.dt_VersionDetails != null && ac_ValuationReport.dt_VersionDetails.Rows.Count != 0)
                {
                    DataRow[] drVersion = ac_ValuationReport.dt_VersionDetails.Select("GROUP_ID = '" + s_GroupNumber + "'");
                    d_VersionNumber = drVersion.Count() != 0 ? Convert.ToInt32(drVersion.Last()["Version Number"]) + 1 : 1;
                    s_SelectedTemplateName = s_SelectedTemplateName.Replace(".pdf", "_Version_" + Convert.ToString(drVersion.Count() != 0 ? Convert.ToInt32(drVersion.Last()["Version Number"]) + 1 : 1));
                }
                else
                {
                    s_SelectedTemplateName = s_SelectedTemplateName.Replace(".pdf", "_Version_1");
                }

                if (!File.Exists(Path.Combine(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + s_GroupNumber + "/"), s_SelectedTemplateName + "_" + DateTime.Now.ToString("dd/MMM/yyyy").Replace("/", "_") + ".pdf")))
                {
                    File.Move(Path.Combine(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + s_GroupNumber + "/"), s_SelectedTemplateName + ".pdf"), Path.Combine(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + s_GroupNumber + "/"), s_SelectedTemplateName + "_" + DateTime.Now.ToString("dd/MMM/yyyy").Replace("/", "_") + ".pdf"));
                }

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                    valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.Step = "SAVE_STEP_NUMBER_OR_COMMENT";
                    valuationProperties.Step_Number = s_ButtonID.Equals("btnAgree") ? "6" : s_ButtonID.Equals("btnSendToClient") ? "10" : "1";
                    valuationProperties.Action = "C";
                    valuationProperties.Version_Number = d_VersionNumber;
                    valuationProperties.Final_Report_Name = s_SelectedTemplateName + "_" + DateTime.Now.ToString("dd/MMM/yyyy").Replace("/", "_") + ".pdf";
                    valuationProperties.Is_Sent_OR_Approved_By_Client = s_ButtonID.Equals("btnSendToClient") ? 1 : s_ButtonID.Equals("btnAgree") ? 2 : 0;
                    valuationProperties.Invoice_Number = finalReportUC.txtInvoiceNumber.Text;
                    valuationProperties.Group_Id = s_GroupNumber;
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                }

                switch (s_ButtonID)
                {
                    case "btnAgree":
                        string s_SelectedGrants = string.Empty;
                        using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                        {
                            try
                            {
                                valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                                valuationProperties.PageName = CommonConstantModel.s_MaintainVersion;
                                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                valuationProperties.Action = "R";
                                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                                ac_ValuationReport.dt_VersionDetails = valuationCRUDProperties.dt_Result;

                                ac_ValuationReport.dt_VersionDetails.Columns["DOCUMENT_NAME"].ColumnName = "Document Name";
                                ac_ValuationReport.dt_VersionDetails.Columns["VERSION_NUMBER"].ColumnName = "Version Number";
                                ac_ValuationReport.dt_VersionDetails.Columns.Add("Action", typeof(string));
                            }
                            catch
                            {
                                //Do Nothing
                            }
                        }
                        foreach (var item in ac_ValuationReport.s_SelectedGrants.TrimStart(',').Split(','))
                        {
                            s_SelectedGrants = string.IsNullOrEmpty(s_SelectedGrants) ? "AGRMID = '" + item + "'" : s_SelectedGrants + " OR AGRMID = '" + item + "'";
                        }

                        using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                        {
                            foreach (DataRow perRow in _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report.Select(s_SelectedGrants))
                            {
                                perRow["IS_SENT_OR_APPROVED_BY_CLIENT"] = "2";
                            }
                        }

                        finalReportUC.trSendToClient.Visible = false;
                        finalReportUC.trDisapprove.Visible = false;
                        finalReportUC.tblApproved.Visible = true;
                        break;

                    case "btnSendToClient":
                        finalReportUC.trSendToClient.Visible = false;
                        finalReportUC.trDisapprove.Visible = true;
                        finalReportUC.tblApproved.Visible = false;
                        break;

                    case "btnDisagree":
                        using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                        {
                            _gvUserControlModel.ac_SearchGrantDetails.s_StepNumber = "1";
                        }
                        break;
                }

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                    {
                        valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                        valuationProperties.PAGE_INDEX = _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex.Equals(0) ? 1 : _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex;
                        valuationProperties.PAGE_SIZE = _gvUserControlModel.ac_SearchGrantDetails.n_PageSize.Equals(0) ? 10 : _gvUserControlModel.ac_SearchGrantDetails.n_PageSize;
                        valuationProperties.PAGE_INDEX_LOCKED = _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex_Locked.Equals(0) ? 1 : _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex_Locked;
                        valuationProperties.PAGE_SIZE_LOCKED = _gvUserControlModel.ac_SearchGrantDetails.n_PageSize_Locked.Equals(0) ? 10 : _gvUserControlModel.ac_SearchGrantDetails.n_PageSize_Locked;
                        valuationProperties.GET_DATA_TYPE = "GRANTWISE";
                        valuationProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;
                        valuationProperties.SEN_IsMYESOPsClient = userSessionInfo.ACC_IsMYESOPsClient;
                        valuationProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.SEN_CompanyTitle = userSessionInfo.ACC_CompanyTitle;
                        valuationProperties.Operation_Param = string.Empty;

                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants = valuationCRUDProperties.ds_Result.Tables[0];
                        _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report = valuationCRUDProperties.ds_Result.Tables[0];
                        _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Locked_Valuation_Report = valuationCRUDProperties.ds_Result.Tables[1];
                    }
                }
            }
            catch
            {

                throw;
            }


        }
        /// <summary>
        /// Download Reports
        /// </summary>
        /// <param name="finalReportUC">object of the report format page</param>
        public void Download_Report(FinalReportUC finalReportUC)
        {
            string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
            try
            {
                string temp_GrantRegId = string.Empty;
                foreach (var item in ac_ValuationReport.s_SelectedGrants.TrimStart(',').Split(','))
                {
                    if (!string.IsNullOrEmpty(item))
                    {
                        string x = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Grant Registration ID"].ToString();
                        temp_GrantRegId = string.IsNullOrEmpty(temp_GrantRegId) ? "GRANT_ID = '" + x + "'" : temp_GrantRegId + " OR GRANT_ID = '" + x + "'";
                    }
                }
                string s_SelectedTemplateName = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["TEMPLATE_NAME"].ToString();

                DownloadDocument(s_SelectedTemplateName, finalReportUC, string.Empty);

            }
            catch (Exception ex)
            {
                string message = ex.Message;
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="finalReportUC"></param>
        public void UploadFile(FinalReportUC finalReportUC)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                if (finalReportUC.fileFRUploadDoc.HasFile)
                {
                    if (finalReportUC.fileFRUploadDoc.FileContent.Length <= 5242880)
                    {
                        switch (Convert.ToString(finalReportUC.fileFRUploadDoc.FileName.Split('.').Last()))
                        {
                            case "pdf":
                                try
                                {
                                    // Determine whether the directory exists. 
                                    if (!Directory.Exists(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + userSessionInfo.ACC_CompanyName)))
                                    {
                                        Directory.CreateDirectory(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + userSessionInfo.ACC_CompanyName));
                                    }
                                    string filename = Path.GetFileName(finalReportUC.fileFRUploadDoc.FileName);
                                    if (!File.Exists(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + userSessionInfo.ACC_CompanyName + "/") + filename))
                                    {
                                        finalReportUC.fileFRUploadDoc.SaveAs(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + userSessionInfo.ACC_CompanyName + "/") + filename);
                                        File.Move(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + userSessionInfo.ACC_CompanyName + "/") + filename, HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + userSessionInfo.ACC_CompanyName + "/") + filename);
                                        finalReportUC.lblUploadedDocName.Text = finalReportUC.fileFRUploadDoc.FileName;
                                        finalReportUC.lblDocStatus.ForeColor = System.Drawing.Color.Black;
                                        finalReportUC.lblUploadedDocName.ForeColor = System.Drawing.Color.Black;
                                        finalReportUC.lblDocStatus.Text = " " + Convert.ToString(valuationServiceClient.GetValuation_L10N("lblUploaded", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10));
                                        finalReportUC.btnDownloadUplDoc.Visible = true;
                                    }
                                    else
                                    {
                                        finalReportUC.lblUploadedDocName.Text = finalReportUC.fileFRUploadDoc.FileName;
                                        finalReportUC.lblUploadedDocName.ForeColor = System.Drawing.Color.Red;
                                        finalReportUC.lblDocStatus.Text = " " + valuationServiceClient.GetValuation_L10N("lblFileExist", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10);
                                        finalReportUC.lblDocStatus.ForeColor = System.Drawing.Color.Red;
                                    }
                                }
                                catch
                                {
                                    finalReportUC.lblDocStatus.Text = valuationServiceClient.GetValuation_L10N("lblNotUploaded", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10);
                                }
                                break;

                            default:
                                ScriptManager.RegisterStartupScript(finalReportUC, GetType(), "alertMessage", "alert('" + valuationServiceClient.GetValuation_L10N("lblOnlyPFDFileAllow", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10) + "')", true);
                                break;
                        }

                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(finalReportUC, GetType(), "alertMessage", "alert('" + valuationServiceClient.GetValuation_L10N("lblFileSizeExited", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10) + "')", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(finalReportUC, GetType(), "alertMessage", "alert('" + valuationServiceClient.GetValuation_L10N("lblSelectFile", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10) + "')", true);
                }
            }
        }

        /// <summary>
        /// This method is used to download uploaded document
        /// </summary>
        /// <param name="finalReportUC"></param>
        /// <param name="s_DownloadFileType"></param>
        /// <param name="s_TemplateName"></param>
        public void DownloadUploadedFile(FinalReportUC finalReportUC, string s_DownloadFileType, string s_TemplateName)
        {
            try
            {
                if (s_DownloadFileType.Equals("DocDownload"))
                {
                    DownloadDocument("DownloadUploadedDoc", finalReportUC, string.Empty);
                }
                else if (s_DownloadFileType.Equals("VersionDoc"))
                {
                    DownloadDocument(s_DownloadFileType, finalReportUC, s_TemplateName);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is to download selected templates in zip file
        /// </summary>
        /// <param name="s_SelectedTemplateName">Template name</param>
        /// <param name="finalReportUC">Page object</param>
        /// <param name="s_TemplateName">Template Name</param>
        protected void DownloadDocument(string s_SelectedTemplateName, FinalReportUC finalReportUC, string s_TemplateName)
        {
            try
            {
                using (ZipFile zip = new ZipFile())
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.Buffer = true;
                    HttpContext.Current.Response.BufferOutput = false;
                    HttpContext.Current.Response.ContentType = "application/zip";
                    HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=UploadedReport.zip");

                    if (s_SelectedTemplateName.Equals("DownloadUploadedDoc"))
                    {
                        zip.AddFile(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + userSessionInfo.ACC_CompanyName + "/" + finalReportUC.lblUploadedDocName.Text), "PDF file");
                    }
                    else if (s_SelectedTemplateName.Equals("VersionDoc"))
                    {
                        string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
                        string s_GroupNumber = "/" + "Group_No_" + Convert.ToString(ac_ValuationReport.dt_all_Grants.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]);

                        string s_UploadedFileName = ac_ValuationReport.dt_VersionDetails.Select("GROUP_ID = '" + Convert.ToString(ac_ValuationReport.dt_all_Grants.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]) + "'").Last()["Signed Copy"].ToString();
                        if (!string.IsNullOrEmpty(s_UploadedFileName))
                        {
                            zip.AddFile(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["UploadDocument"] + userSessionInfo.ACC_CompanyName + "/") + s_UploadedFileName, "SignedCopy");
                        }

                        zip.AddFile(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/FinalReport" + s_GroupNumber + "/" + s_TemplateName + ".pdf"), "VersionCopy");

                    }
                    else
                    {
                        zip.AddFile(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/FinalReport/" + s_SelectedTemplateName + ".pdf"), "PDFs");
                    }
                    zip.Save(HttpContext.Current.Response.OutputStream);
                    HttpContext.Current.Response.Flush();
                    HttpContext.Current.Response.End();
                }
            }
            catch (FileNotFoundException e)
            {
                e.Message.Equals("File Not Found!");
            }
        }

        /// <summary>
        /// This method is used to save comments
        /// </summary>
        /// <param name="finalReportUC">Page object</param>
        /// <param name="s_Action">Action</param>
        public void SaveContinue(FinalReportUC finalReportUC, string s_Action)
        {            
            string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
            string s_GroupNumber = Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]);
            decimal d_VersionNumber = 1;

            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                if (finalReportUC.hdnFRModEDLSelected.Value.Equals("Set"))
                {
                    GetModEDLData(_gvUserControlModel);
                }

                ac_ValuationReport.dt_temp_Unlocked_Valuation_Report = _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report;
                _gvUserControlModel.ac_SearchGrantDetails.s_StepNumber = finalReportUC.ddlStatus.SelectedItem.Text.Equals("Approve") ? "6" : "6";
            }

            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                if (ac_ValuationReport.dt_VersionDetails != null && ac_ValuationReport.dt_VersionDetails.Rows.Count != 0)
                {
                    DataRow[] drVersion = ac_ValuationReport.dt_VersionDetails.Select("GROUP_ID = '" + s_GroupNumber + "'");
                    d_VersionNumber = Convert.ToInt32(drVersion.Last()["Version Number"]);
                }

                try
                {
                    valuationProperties.Operation = s_Action.Equals("Create") ? CommonConstantModel.s_OperationCUD : CommonConstantModel.s_OperationRead;
                    valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.Action = s_Action.Equals("Create") ? "C" : "V";
                    valuationProperties.AGRMID = string.Empty;
                    valuationProperties.Step = "SAVE_STEP_NUMBER_OR_COMMENT";
                    valuationProperties.Step_Number = finalReportUC.ddlStatus.SelectedItem.Text.Equals("Lock") ? "6" : "6";
                    valuationProperties.FinalReportUsrComment = finalReportUC.txtUserComments.Text;
                    valuationProperties.UploadedDocName = finalReportUC.lblUploadedDocName.Text;
                    valuationProperties.FinalReportIsRevUsr = userSessionInfo.ACC_UerTypeID.Equals(5) ? 2 : 1;
                    valuationProperties.Group_Id = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"].ToString();
                    valuationProperties.Version_Number = d_VersionNumber;
                    valuationProperties.Invoice_Number = finalReportUC.txtInvoiceNumber.Text;
                    valuationProperties.Signed_Copy_Name = finalReportUC.lblUploadedDocName.Text;
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    switch (valuationCRUDProperties.a_result)
                    {
                        case 2:
                            finalReportUC.trSendToClient.Visible = false;
                            finalReportUC.trDisapprove.Visible = false;
                            finalReportUC.tblApproved.Visible = true;
                            ScriptManager.RegisterStartupScript(finalReportUC, GetType(), "alertMessage", "alert('" + valuationServiceClient.GetValuation_L10N("lblValuationReportMustLocked", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10) + "')", true);
                            break;

                        default:
                            HttpContext.Current.Response.Redirect("ValuationReport.aspx", false);
                            break;
                    }
                }
                catch
                {
                    throw;
                }
            }

        }

        /// <summary>
        /// This method is used to get Modification EDL Grant(s) Data.
        /// </summary>
        /// <param name="_gvUserControlModel">gvUserControlModel object</param>
        private void GetModEDLData(gvUserControlModel _gvUserControlModel)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                valuationProperties.Operation_Param = CommonConstantModel.s_ModEDL;

                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                ac_ValuationReport.dt_all_Grants = _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report = valuationCRUDProperties.dt_Result.Copy().Select("OPERATION_ID = 2 OR OPERATION_ID = 3").Count() > 0 ? valuationCRUDProperties.dt_Result.Copy().Select("OPERATION_ID = 2 OR OPERATION_ID = 3").CopyToDataTable() : new System.Data.DataTable();
            }
        }

        /// <summary>
        /// This method is used to Unlock Grants
        /// </summary>
        /// <param name="finalReportUC">Page object</param>
        public void UnlockGrants(FinalReportUC finalReportUC)
        {
            string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {

                try
                {
                    if (finalReportUC.hdnFRModEDLSelected.Value.Equals("Set"))
                    {
                        using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                        {
                            GetModEDLData(_gvUserControlModel);
                        }
                    }

                    valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                    valuationProperties.PageName = CommonConstantModel.s_UnlockGrants;
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.Group_Id = ac_ValuationReport.dt_temp_Locked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"].ToString();
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                }
                catch
                {
                    throw;
                }
            }

        }

        /// <summary>
        /// Compare records vest-wise
        /// </summary>
        /// <param name="finalReportUC">Page object</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="n_index">index</param>
        /// <param name="n_Action">Action</param>
        /// <param name="n_Group_ID"></param>
        /// <param name="s_ControlID">s_ControlID</param>
        public void BindGrid(FinalReportUC finalReportUC, GridViewRowEventArgs e, ref int n_index, ref int n_Action, ref int n_Group_ID, out string s_ControlID)
        {
            try
            {
                s_ControlID = string.Empty;
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ACTION":
                                    n_Action = n_index;
                                    break;

                                case "GROUP_ID":
                                    n_Group_ID = n_index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:

                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("~/View/App_Themes/images/download.png", e.Row.Cells[0].Text, e.Row.Cells[n_Group_ID].Text, finalReportUC));
                        e.Row.Cells[n_Group_ID].Visible = false;
                        s_ControlID = e.Row.Cells[0].Text.Replace(".pdf", string.Empty);

                        break;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add ImageButton 
        /// </summary>
        /// <param name="s_strUrl">Image path</param>
        /// <param name="s_DocName">Document Name</param>
        /// <param name="s_GroupNo">Group Number</param>
        /// <param name="finalReportUC">finalReportUC</param>
        /// <returns>ImageButton control</returns>        
        private ImageButton AddImageLink(string s_strUrl, string s_DocName, string s_GroupNo, FinalReportUC finalReportUC)
        {
            ImageButton imgButton = new ImageButton();
            imgButton.ImageUrl = s_strUrl;
            imgButton.ToolTip = "Click here to download file";
            imgButton.Style.Add("cursor", "pointer");
            imgButton.ID = s_DocName.Replace(".pdf", string.Empty);
            imgButton.Click += new System.Web.UI.ImageClickEventHandler(finalReportUC.lbtnDownload_Click);
            imgButton.Attributes.Add("onclick", "return DownloadRep('" + s_GroupNo + "')");
            return imgButton;

        }

        #region Destructors
        /// <summary>
        /// This is the Dispose method of ReportParameters Model.
        /// </summary>
        ~FinalReportUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// this is the dispose method of ReportParameters Page.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}