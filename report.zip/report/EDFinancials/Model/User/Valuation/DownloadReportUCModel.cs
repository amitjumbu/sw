﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation.UserControl_Model;
using EDFinancials.View.User.Valuation.UserControl;
using Ionic.Zip;
using Microsoft.Office.Interop.Word;
using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Text;
using System.Web;
using System.Linq;
using System.Text.RegularExpressions;
using MSWord = Microsoft.Office.Interop.Word;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Download Report UC Model
    /// </summary>
    public class DownloadReportUCModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public DownloadReportUCModel()
        {
            if (ac_ValuationReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationReport);
                ac_ValuationReport = (CommonModel.AC_ValuationReport)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationReport];
            }
        }

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="downloadReport_and_WorkingUC">ucCompareGrants page object</param>
        internal void ReadL10N_UI(DownloadReportWithWorkingUC downloadReport_and_WorkingUC)
        {
            try
            {
                if ((ac_ValuationReport.dt_Valuation_Report_UI_Text != null) && (ac_ValuationReport.dt_Valuation_Report_UI_Text.Rows.Count > 0))
                {
                    downloadReport_and_WorkingUC.btnDownloadReport.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnDownloadReport'"))[0]["LabelName"]);
                    downloadReport_and_WorkingUC.btnDownloadReport.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnDownloadReport'"))[0]["LabelToolTip"]);

                    downloadReport_and_WorkingUC.lblUserComments.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblUserComments'"))[0]["LabelName"]);
                    downloadReport_and_WorkingUC.lblUserComments.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblUserComments'"))[0]["LabelToolTip"]);

                    downloadReport_and_WorkingUC.lblReportStatus.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblReportStatus'"))[0]["LabelName"]);
                    downloadReport_and_WorkingUC.lblReportStatus.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblReportStatus'"))[0]["LabelToolTip"]);

                    downloadReport_and_WorkingUC.btnUpdateComments.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnUpdateComments'"))[0]["LabelName"]);
                    downloadReport_and_WorkingUC.btnUpdateComments.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnUpdateComments'"))[0]["LabelToolTip"]);

                    downloadReport_and_WorkingUC.btnSendForReview.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSendForReview'"))[0]["LabelName"]);
                    downloadReport_and_WorkingUC.btnSendForReview.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSendForReview'"))[0]["LabelToolTip"]);

                    downloadReport_and_WorkingUC.btnDRDownloadWorkings.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnDownloadWorkings'"))[0]["LabelName"]);
                    downloadReport_and_WorkingUC.btnDRDownloadWorkings.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnDownloadWorkings'"))[0]["LabelToolTip"]);

                    downloadReport_and_WorkingUC.lblSelectedTemplate.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblSelectedTemplate'"))[0]["LabelName"]);
                    downloadReport_and_WorkingUC.lblSelectedTemplate.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblSelectedTemplate'"))[0]["LabelToolTip"]);

                    downloadReport_and_WorkingUC.lblCommentHistory.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblCommentHistory'"))[0]["LabelName"]);
                    downloadReport_and_WorkingUC.lblCommentHistory.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblCommentHistory'"))[0]["LabelToolTip"]);

                    downloadReport_and_WorkingUC.btnUpdateComments.Visible = !userSessionInfo.ACC_UerTypeID.Equals(5);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Download Reports
        /// </summary>
        /// <param name="downloadReport_and_WorkingUC">object of the report format page</param>
        public void Download_Report(DownloadReportWithWorkingUC downloadReport_and_WorkingUC)
        {
            string s_FinancialYear = string.Empty;
            string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                if (downloadReport_and_WorkingUC.hdnDRWWModEDLSelected.Value.Equals("Set"))
                {
                    GetModEDLData(_gvUserControlModel);
                }
                ac_ValuationReport.dt_temp_Unlocked_Valuation_Report = _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report;
            }

            System.Data.DataTable dt_Parameters = new System.Data.DataTable();
            try
            {
                string temp_GrantRegId = string.Empty, s_GrantDate = string.Empty, s_SchemeName = string.Empty, Grant_IDs = string.Empty;
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    foreach (var item in ac_ValuationReport.s_SelectedGrants.TrimStart(',').Split(','))
                    {
                        if (!string.IsNullOrEmpty(item))
                        {
                            string str = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Grant Registration ID"].ToString();
                            Grant_IDs = Grant_IDs + ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Grant Registration ID"].ToString() + ",";
                            temp_GrantRegId = string.IsNullOrEmpty(temp_GrantRegId) ? "GRANT_ID = '" + str + "'" : temp_GrantRegId + " OR GRANT_ID = '" + str + "'";
                            s_GrantDate = string.IsNullOrEmpty(s_GrantDate) ? ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Grant Date"].ToString() : s_GrantDate + ", " + ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Grant Date"].ToString();
                            s_SchemeName = string.IsNullOrEmpty(s_SchemeName) ? ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Scheme Title"].ToString() : s_SchemeName + ", " + ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Scheme Title"].ToString();
                            valuationProperties.Opt_ID = Convert.ToInt32(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["OPERATION_ID"].ToString());
                            valuationProperties.Opt_Date = Convert.ToDateTime(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["OPERATION_DATE"].ToString());
                        }
                    }

                    valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                    valuationProperties.GET_DATA_TYPE = "VESTWISE";
                    valuationProperties.Grant_ID = Grant_IDs.TrimEnd(',');
                    valuationProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;
                    valuationProperties.SEN_IsMYESOPsClient = userSessionInfo.ACC_IsMYESOPsClient;
                    valuationProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.SEN_CompanyTitle = userSessionInfo.ACC_CompanyTitle;

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    using (System.Data.DataTable dt_VestwiseRecords = valuationCRUDProperties.ds_Result.Tables[0])
                    {

                        valuationProperties.PageName = CommonConstantModel.s_GetReportParams;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                        dt_Parameters = valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result.Select(temp_GrantRegId).CopyToDataTable();

                        if (ac_ValuationReport.s_SelectedGrants.TrimStart(',').Split(',').Count() <= 1)
                        {
                            try
                            {
                                valuationProperties.PageName = CommonConstantModel.s_GetFinancialYear;
                                valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                valuationProperties.AGRMID = ac_ValuationReport.s_SelectedGrants.TrimStart(',');
                                s_FinancialYear = Convert.ToString(valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result.Rows[0][0]);
                            }
                            catch
                            {
                                s_FinancialYear = string.Empty;
                            }
                        }


                        MSWord.Application oMSWord = new MSWord.Application();
                        MSWord.Document oDoc = new MSWord.Document();
                        string s_SelectedTemplateName = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["TEMPLATE_NAME"].ToString() + ".xml";
                        object s_TemplatePath_XML = null;
                        object missing = System.Type.Missing;

                        s_TemplatePath_XML = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/");

                        if (!Directory.Exists(s_TemplatePath_XML + @"\Temp"))
                            Directory.CreateDirectory(s_TemplatePath_XML + @"\Temp");

                        s_TemplatePath_XML = s_TemplatePath_XML + @"\Temp\" + s_SelectedTemplateName;

                        switch (ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["TEMPLATE_NAME"].ToString())
                        {
                            case "Default":
                                File.Copy(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + (userSessionInfo.ACC_IsListed.Equals(1) ? "Default.xml" : "DefaultUnlisted.xml")), Convert.ToString(s_TemplatePath_XML), true);
                                break;

                            default:
                                File.Copy(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/" + s_SelectedTemplateName), Convert.ToString(s_TemplatePath_XML), true);
                                break;
                        }

                        try
                        {
                            oDoc = oMSWord.Documents.Open(ref s_TemplatePath_XML, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
                            oDoc.Activate();

                            ReplaceParameters(ref oDoc, "@NAME_OF_COMPANY", userSessionInfo.ACC_CompanyTitle);
                            ReplaceParameters(ref oDoc, "@ONE_OPTION", dt_VestwiseRecords.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Ratio Options"].ToString());
                            ReplaceParameters(ref oDoc, "@ONE_EQUITY_SHARE", dt_VestwiseRecords.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Ratio Share"].ToString());
                            ReplaceParameters(ref oDoc, "@MARKET_PRICE_IV", !string.IsNullOrEmpty(Convert.ToString(dt_Parameters.Rows[0]["IS_MU_MKT_IV"])) && !Convert.ToString(dt_Parameters.Rows[0]["IS_MU_MKT_IV"]).Equals("0") ? Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'ManuallyEntered'"))[0]["LabelName"]) : dt_Parameters.Rows[0]["SE_IV_REMARK"].ToString());
                            ReplaceParameters(ref oDoc, "@MARKET_PRICE_FV", !string.IsNullOrEmpty(Convert.ToString(dt_Parameters.Rows[0]["IS_MU_MKT_FV"])) && !Convert.ToString(dt_Parameters.Rows[0]["IS_MU_MKT_FV"]).Equals("0") ? Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'ManuallyEntered'"))[0]["LabelName"]) : dt_Parameters.Rows[0]["SE_FV_REMARK"].ToString());
                            ReplaceParameters(ref oDoc, "@EXPECTED_LIFE", !string.IsNullOrEmpty(Convert.ToString(dt_Parameters.Rows[0]["IS_MU_EXL"])) && !Convert.ToString(dt_Parameters.Rows[0]["IS_MU_EXL"]).Equals("0") ? Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'ManuallyEntered'"))[0]["LabelName"]) : dt_Parameters.Rows[0]["EL_REMARK"].ToString());
                            ReplaceParameters(ref oDoc, "@VOLATILITY", !string.IsNullOrEmpty(Convert.ToString(dt_Parameters.Rows[0]["IS_MU_VOL"])) && !Convert.ToString(dt_Parameters.Rows[0]["IS_MU_VOL"]).Equals("0") ? Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'ManuallyEntered'"))[0]["LabelName"]) : dt_Parameters.Rows[0]["VOL_OF_REMARK"].ToString());
                            ReplaceParameters(ref oDoc, "@DIVIDEND", !string.IsNullOrEmpty(Convert.ToString(dt_Parameters.Rows[0]["IS_MU_DIVD"])) && !Convert.ToString(dt_Parameters.Rows[0]["IS_MU_DIVD"]).Equals("0") ? Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'ManuallyEntered'"))[0]["LabelName"]) : dt_Parameters.Rows[0]["DIV_REMARK"].ToString());
                            ReplaceParameters(ref oDoc, "@RISK_FREE_INTEREST_RATE", !string.IsNullOrEmpty(Convert.ToString(dt_Parameters.Rows[0]["IS_MU_RFIR"])) && !Convert.ToString(dt_Parameters.Rows[0]["IS_MU_RFIR"]).Equals("0") ? Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'ManuallyEntered'"))[0]["LabelName"]) : dt_Parameters.Rows[0]["RFIR_REMARK"].ToString());

                            ReplaceParameters(ref oDoc, "@CURRENCY", dt_VestwiseRecords.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Currency"].ToString());
                            ReplaceParameters(ref oDoc, "@EXERCISE_PERIOD", dt_VestwiseRecords.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Exercise Period"].ToString());
                            ReplaceParameters(ref oDoc, "@FACE_VALUE", dt_VestwiseRecords.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Face Value"].ToString());
                            ReplaceParameters(ref oDoc, "@DATE_OF_GRANT", s_GrantDate);
                            ReplaceParameters(ref oDoc, "@SCHEME_NAME", s_SchemeName);
                            ReplaceParameters(ref oDoc, "@LISTING_STATUS", userSessionInfo.ACC_IsListed.Equals(1) ? "Listed" : "Unlisted");
                            ReplaceParameters(ref oDoc, "@RATIO_OF_OPTION_TO_SHARE", dt_VestwiseRecords.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Ratio Options"].ToString() + " : " + dt_VestwiseRecords.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Ratio Share"].ToString());
                            ReplaceParameters(ref oDoc, "@SHARE_PRICE", dt_Parameters.Rows[0]["SHORT_NAME"].ToString());
                            ReplaceParameters(ref oDoc, "@STOCK_EXCHANGE_NAME", dt_Parameters.Rows[0]["STOCK_EXCHANGE_NAME"].ToString());
                            ReplaceParameters(ref oDoc, "@STOCK_EXCHANGE_SHORT_NAME", dt_Parameters.Rows[0]["MARKET_PRICE"].ToString());
                            if (!string.IsNullOrEmpty(s_FinancialYear))
                            {
                                ReplaceParameters(ref oDoc, "@FINANCIAL_YEAR", s_FinancialYear);
                            }
                            else
                            {
                                ReplaceParameters(ref oDoc, "@FINANCIAL_YEAR", "-");
                            }
                            object replaceAll = MSWord.WdReplace.wdReplaceAll;
                            //Replace Footers value
                            foreach (Microsoft.Office.Interop.Word.Section section in oDoc.Sections)
                            {
                                Microsoft.Office.Interop.Word.Range footerRange = section.Footers[Microsoft.Office.Interop.Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                                footerRange.Find.Text = "@NAME_OF_COMPANY";
                                footerRange.Find.Replacement.Text = userSessionInfo.ACC_CompanyTitle;
                                footerRange.Find.Execute(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref replaceAll, ref missing, ref missing, ref missing, ref missing);
                            }

                            GetCalculations("GenerateVestWise", oDoc, dt_VestwiseRecords);
                            GetCalculations("GenerateGrantWise", oDoc, dt_VestwiseRecords);

                            // Determine whether the directory exists. 
                            if (!Directory.Exists(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/" + "FinalReport")))
                            {
                                Directory.CreateDirectory(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "/" + "FinalReport"));
                                Directory.CreateDirectory(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "/" + "TempReport"));
                            }

                            string s_FileName = string.Empty;
                            decimal n_Version_Number = 1;
                            generatePDF(s_SelectedTemplateName, oDoc, out s_FileName, out n_Version_Number);
                            DownloadDocument(s_FileName, n_Version_Number);
                            downloadReport_and_WorkingUC.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";


                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                        finally
                        {
                            ((_Document)oDoc).Close(ref missing, ref missing, ref missing);
                            ((_Application)oMSWord).Quit(ref missing, ref missing, ref missing);
                            File.Delete(Convert.ToString(s_TemplatePath_XML));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                HttpContext.Current.Response.Flush();
                HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                HttpContext.Current.ApplicationInstance.CompleteRequest();
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oDoc"></param>
        /// <param name="s_KeyName"></param>
        /// <param name="s_ReplacementText"></param>
        private void ReplaceParameters(ref MSWord.Document oDoc, string s_KeyName, string s_ReplacementText)
        {
            object missing = System.Type.Missing;
            object replaceAll = MSWord.WdReplace.wdReplaceAll;
            if (s_ReplacementText.Length > 250)
            {
                string s_ReplacementTextTemp = string.Empty;
                int n_NextNumber = 0;
                int n_divideByNumber = 230;
                for (int intloop = 0; intloop < Math.Ceiling((double)s_ReplacementText.Length / n_divideByNumber); intloop++)
                {
                    if (intloop.Equals(0))
                    {
                        s_ReplacementTextTemp = s_ReplacementText.Substring(intloop, n_divideByNumber) + "|~|TEMPCODE|~|";
                        n_NextNumber = n_divideByNumber;
                        oDoc.Content.Application.Selection.Find.Text = s_KeyName; oDoc.Content.Application.Selection.Find.Replacement.Text = string.IsNullOrEmpty(s_ReplacementTextTemp) ? string.Empty : s_ReplacementTextTemp;
                        oDoc.Content.Application.Selection.Find.Execute(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref replaceAll, ref missing, ref missing, ref missing, ref missing);
                    }
                    else
                    {
                        if ((n_NextNumber + n_divideByNumber) <= s_ReplacementText.Length)
                        {
                            s_ReplacementTextTemp = s_ReplacementText.Substring(n_NextNumber, ((s_ReplacementText.Length - n_NextNumber) > 230 ? 230 : (s_ReplacementText.Length - n_NextNumber))) + "|~|TEMPCODE|~|";

                        }
                        else
                        {
                            s_ReplacementTextTemp = s_ReplacementText.Substring(n_NextNumber, (s_ReplacementText.Length - n_NextNumber));
                        }

                        n_NextNumber = (n_divideByNumber * intloop) + n_divideByNumber;
                        oDoc.Content.Application.Selection.Find.Text = "|~|TEMPCODE|~|"; oDoc.Content.Application.Selection.Find.Replacement.Text = string.IsNullOrEmpty(s_ReplacementTextTemp) ? string.Empty : s_ReplacementTextTemp;
                        oDoc.Content.Application.Selection.Find.Execute(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref replaceAll, ref missing, ref missing, ref missing, ref missing);
                    }
                }

            }
            else
            {

                oDoc.Content.Application.Selection.Find.Text = s_KeyName; oDoc.Content.Application.Selection.Find.Replacement.Text = string.IsNullOrEmpty(s_ReplacementText) ? string.Empty : s_ReplacementText;
                oDoc.Content.Application.Selection.Find.Execute(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref replaceAll, ref missing, ref missing, ref missing, ref missing);
            }
        }

        /// <summary>
        /// This method name is used to create template
        /// </summary>
        /// <param name="s_SelectedTemplateName">Template Name</param>
        /// <param name="oDoc">Document object</param>
        /// <param name="s_FileName"></param>
        /// <param name="n_Version_Number"></param>
        private void generatePDF(string s_SelectedTemplateName, MSWord.Document oDoc, out string s_FileName, out decimal n_Version_Number)
        {
            try
            {
                n_Version_Number = 1;
                string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
                string s_GroupNumber = Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]);
                string filename = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "/" + "FinalReport") + "\\" + s_SelectedTemplateName.Replace(".xml", "") + ".pdf";

                if (ac_ValuationReport.dt_VersionDetails != null && ac_ValuationReport.dt_VersionDetails.Rows.Count != 0)
                {
                    DataRow[] drVersion = ac_ValuationReport.dt_VersionDetails.Select("GROUP_ID = '" + s_GroupNumber + "'");
                    n_Version_Number = drVersion.Count() != 0 ? Convert.ToInt32(drVersion.Last()["Version Number"]) : 0;
                    n_Version_Number = n_Version_Number.Equals(0) ? 1 : n_Version_Number + 1;
                }

                //Covert word to pdf
                oDoc.ExportAsFixedFormat(filename, WdExportFormat.wdExportFormatPDF);

                // Determine whether the directory exists. 
                if (!Directory.Exists(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "/" + "FinalReport") + "\\" + "Group_No_" + s_GroupNumber))
                {
                    Directory.CreateDirectory(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "/" + "FinalReport") + "\\" + "Group_No_" + s_GroupNumber);
                }
                s_FileName = s_SelectedTemplateName.Replace(".xml", "") + ".pdf";
                s_FileName = s_FileName.Replace(".pdf", "_Version_" + n_Version_Number);
                if (!File.Exists(Path.Combine(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + s_GroupNumber + "/"), s_FileName + ".pdf")))
                {
                    File.Move(filename, Path.Combine(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + s_GroupNumber + "/"), s_FileName + ".pdf"));
                }
                else
                {
                    File.Delete(Path.Combine(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + s_GroupNumber + "/"), s_FileName + ".pdf"));
                    File.Move(filename, Path.Combine(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + s_GroupNumber + "/"), s_FileName + ".pdf"));

                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to get version details
        /// </summary>
        /// <param name="finalReportUC">Page object</param>
        internal void GetDocumnetVersionDetails(FinalReportUC finalReportUC)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                try
                {
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    valuationProperties.PageName = CommonConstantModel.s_MaintainVersion;
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.Action = "R";
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    ac_ValuationReport.dt_VersionDetails = valuationCRUDProperties.dt_Result;
                    ac_ValuationReport.dt_VersionDetails.Columns["DOCUMENT_NAME"].ColumnName = "Document Name";
                    ac_ValuationReport.dt_VersionDetails.Columns["VERSION_NUMBER"].ColumnName = "Version Number";
                    ac_ValuationReport.dt_VersionDetails.Columns.Add("Action", typeof(string));

                    finalReportUC.gvVersionDetails.DataSource = ac_ValuationReport.dt_VersionDetails;
                }
                catch
                {
                    //Do Nothing
                }
            }
        }
        /// <summary>
        /// This method is to download selected templates in zip file
        /// </summary>
        /// <param name="s_SelectedTemplateName"></param>
        /// <param name="d_VersionNumber"></param>
        protected void DownloadDocument(string s_SelectedTemplateName, decimal d_VersionNumber)
        {
            try
            {
                string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
                string s_GroupNumber = Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]);

                using (ZipFile zip = new ZipFile())
                {
                    zip.AddFile(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + "/" + userSessionInfo.ACC_CompanyName + "/FinalReport/" + "\\" + "Group_No_" + s_GroupNumber + "/" + s_SelectedTemplateName + ".pdf"), "PDFs");

                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.Buffer = true;
                    HttpContext.Current.Response.BufferOutput = false;
                    HttpContext.Current.Response.ContentType = "application/zip";

                    HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=FinalReport.zip");
                    zip.Save(HttpContext.Current.Response.OutputStream);
                    HttpContext.Current.Response.Flush();
                   //Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.Response.SuppressContent = true;
                    // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.  
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (FileNotFoundException e)
            {
                e.Message.Equals("File Not Found!");
            }
        }

        /// <summary>
        /// Method is used to get calculations
        /// </summary>
        /// <param name="s_GenerateCalculations">GenerateCalculations</param>
        /// <param name="oDoc">oDoc</param>
        /// <param name="dt_VestwiseRecords">VestwiseRecords</param>
        /// <returns>string</returns>
        public string GetCalculations(string s_GenerateCalculations, MSWord.Document oDoc = null, System.Data.DataTable dt_VestwiseRecords = null)
        {
            object oMissing = System.Reflection.Missing.Value;
            string Calculations = string.Empty;
            object missing = System.Type.Missing;
            MSWord.Table tempTable = null;
            try
            {
                switch (s_GenerateCalculations)
                {
                    case "GenerateGrantWise":
                        GenerateGrantWiseTable(oDoc, ref oMissing, ref missing, ref tempTable, dt_VestwiseRecords);
                        break;

                    case "GenerateVestWise":
                        GenerateVestWiseTable(oDoc, ref oMissing, ref missing, ref tempTable, dt_VestwiseRecords);
                        break;
                }

            }
            catch
            {
                throw;
            }

            return Calculations;
        }

        /// <summary>
        /// Generate GrantWiseTable
        /// </summary>
        /// <param name="oDoc">oDoc</param>
        /// <param name="oMissing">oMissing</param>
        /// <param name="missing">missing</param>
        /// <param name="tempTable">tempTable</param>
        /// <param name="dt_VestwiseRecords">VestwiseRecords</param>
        private void GenerateGrantWiseTable(MSWord.Document oDoc, ref object oMissing, ref object missing, ref MSWord.Table tempTable, System.Data.DataTable dt_VestwiseRecords)
        {
            while (true)
            {
                using (GetValuationParameters getValuationParameters = new GetValuationParameters())
                {

                    MSWord.Range currentRange = oDoc.Content;
                    Find find = currentRange.Find;
                    find.Text = "@FAIR_VALUE_GRANTWISE";
                    find.ClearFormatting();
                    find.Execute(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);

                    if (find.Found)
                    {
                        string temp_GrantRegId = string.Empty;
                        foreach (var item in ac_ValuationReport.s_SelectedGrants.TrimStart(',').Split(','))
                        {
                            if (!string.IsNullOrEmpty(item))
                            {
                                string x = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Grant Registration ID"].ToString();
                                temp_GrantRegId = string.IsNullOrEmpty(temp_GrantRegId) ? "[Grant Registration ID] = '" + x + "'" : temp_GrantRegId + " OR [Grant Registration ID] = '" + x + "'";
                            }
                        }

                        DataView view = new DataView(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report);
                        using (System.Data.DataTable temp_dt = view.ToTable("DT", true, new string[] { "Grant Registration ID", "Grant Date", "Fair Value", "Exercise Price" }).Copy())
                        {
                            var groupedRecords = temp_dt.Select(temp_GrantRegId).CopyToDataTable().AsEnumerable().GroupBy(m => m.Field<string>("Grant Registration ID"));
                            var shortestRecords = groupedRecords.Select(grp => grp.OrderBy(m => m.Field<string>("Grant Date")).First());

                            using (System.Data.DataTable outputTable = shortestRecords.CopyToDataTable())
                            {
                                using (System.Data.DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                                {
                                    string s_roundingLimit = string.Empty;
                                    int Colcounter = outputTable.Columns.Count;
                                    foreach (DataRow perRow in outputTable.Rows)
                                    {
                                        try
                                        {
                                            double num;
                                            for (int i_counter = 1; i_counter <= (Colcounter - 1); i_counter++)
                                            {
                                                s_roundingLimit = outputTable.Columns[i_counter].ColumnName.ToString().Contains("Intrinsic Value") ? "1" : outputTable.Columns[i_counter].ColumnName.Contains("Fair Value") ? "2" : outputTable.Columns[i_counter].ColumnName.Contains("Market Price") ? "3" : outputTable.Columns[i_counter].ColumnName.Contains("Exercise Price") ? "4" : outputTable.Columns[i_counter].ColumnName.Contains("Expected Life ") ? "5" : outputTable.Columns[i_counter].ColumnName.Contains("Volatility") ? "6" : outputTable.Columns[i_counter].ColumnName.Contains("Riskfree Rate") ? "7" : outputTable.Columns[i_counter].ColumnName.Contains("Dividend yield") ? "8" : "11";

                                                if (!string.IsNullOrEmpty(Convert.ToString(perRow[i_counter])) && i_counter != 0 && double.TryParse(Convert.ToString(perRow[i_counter]), out num))
                                                {
                                                    if (Convert.ToDouble(perRow[i_counter]) > 999)
                                                    {

                                                        perRow[i_counter] = CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Convert.ToString(perRow[i_counter]), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                    }
                                                    else
                                                        perRow[i_counter] = CommonModel.GetRoundedValue(Convert.ToString(perRow[i_counter]), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                }
                                            }

                                        }
                                        catch
                                        {
                                            // Do nothing
                                        }
                                    }

                                    #region Create table
                                    MSWord.Table MSWTable = oDoc.Content.Tables.Add(currentRange, outputTable.Rows.Count + 1, outputTable.Columns.Count, ref oMissing, ref oMissing);

                                    currentRange.InsertParagraphAfter();
                                    MSWTable.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                                    MSWTable.Columns.DistributeWidth();
                                    MSWTable.set_Style("Table Grid");
                                    #endregion

                                    int n_Colcount = 1;
                                    int n_Rowcount = 2;

                                    #region Create header
                                    foreach (DataColumn column in outputTable.Columns)
                                    {
                                        MSWTable.Cell(1, n_Colcount).Range.Cells.Width = n_Colcount.Equals(1) ? 150 : 70;
                                        MSWTable.Cell(1, n_Colcount).Range.Cells.Height = 30;
                                        MSWTable.Cell(1, n_Colcount).Range.Text = !n_Colcount.Equals(1) ? column.ColumnName : column.ColumnName;
                                        MSWTable.Cell(1, n_Colcount).Range.Font.Size = 9;
                                        MSWTable.Cell(1, n_Colcount).Range.Font.Bold = 1;
                                        MSWTable.Cell(1, n_Colcount).Range.Font.ColorIndex = WdColorIndex.wdBlack;
                                        MSWTable.Cell(1, n_Colcount).Range.Shading.BackgroundPatternColor = WdColor.wdColorGray15;
                                        MSWTable.Cell(1, n_Colcount).VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                        MSWTable.Cell(n_Rowcount, n_Colcount).Range.Paragraphs.SpaceAfter = 2;
                                        MSWTable.Cell(n_Rowcount, n_Colcount).Range.Paragraphs.SpaceBefore = 2;
                                        n_Colcount++;
                                    }
                                    #endregion

                                    #region Create rows
                                    n_Colcount = 1;
                                    foreach (DataRow row in outputTable.Rows)
                                    {
                                        n_Colcount = 1;
                                        foreach (DataColumn column in outputTable.Columns)
                                        {

                                            MSWTable.Cell(n_Rowcount, n_Colcount).Range.Cells.Width = n_Colcount.Equals(1) ? 150 : 70;
                                            MSWTable.Cell(n_Rowcount, n_Colcount).Range.Cells.Height = 30;
                                            MSWTable.Cell(n_Rowcount, n_Colcount).Range.Text = Convert.ToString(row[column.ColumnName]);
                                            MSWTable.Cell(n_Rowcount, n_Colcount).Range.Font.Size = 9;
                                            MSWTable.Cell(n_Rowcount, n_Colcount).Range.Font.Bold = 0;
                                            MSWTable.Cell(n_Rowcount, n_Colcount).Range.Font.ColorIndex = WdColorIndex.wdBlack;
                                            MSWTable.Cell(n_Rowcount, n_Colcount).VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                            MSWTable.Cell(n_Rowcount, n_Colcount).Range.Paragraphs.SpaceAfter = 2;
                                            MSWTable.Cell(n_Rowcount, n_Colcount).Range.Paragraphs.SpaceBefore = 2;

                                            n_Colcount++;
                                        }
                                        n_Rowcount++;
                                    }
                                    #endregion
                                    tempTable = MSWTable;
                                    MSWTable.Rows.Alignment = WdRowAlignment.wdAlignRowCenter;
                                }
                            }
                        }
                        view.Dispose();

                    }
                    else
                    {
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Generate vest wise calculations
        /// </summary>
        /// <param name="oDoc"></param>
        /// <param name="oMissing"></param>
        /// <param name="missing"></param>
        /// <param name="tempTable">tempTable</param>
        /// <param name="dt_VestwiseRecords">VestwiseRecords</param>
        private void GenerateVestWiseTable(MSWord.Document oDoc, ref object oMissing, ref object missing, ref MSWord.Table tempTable, System.Data.DataTable dt_VestwiseRecords)
        {
            while (true)
            {
                using (GetValuationParameters getValuationParameters = new GetValuationParameters())
                {
                    int cnt = 0;
                    MSWord.Range currentRange = oDoc.Content;
                    Find find = currentRange.Find;
                    find.Text = "@FAIR_VALUE_CALCULATION";
                    find.ClearFormatting();
                    find.Execute(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);

                    if (find.Found)
                    {
                        string s_PrevTableID = string.Empty;
                        foreach (string item in ac_ValuationReport.s_SelectedGrants.Split(','))
                        {
                            if (!string.IsNullOrEmpty(item))
                            {
                                System.Data.DataTable dt = dt_VestwiseRecords.Select("AGRMID = '" + item + "'").CopyToDataTable();
                                using (System.Data.DataTable outputTable = getValuationParameters.GetCalculationsIVnFV(ref dt, "FairValue"))
                                {
                                    using (System.Data.DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                                    {
                                        string s_roundingLimit = RoundingValuesInDataTable(outputTable, DecimalLimitTable);

                                        outputTable.AcceptChanges();
                                        DataRow dr = null;
                                        //outputTable.Rows.InsertAt(dr = outputTable.NewRow(), 0);
                                        outputTable.Rows.Add(dr = outputTable.NewRow());
                                        outputTable.Rows.Add(dr = outputTable.NewRow());
                                        //outputTable.Rows.Add(dr = outputTable.NewRow());

                                        outputTable.Columns.RemoveAt(outputTable.Columns.Count - 1);
                                        outputTable.Rows.RemoveAt(10);
                                        outputTable.Rows.RemoveAt(10);
                                        outputTable.Rows.RemoveAt(10);
                                        outputTable.Rows.RemoveAt(10);
                                        outputTable.Rows.RemoveAt(10);
                                        outputTable.Rows.RemoveAt(10);

                                        foreach (Microsoft.Office.Interop.Word.Table perTable in oDoc.Content.Tables)
                                        {
                                            if (perTable.ID != null && perTable.ID.Equals(s_PrevTableID))
                                            {
                                                currentRange = (MSWord.Range)tempTable.Cell(outputTable.Rows.Count + 1, 2).Range.Next(WdUnits.wdParagraph, 2).Next(WdUnits.wdParagraph, 2);
                                                if (currentRange == null)
                                                {
                                                    currentRange = (MSWord.Range)tempTable.Cell(outputTable.Rows.Count + 1, 2).Range.Next(WdUnits.wdParagraph, 2).Next(WdUnits.wdParagraph, 1);
                                                    currentRange.ParagraphFormat = tempTable.Cell(outputTable.Rows.Count + 1, 2).Range.Next(WdUnits.wdParagraph, 2).Next(WdUnits.wdParagraph, 1).ParagraphFormat.Duplicate;
                                                    tempTable.Cell(outputTable.Rows.Count + 1, 2).Range.Next(WdUnits.wdParagraph, 2).Next(WdUnits.wdParagraph, 1).Paragraphs.Add();
                                                }
                                                else
                                                {
                                                    tempTable.Cell(outputTable.Rows.Count + 1, 2).Range.Paragraphs.Add();
                                                    currentRange.ParagraphFormat = tempTable.Cell(outputTable.Rows.Count + 1, 2).Range.Next(WdUnits.wdParagraph, 2).Next(WdUnits.wdParagraph, 2).ParagraphFormat.Duplicate;
                                                    tempTable.Cell(outputTable.Rows.Count + 1, 2).Range.Next(WdUnits.wdParagraph, 2).Next(WdUnits.wdParagraph, 2).Paragraphs.Add();
                                                }
                                                break;
                                            }
                                        }

                                        #region Create table
                                        MSWord.Table MSWTable = oDoc.Content.Tables.Add(currentRange, outputTable.Rows.Count + 1, outputTable.Columns.Count, ref oMissing, ref oMissing);
                                        MSWTable.AllowPageBreaks = false;

                                        MSWTable.ID = "AGRMID = " + item;
                                        s_PrevTableID = MSWTable.ID;
                                        currentRange.InsertParagraphAfter();
                                        MSWTable.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                                        MSWTable.Columns.DistributeWidth();
                                        MSWTable.set_Style("Table Grid");
                                        #endregion

                                        int n_Colcount = 1;
                                        int n_Rowcount = 2;

                                        #region Create header
                                        foreach (DataColumn column in outputTable.Columns)
                                        {
                                            MSWTable.Cell(1, n_Colcount).Range.Cells.Width = n_Colcount.Equals(1) ? 140 : 70;
                                            MSWTable.Cell(1, n_Colcount).Range.Cells.Height = 30;
                                            MSWTable.Cell(1, n_Colcount).Range.Text = column.ColumnName;
                                            MSWTable.Cell(1, n_Colcount).Range.Font.Size = 9;
                                            MSWTable.Cell(1, n_Colcount).Range.Font.Bold = 1;
                                            MSWTable.Cell(1, n_Colcount).Range.Font.Name = "Trebuchet MS";
                                            MSWTable.Cell(1, n_Colcount).Range.Font.ColorIndex = WdColorIndex.wdBlack;
                                            MSWTable.Cell(1, n_Colcount).Range.Shading.BackgroundPatternColor = WdColor.wdColorGray20;
                                            MSWTable.Cell(1, n_Colcount).VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                            n_Colcount++;
                                        }
                                        #endregion

                                        #region Create rows
                                        n_Colcount = 1;
                                        foreach (DataRow row in outputTable.Rows)
                                        {
                                            n_Colcount = 1;
                                            foreach (DataColumn column in outputTable.Columns)
                                            {

                                                MSWTable.Cell(n_Rowcount, n_Colcount).Range.Cells.Width = n_Colcount.Equals(1) ? 140 : 70;
                                                MSWTable.Cell(n_Rowcount, n_Colcount).Range.Cells.Height = 20;
                                                if (n_Rowcount.Equals(9) || n_Rowcount.Equals(11) || n_Rowcount.Equals(13))
                                                {
                                                    MSWTable.Cell(n_Rowcount, n_Colcount).Range.Shading.BackgroundPatternColor = WdColor.wdColorGray20;
                                                }

                                                MSWTable.Cell(n_Rowcount, n_Colcount).Range.Text = Convert.ToString(row[column.ColumnName]);
                                                MSWTable.Cell(n_Rowcount, n_Colcount).Range.Font.Size = 9;
                                                MSWTable.Cell(n_Rowcount, n_Colcount).Range.Font.Bold = 0;
                                                MSWTable.Cell(n_Rowcount, n_Colcount).Range.Font.Name = "Trebuchet MS";
                                                MSWTable.Cell(n_Rowcount, n_Colcount).Range.Font.ColorIndex = WdColorIndex.wdBlack;
                                                MSWTable.Cell(n_Rowcount, n_Colcount).Range.ParagraphFormat.Alignment = !n_Colcount.Equals(1) ? WdParagraphAlignment.wdAlignParagraphCenter : WdParagraphAlignment.wdAlignParagraphLeft;
                                                MSWTable.Cell(n_Rowcount, n_Colcount).VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                                MSWTable.Cell(n_Rowcount, n_Colcount).Range.Paragraphs.SpaceAfter = 2;
                                                MSWTable.Cell(n_Rowcount, n_Colcount).Range.Paragraphs.SpaceBefore = 2;
                                                n_Colcount++;
                                            }
                                            n_Rowcount++;
                                        }
                                        #endregion

                                        if (!Convert.ToInt32(dt_VestwiseRecords.Select("AGRMID = '" + item + "'")[0]["Number of Vests"]).Equals(1))
                                        {
                                            MSWTable.Rows[13].Cells[outputTable.Columns.Count].Merge(MSWTable.Rows[13].Cells[2]);
                                        }

                                        MSWTable.Cell(13, 1).Range.Text = "Option Fair Value (" + dt_VestwiseRecords.Rows[0]["Currency"].ToString() + ")";
                                        MSWTable.Cell(13, 1).Range.Font.Bold = 1;
                                        MSWTable.Cell(13, 1).Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;

                                        MSWTable.Cell(13, 2).Range.Text = CommonModel.GetRoundedValue(string.IsNullOrEmpty(Convert.ToString(dt_VestwiseRecords.Select("AGRMID = '" + item + "'")[0]["Fair Value"])) ? "0" : Convert.ToString(dt_VestwiseRecords.Select("AGRMID = '" + item + "'")[0]["Fair Value"]), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                        MSWTable.Cell(13, 2).Range.Font.Bold = 1;
                                        MSWTable.Cell(13, 2).Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                                        MSWTable.Cell(13, 2).VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalBottom;

                                        tempTable = MSWTable;
                                        MSWTable.Rows.Alignment = WdRowAlignment.wdAlignRowCenter;
                                    }
                                }
                            }
                            cnt++;
                        }

                    }
                    else
                    {
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// This method is used to round values in DataTable
        /// </summary>
        /// <param name="outputTable">Final datatable</param>
        /// <param name="DecimalLimitTable">Rounding settings</param>
        /// <returns>string</returns>
        private string RoundingValuesInDataTable(System.Data.DataTable outputTable, System.Data.DataTable DecimalLimitTable)
        {
            string s_roundingLimit = string.Empty;
            int Colcounter = outputTable.Columns.Count;
            foreach (DataRow perRow in outputTable.Rows)
            {
                try
                {
                    s_roundingLimit = perRow[0].ToString().Contains("Intrinsic Value") ? "1" : perRow[0].ToString().Contains("Fair Value") ? "2" : perRow[0].ToString().Contains("Market Price") ? "3" : perRow[0].ToString().Contains("Exercise Price") ? "4" : perRow[0].ToString().Contains("Expected Life ") ? "5" : perRow[0].ToString().Contains("Volatility") ? "6" : perRow[0].ToString().Contains("Riskfree Rate") ? "7" : perRow[0].ToString().Contains("Dividend yield") ? "8" : "11";

                    for (int i_counter = 1; i_counter <= (Colcounter - 2); i_counter++)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(perRow[i_counter])) && i_counter != 0)
                        {
                            if (Convert.ToDouble(perRow[i_counter]) > 999)
                            {

                                perRow[i_counter] = CommonModel.ThousandFormating(CommonModel.GetRoundedValue(Convert.ToString(perRow[i_counter]), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                            }
                            else
                                perRow[i_counter] = CommonModel.GetRoundedValue(Convert.ToString(perRow[i_counter]), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                        }
                    }

                }
                catch
                {
                    // Do nothing
                }
            }
            return s_roundingLimit;
        }

        /// <summary>
        /// This method is used to save comments
        /// </summary>
        /// <param name="downloadReport_and_WorkingUC"></param>
        /// <param name="s_Action"></param>
        /// <param name="s_SelectStep"></param>
        public void SaveContinue(DownloadReportWithWorkingUC downloadReport_and_WorkingUC, string s_Action, string s_SelectStep)
        {
            bool? temp = null;

            string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];

            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                if (downloadReport_and_WorkingUC.hdnDRWWModEDLSelected.Value.Equals("Set"))
                {
                    GetModEDLData(_gvUserControlModel);
                }
                ac_ValuationReport.dt_temp_Unlocked_Valuation_Report = _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report;
                _gvUserControlModel.ac_SearchGrantDetails.s_StepNumber = userSessionInfo.ACC_UerTypeID.Equals(5) ? "4" : "3";
            }

            #region Identify whether report generated or not
            string s_GroupNumber = Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]);
            string s_SelectedTemplateName = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["TEMPLATE_NAME"].ToString() + ".xml";
            int n_Version_Number = 1;
            string s_FileName = string.Empty;

            if (ac_ValuationReport.dt_VersionDetails != null && ac_ValuationReport.dt_VersionDetails.Rows.Count != 0)
            {
                DataRow[] drVersion = ac_ValuationReport.dt_VersionDetails.Select("GROUP_ID = '" + s_GroupNumber + "'");
                n_Version_Number = drVersion.Count() == 0 ? 0 : Convert.ToInt32(drVersion.Last()["Version Number"]);
                n_Version_Number = n_Version_Number + 1;
            }

            // Determine whether the directory exists. 
            s_FileName = s_SelectedTemplateName.Replace(".xml", "") + ".pdf";
            s_FileName = s_FileName.Replace(".pdf", "_Version_" + n_Version_Number);
            #endregion

            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                if (s_SelectStep.Equals("UpdateComments"))
                {
                    valuationProperties.Operation = s_Action.Equals("Create") ? CommonConstantModel.s_OperationCUD : CommonConstantModel.s_OperationRead;
                    valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.Action = s_Action.Equals("Create") ? "C" : "V";
                    valuationProperties.Step = "SAVE_STEP_NUMBER_OR_COMMENT";
                    valuationProperties.Step_Number = "3";
                    valuationProperties.DownloadRepWorkUsrComment = s_SelectStep.Equals("UpdateComments") ? downloadReport_and_WorkingUC.txtUserComments.Text : string.Empty;
                    valuationProperties.DownloadRepWorkIsUsrRev = 1; // 1 : User Comments
                    valuationProperties.Is_Send_For_Review = s_SelectStep.Equals("UpdateComments") ? temp : true;

                    valuationProperties.Group_Id = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"].ToString();
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    switch (valuationCRUDProperties.a_result)
                    {
                        case 1:
                            downloadReport_and_WorkingUC.ctrSuccessErrorMessage.s_MessageText = s_SelectStep.Equals("UpdateComments") ? valuationServiceClient.GetValuation_L10N("lblCommentsUploaded", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10) :
                                                                           valuationServiceClient.GetValuation_L10N("lblSendForReview", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10);
                            downloadReport_and_WorkingUC.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;
                    }
                }
                else if (s_SelectStep.Equals("SendForReview") && File.Exists(Path.Combine(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"] + userSessionInfo.ACC_CompanyName + "\\FinalReport" + "\\" + "Group_No_" + s_GroupNumber + "/"), s_FileName + ".pdf")))
                {
                    if ((string.IsNullOrEmpty(Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["ARWSID"])) ? 0 : Convert.ToInt32(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["ARWSID"])) <= 3)
                    {
                        downloadReport_and_WorkingUC.lblCurrentStatus.Text = "Waiting for Reviewers Feedback";
                        valuationProperties.Operation = s_Action.Equals("Create") ? CommonConstantModel.s_OperationCUD : CommonConstantModel.s_OperationRead;
                        valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.Action = s_Action.Equals("Create") ? "C" : "V";
                        valuationProperties.Step = "SAVE_STEP_NUMBER_OR_COMMENT";
                        valuationProperties.Step_Number = "4";
                        valuationProperties.DownloadRepWorkUsrComment = s_SelectStep.Equals("UpdateComments") ? downloadReport_and_WorkingUC.txtUserComments.Text : string.Empty;
                        valuationProperties.DownloadRepWorkIsUsrRev = 1; // 1 : User Comments
                        valuationProperties.Is_Send_For_Review = s_SelectStep.Equals("UpdateComments") ? temp : true;

                        valuationProperties.Group_Id = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"].ToString();
                        valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        switch (valuationCRUDProperties.a_result)
                        {
                            case 1:
                                downloadReport_and_WorkingUC.ctrSuccessErrorMessage.s_MessageText = s_SelectStep.Equals("UpdateComments") ? valuationServiceClient.GetValuation_L10N("lblCommentsUploaded", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10) :
                                                                               valuationServiceClient.GetValuation_L10N("lblSendForReview", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10);
                                downloadReport_and_WorkingUC.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                break;
                        }

                        if (s_SelectStep.Equals("SendForReview"))
                        {
                            valuationProperties.Operation = "GETUSERMAILSIDS";
                            using (System.Data.DataTable dt_Temp = valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result)
                            {
                                SendMail(dt_Temp.AsEnumerable().Select(m => m.Field<string>("IS_APPROVED")).First().Equals("TRUE") ? "RepoertSentForReview" : "CompletedChanges");
                            }
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(downloadReport_and_WorkingUC, GetType(), "alertMessage", "alert('" + valuationServiceClient.GetValuation_L10N("lblReviewedReport", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10) + "')", true);
                    }

                }
                else
                {
                    using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                    {
                        _gvUserControlModel.ac_SearchGrantDetails.s_StepNumber = "3";
                    }
                    downloadReport_and_WorkingUC.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblGenerateReport", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10);
                    downloadReport_and_WorkingUC.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                }
            }

        }

        /// <summary>
        /// This method is used to get the Modification EDL Grant(s) Data
        /// </summary>
        /// <param name="_gvUserControlModel">gvUserControlModel object</param>
        private void GetModEDLData(gvUserControlModel _gvUserControlModel)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                valuationProperties.Operation_Param = CommonConstantModel.s_ModEDL;

                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                ac_ValuationReport.dt_all_Grants = _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report = valuationCRUDProperties.dt_Result.Copy().Select("OPERATION_ID = 2 OR OPERATION_ID = 3").Count() > 0 ? valuationCRUDProperties.dt_Result.Copy().Select("OPERATION_ID = 2 OR OPERATION_ID = 3").CopyToDataTable() : new System.Data.DataTable();
            }
        }

        /// <summary>
        /// This method is used to trigger a mail to the reviewer/user
        /// </summary>
        /// <param name="s_TemplateName">Template name</param>
        public void SendMail(string s_TemplateName)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    using (System.Data.DataTable dt_ReviewerDetails = genericServiceClient.GetReviewerDetails(genericProperties))
                    {
                        if (dt_ReviewerDetails != null && dt_ReviewerDetails.Rows.Count > 0)
                        {
                            string s_MailBody = MailBody(s_TemplateName);
                            emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                            emailProperties.b_IsBodyHtml = true;
                            emailProperties.s_MailBody = s_MailBody;
                            emailProperties.s_MailTo = string.Join(",", dt_ReviewerDetails.AsEnumerable().SelectMany(r => r.Field<string>("EMAIL_ID").Split(',')).ToArray());
                            emailProperties.s_MailCC = "";
                            emailProperties.s_MailBCC = "";
                            emailProperties.s_MailSubject = Regex.Match(s_MailBody.ToString(), @"<Title>\s*(.+?)\s*</Title>").Value.
                                                            Replace("\r", "").Replace("<Title>", "").Replace("</Title>", "").Replace("\n", "").Replace("\t", "");
                            genericServiceClient.SaveSendMail(emailProperties);
                        }
                    }
                        
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to replace parameters from template
        /// </summary>
        /// <param name="s_TemplateName">Template name</param>
        private string MailBody(string s_TemplateName)
        {
            StringBuilder s_MailBody = new StringBuilder();
            s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\" + s_TemplateName + ".html"));
            s_MailBody.Replace("<<NAME OF COMPANY>>", userSessionInfo.ACC_CompanyName);
            s_MailBody.Replace("@ValCustSupportID", ConfigurationManager.AppSettings["ValCustSupport"]);
            s_MailBody.Replace("@Link", ConfigurationManager.AppSettings["SiteURL"]);
            return s_MailBody.ToString();
        }

        /// <summary>
        ///  Bind GridView Rows
        /// </summary>
        /// <param name="downloadReport_and_WorkingUC"></param>
        /// <param name="e"></param>
        /// <param name="n_index"></param>
        /// <param name="n_Comment"></param>
        public void BindRows(DownloadReportWithWorkingUC downloadReport_and_WorkingUC, GridViewRowEventArgs e, ref int n_index, ref int n_Comment)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "COMMENT":
                                    n_Comment = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_Comment].Attributes.Add("style", "word-break:break-all;word-wrap:break-word");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }
        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~DownloadReportUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}