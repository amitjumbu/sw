﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation.UserControl_Model;
using EDFinancials.View.User.Valuation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class GrantDetailsModel : BaseModel, IDisposable
    {
        bool Is_GrantIDExists = false;
        decimal d_OptFairVal = 0, d_OptIntrinsicVal = 0;

        #region Default Constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public GrantDetailsModel()
        {
            if (ac_GrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_GrantDetails);
                ac_GrantDetails = (CommonModel.AC_GrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_GrantDetails];
            }
        }
        #endregion

        #region Clear CommonModel Static DataTables
        /// <summary>
        /// This Method is used to Clear CommonModel Static DataTables
        /// </summary>
        internal void ClearCommonTables()
        {
            try
            {
                ac_GrantDetails.dt_GrantDetails = null;
                ac_GrantDetails.dt_GetGrantDetails = null;
                ac_GrantDetails.dt_ChildVestDetails = null;
                ac_GrantDetails.dt_UnlockedGrants = null;
                ac_GrantDetails.dt_LockedGrants = null;
                ac_GrantDetails.dt_UpdateGenParams = null;
                ac_GrantDetails.dt_TempVestDetails = null;
                ac_GrantDetails.dt_GrantRegMaster = null;
                ac_GrantDetails.dt_GrantRegDetails = null;
                ac_GrantDetails.dt_DBGrantRegMaster = null;
                ac_GrantDetails.dt_DBGrantRegDetails = null;
                ac_GrantDetails.dt_FileUploads = null;
                ac_GrantDetails.dt_temp_Unlocked_Valuation_Report = null;
                ac_GrantDetails.dt_temp_Locked_Valuation_Report = null;
            }
            catch
            {
                throw;

            }
        }
        #endregion

        #region Bind UI
        /// <summary>
        /// This Method is used to Bind All Labels to UI Control(s)
        /// </summary>
        /// <param name="grantDetails"></param>
        internal void BindUI(GrantDetails grantDetails)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (DataTable dt_GrantDetailUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if ((dt_GrantDetailUI != null) && (dt_GrantDetailUI.Rows.Count > 0))
                        {
                            #region Grant Details Tab Labels
                            grantDetails.lblGDPageName.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDPageName'")[0]["LabelName"]);
                            grantDetails.lblGDPageName.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDPageName'")[0]["LabelToolTip"]);

                            grantDetails.lblPaneOneHeader.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblPaneOneHeader'")[0]["LabelName"]);
                            grantDetails.lblPaneOneHeader.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblPaneOneHeader'")[0]["LabelToolTip"]);

                            grantDetails.lblPaneTwoHeader.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblPaneTwoHeader'")[0]["LabelName"]);
                            grantDetails.lblPaneTwoHeader.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblPaneTwoHeader'")[0]["LabelToolTip"]);

                            grantDetails.lblTabGrantDetails.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblTabGrantDetails'")[0]["LabelName"]);
                            grantDetails.lblTabGrantDetails.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblTabGrantDetails'")[0]["LabelToolTip"]);

                            grantDetails.lblTabViewUpdateGeneralParams.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblTabViewUpdateGeneralParams'")[0]["LabelName"]);
                            grantDetails.lblTabViewUpdateGeneralParams.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblTabViewUpdateGeneralParams'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantSchemeName.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDSchemeName'")[0]["LabelName"]);
                            grantDetails.lblAddGrantSchemeName.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDSchemeName'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantGrantID.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDGrantID'")[0]["LabelName"]);
                            grantDetails.lblAddGrantGrantID.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDGrantID'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantGrantDate.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantGrantDate'")[0]["LabelName"]);
                            grantDetails.lblAddGrantGrantDate.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantGrantDate'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantExercisePrice.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExercisePrice'")[0]["LabelName"]);
                            grantDetails.lblAddGrantExercisePrice.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExercisePrice'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantPricingFormula.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantPricingFormula'")[0]["LabelName"]);
                            grantDetails.lblAddGrantPricingFormula.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantPricingFormula'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantCurrency.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDCurrency'")[0]["LabelName"]);
                            grantDetails.lblAddGrantCurrency.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblGDCurrency'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantVestingDetails.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantVestingDetails'")[0]["LabelName"]);
                            grantDetails.lblAddGrantVestingDetails.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantVestingDetails'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantNumberOfVest.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantNumberOfVest'")[0]["LabelName"]);
                            grantDetails.lblAddGrantNumberOfVest.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantNumberOfVest'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantVestingFrequency.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantVestingFrequency'")[0]["LabelName"]);
                            grantDetails.lblAddGrantVestingFrequency.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantVestingFrequency'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantFirstVesting.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantFirstVesting'")[0]["LabelName"]);
                            grantDetails.lblAddGrantFirstVesting.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantFirstVesting'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantVestingParams.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantVestingParams'")[0]["LabelName"]);
                            grantDetails.lblAddGrantVestingParams.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantVestingParams'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantExercisePeriod.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExercisePeriod'")[0]["LabelName"]);
                            grantDetails.lblAddGrantExercisePeriod.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExercisePeriod'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantExercisePeriodFrom.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExercisePeriodFrom'")[0]["LabelName"]);
                            grantDetails.lblAddGrantExercisePeriodFrom.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExercisePeriodFrom'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantExPrcLnkMultDates.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExPrcLnkMultDates'")[0]["LabelName"]);
                            grantDetails.lblAddGrantExPrcLnkMultDates.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExPrcLnkMultDates'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantExPrcWhcIs.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExPrcWhcIs'")[0]["LabelName"]);
                            grantDetails.lblAddGrantExPrcWhcIs.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExPrcWhcIs'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantExPrcFrom.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExercisePeriodFrom'")[0]["LabelName"]);
                            grantDetails.lblAddGrantExPrcFrom.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantExercisePeriodFrom'")[0]["LabelToolTip"]);

                            grantDetails.btnAddGrantPopulateVestDetails.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantPopulateVestDetails'")[0]["LabelName"]);
                            grantDetails.btnAddGrantPopulateVestDetails.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantPopulateVestDetails'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantSettlementOpt.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantSettlementOpt'")[0]["LabelName"]);
                            grantDetails.lblAddGrantSettlementOpt.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantSettlementOpt'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantRatioOptShares.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantRatioOptShares'")[0]["LabelName"]);
                            grantDetails.lblAddGrantRatioOptShares.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantRatioOptShares'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantTrustRoute.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantTrustRoute'")[0]["LabelName"]);
                            grantDetails.lblAddGrantTrustRoute.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantTrustRoute'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantUploadDoc.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantUploadDoc'")[0]["LabelName"]);
                            grantDetails.lblAddGrantUploadDoc.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantUploadDoc'")[0]["LabelToolTip"]);

                            grantDetails.btnAddGrantAddMoreGrants.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantAddMoreGrants'")[0]["LabelName"]);
                            grantDetails.btnAddGrantAddMoreGrants.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantAddMoreGrants'")[0]["LabelToolTip"]);

                            grantDetails.btnAddGrantSaveContinue.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantSaveContinue'")[0]["LabelName"]);
                            grantDetails.btnAddGrantSaveContinue.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantSaveContinue'")[0]["LabelToolTip"]);

                            grantDetails.btnBackToValParams.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnBackToValParams'")[0]["LabelName"]);
                            grantDetails.btnBackToValParams.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnBackToValParams'")[0]["LabelToolTip"]);

                            grantDetails.btnAddGrantCancel.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantCancel'")[0]["LabelName"]);
                            grantDetails.btnAddGrantCancel.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantCancel'")[0]["LabelToolTip"]);

                            grantDetails.hdnbtnAddGrantPopulateVestDetails.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantPopulateVestDetails'")[0]["LabelName"]);
                            grantDetails.hdnbtnAddGrantPopulateVestDetails.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantPopulateVestDetails'")[0]["LabelToolTip"]);

                            grantDetails.lblAddGrantCommentBox.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblAddGrantCommentBox'")[0]["LabelName"]);
                            grantDetails.lblddlAddGrantSchemeName.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblddlAddGrantSchemeName'")[0]["ErrorText"]);

                            grantDetails.btnGDReset.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnGDReset'")[0]["LabelName"]);
                            grantDetails.btnGDReset.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnGDReset'")[0]["LabelToolTip"]);


                            grantDetails.btnAddGrantFileUpload.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantFileUpload'")[0]["LabelName"]);
                            grantDetails.btnAddGrantFileUpload.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnAddGrantFileUpload'")[0]["LabelToolTip"]);

                            //Update GeneralParams Tab
                            grantDetails.UCUpdateGeneralParams.lblMarketPrice.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblMarketPrice'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.lblMarketPrice.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblMarketPrice'")[0]["LabelToolTip"]);

                            grantDetails.UCUpdateGeneralParams.lblDividend.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblDividend'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.lblDividend.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblDividend'")[0]["LabelToolTip"]);

                            grantDetails.UCUpdateGeneralParams.lblRFIR.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblRFIR'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.lblRFIR.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblRFIR'")[0]["LabelToolTip"]);

                            grantDetails.UCUpdateGeneralParams.lblPeerCompany.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblPeerCompany'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.lblPeerCompany.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblPeerCompany'")[0]["LabelToolTip"]);

                            grantDetails.UCUpdateGeneralParams.lblCorpAction.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblCorpAction'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.lblCorpAction.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblCorpAction'")[0]["LabelToolTip"]);

                            grantDetails.UCUpdateGeneralParams.lnkMarketPrice.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lnkMarketPrice'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.lnkMarketPrice.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lnkMarketPrice'")[0]["LabelToolTip"]);

                            grantDetails.UCUpdateGeneralParams.lnkDividend.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lnkDividend'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.lnkDividend.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lnkDividend'")[0]["LabelToolTip"]);

                            grantDetails.UCUpdateGeneralParams.lnkRFIR.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lnkRFIR'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.lnkRFIR.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lnkRFIR'")[0]["LabelToolTip"]);

                            grantDetails.UCUpdateGeneralParams.lnkPeerCompany.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lnkPeerCompany'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.lnkPeerCompany.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lnkPeerCompany'")[0]["LabelToolTip"]);

                            grantDetails.UCUpdateGeneralParams.lnkCorpAction.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lnkCorpAction'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.lnkCorpAction.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lnkCorpAction'")[0]["LabelToolTip"]);

                            grantDetails.UCUpdateGeneralParams.btnViewValuationReport.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnViewValuationReport'")[0]["LabelName"]);
                            grantDetails.UCUpdateGeneralParams.btnViewValuationReport.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'btnViewValuationReport'")[0]["LabelToolTip"]);

                            grantDetails.gvSearch.lblViewDoc.Text = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'lblViewDoc'")[0]["LabelName"]);
                            #endregion

                            #region Validation Messages On the Page
                            grantDetails.reqFldAddGrantGrantID.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldAddGrantGrantID'")[0]["ErrorText"]);
                            grantDetails.reqFldAddGrantGrantDate.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldAddGrantGrantDate'")[0]["ErrorText"]);
                            grantDetails.regExpAddGrantGrantDate.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'regExpAddGrantGrantDate'")[0]["ErrorText"]);
                            grantDetails.regExpAddGrantExercisePrice.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'regExpAddGrantExercisePrice'")[0]["ErrorText"]);
                            grantDetails.reqFldAddGrantExercisePrice.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldAddGrantExercisePrice'")[0]["ErrorText"]);
                            grantDetails.reqFldAddGrantPricingFormula.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldAddGrantPricingFormula'")[0]["ErrorText"]);
                            grantDetails.regExpNumberOfVest.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'regExpNumberOfVest'")[0]["ErrorText"]);
                            grantDetails.reqFldNumberOfVest.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldNumberOfVest'")[0]["ErrorText"]);
                            grantDetails.regExpVestingFrequencyValue.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'regExpVestingFrequencyValue'")[0]["ErrorText"]);
                            grantDetails.reqFldVestingFrequencyValue.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldVestingFrequencyValue'")[0]["ErrorText"]);
                            grantDetails.regExpExercisePeriod.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'regExpExercisePeriod'")[0]["ErrorText"]);
                            grantDetails.reqFldExercisePeriod.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldExercisePeriod'")[0]["ErrorText"]);
                            grantDetails.regExpExPrcFirst.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'regExpExPrcFirst'")[0]["ErrorText"]);
                            grantDetails.reqFldExPrcFirst.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldExPrcFirst'")[0]["ErrorText"]);
                            grantDetails.regExpExPrcSecond.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'regExpExPrcFirst'")[0]["ErrorText"]);
                            grantDetails.reqFldExPrcSecond.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldExPrcFirst'")[0]["ErrorText"]);
                            grantDetails.reqFldRatioOpt.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldRatioOpt'")[0]["ErrorText"]);
                            grantDetails.regExpRatioOpt.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'regExpRatioOpt'")[0]["ErrorText"]);
                            grantDetails.reqFldRatioShares.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'reqFldRatioShares'")[0]["ErrorText"]);
                            grantDetails.regExpRatioShares.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'regExpRatioShares'")[0]["ErrorText"]);
                            grantDetails.gvSearch.regxcalGDFromDate.ToolTip = grantDetails.gvSearch.regxcalGDToDate.ToolTip = Convert.ToString(dt_GrantDetailUI.Select("LabelID = 'regx_gvVestExercisePopulate'")[0]["ErrorText"]);
                            #endregion
                        }
                    }
                    using (DataTable dt_ValuationReportUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if ((dt_ValuationReportUI != null) && (dt_ValuationReportUI.Rows.Count > 0))
                        {
                            ac_GrantDetails.dt_Valuation_Report_UI_Text = dt_ValuationReportUI;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Get Grant Details
        /// <summary>
        /// This Method is used to get Grant Details
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void GetGrantDetails(GrantDetails grantDetails)
        {
            try
            {
                using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                {
                    using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                    {
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.PageName = CommonConstantModel.s_GrantDetails;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                        valuationProperties.PAGE_INDEX = _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex.Equals(0) ? 1 : _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex;
                        valuationProperties.PAGE_SIZE = _gvUserControlModel.ac_SearchGrantDetails.n_PageSize.Equals(0) ? 10 : _gvUserControlModel.ac_SearchGrantDetails.n_PageSize;
                        valuationProperties.PAGE_INDEX_LOCKED = _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex_Locked.Equals(0) ? 1 : _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex_Locked;
                        valuationProperties.PAGE_SIZE_LOCKED = _gvUserControlModel.ac_SearchGrantDetails.n_PageSize_Locked.Equals(0) ? 10 : _gvUserControlModel.ac_SearchGrantDetails.n_PageSize_Locked;
                        valuationProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;
                        valuationProperties.SEN_IsMYESOPsClient = userSessionInfo.ACC_IsMYESOPsClient;
                        valuationProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.SEN_CompanyTitle = userSessionInfo.ACC_CompanyTitle;
                        valuationProperties.GET_DATA_TYPE = "GRANTWISE";

                        valuationProperties.PopulateControls = "GET_GRANT_DETAILS";
                        valuationProperties.Operation_Param = CommonConstantModel.s_GrantDetails;
                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                        valuationCRUDProperties.ds_Result.Tables[0].TableName = "DT";

                        ac_GrantDetails.dt_GetGrantDetails = (DataTable)valuationCRUDProperties.ds_Result.Tables[0];

                        if ((ac_GrantDetails.dt_GetGrantDetails != null) && (ac_GrantDetails.dt_GetGrantDetails.Rows.Count > 0))
                        {
                            valuationProperties.PopulateControls = "GETVESTINGDETAILS";
                            valuationProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;
                            valuationProperties.Grant_Date = string.Empty;

                            valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                            // Get Scheme Name
                            using (DataTable dt_SchemeName = ac_GrantDetails.dt_GetGrantDetails.DefaultView.ToTable(true, "Scheme Title"))
                            {
                                if ((dt_SchemeName != null) && (dt_SchemeName.Rows.Count > 0))
                                {
                                    grantDetails.ddlAddGrantSchemeName.DataSource = dt_SchemeName;
                                    grantDetails.ddlAddGrantSchemeName.DataTextField = "Scheme Title";
                                    grantDetails.ddlAddGrantSchemeName.DataValueField = "Scheme Title";
                                    grantDetails.ddlAddGrantSchemeName.DataBind();
                                    grantDetails.ddlAddGrantSchemeName.Items.Insert(0, "--- Please Select ---");
                                    grantDetails.ddlAddGrantSchemeName.Items.Insert(1, "--- Enter New Scheme ---");
                                }
                            }
                        }
                        else
                        {
                            grantDetails.ddlAddGrantSchemeName.Items.Clear();
                            grantDetails.ddlAddGrantSchemeName.Items.Insert(0, "--- Please Select ---");
                            grantDetails.ddlAddGrantSchemeName.Items.Insert(1, "--- Enter New Scheme ---");
                            ac_GrantDetails.dt_temp_Unlocked_Valuation_Report = null;
                            ac_GrantDetails.dt_temp_Locked_Valuation_Report = null;
                            ac_GrantDetails.dt_GetGrantDetails = null;
                        }

                        // Add Currency
                        valuationProperties.PopulateControls = "FILLCURRENCYDETAILS";
                        valuationProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;
                        valuationProperties.Grant_Date = string.Empty;

                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        if ((valuationCRUDProperties.dt_Result != null) && (valuationCRUDProperties.dt_Result.Rows.Count > 0))
                        {
                            grantDetails.ddlAddGrantCurrency.DataSource = valuationCRUDProperties.dt_Result;
                            grantDetails.ddlAddGrantCurrency.DataTextField = "CURRENCY_NAME";
                            grantDetails.ddlAddGrantCurrency.DataValueField = "CRMID";
                            grantDetails.ddlAddGrantCurrency.DataBind();
                        }

                        // Get Listing date
                        valuationProperties.PopulateControls = "GetListingDate";
                        valuationProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;
                        valuationProperties.Grant_Date = string.Empty;

                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        if ((valuationCRUDProperties.dt_Result != null) && (valuationCRUDProperties.dt_Result.Rows.Count > 0))
                        {
                            ac_GrantDetails.dat_ListingDate = Convert.ToDateTime(Convert.ToString(valuationCRUDProperties.dt_Result.Rows[0]["ESTIMATED_DATE_OF_LISTING"]));
                        }

                        if (grantDetails.ddlAddGrantVestingParams.Items.Count.Equals(0))
                        {
                            grantDetails.ddlAddGrantVestingParams.Items.Insert(0, "Time Based");
                            //grantDetails.ddlAddGrantVestingParams.Items.Insert(1, "Performance Based");
                            //grantDetails.ddlAddGrantVestingParams.Items.Insert(2, "Both");
                        }
                        grantDetails.btnGDReset.Visible = false;
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Implementation of Role Rights

        /// <summary>
        /// This Method is used to Implements Role Rights on the Page.
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void CheckEmployeeRolePriviledges(GrantDetails grantDetails)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuGrantDetails;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePreviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePreviledges != null && dt_RolePreviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePreviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    grantDetails.gvSearch.btnGDSearch.Enabled = true;
                                    grantDetails.gvSearch.btnGDAddGrant.Enabled = false;
                                    grantDetails.gvSearch.btnGDDelete.Enabled = false;
                                    grantDetails.btnAddGrantAddMoreGrants.Enabled = false;
                                    grantDetails.btnAddGrantPopulateVestDetails.Enabled = false;
                                    grantDetails.btnAddGrantSaveContinue.Enabled = false;
                                    grantDetails.UCUpdateGeneralParams.lnkMarketPrice.Enabled = false;
                                    grantDetails.UCUpdateGeneralParams.lnkCorpAction.Enabled = false;
                                    grantDetails.UCUpdateGeneralParams.lnkDividend.Enabled = false;
                                    grantDetails.UCUpdateGeneralParams.lnkPeerCompany.Enabled = false;
                                    grantDetails.UCUpdateGeneralParams.lnkRFIR.Enabled = false;
                                    grantDetails.UCUpdateGeneralParams.btnViewValuationReport.Enabled = false;
                                    break;

                                case "ADD":
                                    grantDetails.gvSearch.btnGDSearch.Enabled = true;
                                    grantDetails.gvSearch.btnGDAddGrant.Enabled = true;
                                    grantDetails.gvSearch.btnGDDelete.Enabled = false;
                                    grantDetails.btnAddGrantAddMoreGrants.Enabled = true;
                                    grantDetails.btnAddGrantPopulateVestDetails.Enabled = true;
                                    grantDetails.btnAddGrantSaveContinue.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkMarketPrice.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkCorpAction.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkDividend.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkPeerCompany.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkRFIR.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.btnViewValuationReport.Enabled = true;
                                    break;

                                case "EDIT":
                                    grantDetails.gvSearch.btnGDSearch.Enabled = true;
                                    grantDetails.gvSearch.btnGDAddGrant.Enabled = (from b in dt_RolePreviledges.AsEnumerable()
                                                                                   where b.Field<string>("PRIVILEDGES") == "ADD"
                                                                                   select b.Field<string>("PRIVILEDGES")).Distinct().Count() > 0 ? true : false;
                                    grantDetails.gvSearch.btnGDDelete.Enabled = false;
                                    grantDetails.btnAddGrantAddMoreGrants.Enabled = true;
                                    grantDetails.btnAddGrantPopulateVestDetails.Enabled = true;
                                    grantDetails.btnAddGrantSaveContinue.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkMarketPrice.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkCorpAction.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkDividend.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkPeerCompany.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkRFIR.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.btnViewValuationReport.Enabled = true;
                                    break;

                                case "DELETE":
                                    grantDetails.gvSearch.btnGDSearch.Enabled = true;
                                    grantDetails.gvSearch.btnGDAddGrant.Enabled = (from b in dt_RolePreviledges.AsEnumerable()
                                                                                   where b.Field<string>("PRIVILEDGES") == "ADD"
                                                                                   select b.Field<string>("PRIVILEDGES")).Distinct().Count() > 0 ? true : false;
                                    grantDetails.gvSearch.btnGDDelete.Enabled = true;
                                    grantDetails.btnAddGrantAddMoreGrants.Enabled = true;
                                    grantDetails.btnAddGrantPopulateVestDetails.Enabled = true;
                                    grantDetails.btnAddGrantSaveContinue.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkMarketPrice.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkCorpAction.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkDividend.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkPeerCompany.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.lnkRFIR.Enabled = true;
                                    grantDetails.UCUpdateGeneralParams.btnViewValuationReport.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region SetFields in Session and redirection from Grant details to other pages and vice-versa
        /// <summary>
        /// This method is used to Set Accordian Index, Tab Index After Redirecting from Other pages to Grant Details Page.
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void SetFields(GrantDetails grantDetails)
        {
            grantDetails.btnAddGrantSaveContinue.Enabled = false;

            grantDetails.hdnAccordionIndex.Value = "1";
            grantDetails.hdnTabActiveIndex.Value = "1";
            grantDetails.hdnhideTabs.Value = "2";

            grantDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

            grantDetails.h4ViewAddEditGV.Style.Add("display", "normal");
        }
        #endregion

        #region ddlAddGrantSchemeName DropDown Index Change Event
        /// <summary>
        /// This is ddlAddGrantSchemeName Dropdown Index Change Event
        /// </summary>
        /// <param name="grantDetails"></param>
        internal void ddlAddGrantSchemeName_SelectedIndexChanged(GrantDetails grantDetails)
        {
            try
            {
                grantDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                if (grantDetails.ddlAddGrantSchemeName.SelectedItem.Text.Equals("--- Enter New Scheme ---"))
                {
                    grantDetails.popup.Style.Add("display", "block");
                    grantDetails.hdntxtSchemeVal.Value = "hdn";
                    foreach (BaseValidator val in grantDetails.Page.Validators)
                    {
                        if (val.ValidationGroup == "PopulateTxt")
                        {
                            val.Enabled = true;
                            val.CssClass = "EDValidator";
                        }
                    }
                    grantDetails.reqFldEnterSchemeName.Enabled = true;
                    grantDetails.txtEnterSchemeName.Text = string.Empty;
                    grantDetails.txtEnterSchemeName.Visible = true;
                }

                else if (grantDetails.ddlAddGrantSchemeName.SelectedItem.Text.Equals("--- Please Select ---"))
                {
                    grantDetails.gvVestExercisePopulate.Visible = false;
                    grantDetails.btnAddGrantAddMoreGrants.Visible = false;
                    grantDetails.btnAddGrantSaveContinue.Visible = false;
                    grantDetails.txtEnterSchemeName.Visible = false;
                }

                else
                {
                    grantDetails.popup.Style.Add("display", "none");
                    grantDetails.reqFldEnterSchemeName.Enabled = false;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Populate Vest Grid
        /// <summary>
        /// This Method is used to Calulation Part of Populating Vesting Schedule
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void PopulateVestdetails(GrantDetails grantDetails)
        {
            try
            {
                int n_NoVest, n_Real_NoVest = n_NoVest = Convert.ToInt32(grantDetails.txtAddGrantNumberOfVest.Text), n_VestID = 1, n_VestFreqvalue = Convert.ToInt32(grantDetails.txtAddGrantVestingFrequency.Text), n_ExerPeriodValue = grantDetails.chkAddGrantExPrcLnkMultDates.Checked ? 0 : Convert.ToInt32(grantDetails.txtAddGrantExercisePeriod.Text), n_ExerEndValueOne, n_ExerEndValueTwo;
                bool fg_OddVest = false;
                decimal n_VestPercent, n_NoOfVest = Convert.ToDecimal(grantDetails.txtAddGrantNumberOfVest.Text), n_SumVestPercent = 0;
                string s_GrantDate = grantDetails.txtAddGrantGrantDate.Text, s_TempGrantDate = s_GrantDate, s_Zero = "01/01/1000 00:00:00 AM";
                DateTime Date = DateTime.Parse(s_GrantDate), dat_VestDate = new DateTime(), dat_TempVestDate = new DateTime(), dat_ExerDate = new DateTime(), dat_ExerDateOne = new DateTime(), dat_ExerDateTwo = new DateTime();
                n_VestPercent = Convert.ToDecimal(100) / n_NoOfVest;
                fg_OddVest = 100 % n_NoOfVest == 0 ? false : true;

                ac_GrantDetails.dat_VestDate = Convert.ToDateTime("1/1/0001 12:00:00 AM");
                ac_GrantDetails.dt_TempVestDetails = new DataTable();

                if (ac_GrantDetails.dt_TempVestDetails.Rows.Count.Equals(0) && ac_GrantDetails.dt_TempVestDetails.Columns.Count.Equals(0))
                {
                    ac_GrantDetails.dt_TempVestDetails.Columns.Add("Vesting Period ID", typeof(string));
                    ac_GrantDetails.dt_TempVestDetails.Columns.Add("Vesting Date", typeof(string));
                    ac_GrantDetails.dt_TempVestDetails.Columns.Add("Vest Percent", typeof(decimal));
                    ac_GrantDetails.dt_TempVestDetails.Columns.Add("Expiry Date", typeof(string));
                    ac_GrantDetails.dt_TempVestDetails.Columns.Add("Time Based Vest Percent", typeof(decimal));
                    ac_GrantDetails.dt_TempVestDetails.Columns.Add("Performance Based Vest Percent", typeof(decimal));
                }

                ac_GrantDetails.dt_TempVestDetails.Clear();
                dat_VestDate = grantDetails.chkFirstVestAftrOneYr.Checked ? dat_VestDate = dat_TempVestDate = Convert.ToDateTime(Date.AddYears(1)) : Convert.ToDateTime(s_GrantDate);
                Int16 tabIndex = 1;
                while (n_NoVest > 0)
                {
                    if (!(dat_VestDate.Equals(dat_TempVestDate)))
                    {
                        dat_VestDate = grantDetails.rdbtnVestingFreqYearly.SelectedValue == "Y" ? Convert.ToDateTime(dat_VestDate.AddYears(n_VestFreqvalue)) : grantDetails.rdbtnVestingFreqYearly.SelectedValue == "M" ? Convert.ToDateTime(dat_VestDate.AddMonths(n_VestFreqvalue)) : grantDetails.rdbtnVestingFreqYearly.SelectedValue == "Q" ? Convert.ToDateTime(dat_VestDate.AddMonths(3 * n_VestFreqvalue)) : Convert.ToDateTime(dat_VestDate.AddDays(n_VestFreqvalue));
                        ac_GrantDetails.dat_VestDate = ac_GrantDetails.dat_VestDate == Convert.ToDateTime("1/1/0001 12:00:00 AM") ? dat_VestDate : ac_GrantDetails.dat_VestDate;
                    }


                    if (grantDetails.chkAddGrantExPrcLnkMultDates.Checked)
                    {
                        n_ExerEndValueOne = Convert.ToInt32(grantDetails.txtAddGrantExPrcFirst.Text); n_ExerEndValueTwo = Convert.ToInt32(grantDetails.txtAddGrantExPrcSecond.Text);
                        dat_ExerDateOne = grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedValue == "Y" && grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedValue == "G" ? Convert.ToDateTime(s_TempGrantDate).AddYears(n_ExerEndValueOne) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedValue == "M" && grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedValue == "G" ? Convert.ToDateTime(s_TempGrantDate).AddMonths(n_ExerEndValueOne) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedValue == "D" && grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedValue == "G" ? Convert.ToDateTime(s_TempGrantDate).AddDays(n_ExerEndValueOne) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedValue == "Y" && grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedValue == "V" ? Convert.ToDateTime(ac_GrantDetails.dat_VestDate.AddYears(n_ExerEndValueOne)) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedValue == "M" && grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedValue == "V" ? Convert.ToDateTime(ac_GrantDetails.dat_VestDate.AddMonths(n_ExerEndValueOne)) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedValue == "D" && grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedValue == "V" ? Convert.ToDateTime(ac_GrantDetails.dat_VestDate.AddDays(n_ExerEndValueOne)) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedValue == "Y" && grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedValue == "L" ? Convert.ToDateTime(ac_GrantDetails.dat_ListingDate.AddYears(n_ExerEndValueOne)) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedValue == "M" && grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedValue == "L" ? Convert.ToDateTime(ac_GrantDetails.dat_ListingDate.AddMonths(n_ExerEndValueOne)) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedValue == "D" && grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedValue == "L" ? Convert.ToDateTime(ac_GrantDetails.dat_ListingDate.AddDays(n_ExerEndValueOne)) :
                                          Convert.ToDateTime(s_Zero);

                        dat_ExerDateTwo = grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedValue == "Y" && grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedValue == "G" ? Convert.ToDateTime(s_TempGrantDate).AddYears(n_ExerEndValueTwo) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedValue == "M" && grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedValue == "G" ? Convert.ToDateTime(s_TempGrantDate).AddMonths(n_ExerEndValueTwo) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedValue == "D" && grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedValue == "G" ? Convert.ToDateTime(s_TempGrantDate).AddDays(n_ExerEndValueTwo) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedValue == "Y" && grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedValue == "V" ? Convert.ToDateTime(ac_GrantDetails.dat_VestDate.AddYears(n_ExerEndValueTwo)) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedValue == "M" && grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedValue == "V" ? Convert.ToDateTime(ac_GrantDetails.dat_VestDate.AddMonths(n_ExerEndValueTwo)) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedValue == "D" && grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedValue == "V" ? Convert.ToDateTime(ac_GrantDetails.dat_VestDate.AddDays(n_ExerEndValueTwo)) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedValue == "Y" && grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedValue == "L" ? Convert.ToDateTime(ac_GrantDetails.dat_ListingDate.AddYears(n_ExerEndValueTwo)) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedValue == "M" && grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedValue == "L" ? Convert.ToDateTime(ac_GrantDetails.dat_ListingDate.AddMonths(n_ExerEndValueTwo)) :
                                          grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedValue == "D" && grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedValue == "L" ? Convert.ToDateTime(ac_GrantDetails.dat_ListingDate.AddDays(n_ExerEndValueTwo)) :
                                          Convert.ToDateTime(s_Zero);

                        dat_ExerDate = dat_ExerDateOne > dat_ExerDateTwo && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? dat_ExerDateTwo :
                                       dat_ExerDateOne > dat_ExerDateTwo && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? dat_ExerDateOne :
                                       dat_ExerDateTwo > dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? dat_ExerDateOne :
                                       dat_ExerDateTwo > dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? dat_ExerDateTwo :
                                       dat_ExerDateTwo == dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? dat_ExerDateOne :
                                       dat_ExerDateTwo == dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? dat_ExerDateOne :
                                       Convert.ToDateTime(s_Zero);

                        ac_GrantDetails.n_Mult_Exer_Period_Value = dat_ExerDateOne > dat_ExerDateTwo && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? Convert.ToInt32(grantDetails.txtAddGrantExPrcSecond.Text) :
                                                                dat_ExerDateOne > dat_ExerDateTwo && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? Convert.ToInt32(grantDetails.txtAddGrantExPrcFirst.Text) :
                                                                dat_ExerDateTwo > dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? Convert.ToInt32(grantDetails.txtAddGrantExPrcFirst.Text) :
                                                                dat_ExerDateTwo > dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? Convert.ToInt32(grantDetails.txtAddGrantExPrcSecond.Text) :
                                                                dat_ExerDateTwo == dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? Convert.ToInt32(grantDetails.txtAddGrantExPrcFirst.Text) :
                                                                dat_ExerDateTwo == dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? Convert.ToInt32(grantDetails.txtAddGrantExPrcFirst.Text) :
                                                                ac_GrantDetails.n_Mult_Exer_Period_Value;

                        ac_GrantDetails.n_Mult_Exer_Period_Freq = dat_ExerDateOne > dat_ExerDateTwo && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedItem.Value :
                                                                dat_ExerDateOne > dat_ExerDateTwo && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedItem.Value :
                                                                dat_ExerDateTwo > dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedItem.Value :
                                                                dat_ExerDateTwo > dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedItem.Value :
                                                                dat_ExerDateTwo == dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedItem.Value :
                                                                dat_ExerDateTwo == dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedItem.Value :
                                                                ac_GrantDetails.n_Mult_Exer_Period_Freq;

                        ac_GrantDetails.n_Mult_Exer_Period_Freq_From = dat_ExerDateOne > dat_ExerDateTwo && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedItem.Value :
                                                                  dat_ExerDateOne > dat_ExerDateTwo && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedItem.Value :
                                                                  dat_ExerDateTwo > dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedItem.Value :
                                                                  dat_ExerDateTwo > dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedItem.Value :
                                                                  dat_ExerDateTwo == dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "E" ? grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedItem.Value :
                                                                  dat_ExerDateTwo == dat_ExerDateOne && grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedValue == "L" ? grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedItem.Value :
                                                                  ac_GrantDetails.n_Mult_Exer_Period_Freq_From;
                    }

                    else
                    {
                        dat_ExerDate = grantDetails.rdbtnExerPeriodYears.SelectedValue == "Y" && grantDetails.rdbtnExerPeriodFromDOG.SelectedValue == "G" ? Convert.ToDateTime(s_TempGrantDate).AddYears(n_ExerPeriodValue) :
                                        grantDetails.rdbtnExerPeriodYears.SelectedValue == "Y" && grantDetails.rdbtnExerPeriodFromDOG.SelectedValue == "V" ? dat_VestDate.AddYears(n_ExerPeriodValue) :
                                        grantDetails.rdbtnExerPeriodYears.SelectedValue == "Y" && grantDetails.rdbtnExerPeriodFromDOG.SelectedValue == "L" ? ac_GrantDetails.dat_ListingDate.AddYears(n_ExerPeriodValue) :
                                        grantDetails.rdbtnExerPeriodYears.SelectedValue == "M" && grantDetails.rdbtnExerPeriodFromDOG.SelectedValue == "G" ? Convert.ToDateTime(s_TempGrantDate).AddMonths(n_ExerPeriodValue) :
                                        grantDetails.rdbtnExerPeriodYears.SelectedValue == "M" && grantDetails.rdbtnExerPeriodFromDOG.SelectedValue == "V" ? dat_VestDate.AddMonths(n_ExerPeriodValue) :
                                        grantDetails.rdbtnExerPeriodYears.SelectedValue == "M" && grantDetails.rdbtnExerPeriodFromDOG.SelectedValue == "L" ? ac_GrantDetails.dat_ListingDate.AddMonths(n_ExerPeriodValue) :
                                        grantDetails.rdbtnExerPeriodYears.SelectedValue == "D" && grantDetails.rdbtnExerPeriodFromDOG.SelectedValue == "G" ? Convert.ToDateTime(s_TempGrantDate).AddDays(n_ExerPeriodValue) :
                                        grantDetails.rdbtnExerPeriodYears.SelectedValue == "D" && grantDetails.rdbtnExerPeriodFromDOG.SelectedValue == "G" ? Convert.ToDateTime(s_TempGrantDate).AddDays(n_ExerPeriodValue) :
                                        grantDetails.rdbtnExerPeriodYears.SelectedValue == "D" && grantDetails.rdbtnExerPeriodFromDOG.SelectedValue == "V" ? dat_VestDate.AddDays(n_ExerPeriodValue) :
                                        grantDetails.rdbtnExerPeriodYears.SelectedValue == "D" && grantDetails.rdbtnExerPeriodFromDOG.SelectedValue == "L" ? ac_GrantDetails.dat_ListingDate.AddDays(n_ExerPeriodValue) :
                                        Convert.ToDateTime(s_Zero);
                    }
                    n_VestPercent = fg_OddVest == true && n_NoVest == 1 ? 100 - n_SumVestPercent : n_VestPercent;
                    n_SumVestPercent = n_SumVestPercent + Math.Round(n_VestPercent, 2);

                    if (grantDetails.ddlAddGrantVestingParams.SelectedValue.Equals("Both"))
                    {
                        decimal d_TimeBased, d_PerfBased;
                        d_TimeBased = d_PerfBased = n_VestPercent / Convert.ToDecimal(2);
                        ac_GrantDetails.dt_TempVestDetails.Rows.Add(n_VestID, dat_VestDate.ToString("dd/MMM/yyyy"), Math.Round(n_VestPercent), dat_ExerDate.ToString("dd/MMM/yyyy"), Math.Round(d_TimeBased), Math.Round(d_PerfBased));
                    }

                    else
                        ac_GrantDetails.dt_TempVestDetails.Rows.Add(n_VestID, dat_VestDate.ToString("dd/MMM/yyyy"), Math.Round(n_VestPercent, 2), dat_ExerDate.ToString("dd/MMM/yyyy"), 0.00, 0.00);

                    n_NoVest = n_NoVest - 1; n_VestID++;
                    s_GrantDate = Convert.ToString(dat_VestDate);
                    dat_TempVestDate = Convert.ToDateTime("01/01/1000 00:00:00 AM");
                }

                ac_GrantDetails.n_VestTotalPercent = n_SumVestPercent;

                CheckPopulatedGrid(grantDetails);

                grantDetails.divVestExercisePopulate.Visible = true;
                grantDetails.gvVestExercisePopulate.Visible = true;

                grantDetails.gvVestExercisePopulate.DataSource = ac_GrantDetails.dt_TempVestDetails;
                grantDetails.gvVestExercisePopulate.DataBind();

                foreach (GridViewRow perRow in grantDetails.gvVestExercisePopulate.Rows)
                {
                    TextBox ht_InputVestDate = (TextBox)perRow.FindControl("calGDVestDate");
                    ht_InputVestDate.TabIndex = tabIndex;
                    tabIndex++;
                    TextBox txt_InputVestPercent = (TextBox)perRow.FindControl("txtVestPercent");
                    txt_InputVestPercent.TabIndex = tabIndex;
                    tabIndex++;
                    TextBox ht_ExerEndDate = (TextBox)perRow.FindControl("calGDExerEndDate");
                    ht_ExerEndDate.TabIndex = tabIndex;
                    tabIndex++;
                }

                grantDetails.rdbtnEquitySettled.Focus();
                grantDetails.trSaveContinue.Style.Add("display", "normal");
                grantDetails.btnAddGrantAddMoreGrants.Visible = grantDetails.hdnAction.Value.Equals("U") ? false : true;
                grantDetails.trgvVestExercisePopulate.Style.Add("display", "normal");
                grantDetails.trUpdateParamsOrFair.Style.Add("display", "normal");
                grantDetails.h4ViewAddEditGV.Style.Add("display", "normal");
                grantDetails.btnAddGrantAddMoreGrants.Visible = grantDetails.hdnAction.Value.Equals("U") ? false : true;
                grantDetails.btnAddGrantSaveContinue.Visible = true;
                grantDetails.btnAddGrantAddMoreGrants.Enabled = true;
                grantDetails.btnAddGrantSaveContinue.Enabled = true;

                ac_GrantDetails.n_Real_NoVest = Convert.ToInt32(n_NoOfVest);
                grantDetails.gvUpdateFairParams.Visible = false;
                grantDetails.rdbtnUpdateParams.SelectedIndex = 0;

                if (grantDetails.chkAddGrantExPrcLnkMultDates.Checked)
                {
                    grantDetails.divVestExercisePopulateOne.Style.Add("display", "none");
                    grantDetails.trExPrcLnkMultDatesFirst.Style.Add("display", "normal");
                }

                else
                {
                    grantDetails.divVestExercisePopulateOne.Style.Add("display", "normal");
                    grantDetails.trExPrcLnkMultDatesFirst.Style.Add("display", "none");
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is Bind Vesting Schedule Grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <param name="grantDetails"></param>
        internal void gvVestExercisePopulateRowDataBound(object sender, GridViewRowEventArgs e, GrantDetails grantDetails)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.Header)
                {
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "VEST PERCENT":
                                perColumn.Visible = !grantDetails.ddlAddGrantVestingParams.SelectedValue.Equals("Both") ? true : false;
                                break;
                            case "TIME BASED VEST PERCENT":
                                perColumn.Visible = grantDetails.ddlAddGrantVestingParams.SelectedValue.Equals("Both") ? true : false;
                                break;

                            case "PERFORMANCE BASED VEST PERCENT":
                                perColumn.Visible = grantDetails.ddlAddGrantVestingParams.SelectedValue.Equals("Both") ? true : false;
                                break;
                        }
                    }
                }

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    e.Row.Cells[2].Visible = !grantDetails.ddlAddGrantVestingParams.SelectedValue.Equals("Both") ? true : false;
                    e.Row.Cells[3].Visible = e.Row.Cells[4].Visible = grantDetails.ddlAddGrantVestingParams.SelectedValue.Equals("Both") ? true : false;
                    e.Row.Cells[0].HorizontalAlign = e.Row.Cells[1].HorizontalAlign = e.Row.Cells[3].HorizontalAlign = e.Row.Cells[2].HorizontalAlign = e.Row.Cells[4].HorizontalAlign = e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Center;

                    for (int n_ColCnt = 1; n_ColCnt < grantDetails.gvVestExercisePopulate.Columns.Count; n_ColCnt++)
                    {
                        if (n_ColCnt != 2)
                            e.Row.Cells[n_ColCnt].Controls.Add(AddValidation(e.Row.RowIndex, n_ColCnt, grantDetails));
                    }
                }

                if (e.Row.RowType == DataControlRowType.Footer)
                {
                    TextBox txtVestTotal = (TextBox)e.Row.FindControl("txtVestTotal");
                    txtVestTotal.Text = Convert.ToString("100");
                    txtVestTotal.ForeColor = System.Drawing.Color.Green;
                    txtVestTotal.ToolTip = "The Total Vest % should be 100 % ";
                    e.Row.Cells[3].Visible = e.Row.Cells[4].Visible = grantDetails.ddlAddGrantVestingParams.SelectedValue.Equals("Both") ? true : false;
                    e.Row.Cells[5].Visible = !grantDetails.ddlAddGrantVestingParams.SelectedValue.Equals("Both") ? true : false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Add validation to  gvVestExercisePopulate Gridview
        /// </summary>
        /// <param name="n_RowIndex">Row Index</param>
        /// <param name="n_NoOfColumns">No Of Columns</param>
        /// <param name="grantDetails">grantDetails</param>
        /// <returns>regx_gvVestExercisePopulate</returns>
        private Control AddValidation(int n_RowIndex, int n_NoOfColumns, GrantDetails grantDetails)
        {
            try
            {
                using (RegularExpressionValidator regx_gvVestExercisePopulate = new RegularExpressionValidator())
                {
                    regx_gvVestExercisePopulate.CssClass = "EDValidator";
                    regx_gvVestExercisePopulate.ValidationGroup = "ValdiateDate";
                    regx_gvVestExercisePopulate.ID = "regx_" + n_RowIndex + "_" + n_NoOfColumns;
                    regx_gvVestExercisePopulate.ClientIDMode = ClientIDMode.Static;
                    regx_gvVestExercisePopulate.ToolTip = grantDetails.regExpAddGrantGrantDate.ToolTip;

                    switch (n_NoOfColumns)
                    {
                        case 1:
                            regx_gvVestExercisePopulate.ControlToValidate = "calGDVestDate";
                            break;
                        case 3:
                            regx_gvVestExercisePopulate.ControlToValidate = "txtTimeVestPercent";
                            break;
                        case 4:
                            regx_gvVestExercisePopulate.ControlToValidate = "txtPerfVestPercent";
                            break;
                        case 5:
                            regx_gvVestExercisePopulate.ControlToValidate = "calGDExerEndDate";
                            break;
                    }

                    regx_gvVestExercisePopulate.ValidationExpression = @"^((31(?! (FEB|APR|JUN|SEP|NOV)))|((30|29)(?! FEB))|(29(?= FEB (((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))))|(0?[1-9])|1\d|2[0-8])/(Jan|Feb|Mar|May|Apr|Jul|Jun|Aug|Oct|Sep|Nov|Dec)/((1[6-9]|[2-9]\d)\d{2})$";

                    return regx_gvVestExercisePopulate;
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Check Vesting Schedule
        /// <summary>
        /// This Method is used to Populate Vest Details
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void PopulateVestDetails(GrantDetails grantDetails)
        {

            if (ac_GrantDetails.dt_TempVestDetails == null)
            {
                ac_GrantDetails.dt_TempVestDetails = new DataTable();
                ac_GrantDetails.dt_TempVestDetails.Columns.Add("Vesting Period ID", typeof(string));
                ac_GrantDetails.dt_TempVestDetails.Columns.Add("Vesting Date", typeof(string));
                ac_GrantDetails.dt_TempVestDetails.Columns.Add("Vest Percent", typeof(string));
                ac_GrantDetails.dt_TempVestDetails.Columns.Add("Expiry Date", typeof(string));
                ac_GrantDetails.dt_TempVestDetails.Columns.Add("Time Based Vest Percent", typeof(string));
                ac_GrantDetails.dt_TempVestDetails.Columns.Add("Performance Based Vest Percent", typeof(string));
            }

            else
                ac_GrantDetails.dt_TempVestDetails.Clear();

            foreach (GridViewRow perRow in grantDetails.gvVestExercisePopulate.Rows)
            {
                Label lbl_VestID = (Label)perRow.FindControl("VestID");
                TextBox ht_InputVestDate = (TextBox)perRow.FindControl("calGDVestDate");
                TextBox txt_InputVestPercent = (TextBox)perRow.FindControl("txtVestPercent");
                TextBox ht_ExerEndDate = (TextBox)perRow.FindControl("calGDExerEndDate");
                TextBox txt_InputTimeVestPercent = (TextBox)perRow.FindControl("txtTimeVestPercent");
                TextBox txt_InputPerfVestPercent = (TextBox)perRow.FindControl("txtPerfVestPercent");
                string s_VestDate = ht_InputVestDate.Text, s_VestPercent = txt_InputVestPercent.Text, s_ExerEndDate = ht_ExerEndDate.Text;
                string s_InputTimeVestPercent = txt_InputPerfVestPercent.Text, s_InputPerfVestPercent = txt_InputPerfVestPercent.Text;
                ac_GrantDetails.dt_TempVestDetails.Rows.Add(lbl_VestID.Text.ToString(), s_VestDate, s_VestPercent, s_ExerEndDate, s_InputTimeVestPercent, s_InputPerfVestPercent);
            }

            BindgvVestExercise(grantDetails);
        }

        /// <summary>
        /// This Method is used to Final Check of Vesting Schedule Before Saving to Database
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void CheckPopulatedGrid(View.User.Valuation.GrantDetails grantDetails)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    StringBuilder sbErrorMessage = new StringBuilder();

                    foreach (DataRow perRow in ac_GrantDetails.dt_TempVestDetails.Rows)
                    {
                        if (Convert.ToDateTime(perRow["Vesting Date"].ToString()) > Convert.ToDateTime(perRow["Expiry Date"].ToString()))
                        {
                            grantDetails.lblValidateMsg.ForeColor = System.Drawing.Color.Red;
                            sbErrorMessage.Append(string.Format("The Vest date cannot be greater than exercise end date for Vesting Id {0} <br/>", Convert.ToString(perRow[0])));
                            ac_GrantDetails.s_Error = "Set";
                            grantDetails.divValidateMsg.Style.Add("display", "block");
                        }
                    }
                    grantDetails.lblValidateMsg.Text = string.IsNullOrEmpty(grantDetails.lblValidateMsg.Text) ? Convert.ToString(sbErrorMessage) : grantDetails.lblValidateMsg.Text;

                    grantDetails.lblValidateMsg.Text = Convert.ToString(sbErrorMessage);

                    DateTime dat_GrantDate = DateTime.Parse(grantDetails.txtAddGrantGrantDate.Text);

                    foreach (DataRow perRow in ac_GrantDetails.dt_TempVestDetails.Rows)
                    {
                        string s_VestDate = perRow["Vesting Date"].ToString();
                        string s_ExerEndDate = perRow["Expiry Date"].ToString();
                        DateTime dat_VestDate = DateTime.Parse(s_VestDate), dat_ExeDate = DateTime.Parse(s_ExerEndDate);

                        if (dat_GrantDate > dat_VestDate)
                        {
                            grantDetails.lblValidateMsg.ForeColor = System.Drawing.Color.Red;
                            grantDetails.lblValidateMsg.Text = valuationServiceClient.GetValuation_L10N("lblGDVDPriorGDError", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                            ac_GrantDetails.s_Error = "Set";
                        }

                        else if (dat_GrantDate > dat_ExeDate)
                        {
                            grantDetails.lblValidateMsg.ForeColor = System.Drawing.Color.Red;
                            grantDetails.lblValidateMsg.Text = valuationServiceClient.GetValuation_L10N("lblGDEDPriorGDError", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                            ac_GrantDetails.s_Error = "Set";
                        }
                    }
                    grantDetails.divValidateMsg.Visible = grantDetails.lblValidateMsg.Text == string.Empty ? false : true;

                    if (grantDetails.lblValidateMsg.Text != string.Empty && grantDetails.chkAddGrantExPrcLnkMultDates.Checked)
                        grantDetails.btnAddGrantPopulateVestDetails.Style.Add("display", "none");

                    if (grantDetails.lblValidateMsg.Text != string.Empty && !grantDetails.chkAddGrantExPrcLnkMultDates.Checked)
                        grantDetails.hdnbtnAddGrantPopulateVestDetails.Style.Add("display", "none");
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Save Vesting Schedule
        /// <summary>
        /// This Method is used to Save Vesting Schedule Grid
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void SaveVestExerciseGrid(GrantDetails grantDetails)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    bool flag = false; bool flagVestGreater = false;

                    for (int i = 0; i < ac_GrantDetails.dt_TempVestDetails.Rows.Count; i++)
                    {
                        TextBox ht_InputVestDate = (TextBox)grantDetails.gvVestExercisePopulate.Rows[i].FindControl("calGDVestDate");
                        TextBox txt_InputVestPercent = (TextBox)grantDetails.gvVestExercisePopulate.Rows[i].FindControl("txtVestPercent");
                        TextBox ht_ExerEndDate = (TextBox)grantDetails.gvVestExercisePopulate.Rows[i].FindControl("calGDExerEndDate");
                        string s_VestDate = ht_InputVestDate.Text, s_VestPercent = txt_InputVestPercent.Text, s_ExerEndDate = ht_ExerEndDate.Text;
                        grantDetails.divValidateMsg.Style.Add("display", "block");
                        grantDetails.lblValidateMsg.ForeColor = System.Drawing.Color.Red;

                        if (!string.IsNullOrEmpty(s_VestDate) && !string.IsNullOrEmpty(s_ExerEndDate) && !string.IsNullOrEmpty(s_VestPercent))
                        {
                            DateTime dat_GrantDate = DateTime.Parse(grantDetails.txtAddGrantGrantDate.Text), dat_VestDate = DateTime.Parse(s_VestDate), dat_ExeDate = DateTime.Parse(s_ExerEndDate);
                            DateTime dat_RowVestDate = Convert.ToDateTime(s_VestDate.ToString());
                            for (int n_Cnt = ac_GrantDetails.dt_TempVestDetails.Rows.Count; n_Cnt > 0; n_Cnt--)
                            {
                                string s_RowVestDate = ac_GrantDetails.dt_TempVestDetails.Rows[n_Cnt - 1]["Vesting Date"].ToString();

                                if ((n_Cnt - 1) > i)
                                {
                                    flag = dat_RowVestDate < Convert.ToDateTime(s_RowVestDate) ? false : true;
                                    flagVestGreater = dat_RowVestDate > Convert.ToDateTime(s_RowVestDate) ? true : false;
                                }

                                else if ((n_Cnt - 1) < i)
                                    flag = dat_RowVestDate >= Convert.ToDateTime(s_RowVestDate) ? false : true;
                            }
                            grantDetails.lblValidateMsg.Text = flag == true && flagVestGreater == false ? valuationServiceClient.GetValuation_L10N("lblGDVDPriorVDError", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10) : flagVestGreater == true ? valuationServiceClient.GetValuation_L10N("lblGDVDLaterVDError", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10) : "";
                            ac_GrantDetails.s_Error = string.IsNullOrEmpty(grantDetails.lblValidateMsg.Text) ? "" : "Set";

                            if (flag == false && dat_RowVestDate < dat_ExeDate && dat_GrantDate < dat_RowVestDate && flagVestGreater == false || dat_RowVestDate == dat_ExeDate)
                            {
                                ac_GrantDetails.dt_TempVestDetails.Rows[i]["Vesting Date"] = dat_RowVestDate.ToString("dd/MMM/yyyy");
                                ac_GrantDetails.dt_TempVestDetails.Rows[i]["Vest Percent"] = s_VestPercent;
                                ac_GrantDetails.dt_TempVestDetails.Rows[i]["Expiry Date"] = dat_ExeDate.ToString("dd/MMM/yyyy");
                                ac_GrantDetails.dt_TempVestDetails.AcceptChanges();
                                grantDetails.lblValidateMsg.ForeColor = System.Drawing.Color.Blue;
                                grantDetails.lblValidateMsg.Text = valuationServiceClient.GetValuation_L10N("lblGDVDEDUpdated", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                                ac_GrantDetails.s_Error = string.Empty;
                            }

                            else if (dat_RowVestDate > dat_ExeDate)
                                grantDetails.lblValidateMsg.Text = valuationServiceClient.GetValuation_L10N("lblGDEDPriorvDError", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);

                            else if (dat_GrantDate > dat_RowVestDate)
                                grantDetails.lblValidateMsg.Text = valuationServiceClient.GetValuation_L10N("lblGDVDPriorGDError", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                        }

                        else
                            grantDetails.lblValidateMsg.Text = string.IsNullOrEmpty(s_VestDate) ? valuationServiceClient.GetValuation_L10N("lblGDEnterVestDate", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10) : string.IsNullOrEmpty(s_ExerEndDate) ? valuationServiceClient.GetValuation_L10N("lblGDEnterExerEndDate", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10) : string.IsNullOrEmpty(s_VestPercent) ? valuationServiceClient.GetValuation_L10N("lblGDEnterVestPercent", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10) : string.Empty;

                    }

                    grantDetails.rdbtnEquitySettled.Focus();
                    grantDetails.gvVestExercisePopulate.DataSource = ac_GrantDetails.dt_TempVestDetails;
                    grantDetails.gvVestExercisePopulate.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to Bind Vesting Schedule Grid
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void BindgvVestExercise(GrantDetails grantDetails)
        {
            grantDetails.gvVestExercisePopulate.DataSource = ac_GrantDetails.dt_TempVestDetails;
            grantDetails.gvVestExercisePopulate.DataBind();
            grantDetails.divValidateMsg.Visible = true;
        }
        #endregion

        #region Populate UpdateFairParamsGrid
        /// <summary>
        /// This Method is used to Populate UpdateParams Grid
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void PopulateUpdateParamsGrid(GrantDetails grantDetails)
        {
            try
            {
                int n_Temp_NoVest = 1;
                double d_TotalPercent = 0.00;
                DataTable dt_ValParams = new DataTable();
                dt_ValParams.Columns.Add("Valuation Parameters", typeof(string));
                dt_ValParams.Rows.Add("Market price for fair value");
                dt_ValParams.Rows.Add("Market price for intrinsic value");
                dt_ValParams.Rows.Add("Expected life (years)");
                dt_ValParams.Rows.Add("Dividend Yield");

                if (grantDetails.rdbtnUpdateParams.SelectedValue.Equals("P"))
                {
                    dt_ValParams.Rows.Add("Dividend Yield-Dividend");
                    dt_ValParams.Rows.Add("Dividend Yield-Market Price");
                }

                dt_ValParams.Rows.Add("Volatility");
                dt_ValParams.Rows.Add("Risk Free Interest Rate");

                if (grantDetails.rdbtnUpdateParams.SelectedValue.Equals("F"))
                {
                    dt_ValParams.Rows.Add("Fair Value");
                    dt_ValParams.Rows.Add("Intrinsic Value");
                }

                DataTable dt_tempUpdateGenParams = new DataTable();

                ac_GrantDetails.n_Real_NoVest = grantDetails.hdnAction.Value.Equals("U") ? Convert.ToInt32(grantDetails.txtAddGrantNumberOfVest.Text) : ac_GrantDetails.n_Real_NoVest;
                dt_tempUpdateGenParams.Columns.Add("Valuation Parameters", typeof(string));

                while (n_Temp_NoVest <= ac_GrantDetails.n_Real_NoVest)
                {
                    dt_tempUpdateGenParams.Columns.Add("Vest Date " + n_Temp_NoVest, typeof(DateTime));
                    dt_tempUpdateGenParams.AcceptChanges();
                    n_Temp_NoVest++;
                }

                dt_ValParams.Merge(dt_tempUpdateGenParams);
                ac_GrantDetails.n_NoOfColumns = dt_ValParams.Columns.Count;
                grantDetails.gvUpdateFairParams.Visible = true;
                grantDetails.divValidateMsg.Visible = false;

                foreach (GridViewRow perRow in grantDetails.gvVestExercisePopulate.Rows)
                {
                    d_TotalPercent += double.Parse(((TextBox)perRow.FindControl("txtVestPercent")).Text);
                }

                d_TotalPercent = Math.Round(d_TotalPercent, 2);

                TextBox txtVestTotal = (TextBox)grantDetails.gvVestExercisePopulate.FooterRow.FindControl("txtVestTotal");
                txtVestTotal.Text = Convert.ToString(d_TotalPercent);

                if (d_TotalPercent == 100.00 || d_TotalPercent == 100)
                {
                    grantDetails.trSaveContinue.Style.Add("display", "normal");
                    txtVestTotal.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    grantDetails.trSaveContinue.Style.Add("display", "none");
                    txtVestTotal.ForeColor = System.Drawing.Color.Red;
                }

                grantDetails.gvUpdateFairParams.Visible = true;
                ac_GrantDetails.dt_UpdateGenParams = dt_ValParams;

                grantDetails.gvUpdateFairParams.DataSource = dt_ValParams;
                grantDetails.gvUpdateFairParams.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to Bind UpdateFairParams Grid
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        /// <param name="grantDetails">grantDetails</param>
        internal void gvUpdateFairParams_RowDataBound(object sender, GridViewRowEventArgs e, GrantDetails grantDetails)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.DataRow:

                        for (int n_NoOfColumns = 1; n_NoOfColumns < ac_GrantDetails.n_NoOfColumns; n_NoOfColumns++)
                        {
                            e.Row.Cells[n_NoOfColumns].Controls.Add(AddTextBox(e.Row.RowIndex, n_NoOfColumns, e.Row.Cells[n_NoOfColumns].Text));
                            e.Row.Cells[n_NoOfColumns].Controls.Add(AddRFV(e.Row.RowIndex, n_NoOfColumns));
                            e.Row.Cells[n_NoOfColumns].HorizontalAlign = HorizontalAlign.Center;
                            grantDetails.gvUpdateFairParams.Visible = true;
                            grantDetails.btnAddGrantSaveContinue.Focus();

                            if (grantDetails.rdbtnUpdateParams.SelectedValue == "N")
                            {
                                grantDetails.gvUpdateFairParams.Visible = false;
                                grantDetails.btnAddGrantSaveContinue.Focus();
                            }
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to add textboxes to UpdateParams Grid
        /// </summary>
        /// <param name="n_rowIndex">n_rowIndex</param>
        /// <param name="n_NoOfColumns">n_NoOfColumns</param>
        /// <param name="s_Text">s_Text</param>
        /// <returns>returns textbox</returns>
        private Control AddTextBox(int n_rowIndex, int n_NoOfColumns, string s_Text)
        {
            using (TextBox txt_Box = new TextBox())
            {
                txt_Box.CssClass = "cTextBox txtEditCode Validators";
                txt_Box.ID = "txt_" + n_rowIndex + "_" + n_NoOfColumns;
                txt_Box.ClientIDMode = ClientIDMode.Static;
                txt_Box.ValidationGroup = "ValdParams_" + n_rowIndex;
                txt_Box.Attributes.Add("NoOfColumns", Convert.ToString(ac_GrantDetails.n_NoOfColumns));
                txt_Box.Text = s_Text.Equals("&nbsp;") ? string.Empty : s_Text;
                txt_Box.Width = 80;

                return txt_Box;
            }
        }

        /// <summary>
        /// This Method is used to add textboxes to UpdateParams Grid
        /// </summary>
        /// <param name="n_rowIndex">n_rowIndex</param>
        /// <param name="n_NoOfColumns">n_NoOfColumns</param>
        /// <returns>textbox</returns>
        private Control AddRFV(int n_rowIndex, int n_NoOfColumns)
        {
            using (RequiredFieldValidator o_RFV = new RequiredFieldValidator())
            {
                o_RFV.CssClass = "EDValidator";
                o_RFV.ID = "rfv_" + n_rowIndex + "_" + n_NoOfColumns;
                o_RFV.ClientIDMode = ClientIDMode.Static;
                o_RFV.ValidationGroup = "ValdParams_" + n_rowIndex;
                o_RFV.ControlToValidate = "txt_" + n_rowIndex + "_" + n_NoOfColumns;
                o_RFV.ToolTip = "Please enter Value";
                return o_RFV;
            }
        }
        #endregion

        #region Save and Continue Grant(s)
        /// <summary>
        /// This Method is used to save Garnt(s) Data to Database
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        internal void SaveContinueGrant(GrantDetails grantDetails, object sender, EventArgs e)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    bool b_flag = false, b_AddGrant = false, b_EditFlag = false; ;
                    int[] n_GRMIDs;

                    SaveVestExerciseGrid(grantDetails);

                    CheckPopulatedGrid(grantDetails);

                    if ((grantDetails.ddlAddGrantSchemeName.SelectedIndex == 0 || grantDetails.ddlAddGrantSchemeName.SelectedIndex == -1) && grantDetails.ddlAddGrantSchemeName.SelectedItem.Value.Equals("--- Please Select ---"))
                    {
                        valuationCRUDProperties.a_result = 3;
                    }

                    else
                    {
                        if (ac_GrantDetails.dt_GetGrantDetails != null && (grantDetails.hdnAction.Value != "U"))
                        {
                            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                            {
                                DataTable dt = new DataTable();
                                DataTable dt1 = new DataTable();
                                DataTable dt2 = new DataTable();
                                dt = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants;
                                dt1 = _gvUserControlModel.ac_SearchGrantDetails.dt_main_Locked_Valuation_Report;
                                dt2 = _gvUserControlModel.ac_SearchGrantDetails.dt_main_Unlocked_Valuation_Report;
                                if (dt1.Select().ToList().Exists(row => row["GRS_GRANT_REGISTRATION_ID"].ToString() == grantDetails.txtAddGrantGrantID.Text) || dt2.Select().ToList().Exists(row => row["GRS_GRANT_REGISTRATION_ID"].ToString() == grantDetails.txtAddGrantGrantID.Text))
                                {
                                    b_flag = true;
                                    valuationCRUDProperties.a_result = b_flag ? 4 : 0;
                                }
                            }
                            if (ac_GrantDetails.dt_GetGrantDetails.Select("[Grant Registration ID] = '" + grantDetails.txtAddGrantGrantID.Text + "'").Length > 0 || (ac_GrantDetails.dt_GrantRegMaster != null && ac_GrantDetails.dt_GrantRegMaster.Rows.Count > 0 && ac_GrantDetails.dt_GrantRegMaster.Select("[GRS_GRANT_REGISTRATION_ID] = '" + grantDetails.txtAddGrantGrantID.Text + "'").Length > 0))
                                b_flag = true;
                            valuationCRUDProperties.a_result = b_flag ? 4 : 0;
                        }

                        if (grantDetails.hdnAction.Value.Equals("U"))
                        {
                            b_EditFlag = Convert.ToInt32(grantDetails.txtAddGrantNumberOfVest.Text).Equals(grantDetails.gvVestExercisePopulate.Rows.Count);
                            valuationCRUDProperties.a_result = !b_EditFlag ? 5 : 0;
                        }

                        if (!b_flag && valuationCRUDProperties.a_result.Equals(0))
                        {
                            if (grantDetails.hdnAction.Value.Equals("U") && Convert.ToString(((Button)sender).ID).ToUpper() == "BTNADDGRANTADDMOREGRANTS")
                            {
                                b_AddGrant = AddMoreGrants_Click(grantDetails, sender, valuationServiceClient, b_AddGrant);
                            }
                            else
                            {
                                AddDatatToDataTable(grantDetails, ((Button)sender).ID);

                                if (ac_GrantDetails.dt_FileUploads == null)
                                    ac_GrantDetails.dt_FileUploads = new DataTable();

                                if (ac_GrantDetails.dt_FileUploads.Columns.Count == 0)
                                {
                                    ac_GrantDetails.dt_FileUploads.Columns.Add("GrantID", typeof(string));
                                    ac_GrantDetails.dt_FileUploads.Columns.Add("FileName", typeof(string));
                                    ac_GrantDetails.dt_FileUploads.Columns.Add("Remark", typeof(string));
                                }

                                if (grantDetails.FileUploadControlOne.HasFile && (grantDetails.FileUploadControlOne.FileName.Substring(grantDetails.FileUploadControlOne.FileName.LastIndexOf('.')) == ".doc" || grantDetails.FileUploadControlOne.FileName.Substring(grantDetails.FileUploadControlOne.FileName.LastIndexOf('.')) == ".docx" || grantDetails.FileUploadControlOne.FileName.Substring(grantDetails.FileUploadControlOne.FileName.LastIndexOf('.')) == ".pdf" || grantDetails.FileUploadControlOne.FileName.Substring(grantDetails.FileUploadControlOne.FileName.LastIndexOf('.')) == ".xlsx" || grantDetails.FileUploadControlOne.FileName.Substring(grantDetails.FileUploadControlOne.FileName.LastIndexOf('.')) == ".xls"))
                                {
                                    ac_GrantDetails.dt_FileUploads.Rows.Add(grantDetails.txtAddGrantGrantID.Text, grantDetails.txtAddGrantGrantID.Text + "_" + grantDetails.FileUploadControlOne.FileName, grantDetails.txtAddGrantCommentBox.Text);

                                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                    string s_MainFolderPath = grantDetails.Server.MapPath("~/Uploads/");
                                    string s_CmpNameFolderPath = grantDetails.Server.MapPath("~/Uploads/" + valuationProperties.SEN_CompanyName + "/");
                                    string s_FilePath = grantDetails.Server.MapPath("~/Uploads/" + valuationProperties.SEN_CompanyName + "/" + grantDetails.txtAddGrantGrantID.Text + "_" + Path.GetFileName(grantDetails.FileUploadControlOne.FileName));

                                    if (grantDetails.FileUploadControlOne.HasFile)
                                    {
                                        if (!Directory.Exists(s_CmpNameFolderPath))
                                        {
                                            Directory.CreateDirectory(s_CmpNameFolderPath);
                                        }

                                        if (!File.Exists(s_FilePath) && Directory.Exists(s_CmpNameFolderPath))
                                        {
                                            grantDetails.FileUploadControlOne.SaveAs(s_FilePath);
                                        }
                                    }
                                }

                                if (Convert.ToString(((Button)sender).ID).ToUpper() == "BTNADDGRANTSAVECONTINUE")
                                {
                                    if (!Is_GrantIDExists)
                                    {
                                        // Save button logic
                                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                                        valuationProperties.PopulateControls = "CUDGrantDetails";
                                        valuationProperties.PageName = CommonConstantModel.s_GrantDetails;
                                        valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                                        valuationProperties.dt_DBGrantRegMaster = ac_GrantDetails.dt_GrantRegMaster;
                                        valuationProperties.dt_DBGrantRegMaster.TableName = "DT";
                                        valuationProperties.dt_DBGrantRegDetails = ac_GrantDetails.dt_GrantRegDetails;
                                        valuationProperties.dt_DBGrantRegDetails.TableName = "DT";
                                        valuationProperties.Action = grantDetails.hdnAction.Value == "U" ? "U" : string.Empty;
                                        valuationProperties.Grant_ID = valuationProperties.Action == "U" ? grantDetails.txtAddGrantGrantID.Text : string.Empty;
                                        valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;

                                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                                        n_GRMIDs = valuationCRUDProperties.dt_Result.AsEnumerable().Select(s => s.Field<int>("GRM")).ToArray<int>();
                                        ac_GrantDetails.s_GRMIDs = grantDetails.hdnAction.Value.Equals("U") ? string.Empty : ac_GrantDetails.s_GRMIDs;

                                        for (int n_GRMID = 0; n_GRMID < n_GRMIDs.Count(); n_GRMID++)
                                        {
                                            if (string.IsNullOrEmpty(ac_GrantDetails.s_GRMIDs))
                                                ac_GrantDetails.s_GRMIDs = Convert.ToString(n_GRMIDs[n_GRMID]);

                                            else
                                                ac_GrantDetails.s_GRMIDs += "," + Convert.ToString(n_GRMIDs[n_GRMID]);
                                        }
                                        grantDetails.hdnhideTabs.Value = "2";
                                        grantDetails.hdnTabActiveIndex.Value = "1";

                                    }
                                    else
                                    {
                                        grantDetails.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblGDIDExists", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                                        grantDetails.btnAddGrantPopulateVestDetails.Style.Add("display", "none");
                                    }
                                }

                                else if (Convert.ToString(((Button)sender).ID).ToUpper() == "BTNADDGRANTADDMOREGRANTS")
                                {
                                    b_AddGrant = AddMoreGrants_Click(grantDetails, sender, valuationServiceClient, b_AddGrant);
                                }
                            }
                        }
                    }

                    if (!b_AddGrant)
                    {
                        grantDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        grantDetails.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;

                        if (!string.IsNullOrEmpty(ac_GrantDetails.s_GRMIDs) && valuationCRUDProperties.a_result.Equals(0))
                        {
                            string s_CmpNameFolderPath = grantDetails.Server.MapPath("~/Uploads/" + valuationProperties.SEN_CompanyName + "/");

                            if (ac_GrantDetails.dt_FileUploads.Rows.Count > 0)
                                SaveUploadeFile(grantDetails, s_CmpNameFolderPath);

                            grantDetails.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            grantDetails.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblGDDataSaved", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);

                            grantDetails.hdnAction.Value = "U";

                            EnableDisableControls(grantDetails, Convert.ToString(((Button)sender).ID));

                            grantDetails.ddlAddGrantSchemeName.Enabled = false;
                            grantDetails.txtAddGrantGrantID.Enabled = false;
                            grantDetails.txtEnterSchemeName.Enabled = false;

                            grantDetails.gvSearch.BindGrid();

                            ShowMsgForMissingPrices(grantDetails, valuationServiceClient);

                            grantDetails.UCUpdateGeneralParams.gvUGPGrantDetails.DataSource = ac_GrantDetails.dt_ViewDataEntered;
                            grantDetails.UCUpdateGeneralParams.gvUGPGrantDetails.DataBind();

                            FillSchemeDropDown(grantDetails, valuationServiceClient);

                            grantDetails.ddlAddGrantSchemeName.Text = Convert.ToString(ac_GrantDetails.dt_ViewDataEntered.Rows[ac_GrantDetails.dt_ViewDataEntered.Rows.Count - 1][0]);
                            grantDetails.txtEnterSchemeName.Visible = false;

                            ac_GrantDetails.dt_FileUploads = null;
                            ac_GrantDetails.dt_GrantRegMaster = null;
                            ac_GrantDetails.dt_GrantRegDetails = null;
                            ac_GrantDetails.dt_ViewDataEntered = null;
                        }

                        else
                            grantDetails.ctrSuccessErrorMessage.lblMessage.Text = valuationServiceClient.GetValuation_L10N("lblGDOperationError", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);

                        switch (valuationCRUDProperties.a_result)
                        {
                            case 3:
                                grantDetails.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblGDSelectSchemeError", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                                break;

                            case 4:
                                grantDetails.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblGDGrantIDExists", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                                ac_GrantDetails.dt_FileUploads = null;
                                ac_GrantDetails.dt_gvFileUploads = null;
                                grantDetails.gvFileUpload.DataSource = ac_GrantDetails.dt_gvFileUploads;
                                grantDetails.gvFileUpload.DataBind();
                                ac_GrantDetails.s_Error = "true";
                                PopulateUpdateParamsGrid(grantDetails);
                                break;

                            case 5:
                                grantDetails.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblGDNOVEqualsToVestGridRows", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                                break;
                        }

                        if (grantDetails.chkAddGrantExPrcLnkMultDates.Checked)
                        {
                            grantDetails.btnAddGrantPopulateVestDetails.Style.Add("display", "none");
                            grantDetails.hdnbtnAddGrantPopulateVestDetails.Style.Add("display", "normal");
                        }

                        else
                        {
                            grantDetails.btnAddGrantSaveContinue.Style.Add("display", "normal");
                            grantDetails.hdnbtnAddGrantPopulateVestDetails.Style.Add("display", "none");
                        }

                        grantDetails.divValidateMsg.Style.Add("display", "none");
                        grantDetails.rdbtnUpdateParams.SelectedIndex = 0;
                        grantDetails.gvUpdateFairParams.Visible = false;
                        valuationCRUDProperties.a_result = 0;
                    }

                    else
                        grantDetails.rdbtnEquitySettled.Focus();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to AddMoreGrants Click Button
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="sender">Add More Grant Button</param>
        /// <param name="valuationServiceClient">valuationServiceClient</param>
        /// <param name="b_AddGrant">Boolean b_AddGrant</param>
        /// <returns>bool b_AddGrant</returns>
        private bool AddMoreGrants_Click(GrantDetails grantDetails, object sender, ValuationServiceClient valuationServiceClient, bool b_AddGrant)
        {
            grantDetails.hdnAction.Value = "S";

            if (grantDetails.ddlAddGrantSchemeName.SelectedItem.Text.Equals("--- Enter New Scheme ---"))
            {
                using (DataTable dt_SchemeName = ac_GrantDetails.dt_GetGrantDetails.DefaultView.ToTable(true, "Scheme Title"))
                {
                    if ((dt_SchemeName != null) && (dt_SchemeName.Rows.Count > 0))
                    {
                        DataRow perRow = dt_SchemeName.NewRow();
                        dt_SchemeName.Rows.Add(perRow["Scheme Title"] = grantDetails.txtEnterSchemeName.Text);

                        grantDetails.ddlAddGrantSchemeName.DataSource = dt_SchemeName;
                        grantDetails.ddlAddGrantSchemeName.DataTextField = "Scheme Title";
                        grantDetails.ddlAddGrantSchemeName.DataValueField = "Scheme Title";
                        grantDetails.ddlAddGrantSchemeName.DataBind();
                        grantDetails.ddlAddGrantSchemeName.Items.Insert(0, "--- Please Select ---");
                        grantDetails.ddlAddGrantSchemeName.Items.Insert(1, "--- Enter New Scheme ---");
                    }
                }
            }

            ClearAllTabControls(grantDetails, sender);

            if (Is_GrantIDExists)
            {
                grantDetails.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblGDIDExists", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                grantDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                grantDetails.btnAddGrantPopulateVestDetails.Style.Add("display", "none");
            }
            b_AddGrant = true;
            return b_AddGrant;
        }

        DataTable dt_GrantRegMaster = new DataTable();

        DataTable dt_GrantRegDetails = new DataTable();

        /// <summary>
        /// This Method is used to store All Garnts Data to CommonDatatables 
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="s_ButtonName">s_ButtonName</param>
        public void AddDatatToDataTable(GrantDetails grantDetails, string s_ButtonName)
        {
            try
            {
                ac_GrantDetails.dt_GrantRegMaster = grantDetails.hdnAction.Value.Equals("U") || grantDetails.gvSearch.hdnDropDownChange.Value.Equals("1") ? null : ac_GrantDetails.dt_GrantRegMaster;
                ac_GrantDetails.dt_GrantRegDetails = grantDetails.hdnAction.Value.Equals("U") || grantDetails.gvSearch.hdnDropDownChange.Value.Equals("1") ? null : ac_GrantDetails.dt_GrantRegDetails;
                ac_GrantDetails.dt_ViewDataEntered = ((grantDetails.hdnAction.Value.Equals("U") || grantDetails.gvSearch.hdnDropDownChange.Value.Equals("1")) && !s_ButtonName.Equals("btnAddGrantAddMoreGrants") || !grantDetails.hdnAction.Value.Equals("S")) ? null : ac_GrantDetails.dt_ViewDataEntered;

                if (ac_GrantDetails.dt_GrantRegDetails == null)
                    ac_GrantDetails.dt_GrantRegDetails = new DataTable();

                if (ac_GrantDetails.dt_GrantRegDetails.Columns.Count == 0)
                {
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("SCH_SCHEME_TITLE", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("GRS_GRANT_REGISTRATION_ID", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("GRS_GRANT_DATE", typeof(DateTime));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("GRS_EXERCISE_PRICE", typeof(double));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("VPD_VESTING_PERIOD_ID", typeof(int));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("VPD_VESTING_DATE", typeof(DateTime));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("VPD_EXPIRY_DATE", typeof(DateTime));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("VPD_VESTING_TYPE", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("VPD_VESTING_PERIOD_NO", typeof(int));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("CRMID", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("SETTLEMENT_OF_OPTIONS", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("PRICING_FORMULA", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("NO_OF_VESTS", typeof(int));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("VEST_PERCENT", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("VESTING_FEQUENCY", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("VESIING_FREQUENCY_VALUE", typeof(int));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("VESTING_AFTER_1_YEAR", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("EXERCISE_PERIOD", typeof(int));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("EXERCISE_PERIOD_FREQ", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("EXERCISE_PERIOD_FROM", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("MULTIPLE_EXSERCISE_PERIOD", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("MULT_EXERCISE_PERIOD_VALUE", typeof(int));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("MULT_EXSERCISE_PERIOD_FREQ", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("MULT_EXSERCISE_PERIOD_FREQ_FROM", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("WHICHEVERIS", typeof(string));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("TRUST_ROUTE", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("RATIO_OPTION", typeof(int));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("RATIO_SHARE", typeof(int));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("MARKET_PRICE_PER_VEST", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("MARKET_PRICE_IV", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("EXPECTED_LIFE_PER_VEST", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("VOLATILITY_PER_VEST", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("RFIR_PER_VEST", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("DIVIDEND_PER_VEST", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("FAIR_VALUE_PER_VEST", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("INTRINSIC_VALUE_PER_VEST", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("DIVIDEND_YIELD_DIVD", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("DIVIDEND_YIELD_MARKET_PRICE", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("UPDATE_VAL_PARAMS", typeof(string));

                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("IS_MU_MKT_FV", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("IS_MU_MKT_IV", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("IS_MU_EXL", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("IS_MU_VOL", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("IS_MU_RFIR", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("IS_MU_DIVD", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("IS_MU_FV", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("IS_MU_IV", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("IS_MU_DIVD_MP_DIVD", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("IS_MRKT_LINKED", typeof(byte));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("TIME_BASED_VEST_PERCENT", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("PERFORMANCE_BASED_VEST_PERCENT", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegDetails.Columns.Add("OPERATION_DATE", typeof(DateTime));
                }

                int nRowCount = 0;

                foreach (DataRow perRow in ac_GrantDetails.dt_TempVestDetails.Rows)
                {
                    DataRow drGrantRegDetails = ac_GrantDetails.dt_GrantRegDetails.NewRow();
                    nRowCount = nRowCount + 1;
                    drGrantRegDetails["SCH_SCHEME_TITLE"] = grantDetails.ddlAddGrantSchemeName.SelectedItem.Text == "--- Enter New Scheme ---" ? grantDetails.txtEnterSchemeName.Text : grantDetails.ddlAddGrantSchemeName.SelectedItem.Text;
                    drGrantRegDetails["GRS_GRANT_REGISTRATION_ID"] = grantDetails.txtAddGrantGrantID.Text;
                    drGrantRegDetails["GRS_GRANT_DATE"] = Convert.ToDateTime(grantDetails.txtAddGrantGrantDate.Text);
                    drGrantRegDetails["GRS_EXERCISE_PRICE"] = string.IsNullOrEmpty(grantDetails.txtAddGrantExercisePrice.Text) ? (object)DBNull.Value : Convert.ToDouble(grantDetails.txtAddGrantExercisePrice.Text);
                    drGrantRegDetails["VPD_VESTING_PERIOD_ID"] = Convert.ToInt32(Convert.ToString(perRow["Vesting Period ID"]));
                    drGrantRegDetails["VPD_VESTING_DATE"] = Convert.ToDateTime(Convert.ToString(perRow["Vesting Date"]));
                    drGrantRegDetails["VPD_EXPIRY_DATE"] = Convert.ToDateTime(Convert.ToString(perRow["Expiry Date"]));
                    drGrantRegDetails["VPD_VESTING_TYPE"] = grantDetails.ddlAddGrantVestingParams.SelectedItem.Text == "Time Based" ? "T" : grantDetails.ddlAddGrantVestingParams.SelectedItem.Text == "Performance Based" ? "P" : "B";
                    drGrantRegDetails["VPD_VESTING_PERIOD_NO"] = Convert.ToInt32(Convert.ToString(perRow["Vesting Period ID"]));
                    drGrantRegDetails["CRMID"] = grantDetails.ddlAddGrantCurrency.SelectedItem.Value;
                    drGrantRegDetails["SETTLEMENT_OF_OPTIONS"] = grantDetails.rdbtnCashSettled.Checked ? "C" : "E";
                    drGrantRegDetails["PRICING_FORMULA"] = grantDetails.txtAddGrantPricingFormula.Text;
                    drGrantRegDetails["NO_OF_VESTS"] = Convert.ToInt32(grantDetails.txtAddGrantNumberOfVest.Text);
                    drGrantRegDetails["VEST_PERCENT"] = Convert.ToDecimal(Convert.ToString(perRow["Vest Percent"]));
                    drGrantRegDetails["VESTING_FEQUENCY"] = grantDetails.rdbtnVestingFreqYearly.SelectedItem.Value == "Q" ? "Q" : grantDetails.rdbtnVestingFreqYearly.SelectedItem.Text == "M" ? "M" : grantDetails.rdbtnVestingFreqYearly.SelectedItem.Text == "D" ? "D" : "Y";
                    drGrantRegDetails["VESIING_FREQUENCY_VALUE"] = Convert.ToInt32(grantDetails.txtAddGrantVestingFrequency.Text);
                    drGrantRegDetails["VESTING_AFTER_1_YEAR"] = Convert.ToByte(grantDetails.chkFirstVestAftrOneYr.Checked ? 1 : 0);
                    drGrantRegDetails["EXERCISE_PERIOD"] = grantDetails.chkAddGrantExPrcLnkMultDates.Checked ? 0 : Convert.ToInt32(grantDetails.txtAddGrantExercisePeriod.Text);
                    drGrantRegDetails["EXERCISE_PERIOD_FREQ"] = grantDetails.rdbtnExerPeriodYears.SelectedItem.Value == "M" ? "M" : grantDetails.rdbtnExerPeriodYears.SelectedItem.Value == "D" ? "D" : "Y";
                    drGrantRegDetails["EXERCISE_PERIOD_FROM"] = grantDetails.rdbtnExerPeriodFromDOG.SelectedItem.Value == "G" ? "G" : grantDetails.rdbtnExerPeriodFromDOG.SelectedItem.Value == "L" ? "L" : "V";
                    drGrantRegDetails["MULTIPLE_EXSERCISE_PERIOD"] = Convert.ToByte(grantDetails.chkAddGrantExPrcLnkMultDates.Checked ? 1 : 0);
                    drGrantRegDetails["MULT_EXERCISE_PERIOD_VALUE"] = grantDetails.chkAddGrantExPrcLnkMultDates.Checked ? ac_GrantDetails.n_Mult_Exer_Period_Value : 0;
                    drGrantRegDetails["MULT_EXSERCISE_PERIOD_FREQ"] = grantDetails.chkAddGrantExPrcLnkMultDates.Checked ? ac_GrantDetails.n_Mult_Exer_Period_Freq : "0";
                    drGrantRegDetails["MULT_EXSERCISE_PERIOD_FREQ_FROM"] = grantDetails.chkAddGrantExPrcLnkMultDates.Checked ? ac_GrantDetails.n_Mult_Exer_Period_Freq_From : "0";
                    drGrantRegDetails["WHICHEVERIS"] = grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedItem.Value;
                    drGrantRegDetails["TRUST_ROUTE"] = Convert.ToByte(grantDetails.chkAddGrantTrstRouteYes.Checked ? 1 : 0);
                    drGrantRegDetails["RATIO_OPTION"] = !string.IsNullOrEmpty(grantDetails.txtAddGrantRatioOpt.Text) ? Convert.ToInt32(grantDetails.txtAddGrantRatioOpt.Text) : 1;
                    drGrantRegDetails["RATIO_SHARE"] = !string.IsNullOrEmpty(grantDetails.txtAddGrantRatioShares.Text) ? Convert.ToInt32(grantDetails.txtAddGrantRatioShares.Text) : 1;
                    drGrantRegDetails["MARKET_PRICE_PER_VEST"] = (grantDetails.hdnMarketPricePerVest.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnMarketPricePerVest.Value.Split('~')[nRowCount]);
                    drGrantRegDetails["MARKET_PRICE_IV"] = (grantDetails.hdnMarketPriceIV.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnMarketPriceIV.Value.Split('~')[nRowCount]);
                    drGrantRegDetails["EXPECTED_LIFE_PER_VEST"] = (grantDetails.hdnExpectedLife.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnExpectedLife.Value.Split('~')[nRowCount]);
                    drGrantRegDetails["DIVIDEND_PER_VEST"] = (grantDetails.hdnDividend.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnDividend.Value.Split('~')[nRowCount]);
                    drGrantRegDetails["VOLATILITY_PER_VEST"] = (grantDetails.hdnVolatility.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnVolatility.Value.Split('~')[nRowCount]);
                    drGrantRegDetails["RFIR_PER_VEST"] = (grantDetails.hdnRFIR.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnRFIR.Value.Split('~')[nRowCount]);
                    drGrantRegDetails["FAIR_VALUE_PER_VEST"] = (grantDetails.hdnFairVal.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnFairVal.Value.Split('~')[nRowCount]);
                    drGrantRegDetails["INTRINSIC_VALUE_PER_VEST"] = (grantDetails.hdnIntriVal.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnIntriVal.Value.Split('~')[nRowCount]);

                    drGrantRegDetails["DIVIDEND_YIELD_DIVD"] = (grantDetails.hdnDividendDIVD.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnDividendDIVD.Value.Split('~')[nRowCount]);
                    drGrantRegDetails["DIVIDEND_YIELD_MARKET_PRICE"] = (grantDetails.hdnDividendMP.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnDividendMP.Value.Split('~')[nRowCount]);

                    drGrantRegDetails["UPDATE_VAL_PARAMS"] = (grantDetails.rdbtnUpdateParams.SelectedItem == null) ? "N" : grantDetails.rdbtnUpdateParams.SelectedItem.Value == "P" ? "P" : grantDetails.rdbtnUpdateParams.SelectedItem.Value == "F" ? "F" : "N";

                    drGrantRegDetails["IS_MU_MKT_FV"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnMPFlag.Value == "set") ? 1 : 0);
                    drGrantRegDetails["IS_MU_MKT_IV"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnMPIVFlag.Value == "set") ? 1 : 0);
                    drGrantRegDetails["IS_MU_EXL"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnEXLFlag.Value == "set") ? 1 : 0);
                    drGrantRegDetails["IS_MU_VOL"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnVOLFlag.Value == "set") ? 1 : 0);
                    drGrantRegDetails["IS_MU_RFIR"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnRFIRFlag.Value == "set") ? 1 : 0);
                    drGrantRegDetails["IS_MU_DIVD"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnDIVDFlag.Value == "set") ? 1 : 0);
                    drGrantRegDetails["IS_MU_FV"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnFVFlag.Value == "set") ? 1 : 0);
                    drGrantRegDetails["IS_MU_IV"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnIVFlag.Value == "set") ? 1 : 0);
                    drGrantRegDetails["IS_MU_DIVD_MP_DIVD"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && (grantDetails.hdnDIVDDivdFlag.Value == "set" || grantDetails.hdnDividendMPFlag.Value == "set")) ? 1 : 0);

                    drGrantRegDetails["IS_MRKT_LINKED"] = grantDetails.rdbtnMrktLnk.Checked ? 1 : 0;
                    drGrantRegDetails["TIME_BASED_VEST_PERCENT"] = grantDetails.ddlAddGrantVestingParams.SelectedItem.Text.Equals("Both") ? Convert.ToDecimal(Convert.ToString(perRow["Time Based Vest Percent"])) : Convert.ToDecimal(0);
                    drGrantRegDetails["PERFORMANCE_BASED_VEST_PERCENT"] = grantDetails.ddlAddGrantVestingParams.SelectedItem.Text.Equals("Both") ? Convert.ToDecimal(Convert.ToString(perRow["Performance Based Vest Percent"])) : Convert.ToDecimal(0);
                    drGrantRegDetails["OPERATION_DATE"] = Convert.ToDateTime(grantDetails.txtAddGrantGrantDate.Text) + DateTime.Now.TimeOfDay;

                    ac_GrantDetails.dt_GrantRegDetails.Rows.Add(drGrantRegDetails);

                    if (ac_GrantDetails.dt_ViewDataEntered == null)
                        ac_GrantDetails.dt_ViewDataEntered = new DataTable();

                    if (ac_GrantDetails.dt_ViewDataEntered.Columns.Count.Equals(0))
                    {
                        ac_GrantDetails.dt_ViewDataEntered.Columns.Add("Scheme Name", typeof(string));
                        ac_GrantDetails.dt_ViewDataEntered.Columns.Add("Grant ID", typeof(string));
                        ac_GrantDetails.dt_ViewDataEntered.Columns.Add("Grant Date", typeof(string));
                        ac_GrantDetails.dt_ViewDataEntered.Columns.Add("Currency", typeof(string));
                        ac_GrantDetails.dt_ViewDataEntered.Columns.Add("Exercise Price", typeof(string));
                        ac_GrantDetails.dt_ViewDataEntered.Columns.Add("Vesting Details", typeof(string));
                        ac_GrantDetails.dt_ViewDataEntered.Columns.Add("Settlement Of Options", typeof(string));
                        ac_GrantDetails.dt_ViewDataEntered.Columns.Add("Ratio Options to Shares", typeof(string));
                        ac_GrantDetails.dt_ViewDataEntered.Columns.Add("Trust Route", typeof(string));
                    }

                    string s_CRMID = grantDetails.ddlAddGrantCurrency.SelectedItem.Text;
                    string s_ExPrdFrom = Convert.ToString(drGrantRegDetails["EXERCISE_PERIOD_FROM"]) == "L" ? "Listing" : Convert.ToString(drGrantRegDetails["EXERCISE_PERIOD_FROM"]) == "G" ? "Grant" : "Vesting";
                    string s_SettOpts = Convert.ToString(drGrantRegDetails["SETTLEMENT_OF_OPTIONS"]) == "C" ? "Cash Settled" : "Equity Settled";
                    string s_TrstRut = grantDetails.chkAddGrantTrstRouteYes.Checked ? "Yes" : "No";

                    if (ac_GrantDetails.dt_ViewDataEntered.Select("[Grant ID] = '" + drGrantRegDetails["GRS_GRANT_REGISTRATION_ID"] + "'").Length.Equals(0))
                    {
                        ac_GrantDetails.dt_ViewDataEntered.Rows.Add(drGrantRegDetails["SCH_SCHEME_TITLE"], drGrantRegDetails["GRS_GRANT_REGISTRATION_ID"], DateTime.Parse(Convert.ToString(drGrantRegDetails["GRS_GRANT_DATE"])).ToString("dd/MMM/yyyy"), s_CRMID,
                            drGrantRegDetails["GRS_EXERCISE_PRICE"], " ", s_SettOpts, drGrantRegDetails["RATIO_OPTION"] + " : " + drGrantRegDetails["RATIO_SHARE"], s_TrstRut);
                    }

                    if ((grantDetails.rdbtnUpdateParams.SelectedValue == "F") && !(grantDetails.hdnFairVal.Value.Equals("0")))
                        d_OptFairVal = d_OptFairVal + (Convert.ToDecimal(Convert.ToString(perRow["Vest Percent"])) * Convert.ToDecimal(grantDetails.hdnFairVal.Value.Split('~')[nRowCount]) / 100);

                    if ((grantDetails.rdbtnUpdateParams.SelectedValue == "F") && !(grantDetails.hdnIntriVal.Value.Equals("0")))
                        d_OptIntrinsicVal = d_OptIntrinsicVal + Convert.ToDecimal(grantDetails.hdnIntriVal.Value.Split('~')[nRowCount]);

                }

                if (ac_GrantDetails.dt_GrantRegMaster == null)
                    ac_GrantDetails.dt_GrantRegMaster = new DataTable();

                if (ac_GrantDetails.dt_GrantRegMaster.Columns.Count == 0)
                    if (ac_GrantDetails.dt_GrantRegMaster == null)
                        ac_GrantDetails.dt_GrantRegMaster = new DataTable();

                if (ac_GrantDetails.dt_GrantRegMaster.Columns.Count == 0)
                {
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("GRS_GRANT_REGISTRATION_ID", typeof(string));

                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("GRS_GRANT_DATE", typeof(DateTime));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("GRS_EXERCISE_PRICE", typeof(double));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("CRMID", typeof(string));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("PRICING_FORMULA", typeof(string));

                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("VESTING_TYPE", typeof(string));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("OPTION_FAIR_VALUE", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("OPTION_INTRINSIC_VALUE", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("MARKET_PRICE_FOR_FAIR_VALUE", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("MARKET_PRICE_FOR_INTRINSIC_VALUE", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("EXPECTED_LIFE", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("VOLATILITY", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("RISK_FREE_INTEREST_RATE", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("DIVIDEND_YIELD", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("DIVIDEND_YIELD_DIVD", typeof(decimal));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("DIVIDEND_YIELD_MARKET_PRICE", typeof(decimal));

                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("IS_MU_MKT_FV", typeof(byte));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("IS_MU_MKT_IV", typeof(byte));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("IS_MU_EXL", typeof(byte));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("IS_MU_VOL", typeof(byte));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("IS_MU_RFIR", typeof(byte));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("IS_MU_DIVD", typeof(byte));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("IS_MU_FV", typeof(byte));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("IS_MU_IV", typeof(byte));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("IS_MU_DIVD_MP_DIVD", typeof(byte));
                    ac_GrantDetails.dt_GrantRegMaster.Columns.Add("OPERATION_DATE", typeof(DateTime));
                }

                if (!ac_GrantDetails.dt_GrantRegMaster.Select().ToList().Exists(row => row["GRS_GRANT_REGISTRATION_ID"].ToString().ToUpper() == grantDetails.txtAddGrantGrantID.Text.ToUpper()))
                {
                    DataRow drGrantRegMaster = ac_GrantDetails.dt_GrantRegMaster.NewRow();
                    drGrantRegMaster["GRS_GRANT_REGISTRATION_ID"] = grantDetails.txtAddGrantGrantID.Text;

                    drGrantRegMaster["GRS_GRANT_DATE"] = Convert.ToDateTime(grantDetails.txtAddGrantGrantDate.Text);
                    drGrantRegMaster["GRS_EXERCISE_PRICE"] = string.IsNullOrEmpty(grantDetails.txtAddGrantExercisePrice.Text) ? (object)DBNull.Value : Convert.ToDouble(grantDetails.txtAddGrantExercisePrice.Text);
                    drGrantRegMaster["CRMID"] = grantDetails.ddlAddGrantCurrency.SelectedItem.Value;
                    drGrantRegMaster["PRICING_FORMULA"] = grantDetails.txtAddGrantPricingFormula.Text;
                    drGrantRegMaster["DIVIDEND_YIELD_DIVD"] = (grantDetails.hdnDividendDIVD.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnDividendDIVD.Value.Split('~')[1]);
                    drGrantRegMaster["DIVIDEND_YIELD_MARKET_PRICE"] = (grantDetails.hdnDividendMP.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnDividendMP.Value.Split('~')[1]);

                    drGrantRegMaster["VESTING_TYPE"] = grantDetails.ddlAddGrantVestingParams.SelectedItem.Text == "Time Based" ? "T" : grantDetails.ddlAddGrantVestingParams.SelectedItem.Text == "Performance Based" ? "P" : "B";

                    drGrantRegMaster["OPTION_FAIR_VALUE"] = (grantDetails.rdbtnUpdateParams.SelectedValue == "F") && !(grantDetails.hdnFairVal.Value.Equals("0")) ? d_OptFairVal : (object)DBNull.Value;
                    drGrantRegMaster["OPTION_INTRINSIC_VALUE"] = (grantDetails.rdbtnUpdateParams.SelectedValue == "F") && !(grantDetails.hdnIntriVal.Value.Equals("0")) ? d_OptIntrinsicVal / Convert.ToDecimal(grantDetails.txtAddGrantNumberOfVest.Text) : (object)DBNull.Value;
                    drGrantRegMaster["MARKET_PRICE_FOR_FAIR_VALUE"] = (grantDetails.hdnMarketPricePerVest.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnMarketPricePerVest.Value.Split('~')[1]);
                    drGrantRegMaster["MARKET_PRICE_FOR_INTRINSIC_VALUE"] = (grantDetails.hdnMarketPriceIV.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnMarketPriceIV.Value.Split('~')[1]);
                    drGrantRegMaster["EXPECTED_LIFE"] = (grantDetails.hdnExpectedLife.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnExpectedLife.Value.Split('~')[1]);
                    drGrantRegMaster["VOLATILITY"] = (grantDetails.hdnVolatility.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnVolatility.Value.Split('~')[1]);
                    drGrantRegMaster["RISK_FREE_INTEREST_RATE"] = (grantDetails.hdnRFIR.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnRFIR.Value.Split('~')[1]);
                    drGrantRegMaster["DIVIDEND_YIELD"] = (grantDetails.hdnDividend.Value == "0") ? (object)DBNull.Value : Convert.ToDecimal(grantDetails.hdnDividend.Value.Split('~')[1]);
                    drGrantRegMaster["IS_MU_DIVD_MP_DIVD"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && (grantDetails.hdnDIVDDivdFlag.Value == "set" || grantDetails.hdnDividendMPFlag.Value == "set")) ? 1 : 0);

                    drGrantRegMaster["IS_MU_MKT_FV"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnMPFlag.Value == "set") ? 1 : 0);
                    drGrantRegMaster["IS_MU_MKT_IV"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnMPIVFlag.Value == "set") ? 1 : 0);
                    drGrantRegMaster["IS_MU_EXL"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnEXLFlag.Value == "set") ? 1 : 0);
                    drGrantRegMaster["IS_MU_VOL"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnVOLFlag.Value == "set") ? 1 : 0);
                    drGrantRegMaster["IS_MU_RFIR"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnRFIRFlag.Value == "set") ? 1 : 0);
                    drGrantRegMaster["IS_MU_DIVD"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnDIVDFlag.Value == "set") ? 1 : 0);
                    drGrantRegMaster["IS_MU_FV"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnFVFlag.Value == "set") ? 1 : 0);
                    drGrantRegMaster["IS_MU_IV"] = Convert.ToByte((((grantDetails.rdbtnUpdateParams.SelectedValue == "P") || (grantDetails.rdbtnUpdateParams.SelectedValue == "F")) && grantDetails.hdnIVFlag.Value == "set") ? 1 : 0);
                    drGrantRegMaster["OPERATION_DATE"] = Convert.ToDateTime(grantDetails.txtAddGrantGrantDate.Text) + DateTime.Now.TimeOfDay;

                    ac_GrantDetails.dt_GrantRegMaster.Rows.Add(drGrantRegMaster);
                }
                else
                {
                    Is_GrantIDExists = true;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region File Upload
        /// <summary>
        /// This Method is used to Upload File Document(s)
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="s_CmpNameFolderPath">Company Folder Path s_CmpNameFolderPath</param>
        internal void SaveUploadeFile(GrantDetails grantDetails, string s_CmpNameFolderPath)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                    valuationProperties.PageName = CommonConstantModel.s_GrantDetails;
                    valuationProperties.dt_DBFileUploads = ac_GrantDetails.dt_FileUploads;
                    valuationProperties.dt_DBFileUploads.TableName = "DT";
                    valuationProperties.Document_Path = s_CmpNameFolderPath;
                    valuationProperties.Document_VersionNo = 0;

                    valuationProperties.PopulateControls = "DocumentUpload";
                    valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    valuationProperties.Action = "U";

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Bind Scheme Names to Scheme NamesDropdown
        /// <summary>
        /// This Method is used to Bind Scheme Names to Scheme NamesDropdown
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="valuationServiceClient">valuationServiceClient</param>
        public void FillSchemeDropDown(GrantDetails grantDetails, ValuationServiceClient valuationServiceClient)
        {
            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                valuationProperties.PageName = CommonConstantModel.s_GrantDetails;
                valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                valuationProperties.Operation_Param = CommonConstantModel.s_ValuationReport;

                valuationProperties.PopulateControls = "GET_GRANT_DETAILS";
                valuationProperties.PAGE_INDEX = _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex.Equals(0) ? 1 : _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex;
                valuationProperties.PAGE_SIZE = _gvUserControlModel.ac_SearchGrantDetails.n_PageSize.Equals(0) ? 10 : _gvUserControlModel.ac_SearchGrantDetails.n_PageSize;
                valuationProperties.PAGE_INDEX_LOCKED = _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex_Locked.Equals(0) ? 1 : _gvUserControlModel.ac_SearchGrantDetails.n_PageIndex_Locked;
                valuationProperties.PAGE_SIZE_LOCKED = _gvUserControlModel.ac_SearchGrantDetails.n_PageSize_Locked.Equals(0) ? 10 : _gvUserControlModel.ac_SearchGrantDetails.n_PageSize_Locked;
                valuationProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;
                valuationProperties.SEN_IsMYESOPsClient = userSessionInfo.ACC_IsMYESOPsClient;
                valuationProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                valuationProperties.SEN_CompanyTitle = userSessionInfo.ACC_CompanyTitle;

                valuationProperties.GET_DATA_TYPE = "GRANTWISE";
                valuationProperties.Operation_Param = CommonConstantModel.s_GrantDetails;

                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                valuationCRUDProperties.ds_Result.Tables[0].TableName = "DT";

                ac_GrantDetails.dt_GetGrantDetails = (DataTable)valuationCRUDProperties.ds_Result.Tables[0];
                grantDetails.ddlAddGrantSchemeName.DataSource = ac_GrantDetails.dt_GetGrantDetails.DefaultView.ToTable(true, "Scheme Title");
                grantDetails.ddlAddGrantSchemeName.DataTextField = "Scheme Title";
                grantDetails.ddlAddGrantSchemeName.DataValueField = "Scheme Title";
                grantDetails.ddlAddGrantSchemeName.DataBind();
                grantDetails.ddlAddGrantSchemeName.Items.Insert(0, "--- Please Select ---");
                grantDetails.ddlAddGrantSchemeName.Items.Insert(1, "--- Enter New Scheme ---");
            }
        }
        #endregion

        #region ClearAllTabControls
        /// <summary>
        /// This Method is used to clear all grant details tab controls.
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="sender">sender's object</param>
        internal void ClearAllTabControls(GrantDetails grantDetails, object sender)
        {
            try
            {
                if (Convert.ToString(((Button)sender).ID).ToUpper() == "BTNADDGRANTADDMOREGRANTS")
                {
                    grantDetails.ddlAddGrantSchemeName.SelectedIndex = -1;
                    grantDetails.txtAddGrantGrantID.Text = string.Empty;
                    grantDetails.ddlAddGrantSchemeName.Focus();
                }
                grantDetails.lblMsgMP.Visible = false;
                grantDetails.lblMsgRFIR.Visible = false;
                grantDetails.txtAddGrantGrantID.Enabled = true;
                grantDetails.ddlAddGrantSchemeName.Enabled = true;
                grantDetails.txtAddGrantGrantDate.Text = string.Empty;
                grantDetails.txtAddGrantExercisePrice.Text = string.Empty;
                grantDetails.txtAddGrantPricingFormula.Text = string.Empty;
                grantDetails.ddlAddGrantCurrency.SelectedIndex = -1;
                grantDetails.txtAddGrantNumberOfVest.Text = string.Empty;
                grantDetails.txtAddGrantVestingFrequency.Text = string.Empty;
                grantDetails.chkAddGrantTrstRouteNo.Checked = true;
                grantDetails.chkAddGrantTrstRouteYes.Checked = false;
                grantDetails.txtAddGrantExercisePeriod.Text = string.Empty;
                grantDetails.chkFirstVestAftrOneYr.Checked = false;
                grantDetails.chkAddGrantExPrcLnkMultDates.Checked = false;
                grantDetails.txtAddGrantExPrcFirst.Text = string.Empty;
                grantDetails.txtAddGrantExPrcSecond.Text = string.Empty;
                grantDetails.divVestExercisePopulate.Visible = false;
                grantDetails.txtAddGrantRatioOpt.Text = "1";
                grantDetails.txtAddGrantRatioShares.Text = "1";
                grantDetails.txtAddGrantCommentBox.Text = string.Empty;
                grantDetails.gvUpdateFairParams.Visible = false;
                grantDetails.divVestExercisePopulateOne.Style.Add("display", "normal");
                grantDetails.trdivVestExercisePopulateFirst.Style.Add("display", "normal");
                grantDetails.ddlAddGrantVestingParams.SelectedIndex = -1;
                grantDetails.rdbtnVestingFreqYearly.SelectedIndex = 0;
                grantDetails.rdbtnExerPeriodYears.SelectedIndex = 0;
                grantDetails.rdbtnExerPeriodFromDOG.SelectedIndex = 1;
                grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedIndex = 0;
                grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedIndex = 1;
                grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedIndex = 0;
                grantDetails.rdbtnExPrcLnkMultDatesYearsTwo.SelectedIndex = 0;
                grantDetails.rdbtnExPrcLnkMultDatesGDTwo.SelectedIndex = 1;

                grantDetails.trSaveContinue.Style.Add("display", "none");
                grantDetails.btnAddGrantAddMoreGrants.Visible = false;
                grantDetails.btnAddGrantSaveContinue.Visible = false;
                grantDetails.popup.Style.Add("display", "none");

                if (!(string.IsNullOrEmpty(Convert.ToString(sender))))
                {
                    if (!Convert.ToString(((Button)sender).ID).Equals("btnGDSearch") && !Convert.ToString(((Button)sender).ID).Equals("btnGDResetFilter"))
                        grantDetails.h4ViewAddEditGV.Style.Add("display", "block");

                    else
                        grantDetails.h4ViewAddEditGV.Style.Add("display", "none");
                }

                grantDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Display Message Box
        /// <summary>
        /// This Method is used to Display Message Box
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="s_ButtonID">Button ID</param>
        /// <param name="n_Result">n_Result</param>
        public void DisplayMessage(GrantDetails grantDetails, string s_ButtonID, int n_Result)
        {
            try
            {
                grantDetails.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "block");
                grantDetails.h4ViewAddEditGV.Style.Add("display", "none");

                grantDetails.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    switch (s_ButtonID)
                    {
                        case "btnGDDelete":
                            switch (n_Result)
                            {
                                case 0:
                                    grantDetails.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    grantDetails.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblGDErrorDelete", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                                    grantDetails.gvSearch.hdnIsDeleted.Value = "true";
                                    break;

                                case 1:
                                    grantDetails.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    grantDetails.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblGDDeleted", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                                    grantDetails.gvSearch.hdnIsDeleted.Value = "true";

                                    GetGrantDetails(grantDetails);

                                    if (((ac_GrantDetails.dt_temp_Unlocked_Valuation_Report != null) && (ac_GrantDetails.dt_temp_Unlocked_Valuation_Report.Rows.Count > 0)) || ((ac_GrantDetails.dt_temp_Locked_Valuation_Report != null) && (ac_GrantDetails.dt_temp_Locked_Valuation_Report.Rows.Count > 0)))
                                    {
                                        grantDetails.gvSearch.BindGrid();
                                        grantDetails.hdnDeletedRecords.Value = string.Empty;
                                        grantDetails.gvSearch.hdnIsDeleted.Value = string.Empty;
                                    }

                                    break;
                            }
                            break;

                        case "btnGDSearch":
                            grantDetails.h4ViewAddEditGV.Style.Add("display", "none");

                            if (n_Result.Equals(0))
                            {
                                grantDetails.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                grantDetails.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblGDErrorSearch", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                            }

                            else
                            {
                                grantDetails.gvSearch.btnGDDelete.Visible = grantDetails.gvSearch.gv.Rows.Count == 0 ? false : true;
                                grantDetails.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "none");
                            }

                            break;

                        case "btnGDClearFilter":
                            grantDetails.h4ViewAddEditGV.Style.Add("display", "none");
                            grantDetails.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "none");
                            break;

                        case "btnGDAddGrant":

                            EnableDisableControls(grantDetails, s_ButtonID);

                            FillSchemeDropDown(grantDetails, valuationServiceClient);

                            grantDetails.divVestExercisePopulateOne.Style.Add("display", "normal");
                            grantDetails.txtEnterSchemeName.Visible = false;
                            grantDetails.btnGDReset.Visible = false;
                            grantDetails.lblMsgMP.Visible = false;
                            grantDetails.lblMsgRFIR.Visible = false;
                            grantDetails.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "none");
                            grantDetails.h4ViewAddEditGV.Style.Add("display", "normal");
                            grantDetails.gvVestExercisePopulate.Visible = false;
                            grantDetails.gvUpdateFairParams.Visible = false;
                            grantDetails.trUpdateParamsOrFair.Style.Add("display", "none");
                            grantDetails.btnAddGrantAddMoreGrants.Visible = false;
                            grantDetails.btnAddGrantSaveContinue.Visible = false;
                            grantDetails.hdnhideTabs.Value = "1";
                            ac_GrantDetails.dt_GrantRegMaster = null;
                            ac_GrantDetails.dt_GrantRegDetails = null;

                            grantDetails.gvSearch.chkGDGrantID.ClearSelection();
                            grantDetails.gvSearch.chkGDSchemeName.ClearSelection();
                            grantDetails.gvSearch.chkGDCurrency.ClearSelection();
                            grantDetails.gvSearch.chkGDReportStatus.ClearSelection();

                            grantDetails.gvSearch.txtGDGrantID.Text = grantDetails.gvSearch.txtGDSchemeName.Text = grantDetails.gvSearch.txtGDCurrency.Text = grantDetails.gvSearch.txtGDReportStatus.Text = "--- Please Select ---";
                            grantDetails.gvSearch.calGDFromDate.Value = grantDetails.gvSearch.calGDToDate.Value =
                            grantDetails.gvSearch.txtGDExercisePriceFrom.Text = grantDetails.gvSearch.txtVRGrpNumFrom.Text =
                            grantDetails.gvSearch.txtGDExercisePriceTo.Text = grantDetails.gvSearch.txtVRGrpNumTo.Text = string.Empty;

                            grantDetails.gvSearch.btnGDClearFilter.Visible = false;

                            ac_GrantDetails.dt_FileUploads = null;
                            ac_GrantDetails.dt_gvFileUploads = null;
                            grantDetails.trgvFileUpload.Style.Add("display", "none");

                            break;

                        case "ddlAddGrantSchemeName":
                            grantDetails.h4ViewAddEditGV.Style.Add("display", "block");
                            grantDetails.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "none");
                            grantDetails.txtAddGrantGrantID.Focus();
                            break;

                        case "EnableDisableControls":
                            grantDetails.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "none");
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Edit Functionality
        /// <summary>
        /// This Method is used to Perform Edit Functionality Of Grant Details Page
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="s_AGRMID">s_AGRMID</param>
        /// <param name="s_SessionGrantID">s_SessionGrantID</param>
        /// <param name="s_HdnAction">s_HdnAction</param>
        internal void ShowEditSection(GrantDetails grantDetails, string s_AGRMID, string s_SessionGrantID, string s_HdnAction)
        {
            try
            {
                grantDetails.lblMsgMP.Visible = false;
                grantDetails.lblMsgRFIR.Visible = false;

                ac_GrantDetails.dt_FileUploads = null;
                ac_GrantDetails.dt_gvFileUploads = null;
                grantDetails.trgvFileUpload.Style.Add("display", "none");

                using (GrantDetailsEditDeleteModel grantDetailsEditDeleteModel = new GrantDetailsEditDeleteModel())
                {
                    grantDetailsEditDeleteModel.ShowEditSection(grantDetails, s_AGRMID, s_SessionGrantID, s_HdnAction);

                    if (grantDetails.chkAddGrantExPrcLnkMultDates.Checked)
                        ac_GrantDetails.n_Mult_Exer_Period_Value = Convert.ToInt32(grantDetails.txtAddGrantExPrcFirst.Text);
                }

                if (s_HdnAction.Equals("U"))
                {
                    PopulateVestDetails(grantDetails);

                    AddDatatToDataTable(grantDetails, "");

                    grantDetails.hdnhideTabs.Value = "2";
                }

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    ShowMsgForMissingPrices(grantDetails, valuationServiceClient);
                }

                grantDetails.UCUpdateGeneralParams.gvUGPGrantDetails.DataSource = ac_GrantDetails.dt_ViewDataEntered;
                grantDetails.UCUpdateGeneralParams.gvUGPGrantDetails.DataBind();

                grantDetails.btnGDReset.Visible = true;
                grantDetails.btnAddGrantSaveContinue.Enabled = true;
                grantDetails.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "none");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to show message for missing prices dates
        /// </summary>
        /// <param name="grantDetails">GrantDetails page object</param>
        /// <param name="valuationServiceClient">ValuationServiceClient</param>
        private void ShowMsgForMissingPrices(GrantDetails grantDetails, ValuationServiceClient valuationServiceClient)
        {
            using (DataTable dt_MissingDates = CommonModel.GetMissingVolatilityDates(grantDetails.txtAddGrantGrantID.Text, Convert.ToInt32(ac_GrantDetails.dt_GrantRegDetails.Rows[ac_GrantDetails.dt_GrantRegDetails.Rows.Count - 1]["VPD_VESTING_PERIOD_ID"]), userSessionInfo.ACC_CompanyName, valuationServiceClient, valuationProperties))
            {
                if (dt_MissingDates != null && dt_MissingDates.Rows.Count > 0)
                {
                    grantDetails.UCUpdateGeneralParams.lblMissingVolatility.Text = valuationServiceClient.GetValuation_L10N("lblGDMissingVolatility", CommonConstantModel.s_GrantDetails, CommonConstantModel.s_ValuationL10);
                }
            }
        }
        #endregion

        #region Redirected from Valuation Report page
        /// <summary>
        /// This Method is used when Redirected from Valuation Report page
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        public void RedirectFromValuationRep(GrantDetails grantDetails)
        {
            string s_GrantID, s_ChildPageName = string.Empty;

            ac_GrantDetails.dt_ViewDataEntered = null;

            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                s_GrantID = _gvUserControlModel.ac_SearchGrantDetails.s_GrantID;
                s_ChildPageName = _gvUserControlModel.ac_SearchGrantDetails.s_ChildPageName;

                if (!string.IsNullOrEmpty(s_GrantID))
                {
                    grantDetails.txtAddGrantGrantDate.Text = ac_GrantDetails.dt_GetGrantDetails.Select("[Grant Registration ID] = '" + s_GrantID + "'")[0]["Grant Date"].ToString();
                    grantDetails.txtAddGrantGrantID.Text = ac_GrantDetails.dt_GetGrantDetails.Select("[Grant Registration ID] = '" + s_GrantID + "'")[0]["Grant Registration ID"].ToString();
                    grantDetails.txtAddGrantExercisePrice.Text = ac_GrantDetails.dt_GetGrantDetails.Select("[Grant Registration ID] = '" + s_GrantID + "'")[0]["Exercise Price"].ToString();
                    grantDetails.ddlAddGrantSchemeName.SelectedValue = ac_GrantDetails.dt_GetGrantDetails.Select("[Grant Registration ID] = '" + s_GrantID + "'")[0]["Scheme Title"].ToString();
                    grantDetails.hdnAccordionIndex.Value = "1";

                    if (s_ChildPageName.Equals("GrantDetails"))
                    {
                        //using (Button btnValuationParams = (Button)grantDetails.ctrValuationParams.FindControl("btnGVPUpdateForCurrGrant"))
                        //{
                        //    btnValuationParams.Visible = false;
                        //    grantDetails.btnAddGrantCancel.Visible = false;
                        //}
                        grantDetails.btnBackToValParams.Visible = true;
                        grantDetails.btnAddGrantSaveContinue.Visible = false;
                    }
                    else
                    {
                        grantDetails.hdnTabActiveIndex.Value = "1";
                        grantDetails.btnAddGrantCancel.Visible = false;
                    }

                    ShowEditSection(grantDetails, ac_GrantDetails.dt_GetGrantDetails.Select("[Grant Registration ID] = '" + s_GrantID + "'")[0]["AGRMID"].ToString(), string.Empty, string.Empty);

                    grantDetails.hdnAccordionIndex.Value = "1";
                    grantDetails.btnBackToValParams.Visible = true;
                    grantDetails.btnAddGrantSaveContinue.Visible = false;
                    grantDetails.btnAddGrantPopulateVestDetails.Visible = false;
                    grantDetails.UCUpdateGeneralParams.btnViewValuationReport.Visible = false;
                    _gvUserControlModel.ac_SearchGrantDetails.s_GrantID = string.Empty;
                }
            }

        }
        #endregion

        #region ddlAddGrantVestingParams Dropdown Index Change Event
        /// <summary>
        /// The ddlAddGrantVestingParams Dropdown Index Change
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void ddlAddGrantVestingParams_SelectedIndexChanged(GrantDetails grantDetails)
        {
            try
            {
                if (grantDetails.ddlAddGrantVestingParams.SelectedValue.Equals("Performance Based"))
                {
                    grantDetails.trMrktLnk.Style.Add("display", "block");
                    grantDetails.rdbtnExerPeriodYears.Focus();
                }
                else
                    grantDetails.trMrktLnk.Style.Add("display", "none");
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Grant Date TextBox Change Event

        /// <summary>
        /// This is txtAddGrantGrantDate Grant Date TextBox Change Event
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void txtAddGrantGrantDate_TextChanged(GrantDetails grantDetails)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    if (!grantDetails.txtAddGrantGrantDate.Text.Equals("dd/mmm/yyyy"))
                    {
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.SEN_CompanyTitle = userSessionInfo.ACC_CompanyTitle;
                        valuationProperties.PageName = CommonConstantModel.s_GrantDetails;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                        valuationProperties.PopulateControls = "GETMPANDRFIR";
                        valuationProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;

                        valuationProperties.Grant_Date = Convert.ToDateTime(grantDetails.txtAddGrantGrantDate.Text).ToString("yyyy-MM-dd");

                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        DataTable dt_lblShowMsg = (DataTable)valuationCRUDProperties.dt_Result;

                        if (dt_lblShowMsg != null && dt_lblShowMsg.Rows.Count > 0)
                        {
                            grantDetails.lblMsgMP.ForeColor = Convert.ToString(dt_lblShowMsg.Rows[0][2].ToString()).Equals("0.00") ? Color.Red : Color.Blue;
                            grantDetails.lblMsgRFIR.ForeColor = !string.IsNullOrEmpty(dt_lblShowMsg.Rows[0][1].ToString()) ? Color.Red : Color.Blue;

                            grantDetails.lblMsgMP.Text = Convert.ToString(dt_lblShowMsg.Rows[0][0].ToString());
                            grantDetails.lblMsgRFIR.Text = Convert.ToString(dt_lblShowMsg.Rows[0][1].ToString());

                            grantDetails.lblMsgMP.Visible = true;
                            grantDetails.lblMsgRFIR.Visible = true;
                            grantDetails.trgvVestExercisePopulate.Style.Add("display", "none");
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Enable or Disable Controls
        /// <summary>
        /// This Method is used to Enable or Disable Controls.
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="s_Sender">s_Sender(Buttons and Dropdowns)</param>
        internal void EnableDisableControls(GrantDetails grantDetails, string s_Sender)
        {
            try
            {
                if (s_Sender.Equals("btnAddGrantSaveContinue") || s_Sender.Equals("ddlGVPGrantList") || s_Sender.Equals("ddlAddGrantSchemeName") || s_Sender.Equals("hdnBtnUpdate"))
                {
                    grantDetails.UCUpdateGeneralParams.lnkMarketPrice.Enabled = grantDetails.hdnAction.Value.Equals("U") || s_Sender.Equals("btnAddGrantSaveContinue") ? true : false;
                    grantDetails.UCUpdateGeneralParams.lnkDividend.Enabled = grantDetails.hdnAction.Value.Equals("U") || s_Sender.Equals("btnAddGrantSaveContinue") ? true : false;
                    grantDetails.UCUpdateGeneralParams.lnkPeerCompany.Enabled = grantDetails.hdnAction.Value.Equals("U") || s_Sender.Equals("btnAddGrantSaveContinue") ? true : false;
                    grantDetails.UCUpdateGeneralParams.lnkCorpAction.Enabled = grantDetails.hdnAction.Value.Equals("U") || s_Sender.Equals("btnAddGrantSaveContinue") ? true : false;
                    grantDetails.UCUpdateGeneralParams.btnViewValuationReport.Enabled = grantDetails.hdnAction.Value.Equals("U") || s_Sender.Equals("btnAddGrantSaveContinue") ? true : false;
                }

                else
                {
                    grantDetails.UCUpdateGeneralParams.lnkMarketPrice.Enabled = false;
                    grantDetails.UCUpdateGeneralParams.lnkDividend.Enabled = false;
                    grantDetails.UCUpdateGeneralParams.lnkPeerCompany.Enabled = false;
                    grantDetails.UCUpdateGeneralParams.lnkCorpAction.Enabled = false;
                    grantDetails.UCUpdateGeneralParams.btnViewValuationReport.Enabled = false;
                }

                grantDetails.ddlAddGrantSchemeName.Enabled = grantDetails.hdnAction.Value.Equals("A") || string.IsNullOrEmpty(grantDetails.hdnAction.Value) || grantDetails.hdnAction.Value.Equals("S") ? true : false;
                grantDetails.txtAddGrantGrantID.Enabled = grantDetails.hdnAction.Value.Equals("A") || string.IsNullOrEmpty(grantDetails.hdnAction.Value) || grantDetails.hdnAction.Value.Equals("S") ? true : false;
                grantDetails.txtEnterSchemeName.Enabled = grantDetails.hdnAction.Value.Equals("A") || string.IsNullOrEmpty(grantDetails.hdnAction.Value) || grantDetails.hdnAction.Value.Equals("S") ? true : false;
            }
            catch
            {
                throw;
            }
        }
        #endregion

        /// <summary>
        /// The File Upload for Grant
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        internal void btnAddGrantFileUpload_Click(GrantDetails grantDetails)
        {
            try
            {
                if (ac_GrantDetails.dt_FileUploads == null)
                    ac_GrantDetails.dt_FileUploads = new DataTable();

                if (ac_GrantDetails.dt_FileUploads.Columns.Count == 0)
                {
                    ac_GrantDetails.dt_FileUploads.Columns.Add("GrantID", typeof(string));
                    ac_GrantDetails.dt_FileUploads.Columns.Add("FileName", typeof(string));
                    ac_GrantDetails.dt_FileUploads.Columns.Add("Remark", typeof(string));
                }

                if (grantDetails.FileUploadControlOne.HasFile)
                {

                    string s_FileName = grantDetails.txtAddGrantGrantID.Text + "_" + grantDetails.FileUploadControlOne.FileName;

                    if (ac_GrantDetails.dt_FileUploads.Select("FileName = '" + s_FileName + "'").Count() == 0)
                    {
                        ac_GrantDetails.dt_FileUploads.Rows.Add(grantDetails.txtAddGrantGrantID.Text, grantDetails.txtAddGrantGrantID.Text + "_" + grantDetails.FileUploadControlOne.FileName, grantDetails.txtAddGrantCommentBox.Text);

                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        string s_MainFolderPath = grantDetails.Server.MapPath("~/Uploads/");
                        string s_CmpNameFolderPath = grantDetails.Server.MapPath("~/Uploads/" + valuationProperties.SEN_CompanyName + "/");
                        string s_FilePath = grantDetails.Server.MapPath("~/Uploads/" + valuationProperties.SEN_CompanyName + "/" + grantDetails.txtAddGrantGrantID.Text + "_" + Path.GetFileName(grantDetails.FileUploadControlOne.FileName));

                        if (grantDetails.FileUploadControlOne.HasFile)
                        {
                            if (!Directory.Exists(s_CmpNameFolderPath))
                            {
                                Directory.CreateDirectory(s_CmpNameFolderPath);
                            }

                            if (!File.Exists(s_FilePath) && Directory.Exists(s_CmpNameFolderPath))
                            {
                                grantDetails.FileUploadControlOne.SaveAs(s_FilePath);
                            }
                        }

                        if (ac_GrantDetails.dt_gvFileUploads == null)
                            ac_GrantDetails.dt_gvFileUploads = new DataTable();

                        if (ac_GrantDetails.dt_gvFileUploads.Columns.Count == 0)
                        {
                            ac_GrantDetails.dt_gvFileUploads.Columns.Add("Document Uploaded", typeof(string));
                        }

                        ac_GrantDetails.dt_gvFileUploads.Rows.Add(grantDetails.txtAddGrantGrantID.Text + "_" + grantDetails.FileUploadControlOne.FileName);

                        grantDetails.trgvFileUpload.Style.Add("display", "normal");

                        grantDetails.gvFileUpload.DataSource = ac_GrantDetails.dt_gvFileUploads;
                        grantDetails.gvFileUpload.DataBind();

                        grantDetails.lblAddGrantCommentBox.Focus();

                        using (GrantDetailsEditDeleteModel grantDetailsEditDeleteModel = new GrantDetailsEditDeleteModel())
                        {
                            if (grantDetails.rdbtnUpdateParams.SelectedValue.Equals("P") || grantDetails.rdbtnUpdateParams.SelectedValue.Equals("F"))
                            {
                                grantDetailsEditDeleteModel.BindUpdateParamsGridOnEdit(grantDetails, "", grantDetails.UCUpdateGeneralParams.hdnARMID_ToEdit.Value);
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Row Data Bound Event of gvFileUpload GridView
        /// </summary>
        /// <param name="e">e</param>
        internal void gvFileUpload_RowDataBound(GridViewRowEventArgs e)
        {
            try
            {
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The Row Deleting Event of gvFileUpload GridView
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="e">e</param>
        internal void gvFileUpload_RowDeleting(GrantDetails grantDetails, GridViewDeleteEventArgs e)
        {
            try
            {
                ac_GrantDetails.dt_gvFileUploads.Rows[e.RowIndex].Delete();
                ac_GrantDetails.dt_FileUploads.Rows[e.RowIndex].Delete();

                if (ac_GrantDetails.dt_gvFileUploads.Rows.Count == 0 && grantDetails.hdnAction.Value != "U")
                {
                    using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                    {
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                        valuationProperties.PageName = CommonConstantModel.s_GrantDetails;
                        valuationProperties.dt_DBFileUploads = ac_GrantDetails.dt_FileUploads;
                        valuationProperties.dt_DBFileUploads.TableName = "DT";
                        valuationProperties.Document_Path = grantDetails.txtAddGrantGrantID.Text;
                        valuationProperties.Document_VersionNo = 0;

                        valuationProperties.PopulateControls = "DocumentUpload";
                        valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                        valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        valuationProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                        valuationProperties.Action = "D";

                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        grantDetails.trgvFileUpload.Style.Add("display", "none");
                    }
                }

                grantDetails.gvFileUpload.DataSource = ac_GrantDetails.dt_gvFileUploads;
                grantDetails.gvFileUpload.DataBind();

                using (GrantDetailsEditDeleteModel grantDetailsEditDeleteModel = new GrantDetailsEditDeleteModel())
                {
                    if (grantDetails.rdbtnUpdateParams.SelectedValue.Equals("P") || grantDetails.rdbtnUpdateParams.SelectedValue.Equals("F"))
                    {
                        grantDetailsEditDeleteModel.BindUpdateParamsGridOnEdit(grantDetails, "", grantDetails.UCUpdateGeneralParams.hdnARMID_ToEdit.Value);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to get vest details
        /// </summary>
        /// <param name="s_GrantRegID">UCGrantDetails page object</param>
        public string GetVestWiseDetails(string s_GrantRegID)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {

                valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                valuationProperties.Grant_ID = s_GrantRegID;
                valuationProperties.GET_DATA_TYPE = "VESTWISE";

                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                valuationCRUDProperties.ds_Result.Tables[0].TableName = "dt_VestWiseDetails";
                return DataSetToJSON(valuationCRUDProperties.ds_Result);
            }
        }

        /// <summary>
        /// This method is used to Serialize Json object
        /// </summary>
        /// <param name="dataSet">Dataset used to </param>
        /// <returns>string</returns>
        private string DataSetToJSON(DataSet dataSet)
        {
            JavaScriptSerializer json = new JavaScriptSerializer();
            Dictionary<string, object> dictionary = new Dictionary<string, object>();

            foreach (DataTable dt in dataSet.Tables)
            {
                object[] arr = new object[dt.Rows.Count + 1];

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    arr[i] = dt.Rows[i].ItemArray;
                }

                dictionary.Add(dt.TableName, arr);
            }

            return json.Serialize(dictionary);
        }
        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~GrantDetailsModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}