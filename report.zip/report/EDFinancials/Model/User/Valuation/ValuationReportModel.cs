﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation.UserControl_Model;
using EDFinancials.View.User.Valuation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class ValuationReportModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public ValuationReportModel()
        {
            if(ac_ValuationReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationReport);
                ac_ValuationReport = (CommonModel.AC_ValuationReport)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationReport];
            }
        }

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="valuationReportUI">View.User.Valuation.DividendSetup</param>
        internal void ReadL10N_UI(ValuationReport valuationReportUI)
        {
            try
            {
                using(ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using(DataTable dt_valuationL10N_UI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if((dt_valuationL10N_UI != null) && (dt_valuationL10N_UI.Rows.Count > 0))
                        {
                            ac_ValuationReport.dt_Valuation_Report_UI_Text = dt_valuationL10N_UI;

                            valuationReportUI.lblVRMHeader.Text = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblVRMHeader'"))[0]["LabelName"]);

                            ac_ValuationReport.s_ParametersDetails = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblGridParametersDetails'"))[0]["LabelName"]);
                            ac_ValuationReport.s_GrantDetails = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblGridGrantDetails'"))[0]["LabelName"]);
                            ac_ValuationReport.s_VestingDetails = Convert.ToString((dt_valuationL10N_UI.Select("LabelID = 'lblGridVestingDetails'"))[0]["LabelName"]);
                            ac_ValuationReport.s_QueryStringParams = string.Empty;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind selected grants
        /// </summary>
        /// <param name="valuationReportUI">Page object</param>
        public void BindCountryNameDataTable(ValuationReport valuationReportUI)
        {
            using(AdminServiceClient adminServiceClient = new AdminServiceClient())
            {
                adminProperties.CMID = 0;
                adminProperties.IsActive =  0;
                adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCountries, "Read", adminProperties);
                ac_ValuationReport.dt_CountryNames = adminCRUDProperties.dt_Result;
          
            }
        }

        /// <summary>
        ///  Method to check employee role privileges
        /// </summary>
        /// <param name="valuationReportUI">Page object</param>
        public void CheckEmployeeRolePriviledges(ValuationReport valuationReportUI)
        {
            userSessionInfo = SessionContext.GetUserSessionInfoValues();
            GenericProperties genericProperties = new GenericProperties();
            genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
            genericProperties.PageName = CommonConstantModel.s_MnuValuationReport;
            genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
            using(DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
            {
                if(dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                {
                    foreach(DataRow rowPriviledge in dt_RolePerviledges.Rows)
                    {
                        switch(Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                        {
                            case "EDIT":
                                ac_ValuationReport.b_IsEditEnabled = true;
                                break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// This method is used to bind selected grants
        /// </summary>
        /// <param name="valuationReportUI">Page object</param>
        public void BindSelectedGrants(ValuationReport valuationReportUI)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(valuationReportUI.Session["StepNumber"])))
            {
                valuationReportUI.Session["StepNumber"] = "";
                ac_ValuationReport.s_SelectedGrants = string.Empty;
            }

            using(gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                if (valuationReportUI.hdnIsMEDLSelected.Value.Equals("Set"))
                {
                    using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                    {
                        valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                        valuationProperties.Operation_Param = CommonConstantModel.s_ModEDL;

                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report = valuationCRUDProperties.ds_Result.Tables[0];
                        _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Locked_Valuation_Report = valuationCRUDProperties.ds_Result.Tables[1];
                    }
                }
                
                valuationReportUI.hdnStepNumber.Value = (string.IsNullOrEmpty(ac_ValuationReport.s_StepNumber) || ac_ValuationReport.s_StepNumber.Equals("0")) ? _gvUserControlModel.ac_SearchGrantDetails.s_StepNumber : ac_ValuationReport.s_StepNumber;

                if (valuationReportUI.hdnStepNumber.Value.Equals("5"))
                {
                    valuationReportUI.hdnCurrentTab.Value = string.Empty;
                }

                ac_ValuationReport.s_SelectedGrants = string.IsNullOrEmpty(_gvUserControlModel.ac_SearchGrantDetails.s_SelectedGrants) ? ac_ValuationReport.s_SelectedGrants : _gvUserControlModel.ac_SearchGrantDetails.s_SelectedGrants;
                ac_ValuationReport.dt_temp_Unlocked_Valuation_Report = _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report;
                ac_ValuationReport.dt_temp_Locked_Valuation_Report = _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Locked_Valuation_Report;
            }

            if(!string.IsNullOrEmpty(ac_ValuationReport.s_ChildPageName))
            {
                valuationReportUI.CompareGrants.RerdirectedFromValuationParam();

            }
            ac_ValuationReport.s_ChildPageName = string.Empty;
            if(!string.IsNullOrEmpty(ac_ValuationReport.s_SelectedGrants))
            {
                string temp = string.Empty;

                foreach(var item in ac_ValuationReport.s_SelectedGrants.TrimStart(',').Split(','))
                {
                    temp = string.IsNullOrEmpty(temp) ? "AGRMID = '" + item + "'" : temp + " OR AGRMID = '" + item + "'";
                }


                DataRow[] dataRowTemp = ac_ValuationReport.dt_temp_Locked_Valuation_Report != null && ac_ValuationReport.dt_temp_Locked_Valuation_Report.Rows.Count > 0 ? ac_ValuationReport.dt_temp_Locked_Valuation_Report.Select(temp) : null; 

                try
                {
                    if(dataRowTemp != null  && dataRowTemp.Count() > 0)
                    {
                        string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
                        string s_GroupNumber = Convert.ToString(ac_ValuationReport.dt_temp_Locked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]);

                        #region bind common GridView for selected Grants
                        DataView view = new DataView(ac_ValuationReport.dt_temp_Locked_Valuation_Report.Select(temp).CopyToDataTable());

                        if(view.Count > 0)
                        {
                            var groupedRecords = view.ToTable("DT", true, new string[] { "Grant Registration ID", "Grant Date", "Scheme Title", "Exercise Price", "Currency", "Intrinsic Value", "Fair Value" }).Copy()
                                                .AsEnumerable().GroupBy(item => item.Field<string>("Grant Registration ID"));
                            var shortestRecords = groupedRecords.Select(grp => grp.OrderBy(item => item.Field<string>("Grant Date")).First());
                            valuationReportUI.SelectedGrants.gvSelectedGrants.DataSource = shortestRecords.CopyToDataTable();
                            valuationReportUI.SelectedGrants.gvSelectedGrants.DataBind();
                        }

                        view.Dispose();
                        #endregion

                        if(string.IsNullOrEmpty(valuationReportUI.FinalReport.hdnGroupNo.Value) && ac_ValuationReport.dt_VersionDetails != null && ac_ValuationReport.dt_VersionDetails.Rows.Count > 0)
                        {
                            DataRow[] dr = ac_ValuationReport.dt_VersionDetails.Select("GROUP_ID = '" + s_GroupNumber + "'");

                            if(dr.Count() > 0)
                            {
                                DataView dv_VersionDetails = new DataView(dr.CopyToDataTable());

                                using(System.Data.DataTable dt = dv_VersionDetails.ToTable("DT", true, "Document Name", "Signed Copy", "Version Number", "GROUP_ID", "Action").Copy())
                                {
                                    valuationReportUI.FinalReport.gvVersionDetails.DataSource = dt;
                                    valuationReportUI.FinalReport.gvVersionDetails.DataBind();
                                }
                            }
                        }

                        using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                        {
                            valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                            valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                            valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            valuationProperties.Action = "V";
                            valuationProperties.Step = "SAVE_STEP_NUMBER_OR_COMMENT";
                            valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                            
                            if (valuationCRUDProperties.ds_Result != null && valuationCRUDProperties.ds_Result.Tables[0].Rows.Count != 0)
                            {
                                using (DataTable dt_FRCommentsDetails = new DataTable())
                                {
                                    dt_FRCommentsDetails.Columns.Add("User Type", typeof(string));
                                    dt_FRCommentsDetails.Columns.Add("Comment", typeof(string));
                                    dt_FRCommentsDetails.Columns.Add("Created On", typeof(string));
                                    DataRow[] dr_FRCommentsDetails = valuationCRUDProperties.ds_Result.Tables[0].Copy().Select("GROUP_ID = '" + Convert.ToString(ac_ValuationReport.dt_temp_Locked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]) + "'");

                                    foreach (DataRow perRow in dr_FRCommentsDetails)
                                    {
                                        DataRow dataRow = dt_FRCommentsDetails.NewRow();
                                        if (!string.IsNullOrEmpty(Convert.ToString(perRow["FINAL_REPORT_COMMENT"])))
                                        {
                                            dataRow["User Type"] = perRow["FINAL_REPORT_IS_REV_USR"].Equals(1) ? "User" : "Reviewer";
                                            dataRow["Comment"] = perRow["FINAL_REPORT_COMMENT"];
                                            dataRow["Created On"] = perRow["UPDATED_ON"];
                                            dt_FRCommentsDetails.Rows.Add(dataRow);
                                        }
                                    }

                                    valuationReportUI.FinalReport.gvFRCommentDetails.DataSource = dt_FRCommentsDetails;
                                    valuationReportUI.FinalReport.gvFRCommentDetails.DataBind();
                                }
                            }
                        }

                        valuationReportUI.FinalReport.trSendToClient.Visible = false;
                        valuationReportUI.FinalReport.trDisapprove.Visible = false;
                        valuationReportUI.FinalReport.tblApproved.Visible = false;
                        valuationReportUI.FinalReport.tblVersionGrid.Visible = true;
                        valuationReportUI.FinalReport.tblUnlockGrants.Visible = true;
                    }
                    else
                    {
                        string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
                        string s_GroupNumber = Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]);

                        if(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report != null && !string.IsNullOrEmpty(Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select(temp)[0]["TEMPLATE_NAME"])))
                        {
                            valuationReportUI.DownloadReport.lblSelectedTemplateName.Text = Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select(temp)[0]["TEMPLATE_NAME"]);
                            valuationReportUI.SelectTemplate.ddlTemplateNames.SelectedIndex = valuationReportUI.SelectTemplate.ddlTemplateNames.Items.IndexOf(valuationReportUI.SelectTemplate.ddlTemplateNames.Items.FindByText(Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select(temp)[0]["TEMPLATE_NAME"])));
                        }
                        else
                        {
                            try
                            {
                                valuationReportUI.DownloadReport.lblSelectedTemplateName.Text = valuationReportUI.SelectTemplate.ddlTemplateNames.SelectedItem.Text;

                            }
                            catch
                            {
								// Do Nothing
                            }
                        }
                        #region hide or show tr and bind Version GridView on Tab-5(Final Report)
                        if(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report != null && ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select(temp)[0]["IS_SENT_OR_APPROVED_BY_CLIENT"].Equals(2))
                        {
                            valuationReportUI.FinalReport.trSendToClient.Visible = false;
                            valuationReportUI.FinalReport.trDisapprove.Visible = false;
                            valuationReportUI.FinalReport.tblApproved.Visible = true;
                            valuationReportUI.FinalReport.tblVersionGrid.Visible = true;
                            valuationReportUI.FinalReport.tblUnlockGrants.Visible = false;
                        }
                        else if(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report != null && ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select(temp)[0]["IS_SENT_OR_APPROVED_BY_CLIENT"].Equals(1))
                        {
                            valuationReportUI.FinalReport.trSendToClient.Visible = false;
                            valuationReportUI.FinalReport.trDisapprove.Visible = true;
                            valuationReportUI.FinalReport.tblApproved.Visible = false;
                            valuationReportUI.FinalReport.tblVersionGrid.Visible = false;
                            valuationReportUI.FinalReport.tblUnlockGrants.Visible = false;
                        }
                        else if (ac_ValuationReport.dt_temp_Unlocked_Valuation_Report != null && ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select(temp)[0]["IS_SENT_OR_APPROVED_BY_CLIENT"].Equals(0))
                        {
                            valuationReportUI.FinalReport.trSendToClient.Visible = true;
                            valuationReportUI.FinalReport.tblVersionGrid.Visible = false;
                        }

                        if(string.IsNullOrEmpty(valuationReportUI.FinalReport.hdnGroupNo.Value) && ac_ValuationReport.dt_VersionDetails != null && ac_ValuationReport.dt_VersionDetails.Rows.Count > 0)
                        {
                            DataRow[] dr = ac_ValuationReport.dt_VersionDetails.Select("GROUP_ID = '" + s_GroupNumber + "'");

                            if(dr.Count() > 0)
                            {
                                DataView dv_VersionDetails = new DataView(dr.CopyToDataTable());

                                using(System.Data.DataTable dt = dv_VersionDetails.ToTable("DT", true, "Document Name", "Version Number", "GROUP_ID", "Action").Copy())
                                {
                                    valuationReportUI.FinalReport.gvVersionDetails.DataSource = dt;
                                    valuationReportUI.FinalReport.gvVersionDetails.DataBind();
                                }
                            }
                        }

                        #endregion

                        #region bind common GridView for selected Grants
                        DataView view = new DataView(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select(temp).CopyToDataTable());

                        if(view.Count > 0)
                        {
                            var groupedRecords = view.ToTable("DT", true, new string[] { "Grant Registration ID", "Grant Date", "Scheme Title", "Exercise Price", "Currency", "Intrinsic Value", "Fair Value" }).Copy()
                                                .AsEnumerable().GroupBy(item => item.Field<string>("Grant Registration ID"));
                            var shortestRecords = groupedRecords.Select(grp => grp.OrderBy(item => item.Field<string>("Grant Date")).First());
                            valuationReportUI.SelectedGrants.gvSelectedGrants.DataSource = shortestRecords.CopyToDataTable();
                            valuationReportUI.SelectedGrants.gvSelectedGrants.DataBind();
                        }

                        view.Dispose();
                        #endregion

                        #region bind GridView on tab-4(Download Report and Workings)
                        using(ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                        {
                            valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                            valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                            valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            valuationProperties.Action = "V";
                            valuationProperties.Step = "SAVE_STEP_NUMBER_OR_COMMENT";
                            valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                            if(valuationCRUDProperties.ds_Result != null && valuationCRUDProperties.ds_Result.Tables[0].Rows.Count != 0)
                            {
                                DataTable dt_CommentsDetails = new DataTable();
                                dt_CommentsDetails.Columns.Add("User Type", typeof(string));
                                dt_CommentsDetails.Columns.Add("Comment", typeof(string));
                                dt_CommentsDetails.Columns.Add("Created On", typeof(string));
                                DataRow[] dr_CommentsDetails = valuationCRUDProperties.ds_Result.Tables[0].Copy().Select("GROUP_ID = '" + Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]) + "'");

                                foreach(DataRow perRow in dr_CommentsDetails)
                                {
                                    DataRow dataRow = dt_CommentsDetails.NewRow();
                                    if (!string.IsNullOrEmpty(Convert.ToString(perRow["DOWNLOAD_REP_WORK_COMMENT"])))
                                    {
                                    dataRow["User Type"] = perRow["DOWNLOAD_REP_WORK_IS_REV_USR"].Equals(1) ? "User" : "Reviewer";
                                    dataRow["Comment"] = perRow["DOWNLOAD_REP_WORK_COMMENT"];
                                    dataRow["Created On"] = perRow["UPDATED_ON"];
                                    dt_CommentsDetails.Rows.Add(dataRow);
                                }
                                }

                                valuationReportUI.DownloadReport.gvCommentsDetails.DataSource = dt_CommentsDetails;
                                valuationReportUI.DownloadReport.gvCommentsDetails.DataBind();
                                dt_CommentsDetails.Dispose();
                            }

                            if(valuationCRUDProperties.ds_Result != null && valuationCRUDProperties.ds_Result.Tables[1].Rows.Count != 0)
                            {
                                if(!string.IsNullOrEmpty(Convert.ToString(valuationCRUDProperties.ds_Result.Tables[1].Select(temp)[0]["IS_SEND_FOR_REVIEW"])))
                                {
                                    valuationReportUI.DownloadReport.lblCurrentStatus.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblRptWaitingApproval'"))[0]["LabelName"]);
                                }
                                else
                                {
                                    valuationReportUI.DownloadReport.lblCurrentStatus.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblRptInProcess'"))[0]["LabelName"]);
                                }
                            }
                        }
                        #endregion

                        #region
                        using(GenericServiceClient genericServiceClient = new GenericServiceClient())
                        {
                            valuationReportUI.DownloadReport.hdnQueryStringParams.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=1") + "&" + genericServiceClient.EncryptString("GrpNo=" + Convert.ToString(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"]))).Replace("+", "%2B").Replace("+", "%2B");
                        }
                        #endregion

                        if(valuationReportUI.SelectTemplate.hdnSTSaveContinue.Value == "Set")
                            valuationReportUI.DownloadReport.ctrSuccessErrorMessage.divMessegebox.Style.Add("display", "none");
                    }
                    GetMissingMarketPrices(valuationReportUI);
                }
                catch(Exception ex)
                {
                    throw ex;
                }

            }
        }

        /// <summary>
        /// This method in used to get missing market price dates
        /// </summary>
        /// <param name="valuationReportUI">ValuationReport page object</param>
        public void GetMissingMarketPrices(ValuationReport valuationReportUI)
        {
            string s_MissingPriceGrantID = string.Empty;

            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                if (ac_ValuationReport.dt_all_Grants != null && ac_ValuationReport.dt_all_Grants.Rows.Count > 0)
                {
                foreach (var item in ac_ValuationReport.s_SelectedGrants.TrimStart(',').Split(','))
                {
                    if (!string.IsNullOrEmpty(item))
                    {
                        string s_GrantRegID = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Grant Registration ID"].ToString(),
                               s_VestingPeriodID = "1";


                        using (System.Data.DataTable dt_MissingDates = CommonModel.GetMissingVolatilityDates(s_GrantRegID, Convert.ToInt32(s_VestingPeriodID), userSessionInfo.ACC_CompanyName, valuationServiceClient, valuationProperties))
                        {
                            if (dt_MissingDates != null && dt_MissingDates.Rows.Count > 0)
                            {
                                s_MissingPriceGrantID = string.IsNullOrEmpty(s_MissingPriceGrantID) ? "'" + s_GrantRegID + "'" : s_MissingPriceGrantID + ",'" + s_GrantRegID + "'";
                            }
                        }
                    }
                }
                valuationReportUI.DownloadReport.lblValMissingVolatilityDates.Text = string.IsNullOrEmpty(s_MissingPriceGrantID) ? string.Empty :
                                                                                 string.Format(valuationServiceClient.GetValuation_L10N("lblValMissingVolatilityDates", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10), s_MissingPriceGrantID);
            }
        }
        }

        /// <summary>
        /// This method is used to clear static variable data
        /// </summary>
        /// <param name="valuationReportUI">Page object</param>
        /// <param name="s_PriviousPage">Previous page name</param>
        /// <param name="s_IsSession">Session name</param>
        /// <param name="s_IsRedirectFromValParam">s_IsRedirectFromValParam</param>
        public void ClearStaticVariables(ValuationReport valuationReportUI, string s_PriviousPage, string s_IsSession, string s_IsRedirectFromValParam)
        {
            if(!string.IsNullOrEmpty(s_IsSession))
            {
                ac_ValuationReport.s_StepNumber = "0";
            }
            else
            {
                using(gvUserControlModel o_gvUserControlModel = new gvUserControlModel())
                {
                    ac_ValuationReport.s_SelectedGrants = string.IsNullOrEmpty(ac_ValuationReport.s_SelectedGrants) ? o_gvUserControlModel.ac_SearchGrantDetails.s_SelectedGrants : ac_ValuationReport.s_SelectedGrants;
                    ac_ValuationReport.s_StepNumber = string.IsNullOrEmpty(ac_ValuationReport.s_StepNumber) || ac_ValuationReport.s_StepNumber.Equals("0") ? o_gvUserControlModel.ac_SearchGrantDetails.s_StepNumber : ac_ValuationReport.s_StepNumber;
                    o_gvUserControlModel.ac_SearchGrantDetails.n_PageIndex = o_gvUserControlModel.ac_SearchGrantDetails.n_PageIndex_Locked = 1;
                    o_gvUserControlModel.ac_SearchGrantDetails.n_PageSize = o_gvUserControlModel.ac_SearchGrantDetails.n_PageSize_Locked = 10;
                }
                ac_ValuationReport.s_SelectedGrants = (s_PriviousPage.Contains("ValuationParameters.aspx")) && !string.IsNullOrEmpty(ac_ValuationReport.s_ChildPageName) && !string.IsNullOrEmpty(ac_ValuationReport.s_SelectedGrants) ? ac_ValuationReport.s_SelectedGrants : string.Empty;
                ac_ValuationReport.s_StepNumber = (s_PriviousPage.Contains("ValuationParameters.aspx")) && !string.IsNullOrEmpty(ac_ValuationReport.s_ChildPageName) && !string.IsNullOrEmpty(ac_ValuationReport.s_StepNumber) ? Convert.ToString(valuationReportUI.Session["CurrentTabIndex"]) : "0";
                ac_ValuationReport.ds_SelectedDataTables = (s_PriviousPage.Contains("ValuationParameters.aspx")) && !string.IsNullOrEmpty(ac_ValuationReport.s_ChildPageName) ? ac_ValuationReport.ds_SelectedDataTables : new DataSet();
                ac_ValuationReport.s_CompareGrantID = string.Empty;
            }

            ac_ValuationReport.s_CompareGrantID = string.Empty;
            valuationReportUI.hdnCurrentTab.Value = string.IsNullOrEmpty(Convert.ToString(valuationReportUI.Session["CurrentTabIndex"])) ? "" : "1";
            valuationReportUI.Session["CurrentTabIndex"] = string.Empty;

            if (string.IsNullOrEmpty(s_IsRedirectFromValParam))
            {
                ac_ValuationReport.s_SelectedGrants = string.Empty;
                ac_ValuationReport.s_StepNumber = string.Empty;
                valuationReportUI.hdnCurrentTab.Value = string.Empty;
            }
            
        }

        /// <summary>
        /// This method is used to get vest details
        /// </summary>
        /// <param name="s_GrantRegID">UCGrantDetails page object</param>
        public string GetVestWiseDetails(string s_GrantRegID)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {

                valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                valuationProperties.Grant_ID = s_GrantRegID;
                valuationProperties.GET_DATA_TYPE = "VESTWISE";
                
                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                valuationCRUDProperties.ds_Result.Tables[0].TableName = "dt_VestWiseDetails";
                return DataSetToJSON(valuationCRUDProperties.ds_Result);
            }
        }

        /// <summary>
        /// This method is used to Serialize Json object
        /// </summary>
        /// <param name="dataSet">Dataset used to </param>
        /// <returns>string</returns>
        private string DataSetToJSON(DataSet dataSet)
        {
            JavaScriptSerializer json = new JavaScriptSerializer();
            Dictionary<string, object> dictionary = new Dictionary<string, object>();

            foreach (DataTable dt in dataSet.Tables)
            {
                object[] arr = new object[dt.Rows.Count + 1];

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    arr[i] = dt.Rows[i].ItemArray;
                }

                dictionary.Add(dt.TableName, arr);
            }

            return json.Serialize(dictionary);
        }

        #region Destructor
        /// <summary>
        /// Destructor for ValuationReportModel.
        /// </summary>
        ~ValuationReportModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members

        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// Dispose method for ValuationReportModel
        /// </summary>
        /// <param name="disposing">dispose status</param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion

        /// <summary>
        /// This method is used to Clear Checkboxlist Selection on First Tab if it is redirected from Modification/EDL tab
        /// </summary>
        /// <param name="valuationReport">valuationReport Page Object</param>
        internal void ClearSelection(ValuationReport valuationReport)
        {
            try
            {
                #region Clear Checkboxlist Selection on First Tab if it is redirected from Modification/EDL tab
                    valuationReport.gvGrantDetails.chkGDGrantID.ClearSelection();
                    valuationReport.gvGrantDetails.chkGDSchemeName.ClearSelection();
                    valuationReport.gvGrantDetails.chkGDCurrency.ClearSelection();
                    valuationReport.gvGrantDetails.chkGDReportStatus.ClearSelection();
                    valuationReport.gvGrantDetails.calGDFromDate.Value = valuationReport.gvGrantDetails.calGDToDate.Value = "dd/mmm/yyyy";
                    valuationReport.gvGrantDetails.txtVRGrpNumFrom.Text = valuationReport.gvGrantDetails.txtVRGrpNumTo.Text = string.Empty;
                    valuationReport.gvGrantDetails.btnGDClearFilter.Visible = false;
                    valuationReport.gvGrantDetails.txtGDGrantID.Text = valuationReport.gvGrantDetails.txtGDSchemeName.Text =
                    valuationReport.gvGrantDetails.txtGDCurrency.Text = valuationReport.gvGrantDetails.txtGDReportStatus.Text = "--- Please Select ---";
                #endregion
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to Display Message Box
        /// </summary>
        /// <param name="valuationReport">valuationReport</param>
        /// <param name="s_ButtonID">Button ID</param>
        /// <param name="n_Result">n_Result</param>
        internal void DisplayMessage(ValuationReport valuationReport, string s_ButtonID, int n_Result)
        {
            try
            {
                switch (s_ButtonID)
                {
                    case "btnGDSearch":
                        valuationReport.gvGrantDetails.btnVRProceed.Visible = valuationReport.gvGrantDetails.gv.Visible == false ? false : true;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }
    }
}