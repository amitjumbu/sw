﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using System;
using System.Data;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Approve Valuation Parameters Model
    /// </summary>
    public class ApproveValuationParamsModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public ApproveValuationParamsModel()
        {
            if (ac_ApproveValuationParams == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ApproveValuationParams);
                ac_ApproveValuationParams = (CommonModel.AC_ApproveValuationParams)HttpContext.Current.Session[CommonConstantModel.s_AC_ApproveValuationParams];
            }
        }

        #endregion

        #region Approval Section

        /// <summary>
        /// This method is used to bind UI labels from xml
        /// </summary>
        /// <param name="approveValuationParameters">approveValuationParameters page object</param>
        public void BindUI(ApproveValuationParameters approveValuationParameters)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    ac_ApproveValuationParams.dt_ApprValParamsSetupUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10_UI);
                    approveValuationParameters.lblVPSApprovalPageHeader.Text = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = 'lblVPSApprovalPageHeader'"))[0]["LabelName"]);
                    approveValuationParameters.gvVPAApprovalGrid.EmptyDataText = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = 'lblVPSGVEmptyDataText'"))[0]["LabelName"]);
                    approveValuationParameters.btnVPSApprove.Text = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = 'btnVPSApprove'"))[0]["LabelName"]);
                    approveValuationParameters.btnVPSApprove.ToolTip = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = 'btnVPSApprove'"))[0]["LabelToolTip"]);
                    approveValuationParameters.btnVPSDisApprove.Text = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = 'btnVPSDisApprove'"))[0]["LabelName"]);
                    approveValuationParameters.btnVPSDisApprove.ToolTip = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = 'btnVPSDisApprove'"))[0]["LabelToolTip"]);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to populate all the controls on page load
        /// </summary>
        /// <param name="approveValuationParameters">approveValuationParameters page object</param>
        public void BindApprovalGrid(ApproveValuationParameters approveValuationParameters)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    approveValuationParameters.divVPAApprovalGrid.Style.Add("display", "");
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    valuationProperties.PopulateControls = "APPROVALDATA";
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    ac_ApproveValuationParams.ds_ApprValParams = (DataSet)valuationCRUDProperties.ds_Result;
                    approveValuationParameters.gvVPAApprovalGrid.DataSource = ac_ApproveValuationParams.ds_ApprValParams.Tables[0];
                    approveValuationParameters.gvVPAApprovalGrid.DataBind();
                    if (ac_ApproveValuationParams.ds_ApprValParams.Tables[0].Rows.Count <= 0)
                        approveValuationParameters.btnVPSApprove.Enabled = approveValuationParameters.btnVPSDisApprove.Enabled = false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view row data bound event
        /// </summary>
        /// <param name="e">event args</param>
        /// <param name="approveValuationParameters">ApproveValuationParameters page object</param>
        /// <param name="n_Index">index</param>
        /// <param name="n_SelectAll">SelectAll</param>
        /// <param name="n_Parameters">Parameters</param>
        /// <param name="n_PreviousSettings">PreviousSettings</param>
        /// <param name="n_CurrentSettings">CurrentSettings</param>
        /// <param name="n_CONFIGID">CONFIGID</param>
        public void gvVPAApprovalGrid_RowDataBound(GridViewRowEventArgs e, ApproveValuationParameters approveValuationParameters, ref int n_Index, ref int n_SelectAll, ref int n_Parameters, ref int n_PreviousSettings, ref int n_CurrentSettings, ref int n_CONFIGID)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SELECT ALL":
                                    n_SelectAll = n_Index;
                                    e.Row.Cells[n_SelectAll].Controls.Add(AddSelectAllCheckBox());
                                    break;
                                case "PARAMETERS":
                                    n_Parameters = n_Index;
                                    break;
                                case "PREVIOUS SETTINGS":
                                    n_PreviousSettings = n_Index;
                                    break;
                                case "CURRENT SETTINGS":
                                    n_CurrentSettings = n_Index;
                                    break;
                                case "CONFIGID":
                                    n_CONFIGID = n_Index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_Index++;
                        }
                        break;
                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_CONFIGID].Visible = false;
                        e.Row.Cells[n_PreviousSettings].Controls.Add(AddBulletedList(e.Row.Cells[n_Parameters].Text, e.Row.Cells[n_PreviousSettings].Text, "PreviousSettings"));
                        e.Row.Cells[n_CurrentSettings].Controls.Add(AddBulletedList(e.Row.Cells[n_Parameters].Text, e.Row.Cells[n_CurrentSettings].Text, "CurrentSettings"));

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_PreviousSettings].Text) && !string.IsNullOrEmpty(e.Row.Cells[n_CurrentSettings].Text) && !e.Row.Cells[n_PreviousSettings].Text.Equals("&nbsp;") && !e.Row.Cells[n_CurrentSettings].Text.Equals("&nbsp;") && e.Row.Cells[n_PreviousSettings].Text != e.Row.Cells[n_CurrentSettings].Text)
                            e.Row.Cells[n_CurrentSettings].Attributes.Add("style", "color:green;");
                        else if (e.Row.Cells[n_CurrentSettings].Text.Contains("lblDIV04") && (ac_ApproveValuationParams.ds_ApprValParams.Tables[1].Rows.Count != ac_ApproveValuationParams.ds_ApprValParams.Tables[2].Rows.Count))
                            e.Row.Cells[n_CurrentSettings].Attributes.Add("style", "color:green;");

                        e.Row.Cells[n_PreviousSettings].Width = e.Row.Cells[n_CurrentSettings].Width = 400;
                        e.Row.Cells[n_Parameters].Width = 200;
                        SetConfigIDsToHdnFields(e.Row.Cells[n_Parameters].Text, e.Row.Cells[n_CONFIGID].Text, approveValuationParameters);
                        e.Row.Cells[n_SelectAll].Controls.Add(AddCheckBox(e.Row.Cells[n_Parameters].Text));
                        e.Row.Cells[n_SelectAll].HorizontalAlign = HorizontalAlign.Center;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add delete check-box to grid-view rows
        /// </summary>
        /// <param name="s_Parameter">Parameter string</param>
        /// <returns>returns CheckBox control</returns>
        private CheckBox AddCheckBox(string s_Parameter)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_Parameter);
                checkBox.ID = "chk";
                checkBox.ClientIDMode = ClientIDMode.Static;
                checkBox.Checked = false;
                checkBox.TabIndex = 7;
                checkBox.Style.Add("cursor", "pointer");
                checkBox.Style.Add("text-align", "center");
                if (!string.IsNullOrEmpty(s_Parameter))
                {
                    checkBox.Attributes.Add("onclick", "DeleteSelectedRecords('" + s_Parameter + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// This method is used to add delete all check-box to grid-view header
        /// </summary>
        /// <returns>Returns CHeckBox control</returns>
        private CheckBox AddSelectAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chk";
                checkBox.Attributes.Add("name", "Types");
                checkBox.Text = string.Empty;
                checkBox.TabIndex = 6;
                checkBox.Style.Add("cursor", "pointer");
                checkBox.Attributes.Add("onclick", "SelectAllCheckBoxes(this)");
                return checkBox;
            }
        }

        /// <summary>
        /// This method is used to get bulleted list object
        /// </summary>
        /// <param name="s_Type">Valuation parameter type</param>
        /// <param name="s_Parameters">~ separated string object</param>
        /// <param name="s_Settings">Setting Type</param>
        /// <returns></returns>
        private BulletedList AddBulletedList(string s_Type, string s_Parameters, string s_Settings)
        {
            using (BulletedList bulletedList = new BulletedList())
            {
                string[] Parameters = s_Parameters.Split('~');
                string s_ItemToAdd = string.Empty;
                if (s_Type.ToUpper().Equals("MARKET PRICE - IV") || s_Type.ToUpper().Equals("MARKET PRICE - FV"))
                    s_Type = "MARKET PRICE";
                switch (s_Type.ToUpper())
                {
                    case "MARKET PRICE":
                        string s_STOCK_EX_LABEL_ID = string.Empty, s_SHORT_NAME = string.Empty, s_MARKET_PRICE_DT_LABEL_ID = string.Empty;
                        foreach (string item in Parameters)
                        {
                            string[] s_Items = item.Split(':');
                            switch (s_Items[0])
                            {
                                case "STOCK_EX_LABEL_ID": s_STOCK_EX_LABEL_ID = s_Items[1]; break;
                                case "SHORT_NAME": s_SHORT_NAME = s_Items[1]; break;
                                case "MARKET_PRICE_DT_LABEL_ID": s_MARKET_PRICE_DT_LABEL_ID = s_Items[1]; break;
                            }
                        }
                        if (!string.IsNullOrEmpty(s_STOCK_EX_LABEL_ID))
                        {
                            s_ItemToAdd = string.Empty;
                            if (!string.IsNullOrEmpty(s_SHORT_NAME))
                                s_ItemToAdd = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = '" + s_STOCK_EX_LABEL_ID + "'"))[0]["LabelName"]) + " : " + s_SHORT_NAME;
                            else s_ItemToAdd = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = '" + s_STOCK_EX_LABEL_ID + "'"))[0]["LabelName"]);
                            bulletedList.Items.Add(s_ItemToAdd);
                        }
                        if (!string.IsNullOrEmpty(s_MARKET_PRICE_DT_LABEL_ID))
                            bulletedList.Items.Add(Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = '" + s_MARKET_PRICE_DT_LABEL_ID + "'"))[0]["LabelName"]));
                        break;
                    case "EXPECTED LIFE":
                        string s_CAL_METHOD_LABEL_ID = string.Empty, s_CONSIDER_PERIOD_IN = string.Empty, s_CONSIDER_VALUE = string.Empty;
                        foreach (string item in Parameters)
                        {
                            string[] s_Items = item.Split(':');
                            switch (s_Items[0])
                            {
                                case "CAL_METHOD_LABEL_ID": s_CAL_METHOD_LABEL_ID = s_Items[1]; break;
                                case "CONSIDER_PERIOD_IN": s_CONSIDER_PERIOD_IN = s_Items[1]; break;
                                case "CONSIDER_VALUE": s_CONSIDER_VALUE = s_Items[1]; break;
                            }
                        }
                        if (!string.IsNullOrEmpty(s_CAL_METHOD_LABEL_ID))
                        {
                            s_ItemToAdd = string.Empty;
                            s_ItemToAdd = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = '" + s_CAL_METHOD_LABEL_ID + "'"))[0]["LabelName"]);
                            if (s_CAL_METHOD_LABEL_ID.Equals("lblMCEL02") || s_CAL_METHOD_LABEL_ID.Equals("lblMCEL03"))
                            {
                                if (!string.IsNullOrEmpty(s_CONSIDER_VALUE))
                                    s_ItemToAdd = s_ItemToAdd + " : " + s_CONSIDER_VALUE;
                                switch (s_CONSIDER_PERIOD_IN.ToUpper())
                                {
                                    case "Y": s_ItemToAdd = s_ItemToAdd + " Years"; break;
                                    case "D": s_ItemToAdd = s_ItemToAdd + " Days"; break;
                                    case "M": s_ItemToAdd = s_ItemToAdd + " Months"; break;
                                }
                            }
                            bulletedList.Items.Add(s_ItemToAdd);
                        }
                        break;
                    case "VOLATILITY":
                        string s_VOLATILITY_OF_LABEL_ID = string.Empty, s_SHORT_NAME_VC = string.Empty, s_MP_CALC_VOLATILITY_LABEL_ID = string.Empty, s_TRADING_DAYS_LABEL_ID = string.Empty, s_TRADING_DAYS = string.Empty, s_PRD_CALC_VOLATILITY_LABEL_ID = string.Empty, s_CONSIDER_PERIOD_IN_VC = string.Empty, s_CONSIDER_VALUE_VC = string.Empty;
                        foreach (string item in Parameters)
                        {
                            string[] s_Items = item.Split(':');
                            switch (s_Items[0])
                            {
                                case "VOLATILITY_OF_LABEL_ID": s_VOLATILITY_OF_LABEL_ID = s_Items[1]; break;
                                case "SHORT_NAME": s_SHORT_NAME_VC = s_Items[1]; break;
                                case "MP_CALC_VOLATILITY_LABEL_ID": s_MP_CALC_VOLATILITY_LABEL_ID = s_Items[1]; break;
                                case "TRADING_DAYS_LABEL_ID": s_TRADING_DAYS_LABEL_ID = s_Items[1]; break;
                                case "TRADING_DAYS": s_TRADING_DAYS = s_Items[1]; break;
                                case "PRD_CALC_VOLATILITY_LABEL_ID": s_PRD_CALC_VOLATILITY_LABEL_ID = s_Items[1]; break;
                                case "CONSIDER_PERIOD_IN": s_CONSIDER_PERIOD_IN_VC = s_Items[1]; break;
                                case "CONSIDER_VALUE": s_CONSIDER_VALUE_VC = s_Items[1]; break;
                            }
                        }
                        if (!string.IsNullOrEmpty(s_VOLATILITY_OF_LABEL_ID))
                        {
                            s_ItemToAdd = string.Empty;
                            s_ItemToAdd = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = '" + s_VOLATILITY_OF_LABEL_ID + "'"))[0]["LabelName"]);
                            if (s_VOLATILITY_OF_LABEL_ID.Equals("lblVOL01") && !string.IsNullOrEmpty(s_SHORT_NAME_VC))
                                s_ItemToAdd = s_ItemToAdd + " : " + s_SHORT_NAME_VC;
                            bulletedList.Items.Add(s_ItemToAdd);
                        }
                        if (!string.IsNullOrEmpty(s_MP_CALC_VOLATILITY_LABEL_ID))
                        {
                            s_ItemToAdd = string.Empty;
                            s_ItemToAdd = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = '" + s_MP_CALC_VOLATILITY_LABEL_ID + "'"))[0]["LabelName"]);
                            if (!string.IsNullOrEmpty(s_TRADING_DAYS_LABEL_ID))
                            {
                                if (s_TRADING_DAYS_LABEL_ID.Equals("lblTDD01") || s_TRADING_DAYS_LABEL_ID.Equals("lblTDD02"))
                                    s_ItemToAdd = s_ItemToAdd + " : Trading Days - " + Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = '" + s_TRADING_DAYS_LABEL_ID + "'"))[0]["LabelName"]);
                                else if (s_TRADING_DAYS_LABEL_ID.Equals("lblTDD03") && !string.IsNullOrEmpty(s_TRADING_DAYS))
                                    s_ItemToAdd = s_ItemToAdd + " : Trading Days - " + s_TRADING_DAYS;
                            }
                            bulletedList.Items.Add(s_ItemToAdd);
                        }
                        if (!string.IsNullOrEmpty(s_PRD_CALC_VOLATILITY_LABEL_ID))
                        {
                            s_ItemToAdd = string.Empty;
                            s_ItemToAdd = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = '" + s_PRD_CALC_VOLATILITY_LABEL_ID + "'"))[0]["LabelName"]);
                            if (s_PRD_CALC_VOLATILITY_LABEL_ID.Equals("lblPTCV03"))
                            {
                                if (!string.IsNullOrEmpty(s_CONSIDER_VALUE_VC))
                                    s_ItemToAdd = s_ItemToAdd + " : " + s_CONSIDER_VALUE_VC;
                                switch (s_CONSIDER_PERIOD_IN_VC.ToUpper())
                                {
                                    case "Y": s_ItemToAdd = s_ItemToAdd + " Years"; break;
                                    case "D": s_ItemToAdd = s_ItemToAdd + " Days"; break;
                                    case "M": s_ItemToAdd = s_ItemToAdd + " Months"; break;
                                }
                            }
                            bulletedList.Items.Add(s_ItemToAdd);
                        }
                        break;
                    case "DIVIDEND":
                        string s_DIVIDEND_LABEL_ID = string.Empty, s_NO_OF_YEARS = string.Empty, s_SPECIAL_DIVIDEND = string.Empty, s_MP_TO_CAL_DIVIDEND_LABEL_ID = string.Empty, s_SHORT_NAME_DC = string.Empty;
                        foreach (string item in Parameters)
                        {
                            string[] s_Items = item.Split(':');
                            switch (s_Items[0])
                            {
                                case "DIVIDEND_LABEL_ID": s_DIVIDEND_LABEL_ID = s_Items[1]; break;
                                case "NO_OF_YEARS": s_NO_OF_YEARS = s_Items[1]; break;
                                case "SPECIAL_DIVIDEND": s_SPECIAL_DIVIDEND = s_Items[1]; break;
                                case "MP_TO_CAL_DIVIDEND_LABEL_ID": s_MP_TO_CAL_DIVIDEND_LABEL_ID = s_Items[1]; break;
                                case "SHORT_NAME": s_SHORT_NAME_DC = s_Items[1]; break;
                            }
                        }
                        if (!string.IsNullOrEmpty(s_DIVIDEND_LABEL_ID))
                        {
                            s_ItemToAdd = string.Empty;
                            s_ItemToAdd = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = '" + s_DIVIDEND_LABEL_ID + "'"))[0]["LabelName"]);
                            if (s_DIVIDEND_LABEL_ID.Equals("lblDIV03") && !string.IsNullOrEmpty(s_NO_OF_YEARS))
                                s_ItemToAdd = s_ItemToAdd + " : Last " + s_NO_OF_YEARS + " Years";
                            else if (s_DIVIDEND_LABEL_ID.Equals("lblDIV04"))
                            {
                                StringBuilder s_IncorporateDetails = new StringBuilder();
                                if (s_Settings.Equals("PreviousSettings") && ac_ApproveValuationParams.ds_ApprValParams.Tables[1].Rows.Count > 0)
                                    ac_ApproveValuationParams.dt_IncorporateDetails = ac_ApproveValuationParams.ds_ApprValParams.Tables[1];
                                else if (s_Settings.Equals("CurrentSettings") && ac_ApproveValuationParams.ds_ApprValParams.Tables[2].Rows.Count > 0)
                                    ac_ApproveValuationParams.dt_IncorporateDetails = ac_ApproveValuationParams.ds_ApprValParams.Tables[2];
                                if (ac_ApproveValuationParams.dt_IncorporateDetails.Rows.Count > 0)
                                {
                                    foreach (DataRow dr_Row in ac_ApproveValuationParams.dt_IncorporateDetails.Rows)
                                    {
                                        if (s_IncorporateDetails.Length.Equals(0))
                                            s_IncorporateDetails.Append(Convert.ToString(dr_Row["Dividend"]) + " ( " + Convert.ToDateTime(dr_Row["From Date"]).ToString("dd/MMM/yyyy") + " - " + Convert.ToDateTime(dr_Row["To Date"]).ToString("dd/MMM/yyyy") + " )");
                                        else
                                            s_IncorporateDetails.Append(" , " + Convert.ToString(dr_Row["Dividend"]) + " ( " + Convert.ToDateTime(dr_Row["From Date"]).ToString("dd/MMM/yyyy") + " - " + Convert.ToDateTime(dr_Row["To Date"]).ToString("dd/MMM/yyyy") + " )");
                                    }
                                }
                                if (s_IncorporateDetails.Length > 0)
                                    s_ItemToAdd += " : " + s_IncorporateDetails;
                                s_IncorporateDetails.Clear();
                            }
                            bulletedList.Items.Add(s_ItemToAdd);
                        }
                        if (!string.IsNullOrEmpty(s_MP_TO_CAL_DIVIDEND_LABEL_ID))
                        {
                            s_ItemToAdd = string.Empty;
                            s_ItemToAdd = Convert.ToString((ac_ApproveValuationParams.dt_ApprValParamsSetupUI.Select("LabelID = '" + s_MP_TO_CAL_DIVIDEND_LABEL_ID + "'"))[0]["LabelName"]);
                            if (s_DIVIDEND_LABEL_ID.Equals("lblMPTCD02") && !string.IsNullOrEmpty(s_SHORT_NAME_DC))
                                s_ItemToAdd = s_ItemToAdd + " : " + s_SHORT_NAME_DC;
                            bulletedList.Items.Add(s_ItemToAdd);
                        }
                        break;
                }
                return bulletedList;
            }
        }

        /// <summary>
        /// This method is used to set Config ID's to hidden fields
        /// </summary>
        /// <param name="s_Type">Valuation parameter name</param>
        /// <param name="s_ConfigID">ConfigID : primary key</param>
        /// <param name="approveValuationParameters">ValuationParameters page object</param>
        private void SetConfigIDsToHdnFields(string s_Type, string s_ConfigID, ApproveValuationParameters approveValuationParameters)
        {
            if (!string.IsNullOrEmpty(s_ConfigID) || !s_ConfigID.Equals("&nbsp;"))
            {
                switch (s_Type.ToUpper())
                {
                    case "MARKET PRICE - IV": approveValuationParameters.hdnVPSIntrinsicValueID.Value = s_ConfigID; break;
                    case "MARKET PRICE - FV": approveValuationParameters.hdnVPSFairValueID.Value = s_ConfigID; break;
                    case "EXPECTED LIFE": approveValuationParameters.hdnVPSExpectedLifeID.Value = s_ConfigID; break;
                    case "VOLATILITY": approveValuationParameters.hdnVPSVolatilityID.Value = s_ConfigID; break;
                    case "DIVIDEND": approveValuationParameters.hdnVPSDividendID.Value = s_ConfigID; break;
                }
            }
        }

        /// <summary>
        /// Button click event to approve/disapprove valuation parameters
        /// </summary>
        /// <param name="approveValuationParameters">ValuationParameters page object</param>
        /// <param name="b_IsApproved">boolean value for approve/disapprove</param>
        public void btnVPSApprove_Click(ApproveValuationParameters approveValuationParameters, bool b_IsApproved)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                    valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                    valuationProperties.IS_APPROVED = b_IsApproved;
                    if (!string.IsNullOrEmpty(approveValuationParameters.hdnConfigIDs.Value))
                    {
                        if (approveValuationParameters.hdnConfigIDs.Value.Contains("Market Price - IV"))
                            valuationProperties.INTRINSIC_VALUE_ID = !string.IsNullOrEmpty(approveValuationParameters.hdnVPSIntrinsicValueID.Value) ? Convert.ToInt32(approveValuationParameters.hdnVPSIntrinsicValueID.Value) : 0;
                        if (approveValuationParameters.hdnConfigIDs.Value.Contains("Market Price - FV"))
                            valuationProperties.FAIR_VALUE_ID = !string.IsNullOrEmpty(approveValuationParameters.hdnVPSFairValueID.Value) ? Convert.ToInt32(approveValuationParameters.hdnVPSFairValueID.Value) : 0;
                        if (approveValuationParameters.hdnConfigIDs.Value.Contains("Expected Life"))
                            valuationProperties.EXPECTED_LIFE_ID = !string.IsNullOrEmpty(approveValuationParameters.hdnVPSExpectedLifeID.Value) ? Convert.ToInt32(approveValuationParameters.hdnVPSExpectedLifeID.Value) : 0;
                        if (approveValuationParameters.hdnConfigIDs.Value.Contains("Volatility"))
                            valuationProperties.VOLATILITY_ID = !string.IsNullOrEmpty(approveValuationParameters.hdnVPSVolatilityID.Value) ? Convert.ToInt32(approveValuationParameters.hdnVPSVolatilityID.Value) : 0;
                        if (approveValuationParameters.hdnConfigIDs.Value.Contains("Dividend"))
                            valuationProperties.DIVIDEND_ID = !string.IsNullOrEmpty(approveValuationParameters.hdnVPSDividendID.Value) ? Convert.ToInt32(approveValuationParameters.hdnVPSDividendID.Value) : 0;
                    }
                    valuationProperties.PopulateControls = "APPROVALDATA";
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    approveValuationParameters.hdnConfigIDs.Value = string.Empty;
                    if (valuationCRUDProperties.a_result > 0)
                    {
                        BindApprovalGrid(approveValuationParameters);
                        approveValuationParameters.ctrSuccessErrorMessage.s_MessageText = valuationCRUDProperties.a_result.Equals(2) ? valuationServiceClient.GetValuation_L10N("lblVPSConfigApproveMessage", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10) : valuationServiceClient.GetValuation_L10N("lblVPSConfigDisApprMessage", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                        approveValuationParameters.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                        approveValuationParameters.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;                        
                        approveValuationParameters.Response.Redirect("ValuationParameters.aspx", false);                                               
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Button click event to approve/disapprove valuation parameters
        /// </summary>
        /// <param name="approveValuationParameters">ValuationParameters page object</param>
        /// <param name="b_IsApproved">boolean value for approve/disapprove</param>
        public void btnVPSDisApprove_Click(ApproveValuationParameters approveValuationParameters, bool b_IsApproved)
        {
            try
            {
                btnVPSApprove_Click(approveValuationParameters, b_IsApproved);
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}