﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation.UserControl_Model;
using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class SelectTemplateUCModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SelectTemplateUCModel()
        {
            if (ac_ValuationReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationReport);
                ac_ValuationReport = (CommonModel.AC_ValuationReport)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationReport];
            }
        }

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="selectTemplateUC">SelectTemplateUC page object</param>
        /// <param name="n_IsListed">Company 0 = IsListed and 1 = Unlisted</param>
        internal void ReadL10N_UI(View.User.Valuation.UserControl.SelectTemplateUC selectTemplateUC, ref int n_IsListed)
        {
            try
            {
                n_IsListed = userSessionInfo.ACC_IsListed;

                selectTemplateUC.lblSelectTemplate.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblSelectTemplate'"))[0]["LabelName"]);
                selectTemplateUC.lblSelectTemplate.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblSelectTemplate'"))[0]["LabelToolTip"]);

                selectTemplateUC.btnViewTemplate.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnViewTemplate'"))[0]["LabelName"]);
                selectTemplateUC.btnViewTemplate.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnViewTemplate'"))[0]["LabelToolTip"]);

                selectTemplateUC.btnSTSaveContinue.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSaveContinue'"))[0]["LabelName"]);
                selectTemplateUC.btnSTSaveContinue.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSaveContinue'"))[0]["LabelToolTip"]);

                selectTemplateUC.lblCreateTemplate.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblCreateTemplate'"))[0]["LabelName"]);
                selectTemplateUC.lblCreateTemplate.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblCreateTemplate'"))[0]["LabelToolTip"]);

                selectTemplateUC.hdnCompanyName.Value = userSessionInfo.ACC_CompanyName;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method loads ddTemplatelist with all the template names that are already created.
        /// </summary>
        /// <param name="selectTemplateUC">object of the report format page</param>
        public void load_ddTemplatelist(View.User.Valuation.UserControl.SelectTemplateUC selectTemplateUC)
        {
            try
            {
                using (DataSet ds_TemplateList = new DataSet())
                {
                    DataTable dt_TemplateList = new DataTable();
                    if(!System.IO.File.Exists(Convert.ToString(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"]) + userSessionInfo.ACC_CompanyName + @"\TemplateList.xml")))
                    {
                        using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                        {
                            valuationServiceClient.GetWordTemplateList(userSessionInfo.ACC_CompanyName);
                        }
                    }
                    ds_TemplateList.ReadXml(Convert.ToString(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["TemplatePath"]) + userSessionInfo.ACC_CompanyName + @"\TemplateList.xml"));
                    dt_TemplateList = ds_TemplateList.Tables["Template"];

                    selectTemplateUC.ddlTemplateNames.DataSource = dt_TemplateList;
                    selectTemplateUC.ddlTemplateNames.DataTextField = "ID";
                    selectTemplateUC.ddlTemplateNames.DataValueField = "Name";
                    selectTemplateUC.ddlTemplateNames.DataBind();
                    dt_TemplateList.Dispose();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Save and Continue to next step
        /// </summary>
        /// <param name="selectTemplateUC">selectTemplateUC page object</param>
        public void SaveContinue(View.User.Valuation.UserControl.SelectTemplateUC selectTemplateUC)
        {
            string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];

            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                if (selectTemplateUC.hdnSTModEDLSelected.Value.Equals("Set"))
                {
                    using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                    {
                        valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                        valuationProperties.Operation_Param = CommonConstantModel.s_ModEDL;

                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report = valuationCRUDProperties.dt_Result.Copy().Select("OPERATION_ID = 2 OR OPERATION_ID = 3").Count() > 0 ? valuationCRUDProperties.dt_Result.Copy().Select("OPERATION_ID = 2 OR OPERATION_ID = 3").CopyToDataTable() : new DataTable();
                    }
                }
                ac_ValuationReport.dt_temp_Unlocked_Valuation_Report = _gvUserControlModel.ac_SearchGrantDetails.dt_temp_Unlocked_Valuation_Report;
                _gvUserControlModel.ac_SearchGrantDetails.s_StepNumber = "3";
            }

            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                valuationProperties.PageName = CommonConstantModel.s_CommentDetails;

                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                valuationProperties.Step = "SAVE_TEMPLATE_NAME";
                valuationProperties.Action = "C";
                valuationProperties.Step_Number = "3";
                valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                valuationProperties.Group_Id = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"].ToString();
                valuationProperties.Template_Name = selectTemplateUC.ddlTemplateNames.SelectedItem.Text;
                valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                try
                {
                    foreach (DataRow perRow in ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("[Group Number] = '" + valuationProperties.Group_Id + "'"))
                    {
                        perRow["TEMPLATE_NAME"] = selectTemplateUC.ddlTemplateNames.SelectedItem.Text;
                    }
                }
                catch
                {
                    // Do Nothing 
                }
            }
        }

        #region Destructors
        /// <summary>
        /// This method calls the dispose method of ReportFormatModel.
        /// </summary>
        ~SelectTemplateUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members

        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// Dispose method of ReportFormatModel
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}