﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using EDFinancials.View.User.Valuation.UserControl;
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Company Info pop-up Model
    /// </summary>
    public class CompanyInfoPopupModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public CompanyInfoPopupModel()
        {
            if (ac_CompanyInformation == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_CompanyInformation);
                ac_CompanyInformation = (CommonModel.AC_CompanyInformation)HttpContext.Current.Session[CommonConstantModel.s_AC_CompanyInformation];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnFaceValUpdateText = string.Empty, s_BtnFaceValUpdateToolTip = string.Empty, s_BtnFaceValSaveText = string.Empty, s_BtnFaceValSaveTooltip = string.Empty
                           , s_BtnShareCapUpdateText = string.Empty, s_BtnShareCapUpdateToolTip = string.Empty, s_BtnShareCapSaveText = string.Empty, s_BtnShareCapSaveTooltip = string.Empty;

        #endregion


        #region Common Methods

        /// <summary>
        /// This method is used to pupulated all the controls 
        /// </summary>
        /// <param name="companyInfoPopup">CompanyInfoPopup page object</param>
        /// <param name="n_DivID">Div ID</param>
        public void PopulateAllControls(CompanyInfoPopup companyInfoPopup, int n_DivID)
        {
            try
            {
                BindUI(companyInfoPopup);
                BindDropDowns(companyInfoPopup, n_DivID);
                CheckEmployeeRolePriviledges(companyInfoPopup);
                BindAllGrids(companyInfoPopup, n_DivID);
                companyInfoPopup.hdnCIPDivID.Value = Convert.ToString(n_DivID);
                companyInfoPopup.ctrCIFaceVal.hdnCIFaceValID.Value = "0";
                companyInfoPopup.ctrCIShareCap.hdnCIShareCapID.Value = "0";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all the lables from L10N_UI
        /// </summary>
        /// <param name="companyInfoPopup">CompanyInfoPopup page object</param>
        public void BindUI(CompanyInfoPopup companyInfoPopup)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    #region Face Value
                    ac_CompanyInformation.dt_CompanyInfoPopUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_CompanyInformation, CommonConstantModel.s_ValuationL10_UI);
                    companyInfoPopup.ctrCIFaceVal.lblCICurrentStatus1.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCICurrentStatus'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.lblCICurrentStatus2.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCICurrentStatus'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.lblCIHistory1.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCIHistory'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.lblCIHistory2.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCIHistory'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.lblCIFaceValFromDate.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCIFaceValFromDate'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.lblCIFaceValFromDate.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCIFaceValFromDate'"))[0]["LabelToolTip"]);
                    companyInfoPopup.ctrCIFaceVal.rfvCIFaceValue.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'rfvCIFaceValue'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.btnCIFaceValClear.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIFaceValClear'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.btnCIFaceValClear.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIFaceValClear'"))[0]["LabelToolTip"]);
                    companyInfoPopup.ctrCIFaceVal.gvCIFaceValueCurrent.EmptyDataText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIEmptyDataText'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.gvCIFaceValueHistory.EmptyDataText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIEmptyDataText'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.lblCIFaceValue.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCIFaceValue'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.lblCIFaceValue.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCIFaceValue'"))[0]["LabelToolTip"]);
                    companyInfoPopup.ctrCIFaceVal.lblCIFVCurrency.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCIFVCurrency'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.lblCIFVCurrency.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCIFVCurrency'"))[0]["LabelToolTip"]);
                    companyInfoPopup.ctrCIFaceVal.rfvCIFVCurrency.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'rfvCIFVCurrency'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.rfvCIFaceValFromDate.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'rfvCIFaceValFromDate'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.btnCIFaceValSave.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIFaceValSave'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIFaceVal.btnCIFaceValSave.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIFaceValSave'"))[0]["LabelToolTip"]);
                    s_BtnFaceValSaveText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIFaceValSave'"))[0]["LabelName"]);
                    s_BtnFaceValSaveTooltip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIFaceValSave'"))[0]["LabelToolTip"]);
                    s_BtnFaceValUpdateText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIFaceValUpdate'"))[0]["LabelName"]);
                    s_BtnFaceValUpdateToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIFaceValUpdate'"))[0]["LabelToolTip"]);
                    #endregion

                    #region Share Capital
                    companyInfoPopup.ctrCIShareCap.lblCISharesFromDate.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCISharesFromDate'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.lblCISharesFromDate.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCISharesFromDate'"))[0]["LabelToolTip"]);
                    companyInfoPopup.ctrCIShareCap.rfvCISharesFromDate.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'rfvCISharesFromDate'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.lblCIShareCap.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCIShareCap'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.lblCIShareCap.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'lblCIShareCap'"))[0]["LabelToolTip"]);
                    companyInfoPopup.ctrCIShareCap.rfvCIShareCap.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'rfvCIShareCap'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.btnCIShareCapClear.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIShareCapClear'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.btnCIShareCapClear.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIShareCapClear'"))[0]["LabelToolTip"]);
                    companyInfoPopup.ctrCIShareCap.gvCIShareCap.EmptyDataText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIEmptyDataText'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.gvCIShareCapHistory.EmptyDataText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIEmptyDataText'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.rfvCISharesFromDate.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'rfvCISharesFromDate'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.btnCIShareCapSave.Text = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIShareCapSave'"))[0]["LabelName"]);
                    companyInfoPopup.ctrCIShareCap.btnCIShareCapSave.ToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIShareCapSave'"))[0]["LabelToolTip"]);
                    s_BtnShareCapSaveText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIShareCapSave'"))[0]["LabelName"]);
                    s_BtnShareCapSaveTooltip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIShareCapSave'"))[0]["LabelToolTip"]);
                    s_BtnShareCapUpdateText = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIShareCapUpdate'"))[0]["LabelName"]);
                    s_BtnShareCapUpdateToolTip = Convert.ToString((ac_CompanyInformation.dt_CompanyInfoPopUI.Select("LabelID = 'btnCIShareCapUpdate'"))[0]["LabelToolTip"]);
                    #endregion
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all the grids
        /// </summary>
        /// <param name="companyInfoPopup">CompanyInfoPopup page object</param>
        /// <param name="n_DivID">Popup Div ID</param>
        public void BindDropDowns(CompanyInfoPopup companyInfoPopup, int n_DivID)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    switch (n_DivID)
                    {
                        case 3:
                            ac_CompanyInformation.dt_Currencies = ac_CompanyInformation.ds_CompanyInfo.Tables[9];
                            companyInfoPopup.ctrCIFaceVal.ddlCIFVCurrency.DataSource = ac_CompanyInformation.dt_Currencies;
                            companyInfoPopup.ctrCIFaceVal.ddlCIFVCurrency.DataTextField = "CURRENCY_NAME";
                            companyInfoPopup.ctrCIFaceVal.ddlCIFVCurrency.DataValueField = "CRMID";
                            companyInfoPopup.ctrCIFaceVal.ddlCIFVCurrency.DataBind();
                            companyInfoPopup.ctrCIFaceVal.ddlCIFVCurrency.Items.Insert(0, new ListItem("--- Please Select ---", "0"));
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind all the grids
        /// </summary>
        /// <param name="companyInfoPopup">CompanyInfoPopup page object</param>
        /// <param name="n_DivID">Popup Div ID</param>
        public void BindAllGrids(CompanyInfoPopup companyInfoPopup, int n_DivID)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    switch (n_DivID)
                    {
                        case 2:
                            ac_CompanyInformation.dt_CurrentShareCap = ac_CompanyInformation.ds_CompanyInfo.Tables[2];
                            ac_CompanyInformation.dt_ShareCapHistory = ac_CompanyInformation.ds_CompanyInfo.Tables[3];
                            companyInfoPopup.ctrCIShareCap.gvCIShareCap.DataSource = ac_CompanyInformation.dt_CurrentShareCap;
                            companyInfoPopup.ctrCIShareCap.gvCIShareCap.DataBind();
                            companyInfoPopup.ctrCIShareCap.gvCIShareCapHistory.DataSource = ac_CompanyInformation.dt_ShareCapHistory;
                            companyInfoPopup.ctrCIShareCap.gvCIShareCapHistory.DataBind();
                            break;

                        case 3:
                            ac_CompanyInformation.dt_CurrentFaceValue = ac_CompanyInformation.ds_CompanyInfo.Tables[5];
                            ac_CompanyInformation.dt_FaceValueHistory = ac_CompanyInformation.ds_CompanyInfo.Tables[6];
                            companyInfoPopup.ctrCIFaceVal.gvCIFaceValueCurrent.DataSource = ac_CompanyInformation.dt_CurrentFaceValue;
                            companyInfoPopup.ctrCIFaceVal.gvCIFaceValueCurrent.DataBind();
                            companyInfoPopup.ctrCIFaceVal.gvCIFaceValueHistory.DataSource = ac_CompanyInformation.dt_FaceValueHistory;
                            companyInfoPopup.ctrCIFaceVal.gvCIFaceValueHistory.DataBind();
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to check employee role priviledges
        /// </summary>
        /// <param name="companyInfoPopup">CompanyInfoPopup page object</param>
        private void CheckEmployeeRolePriviledges(CompanyInfoPopup companyInfoPopup)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuCompanyInformation;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    companyInfoPopup.ctrCIShareCap.btnCIShareCapSave.Enabled = false;
                                    companyInfoPopup.ctrCIFaceVal.btnCIFaceValSave.Enabled = false;
                                    break;

                                case "ADD":
                                    companyInfoPopup.ctrCIShareCap.btnCIShareCapSave.Enabled = true;
                                    companyInfoPopup.ctrCIFaceVal.btnCIFaceValSave.Enabled = true;
                                    break;

                                case "EDIT":
                                    companyInfoPopup.ctrCIShareCap.btnCIShareCapSave.Enabled = true;
                                    companyInfoPopup.ctrCIFaceVal.btnCIFaceValSave.Enabled = true;
                                    ac_CompanyInformation.b_IsEditRights = true;
                                    break;

                                case "DELETE":
                                    ac_CompanyInformation.b_IsDeleteRights = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to rebind all the grids
        /// </summary>
        /// <param name="companyInfoPopup">CompanyInfoPopup page object</param>
        public void ReBindAllGrids(CompanyInfoPopup companyInfoPopup)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_CompanyInformation;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    valuationProperties.PopulateControls = CommonConstantModel.s_OperationRead;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    ac_CompanyInformation.ds_CompanyInfo = valuationCRUDProperties.ds_Result;
                    BindAllGrids(companyInfoPopup, Convert.ToInt32(companyInfoPopup.hdnCIPDivID.Value));
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_BtnEditText">image button text</param>
        /// <param name="s_Url">image URL</param>
        /// <param name="s_FromDate">from date</param>
        /// <param name="s_ToDate">to date</param>
        /// <param name="c_TextVal">image text value</param>
        /// <param name="c_ID">image ID</param>
        /// <param name="s_Type">div type</param>
        /// <param name="s_GRANTS_FROM_DATE">grants from date</param>
        /// <param name="s_CRMID">currency master ID</param>
        /// <returns>returns image button control object</returns>
        public ImageButton AddImageLink(string s_BtnEditText, string s_Url, string s_FromDate, string s_ToDate, string c_TextVal, string c_ID, string s_Type, string s_GRANTS_FROM_DATE, string s_CRMID)
        {
            try
            {
                using (ImageButton img = new ImageButton())
                {
                    img.ImageUrl = s_Url;

                    if (s_BtnEditText.Equals("Edit"))
                        img.Enabled = ac_CompanyInformation.b_IsEditRights;
                    else if (s_BtnEditText.Equals("Delete"))
                        img.Enabled = ac_CompanyInformation.b_IsDeleteRights;

                    img.ToolTip = s_BtnEditText;
                    img.Style.Add("cursor", "pointer");
                    img.Style.Add("text-align", "center");
                    img.TabIndex = 8;

                    s_ToDate = (!string.IsNullOrEmpty(s_ToDate) && !s_ToDate.Equals("&nbsp;")) ? s_ToDate : string.Empty;

                    if (s_Type.Equals("Face_Val"))
                    {
                        if (string.IsNullOrEmpty(s_CRMID) || s_CRMID.Equals("&nbsp;"))
                            s_CRMID = "0";
                        img.Attributes.Add("onclick", "return EditFaceValue('" + s_FromDate + "','" + s_ToDate + "','" + c_TextVal + "','" + c_ID + "','" + s_BtnEditText + "','" + s_CRMID + "')");
                    }
                    else if (s_Type.Equals("Share_Cap"))
                        img.Attributes.Add("onclick", "return EditShareCap('" + s_FromDate + "','" + s_ToDate + "','" + c_TextVal + "','" + c_ID + "','" + s_BtnEditText + "','" + s_CRMID + "')");
                    return img;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to show/hide message div
        /// </summary>
        /// <param name="companyInfoPopup">CompanyInfoPopup page object</param>
        /// <param name="n_result">input parameter</param>
        public void ShowMsgDiv(CompanyInfoPopup companyInfoPopup, int n_result)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    switch (n_result)
                    {
                        case 0: companyInfoPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                            break;
                        case 1: companyInfoPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCISaveMessage", CommonConstantModel.s_CompanyInformation, CommonConstantModel.s_ValuationL10);
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            companyInfoPopup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            companyInfoPopup.hdnCIAccordionIndex.Value = "0";
                            break;
                        case 2: companyInfoPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCIUpdateMessage", CommonConstantModel.s_CompanyInformation, CommonConstantModel.s_ValuationL10);
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            companyInfoPopup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            companyInfoPopup.hdnCIAccordionIndex.Value = "0";
                            break;
                        case 4: companyInfoPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCIRecAlreadyExists", CommonConstantModel.s_CompanyInformation, CommonConstantModel.s_ValuationL10);
                            companyInfoPopup.hdnCIIsAlreayExists.Value = "true";
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            companyInfoPopup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            companyInfoPopup.hdnCIAccordionIndex.Value = "0";
                            break;
                        case 3: companyInfoPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCIDeleteMessage", CommonConstantModel.s_CompanyInformation, CommonConstantModel.s_ValuationL10);
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            companyInfoPopup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            companyInfoPopup.hdnCIAccordionIndex.Value = "0";
                            break;
                        case 5:
                            companyInfoPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCSExistWithDeletedStatus", CommonConstantModel.s_CompanyInformation, CommonConstantModel.s_ValuationL10);
                            companyInfoPopup.hdnCIIsAlreayExists.Value = "true";
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                            companyInfoPopup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "";
                            break;
                        case 6:
                            companyInfoPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCIAssociateSEBeforeDisassociate", CommonConstantModel.s_CompanyInformation, CommonConstantModel.s_ValuationL10);
                            companyInfoPopup.hdnCIIsAlreayExists.Value = "true";
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                            companyInfoPopup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;
                        case 7:
                            companyInfoPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCIAssociateSEBeforeDelete", CommonConstantModel.s_CompanyInformation, CommonConstantModel.s_ValuationL10);
                            companyInfoPopup.hdnCIIsAlreayExists.Value = "true";
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                            companyInfoPopup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;
                        case 8: companyInfoPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                            companyInfoPopup.hdnCIAccordionIndex.Value = "1";
                            break;
                        case 9: companyInfoPopup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCIInvalidStockExCode", CommonConstantModel.s_CompanyInformation, CommonConstantModel.s_ValuationL10);
                            companyInfoPopup.hdnCIIsAlreayExists.Value = "true";
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                            companyInfoPopup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            companyInfoPopup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            break;

                        default:
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Listing Status

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindCIListingStatusHistory(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "LSAPID":
                                    perColumn.Visible = false;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[3].Visible = false;
                        e.Row.Cells[1].HorizontalAlign = e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[2].Text) && !e.Row.Cells[2].Text.Equals("&nbsp;"))
                            e.Row.Cells[2].Text = Convert.ToDateTime(e.Row.Cells[2].Text).ToString("dd/MMM/yyyy");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindCIListingStatus(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "LSAPID":
                                    perColumn.Visible = false;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[3].Visible = false;
                        e.Row.Cells[1].HorizontalAlign = e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[2].Text) && !e.Row.Cells[2].Text.Equals("&nbsp;"))
                            e.Row.Cells[2].Text = Convert.ToDateTime(e.Row.Cells[2].Text).ToString("dd/MMM/yyyy");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Face Value

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindCIFaceVal(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "FVID":
                                    perColumn.Visible = false;
                                    break;
                                case "CRMID":
                                    perColumn.Visible = false;
                                    break;
                                case "TO DATE":
                                    perColumn.Visible = false;
                                    break;
                            }
                        }
                        break;
                    case DataControlRowType.DataRow:
                        e.Row.Cells[5].Visible = e.Row.Cells[6].Visible = e.Row.Cells[1].Visible = false;
                        e.Row.Cells[0].HorizontalAlign = e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;

                        if (!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                            e.Row.Cells[0].Text = Convert.ToDateTime(e.Row.Cells[0].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        e.Row.Cells[4].Controls.Add((Control)AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[1].Text, e.Row.Cells[2].Text, e.Row.Cells[5].Text, "Face_Val", "", e.Row.Cells[6].Text));
                        e.Row.Cells[4].Controls.Add((Control)AddImageLink("Delete", "~/View/App_Themes/images/Delete.png", e.Row.Cells[0].Text, e.Row.Cells[1].Text, e.Row.Cells[2].Text, e.Row.Cells[5].Text, "Face_Val", "", e.Row.Cells[6].Text));

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            e.Row.Cells[2].Text = Convert.ToDouble(e.Row.Cells[2].Text) > 999 ? CommonModel.ThousandFormating(e.Row.Cells[2].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()) : e.Row.Cells[2].Text;
                        }
                        #endregion
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindCIFaceValHistory(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.DataRow:
                        e.Row.Cells[0].HorizontalAlign = e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;

                        if (!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                            e.Row.Cells[0].Text = Convert.ToDateTime(e.Row.Cells[0].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            e.Row.Cells[2].Text = Convert.ToDouble(e.Row.Cells[2].Text) > 999 ? CommonModel.ThousandFormating(e.Row.Cells[2].Text, DecimalLimitTable.Select("ADVSID = 11")[0]["ROUNDING_PLACE_VALUE"].ToString()) : e.Row.Cells[2].Text;
                        }
                        #endregion
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="faceValPopupUC">FaceValPopupUC control object</param>
        /// <param name="NewPageIndex">new page index</param>
        public void gvCIFaceValuePageIndexChang(FaceValPopupUC faceValPopupUC, int NewPageIndex)
        {
            try
            {
                faceValPopupUC.gvCIFaceValueHistory.PageIndex = NewPageIndex;
                faceValPopupUC.gvCIFaceValueHistory.DataSource = ac_CompanyInformation.dt_FaceValueHistory;
                faceValPopupUC.gvCIFaceValueHistory.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view page index change event
        /// </summary>
        /// <param name="faceValPopupUC">FaceValPopupUC control object</param>
        /// <param name="NewPageIndex">new page index</param>
        public void gvCIFaceValueCurrentPageIndexChang(FaceValPopupUC faceValPopupUC, int NewPageIndex)
        {
            try
            {
                faceValPopupUC.gvCIFaceValueCurrent.PageIndex = NewPageIndex;
                faceValPopupUC.gvCIFaceValueCurrent.DataSource = ac_CompanyInformation.dt_CurrentFaceValue;
                faceValPopupUC.gvCIFaceValueCurrent.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to update face value
        /// </summary>
        /// <param name="faceValPopupUC">FaceValPopupUC control object</param>
        /// <param name="s_Type">div type</param>
        /// <param name="s_Action">CUD action</param>
        /// <returns>returns 1 for insert, 2 for update and 3 for delete opration</returns>
        public int UpdateFaceValue(FaceValPopupUC faceValPopupUC, string s_Type, string s_Action)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties = new ValuationProperties();
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_CompanyInformation;
                    valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                    valuationProperties.PopulateControls = s_Type;
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationProperties.ModifiedBy = userSessionInfo.ACC_UserID;

                    if (!string.IsNullOrEmpty(faceValPopupUC.hdnCIFaceValID.Value.Trim()) && Convert.ToInt32(faceValPopupUC.hdnCIFaceValID.Value) > 0)
                    {
                        valuationProperties.FVID = Convert.ToInt32(faceValPopupUC.hdnCIFaceValID.Value);
                        valuationProperties.Action = "U";
                    }

                    if (s_Action.Equals("D"))
                        valuationProperties.Action = s_Action;
                    else
                    {
                        valuationProperties.CI_FROM_DATE = (string.IsNullOrEmpty(faceValPopupUC.txtCIFaceValFromDate.Text) || faceValPopupUC.txtCIFaceValFromDate.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(faceValPopupUC.txtCIFaceValFromDate.Text).ToString("MM/dd/yyyy");
                        valuationProperties.CI_FACE_VALUE = Convert.ToDecimal(faceValPopupUC.txtCIFaceValue.Text);
                        valuationProperties.CMID = userSessionInfo.ACC_CMID;
                        valuationProperties.CRMID = faceValPopupUC.ddlCIFVCurrency.SelectedItem.Value;
                    }

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    faceValPopupUC.hdnCIFaceValID.Value = "0";
                    return valuationCRUDProperties.a_result;
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Share Cap

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindCIShareCap(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SCID":
                                    perColumn.Visible = false;
                                    break;
                                case "TO DATE":
                                    perColumn.Visible = false;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[4].Visible = e.Row.Cells[1].Visible = false;
                        e.Row.Cells[0].HorizontalAlign = e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;

                        if (!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                            e.Row.Cells[0].Text = Convert.ToDateTime(e.Row.Cells[0].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        e.Row.Cells[3].Controls.Add((Control)AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[1].Text, e.Row.Cells[2].Text, e.Row.Cells[4].Text, "Share_Cap", "", ""));
                        e.Row.Cells[3].Controls.Add((Control)AddImageLink("Delete", "~/View/App_Themes/images/Delete.png", e.Row.Cells[0].Text, e.Row.Cells[1].Text, e.Row.Cells[2].Text, e.Row.Cells[4].Text, "Share_Cap", "", ""));

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            e.Row.Cells[2].Text = Convert.ToDouble(e.Row.Cells[2].Text) > 999 ? CommonModel.ThousandFormating(e.Row.Cells[2].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : e.Row.Cells[2].Text;
                        }
                        #endregion
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindCIShareCapHistory(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.DataRow:
                        e.Row.Cells[0].HorizontalAlign = e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;

                        if (!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                            e.Row.Cells[0].Text = Convert.ToDateTime(e.Row.Cells[0].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        #region Below code does decimal rounding , Thousand separating and aligns to the right.
                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            e.Row.Cells[2].Text = Convert.ToDouble(e.Row.Cells[2].Text) > 999 ? CommonModel.ThousandFormating(e.Row.Cells[2].Text, DecimalLimitTable.Select("ADVSID = 12")[0]["ROUNDING_PLACE_VALUE"].ToString()) : e.Row.Cells[2].Text;
                        }
                        #endregion
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// grid view page index change event
        /// </summary>
        /// <param name="shareCapPopupUC">ShareCapPopupUC control object</param>
        /// <param name="NewPageIndex">new page index</param>
        public void gvCIShareCapPageIndexChang(ShareCapPopupUC shareCapPopupUC, int NewPageIndex)
        {
            try
            {
                shareCapPopupUC.gvCIShareCapHistory.PageIndex = NewPageIndex;
                shareCapPopupUC.gvCIShareCapHistory.DataSource = ac_CompanyInformation.dt_ShareCapHistory;
                shareCapPopupUC.gvCIShareCapHistory.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// grid view page index change event
        /// </summary>
        /// <param name="shareCapPopupUC">ShareCapPopupUC control object</param>
        /// <param name="NewPageIndex">new page index</param>
        public void gvCICurrentShareCapPageIndexChang(ShareCapPopupUC shareCapPopupUC, int NewPageIndex)
        {
            try
            {
                shareCapPopupUC.gvCIShareCap.PageIndex = NewPageIndex;
                shareCapPopupUC.gvCIShareCap.DataSource = ac_CompanyInformation.dt_CurrentShareCap;
                shareCapPopupUC.gvCIShareCap.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to update Share Capital
        /// </summary>
        /// <param name="shareCapPopupUC">ShareCapPopupUC control object</param>
        /// <param name="s_Type">div type</param>
        /// <param name="s_Action">CUD action</param>
        /// <returns>returns 1 for insert, 2 for update and 3 for delete opration</returns>
        public int UpdateShareCapital(ShareCapPopupUC shareCapPopupUC, string s_Type, string s_Action)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties = new ValuationProperties();
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_CompanyInformation;
                    valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                    valuationProperties.PopulateControls = s_Type;
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationProperties.ModifiedBy = userSessionInfo.ACC_UserID;

                    if (!string.IsNullOrEmpty(shareCapPopupUC.hdnCIShareCapID.Value.Trim()) && Convert.ToInt32(shareCapPopupUC.hdnCIShareCapID.Value) > 0)
                    {
                        valuationProperties.SCID = Convert.ToInt32(shareCapPopupUC.hdnCIShareCapID.Value);
                        valuationProperties.Action = "U";
                    }

                    if (s_Action.Equals("D"))
                        valuationProperties.Action = s_Action;
                    else
                    {
                        valuationProperties.CI_FROM_DATE = (string.IsNullOrEmpty(shareCapPopupUC.txtCISharesFromDate.Text) || shareCapPopupUC.txtCISharesFromDate.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(shareCapPopupUC.txtCISharesFromDate.Text).ToString("MM/dd/yyyy");
                        valuationProperties.CI_SHARE_CAPITAL = Convert.ToDecimal(shareCapPopupUC.txtCIShareCap.Text);
                        valuationProperties.CMID = userSessionInfo.ACC_CMID;
                    }

                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    shareCapPopupUC.hdnCIShareCapID.Value = "0";
                    return valuationCRUDProperties.a_result;
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~CompanyInfoPopupModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}