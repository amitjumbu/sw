﻿using EDFinancials.Model.Generic;
using EDFinancials.View.Valuation;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Valuation Parameters setup common class
    /// </summary>
    public class VPSCommonModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public VPSCommonModel()
        {
            if (ac_ValuationParameter == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationParameter);
                ac_ValuationParameter = (CommonModel.AC_ValuationParameter)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationParameter];
            }
        }

        #region Common Methods

        /// <summary>
        /// Method is used to show/hide msg div 
        /// </summary>
        /// <param name="b_IsVisible">boolean input parameter for message div visibility</param>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        /// <param name="s_Msg">msg text to display</param>
        /// <param name="s_Type">msg text to display</param>
        /// <param name="n_RetValue">return value</param>
        public void ShowHideMsgDiv(bool b_IsVisible, ValuationParameters valuationParametersSetup, string s_Msg, string s_Type, int n_RetValue)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationParametersSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    if (b_IsVisible)
                    {
                        switch (n_RetValue)
                        {
                            case 1: valuationParametersSetup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N(s_Msg, CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                                valuationParametersSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                valuationParametersSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                break;
                            case 5: valuationParametersSetup.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblVPSCanNotEditSettings", CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10);
                                valuationParametersSetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                valuationParametersSetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                break;
                        }
                    }
                    switch (s_Type)
                    {
                        case "MPC_IV":
                            valuationParametersSetup.ctrMarketPrice.trVPSIntriValue.Style.Add("display", "");
                            valuationParametersSetup.ctrMarketPrice.imgIVHideShow.Attributes.Add("title", "Click here to collapse");
                            valuationParametersSetup.ctrMarketPrice.imgIVHideShow.Attributes.Add("src", "~/View/App_Themes/images/up.png");
                            break;
                        case "MPC_FV":
                            valuationParametersSetup.ctrMarketPrice.trVPSFairValue.Style.Add("display", "");
                            valuationParametersSetup.ctrMarketPrice.imgFVHideShow.Attributes.Add("title", "Click here to collapse");
                            valuationParametersSetup.ctrMarketPrice.imgFVHideShow.Attributes.Add("src", "~/View/App_Themes/images/up.png");
                            break;
                        case "VS_EXCLUDEVOL":
                            valuationParametersSetup.ctrVolatility.divVPSVolExcludeVol.Style.Add("display", "");
                            valuationParametersSetup.ctrVolatility.chkVPSVolExcludeVol.Attributes.Add("title", "Click here to collapse");
                            valuationParametersSetup.ctrVolatility.chkVPSVolExcludeVol.Attributes.Add("src", "~/View/App_Themes/images/up.png");
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_ConfigID">Config ID</param>
        /// <param name="s_FromDate">From Date</param>
        /// <param name="s_ToDate">To Date</param>
        /// <param name="s_Type">Type</param>
        /// <returns>Returns control HyperLink</returns>
        public HyperLink AddHistoryHyperLink(string s_ConfigID, string s_FromDate, string s_ToDate, string s_Type)
        {
            using (HyperLink hyperLink = new HyperLink())
            {
                hyperLink.Text = "View History";
                hyperLink.ToolTip = "Click here to view history data";
                hyperLink.ID = "hypHistory";
                hyperLink.ClientIDMode = ClientIDMode.Static;
                hyperLink.CssClass = "cHyperLinksp";
                hyperLink.TabIndex = 9;
                hyperLink.Attributes.Add("onclick", "return ViewHistoryData('" + s_ConfigID + "','" + s_FromDate.Trim() + "','" + s_ToDate.Trim() + "','" + s_Type + "')");
                return hyperLink;
            }
        }

        /// <summary>
        /// This method is used to add image link to gridview rows
        /// </summary>
        /// <param name="s_Text">Text</param>
        /// <param name="s_FilePath">File path</param>
        /// <returns>Returns control HyperLink</returns>
        public HyperLink AddHyperLink(string s_Text, string s_FilePath)
        {
            using (HyperLink hyperLink = new HyperLink())
            {
                hyperLink.Text = s_Text.Trim();
                hyperLink.ToolTip = "Click here to download";
                hyperLink.ID = "hypDownload";
                hyperLink.ClientIDMode = ClientIDMode.Static;
                hyperLink.CssClass = "cHyperLinksp";
                hyperLink.TabIndex = 8;
                s_FilePath = s_FilePath.Replace("\\", "~");
                hyperLink.Attributes.Add("onclick", "return DownloadFileFromServer('" + s_FilePath + "','" + s_Text + "')");
                return hyperLink;
            }
        }

        /// <summary>
        /// Method is used to bind history data to grid
        /// </summary>
        /// <param name="s_ConfigID">ConfigID as a input parameter</param>
        /// <param name="s_Type">CUD action type</param>
        /// <returns>returns 1 for insert, 2 for update and 3 for delete opration</returns>
        public ValuationProperties[] BindHistoryGridByID(object s_ConfigID, object s_Type)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    if (s_Type.Equals("MPC_IV") || s_Type.Equals("MPC_FV"))
                        s_Type = "MPC";

                    List<ValuationProperties> details = new List<ValuationProperties>();
                    valuationProperties = new ValuationProperties();
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    valuationProperties.CONFIG_ID = Convert.ToInt32(s_ConfigID);
                    valuationProperties.CONFIG_TYPE = Convert.ToString(s_Type);
                    valuationProperties.PopulateControls = "HISTORYDATA";
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    foreach (DataRow dtrow in valuationCRUDProperties.dt_Result.Rows)
                    {
                        valuationProperties = new ValuationProperties();

                        switch (Convert.ToString(s_Type))
                        {
                            case "MPC":
                                valuationProperties.MPC_STOCK_EX_LABEL_ID = Convert.ToString(dtrow["Stock Exchange"]);
                                valuationProperties.MPC_STOCKEXCHANGE = Convert.ToString(dtrow["SHORT_NAME"]);
                                valuationProperties.MPC_MARKET_PRICE_DT_LABEL_ID = Convert.ToString(dtrow["Date of Market Price"]);
                                valuationProperties.MPC_REMARK = Convert.ToString(dtrow["Remark"]);
                                valuationProperties.MPC_APPLICABLE_FROM_DATE = !string.IsNullOrEmpty(Convert.ToString(dtrow["Applicable From Date"])) ? Convert.ToDateTime(dtrow["Applicable From Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                                valuationProperties.MPC_TO_DATE = !string.IsNullOrEmpty(Convert.ToString(dtrow["To Date"])) ? Convert.ToDateTime(dtrow["To Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                                valuationProperties.MPC_IS_APPROVED = Convert.ToBoolean(dtrow["Status"]);

                                if (!string.IsNullOrEmpty(valuationProperties.MPC_STOCK_EX_LABEL_ID.Trim()) && !valuationProperties.MPC_STOCK_EX_LABEL_ID.Trim().Equals("&nbsp;"))
                                {
                                    if (valuationProperties.MPC_STOCK_EX_LABEL_ID.Trim().Equals("lblIVSE01") || valuationProperties.MPC_STOCK_EX_LABEL_ID.Trim().Equals("lblFVSE01"))
                                        valuationProperties.MPC_STOCK_EX_LABEL_ID = valuationProperties.MPC_STOCKEXCHANGE;
                                    else
                                        valuationProperties.MPC_STOCK_EX_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.MPC_STOCK_EX_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]); ;
                                }
                                else
                                    valuationProperties.MPC_STOCK_EX_LABEL_ID = "NA";

                                if (!string.IsNullOrEmpty(valuationProperties.MPC_MARKET_PRICE_DT_LABEL_ID) && !valuationProperties.MPC_MARKET_PRICE_DT_LABEL_ID.Equals("&nbsp;"))
                                    valuationProperties.MPC_MARKET_PRICE_DT_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.MPC_MARKET_PRICE_DT_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]);
                                else
                                    valuationProperties.MPC_MARKET_PRICE_DT_LABEL_ID = "NA";
                                break;

                            case "ELC":
                                valuationProperties.ELC_CAL_METHOD_LABEL_ID = Convert.ToString(dtrow["Method for Calculating Expected Life"]);
                                valuationProperties.ELC_CONSIDER_PERIOD_IN = Convert.ToString(dtrow["CONSIDER_PERIOD_IN"]);
                                if (!string.IsNullOrEmpty(Convert.ToString(dtrow["CONSIDER_VALUE"])))
                                    valuationProperties.ELC_CONSIDER_VALUE = Math.Round(Convert.ToDecimal(dtrow["CONSIDER_VALUE"]), 2);
                                valuationProperties.ELC_REMARK = Convert.ToString(dtrow["Remark"]);
                                valuationProperties.ELC_APPLICABLE_FROM_DATE = !string.IsNullOrEmpty(Convert.ToString(dtrow["Applicable From Date"])) ? Convert.ToDateTime(dtrow["Applicable From Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                                valuationProperties.ELC_TO_DATE = !string.IsNullOrEmpty(Convert.ToString(dtrow["To Date"])) ? Convert.ToDateTime(dtrow["To Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                                valuationProperties.ELC_IS_APPROVED = Convert.ToBoolean(dtrow["Status"]);

                                if (!string.IsNullOrEmpty(valuationProperties.ELC_CAL_METHOD_LABEL_ID) && !valuationProperties.ELC_CAL_METHOD_LABEL_ID.Equals("&nbsp;"))
                                {
                                    if (valuationProperties.ELC_CAL_METHOD_LABEL_ID.Trim().Equals("lblMCEL03") || valuationProperties.ELC_CAL_METHOD_LABEL_ID.Trim().Equals("lblMCEL02"))
                                    {
                                        if (valuationProperties.ELC_CONSIDER_PERIOD_IN.Trim().Equals("Y"))
                                            valuationProperties.ELC_CAL_METHOD_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.ELC_CAL_METHOD_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + valuationProperties.ELC_CONSIDER_VALUE.ToString("#0.00") + " Year(s)";
                                        else if (valuationProperties.ELC_CONSIDER_PERIOD_IN.Trim().Equals("M"))
                                            valuationProperties.ELC_CAL_METHOD_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.ELC_CAL_METHOD_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToInt32(valuationProperties.ELC_CONSIDER_VALUE) + " Month(s)";
                                        else if (valuationProperties.ELC_CONSIDER_PERIOD_IN.Trim().Equals("D"))
                                            valuationProperties.ELC_CAL_METHOD_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.ELC_CAL_METHOD_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToInt32(valuationProperties.ELC_CONSIDER_VALUE) + " Day(s)";
                                    }
                                    else if (valuationProperties.ELC_CAL_METHOD_LABEL_ID.Trim().Equals("lblMCEL04"))
                                    {
                                        valuationProperties.ELC_CAL_METHOD_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.ELC_CAL_METHOD_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + ((!string.IsNullOrEmpty(Convert.ToString(dtrow["EST_DATE_OF_LISTING"]))) ? Convert.ToDateTime(dtrow["EST_DATE_OF_LISTING"]).ToString("dd/MMM/yyyy") : string.Empty);
                                    }
                                    else
                                        valuationProperties.ELC_CAL_METHOD_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.ELC_CAL_METHOD_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]);
                                }

                                valuationProperties.ELC_FILE_PATH = Convert.ToString(dtrow["FILE_PATH"]).Replace("\\", "~");
                                valuationProperties.ELC_FILE_NAME = Convert.ToString(dtrow["FILE_NAME"]);
                                break;

                            case "VC":
                                valuationProperties.VC_VOLATILITY_OF_LABEL_ID = Convert.ToString(dtrow["Volatility of"]);
                                valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID = Convert.ToString(dtrow["Market Price to Calculate Volatility"]);
                                valuationProperties.VC_TRADING_DAYS_LABEL_ID = Convert.ToString(dtrow["TRADING_DAYS_LABEL_ID"]);
                                if (!string.IsNullOrEmpty(Convert.ToString(dtrow["TRADING_DAYS"])))
                                    valuationProperties.VC_TRADING_DAYS = Convert.ToDecimal(dtrow["TRADING_DAYS"]);
                                valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID = Convert.ToString(dtrow["Periods to Calculate Volatility"]);
                                valuationProperties.VC_CONSIDER_PERIOD_IN = Convert.ToString(dtrow["CONSIDER_PERIOD_IN"]);
                                if (!string.IsNullOrEmpty(Convert.ToString(dtrow["CONSIDER_VALUE"])))
                                    valuationProperties.VC_CONSIDER_VALUE = Math.Round(Convert.ToDecimal(dtrow["CONSIDER_VALUE"]), 2);
                                valuationProperties.VC_REMARK = Convert.ToString(dtrow["Remark"]);
                                valuationProperties.VC_SHORT_NAME = Convert.ToString(dtrow["SHORT_NAME"]);
                                valuationProperties.VC_APPLICABLE_FROM_DATE = !string.IsNullOrEmpty(Convert.ToString(dtrow["Applicable From Date"])) ? Convert.ToDateTime(dtrow["Applicable From Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                                valuationProperties.VC_TO_DATE = !string.IsNullOrEmpty(Convert.ToString(dtrow["To Date"])) ? Convert.ToDateTime(dtrow["To Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                                valuationProperties.VC_IS_APPROVED = Convert.ToBoolean(dtrow["Status"]);

                                if (!string.IsNullOrEmpty(valuationProperties.VC_VOLATILITY_OF_LABEL_ID) && !valuationProperties.VC_VOLATILITY_OF_LABEL_ID.Equals("&nbsp;"))
                                {
                                    if (valuationProperties.VC_VOLATILITY_OF_LABEL_ID.Trim().Equals("lblVOL01") && !string.IsNullOrEmpty(valuationProperties.VC_SHORT_NAME))
                                        valuationProperties.VC_VOLATILITY_OF_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_VOLATILITY_OF_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + valuationProperties.VC_SHORT_NAME;
                                    else
                                        valuationProperties.VC_VOLATILITY_OF_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_VOLATILITY_OF_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]);
                                }

                                if (!string.IsNullOrEmpty(valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID) && !valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID.Equals("&nbsp;"))
                                {
                                    if (valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID.Trim().Equals("lblMPTCV01"))
                                    {
                                        if (valuationProperties.VC_TRADING_DAYS_LABEL_ID.Trim().Equals("lblTDD03"))
                                        {
                                            valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToDecimal(valuationProperties.VC_TRADING_DAYS).ToString("N0") + " Day(s)";
                                        }
                                        else valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_TRADING_DAYS_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " Day(s)";
                                    }
                                    //else if (valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID.Trim().Equals("lblMPTCV02"))
                                    //{
                                    //    if (valuationProperties.VC_TRADING_DAYS_LABEL_ID.Trim().Equals("lblTDW02"))
                                    //        valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToDecimal(valuationProperties.VC_TRADING_DAYS).ToString("N0") + " Day(s)";
                                    //    else valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToString((CommonModel.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_TRADING_DAYS_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " Day(s)";
                                    //}
                                    //else if (valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID.Trim().Equals("lblMPTCV03"))
                                    //{
                                    //    if (valuationProperties.VC_TRADING_DAYS_LABEL_ID.Trim().Equals("lblTDA02"))
                                    //        valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToDecimal(valuationProperties.VC_TRADING_DAYS).ToString("N0") + " Day(s)";
                                    //    else valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_MP_CALC_VOLATILITY_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + Convert.ToString((CommonModel.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_TRADING_DAYS_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " Day(s)";
                                    //}
                                }

                                if (!string.IsNullOrEmpty(valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID) && !valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID.Equals("&nbsp;"))
                                {
                                    if (valuationProperties.VC_CONSIDER_PERIOD_IN.Trim().Equals("Y"))
                                        valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID = valuationProperties.VC_CONSIDER_VALUE.ToString("#0.00") + " Year(s)";
                                    else if (valuationProperties.VC_CONSIDER_PERIOD_IN.Trim().Equals("M"))
                                        valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID = Convert.ToInt32(valuationProperties.VC_CONSIDER_VALUE) + " Month(s)";
                                    else if (valuationProperties.VC_CONSIDER_PERIOD_IN.Trim().Equals("D"))
                                        valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID = Convert.ToInt32(valuationProperties.VC_CONSIDER_VALUE) + " Day(s)";
                                    else valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.VC_PRD_CALC_VOLATILITY_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]);
                                }
                                break;

                            case "DC":
                                valuationProperties.DC_DIVIDEND_LABEL_ID = Convert.ToString(dtrow["Dividend"]);
                                if (!string.IsNullOrEmpty(Convert.ToString(dtrow["NO_OF_YEARS"])))
                                    valuationProperties.DC_NO_OF_YEARS = Math.Round(Convert.ToDecimal(dtrow["NO_OF_YEARS"]), 2);
                                valuationProperties.DC_MP_TO_CAL_DIVIDEND_LABEL_ID = Convert.ToString(dtrow["Market Price to Calculate Dividend Yield"]);
                                valuationProperties.DC_IS_APPROVED = Convert.ToBoolean(dtrow["Status"]);

                                if (Convert.ToString(dtrow["SPECIAL_DIVIDEND"]).Equals("1"))
                                    valuationProperties.DC_SPECIAL_DIVIDEND = "Yes";
                                else
                                    valuationProperties.DC_SPECIAL_DIVIDEND = "No";

                                valuationProperties.DC_REMARK = Convert.ToString(dtrow["Remark"]);
                                valuationProperties.DC_SHORT_NAME = Convert.ToString(dtrow["SHORT_NAME"]);
                                valuationProperties.DC_APPLICABLE_FROM_DATE = !string.IsNullOrEmpty(Convert.ToString(dtrow["Applicable From Date"])) ? Convert.ToDateTime(dtrow["Applicable From Date"]).ToString("dd/MMM/yyyy") : string.Empty;
                                valuationProperties.DC_TO_DATE = !string.IsNullOrEmpty(Convert.ToString(dtrow["To Date"])) ? Convert.ToDateTime(dtrow["To Date"]).ToString("dd/MMM/yyyy") : string.Empty;

                                if (!string.IsNullOrEmpty(valuationProperties.DC_DIVIDEND_LABEL_ID) && !valuationProperties.DC_DIVIDEND_LABEL_ID.Equals("&nbsp;"))
                                {
                                    if (valuationProperties.DC_DIVIDEND_LABEL_ID.Trim().Equals("lblDIV03"))
                                        valuationProperties.DC_DIVIDEND_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.DC_DIVIDEND_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : Last " + valuationProperties.DC_NO_OF_YEARS + " Year(s)";
                                    else if (valuationProperties.DC_DIVIDEND_LABEL_ID.Trim().Equals("lblDIV04"))
                                    {
                                        StringBuilder s_IncorporateDetails = new StringBuilder();
                                        if (ac_ValuationParameter.dt_IncorpDividendDetails.Select("ADCID = '" + Convert.ToString(dtrow["ADCAID"]).Trim() + "'").Count() > 0)
                                        {
                                            ac_ValuationParameter.dt_IncorpDetails = ac_ValuationParameter.dt_IncorpDividendDetails.Select("ADCID = '" + Convert.ToString(dtrow["ADCAID"]).Trim() + "'").CopyToDataTable();
                                            if (ac_ValuationParameter.dt_IncorpDetails.Rows.Count > 0)
                                            {
                                                foreach (DataRow dr_Row in ac_ValuationParameter.dt_IncorpDetails.Rows)
                                                {
                                                    if (s_IncorporateDetails.Length.Equals(0))
                                                        s_IncorporateDetails.Append("</br>" + Convert.ToString(dr_Row["Dividend"]) + " ( " + Convert.ToDateTime(dr_Row["From Date"]).ToString("dd/MMM/yyyy") + " - " + Convert.ToDateTime(dr_Row["To Date"]).ToString("dd/MMM/yyyy") + " )");
                                                    else
                                                        s_IncorporateDetails.Append("</br>" + Convert.ToString(dr_Row["Dividend"]) + " ( " + Convert.ToDateTime(dr_Row["From Date"]).ToString("dd/MMM/yyyy") + " - " + Convert.ToDateTime(dr_Row["To Date"]).ToString("dd/MMM/yyyy") + " )");
                                                }
                                            }
                                        }
                                        valuationProperties.DC_DIVIDEND_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.DC_DIVIDEND_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]);
                                        if (s_IncorporateDetails.Length > 0)
                                            valuationProperties.DC_DIVIDEND_LABEL_ID += " : " + s_IncorporateDetails;
                                        s_IncorporateDetails.Clear();
                                    }
                                    else valuationProperties.DC_DIVIDEND_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.DC_DIVIDEND_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]);
                                }
                                if (!string.IsNullOrEmpty(valuationProperties.DC_MP_TO_CAL_DIVIDEND_LABEL_ID) && !valuationProperties.DC_MP_TO_CAL_DIVIDEND_LABEL_ID.Equals("&nbsp;"))
                                {
                                    if (valuationProperties.DC_MP_TO_CAL_DIVIDEND_LABEL_ID.Trim().Equals("lblMPTCD02") && !string.IsNullOrEmpty(valuationProperties.DC_SHORT_NAME))
                                        valuationProperties.DC_MP_TO_CAL_DIVIDEND_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.DC_MP_TO_CAL_DIVIDEND_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]) + " : " + valuationProperties.DC_SHORT_NAME;
                                    else
                                        valuationProperties.DC_MP_TO_CAL_DIVIDEND_LABEL_ID = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + valuationProperties.DC_MP_TO_CAL_DIVIDEND_LABEL_ID.Trim() + "'" + ""))[0]["LabelName"]);
                                }
                                break;
                        }
                        details.Add(valuationProperties);
                    }
                    return details.ToArray();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method auto populates the file names 
        /// </summary>
        /// <param name="fileName">fileName as a input parameter</param>
        /// <returns>returns list object</returns>
        public List<string> RFIRFileName(string fileName)
        {
            try
            {
                List<string> o_FileNameList = new List<string>();

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    valuationProperties.PopulateControls = "FILENAMES";
                    valuationProperties.FILE_NAME = fileName;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    int i = 0;

                    foreach (DataRow row in valuationCRUDProperties.dt_Result.Rows)
                    {
                        o_FileNameList.Add(valuationCRUDProperties.dt_Result.Rows[i][0].ToString());
                        i = i + 1;
                    }
                }
                return o_FileNameList;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to rebind all the grids on postback
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        /// <param name="b_IsPageIndChange">boolean value as a input parameter</param>
        /// <param name="s_CtrName">User control name</param>
        public void ReBindGridsOnPostBack(ValuationParameters valuationParametersSetup, bool b_IsPageIndChange, string s_CtrName)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    valuationProperties.PopulateControls = CommonConstantModel.s_OperationRead;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    ac_ValuationParameter.ds_ValuationParameters = (DataSet)valuationCRUDProperties.ds_Result;

                    if (s_CtrName.Equals("VS_EXCLUDEVOL"))
                    {
                        ac_ValuationParameter.dt_VolExcludeDetails = ac_ValuationParameter.ds_ValuationParameters.Tables[11];
                        valuationParametersSetup.ctrVolatility.gvVPSExcludeVolDetails.DataSource = ac_ValuationParameter.dt_VolExcludeDetails;
                        valuationParametersSetup.ctrVolatility.gvVPSExcludeVolDetails.DataBind();
                    }
                    /* IV */
                    if (b_IsPageIndChange && s_CtrName.Equals("MPC_IV"))
                    { }
                    else
                    {
                        ac_ValuationParameter.dt_MarketPriceIV = ac_ValuationParameter.ds_ValuationParameters.Tables[1];
                        valuationParametersSetup.ctrMarketPrice.gvMarketPriceIV.DataSource = ac_ValuationParameter.dt_MarketPriceIV;
                        valuationParametersSetup.ctrMarketPrice.gvMarketPriceIV.DataBind();
                    }
                    /* FV */
                    if (b_IsPageIndChange && s_CtrName.Equals("MPC_FV"))
                    { }
                    else
                    {
                        ac_ValuationParameter.dt_MarketPriceFV = ac_ValuationParameter.ds_ValuationParameters.Tables[3];
                        valuationParametersSetup.ctrMarketPrice.gvMarketPriceFV.DataSource = ac_ValuationParameter.dt_MarketPriceFV;
                        valuationParametersSetup.ctrMarketPrice.gvMarketPriceFV.DataBind();
                    }

                    /* Expected Life */
                    if (b_IsPageIndChange && s_CtrName.Equals("ELC"))
                    { }
                    else
                    {
                        ac_ValuationParameter.dt_ExpectedLife = ac_ValuationParameter.ds_ValuationParameters.Tables[5];
                        valuationParametersSetup.ctrExpectedLife.gvExpectedLife.DataSource = ac_ValuationParameter.dt_ExpectedLife;
                        valuationParametersSetup.ctrExpectedLife.gvExpectedLife.DataBind();
                        ac_ValuationParameter.dt_CurrEstimatedDOLDetails = ac_ValuationParameter.ds_ValuationParameters.Tables[15];
                        valuationParametersSetup.ctrExpectedLife.gvVPSCurrEstDtOfListing.DataSource = ac_ValuationParameter.dt_CurrEstimatedDOLDetails;
                        valuationParametersSetup.ctrExpectedLife.gvVPSCurrEstDtOfListing.DataBind();
                        valuationParametersSetup.ctrExpectedLife.hdnVPSELEstDateOfListing.Value = (ac_ValuationParameter.ds_ValuationParameters.Tables[13].Rows.Count > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[13].Rows[0]["ESTIMATED_DATE_OF_LISTING"]))) ? Convert.ToDateTime(ac_ValuationParameter.ds_ValuationParameters.Tables[13].Rows[0]["ESTIMATED_DATE_OF_LISTING"]).ToString("dd/MMM/yyyy") : string.Empty;
                    }
                    /* Volatility */
                    if (b_IsPageIndChange && s_CtrName.Equals("VC"))
                    { }
                    else
                    {
                        ac_ValuationParameter.dt_Volatility = ac_ValuationParameter.ds_ValuationParameters.Tables[7];
                        valuationParametersSetup.ctrVolatility.gvVolatility.DataSource = ac_ValuationParameter.dt_Volatility;
                        valuationParametersSetup.ctrVolatility.gvVolatility.DataBind();

                        if (ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows.Count <= 0)
                        {
                            valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.ClearSelection();

                            if (Convert.ToInt32(valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.SelectedItem.Value) > 0)
                                valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Items.FindByValue(valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.SelectedItem.Value).Selected = true;
                            else if (valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Items.FindByText("NSE") != null)
                                valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.Items.FindByText("NSE").Selected = true;
                        }
                    }
                    /* Dividend */
                    if (b_IsPageIndChange && s_CtrName.Equals("DC"))
                    { }
                    else
                    {
                        using (DividendUCModel dividendUCModel = new DividendUCModel())
                        {
                            if (s_CtrName.Equals("IncorpDividend"))
                                dividendUCModel.BindDividendControls(ac_ValuationParameter.ds_ValuationParameters, valuationParametersSetup, string.Empty, "ReBind", string.Empty);
                            else dividendUCModel.BindDividendControls(ac_ValuationParameter.ds_ValuationParameters, valuationParametersSetup, string.Empty, "", string.Empty);
                        }
                        if (ac_ValuationParameter.ds_ValuationParameters.Tables[8].Rows.Count <= 0)
                        {
                            valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.ClearSelection();
                            if (Convert.ToInt32(valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.SelectedItem.Value) > 0)
                                valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Items.FindByValue(valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.SelectedItem.Value).Selected = true;
                            else if (valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Items.FindByText("NSE") != null)
                                valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Items.FindByText("NSE").Selected = true;
                        }
                    }
                    /* RFIR */
                    if (valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.SelectedItem.Value.Equals("0"))
                    { }
                    else
                    {
                        bool isIndia = (string.IsNullOrEmpty(valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.SelectedItem.Value) || valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.SelectedItem.Value.Equals("0") || valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.SelectedItem.Value.ToUpper().Equals("INDIA")) ? true : false;

                        using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                        {
                            if (isIndia)
                                superAdminProperties.FILE_NAME = valuationParametersSetup.ctrRiskFreeInterestRate.txtVPSRFIRFileName.Text.Trim();
                            superAdminProperties.FROM_DATE = (string.IsNullOrEmpty(valuationParametersSetup.ctrRiskFreeInterestRate.txtVPSRFIRFromDate.Text) || valuationParametersSetup.ctrRiskFreeInterestRate.txtVPSRFIRFromDate.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(valuationParametersSetup.ctrRiskFreeInterestRate.txtVPSRFIRFromDate.Text).ToString("MM/dd/yyyy");
                            superAdminProperties.TO_DATE = (string.IsNullOrEmpty(valuationParametersSetup.ctrRiskFreeInterestRate.txtVPSRFIRToDate.Text) || valuationParametersSetup.ctrRiskFreeInterestRate.txtVPSRFIRToDate.Text.Equals("dd/mmm/yyyy")) ? string.Empty : Convert.ToDateTime(valuationParametersSetup.ctrRiskFreeInterestRate.txtVPSRFIRToDate.Text).ToString("MM/dd/yyyy");

                            superAdminProperties.COUNTRY_NAME = valuationParametersSetup.ctrRiskFreeInterestRate.ddlVPSRFIRCountryList.SelectedItem.Value.ToUpper();
                            superAdminProperties.PageName = CommonConstantModel.s_ManageRFIR;
                            superAdminProperties.Operation = CommonConstantModel.s_OperationRead;
                            superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                            superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                            ac_ValuationParameter.dt_RFIRDetails = superAdminCRUDProperties.dt_Result;

                            valuationParametersSetup.ctrRiskFreeInterestRate.gvVPSRFIR.DataSource = ac_ValuationParameter.dt_RFIRDetails;
                            valuationParametersSetup.ctrRiskFreeInterestRate.gvVPSRFIR.DataBind();

                            valuationParametersSetup.ctrRiskFreeInterestRate.divVPSRFIRGrid.Style.Add("display", "");
                            valuationParametersSetup.ctrRiskFreeInterestRate.btnRFIRClearFilter.Style.Add("display", "");
                        }
                    }
                    if (ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows.Count > 0)
                        valuationParametersSetup.ctrVolatility.hdnVPS_IsApproved_VC.Value = Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[6].Rows[0]["IS_APPROVED"]);
                    if (ac_ValuationParameter.ds_ValuationParameters.Tables[8].Rows.Count > 0)
                        valuationParametersSetup.ctrDividend.hdnVPS_IsApproved_DC.Value = Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[8].Rows[0]["IS_APPROVED"]);
                    if (ac_ValuationParameter.ds_ValuationParameters.Tables[4].Rows.Count > 0)
                        valuationParametersSetup.ctrExpectedLife.hdnVPS_IsApproved_ELC.Value = Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[4].Rows[0]["IS_APPROVED"]);
                    if (ac_ValuationParameter.ds_ValuationParameters.Tables[0].Rows.Count > 0)
                        valuationParametersSetup.ctrMarketPrice.hdnVPS_IsApproved_IV.Value = Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[0].Rows[0]["IS_APPROVED"]);
                    if (ac_ValuationParameter.ds_ValuationParameters.Tables[2].Rows.Count > 0)
                        valuationParametersSetup.ctrMarketPrice.hdnVPS_IsApproved_FV.Value = Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[2].Rows[0]["IS_APPROVED"]);

                    using (MarketPriceUCModel marketPriceUCModel = new MarketPriceUCModel())
                    {
                        marketPriceUCModel.SetApprovalHiddenField(valuationParametersSetup);
                    }
                    using (ExpectedLifeUCModel expectedLifeUCModel = new ExpectedLifeUCModel())
                    {
                        expectedLifeUCModel.SetApprovalHiddenField(valuationParametersSetup);
                    }
                    using (VolatilityUCModel volatilityUCModel = new VolatilityUCModel())
                    {
                        volatilityUCModel.SetApprovalHiddenField(valuationParametersSetup);
                    }
                    using (DividendUCModel dividendUCModel = new DividendUCModel())
                    {
                        dividendUCModel.SetApprovalHiddenField(valuationParametersSetup);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Used to bind tooltips to dropdown items
        /// </summary>
        /// <param name="list">ListControl object</param>
        public void BindToolTip(ListControl list)
        {
            try
            {
                foreach (ListItem item in list.Items)
                {
                    item.Attributes.Add("title", item.Text);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// THis method is used to trigger a mail to the reviewer
        /// </summary>
        /// <param name="s_Parameter"></param>
        public void SendMailForApproval(string s_Parameter)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_ValuationParameter.dt_ReviewerDetails = genericServiceClient.GetReviewerDetails(genericProperties);
                    string s_EmailIds = string.Empty;
                    if (ac_ValuationParameter.dt_ReviewerDetails.Rows.Count > 0)
                    {
                        int i = 0;
                        foreach (DataRow row in ac_ValuationParameter.dt_ReviewerDetails.Rows)
                        {
                            if (string.IsNullOrEmpty(s_EmailIds))
                                s_EmailIds = ac_ValuationParameter.dt_ReviewerDetails.Rows[i][0].ToString();
                            else s_EmailIds += ", " + ac_ValuationParameter.dt_ReviewerDetails.Rows[i][0].ToString();
                            i = i + 1;
                        }
                    }
                    var s_MailBody = File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\ReviewerApprovalMailAlert.html");
                    emailProperties.s_MailBody = s_MailBody.Replace("@UserName", userSessionInfo.ACC_UserName).Replace("@Company", userSessionInfo.ACC_CompanyTitle).Replace("@Database", userSessionInfo.ACC_CompanyName)
                        .Replace("@Parameter", s_Parameter).Replace("@Link", ConfigurationManager.AppSettings["SiteURL"]).Replace("@ValCustSupportID", ConfigurationManager.AppSettings["ValCustSupport"]);
                    string s_Subject = "@Company - Change in valuation parameter";
                    s_Subject = s_Subject.Replace("@Company", userSessionInfo.ACC_CompanyTitle);
                    emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                    emailProperties.b_IsBodyHtml = true;
                    emailProperties.s_MailTo = s_EmailIds;
                    emailProperties.s_MailCC = "";
                    emailProperties.s_MailBCC = "";
                    emailProperties.s_MailSubject = s_Subject;
                    genericServiceClient.SaveSendMail(emailProperties);
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="valuationParametersSetup"></param>
        /// <param name="s_GrantID"></param>
        public void BindValues(ValuationParameters valuationParametersSetup, string s_GrantID)
        {
            AddValuesToDataSet(valuationParametersSetup, s_GrantID);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="valuationParametersSetup"></param>
        /// <param name="s_GrantID"></param>
        private void AddValuesToDataSet(ValuationParameters valuationParametersSetup, string s_GrantID)
        {
            CompareGrantsUCModel _CompareGrantsUCModel = new CompareGrantsUCModel();
            _CompareGrantsUCModel.ac_ValuationReport.s_ChildPageName = "ValuationParameters";
            using (DataTable dt_Params = _CompareGrantsUCModel.ac_ValuationReport.ds_SelectedDataTables.Tables[s_GrantID])
            {
                if (dt_Params != null)
                {
                    dt_Params.TableName = s_GrantID;
                    switch (valuationParametersSetup.hdnSelectedTab.Value)
                    {
                        case "Market":
                            _CompareGrantsUCModel.ac_ValuationReport.ds_SelectedDataTables.Tables.Remove(s_GrantID);
                            _CompareGrantsUCModel.ac_ValuationReport.ds_SelectedDataTables.Tables.Add(MarketPrice(valuationParametersSetup, dt_Params));
                            break;

                        case "Expected":
                            _CompareGrantsUCModel.ac_ValuationReport.ds_SelectedDataTables.Tables.Remove(s_GrantID);
                            _CompareGrantsUCModel.ac_ValuationReport.ds_SelectedDataTables.Tables.Add(ExpectedLife(valuationParametersSetup, dt_Params));
                            break;

                        case "Volatility":
                            _CompareGrantsUCModel.ac_ValuationReport.ds_SelectedDataTables.Tables.Remove(s_GrantID);
                            _CompareGrantsUCModel.ac_ValuationReport.ds_SelectedDataTables.Tables.Add(Volatility(valuationParametersSetup, dt_Params));
                            break;

                        case "Dividend":
                            _CompareGrantsUCModel.ac_ValuationReport.ds_SelectedDataTables.Tables.Remove(s_GrantID);
                            _CompareGrantsUCModel.ac_ValuationReport.ds_SelectedDataTables.Tables.Add(Dividend(valuationParametersSetup, dt_Params));
                            break;
                    } 
                }
            }
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="valuationParametersSetup"></param>
        /// <param name="dt_Params"></param>
        /// <returns></returns>
        private DataTable MarketPrice(ValuationParameters valuationParametersSetup, DataTable dt_Params)
        {
            if (userSessionInfo.ACC_IsListed.Equals(1))
            {
                dt_Params.Rows[0]["Parameters at Grant Level"] = string.Empty;
                dt_Params.Rows[0]["ParamID"] = string.Empty;

                if (valuationParametersSetup.ctrMarketPrice.lblFVSE01.Checked)
                {
                    dt_Params.Rows[0]["ParamID"] = valuationParametersSetup.ctrMarketPrice.lblFVSE01.ID + ",";
                    dt_Params.Rows[0]["Parameters at Grant Level"] = "Stock Exchange: ";

                    dt_Params.Rows[0]["ParamID"] = Convert.ToString(dt_Params.Rows[0]["ParamID"] + valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.SelectedItem.Value) + ", ";
                    dt_Params.Rows[0]["Parameters at Grant Level"] = dt_Params.Rows[0]["Parameters at Grant Level"] + valuationParametersSetup.ctrMarketPrice.ddlFVStockExchange.SelectedItem.Text + ", ";
                }
                else
                {
                    dt_Params.Rows[0]["ParamID"] = valuationParametersSetup.ctrMarketPrice.lblFVSE02.ID + ",";
                    dt_Params.Rows[0]["Parameters at Grant Level"] = valuationParametersSetup.ctrMarketPrice.lblFVSE02.Text + ", ";
                }
            }

            if (valuationParametersSetup.ctrMarketPrice.lblFVDMP01.Checked)
            {
                dt_Params.Rows[0]["ParamID"] = dt_Params.Rows[0]["ParamID"] + valuationParametersSetup.ctrMarketPrice.lblFVDMP01.ID;
                dt_Params.Rows[0]["Parameters at Grant Level"] = dt_Params.Rows[0]["Parameters at Grant Level"] + valuationParametersSetup.ctrMarketPrice.lblFVDMP01.Text;
            }
            else
            {
                dt_Params.Rows[0]["ParamID"] = dt_Params.Rows[0]["ParamID"] + valuationParametersSetup.ctrMarketPrice.lblFVDMP02.ID;
                dt_Params.Rows[0]["Parameters at Grant Level"] = dt_Params.Rows[0]["Parameters at Grant Level"] + valuationParametersSetup.ctrMarketPrice.lblFVDMP02.Text;
            }

            if (dt_Params.Rows[0]["Parameters at Grant Level"].ToString() == dt_Params.Rows[0]["Parameters at Company Level"].ToString() && string.IsNullOrEmpty(Convert.ToString(dt_Params.Rows[0]["Parameters at Grant Level"])))
            {
                dt_Params.Rows[0]["ParamID"] = string.Empty;
                dt_Params.Rows[0]["Parameters at Grant Level"] = string.Empty;
            }
            return dt_Params;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="valuationParametersSetup"></param>
        /// <param name="dt_Params"></param>
        /// <returns></returns>
        private DataTable ExpectedLife(ValuationParameters valuationParametersSetup, DataTable dt_Params)
        {
            dt_Params.Rows[1]["Parameters at Grant Level"] = string.Empty;
            dt_Params.Rows[1]["ParamID"] = string.Empty;

            if (valuationParametersSetup.ctrExpectedLife.lblMCEL01.Checked)
            {
                dt_Params.Rows[1]["ParamID"] = valuationParametersSetup.ctrExpectedLife.lblMCEL01.ID;
                dt_Params.Rows[1]["Parameters at Grant Level"] = valuationParametersSetup.ctrExpectedLife.lblMCEL01.Text;
            }
            else if (valuationParametersSetup.ctrExpectedLife.lblMCEL02.Checked)
            {
                dt_Params.Rows[1]["ParamID"] = valuationParametersSetup.ctrExpectedLife.lblMCEL02.ID + ", ";
                dt_Params.Rows[1]["Parameters at Grant Level"] = valuationParametersSetup.ctrExpectedLife.lblMCEL02.Text + ": ";

                if (valuationParametersSetup.ctrExpectedLife.rdoELPastExerBehaviorYrs.Checked)
                {
                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + "Y, ";

                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + Convert.ToString(Math.Round(Convert.ToDecimal(valuationParametersSetup.ctrExpectedLife.txtELPastExerBehaviorYrs.Text.Trim()), 2));
                    dt_Params.Rows[1]["Parameters at Grant Level"] = dt_Params.Rows[1]["Parameters at Grant Level"] + Convert.ToString(Math.Round(Convert.ToDecimal(valuationParametersSetup.ctrExpectedLife.txtELPastExerBehaviorYrs.Text.Trim()), 2)) + " Year(s)";
                }
                else if (valuationParametersSetup.ctrExpectedLife.rdoELPastExerBehaviorMnts.Checked)
                {
                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + "M, ";

                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrExpectedLife.txtELPastExerBehaviorMnts.Text.Trim()));
                    dt_Params.Rows[1]["Parameters at Grant Level"] = dt_Params.Rows[1]["Parameters at Grant Level"] + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrExpectedLife.txtELPastExerBehaviorMnts.Text.Trim())) + " Month(s)";
                }
                else if (valuationParametersSetup.ctrExpectedLife.rdoELPastExerBehaviorDays.Checked)
                {
                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + "D, ";

                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrExpectedLife.txtELPastExerBehaviorDays.Text.Trim()));
                    dt_Params.Rows[1]["Parameters at Grant Level"] = dt_Params.Rows[1]["Parameters at Grant Level"] + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrExpectedLife.txtELPastExerBehaviorDays.Text.Trim())) + " Day(s)";
                }
            }
            else if (valuationParametersSetup.ctrExpectedLife.lblMCEL03.Checked)
            {
                dt_Params.Rows[1]["ParamID"] = valuationParametersSetup.ctrExpectedLife.lblMCEL03.ID + ", ";
                dt_Params.Rows[1]["Parameters at Grant Level"] = valuationParametersSetup.ctrExpectedLife.lblMCEL03.Text + ": ";

                if (valuationParametersSetup.ctrExpectedLife.rdoExpLifeYears.Checked)
                {
                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + "Y, ";

                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + Convert.ToString(Math.Round(Convert.ToDecimal(valuationParametersSetup.ctrExpectedLife.txtExpLifeYears.Text), 2));
                    dt_Params.Rows[1]["Parameters at Grant Level"] = dt_Params.Rows[1]["Parameters at Grant Level"] + Convert.ToString(Math.Round(Convert.ToDecimal(valuationParametersSetup.ctrExpectedLife.txtExpLifeYears.Text), 2)) + " Year(s)";
                }
                else if (valuationParametersSetup.ctrExpectedLife.rdoExpLifeMonths.Checked)
                {
                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + "M, ";

                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrExpectedLife.txtExpLifeMonths.Text.Trim()));
                    dt_Params.Rows[1]["Parameters at Grant Level"] = dt_Params.Rows[1]["Parameters at Grant Level"] + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrExpectedLife.txtExpLifeMonths.Text.Trim())) + " Month(s)";
                }
                else
                {
                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + "D, ";

                    dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrExpectedLife.txtExpLifeDays.Text.Trim()));
                    dt_Params.Rows[1]["Parameters at Grant Level"] = dt_Params.Rows[1]["Parameters at Grant Level"] + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrExpectedLife.txtExpLifeDays.Text.Trim())) + " Day(s)";
                }
            }
            else if (valuationParametersSetup.ctrExpectedLife.lblMCEL04.Checked)
            {
                dt_Params.Rows[1]["ParamID"] = valuationParametersSetup.ctrExpectedLife.lblMCEL04.ID;
                dt_Params.Rows[1]["Parameters at Grant Level"] = valuationParametersSetup.ctrExpectedLife.lblMCEL04.Text + ": ";

                dt_Params.Rows[1]["ParamID"] = dt_Params.Rows[1]["ParamID"] + valuationParametersSetup.ctrExpectedLife.hdnVPSELEstDateOfListing.Value;
                dt_Params.Rows[1]["Parameters at Grant Level"] = dt_Params.Rows[1]["Parameters at Grant Level"] + valuationParametersSetup.ctrExpectedLife.hdnVPSELEstDateOfListing.Value;
            }
            if (dt_Params.Rows[1]["Parameters at Grant Level"].ToString().TrimEnd(' ', ',') == dt_Params.Rows[1]["Parameters at Company Level"].ToString() && string.IsNullOrEmpty(Convert.ToString(dt_Params.Rows[1]["Parameters at Grant Level"])))
            {
                dt_Params.Rows[1]["ParamID"] = string.Empty;
                dt_Params.Rows[1]["Parameters at Grant Level"] = string.Empty;
            }
            return dt_Params;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="valuationParametersSetup"></param>
        /// <param name="dt_Params"></param>
        /// <returns></returns>
        private DataTable Volatility(ValuationParameters valuationParametersSetup, DataTable dt_Params)
        {
            dt_Params.Rows[3]["Parameters at Grant Level"] = string.Empty;
            dt_Params.Rows[3]["ParamID"] = string.Empty;

            //Volatility of
            if (valuationParametersSetup.ctrVolatility.lblVOL01.Checked)
            {
                dt_Params.Rows[3]["ParamID"] = valuationParametersSetup.ctrVolatility.lblVOL01.ID + ", ";
                dt_Params.Rows[3]["Parameters at Grant Level"] = valuationParametersSetup.ctrVolatility.lblVOL01.Text + " Market Price: ";

                dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + Convert.ToString(valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.SelectedItem.Value) + ", ";
                dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + Convert.ToString(valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.SelectedItem.Text) + ", ";
            }
            else if (valuationParametersSetup.ctrVolatility.lblVOL02.Checked)
            {

                dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + valuationParametersSetup.ctrVolatility.lblVOL02.ID + ", ";
                dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + valuationParametersSetup.ctrVolatility.lblVOL02.Text + ", ";
            }
            else if (valuationParametersSetup.ctrVolatility.lblVOL03.Checked)
            {
                dt_Params.Rows[3]["ParamID"] = valuationParametersSetup.ctrVolatility.lblVOL03.ID + ", ";
                dt_Params.Rows[3]["Parameters at Grant Level"] = valuationParametersSetup.ctrVolatility.lblVOL03.Text + ", ";
            }

            //Market Price to Calculate Volatility
            if (valuationParametersSetup.ctrVolatility.lblMPTCV01.Checked)
            {
                dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + valuationParametersSetup.ctrVolatility.lblMPTCV01.ID + ", ";
                dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + valuationParametersSetup.ctrVolatility.lblMPTCV01.Text + ", ";

                if (valuationParametersSetup.ctrVolatility.lblTDD01.Checked)
                {
                    dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + valuationParametersSetup.ctrVolatility.lblTDD01.ID + ", ";
                    dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + valuationParametersSetup.ctrVolatility.lblTDD01.Text + " Days, ";
                }
                else if (valuationParametersSetup.ctrVolatility.lblTDD02.Checked)
                {
                    dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + valuationParametersSetup.ctrVolatility.lblTDD02.ID + ", ";
                    dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + valuationParametersSetup.ctrVolatility.lblTDD02.Text + " Days, ";
                }
                else if (valuationParametersSetup.ctrVolatility.lblTDD03.Checked)
                {
                    dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + valuationParametersSetup.ctrVolatility.lblTDD03.ID + ", ";

                    dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + Convert.ToString(valuationParametersSetup.ctrVolatility.txtVPSSpecifyDaysDaily.Text) + ", ";
                    dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + Convert.ToString(valuationParametersSetup.ctrVolatility.txtVPSSpecifyDaysDaily.Text) + " Days, ";
                }
            }

            //Periods to Calculate Volatility
            if (valuationParametersSetup.ctrVolatility.lblPTCV01.Checked)
            {
                dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + valuationParametersSetup.ctrVolatility.lblPTCV01.ID + ", ";
                dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + "Periods to Calculate Volatility: " + valuationParametersSetup.ctrVolatility.lblPTCV01.Text;
            }
            else if (valuationParametersSetup.ctrVolatility.lblPTCV02.Checked)
            {
                dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + valuationParametersSetup.ctrVolatility.lblPTCV02.ID + ", ";
                dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + "Periods to Calculate Volatility: " + valuationParametersSetup.ctrVolatility.lblPTCV02.Text;
            }
            else if (valuationParametersSetup.ctrVolatility.lblPTCV03.Checked)
            {
                dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + valuationParametersSetup.ctrVolatility.lblPTCV03.ID;

                if (valuationParametersSetup.ctrVolatility.rdoVolatilityYears.Checked)
                {
                    dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + ", Y";

                    dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + ", " + Convert.ToString(Math.Round(Convert.ToDecimal(valuationParametersSetup.ctrVolatility.txtVolatilityYears.Text), 2));
                    dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + "Periods to Calculate Volatility: " + Convert.ToString(Math.Round(Convert.ToDecimal(valuationParametersSetup.ctrVolatility.txtVolatilityYears.Text), 2).ToString("0.00")) + " Years";
                }
                else if (valuationParametersSetup.ctrVolatility.rdoVolatilityMonths.Checked)
                {
                    dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + ", M";

                    dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + ", " + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrVolatility.txtVolatilityMonths.Text));
                    dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + "Periods to Calculate Volatility: " + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrVolatility.txtVolatilityMonths.Text).ToString("0.00")) + " Months";
                }
                if (valuationParametersSetup.ctrVolatility.rdoVolatilityDays.Checked)
                {
                    dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + ", D";

                    dt_Params.Rows[3]["ParamID"] = dt_Params.Rows[3]["ParamID"] + ", " + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrVolatility.txtVolatilityDays.Text));
                    dt_Params.Rows[3]["Parameters at Grant Level"] = dt_Params.Rows[3]["Parameters at Grant Level"] + "Periods to Calculate Volatility: " + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrVolatility.txtVolatilityDays.Text).ToString("0.00")) + " Days";
                }
            }
            if (dt_Params.Rows[3]["Parameters at Grant Level"].ToString() == dt_Params.Rows[3]["Parameters at Company Level"].ToString() && string.IsNullOrEmpty(Convert.ToString(dt_Params.Rows[3]["Parameters at Grant Level"])))
            {
                dt_Params.Rows[3]["Parameters at Grant Level"] = string.Empty;
                dt_Params.Rows[3]["ParamID"] = string.Empty;
            }
            return dt_Params;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="valuationParametersSetup"></param>
        /// <param name="dt_Params"></param>
        /// <returns></returns>
        private DataTable Dividend(ValuationParameters valuationParametersSetup, DataTable dt_Params)
        {
            dt_Params.Rows[4]["Parameters at Grant Level"] = string.Empty;
            dt_Params.Rows[4]["ParamID"] = string.Empty;

            //Dividend to be considered
            if (valuationParametersSetup.ctrDividend.lblDIV01.Checked)
            {
                dt_Params.Rows[4]["ParamID"] = valuationParametersSetup.ctrDividend.lblDIV01.ID + ", ";
                dt_Params.Rows[4]["Parameters at Grant Level"] = valuationParametersSetup.ctrDividend.lblDIV01.Text + ", ";
            }
            else if (valuationParametersSetup.ctrDividend.lblDIV02.Checked)
            {
                dt_Params.Rows[4]["ParamID"] = valuationParametersSetup.ctrDividend.lblDIV02.ID + ", ";
                dt_Params.Rows[4]["Parameters at Grant Level"] = valuationParametersSetup.ctrDividend.lblDIV02.Text + ", ";
            }
            else if (valuationParametersSetup.ctrDividend.lblDIV03.Checked)
            {
                dt_Params.Rows[4]["ParamID"] = valuationParametersSetup.ctrDividend.lblDIV03.ID + " ";
                dt_Params.Rows[4]["Parameters at Grant Level"] = valuationParametersSetup.ctrDividend.lblDIV03.Text + " ";

                dt_Params.Rows[4]["ParamID"] = dt_Params.Rows[4]["ParamID"] + "Last " + Convert.ToString(Math.Round(Convert.ToDecimal(valuationParametersSetup.ctrDividend.ddlAvgDividend.SelectedItem.Text), 2)) + ", ";
                dt_Params.Rows[4]["Parameters at Grant Level"] = dt_Params.Rows[4]["Parameters at Grant Level"] + "Last " + Convert.ToString(Math.Round(Convert.ToDecimal(valuationParametersSetup.ctrDividend.ddlAvgDividend.SelectedItem.Text), 2).ToString("0.00")) + " Years, ";
            }
            else if (valuationParametersSetup.ctrDividend.lblDIV04.Checked)
            {
                dt_Params.Rows[4]["ParamID"] = "Dividend to be considered: " + valuationParametersSetup.ctrDividend.lblDIV04.ID + ", ";
                dt_Params.Rows[4]["Parameters at Grant Level"] = valuationParametersSetup.ctrDividend.lblDIV04.Text + ", ";
            }

            //Special dividend
            //if(valuationParametersSetup.ctrDividend.chkVPSSpecialDividend.Checked)
            //{
            //    dt_Params.Rows[4]["ParamID"] = dt_Params.Rows[4]["ParamID"] + "SpecialDividend," + "1" + ", ";
            //    dt_Params.Rows[4]["Parameters at Grant Level"] = dt_Params.Rows[4]["Parameters at Grant Level"] + "Include Special dividend, ";
            //}
            //else
            //{
            //    dt_Params.Rows[4]["ParamID"] = dt_Params.Rows[4]["ParamID"] + "SpecialDividend," + "0" + ", ";
            //}

            //Market Price to Calculate Dividend Yield
            if (valuationParametersSetup.ctrDividend.lblMPTCD01.Checked)
            {
                dt_Params.Rows[4]["ParamID"] = dt_Params.Rows[4]["ParamID"] + valuationParametersSetup.ctrDividend.lblMPTCD01.ID + ", ";
                dt_Params.Rows[4]["Parameters at Grant Level"] = dt_Params.Rows[4]["Parameters at Grant Level"] + valuationParametersSetup.ctrDividend.lblMPTCD01.Text;
            }
            else if (valuationParametersSetup.ctrDividend.lblMPTCD02.Checked)
            {
                dt_Params.Rows[4]["ParamID"] = dt_Params.Rows[4]["ParamID"] + valuationParametersSetup.ctrDividend.lblMPTCD02.ID + ", ";
                dt_Params.Rows[4]["Parameters at Grant Level"] = dt_Params.Rows[4]["Parameters at Grant Level"] + valuationParametersSetup.ctrDividend.lblMPTCD02.Text;

                dt_Params.Rows[4]["ParamID"] = dt_Params.Rows[4]["ParamID"] + Convert.ToString(Convert.ToInt32(valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.SelectedItem.Value));
                //dt_Params.Rows[4]["Parameters at Grant Level"] = dt_Params.Rows[4]["Parameters at Grant Level"] + Convert.ToString(valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.SelectedItem.Text);
            }
            if (dt_Params.Rows[4]["Parameters at Grant Level"].ToString().TrimEnd(' ', ',') == dt_Params.Rows[4]["Parameters at Company Level"].ToString() && string.IsNullOrEmpty(Convert.ToString(dt_Params.Rows[4]["Parameters at Grant Level"])))
            {
                dt_Params.Rows[4]["ParamID"] = string.Empty;
                dt_Params.Rows[4]["Parameters at Grant Level"] = string.Empty;
            }
            return dt_Params;
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~VPSCommonModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}