﻿using EDFinancials.Model.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class BaseModel : EDFinancials.Model.Admin.BaseModel
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public BaseModel()
        {
            if ((ValuationProperties)System.Web.HttpContext.Current.Session["valuationProperties"] == null)
            {
                valuationProperties = new ValuationProperties();
                System.Web.HttpContext.Current.Session["valuationProperties"] = valuationProperties;
            }
            else
            {
                valuationProperties = (ValuationProperties)System.Web.HttpContext.Current.Session["valuationProperties"];
            }

            if ((ValuationCRUDProperties)System.Web.HttpContext.Current.Session["valuationCRUDProperties"] == null)
            {
                valuationCRUDProperties = new ValuationCRUDProperties();
                System.Web.HttpContext.Current.Session["valuationCRUDProperties"] = valuationCRUDProperties;
            }
            else
            {
                valuationCRUDProperties = (ValuationCRUDProperties)System.Web.HttpContext.Current.Session["valuationCRUDProperties"];
            }
        }

        /// <summary>
        /// PRIVATE DECLARATION FOR VALUATION PROPERTY
        /// </summary>
        private ValuationProperties _valuationProperties;

        /// <summary>
        /// PUBLIC DECLARATION FOR VALUATION PROPERTY
        /// </summary>        
        public ValuationProperties valuationProperties
        {
            get { return _valuationProperties; }
            set { _valuationProperties = value; }
        }

        /// <summary>
        /// PRIVATE DECLARATION FOR VALUATION CURD PROPERTY
        /// </summary>
        private ValuationCRUDProperties _valuationCRUDProperties;

        /// <summary>
        /// PUBLIC DECLARATION FOR VALUATION CURD PROPERTY
        /// </summary>        
        public ValuationCRUDProperties valuationCRUDProperties
        {
            get { return _valuationCRUDProperties; }
            set { _valuationCRUDProperties = value; }
        }

        /// <summary>
        /// OBJECT OF COMPANY INFORMATION ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_CompanyInformation ac_CompanyInformation;

        /// <summary>
        /// OBJECT OF CORPORATE ACTION ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_CorporateAction ac_CorporateAction;

        /// <summary>
        /// OBJECT OF DIVIDEND SETUP ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_DividendSetUp ac_DividendSetUp;

        /// <summary>
        /// OBJECT OF PEER COMPANY SETUP ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_PeerCompanySetup ac_PeerCompanySetup;

        /// <summary>
        /// OBJECT OF VALUATION PARAMETER ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ValuationParameter ac_ValuationParameter;

        /// <summary>
        /// OBJECT OF REPORT PAMEMETER SETUP ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ReportPamameter ac_ReportPamameter;

        /// <summary>
        /// OBJECT OF REPORT FORMT ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ReportFormat ac_ReportFormat;

        /// <summary>
        /// OBJECT OF GRANT DETAILS ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_GrantDetails ac_GrantDetails;

        /// <summary>
        /// OBJECT OF VALUATION REPORT ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ValuationReport ac_ValuationReport;

        /// <summary>
        /// OBJECT OF VALUATION REPORT ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_SearchGrantDetails ac_SearchGrantDetails;

        /// <summary>
        /// OBJECT OF GRANT DETAILS ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ValHelp ac_ValHelp;

        /// <summary>
        /// OBJECT OF APPROVE VALUATION PARAMS ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ApproveValuationParams ac_ApproveValuationParams;
    }
}