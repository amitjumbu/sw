﻿using EDFinancials.Model.Generic;
using EDFinancials.UserControl.User.Valuation;
using EDFinancials.View.Valuation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// This is model file for ReportParameters page.
    /// </summary>
    public class ReportParametersModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public ReportParametersModel()
        {
            if (ac_CompanyInformation == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ReportPamameter);
                ac_ReportPamameter = (CommonModel.AC_ReportPamameter)HttpContext.Current.Session[CommonConstantModel.s_AC_ReportPamameter];
            }
        }

        /// <summary>
        /// Enables or disables a control according to roles assigned to the user.
        /// </summary>
        /// <param name="PageObject">object of page</param>
        /// <param name="s_PageName">Name of page</param>
        internal void CheckEmployeeRolePriviledges(object PageObject, string s_PageName)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuReportParameters;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    switch (s_PageName)
                                    {

                                        case "MarketPrice":
                                            using (MarketPriceUC marketPriceUC = (MarketPriceUC)PageObject)
                                            {
                                                marketPriceUC.btnMPIVPreview.Enabled = true;
                                                marketPriceUC.btnMPFVPreview.Enabled = true;
                                            }
                                            break;

                                        case "ExpectedLife":
                                            using (ExpectedLifeUC expectedLifeUC = (ExpectedLifeUC)PageObject)
                                            {
                                                expectedLifeUC.btnExpLifePreview.Enabled = true;
                                            }
                                            break;

                                        case "Volatility":
                                            using (VolatilityUC volatilityUC = (VolatilityUC)PageObject)
                                            {
                                                volatilityUC.btnVolatilityPreview.Enabled = true;
                                            }
                                            break;

                                        case "RFIR":
                                            using (RiskFreeInterestRateUC riskFreeInterestRateUC = (RiskFreeInterestRateUC)PageObject)
                                            {
                                                riskFreeInterestRateUC.btnRFIRPreview.Enabled = true;
                                            }
                                            break;

                                        case "Dividend":
                                            using (DividendUC dividendUC = (DividendUC)PageObject)
                                            {
                                                dividendUC.btnDividendPreview.Enabled = true;
                                            }
                                            break;
                                    }
                                    break;

                                case "EDIT":

                                    switch (s_PageName)
                                    {

                                        case "MarketPrice":
                                            using (MarketPriceUC marketPriceUC = (MarketPriceUC)PageObject)
                                            {
                                                marketPriceUC.btnMPParameterTextSave.Enabled = true;
                                                marketPriceUC.btnMPFVText.Enabled = true;
                                            }
                                            break;

                                        case "ExpectedLife":
                                            using (ExpectedLifeUC expectedLifeUC = (ExpectedLifeUC)PageObject)
                                            {
                                                expectedLifeUC.btnExpectedLifeSave_Text.Enabled = true;
                                            }
                                            break;

                                        case "Volatility":
                                            using (VolatilityUC volatilityUC = (VolatilityUC)PageObject)
                                            {
                                                volatilityUC.btnVolatilitySave_Text.Enabled = true;
                                            }
                                            break;

                                        case "RFIR":
                                            using (RiskFreeInterestRateUC riskFreeInterestRateUC = (RiskFreeInterestRateUC)PageObject)
                                            {
                                                riskFreeInterestRateUC.btnRFIRSave_Text.Enabled = true;
                                            }
                                            break;

                                        case "Dividend":
                                            using (DividendUC dividendUC = (DividendUC)PageObject)
                                            {
                                                dividendUC.btnDividendSave_Text.Enabled = true;
                                            }
                                            break;
                                    }

                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to fetch messages from L10N xml via superadmin WCF service.
        /// </summary>
        /// <param name="MessegeId"></param>
        /// <returns>string as the message</returns>
        public string Val_L10N(string MessegeId)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    return valuationServiceClient.GetValuation_L10N(MessegeId, CommonConstantModel.s_ReportParamaters, CommonConstantModel.s_ValuationL10);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to load all label text from L10N_UI via wcf service
        /// </summary>
        /// <param name="PageObject">Page object</param>
        /// <param name="s_PageName">Page name</param>
        public void BindPageUI(object PageObject, string s_PageName)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    ac_ReportPamameter.dt_ValuParaSetupUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_ValuationParameter, CommonConstantModel.s_ValuationL10_UI);

                    switch (s_PageName)
                    {
                        case "MarketPrice":
                            using (MarketPriceUC marketPriceUC = (MarketPriceUC)PageObject)
                            {
                                marketPriceUC.ctrPreview_MPIV.s_PreviewLabel = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMPIVPreviewLabel'"))[0]["LabelName"]);
                                marketPriceUC.ctrPreview_MPIV.s_PreviewLabelToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMPIVPreviewLabel'"))[0]["LabelToolTip"]);

                                marketPriceUC.ctrPreview_MPFV.s_PreviewLabel = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMPFVPreviewLabel'"))[0]["LabelName"]);
                                marketPriceUC.ctrPreview_MPFV.s_PreviewLabelToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblMPFVPreviewLabel'"))[0]["LabelToolTip"]);

                                marketPriceUC.btnMPIVPreview.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnMPIVPreview'"))[0]["LabelName"]);
                                marketPriceUC.btnMPIVPreview.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnMPIVPreview'"))[0]["LabelToolTip"]);
                                marketPriceUC.btnMPParameterTextSave.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnMPParameterTextSave'"))[0]["LabelName"]);
                                marketPriceUC.btnMPParameterTextSave.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnMPParameterTextSave'"))[0]["LabelToolTip"]);

                                marketPriceUC.btnMPFVText.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnMPFVText'"))[0]["LabelName"]);
                                marketPriceUC.btnMPFVText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnMPFVText'"))[0]["LabelToolTip"]);

                                marketPriceUC.btnMPFVPreview.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnMPFVPreview'"))[0]["LabelName"]);
                                marketPriceUC.btnMPFVPreview.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnMPFVPreview'"))[0]["LabelToolTip"]);

                                marketPriceUC.ddIVStockExtext_Rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                marketPriceUC.txtIVStockExchangeType.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);
                                marketPriceUC.ddIVMarketPriceDate_Rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                marketPriceUC.txtIVDateOfMarketPriceText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);

                                marketPriceUC.ddFVStockExtext_Rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                marketPriceUC.txtFVStockExchangeTypeText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);
                                marketPriceUC.ddFVMarketPriceDate_Rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                marketPriceUC.txtFVDateOfMarketPriceText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);

                            }
                            break;

                        case "ExpectedLife":
                            using (ExpectedLifeUC expectedLifeUC = (ExpectedLifeUC)PageObject)
                            {
                                expectedLifeUC.ctrPreview_EL.s_PreviewLabel = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblExpLifePreviewLabel'"))[0]["LabelName"]);
                                expectedLifeUC.ctrPreview_EL.s_PreviewLabel = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblExpLifePreviewLabel'"))[0]["LabelName"]);

                                expectedLifeUC.btnExpLifePreview.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnExpLifePreview'"))[0]["LabelName"]);
                                expectedLifeUC.btnExpLifePreview.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnExpLifePreview'"))[0]["LabelName"]);

                                expectedLifeUC.btnExpectedLifeSave_Text.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnExpectedLifeSave_Text'"))[0]["LabelName"]);
                                expectedLifeUC.btnExpectedLifeSave_Text.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnExpectedLifeSave_Text'"))[0]["LabelName"]);

                                expectedLifeUC.txtExpectedLifeMethodText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);
                            }
                            break;

                        case "Volatility":
                            using (VolatilityUC volatilityUC = (VolatilityUC)PageObject)
                            {
                                volatilityUC.ctrPreview_VC.s_PreviewLabel = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVolPreviewLabel'"))[0]["LabelName"]);
                                volatilityUC.ctrPreview_VC.s_PreviewLabelToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblVolPreviewLabel'"))[0]["LabelToolTip"]);

                                volatilityUC.btnVolatilityPreview.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVolatilityPreview'"))[0]["LabelName"]);
                                volatilityUC.btnVolatilityPreview.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVolatilityPreview'"))[0]["LabelToolTip"]);
                                volatilityUC.btnVolatilitySave_Text.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVolatilitySave_Text'"))[0]["LabelName"]);
                                volatilityUC.btnVolatilitySave_Text.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnVolatilitySave_Text'"))[0]["LabelToolTip"]);

                                volatilityUC.ddVolatilityOf_Rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                volatilityUC.txtVolatilityof_text.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);
                                volatilityUC.ddMPToCalcVol_Rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                volatilityUC.txtCalVolatilityText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);

                                volatilityUC.ddPrdsToCalVol_Rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                volatilityUC.txtVolatilityCalPeriodText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);
                                volatilityUC.ddExcludeVol_rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                volatilityUC.txtExclVolText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);
                            }
                            break;

                        case "RFIR":
                            using (RiskFreeInterestRateUC riskFreeInterestRateUC = (RiskFreeInterestRateUC)PageObject)
                            {
                                riskFreeInterestRateUC.ctrPreview_RFIR.s_PreviewLabel = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIRPreviewLabel'"))[0]["LabelName"]);
                                riskFreeInterestRateUC.ctrPreview_RFIR.s_PreviewLabelToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblRFIRPreviewLabel'"))[0]["LabelToolTip"]);

                                riskFreeInterestRateUC.btnRFIRPreview.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRPreview'"))[0]["LabelName"]);
                                riskFreeInterestRateUC.btnRFIRPreview.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRPreview'"))[0]["LabelToolTip"]);
                                riskFreeInterestRateUC.btnRFIRSave_Text.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRSave_Text'"))[0]["LabelName"]);
                                riskFreeInterestRateUC.btnRFIRSave_Text.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnRFIRSave_Text'"))[0]["LabelToolTip"]);
                                riskFreeInterestRateUC.txtVPSRFIRCountryText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);
                            }
                            break;

                        case "Dividend":
                            using (DividendUC dividendUC = (DividendUC)PageObject)
                            {
                                dividendUC.ctrPreview_DC.s_PreviewLabel = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblDividendPreviewLabel'"))[0]["LabelName"]);
                                dividendUC.ctrPreview_DC.s_PreviewLabelToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'lblDividendPreviewLabel'"))[0]["LabelToolTip"]);

                                dividendUC.btnDividendPreview.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnDividendPreview'"))[0]["LabelName"]);
                                dividendUC.btnDividendPreview.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnDividendPreview'"))[0]["LabelToolTip"]);
                                dividendUC.btnDividendSave_Text.Text = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnDividendSave_Text'"))[0]["LabelName"]);
                                dividendUC.btnDividendSave_Text.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'btnDividendSave_Text'"))[0]["LabelToolTip"]);

                                dividendUC.ddDivToBeConsidered_Rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                dividendUC.txtDividendConsideredText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);
                                dividendUC.ddSpecialDiv_Rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                dividendUC.txtSpecialDividendText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);
                                dividendUC.ddMPDivCal_Rank.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'ddSequenceOfPreviewText'"))[0]["LabelToolTip"]);
                                dividendUC.txtDividendYeildText.ToolTip = Convert.ToString((ac_ReportPamameter.dt_ValuParaSetupUI.Select("LabelID = 'txtParameterText'"))[0]["LabelToolTip"]);
                            }
                            break;

                    }
                }
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// This method gets the parameter text from database.
        /// </summary>
        /// <param name="s_Action">Action string</param>
        public void Get_SavedParameterText(string s_Action)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.Action = s_Action;
                    valuationProperties.PageName = CommonConstantModel.s_ReportParamaters;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_ReportPamameter.dt_ReportParameterText = valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result;
                    ac_ReportPamameter.b_IsListed = userSessionInfo.ACC_IsListed.Equals(1) ? true : false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method loads data of Parameter text dropdown.
        /// </summary>
        /// <param name="Dropdown">Dropdown to be loaded</param>
        /// <param name="s_Action">Action to be performed</param>
        public void Load_SequenceDropdown(DropDownList Dropdown, string s_Action)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.Action = s_Action;
                    valuationProperties.PageName = CommonConstantModel.s_ReportParamaters;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    Dropdown.DataSource = valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result;
                    Dropdown.DataTextField = "SEQUENCE";
                    Dropdown.DataValueField = "SEQUENCE";
                    Dropdown.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method loads the details of peer companies .
        /// </summary>
        public void Load_PeerCompanies()
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.Action = "GET_PEERCOMPANY";
                    valuationProperties.PageName = CommonConstantModel.s_ReportParamaters;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_ReportPamameter.dt_GetPeerCompanies = valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method binds the saved text to the corresponding textboxes
        /// </summary>
        /// <param name="Page_Type">this is page object</param>
        /// <param name="s_PageName">this is page name</param>
        public void Bind_ParameterText_ToControls(Object Page_Type, string s_PageName)
        {
            try
            {

                switch (s_PageName)
                {

                    case "MarketPrice":
                        using (MarketPriceUC marketPriceUC = (MarketPriceUC)Page_Type)
                        {
                            marketPriceUC.hdn_IsCompanyListed.Value = Convert.ToString(Convert.ToInt16(ac_ReportPamameter.b_IsListed));

                            if (marketPriceUC.lblIVSE01.Checked)
                            {
                                marketPriceUC.txtIVStockExchangeType.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblIVSE01.ID + "'and PARAMETER_CHILD_ID =  '" + marketPriceUC.ddlIVStockExchange.SelectedValue + "'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (marketPriceUC.lblIVSE02.Checked)
                            {
                                marketPriceUC.txtIVStockExchangeType.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblIVSE02.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            if (marketPriceUC.lblIVDMP01.Checked)
                            {
                                marketPriceUC.txtIVDateOfMarketPriceText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblIVDMP01.ID + "'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (marketPriceUC.lblIVDMP02.Checked)
                            {
                                marketPriceUC.txtIVDateOfMarketPriceText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblIVDMP02.ID + "'")[0]["PARAMETER_TEXT"]);
                            }

                            //-- FV
                            if (marketPriceUC.lblFVSE01.Checked)
                            {
                                marketPriceUC.txtFVStockExchangeTypeText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblFVSE01.ID + "'and PARAMETER_CHILD_ID =  '" + marketPriceUC.ddlIVStockExchange.SelectedValue + "'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (marketPriceUC.lblFVSE02.Checked)
                            {
                                marketPriceUC.txtFVStockExchangeTypeText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblFVSE02.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            if (marketPriceUC.lblFVDMP01.Checked)
                            {
                                marketPriceUC.txtFVDateOfMarketPriceText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblFVDMP01.ID + "'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (marketPriceUC.lblFVDMP02.Checked)
                            {
                                marketPriceUC.txtFVDateOfMarketPriceText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblFVDMP02.ID + "'")[0]["PARAMETER_TEXT"]);
                            }
                        }
                        break;

                    case "ExpectedLife":
                        using (ExpectedLifeUC expectedLifeUC = (ExpectedLifeUC)Page_Type)
                        {
                            if (expectedLifeUC.lblMCEL01.Checked)
                            {
                                expectedLifeUC.txtExpectedLifeMethodText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + expectedLifeUC.lblMCEL01.ID + "'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (expectedLifeUC.lblMCEL02.Checked)
                            {
                                string s_ChildParameter = expectedLifeUC.rdoELPastExerBehaviorYrs.Checked ? "Y" : expectedLifeUC.rdoELPastExerBehaviorMnts.Checked ? "M" : expectedLifeUC.rdoELPastExerBehaviorDays.Checked ? "D" : "";
                                expectedLifeUC.txtExpectedLifeMethodText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + expectedLifeUC.lblMCEL02.ID + "'and PARAMETER_CHILD_ID =  '" + s_ChildParameter + "'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (expectedLifeUC.lblMCEL03.Checked)
                            {
                                string s_ChildParameter = valuationProperties.Parameter_child_Id1 = expectedLifeUC.rdoExpLifeYears.Checked ? "Y" : expectedLifeUC.rdoExpLifeMonths.Checked ? "M" : expectedLifeUC.rdoExpLifeDays.Checked ? "D" : "";
                                expectedLifeUC.txtExpectedLifeMethodText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + expectedLifeUC.lblMCEL02.ID + "'and PARAMETER_CHILD_ID =  '" + s_ChildParameter + "'")[0]["PARAMETER_TEXT"]);
                            }
                        }
                        break;

                    case "Volatility":
                        using (VolatilityUC volatilityUC = (VolatilityUC)Page_Type)
                        {
                            if (volatilityUC.lblVOL01.Checked)
                            {
                                volatilityUC.txtVolatilityof_text.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblVOL01.ID + "' and PARAMETER_CHILD_ID =  '" + volatilityUC.ddlVPSStockExchge_VC.SelectedValue + "'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (volatilityUC.lblVOL02.Checked)
                            {
                                volatilityUC.txtVolatilityof_text.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblVOL02.ID + "' and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (volatilityUC.lblVOL03.Checked)
                            {
                                volatilityUC.txtVolatilityof_text.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblVOL03.ID + "' and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            if (volatilityUC.lblMPTCV01.Checked)
                            {
                                string s_ChildParameter = volatilityUC.lblTDD01.Checked ? "lblTDD01" : volatilityUC.lblTDD02.Checked ? "lblTDD02" : volatilityUC.lblTDD03.Checked ? "lblTDD03" : "";
                                volatilityUC.txtCalVolatilityText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblMPTCV01.ID + "'and PARAMETER_CHILD_ID =  '" + s_ChildParameter + "'")[0]["PARAMETER_TEXT"]);
                            }
                            if (volatilityUC.lblPTCV01.Checked)
                            {
                                volatilityUC.txtVolatilityCalPeriodText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblPTCV01.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (volatilityUC.lblPTCV02.Checked)
                            {
                                volatilityUC.txtVolatilityCalPeriodText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblPTCV02.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (volatilityUC.lblPTCV03.Checked)
                            {
                                string s_ChildParameter = valuationProperties.Parameter_child_Id1 = volatilityUC.rdoVolatilityYears.Checked ? "Y" : volatilityUC.rdoVolatilityMonths.Checked ? "M" : volatilityUC.rdoVolatilityDays.Checked ? "D" : "";
                                volatilityUC.txtVolatilityCalPeriodText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblPTCV03.ID + "'and PARAMETER_CHILD_ID =  '" + s_ChildParameter + "'")[0]["PARAMETER_TEXT"]);
                            }
                            volatilityUC.txtExclVolText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.chkVPSVolExcludeVol.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                        }
                        break;

                    case "RFIR":
                        using (RiskFreeInterestRateUC riskFreeInterestRateUC = (RiskFreeInterestRateUC)Page_Type)
                        {
                            if (riskFreeInterestRateUC.ddlVPSRFIRCountryList.SelectedItem.ToString() != "--- Please Select ---")
                            {
                                riskFreeInterestRateUC.txtVPSRFIRCountryText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + riskFreeInterestRateUC.ddlVPSRFIRCountryList.ID + "' and PARAMETER_CHILD_ID =  '" + riskFreeInterestRateUC.ddlVPSRFIRCountryList.SelectedValue + "'")[0]["PARAMETER_TEXT"]);
                            }
                        }
                        break;

                    case "Dividend":
                        using (DividendUC dividendUC = (DividendUC)Page_Type)
                        {
                            if (dividendUC.lblDIV01.Checked)
                            {
                                dividendUC.txtDividendConsideredText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblDIV01.ID + "' and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (dividendUC.lblDIV02.Checked)
                            {
                                dividendUC.txtDividendConsideredText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblDIV02.ID + "' and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (dividendUC.lblDIV03.Checked)
                            {
                                dividendUC.txtDividendConsideredText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblDIV03.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (dividendUC.lblDIV04.Checked)
                            {
                                dividendUC.txtDividendConsideredText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblDIV04.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            dividendUC.txtSpecialDividendText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.chkVPSSpecialDividend.ID + "'and PARAMETER_CHILD_ID =  '" + Convert.ToString(Convert.ToInt16(dividendUC.chkVPSSpecialDividend.Checked)) + "'")[0]["PARAMETER_TEXT"]);

                            if (dividendUC.lblMPTCD01.Checked)
                            {
                                dividendUC.txtDividendYeildText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblMPTCD01.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAMETER_TEXT"]);
                            }
                            else if (dividendUC.lblMPTCD02.Checked)
                            {
                                dividendUC.txtDividendYeildText.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblMPTCD02.ID + "'and PARAMETER_CHILD_ID =  '" + Convert.ToString(Convert.ToInt16(dividendUC.ddlVPSStockExchge_DC.SelectedValue)) + "'")[0]["PARAMETER_TEXT"]);
                            }
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This is method loads the sequence of parameter text to be showed in the dropdown
        /// </summary>
        /// <param name="Page_Type">this is page object</param>
        /// <param name="s_PageName">this is page name</param>
        public void Bind_Default_Sequence(Object Page_Type, string s_PageName)
        {
            try
            {
                switch (s_PageName)
                {
                    case "MarketPrice":
                        using (MarketPriceUC marketPriceUC = (MarketPriceUC)Page_Type)
                        {
                            // IV
                            if (marketPriceUC.lblIVSE01.Checked)
                            {
                                marketPriceUC.ddIVStockExtext_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblIVSE01.ID + "'and PARAMETER_CHILD_ID =  '" + marketPriceUC.ddlIVStockExchange.SelectedValue + "'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (marketPriceUC.lblIVSE02.Checked)
                            {
                                marketPriceUC.ddIVStockExtext_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblIVSE02.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            if (marketPriceUC.lblIVDMP01.Checked)
                            {
                                marketPriceUC.ddIVMarketPriceDate_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblIVDMP01.ID + "'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (marketPriceUC.lblIVDMP02.Checked)
                            {
                                marketPriceUC.ddIVMarketPriceDate_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblIVDMP02.ID + "'")[0]["PARAM_SEQUENCE"]);
                            }

                            // FV
                            if (marketPriceUC.lblFVSE01.Checked)
                            {
                                marketPriceUC.ddFVStockExtext_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblFVSE01.ID + "'and PARAMETER_CHILD_ID =  '" + marketPriceUC.ddlIVStockExchange.SelectedValue + "'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (marketPriceUC.lblFVSE02.Checked)
                            {
                                marketPriceUC.ddFVStockExtext_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblFVSE02.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            if (marketPriceUC.lblFVDMP01.Checked)
                            {
                                marketPriceUC.ddFVMarketPriceDate_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblFVDMP01.ID + "'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (marketPriceUC.lblFVDMP02.Checked)
                            {
                                marketPriceUC.ddFVMarketPriceDate_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + marketPriceUC.lblFVDMP02.ID + "'")[0]["PARAM_SEQUENCE"]);
                            }
                        }
                        break;

                    case "Volatility":
                        using (VolatilityUC volatilityUC = (VolatilityUC)Page_Type)
                        {
                            if (volatilityUC.lblVOL01.Checked)
                            {
                                volatilityUC.ddVolatilityOf_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblVOL01.ID + "' and PARAMETER_CHILD_ID =  '" + volatilityUC.ddlVPSStockExchge_VC.SelectedValue + "'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (volatilityUC.lblVOL02.Checked)
                            {
                                volatilityUC.ddVolatilityOf_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblVOL02.ID + "' and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (volatilityUC.lblVOL03.Checked)
                            {
                                volatilityUC.ddVolatilityOf_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblVOL03.ID + "' and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            if (volatilityUC.lblMPTCV01.Checked)
                            {
                                volatilityUC.ddMPToCalcVol_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblMPTCV01.ID + "'and PARAMETER_CHILD_ID =  'lblTDD01'")[0]["PARAM_SEQUENCE"]);
                            }
                            if (volatilityUC.lblPTCV01.Checked)
                            {
                                volatilityUC.ddPrdsToCalVol_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblPTCV01.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (volatilityUC.lblPTCV02.Checked)
                            {
                                volatilityUC.ddPrdsToCalVol_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblPTCV02.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (volatilityUC.lblPTCV03.Checked)
                            {
                                volatilityUC.ddPrdsToCalVol_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.lblPTCV03.ID + "'and PARAMETER_CHILD_ID =  'Y'")[0]["PARAM_SEQUENCE"]);
                            }

                            volatilityUC.ddExcludeVol_rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + volatilityUC.chkVPSVolExcludeVol.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                        }
                        break;

                    case "Dividend":
                        using (DividendUC dividendUC = (DividendUC)Page_Type)
                        {
                            if (dividendUC.lblDIV01.Checked)
                            {
                                dividendUC.ddDivToBeConsidered_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblDIV01.ID + "' and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (dividendUC.lblDIV02.Checked)
                            {
                                dividendUC.ddDivToBeConsidered_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblDIV02.ID + "' and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (dividendUC.lblDIV03.Checked)
                            {
                                dividendUC.ddDivToBeConsidered_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblDIV03.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (dividendUC.lblDIV04.Checked)
                            {
                                dividendUC.ddDivToBeConsidered_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblDIV04.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            dividendUC.ddSpecialDiv_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.chkVPSSpecialDividend.ID + "'and PARAMETER_CHILD_ID =  '" + Convert.ToString(Convert.ToInt16(dividendUC.chkVPSSpecialDividend.Checked)) + "'")[0]["PARAM_SEQUENCE"]);

                            if (dividendUC.lblMPTCD01.Checked)
                            {
                                dividendUC.ddMPDivCal_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblMPTCD01.ID + "'and PARAMETER_CHILD_ID =  '0'")[0]["PARAM_SEQUENCE"]);
                            }
                            else if (dividendUC.lblMPTCD02.Checked)
                            {
                                dividendUC.ddMPDivCal_Rank.SelectedValue = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + dividendUC.lblMPTCD02.ID + "'and PARAMETER_CHILD_ID =  '" + Convert.ToString(Convert.ToInt16(dividendUC.ddlVPSStockExchge_DC.SelectedValue)) + "'")[0]["PARAM_SEQUENCE"]);
                            }
                        }
                        break;
                }
            }
            catch
            {
                // Do Nothing
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void Check_isCompany_Listed()
        {
            try
            {
                commonValuationProperties();
                valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                valuationProperties.Action = "IS_LISTED";

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    ac_ReportPamameter.b_IsListed = valuationServiceClient.CRUDValuationOperations(valuationProperties).b_Result;
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// This is common valuation properties that has to set before CRUD.
        /// </summary>
        public void commonValuationProperties()
        {
            try
            {
                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                valuationProperties.Action = "UPDATE_TEXT";
                valuationProperties.PageName = CommonConstantModel.s_ReportParamaters;
                valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method shows / hides the column / rows / buttons / gridview as per requirement of report parameters page
        /// </summary>
        /// <param name="PageObject">this is page object</param>
        /// <param name="s_PageName">this is page name</param>
        /// <param name="IsVisible"> this is the status of report parameters session</param>
        public void Show_Parameter_text_Columns(Object PageObject, string s_PageName, bool IsVisible)
        {
            try
            {
                switch (s_PageName)
                {
                    case "MarketPrice":
                        using (MarketPriceUC marketPriceUC = (MarketPriceUC)PageObject)
                        {
                            marketPriceUC.tdBtnMarketPriceIV.ColSpan = 4;
                            marketPriceUC.tdBtnMarketPriceFV.ColSpan = 4;
                            marketPriceUC.Report_para_td1.Visible = IsVisible;
                            marketPriceUC.Report_para_td2.Visible = IsVisible;
                            marketPriceUC.Report_para_td3.Visible = IsVisible;
                            marketPriceUC.Report_para_td4.Visible = IsVisible;
                            marketPriceUC.Report_para_td5.Visible = IsVisible;
                            marketPriceUC.Report_para_td6.Visible = IsVisible;
                            marketPriceUC.Report_para_td7.Visible = IsVisible;
                            marketPriceUC.Report_para_td8.Visible = IsVisible;
                            marketPriceUC.btnMPIVPreview.Visible = IsVisible;
                            marketPriceUC.btnMPFVPreview.Visible = IsVisible;
                            marketPriceUC.btnMPParameterTextSave.Visible = IsVisible;
                            marketPriceUC.btnMPFVText.Visible = IsVisible;
                            marketPriceUC.btnVPSSaveIV.Visible = !IsVisible;
                            marketPriceUC.btnVPSSaveFV.Visible = !IsVisible;
                            marketPriceUC.gvMarketPriceIV.Visible = !IsVisible;
                            marketPriceUC.gvMarketPriceFV.Visible = !IsVisible;
                            marketPriceUC.MPrice_tr1.Visible = !IsVisible;
                            marketPriceUC.MPrice_tr2.Visible = !IsVisible;
                            marketPriceUC.MPrice_tr4.Visible = !IsVisible;
                            marketPriceUC.MPrice_tr5.Visible = !IsVisible;
                            marketPriceUC.btnVPSResetFV.Visible = !IsVisible;
                            marketPriceUC.btnVPSResetIV.Visible = !IsVisible;
                            if (!(ac_ReportPamameter.b_IsListed))
                            {
                                marketPriceUC.Report_para_td3.Visible = false;
                                marketPriceUC.Report_para_td7.Visible = false;
                            }
                        }
                        break;

                    case "ExpectedLife":
                        using (ExpectedLifeUC expectedLifeUC = (ExpectedLifeUC)PageObject)
                        {
                            expectedLifeUC.ExpLife_td1.Visible = IsVisible;
                            expectedLifeUC.btnExpectedLifeSave_Text.Visible = IsVisible;
                            expectedLifeUC.btnExpLifePreview.Visible = IsVisible;
                            expectedLifeUC.btnVPSExpectedLifeSave.Visible = !IsVisible;
                            expectedLifeUC.gvExpectedLife.Visible = !IsVisible;
                            expectedLifeUC.ExpLife_tr1.Visible = !IsVisible;
                            expectedLifeUC.ExpLife_tr2.Visible = !IsVisible;
                            expectedLifeUC.btnVPSExpectedLifeReset.Visible = !IsVisible;
                            expectedLifeUC.tdBtnExpectedLife.ColSpan = 3;
                        }

                        break;
                    case "Volatility":
                        using (VolatilityUC volatilityUC = (VolatilityUC)PageObject)
                        {
                            volatilityUC.Vol_td1.Visible = IsVisible;
                            volatilityUC.Vol_td2.Visible = IsVisible;
                            volatilityUC.Vol_td3.Visible = IsVisible;
                            volatilityUC.Vol_td4.Visible = IsVisible;
                            volatilityUC.Vol_td5.Visible = IsVisible;
                            volatilityUC.Vol_td6.Visible = IsVisible;
                            volatilityUC.Vol_td7.Visible = IsVisible;
                            volatilityUC.Vol_td8.Visible = IsVisible;
                            volatilityUC.btnVolatilityPreview.Visible = IsVisible;
                            volatilityUC.btnVolatilitySave_Text.Visible = IsVisible;
                            volatilityUC.divReportPara_vol_buttons.Visible = IsVisible;
                            volatilityUC.btnVPSVolatilitySave.Visible = !IsVisible;
                            volatilityUC.btnVPSExcludeVolAdd.Visible = !IsVisible;
                            volatilityUC.gvVolatility.Visible = !IsVisible;
                            volatilityUC.gvVPSExcludeVolDetails.Visible = !IsVisible;
                            volatilityUC.Vol_tr1.Visible = !IsVisible;
                            volatilityUC.Vol_tr2.Visible = !IsVisible;
                            volatilityUC.Vol_tr3.Visible = !IsVisible;
                            volatilityUC.Vol_tr4.Visible = !IsVisible;
                            volatilityUC.btnVPSVolatilityReset.Visible = !IsVisible;
                            volatilityUC.tdBtnVolatility.ColSpan = 4;
                        }
                        break;

                    case "RFIR":
                        using (RiskFreeInterestRateUC riskFreeInterestRateUC = (RiskFreeInterestRateUC)PageObject)
                        {
                            riskFreeInterestRateUC.RFIR_td1.Visible = IsVisible;
                            riskFreeInterestRateUC.btnRFIRPreview.Visible = IsVisible;
                            riskFreeInterestRateUC.btnRFIRSave_Text.Visible = IsVisible;
                            riskFreeInterestRateUC.gvVPSRFIR.Visible = !IsVisible;
                            riskFreeInterestRateUC.tdlblVPSRFIRFileName.Visible = !IsVisible;
                            riskFreeInterestRateUC.tdtxtVPSRFIRFileName.Visible = !IsVisible;
                            riskFreeInterestRateUC.trVPSRFIRFromToDateNonInd.Visible = !IsVisible;
                            riskFreeInterestRateUC.btnRFIRApplyFilter.Visible = !IsVisible;
                            riskFreeInterestRateUC.btnRFIRClearFilter.Visible = !IsVisible;
                            riskFreeInterestRateUC.tdBtnRFIR.ColSpan = 5;
                        }
                        break;

                    case "Dividend":
                        using (DividendUC dividendUC = (DividendUC)PageObject)
                        {
                            dividendUC.Dividend_td1.Visible = IsVisible;
                            dividendUC.Dividend_td2.Visible = IsVisible;
                            dividendUC.Dividend_td3.Visible = IsVisible;
                            dividendUC.Dividend_td4.Visible = IsVisible;
                            dividendUC.Dividend_td5.Visible = IsVisible;
                            dividendUC.Dividend_td6.Visible = IsVisible;
                            dividendUC.btnDividendPreview.Visible = IsVisible;
                            dividendUC.btnDividendSave_Text.Visible = IsVisible;
                            dividendUC.gvDividend.Visible = !IsVisible;
                            dividendUC.btnDividendSave.Visible = !IsVisible;
                            dividendUC.Dividend_tr1.Visible = !IsVisible;
                            dividendUC.Dividend_tr2.Visible = !IsVisible;
                            dividendUC.btnVPSDividendReset.Visible = !IsVisible;
                            dividendUC.DivToBeCon.Width = "40%";
                            dividendUC.DivSpecial.Width = "40%";
                            dividendUC.DivYeield.Width = "40%";
                            dividendUC.tdBtnDividend.ColSpan = 4;
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// this method returns the common success / failure codes after operation.
        /// </summary>
        /// <param name="s_status">status of operation</param>
        /// <returns>returns string code</returns>
        public string GetMessageCode(int s_status)
        {
            string s_OutputMessage = string.Empty;
            try
            {
                switch (s_status)
                {
                    case 0:
                        s_OutputMessage = "RPPError";
                        break;
                    case 1:
                        s_OutputMessage = "RPPAdded";
                        break;
                    case 2:
                        s_OutputMessage = "RPPUpdated";
                        break;
                }

            }
            catch
            {
                throw;
            }

            return s_OutputMessage;
        }

        /// <summary>
        /// This method performs the CUD operations for marketPriceIV page.
        /// </summary>
        /// <param name="marketPriceUC">object of marketPrice page</param>
        internal string PerformCUD_marketPriceIV(MarketPriceUC marketPriceUC)
        {
            string s_OutputMessage = string.Empty;

            try
            {
                commonValuationProperties();
                if (marketPriceUC.lblIVSE01.Checked)
                {
                    valuationProperties.ParameterId1 = marketPriceUC.lblIVSE01.ID;
                    valuationProperties.Parameter_child_Id1 = Convert.ToString(marketPriceUC.ddlIVStockExchange.SelectedItem.Value);
                    valuationProperties.Paprameter_Sequence1 = marketPriceUC.ddIVStockExtext_Rank.SelectedValue;

                }
                else
                {
                    valuationProperties.ParameterId1 = marketPriceUC.lblIVSE02.ID;
                    valuationProperties.Parameter_child_Id1 = Convert.ToString(0);
                    valuationProperties.Paprameter_Sequence1 = marketPriceUC.ddIVStockExtext_Rank.SelectedValue;
                }

                valuationProperties.ParameterText1 = marketPriceUC.txtIVStockExchangeType.Text;

                if (marketPriceUC.lblIVDMP01.Checked)
                {
                    valuationProperties.ParameterId2 = marketPriceUC.lblIVDMP01.ID;
                    valuationProperties.Parameter_child_Id2 = "0";
                }
                else if (marketPriceUC.lblIVDMP02.Checked)
                {
                    valuationProperties.ParameterId2 = marketPriceUC.lblIVDMP02.ID;
                    valuationProperties.Parameter_child_Id2 = "0";
                }

                valuationProperties.ParameterText2 = marketPriceUC.txtIVDateOfMarketPriceText.Text;
                valuationProperties.Paprameter_Sequence2 = marketPriceUC.ddIVMarketPriceDate_Rank.SelectedValue;

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    s_OutputMessage = GetMessageCode(valuationServiceClient.CRUDValuationOperations(valuationProperties).a_result);
                }

                Get_SavedParameterText("GET_PARAMETER_TEXT");
                marketPriceUC.trVPSIntriValue.Style.Add("display", "");
                marketPriceUC.imgIVHideShow.Attributes.Add("title", "Click here to collapse");
                marketPriceUC.imgIVHideShow.Attributes.Add("src", "~/View/App_Themes/images/up.png");
                return s_OutputMessage;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method performs the CUD operations for marketPriceFV page.
        /// </summary>
        /// <param name="marketPriceUC">object marketPriceFV page</param>
        internal string PerformCUD_marketPriceFV(MarketPriceUC marketPriceUC)
        {
            string s_OutputMessage = string.Empty;
            try
            {
                commonValuationProperties();

                if (marketPriceUC.lblFVSE01.Checked)
                {
                    valuationProperties.ParameterId1 = marketPriceUC.lblFVSE01.ID;
                    valuationProperties.Parameter_child_Id1 = Convert.ToString(marketPriceUC.ddlFVStockExchange.SelectedItem.Value);
                    valuationProperties.Paprameter_Sequence1 = marketPriceUC.ddFVStockExtext_Rank.SelectedValue;
                }
                else
                {
                    valuationProperties.ParameterId1 = marketPriceUC.lblFVSE02.ID;
                    valuationProperties.Parameter_child_Id1 = Convert.ToString(0);
                    valuationProperties.Paprameter_Sequence1 = marketPriceUC.ddFVStockExtext_Rank.SelectedValue;
                }

                valuationProperties.ParameterText1 = marketPriceUC.txtFVStockExchangeTypeText.Text;

                valuationProperties.ParameterId2 = marketPriceUC.lblFVDMP01.ID;
                valuationProperties.Parameter_child_Id2 = "0";
                valuationProperties.ParameterText2 = marketPriceUC.txtFVDateOfMarketPriceText.Text;
                valuationProperties.Paprameter_Sequence2 = marketPriceUC.ddFVMarketPriceDate_Rank.SelectedValue;

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    s_OutputMessage = GetMessageCode(valuationServiceClient.CRUDValuationOperations(valuationProperties).a_result);
                }

                Get_SavedParameterText("GET_PARAMETER_TEXT");
                marketPriceUC.trVPSFairValue.Style.Add("display", "");
                marketPriceUC.imgFVHideShow.Attributes.Add("title", "Click here to collapse");
                marketPriceUC.imgFVHideShow.Attributes.Add("src", "~/View/App_Themes/images/up.png");
                return s_OutputMessage;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method performs the CUD operations for ExpectedLife page.
        /// </summary>
        /// <param name="expectedLifeUC">object expectedLifeUC page</param>
        public string PerformCUD_ExpectedLife(ExpectedLifeUC expectedLifeUC)
        {
            string s_OutputMessage = "";

            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    commonValuationProperties();

                    if (expectedLifeUC.lblMCEL01.Checked)
                    {
                        valuationProperties.ParameterId1 = expectedLifeUC.lblMCEL01.ID;
                        valuationProperties.Parameter_child_Id1 = "0";
                    }
                    else if (expectedLifeUC.lblMCEL02.Checked)
                    {
                        valuationProperties.ParameterId1 = expectedLifeUC.lblMCEL02.ID;
                        valuationProperties.Parameter_child_Id1 = expectedLifeUC.rdoELPastExerBehaviorYrs.Checked ? "Y" : expectedLifeUC.rdoELPastExerBehaviorMnts.Checked ? "M" : expectedLifeUC.rdoELPastExerBehaviorDays.Checked ? "D" : "";
                    }
                    else if (expectedLifeUC.lblMCEL03.Checked)
                    {
                        valuationProperties.ParameterId1 = expectedLifeUC.lblMCEL03.ID;
                        valuationProperties.Parameter_child_Id1 = expectedLifeUC.rdoExpLifeYears.Checked ? "Y" : expectedLifeUC.rdoExpLifeMonths.Checked ? "M" : expectedLifeUC.rdoExpLifeDays.Checked ? "D" : "";
                    }

                    valuationProperties.ParameterText1 = expectedLifeUC.txtExpectedLifeMethodText.Text;
                    s_OutputMessage = GetMessageCode(valuationServiceClient.CRUDValuationOperations(valuationProperties).a_result);
                }

                Get_SavedParameterText("GET_PARAMETER_TEXT");

                return s_OutputMessage;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method performs the CUD operations for Volatility page.
        /// </summary>
        /// <param name="volatilityUC">object of volatilityUC page</param>
        internal string PerformCUD_Volatility(VolatilityUC volatilityUC)
        {
            string s_OutputMessage = string.Empty;

            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    commonValuationProperties();

                    if (volatilityUC.lblVOL01.Checked)
                    {
                        valuationProperties.ParameterId1 = volatilityUC.lblVOL01.ID;
                        valuationProperties.Parameter_child_Id1 = Convert.ToString(volatilityUC.ddlVPSStockExchge_VC.SelectedItem.Value);
                    }
                    else if (volatilityUC.lblVOL02.Checked)
                    {
                        valuationProperties.ParameterId1 = volatilityUC.lblVOL02.ID;
                        valuationProperties.Parameter_child_Id1 = Convert.ToString(0);
                    }
                    else if (volatilityUC.lblVOL03.Checked)
                    {
                        valuationProperties.ParameterId1 = volatilityUC.lblVOL03.ID;
                        valuationProperties.Parameter_child_Id1 = Convert.ToString(0);
                    }

                    if (volatilityUC.lblMPTCV01.Checked)
                    {
                        valuationProperties.ParameterId2 = volatilityUC.lblMPTCV01.ID;
                        valuationProperties.Parameter_child_Id2 = volatilityUC.lblTDD01.Checked ? volatilityUC.lblTDD01.ID : volatilityUC.lblTDD02.Checked ? volatilityUC.lblTDD02.ID : volatilityUC.lblTDD03.ID;
                    }

                    valuationProperties.ParameterText1 = volatilityUC.txtVolatilityof_text.Text;
                    valuationProperties.ParameterText2 = volatilityUC.txtCalVolatilityText.Text;

                    if (volatilityUC.lblPTCV01.Checked)
                    {
                        valuationProperties.ParameterId3 = volatilityUC.lblPTCV01.ID;
                        valuationProperties.Parameter_child_Id3 = Convert.ToString(0);
                    }
                    else if (volatilityUC.lblPTCV02.Checked)
                    {
                        valuationProperties.ParameterId3 = volatilityUC.lblPTCV02.ID;
                        valuationProperties.Parameter_child_Id3 = Convert.ToString(0);
                    }
                    else if (volatilityUC.lblPTCV03.Checked)
                    {
                        valuationProperties.ParameterId3 = volatilityUC.lblPTCV03.ID;
                        valuationProperties.Parameter_child_Id3 = volatilityUC.rdoVolatilityYears.Checked ? "Y" : volatilityUC.rdoVolatilityMonths.Checked ? "M" : volatilityUC.rdoVolatilityDays.Checked ? "D" : "";
                    }

                    valuationProperties.ParameterText3 = volatilityUC.txtVolatilityCalPeriodText.Text;

                    valuationProperties.ParameterId4 = volatilityUC.chkVPSVolExcludeVol.ID;
                    valuationProperties.Parameter_child_Id4 = "0";
                    valuationProperties.ParameterText4 = volatilityUC.txtExclVolText.Text;
                    valuationProperties.Paprameter_Sequence1 = volatilityUC.ddVolatilityOf_Rank.SelectedValue;
                    valuationProperties.Paprameter_Sequence2 = volatilityUC.ddMPToCalcVol_Rank.SelectedValue;
                    valuationProperties.Paprameter_Sequence3 = volatilityUC.ddPrdsToCalVol_Rank.SelectedValue;
                    valuationProperties.Paprameter_Sequence4 = volatilityUC.ddExcludeVol_rank.SelectedValue;

                    s_OutputMessage = GetMessageCode(valuationServiceClient.CRUDValuationOperations(valuationProperties).a_result);
                }

                Get_SavedParameterText("GET_PARAMETER_TEXT");

                return s_OutputMessage;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method performs the CUD operations for RFIR page.
        /// </summary>
        /// <param name="riskFreeInterestRateUC">object of report parameters page</param>
        public string PerformCUD_RFIR(RiskFreeInterestRateUC riskFreeInterestRateUC)
        {
            string s_OutputMessage = "";
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    commonValuationProperties();

                    valuationProperties.ParameterId1 = riskFreeInterestRateUC.ddlVPSRFIRCountryList.ID;
                    valuationProperties.Parameter_child_Id1 = riskFreeInterestRateUC.ddlVPSRFIRCountryList.SelectedValue;

                    valuationProperties.ParameterText1 = riskFreeInterestRateUC.txtVPSRFIRCountryText.Text;
                    s_OutputMessage = GetMessageCode(valuationServiceClient.CRUDValuationOperations(valuationProperties).a_result);
                }

                Get_SavedParameterText("GET_PARAMETER_TEXT");

                return s_OutputMessage;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method performs the CUD operations for Dividend page.
        /// </summary>
        /// <param name="dividendUC">object of dividendUC page</param>
        internal string PerformCUD_Dividend(DividendUC dividendUC)
        {
            try
            {
                string s_OutputMessage = string.Empty;

                commonValuationProperties();

                if (dividendUC.lblDIV01.Checked)
                {
                    valuationProperties.ParameterId1 = dividendUC.lblDIV01.ID;
                    valuationProperties.Parameter_child_Id1 = Convert.ToString(0);
                }
                else
                {
                    if (dividendUC.lblDIV02.Checked)
                    {
                        valuationProperties.ParameterId1 = dividendUC.lblDIV02.ID;
                        valuationProperties.Parameter_child_Id1 = Convert.ToString(0);
                    }
                    else if (dividendUC.lblDIV03.Checked)
                    {
                        valuationProperties.ParameterId1 = dividendUC.lblDIV03.ID;
                        valuationProperties.Parameter_child_Id1 = Convert.ToString(0);
                    }
                    else
                    {
                        if (dividendUC.lblDIV04.Checked)
                        {
                            valuationProperties.ParameterId1 = dividendUC.lblDIV04.ID;
                            valuationProperties.Parameter_child_Id1 = Convert.ToString(0);
                        }
                    }
                }

                valuationProperties.ParameterText1 = dividendUC.txtDividendConsideredText.Text;

                valuationProperties.ParameterId2 = dividendUC.chkVPSSpecialDividend.ID;
                valuationProperties.Parameter_child_Id2 = Convert.ToString(dividendUC.chkVPSSpecialDividend.Checked ? "1" : "0");
                valuationProperties.ParameterText2 = dividendUC.txtSpecialDividendText.Text;

                if (dividendUC.lblMPTCD01.Checked)
                {
                    valuationProperties.ParameterId3 = dividendUC.lblMPTCD01.ID;
                    valuationProperties.Parameter_child_Id3 = Convert.ToString(0);
                }
                else if (dividendUC.lblMPTCD02.Checked)
                {
                    valuationProperties.ParameterId3 = dividendUC.lblMPTCD02.ID;
                    valuationProperties.Parameter_child_Id3 = Convert.ToString(dividendUC.ddlVPSStockExchge_DC.SelectedValue);
                }

                valuationProperties.ParameterText3 = dividendUC.txtDividendYeildText.Text;
                valuationProperties.Paprameter_Sequence1 = dividendUC.ddDivToBeConsidered_Rank.SelectedValue;
                valuationProperties.Paprameter_Sequence2 = dividendUC.ddSpecialDiv_Rank.SelectedValue;
                valuationProperties.Paprameter_Sequence3 = dividendUC.ddMPDivCal_Rank.SelectedValue;

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    s_OutputMessage = GetMessageCode(valuationServiceClient.CRUDValuationOperations(valuationProperties).a_result);
                }

                Get_SavedParameterText("GET_PARAMETER_TEXT");

                return s_OutputMessage;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method gives the preview of report parameter text for each page when called individually .
        /// </summary>
        /// <param name="PageObject">Page object</param>
        /// <param name="s_PageName">page name</param>
        public void GetPriview_MPIV(object PageObject, string s_PageName)
        {
            string s_TextToBePreviewed = string.Empty;
            string[] PreviewData = new string[4];

            try
            {
                switch (s_PageName)
                {
                    case "Market_Price_IV":
                        using (MarketPriceUC marketPriceUC = (MarketPriceUC)PageObject)
                        {
                            PreviewData[Convert.ToUInt16(marketPriceUC.ddIVStockExtext_Rank.SelectedValue)] = marketPriceUC.txtIVStockExchangeType.Text;
                            PreviewData[Convert.ToUInt16(marketPriceUC.ddIVMarketPriceDate_Rank.SelectedValue)] = marketPriceUC.txtIVDateOfMarketPriceText.Text;
                            marketPriceUC.ctrPreview_MPIV.s_PreviewText = Convert.ToString(PreviewData[0]) + " " + Convert.ToString(PreviewData[1]) + " " + Convert.ToString(PreviewData[2]);
                            marketPriceUC.ctrPreview_MPIV.b_IsVisible = true;
                            marketPriceUC.ctrPreview_MPFV.b_IsVisible = false;
                            marketPriceUC.trVPSIntriValue.Style.Add("display", "");
                            marketPriceUC.imgIVHideShow.Attributes.Add("title", "Click here to collapse");
                            marketPriceUC.imgIVHideShow.Attributes.Add("src", "~/View/App_Themes/images/up.png");
                        }
                        break;

                    case "Market_Price_FV":
                        using (MarketPriceUC marketPriceUC_Fv = (MarketPriceUC)PageObject)
                        {
                            PreviewData[Convert.ToUInt16(marketPriceUC_Fv.ddFVStockExtext_Rank.SelectedValue)] = marketPriceUC_Fv.txtFVStockExchangeTypeText.Text;
                            PreviewData[Convert.ToUInt16(marketPriceUC_Fv.ddFVMarketPriceDate_Rank.SelectedValue)] = marketPriceUC_Fv.txtFVDateOfMarketPriceText.Text;
                            marketPriceUC_Fv.ctrPreview_MPFV.s_PreviewText = Convert.ToString(PreviewData[0]) + " " + Convert.ToString(PreviewData[1]) + " " + Convert.ToString(PreviewData[2]);
                            marketPriceUC_Fv.ctrPreview_MPFV.b_IsVisible = true;
                            marketPriceUC_Fv.ctrPreview_MPIV.b_IsVisible = false;
                            marketPriceUC_Fv.trVPSFairValue.Style.Add("display", "");
                            marketPriceUC_Fv.imgFVHideShow.Attributes.Add("title", "Click here to collapse");
                            marketPriceUC_Fv.imgFVHideShow.Attributes.Add("src", "~/View/App_Themes/images/up.png");
                        }
                        break;

                    case "Expected_Life":
                        using (ExpectedLifeUC expectedLifeUC = (ExpectedLifeUC)PageObject)
                        {
                            PreviewData[0] = expectedLifeUC.txtExpectedLifeMethodText.Text;
                            s_TextToBePreviewed = Convert.ToString(PreviewData[0]) + Convert.ToString(PreviewData[1]) + Convert.ToString(PreviewData[2]);

                            if (s_TextToBePreviewed.Contains("@Past_Exercise_Behaviour_Years"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@Past_Exercise_Behaviour_Years", expectedLifeUC.txtELPastExerBehaviorYrs.Text);

                            if (s_TextToBePreviewed.Contains("@Past_Exercise_Behaviour_Months"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@Past_Exercise_Behaviour_Months", expectedLifeUC.txtELPastExerBehaviorMnts.Text);

                            if (s_TextToBePreviewed.Contains("@Past_Exercise_Behaviour_Days"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@Past_Exercise_Behaviour_Days", expectedLifeUC.txtELPastExerBehaviorDays.Text);

                            if (s_TextToBePreviewed.Contains("@EXPL_Specified_Period_Years"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@EXPL_Specified_Period_Years", expectedLifeUC.txtExpLifeYears.Text);

                            if (s_TextToBePreviewed.Contains("@EXPL_Specified_Period_Months"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@EXPL_Specified_Period_Months", expectedLifeUC.txtExpLifeMonths.Text);

                            if (s_TextToBePreviewed.Contains("@EXPL_Specified_Period_Days"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@EXPL_Specified_Period_Days", expectedLifeUC.txtExpLifeDays.Text);

                            expectedLifeUC.ctrPreview_EL.s_PreviewText = s_TextToBePreviewed;
                            expectedLifeUC.ctrPreview_EL.b_IsVisible = true;
                        }
                        break;

                    case "Volatility":
                        using (VolatilityUC volatilityUC = (VolatilityUC)PageObject)
                        {
                            PreviewData[Convert.ToUInt16(volatilityUC.ddVolatilityOf_Rank.SelectedValue) - 1] = volatilityUC.txtVolatilityof_text.Text;
                            PreviewData[Convert.ToUInt16(volatilityUC.ddMPToCalcVol_Rank.SelectedValue) - 1] = volatilityUC.txtCalVolatilityText.Text;
                            PreviewData[Convert.ToUInt16(volatilityUC.ddPrdsToCalVol_Rank.SelectedValue) - 1] = volatilityUC.txtVolatilityCalPeriodText.Text;
                            PreviewData[Convert.ToUInt16(volatilityUC.ddExcludeVol_rank.SelectedValue) - 1] = volatilityUC.txtExclVolText.Text;
                            s_TextToBePreviewed = Convert.ToString(PreviewData[0]) + " " + Convert.ToString(PreviewData[1]) + " " + Convert.ToString(PreviewData[2]) + Convert.ToString(PreviewData[3]);

                            if (s_TextToBePreviewed.Contains("@PeerCompany_On_StockExchange"))
                            {
                                Load_PeerCompanies();

                                string s_PeerCompanyStatement = string.Empty;
                                string s_PeerCompanyNames = string.Empty;
                                string s_StockExNames = string.Empty;

                                for (int i = 0; i < ac_ReportPamameter.dt_GetPeerCompanies.Rows.Count; i++)
                                {
                                    s_PeerCompanyNames = s_PeerCompanyNames + ac_ReportPamameter.dt_GetPeerCompanies.Rows[i][0].ToString() + ",";
                                    s_StockExNames = s_StockExNames + ac_ReportPamameter.dt_GetPeerCompanies.Rows[i][1].ToString() + ",";
                                }

                                if (ac_ReportPamameter.dt_GetPeerCompanies.Rows.Count > 0)
                                {
                                    s_PeerCompanyNames = s_PeerCompanyNames.Substring(0, (s_PeerCompanyNames.Length) - 1).ToString();
                                    s_StockExNames = s_StockExNames.Substring(0, (s_StockExNames.Length) - 1).ToString();
                                    s_PeerCompanyStatement = s_PeerCompanyNames + " on " + s_StockExNames;
                                    s_TextToBePreviewed = s_TextToBePreviewed.Replace("@PeerCompany_On_StockExchange", s_PeerCompanyStatement);
                                }
                            }

                            if (s_TextToBePreviewed.Contains("@SpecifyDays_MarketPrice"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@SpecifyDays_MarketPrice", volatilityUC.txtVPSSpecifyDaysDaily.Text);

                            if (s_TextToBePreviewed.Contains("@Vol_Specified_Period_Years"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@Vol_Specified_Period_Years", volatilityUC.txtVolatilityYears.Text);

                            if (s_TextToBePreviewed.Contains("@Vol_Specified_Period_Months"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@Vol_Specified_Period_Months", volatilityUC.txtVolatilityMonths.Text);

                            if (s_TextToBePreviewed.Contains("@Vol_Specified_Period_Days"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@Vol_Specified_Period_Days", volatilityUC.txtVolatilityDays.Text);

                            if (s_TextToBePreviewed.Contains("@FromDate"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@FromDate", volatilityUC.txtVPSExcludeFromDate.Text);

                            if (s_TextToBePreviewed.Contains("@ToDate"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@ToDate", volatilityUC.txtVPSExcludeToDate.Text);
                            volatilityUC.ctrPreview_VC.s_PreviewText = s_TextToBePreviewed;
                            volatilityUC.ctrPreview_VC.b_IsVisible = true;
                        }
                        break;

                    case "RFIR":
                        using (RiskFreeInterestRateUC riskFreeInterestRateUC = (RiskFreeInterestRateUC)PageObject)
                        {
                            PreviewData[0] = riskFreeInterestRateUC.txtVPSRFIRCountryText.Text;
                            riskFreeInterestRateUC.ctrPreview_RFIR.s_PreviewText = Convert.ToString(PreviewData[0]) + Convert.ToString(PreviewData[1]) + Convert.ToString(PreviewData[2]);
                            riskFreeInterestRateUC.ctrPreview_RFIR.b_IsVisible = true;
                        }
                        break;

                    case "Dividend":
                        using (DividendUC dividendUC = (DividendUC)PageObject)
                        {
                            PreviewData[Convert.ToUInt16(dividendUC.ddDivToBeConsidered_Rank.SelectedValue)] = dividendUC.txtDividendConsideredText.Text;
                            PreviewData[Convert.ToUInt16(dividendUC.ddSpecialDiv_Rank.SelectedValue)] = dividendUC.txtSpecialDividendText.Text;
                            PreviewData[Convert.ToUInt16(dividendUC.ddMPDivCal_Rank.SelectedValue)] = dividendUC.txtDividendYeildText.Text;
                            s_TextToBePreviewed = Convert.ToString(PreviewData[0]) + " " + Convert.ToString(PreviewData[1]) + " " + Convert.ToString(PreviewData[2]) + " " + Convert.ToString(PreviewData[3]);

                            if (s_TextToBePreviewed.Contains("@Average_Dividend_years"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@Average_Dividend_years", dividendUC.ddlAvgDividend.SelectedItem.ToString());

                            if (s_TextToBePreviewed.Contains("@Consider_Dividend_Rupees"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@@Consider_Dividend_Rupees", dividendUC.txtVPSDivDividend.Text);

                            if (s_TextToBePreviewed.Contains("@DividendFrom_ToDate"))
                                s_TextToBePreviewed = s_TextToBePreviewed.Replace("@DividendFrom_ToDate", dividendUC.txtVPSDivFromDate.Text + " " + dividendUC.txtVPSDivToDate.Text);

                            dividendUC.ctrPreview_DC.s_PreviewText = s_TextToBePreviewed;
                            dividendUC.ctrPreview_DC.b_IsVisible = true;
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method loads the corresponding text whose parent_id and Child_id is selected.
        /// </summary>
        /// <param name="Paraent_Parameter">parent id</param>
        /// <param name="Child_Parameter">child id.</param>
        /// <param name="txt"></param>
        public void changeTextOnRadioSelection(string Paraent_Parameter, string Child_Parameter, TextBox txt)
        {
            try
            {
                if (ac_ReportPamameter.dt_ReportParameterText.Rows.Count > 0)
                    txt.Text = Convert.ToString(ac_ReportPamameter.dt_ReportParameterText.Select("PARAMETER_ID =  '" + Paraent_Parameter + "' and PARAMETER_CHILD_ID =  '" + Child_Parameter + "'")[0]["PARAMETER_TEXT"]);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method keeps MarketPrice IV/FV Accordian open after a postback occurs from any radio button click.
        /// </summary>
        /// <param name="s_Type">Object of Market Price IV/FV accordian name</param>
        /// <param name="marketPriceUC">Object of MarketPrice User control</param>
        public void ShowHideIVFVAccordion(string s_Type, MarketPriceUC marketPriceUC)
        {
            try
            {
                if (!string.IsNullOrEmpty(s_Type))
                {
                    switch (s_Type)
                    {
                        case "IV":
                            marketPriceUC.trVPSIntriValue.Style.Add("display", "");
                            marketPriceUC.imgIVHideShow.Attributes.Add("title", "Click here to collapse");
                            marketPriceUC.imgIVHideShow.Attributes.Add("src", "~/View/App_Themes/images/up.png");
                            break;
                        case "FV":
                            marketPriceUC.trVPSFairValue.Style.Add("display", "");
                            marketPriceUC.imgFVHideShow.Attributes.Add("title", "Click here to collapse");
                            marketPriceUC.imgFVHideShow.Attributes.Add("src", "~/View/App_Themes/images/up.png");
                            break;
                    }
                }

            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ReportParametersModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}