﻿using EDFinancials.Model.Generic;
using EDFinancials.UserControl.User.Valuation;
using EDFinancials.View.Valuation;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Expected Life user control Model
    /// </summary>
    public class ExpectedLifeUCModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public ExpectedLifeUCModel()
        {
            if (ac_ValuationParameter == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationParameter);
                ac_ValuationParameter = (CommonModel.AC_ValuationParameter)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationParameter];
            }
        }

        #region Expected Life

        /// <summary>
        /// This method is used to bind 'Expected Life' tab controls on page load
        /// </summary>
        /// <param name="ds_ValuationParameters">DataSet Object</param>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        /// <param name="s_GrantDate"></param>
        /// <param name="s_GrantID"></param>
        public void BindExpectedLifeControls(DataSet ds_ValuationParameters, ValuationParameters valuationParametersSetup, string s_GrantDate, string s_GrantID)
        {
            try
            {
                ac_ValuationParameter.dt_ExpectedLife = ac_ValuationParameter.ds_ValuationParameters.Tables[5];
                valuationParametersSetup.ctrExpectedLife.gvExpectedLife.DataSource = ac_ValuationParameter.dt_ExpectedLife;
                valuationParametersSetup.ctrExpectedLife.gvExpectedLife.DataBind();

                ac_ValuationParameter.dt_CurrEstimatedDOLDetails = ac_ValuationParameter.ds_ValuationParameters.Tables[15];
                valuationParametersSetup.ctrExpectedLife.gvVPSCurrEstDtOfListing.DataSource = ac_ValuationParameter.dt_CurrEstimatedDOLDetails;
                valuationParametersSetup.ctrExpectedLife.gvVPSCurrEstDtOfListing.DataBind();

                BindControls(valuationParametersSetup, s_GrantDate, s_GrantID);
                SetApprovalHiddenField(valuationParametersSetup);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to set hidden field to check approval status
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        public void SetApprovalHiddenField(ValuationParameters valuationParametersSetup)
        {
            try
            {
                bool s_IsApproved = (from query in ac_ValuationParameter.dt_ExpectedLife.AsEnumerable()
                                     where query.Field<string>("Approval Status") == "Pending"
                                     select query.Field<string>("Approval Status")).Distinct().Count() > 0 ? false : true;
                valuationParametersSetup.ctrExpectedLife.hdnVPS_IsApproved_ELC.Value = s_IsApproved ? "1" : "0";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  This method is used to bind 'Expected Life' tab controls on page load
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        /// <param name="s_GrantDate"></param>
        /// <param name="s_GrantID"></param>
        public void BindControls(ValuationParameters valuationParametersSetup, string s_GrantDate, string s_GrantID)
        {
            try
            {
                #region This is used to bind controls at time of redirect from Valuation Report page
                if (!string.IsNullOrEmpty(s_GrantDate))
                {
                    foreach (DataRow perRow in ac_ValuationParameter.ds_ValuationParameters.Tables[5].Select("[To Date] IS NULL"))
                    {
                        perRow["To Date"] = DateTime.Now.Date;
                    }
                }
                #endregion

                DataRow[] dr_GrantLevelSettings = null;
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    if (!string.IsNullOrEmpty(s_GrantDate))
                    {
                        valuationProperties.PageName = CommonConstantModel.s_ValuationParameters;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        dr_GrantLevelSettings = valuationCRUDProperties.ds_Result.Tables[5].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'");
                    }
                }

                using (DataTable dt_ValuationParameters = string.IsNullOrEmpty(s_GrantDate) ? ac_ValuationParameter.ds_ValuationParameters.Tables[4] : dr_GrantLevelSettings.Count() > 0 ? dr_GrantLevelSettings.CopyToDataTable() : ac_ValuationParameter.ds_ValuationParameters.Tables[5].Select("[Applicable From Date] <= #" + Convert.ToDateTime(s_GrantDate).Date + "# AND [To Date] >= #" + Convert.ToDateTime(s_GrantDate).Date + "#").CopyToDataTable())
                {
                    #region This is used to bind controls at time of redirect from Valuation Report page
                    if (!string.IsNullOrEmpty(s_GrantDate) && dr_GrantLevelSettings.Count().Equals(0))
                    {
                        dt_ValuationParameters.Columns["Method for Calculating Expected Life"].ColumnName = "CAL_METHOD_LABEL_ID";
                        dt_ValuationParameters.Columns["Remark"].ColumnName = "REMARK";
                        dt_ValuationParameters.Columns["Applicable From Date"].ColumnName = "APPLICABLE_FROM_DATE";
                    }
                    else if (dr_GrantLevelSettings != null && dr_GrantLevelSettings.Count() > 0)
                    {
                        dt_ValuationParameters.Columns["GRANT_CAL_EXPECTED_LIFE"].ColumnName = "CAL_METHOD_LABEL_ID";
                        dt_ValuationParameters.Columns["GRANT_CONSIDER_PERIOD_IN"].ColumnName = "CONSIDER_PERIOD_IN";
                        dt_ValuationParameters.Columns["GRANT_CONSIDER_VALUE"].ColumnName = "CONSIDER_VALUE";
                    }
                    #endregion

                    if (userSessionInfo.ACC_IsListed.Equals(1))
                        valuationParametersSetup.ctrExpectedLife.divVPSELEstDateOfListing.Style.Add("display", "none");
                    else
                        valuationParametersSetup.ctrExpectedLife.divVPSELEstDateOfListing.Style.Add("display", "");

                    if (dt_ValuationParameters.Rows.Count > 0)
                    {
                        if (Convert.ToString(dt_ValuationParameters.Rows[0]["CAL_METHOD_LABEL_ID"]).Trim().Equals("lblMCEL01"))
                            valuationParametersSetup.ctrExpectedLife.lblMCEL01.Checked = true;
                        else if (Convert.ToString(dt_ValuationParameters.Rows[0]["CAL_METHOD_LABEL_ID"]).Trim().Equals("lblMCEL02"))
                        {
                            valuationParametersSetup.ctrExpectedLife.lblMCEL02.Checked = true;
                            if (Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_PERIOD_IN"]).Trim().Equals("Y"))
                            {
                                valuationParametersSetup.ctrExpectedLife.rdoELPastExerBehaviorYrs.Checked = true;
                                valuationParametersSetup.ctrExpectedLife.txtELPastExerBehaviorYrs.Text = Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_VALUE"]).Trim();
                            }
                            else if (Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_PERIOD_IN"]).Trim().Equals("M"))
                            {
                                valuationParametersSetup.ctrExpectedLife.rdoELPastExerBehaviorMnts.Checked = true;
                                valuationParametersSetup.ctrExpectedLife.txtELPastExerBehaviorMnts.Text = Convert.ToString(Convert.ToInt32(dt_ValuationParameters.Rows[0]["CONSIDER_VALUE"]));
                            }
                            else if (Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_PERIOD_IN"]).Trim().Equals("D"))
                            {
                                valuationParametersSetup.ctrExpectedLife.rdoELPastExerBehaviorDays.Checked = true;
                                valuationParametersSetup.ctrExpectedLife.txtELPastExerBehaviorDays.Text = Convert.ToString(Convert.ToInt32(dt_ValuationParameters.Rows[0]["CONSIDER_VALUE"]));
                            }
                        }
                        else if (Convert.ToString(dt_ValuationParameters.Rows[0]["CAL_METHOD_LABEL_ID"]).Trim().Equals("lblMCEL03"))
                        {
                            valuationParametersSetup.ctrExpectedLife.lblMCEL03.Checked = true;

                            if (Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_PERIOD_IN"]).Trim().Equals("Y"))
                            {
                                valuationParametersSetup.ctrExpectedLife.rdoExpLifeYears.Checked = true;
                                valuationParametersSetup.ctrExpectedLife.txtExpLifeYears.Text = Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_VALUE"]).Trim();
                            }
                            else if (Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_PERIOD_IN"]).Trim().Equals("M"))
                            {
                                valuationParametersSetup.ctrExpectedLife.rdoExpLifeMonths.Checked = true;
                                valuationParametersSetup.ctrExpectedLife.txtExpLifeMonths.Text = Convert.ToString(Convert.ToInt32(dt_ValuationParameters.Rows[0]["CONSIDER_VALUE"]));
                            }
                            else if (Convert.ToString(dt_ValuationParameters.Rows[0]["CONSIDER_PERIOD_IN"]).Trim().Equals("D"))
                            {
                                valuationParametersSetup.ctrExpectedLife.rdoExpLifeDays.Checked = true;
                                valuationParametersSetup.ctrExpectedLife.txtExpLifeDays.Text = Convert.ToString(Convert.ToInt32(dt_ValuationParameters.Rows[0]["CONSIDER_VALUE"]));
                            }
                        }
                        else if (Convert.ToString(dt_ValuationParameters.Rows[0]["CAL_METHOD_LABEL_ID"]).Trim().Equals("lblMCEL04"))
                            valuationParametersSetup.ctrExpectedLife.lblMCEL04.Checked = true;

                        if (string.IsNullOrEmpty(s_GrantDate))
                        {
                            valuationParametersSetup.ctrExpectedLife.txtExpectedLifeRemark.Text = Convert.ToString(dt_ValuationParameters.Rows[0]["REMARK"]).Trim();
                            valuationParametersSetup.ctrExpectedLife.hdnVPSAppFromDate_ELC.Value = valuationParametersSetup.ctrExpectedLife.txtVPSApplicableValFromDate.Text = !string.IsNullOrEmpty(Convert.ToString(dt_ValuationParameters.Rows[0]["APPLICABLE_FROM_DATE"])) ? Convert.ToDateTime(dt_ValuationParameters.Rows[0]["APPLICABLE_FROM_DATE"]).ToString("dd/MMM/yyyy") : string.Empty; 
                        }
                        using (ValuationModel valuationModel = new ValuationModel())
                        {
                            valuationModel.SetButtonText(valuationParametersSetup.ctrExpectedLife.btnVPSExpectedLifeSave);
                        }
                    }
                }
                if (ac_ValuationParameter.ds_ValuationParameters.Tables[13].Rows.Count > 0)
                    valuationParametersSetup.ctrExpectedLife.hdnVPSELEstDateOfListing.Value = (ac_ValuationParameter.ds_ValuationParameters.Tables[13].Rows.Count > 0 && !string.IsNullOrEmpty(Convert.ToString(ac_ValuationParameter.ds_ValuationParameters.Tables[13].Rows[0]["ESTIMATED_DATE_OF_LISTING"]))) ? Convert.ToDateTime(ac_ValuationParameter.ds_ValuationParameters.Tables[13].Rows[0]["ESTIMATED_DATE_OF_LISTING"]).ToString("dd/MMM/yyyy") : string.Empty;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to update 'Expected Life' comnfig data
        /// </summary>
        /// <param name="expectedLifeUC">ExpectedLifeUC control object</param>
        /// <param name="s_Type">CUD operation type</param>
        /// <param name="s_PastExerciseFolderPath">Past Exercise Folder Path</param>
        /// <param name="s_SpecifiedPeriodFolderPath">Specified Period Folder Path</param>
        /// <returns>returns result of CURD operation</returns>
        public int UpdateExpectedLifeConfigData(ExpectedLifeUC expectedLifeUC, string s_Type, string s_PastExerciseFolderPath, string s_SpecifiedPeriodFolderPath)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties = new ValuationProperties();
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                    valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    valuationProperties.PopulateControls = s_Type;
                    if (userSessionInfo.ACC_UerTypeID.Equals(5))
                        valuationProperties.ELC_IS_APPROVED = true;
                    else valuationProperties.ELC_IS_APPROVED = false;

                    if (expectedLifeUC.lblMCEL01.Checked)
                    {
                        valuationProperties.ELC_CAL_METHOD_LABEL_ID = expectedLifeUC.lblMCEL01.ID;
                        valuationProperties.ELC_FILE_PATH = string.Empty;
                        valuationProperties.ELC_FILE_NAME = string.Empty;
                    }
                    else if (expectedLifeUC.lblMCEL02.Checked)
                    {
                        valuationProperties.ELC_CAL_METHOD_LABEL_ID = expectedLifeUC.lblMCEL02.ID;

                        if (expectedLifeUC.rdoELPastExerBehaviorYrs.Checked)
                        {
                            valuationProperties.ELC_CONSIDER_PERIOD_IN = "Y";
                            valuationProperties.ELC_CONSIDER_VALUE = Math.Round(Convert.ToDecimal(expectedLifeUC.txtELPastExerBehaviorYrs.Text.Trim()), 2);
                        }
                        else if (expectedLifeUC.rdoELPastExerBehaviorMnts.Checked)
                        {
                            valuationProperties.ELC_CONSIDER_PERIOD_IN = "M";
                            valuationProperties.ELC_CONSIDER_VALUE = Convert.ToInt32(expectedLifeUC.txtELPastExerBehaviorMnts.Text.Trim());
                        }
                        else if (expectedLifeUC.rdoELPastExerBehaviorDays.Checked)
                        {
                            valuationProperties.ELC_CONSIDER_PERIOD_IN = "D";
                            valuationProperties.ELC_CONSIDER_VALUE = Convert.ToInt32(expectedLifeUC.txtELPastExerBehaviorDays.Text.Trim());
                        }

                        string s_ReturnStr = SaveFileToServer(expectedLifeUC, "PastExerciseFiles", s_PastExerciseFolderPath);

                        if (!string.IsNullOrEmpty(s_ReturnStr))
                        {
                            string[] files = s_ReturnStr.Split('~');
                            valuationProperties.ELC_FILE_PATH = files[0];
                            valuationProperties.ELC_FILE_NAME = files[1];
                        }
                    }
                    else if (expectedLifeUC.lblMCEL03.Checked)
                    {
                        valuationProperties.ELC_CAL_METHOD_LABEL_ID = expectedLifeUC.lblMCEL03.ID;

                        if (expectedLifeUC.rdoExpLifeYears.Checked)
                        {
                            valuationProperties.ELC_CONSIDER_PERIOD_IN = "Y";
                            valuationProperties.ELC_CONSIDER_VALUE = Math.Round(Convert.ToDecimal(expectedLifeUC.txtExpLifeYears.Text), 2);
                        }
                        else if (expectedLifeUC.rdoExpLifeMonths.Checked)
                        {
                            valuationProperties.ELC_CONSIDER_PERIOD_IN = "M";
                            valuationProperties.ELC_CONSIDER_VALUE = Convert.ToInt32(expectedLifeUC.txtExpLifeMonths.Text.Trim());
                        }
                        else
                        {
                            valuationProperties.ELC_CONSIDER_PERIOD_IN = "D";
                            valuationProperties.ELC_CONSIDER_VALUE = Convert.ToInt32(expectedLifeUC.txtExpLifeDays.Text.Trim());
                        }

                        string s_ReturnStr = SaveFileToServer(expectedLifeUC, "SpecifiedPeriodFiles", s_SpecifiedPeriodFolderPath);

                        if (!string.IsNullOrEmpty(s_ReturnStr))
                        {
                            string[] files = s_ReturnStr.Split('~');
                            valuationProperties.ELC_FILE_PATH = files[0];
                            valuationProperties.ELC_FILE_NAME = files[1];
                        }
                    }
                    else if (expectedLifeUC.lblMCEL04.Checked)
                    {
                        valuationProperties.ELC_CAL_METHOD_LABEL_ID = expectedLifeUC.lblMCEL04.ID;
                        valuationProperties.ELC_EST_DATE_OF_LISTING = expectedLifeUC.hdnVPSELEstDateOfListing.Value;
                    }

                    valuationProperties.ELC_REMARK = expectedLifeUC.txtExpectedLifeRemark.Text;
                    valuationProperties.ELC_APPLICABLE_FROM_DATE = expectedLifeUC.txtVPSApplicableValFromDate.Text;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                    if (valuationCRUDProperties.a_result.Equals(1))
                    {
                        ParamChange(expectedLifeUC);
                        
						using (ValuationModel valuationModel = new ValuationModel())
                        {
                            valuationModel.SetButtonText(expectedLifeUC.btnVPSExpectedLifeSave);
                        }
                        expectedLifeUC.hdnVPSAppFromDate_ELC.Value = expectedLifeUC.txtVPSApplicableValFromDate.Text;
                    }

                    return valuationCRUDProperties.a_result;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void RowDataBindForGVEL(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "CONSIDER_PERIOD_IN":
                                    perColumn.Visible = false;
                                    break;
                                case "CONSIDER_VALUE":
                                    perColumn.Visible = false;
                                    break;
                                case "EST_DATE_OF_LISTING":
                                    perColumn.Visible = false;
                                    break;
                                case "AELCID":
                                    perColumn.Visible = false;
                                    break;
                                case "FILE_PATH":
                                    perColumn.Visible = false;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[1].Visible = e.Row.Cells[2].Visible = e.Row.Cells[5].Visible = e.Row.Cells[4].Visible = e.Row.Cells[9].Visible = false;
                        e.Row.Cells[7].HorizontalAlign = e.Row.Cells[8].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[7].Text) && !e.Row.Cells[7].Text.Equals("&nbsp;"))
                            e.Row.Cells[7].Text = Convert.ToDateTime(e.Row.Cells[7].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[8].Text) && !e.Row.Cells[8].Text.Equals("&nbsp;"))
                            e.Row.Cells[8].Text = Convert.ToDateTime(e.Row.Cells[8].Text).ToString("dd/MMM/yyyy");

                        e.Row.Cells[6].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;");

                        if (!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                        {
                            if (e.Row.Cells[0].Text.Trim().Equals("lblMCEL03") || e.Row.Cells[0].Text.Trim().Equals("lblMCEL02"))
                            {
                                string s_PrdIn = string.Empty;
                                if (e.Row.Cells[1].Text.Trim().Equals("Y"))
                                    s_PrdIn = Math.Round(Convert.ToDecimal(e.Row.Cells[2].Text.Trim()), 2) + " Year(s)";
                                else if (e.Row.Cells[1].Text.Trim().Equals("M"))
                                    s_PrdIn = Convert.ToDecimal(e.Row.Cells[2].Text.Trim()).ToString("N0") + " Month(s)";
                                else if (e.Row.Cells[1].Text.Trim().Equals("D"))
                                    s_PrdIn = Convert.ToDecimal(e.Row.Cells[2].Text.Trim()).ToString("N0") + " Day(s)";
                                e.Row.Cells[0].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[0].Text.Trim() + "'" + ""))[0]["LabelName"]) + " : " + s_PrdIn;
                            }
                            else if (e.Row.Cells[0].Text.Trim().Equals("lblMCEL04"))
                                e.Row.Cells[0].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[0].Text.Trim() + "'" + ""))[0]["LabelName"]) + " : " + ((!string.IsNullOrEmpty(e.Row.Cells[5].Text) && !e.Row.Cells[5].Text.Equals("&nbsp;")) ? Convert.ToDateTime(e.Row.Cells[5].Text).ToString("dd/MMM/yyyy") : string.Empty);
                            else e.Row.Cells[0].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[0].Text.Trim() + "'" + ""))[0]["LabelName"]);
                        }
                        e.Row.Cells[11].Controls.Add((Control)new VPSCommonModel().AddHistoryHyperLink(e.Row.Cells[9].Text, e.Row.Cells[7].Text, e.Row.Cells[8].Text, "ELC"));

                        if (!string.IsNullOrEmpty(e.Row.Cells[3].Text) && !e.Row.Cells[3].Text.Equals("&nbsp;"))
                            e.Row.Cells[3].Controls.Add((Control)new VPSCommonModel().AddHyperLink(e.Row.Cells[3].Text, e.Row.Cells[4].Text));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="expectedLifeUC">expectedLifeUC page object</param>
        public void PageIndexChangingForGVEL(int NewPageIndex, ExpectedLifeUC expectedLifeUC)
        {
            try
            {
                expectedLifeUC.gvExpectedLife.PageIndex = NewPageIndex;
                expectedLifeUC.gvExpectedLife.DataSource = ac_ValuationParameter.dt_ExpectedLife;
                expectedLifeUC.gvExpectedLife.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to save uploaded file to the server
        /// </summary>
        /// <param name="expectedLifeUC">ExpectedLifeUC control object</param>
        /// <param name="s_Type">file type</param>
        /// <param name="s_FolderPath">Folder path</param>
        /// <returns>returns server path</returns>
        public string SaveFileToServer(ExpectedLifeUC expectedLifeUC, string s_Type, string s_FolderPath)
        {
            try
            {
                switch (s_Type)
                {
                    case "PastExerciseFiles":
                        if (expectedLifeUC.fileUpVPSELPastExerBehavior.HasFile && !string.IsNullOrEmpty(expectedLifeUC.fileUpVPSELPastExerBehavior.FileName))
                        {
                            return UploadFile(expectedLifeUC.fileUpVPSELPastExerBehavior, s_FolderPath);
                        }
                        break;

                    case "SpecifiedPeriodFiles":
                        if (expectedLifeUC.fielUpVPSELSpecPrdFromVD.HasFile && !string.IsNullOrEmpty(expectedLifeUC.fielUpVPSELSpecPrdFromVD.FileName))
                        {
                            return UploadFile(expectedLifeUC.fielUpVPSELSpecPrdFromVD, s_FolderPath);
                        }
                        break;
                }
                return string.Empty;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to upload file to the server
        /// </summary>
        /// <param name="asyncFileUpload">Ajax AsyncFileUpload control object</param>
        /// <param name="s_FolderPath">Folder path</param>
        /// <returns>returns server path</returns>
        private string UploadFile(AjaxControlToolkit.AsyncFileUpload asyncFileUpload, string s_FolderPath)
        {
            try
            {
                string s_FilePath = string.Empty, s_FileName = string.Empty;
                s_FileName = Path.GetFileName(asyncFileUpload.FileName);
                if (!Directory.Exists(s_FolderPath))
                {
                    Directory.CreateDirectory(s_FolderPath);
                    s_FilePath = s_FolderPath + s_FileName;
                }
                else if (!File.Exists(s_FolderPath + s_FileName))
                {
                    s_FilePath = s_FolderPath + s_FileName;
                }
                else if (File.Exists(s_FolderPath + s_FileName))
                {
                    for (int i = 1; i < 100; i++)
                    {
                        if (!File.Exists(s_FolderPath + i + "\\" + s_FileName))
                        {
                            if (!Directory.Exists(s_FilePath = s_FolderPath + i + "\\"))
                                Directory.CreateDirectory(s_FilePath = s_FolderPath + i + "\\");
                            s_FilePath = s_FolderPath + i + "\\" + s_FileName;
                            goto loopEnd;
                        }
                    }
                }
            loopEnd:
                if (!string.IsNullOrEmpty(s_FilePath))
                    asyncFileUpload.SaveAs(s_FilePath);
                asyncFileUpload.ClearAllFilesFromPersistedStore();
                return !string.IsNullOrEmpty(s_FileName) ? s_FilePath + "~" + s_FileName : string.Empty;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to download file from server folder
        /// </summary>
        /// <param name="expectedLifeUC">ExpectedLifeUC control object</param>
        public void DownloadFile(ExpectedLifeUC expectedLifeUC)
        {
            try
            {
                using (WebClient o_WebClient = new WebClient())
                {
                    HttpResponse o_HttpResponse = HttpContext.Current.Response;
                    o_HttpResponse.Clear();
                    o_HttpResponse.ClearContent();
                    o_HttpResponse.ClearHeaders();
                    o_HttpResponse.Buffer = true;
                    expectedLifeUC.Response.AddHeader("Content-Disposition", "attachment;filename=" + expectedLifeUC.hdnVPSELFileName.Value);
                    o_HttpResponse.BinaryWrite(o_WebClient.DownloadData(expectedLifeUC.hdnVPSESFileServerPath.Value.Replace("~", "\\")));
                    // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.Flush();
                    // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.Response.SuppressContent = true;
                    // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void gvVPSCurrEstDtOfListing_RowDataBound(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.DataRow:
                        e.Row.Cells[0].HorizontalAlign = e.Row.Cells[1].HorizontalAlign = e.Row.Cells[2].HorizontalAlign = e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                            e.Row.Cells[0].Text = Convert.ToDateTime(e.Row.Cells[0].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[3].Text) && !e.Row.Cells[3].Text.Equals("&nbsp;"))
                            e.Row.Cells[3].Text = Convert.ToDateTime(e.Row.Cells[3].Text).ToString("dd/MMM/yyyy");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to clear the file content
        /// </summary>
        /// <param name="asyncFileUpload">Ajax AsyncFileUpload control object</param>
        public void ClearFileContent(AjaxControlToolkit.AsyncFileUpload asyncFileUpload)
        {
            try
            {
                asyncFileUpload.ClearAllFilesFromPersistedStore();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        ///  This method is used to check changes in Parameter.
        /// </summary>
        /// <param name="expectedLifeUC"></param>
        public void ParamChange(ExpectedLifeUC expectedLifeUC)
        {
            CommonModel.IsParamChange("UPDATE", userSessionInfo);
        }

        #endregion
        
        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ExpectedLifeUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}