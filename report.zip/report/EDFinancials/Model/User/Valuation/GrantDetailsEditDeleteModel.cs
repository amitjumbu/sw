﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using System;
using System.Data;
using System.Web;
using System.Linq;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class GrantDetailsEditDeleteModel : BaseModel, IDisposable
    {
        #region Default Constructor
        /// <summary>
        ///  Default constructor
        /// </summary>
        public GrantDetailsEditDeleteModel()
        {
            if (ac_GrantDetails == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_GrantDetails);
                ac_GrantDetails = (CommonModel.AC_GrantDetails)HttpContext.Current.Session[CommonConstantModel.s_AC_GrantDetails];
            }
        }
        #endregion

        #region Edit Functionality
        /// <summary>
        /// This Method is used to Perform Edit Functionality On Grant Details
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="s_AGRMID">s_AGRMID</param>
        /// <param name="s_SessionGrantID">s_SessionGrantID</param>
        /// <param name="hdnAction">hdnAction</param>
        internal void ShowEditSection(GrantDetails grantDetails, string s_AGRMID, string s_SessionGrantID, string hdnAction)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    string s_GrantID = hdnAction.Equals("U") ? s_AGRMID : s_SessionGrantID;
                    string s_SelectedGrant = string.Empty;

                    if (grantDetailsModel.ac_GrantDetails.dt_GetGrantDetails != null && grantDetailsModel.ac_GrantDetails.dt_GetGrantDetails.Rows.Count > 0)
                    {
                        grantDetailsModel.ac_GrantDetails.s_GrantID = s_GrantID;

                        s_SelectedGrant = !string.IsNullOrEmpty(s_AGRMID) ? Convert.ToString(grantDetailsModel.ac_GrantDetails.dt_GetGrantDetails.Select("AGRMID = '" + s_AGRMID + "'")[0]["Grant Registration ID"]) : s_GrantID;

                        using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                        {
                            valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                            valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                            valuationProperties.Grant_ID = s_SelectedGrant;
                            valuationProperties.GET_DATA_TYPE = "VESTWISE";

                            valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                            DataTable dt_GetGrantDetails = valuationCRUDProperties.ds_Result.Tables[0];

                            grantDetails.txtAddGrantGrantID.Enabled = false;
                            grantDetails.ddlAddGrantSchemeName.Enabled = false;
                            grantDetails.ddlAddGrantSchemeName.SelectedItem.Text = dt_GetGrantDetails.Rows[0]["Scheme Title"].ToString();
                            grantDetails.txtAddGrantGrantID.Text = dt_GetGrantDetails.Rows[0]["Grant Registration ID"].ToString();
                            grantDetails.txtAddGrantGrantDate.Text = dt_GetGrantDetails.Rows[0]["Grant Date"].ToString();
                            grantDetails.txtAddGrantExercisePrice.Text = dt_GetGrantDetails.Rows[0]["Exercise Price"].ToString();

                            grantDetails.ddlAddGrantCurrency.SelectedItem.Text = dt_GetGrantDetails.Rows[0]["Currency"].ToString();
                            grantDetails.txtAddGrantPricingFormula.Text = dt_GetGrantDetails.Rows[0]["Pricing Formula"].ToString();
                            grantDetails.txtAddGrantNumberOfVest.Text = dt_GetGrantDetails.Rows[0]["Number of Vests"].ToString();

                            string[] s_VestingFrequency = dt_GetGrantDetails.Rows[0]["Vesting Frequency Value"].ToString().Split('.');
                            grantDetails.txtAddGrantVestingFrequency.Text = s_VestingFrequency[0];
                            grantDetails.rdbtnVestingFreqYearly.SelectedIndex = dt_GetGrantDetails.Rows[0]["Vesting Frequency"].ToString().Equals("Quarterly") ? 1 : dt_GetGrantDetails.Rows[0]["Vesting Frequency"].ToString().Equals("Monthly") ? 2 : dt_GetGrantDetails.Rows[0]["Vesting Frequency"].ToString().Equals("Days") ? 3 : 0;
                            grantDetails.chkFirstVestAftrOneYr.Checked = dt_GetGrantDetails.Rows[0]["Vesting After 1 Year"].ToString().Equals("Yes") ? true : false;
                            grantDetails.ddlAddGrantVestingParams.SelectedIndex = dt_GetGrantDetails.Rows[0]["Vesting Type"].ToString().Equals("Time Based") ? 0 : dt_GetGrantDetails.Rows[0]["Vesting Type"].ToString().Equals("Performance Based") ? 1 : 2;

                            if (grantDetails.ddlAddGrantVestingParams.SelectedIndex.Equals(1))
                                grantDetails.trMrktLnk.Style.Add("display", "normal");
                            else
                                grantDetails.trMrktLnk.Style.Add("display", "none");

                            grantDetails.rdbtnMrktLnk.Checked = dt_GetGrantDetails.Rows[0]["Is Market Linked"].ToString().Equals("Yes") ? true : false;
                            grantDetails.rdbtnNonMrktLnk.Checked = grantDetails.rdbtnMrktLnk.Checked ? false : true;
                            grantDetails.chkAddGrantExPrcLnkMultDates.Checked = dt_GetGrantDetails.Rows[0]["Multiple Exercise Period"].ToString().Equals("True") ? true : false;

                            if (grantDetails.chkAddGrantExPrcLnkMultDates.Checked)
                            {
                                grantDetails.divVestExercisePopulateOne.Style.Add("display", "none");
                                grantDetails.trdivVestExercisePopulateFirst.Style.Add("display", "normal");
                                grantDetails.trExPrcLnkMultDatesFirst.Style.Add("display", "normal");
                                string[] s_ExercisePeriod = dt_GetGrantDetails.Rows[0]["Multiple Exercise Period Value"].ToString().Split('.');
                                grantDetails.txtAddGrantExPrcFirst.Text = s_ExercisePeriod[0];
                                grantDetails.txtAddGrantExPrcSecond.Text = string.Empty;
                                grantDetails.rdbtnExPrcLnkMultDatesYearsOne.SelectedIndex = dt_GetGrantDetails.Rows[0]["Multiple Exsercise Period Freq"].ToString() == "M" ? 1 : dt_GetGrantDetails.Rows[0][19].ToString() == "D" ? 2 : 0;
                                grantDetails.rdbtnExPrcLnkMultDatesGDOne.SelectedIndex = dt_GetGrantDetails.Rows[0]["Exsercise Period Freq. From"].ToString() == "V" ? 1 : dt_GetGrantDetails.Rows[0][19].ToString() == "L" ? 2 : 0;
                                grantDetails.rdbtnExPrcLnkMultDatesEarlier.SelectedIndex = dt_GetGrantDetails.Rows[0]["WhichEverIs"].ToString().Equals("E") ? 0 : 1;
                            }
                            else
                            {
                                grantDetails.divVestExercisePopulateOne.Style.Add("display", "normal");
                                grantDetails.trdivVestExercisePopulateFirst.Style.Add("display", "normal");
                                string[] s_ExercisePeriod = dt_GetGrantDetails.Rows[0]["Exercise Period"].ToString().Split('.');
                                grantDetails.txtAddGrantExercisePeriod.Text = s_ExercisePeriod[0];
                                grantDetails.txtAddGrantExPrcFirst.Text = string.Empty;
                                grantDetails.txtAddGrantExPrcSecond.Text = string.Empty;
                                grantDetails.rdbtnExerPeriodYears.SelectedIndex = dt_GetGrantDetails.Rows[0]["Exercise Period Freq"].ToString() == "M" ? 1 : dt_GetGrantDetails.Rows[0][19].ToString() == "D" ? 2 : 0;
                                grantDetails.rdbtnExerPeriodFromDOG.SelectedIndex = dt_GetGrantDetails.Rows[0]["Exercise Period From"].ToString() == "V" ? 1 : dt_GetGrantDetails.Rows[0][19].ToString() == "L" ? 2 : 0;
                                grantDetails.trExPrcLnkMultDatesFirst.Style.Add("display", "none");
                            }

                            grantDetails.rdbtnCashSettled.Checked = dt_GetGrantDetails.Rows[0]["Settlement Of Options"].ToString() == "C" ? true : false;
                            grantDetails.rdbtnEquitySettled.Checked = grantDetails.rdbtnCashSettled.Checked ? false : true; ;
                            grantDetails.txtAddGrantRatioOpt.Text = dt_GetGrantDetails.Rows[0]["Ratio Options"].ToString();
                            grantDetails.txtAddGrantRatioShares.Text = dt_GetGrantDetails.Rows[0]["Ratio Share"].ToString();
                            grantDetails.chkAddGrantTrstRouteYes.Checked = dt_GetGrantDetails.Rows[0]["Trust Route"].ToString() == "1" ? true : false;
                            grantDetails.chkAddGrantTrstRouteNo.Checked = grantDetails.chkAddGrantTrstRouteYes.Checked ? false : true;
                            grantDetails.rdbtnUpdateParams.SelectedIndex = dt_GetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].ToString() == "P" ? 1 : dt_GetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].ToString() == "F" ? 2 : 0;
                            grantDetails.rdbtnUpdateParams.SelectedValue = dt_GetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].ToString().Trim().Equals("P") ? "P" : dt_GetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].ToString().Trim().Equals("F") ? "F" : "N";

                            PopulateVestGridOnEdit(grantDetails, s_AGRMID, dt_GetGrantDetails);

                            if (dt_GetGrantDetails.Rows[0]["Document Name"].ToString() != "")
                            {
                                var docUploaded = dt_GetGrantDetails.AsEnumerable().Select(s => new { id = s.Field<string>("Document Name") }).Distinct().ToList();

                                if (ac_GrantDetails.dt_FileUploads == null)
                                    ac_GrantDetails.dt_FileUploads = new DataTable();

                                if (ac_GrantDetails.dt_FileUploads.Columns.Count == 0)
                                {
                                    ac_GrantDetails.dt_FileUploads.Columns.Add("GrantID", typeof(string));
                                    ac_GrantDetails.dt_FileUploads.Columns.Add("FileName", typeof(string));
                                    ac_GrantDetails.dt_FileUploads.Columns.Add("Remark", typeof(string));
                                }

                                if (ac_GrantDetails.dt_gvFileUploads == null)
                                    ac_GrantDetails.dt_gvFileUploads = new DataTable();

                                if (ac_GrantDetails.dt_gvFileUploads.Columns.Count == 0)
                                {
                                    ac_GrantDetails.dt_gvFileUploads.Columns.Add("Document Uploaded", typeof(string));
                                }


                                for (int i = 0; i < docUploaded.Count(); i++)
                                {
                                    ac_GrantDetails.dt_FileUploads.Rows.Add(grantDetails.txtAddGrantGrantID.Text, docUploaded[i].id.ToString(), "");
                                    ac_GrantDetails.dt_gvFileUploads.Rows.Add(docUploaded[i].id.ToString());
                                }

                                grantDetails.gvFileUpload.DataSource = ac_GrantDetails.dt_gvFileUploads;
                                grantDetails.gvFileUpload.DataBind();

                                grantDetails.trgvFileUpload.Style.Add("display", "normal");
                            }
                            else
                            {
                                grantDetails.trgvFileUpload.Style.Add("display", "none");
                            }

                            BindUpdateParamsGridOnEdit(grantDetails, s_GrantID, s_AGRMID);

                            grantDetails.trUpdateParamsOrFair.Style.Add("display", "normal");

                            if (grantDetails.rdbtnUpdateParams.SelectedIndex == 0)
                                grantDetails.gvUpdateFairParams.Visible = false;

                            grantDetails.btnAddGrantAddMoreGrants.Visible = false;
                            grantDetails.trSaveContinue.Style.Add("display", "normal");
                            grantDetails.btnAddGrantSaveContinue.Visible = true;
                            grantDetails.divValidateMsg.Style.Add("display", "none");
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Bind Update Parameter Grid on Edit ImageButton Click
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="s_GrantID">Grant ID</param>
        /// <param name="s_AGRMID">s_AGRMID</param>
        public void BindUpdateParamsGridOnEdit(GrantDetails grantDetails, string s_GrantID, string s_AGRMID)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    int n_Temp_NoVest = 1;
                    using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                    {
                        valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                        valuationProperties.Grant_ID = grantDetails.txtAddGrantGrantID.Text;
                        valuationProperties.GET_DATA_TYPE = "VESTWISE";

                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        valuationCRUDProperties.ds_Result.Tables[0].TableName = "dt_VestWiseDetails";

                        DataTable dt_tempGetGrantDetails;

                        if (!string.IsNullOrEmpty(s_AGRMID))
                        {
                            dt_tempGetGrantDetails = valuationCRUDProperties.ds_Result.Tables[0].AsEnumerable().Where(r => r.Field<int>("AGRMID") == Convert.ToInt32(s_AGRMID)).CopyToDataTable();
                        }
                        else
                        {
                            dt_tempGetGrantDetails = valuationCRUDProperties.ds_Result.Tables[0].AsEnumerable().Where(r => r.Field<string>("Grant Registration ID") == s_GrantID).CopyToDataTable();
                        }

                        DataTable dt_ValParams = new DataTable();
                        DataTable dt_tempUpdateGenParams = new DataTable();
                        dt_ValParams.Columns.Add("Valuation Parameters", typeof(string));
                        dt_ValParams.Rows.Add("Market price for fair value");
                        dt_ValParams.Rows.Add("Market price for intrinsic value");
                        dt_ValParams.Rows.Add("Expected life (years)");
                        dt_ValParams.Rows.Add("Dividend Yield");

                        if (dt_tempGetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].Equals("P"))
                        {
                            dt_ValParams.Rows.Add("Dividend Yield-Dividend");
                            dt_ValParams.Rows.Add("Dividend Yield-Market Price");
                        }

                        dt_ValParams.Rows.Add("Volatility");
                        dt_ValParams.Rows.Add("Risk Free Interest Rate");

                        if (dt_tempGetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].Equals("F"))
                        {
                            dt_ValParams.Rows.Add("Fair Value");
                            dt_ValParams.Rows.Add("Intrinsic Value");
                        }

                        dt_tempUpdateGenParams.Columns.Add("Valuation Parameters", typeof(string));

                        while (n_Temp_NoVest <= Convert.ToInt32(dt_tempGetGrantDetails.Rows[0]["Number of Vests"].ToString()))
                        {
                            dt_tempUpdateGenParams.Columns.Add("Vest Date " + n_Temp_NoVest, typeof(string));
                            dt_tempUpdateGenParams.AcceptChanges();
                            n_Temp_NoVest++;
                        }
                        dt_ValParams.Merge(dt_tempUpdateGenParams);

                        using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                        {
                            for (int i = 0; i < dt_ValParams.Rows.Count; i++)
                            {
                                for (int j = 0; j < Convert.ToInt32(dt_tempGetGrantDetails.Rows[0]["Number of Vests"].ToString()); j++)
                                {
                                    switch (i)
                                    {
                                        case 0:
                                            dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_MKT_FV"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["Market Price Per Vest"].ToString() : string.Empty;

                                            if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                            {
                                                dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                            }

                                            break;

                                        case 1:
                                            dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_MKT_IV"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["Market Price IV"].ToString() : string.Empty;

                                            if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                            {
                                                dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 3")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                            }

                                            break;
                                        case 2:

                                            dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_EXL"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["Expected Life Per Vest"].ToString() : string.Empty;

                                            if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                            {
                                                dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 5")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 5")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 5")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                            }

                                            break;

                                        case 3:
                                            dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_DIVD"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["Dividend Per Vest"].ToString() : string.Empty;

                                            if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                            {
                                                dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                            }

                                            break;

                                        case 4:

                                            if (dt_tempGetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].Equals("P"))
                                            {
                                                dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_DIVD_MP_DIVD"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["Dividend For Divedend"].ToString() : string.Empty;

                                                if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                                {
                                                    dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                }
                                            }

                                            else if (dt_tempGetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].Equals("F"))
                                            {
                                                dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_VOL"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["Volatility Per Vest"].ToString() : string.Empty;

                                                if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                                {
                                                    dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                }
                                            }

                                            break;

                                        case 5:

                                            if (dt_tempGetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].Equals("P"))
                                            {
                                                dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_DIVD_MP_DIVD"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["Dividend For Market Price"].ToString() : string.Empty;

                                                if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                                {
                                                    dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 8")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                }
                                            }

                                            else if (dt_tempGetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].Equals("F"))
                                            {
                                                dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_RFIR"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["RFIR Per Vest"].ToString() : string.Empty;

                                                if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                                {
                                                    dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                }
                                            }

                                            break;

                                        case 6:

                                            if (dt_tempGetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].Equals("P"))
                                            {
                                                dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_VOL"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["Volatility Per Vest"].ToString() : string.Empty;

                                                if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                                {
                                                    dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 6")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                }
                                            }

                                            else if (dt_tempGetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].Equals("F"))
                                            {
                                                dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_FV"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["FAIR_VALUE_PER_VEST"].ToString() : string.Empty;

                                                if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                                {
                                                    dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 2")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                }
                                            }

                                            break;

                                        case 7:

                                            if (dt_tempGetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].Equals("P"))
                                            {
                                                dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_RFIR"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["RFIR Per Vest"].ToString() : string.Empty;

                                                if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                                {
                                                    dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 7")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                }
                                            }

                                            else if (dt_tempGetGrantDetails.Rows[0]["UPDATE_VAL_PARAMS"].Equals("F"))
                                            {
                                                dt_ValParams.Rows[i][j + 1] = dt_tempGetGrantDetails.Rows[j]["IS_MU_IV"].ToString().Equals("True") ? dt_tempGetGrantDetails.Rows[j]["INTRINSIC_VALUE_PER_VEST"].ToString() : string.Empty;

                                                if (dt_ValParams.Rows[i][j + 1].ToString() != "&nbsp;" && dt_ValParams.Rows[i][j + 1].ToString() != "")
                                                {
                                                    dt_ValParams.Rows[i][j + 1] = Convert.ToDouble(dt_ValParams.Rows[i][j + 1]) > 999 ? CommonModel.ThousandFormating(CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString()) : CommonModel.GetRoundedValue(dt_ValParams.Rows[i][j + 1].ToString(), DecimalLimitTable.Select("ADVSID = 1")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                }
                                            }

                                            break;
                                    }
                                    dt_ValParams.AcceptChanges();
                                }
                            }
                        }

                        grantDetailsModel.ac_GrantDetails.n_NoOfColumns = Convert.ToInt32(dt_tempGetGrantDetails.Rows[0]["Number of Vests"].ToString()) + 1;
                        grantDetails.gvUpdateFairParams.Visible = true;
                        grantDetails.gvUpdateFairParams.DataSource = dt_ValParams;
                        grantDetails.gvUpdateFairParams.DataBind();
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to Display Vesting Schedule Grid On Edit Click of Grant
        /// </summary>
        /// <param name="grantDetails">grantDetails</param>
        /// <param name="s_AGRMID">s_AGRMID</param>
        /// <param name="dt_GetGrantDetails">dt_GetGrantDetails</param>
        private void PopulateVestGridOnEdit(GrantDetails grantDetails, string s_AGRMID, DataTable dt_GetGrantDetails)
        {
            try
            {
                using (GrantDetailsModel grantDetailsModel = new GrantDetailsModel())
                {
                    using (DataTable dt_VestGrid = dt_GetGrantDetails.DefaultView.ToTable(true, "Vesting Period ID", "Vesting Date", "Vest Percent", "Expiry Date", "Time Based Vest Percent", "Performance Based Vest Percent"))
                    {
                        grantDetails.trgvVestExercisePopulate.Style.Add("display", "normal");
                        grantDetails.divVestExercisePopulate.Visible = true;
                        grantDetails.gvVestExercisePopulate.Visible = true;
                        grantDetails.gvVestExercisePopulate.DataSource = dt_VestGrid;
                        grantDetails.gvVestExercisePopulate.DataBind();
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~GrantDetailsEditDeleteModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}