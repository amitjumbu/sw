﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using System;
using System.Data;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class MarketPriceSetupModel : BaseModel, IDisposable
    {
        #region BindUI
        /// <summary>
        /// This Method is used to bind all labels to Page UI controls
        /// </summary>
        /// <param name="marketPriceSetup">marketPriceSetup</param>
        internal void BindUI(MarketPriceSetup marketPriceSetup)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (DataTable dt_MrktPrcUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_MarketPriceSetup, CommonConstantModel.s_ValuationL10_UI))
                    {
                        if ((dt_MrktPrcUI != null) && (dt_MrktPrcUI.Rows.Count > 0))
                        {
                            marketPriceSetup.lblTopHeader.Text = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'lblTopHeader'")[0]["LabelName"]);
                            marketPriceSetup.lblSearchAccordianPanel.Text = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'lblSearchAccordianPanel'")[0]["LabelName"]);
                            marketPriceSetup.btnMPCorpActionReport.Text = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'btnMPCorpActionChkBox'")[0]["LabelName"]);
                            marketPriceSetup.btnMPCorpActionReport.ToolTip = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'btnMPCorpActionChkBox'")[0]["LabelToolTip"]);
                            marketPriceSetup.lblMPViewNote.Text = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'lblMPViewNote'")[0]["LabelName"]);
                            marketPriceSetup.btnBackToGD.Text = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'btnBackToGD'")[0]["LabelName"]);
                            marketPriceSetup.btnBackToGD.ToolTip = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'btnBackToGD'")[0]["LabelToolTip"]);
                            marketPriceSetup.lblMPViewNote.Text = marketPriceSetup.lblMPViewNote.Text.Replace("~", "<br/><br/>");
                            marketPriceSetup.btnViewMPForUnlisted.Text = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'btnViewMPForUnlisted'")[0]["LabelName"]);
                            marketPriceSetup.btnViewMPForUnlisted.ToolTip = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'btnViewMPForUnlisted'")[0]["LabelToolTip"]);
                            marketPriceSetup.btnBackToPeer.Text = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'btnBackToPeer'")[0]["LabelName"]);
                            marketPriceSetup.btnBackToPeer.ToolTip = Convert.ToString(dt_MrktPrcUI.Select("LabelID = 'btnBackToPeer'")[0]["LabelToolTip"]);
                          
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Encrypt 
        /// </summary>
        /// <param name="marketPriceSetup"></param>
        internal void EncryptData(MarketPriceSetup marketPriceSetup)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                marketPriceSetup.hdnQueryStringParams.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=2").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                marketPriceSetup.hdnQueryStringParams.Dispose();
            }
        }

        /// <summary>
        /// This method is used to Encrypt 
        /// </summary>
        /// <param name="marketPriceSetup">MarketPriceSetup page object</param>
        internal void EncryptData_Unlisted(MarketPriceSetup marketPriceSetup)
        {
            using (GenericServiceClient genericServiceClient = new GenericServiceClient())
            {
                marketPriceSetup.hdnQueryStringParams_Unlisted.Value = Convert.ToString(genericServiceClient.EncryptString("RptID=3").Replace("+", "%2B") + "&" + genericServiceClient.EncryptString("GrpNo=0").Replace("+", "%2B"));
                marketPriceSetup.hdnQueryStringParams_Unlisted.Dispose();
            }
        }

 		/// <summary>
        /// This method is used to set visibility of button 'Back To Grant Details'
        /// </summary>
        /// <param name="marketPriceSetup">MarketPriceSetup page object</param>
        /// <param name="b_IsVisible">input boolean variable to set control visibility</param>
        public void ShowHideBacktoGDBtn(MarketPriceSetup marketPriceSetup, bool b_IsVisible)
        {
            marketPriceSetup.btnBackToGD.Visible = b_IsVisible;
        }

        /// <summary>
        /// This method is used to set visibility of button 'Back To PeerCpmpanySetup page'
        /// </summary>
        /// <param name="marketPriceSetup">MarketPriceSetup page object</param>
        /// <param name="b_IsVisible">input boolean variable to set control visibility</param>
        public void ShowHideBacktoPeerBtn(MarketPriceSetup marketPriceSetup, bool b_IsVisible)
        {
            marketPriceSetup.btnBackToPeer.Visible = b_IsVisible;
        }

        /// <summary>
        /// This method is used to set visibility of button 'View Market Price'
        /// </summary>
        /// <param name="marketPriceSetup">MarketPriceSetup page object</param>
        public void ShowHideBtnViewMPForUnlisted(MarketPriceSetup marketPriceSetup)
        {
            marketPriceSetup.btnViewMPForUnlisted.Visible = userSessionInfo.ACC_IsListed.Equals(0);
            if (userSessionInfo.ACC_IsListed.Equals(0))
                EncryptData_Unlisted(marketPriceSetup);
        }

        #endregion


        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~MarketPriceSetupModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}