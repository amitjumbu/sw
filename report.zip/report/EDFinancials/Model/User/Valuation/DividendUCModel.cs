﻿using EDFinancials.Model.Generic;
using EDFinancials.UserControl.User.Valuation;
using EDFinancials.View.Valuation;
using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Dividend user control Model
    /// </summary>
    public class DividendUCModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public DividendUCModel()
        {
            if (ac_ValuationParameter == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationParameter);
                ac_ValuationParameter = (CommonModel.AC_ValuationParameter)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationParameter];
            }
        }

        #region Dividend

        /// <summary>
        /// This method is used to bind all the dropdowns
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        public void BindDropDowns(ValuationParameters valuationParametersSetup)
        {
            try
            {
                if (userSessionInfo.ACC_IsListed.Equals(1))
                {
                    if (ac_ValuationParameter.ds_ValuationParameters.Tables[14].Rows.Count > 0)
                    {
                        using (DataTable dt_SEDetails = ac_ValuationParameter.ds_ValuationParameters.Tables[14])
                        {
                            valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.DataSource = dt_SEDetails;
                            valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.DataTextField = "Short Name";
                            valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.DataValueField = "SEID";
                            valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.DataBind();
                            using (VPSCommonModel vPSCommonModel = new VPSCommonModel())
                            {
                                vPSCommonModel.BindToolTip(valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC);
                            }
                            if (Convert.ToInt32(valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.SelectedItem.Value) > 0)
                                valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Items.FindByValue(valuationParametersSetup.ctrVolatility.ddlVPSStockExchge_VC.SelectedItem.Value).Selected = true;
                            else if (valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Items.FindByText("NSE") != null)
                                valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Items.FindByText("NSE").Selected = true;
                        }
                    }
                }
                else valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Visible = false;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind Dividend tab controls
        /// </summary>
        /// <param name="ds_ValuationParameters">dataset object</param>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        /// <param name="s_GrantDate">GrantDate</param>
        /// <param name="s_Event">Event</param>
        /// <param name="s_GrantID">s_GrantID</param>
        public void BindDividendControls(DataSet ds_ValuationParameters, ValuationParameters valuationParametersSetup, string s_GrantDate, string s_Event, string s_GrantID)
        {
            try
            {
                ac_ValuationParameter.dt_Dividend = ac_ValuationParameter.ds_ValuationParameters.Tables[9];
                if (string.IsNullOrEmpty(s_Event))
                {
                    ac_ValuationParameter.dt_IncorpDividendDetails = ac_ValuationParameter.ds_ValuationParameters.Tables[12];
                    if (!string.IsNullOrEmpty(Convert.ToString(ac_ValuationParameter.dt_Dividend.Rows[0]["ADCAID"]).Trim()))
                    {
                        StringBuilder s_IncorporateDetails = new StringBuilder();
                        if (ac_ValuationParameter.dt_IncorpDividendDetails.Select("ADCID = '" + ac_ValuationParameter.dt_Dividend.Rows[0]["ADCAID"] + "'").Count() > 0)
                            ac_ValuationParameter.dt_IncorpDividendToSave = ac_ValuationParameter.dt_IncorpDividendDetails.Select("ADCID = '" + ac_ValuationParameter.dt_Dividend.Rows[0]["ADCAID"] + "'").CopyToDataTable();
                    }
                    valuationParametersSetup.ctrDividend.gvVPSIncorpDividend.DataSource = ac_ValuationParameter.dt_IncorpDividendToSave;
                    valuationParametersSetup.ctrDividend.gvVPSIncorpDividend.DataBind();
                    if (!s_Event.Equals("ReBind"))
                        BindControls(valuationParametersSetup, s_GrantDate, s_GrantID);
                }
                valuationParametersSetup.ctrDividend.gvDividend.DataSource = ac_ValuationParameter.dt_Dividend;
                valuationParametersSetup.ctrDividend.gvDividend.DataBind();
                SetApprovalHiddenField(valuationParametersSetup);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to set hidden field to check approval status
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        public void SetApprovalHiddenField(ValuationParameters valuationParametersSetup)
        {
            try
            {
                bool s_IsApproved = (from query in ac_ValuationParameter.dt_Dividend.AsEnumerable()
                                     where query.Field<string>("Approval Status") == "Pending"
                                     select query.Field<string>("Approval Status")).Distinct().Count() > 0 ? false : true;
                valuationParametersSetup.ctrDividend.hdnVPS_IsApproved_DC.Value = s_IsApproved ? "1" : "0";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind Incorporate Dividend data to grid
        /// </summary>
        /// <param name="dividendUC">DividendUC object</param>
        public int BindIncorpDivToGrid(DividendUC dividendUC)
        {
            try
            {
                int n_FromDateCount = 0, n_ToDateCount = 0;
                string s_FromDate = dividendUC.txtVPSDivFromDate.Text;
                string s_ToDate = dividendUC.txtVPSDivToDate.Text;

                if (ac_ValuationParameter.dt_IncorpDividendToSave.Columns.Count > 0)
                {
                    foreach (DataRow dr in ac_ValuationParameter.dt_IncorpDividendToSave.Rows)
                    {
                        if (Convert.ToDateTime(dr[1]) <= Convert.ToDateTime(dividendUC.txtVPSDivFromDate.Text) && Convert.ToDateTime(dr[2]) >= Convert.ToDateTime(dividendUC.txtVPSDivFromDate.Text))
                            n_FromDateCount = 1;
                        if (Convert.ToDateTime(dr[1]) <= Convert.ToDateTime(dividendUC.txtVPSDivToDate.Text) && Convert.ToDateTime(dr[2]) >= Convert.ToDateTime(dividendUC.txtVPSDivToDate.Text))
                            n_ToDateCount = 1;
                        if (Convert.ToDateTime(dr[1]) >= Convert.ToDateTime(dividendUC.txtVPSDivFromDate.Text) && Convert.ToDateTime(dr[2]) >= Convert.ToDateTime(dividendUC.txtVPSDivFromDate.Text) && Convert.ToDateTime(dr[1]) <= Convert.ToDateTime(dividendUC.txtVPSDivToDate.Text) && Convert.ToDateTime(dr[2]) <= Convert.ToDateTime(dividendUC.txtVPSDivToDate.Text))
                            return 5;
                    }
                }
                else
                {
                    ac_ValuationParameter.dt_IncorpDividendToSave.Columns.Add("ADCID", typeof(int));
                    ac_ValuationParameter.dt_IncorpDividendToSave.Columns.Add("From Date", typeof(string));
                    ac_ValuationParameter.dt_IncorpDividendToSave.Columns.Add("To Date", typeof(string));
                    ac_ValuationParameter.dt_IncorpDividendToSave.Columns.Add("Dividend", typeof(string));
                }

                if (n_FromDateCount > 0 && n_ToDateCount > 0)
                    return 2;
                else if (n_FromDateCount > 0 && n_ToDateCount <= 0)
                    return 3;
                else if (n_ToDateCount > 0 && n_FromDateCount <= 0)
                    return 4;

                DataRow dr1 = ac_ValuationParameter.dt_IncorpDividendToSave.NewRow();
                dr1[0] = 0;
                dr1[1] = s_FromDate;
                dr1[2] = s_ToDate;
                dr1[3] = dividendUC.txtVPSDivDividend.Text;

                ac_ValuationParameter.dt_IncorpDividendToSave.Rows.Add(dr1);
                dividendUC.gvVPSIncorpDividend.DataSource = ac_ValuationParameter.dt_IncorpDividendToSave;
                dividendUC.gvVPSIncorpDividend.DataBind();

                dividendUC.txtVPSDivFromDate.Text = dividendUC.txtVPSDivToDate.Text = dividendUC.txtVPSDivDividend.Text = string.Empty;
                return 0;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind Dividend tab controls
        /// </summary>
        /// <param name="valuationParametersSetup">ValuationParametersSetup page object</param>
        /// <param name="s_GrantDate"></param>
        /// <param name="s_GrantID"></param>
        private void BindControls(ValuationParameters valuationParametersSetup, string s_GrantDate, string s_GrantID)
        {
            try
            {
                #region This is used to bind controls at time of redirect from Valuation Report page
                if (!string.IsNullOrEmpty(s_GrantDate))
                {
                    foreach (DataRow perRow in ac_ValuationParameter.ds_ValuationParameters.Tables[9].Select("[To Date] IS NULL"))
                    {
                        perRow["To Date"] = DateTime.Now.Date;
                    }
                }
                #endregion

                DataRow[] dr_GrantLevelSettings = null;
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    if (!string.IsNullOrEmpty(s_GrantDate))
                    {
                        valuationProperties.PageName = CommonConstantModel.s_ValuationParameters;
                        valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        dr_GrantLevelSettings = valuationCRUDProperties.ds_Result.Tables[9].Select("GRANT_GRANT_REG_ID = '" + s_GrantID + "'");
                    }
                }

                using (DataTable dt_ValuationParameters = string.IsNullOrEmpty(s_GrantDate) ? ac_ValuationParameter.ds_ValuationParameters.Tables[8] : (dr_GrantLevelSettings != null && dr_GrantLevelSettings.Count() > 0) ? dr_GrantLevelSettings.CopyToDataTable() : ac_ValuationParameter.ds_ValuationParameters.Tables[9].Select("[Applicable From Date] <= #" + Convert.ToDateTime(s_GrantDate).Date + "# AND [To Date] >= #" + Convert.ToDateTime(s_GrantDate).Date + "#").CopyToDataTable())
                {
                    #region This is used to bind controls at time of redirect from Valuation Report page
                    if (!string.IsNullOrEmpty(s_GrantDate) && dr_GrantLevelSettings.Count().Equals(0))
                    {
                        dt_ValuationParameters.Columns["Dividend to be considered"].ColumnName = "DIVIDEND_LABEL_ID";
                        dt_ValuationParameters.Columns["Market Price to Calculate Dividend Yield"].ColumnName = "MP_TO_CAL_DIVIDEND_LABEL_ID";
                        dt_ValuationParameters.Columns["Special Dividend"].ColumnName = "SPECIAL_DIVIDEND";
                        dt_ValuationParameters.Columns["Remark"].ColumnName = "REMARK";
                        dt_ValuationParameters.Columns["Applicable From Date"].ColumnName = "APPLICABLE_FROM_DATE";
                    }
                    else if (dr_GrantLevelSettings != null && dr_GrantLevelSettings.Count() > 0)
                    {
                        dt_ValuationParameters.Columns["GRANT_DIVIDEND_LABEL_ID"].ColumnName = "DIVIDEND_LABEL_ID";
                        dt_ValuationParameters.Columns["GRANT_MP_TO_CAL_DIVIDEND"].ColumnName = "MP_TO_CAL_DIVIDEND_LABEL_ID";
                        dt_ValuationParameters.Columns["GRANT_SPECIAL_DIVIDEND"].ColumnName = "SPECIAL_DIVIDEND";
                        dt_ValuationParameters.Columns["GRANT_NO_OF_YEARS"].ColumnName = "NO_OF_YEARS";
                    }
                    #endregion

                    if (dt_ValuationParameters.Rows.Count > 0)
                    {
                        if (Convert.ToString(dt_ValuationParameters.Rows[0]["DIVIDEND_LABEL_ID"]).Trim().Equals("lblDIV01"))
                            valuationParametersSetup.ctrDividend.lblDIV01.Checked = true;
                        else if (Convert.ToString(dt_ValuationParameters.Rows[0]["DIVIDEND_LABEL_ID"]).Trim().Equals("lblDIV02"))
                            valuationParametersSetup.ctrDividend.lblDIV02.Checked = true;
                        else if (Convert.ToString(dt_ValuationParameters.Rows[0]["DIVIDEND_LABEL_ID"]).Trim().Equals("lblDIV03"))
                        {
                            valuationParametersSetup.ctrDividend.lblDIV03.Checked = true;
                            valuationParametersSetup.ctrDividend.ddlAvgDividend.Items.FindByValue(Convert.ToString(Convert.ToInt32(dt_ValuationParameters.Rows[0]["NO_OF_YEARS"])).Trim()).Selected = true;
                        }
                        else if (Convert.ToString(dt_ValuationParameters.Rows[0]["DIVIDEND_LABEL_ID"]).Trim().Equals("lblDIV04"))
                        {
                            valuationParametersSetup.ctrDividend.lblDIV04.Checked = true;
                        }
                        if (Convert.ToString(dt_ValuationParameters.Rows[0]["SPECIAL_DIVIDEND"]).Trim().Equals("1"))
                            valuationParametersSetup.ctrDividend.chkVPSSpecialDividend.Checked = true;
                        else valuationParametersSetup.ctrDividend.chkVPSSpecialDividend.Checked = false;

                        if (Convert.ToString(dt_ValuationParameters.Rows[0]["MP_TO_CAL_DIVIDEND_LABEL_ID"]).Trim().Equals("lblMPTCD01"))
                            valuationParametersSetup.ctrDividend.lblMPTCD01.Checked = true;
                        else if (Convert.ToString(dt_ValuationParameters.Rows[0]["MP_TO_CAL_DIVIDEND_LABEL_ID"]).Trim().Equals("lblMPTCD02"))
                        {
                            valuationParametersSetup.ctrDividend.lblMPTCD02.Checked = true;

                            if (string.IsNullOrEmpty(s_GrantDate))
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(dt_ValuationParameters.Rows[0]["SEID"]).Trim()))
                                {
                                    if (valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Items.FindByValue(Convert.ToString(dt_ValuationParameters.Rows[0]["SEID"]).Trim()) != null)
                                    {
                                        valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.ClearSelection();
                                        valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Items.FindByValue(Convert.ToString(dt_ValuationParameters.Rows[0]["SEID"]).Trim()).Selected = true;
                                    }
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(dt_ValuationParameters.Rows[0]["SHORT_NAME"]).Trim()))
                                {
                                    if (valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Items.FindByText(Convert.ToString(dt_ValuationParameters.Rows[0]["SHORT_NAME"]).Trim()) != null)
                                    {
                                        valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.ClearSelection();
                                        valuationParametersSetup.ctrDividend.ddlVPSStockExchge_DC.Items.FindByText(Convert.ToString(dt_ValuationParameters.Rows[0]["SHORT_NAME"]).Trim()).Selected = true;
                                    }
                                }
                            }
                        }

                        if (string.IsNullOrEmpty(s_GrantDate))
                        {
                            valuationParametersSetup.ctrDividend.txtDividendRemark.Text = Convert.ToString(dt_ValuationParameters.Rows[0]["REMARK"]).Trim();
                            valuationParametersSetup.ctrDividend.hdnVPSAppFromDate_DC.Value = valuationParametersSetup.ctrDividend.txtDividendApplFromDate.Text = !string.IsNullOrEmpty(Convert.ToString(dt_ValuationParameters.Rows[0]["APPLICABLE_FROM_DATE"])) ? Convert.ToDateTime(dt_ValuationParameters.Rows[0]["APPLICABLE_FROM_DATE"]).ToString("dd/MMM/yyyy") : string.Empty; 
                        }
                        using (ValuationModel valuationModel = new ValuationModel())
                        {
                            valuationModel.SetButtonText(valuationParametersSetup.ctrDividend.btnDividendSave);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to update Dividend config data
        /// </summary>
        /// <param name="dividendUC">DividendUC control object</param>
        /// <param name="s_Type">CUD operation type</param>
        /// <returns></returns>
        public int UpdateDividendConfigData(DividendUC dividendUC, string s_Type)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.PageName = CommonConstantModel.s_ValuationParameter;
                        valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                        valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        valuationProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                        if (userSessionInfo.ACC_UerTypeID.Equals(5))
                            valuationProperties.DC_IS_APPROVED = true;
                        else valuationProperties.DC_IS_APPROVED = false;

                        valuationProperties.PopulateControls = s_Type;

                        if (dividendUC.lblDIV01.Checked)
                            valuationProperties.DC_DIVIDEND_LABEL_ID = dividendUC.lblDIV01.ID;
                        else if (dividendUC.lblDIV02.Checked)
                            valuationProperties.DC_DIVIDEND_LABEL_ID = dividendUC.lblDIV02.ID;
                        else if (dividendUC.lblDIV03.Checked)
                        {
                            valuationProperties.DC_DIVIDEND_LABEL_ID = dividendUC.lblDIV03.ID;
                            valuationProperties.DC_NO_OF_YEARS = Math.Round(Convert.ToDecimal(dividendUC.ddlAvgDividend.SelectedItem.Text), 2);
                        }
                        else if (dividendUC.lblDIV04.Checked)
                        {
                            valuationProperties.DC_DIVIDEND_LABEL_ID = dividendUC.lblDIV04.ID;
                            ac_ValuationParameter.dt_IncorpDetails = ac_ValuationParameter.dt_IncorpDividendToSave;
                            if (ac_ValuationParameter.dt_IncorpDetails.Columns.Contains("ADCID"))
                                ac_ValuationParameter.dt_IncorpDetails.Columns.Remove("ADCID");
                            ac_ValuationParameter.dt_IncorpDetails.TableName = "DT";
                            valuationProperties.dt_IncorpDividendDetails = ac_ValuationParameter.dt_IncorpDetails;
                        }

                        if (dividendUC.chkVPSSpecialDividend.Checked)
                            valuationProperties.DC_SPECIAL_DIVIDEND = "1";
                        else
                            valuationProperties.DC_SPECIAL_DIVIDEND = "0";

                        if (dividendUC.lblMPTCD01.Checked)
                            valuationProperties.DC_MP_TO_CAL_DIVIDEND_LABEL_ID = dividendUC.lblMPTCD01.ID;
                        else if (dividendUC.lblMPTCD02.Checked)
                        {
                            valuationProperties.DC_MP_TO_CAL_DIVIDEND_LABEL_ID = dividendUC.lblMPTCD02.ID;
                            valuationProperties.DC_SEID = Convert.ToInt32(dividendUC.ddlVPSStockExchge_DC.SelectedItem.Value);
                        }

                        valuationProperties.DC_REMARK = dividendUC.txtDividendRemark.Text;
                        valuationProperties.DC_APPLICABLE_FROM_DATE = dividendUC.txtDividendApplFromDate.Text;
                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                        if (valuationCRUDProperties.a_result.Equals(1))
                        {
                            ParamChange(dividendUC);

                            using (ValuationModel valuationModel = new ValuationModel())
                            {
                                valuationModel.SetButtonText(dividendUC.btnDividendSave);
                            }
                            dividendUC.hdnVPSAppFromDate_DC.Value = dividendUC.txtDividendApplFromDate.Text;
                        }

                        return valuationCRUDProperties.a_result;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid-view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="n_Index">n_Index</param>
        /// <param name="n_DIVIDEND_LABEL_ID">n_DIVIDEND_LABEL_ID</param>
        /// <param name="n_NO_OF_YEARS">n_NO_OF_YEARS</param>
        /// <param name="n_MP_TO_CAL_DIVIDEND_LABEL_ID">n_MP_TO_CAL_DIVIDEND_LABEL_ID</param>
        /// <param name="n_SHORT_NAME">n_SHORT_NAME</param>
        /// <param name="n_SPECIAL_DIVIDEND">n_SPECIAL_DIVIDEND</param>
        /// <param name="n_REMARK">n_REMARK</param>
        /// <param name="n_APPLICABLE_FROM_DATE">n_APPLICABLE_FROM_DATE</param>
        /// <param name="n_TO_DATE">n_TO_DATE</param>
        /// <param name="n_ADCID">n_ADCID</param>
        /// <param name="n_ApprovalStatus">n_ApprovalStatus</param>
        /// <param name="n_ViewHistoryData">n_ViewHistoryData</param>
        /// <param name="n_SEID">n_SEID</param>
        /// <param name="n_ADCAID">n_ADCAID</param>
        public void RowDataBindForGVDividend(GridViewRowEventArgs e, ref int n_Index, ref int n_DIVIDEND_LABEL_ID, ref int n_NO_OF_YEARS, ref int n_MP_TO_CAL_DIVIDEND_LABEL_ID, ref int n_SHORT_NAME, ref int n_SPECIAL_DIVIDEND, ref int n_REMARK, ref int n_APPLICABLE_FROM_DATE, ref int n_TO_DATE, ref int n_ADCID, ref int n_ApprovalStatus, ref int n_ViewHistoryData, ref int n_SEID, ref int n_ADCAID)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "DIVIDEND TO BE CONSIDERED":
                                    n_DIVIDEND_LABEL_ID = n_Index;
                                    break;
                                case "NO_OF_YEARS":
                                    n_NO_OF_YEARS = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "MARKET PRICE TO CALCULATE DIVIDEND YIELD":
                                    n_MP_TO_CAL_DIVIDEND_LABEL_ID = n_Index;
                                    break;
                                case "SHORT_NAME":
                                    n_SHORT_NAME = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "SPECIAL DIVIDEND":
                                    n_SPECIAL_DIVIDEND = n_Index;
                                    break;
                                case "REMARK":
                                    n_REMARK = n_Index;
                                    break;
                                case "APPLICABLE FROM DATE":
                                    n_APPLICABLE_FROM_DATE = n_Index;
                                    break;
                                case "TO DATE":
                                    n_TO_DATE = n_Index;
                                    break;
                                case "ADCID":
                                    n_ADCID = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "APPROVAL STATUS":
                                    n_ApprovalStatus = n_Index;
                                    break;
                                case "VIEW HISTORY DATA":
                                    n_ViewHistoryData = n_Index;
                                    break;
                                case "SEID":
                                    n_SEID = n_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "ADCAID":
                                    n_ADCAID = n_Index;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_Index++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_NO_OF_YEARS].Visible = e.Row.Cells[n_ADCID].Visible = e.Row.Cells[n_SHORT_NAME].Visible = e.Row.Cells[n_ADCAID].Visible = e.Row.Cells[n_SEID].Visible = false;
                        e.Row.Cells[n_APPLICABLE_FROM_DATE].HorizontalAlign = e.Row.Cells[n_TO_DATE].HorizontalAlign = HorizontalAlign.Center;

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_APPLICABLE_FROM_DATE].Text) && !e.Row.Cells[n_APPLICABLE_FROM_DATE].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_APPLICABLE_FROM_DATE].Text = Convert.ToDateTime(e.Row.Cells[n_APPLICABLE_FROM_DATE].Text).ToString("dd/MMM/yyyy");
                        if (!string.IsNullOrEmpty(e.Row.Cells[n_TO_DATE].Text) && !e.Row.Cells[n_TO_DATE].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_TO_DATE].Text = Convert.ToDateTime(e.Row.Cells[n_TO_DATE].Text).ToString("dd/MMM/yyyy");
                        if (!string.IsNullOrEmpty(e.Row.Cells[n_SPECIAL_DIVIDEND].Text) && !e.Row.Cells[n_SPECIAL_DIVIDEND].Text.Equals("&nbsp;") && Convert.ToInt32(e.Row.Cells[n_SPECIAL_DIVIDEND].Text) > 0)
                            e.Row.Cells[n_SPECIAL_DIVIDEND].Text = "Yes";
                        else
                            e.Row.Cells[n_SPECIAL_DIVIDEND].Text = "No";

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_DIVIDEND_LABEL_ID].Text) && !e.Row.Cells[n_DIVIDEND_LABEL_ID].Text.Equals("&nbsp;"))
                        {
                            if (e.Row.Cells[n_DIVIDEND_LABEL_ID].Text.Trim().Equals("lblDIV03"))
                            {
                                e.Row.Cells[n_DIVIDEND_LABEL_ID].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_DIVIDEND_LABEL_ID].Text.Trim() + "'" + ""))[n_DIVIDEND_LABEL_ID]["LabelName"]) + " : Last " + Convert.ToDecimal(e.Row.Cells[n_NO_OF_YEARS].Text.Trim()).ToString("N0") + " Year(s)";
                            }
                            else if (e.Row.Cells[n_DIVIDEND_LABEL_ID].Text.Trim().Equals("lblDIV04"))
                            {
                                StringBuilder s_IncorporateDetails = new StringBuilder();
                                if (ac_ValuationParameter.dt_IncorpDividendDetails.Select("ADCID = '" + e.Row.Cells[n_ADCAID].Text.Trim() + "'").Count() > 0)
                                {
                                    ac_ValuationParameter.dt_IncorpDetails = ac_ValuationParameter.dt_IncorpDividendDetails.Select("ADCID = '" + e.Row.Cells[n_ADCAID].Text.Trim() + "'").CopyToDataTable();
                                    if (ac_ValuationParameter.dt_IncorpDetails.Rows.Count > 0)
                                    {
                                        foreach (DataRow dr_Row in ac_ValuationParameter.dt_IncorpDetails.Rows)
                                        {
                                            if (s_IncorporateDetails.Length.Equals(0))
                                                s_IncorporateDetails.Append("</br>" + Convert.ToString(dr_Row["Dividend"]) + " ( " + Convert.ToDateTime(dr_Row["From Date"]).ToString("dd/MMM/yyyy") + " - " + Convert.ToDateTime(dr_Row["To Date"]).ToString("dd/MMM/yyyy") + " )");
                                            else
                                                s_IncorporateDetails.Append("</br>" + Convert.ToString(dr_Row["Dividend"]) + " ( " + Convert.ToDateTime(dr_Row["From Date"]).ToString("dd/MMM/yyyy") + " - " + Convert.ToDateTime(dr_Row["To Date"]).ToString("dd/MMM/yyyy") + " )");
                                        }
                                    }
                                }
                                e.Row.Cells[n_DIVIDEND_LABEL_ID].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_DIVIDEND_LABEL_ID].Text.Trim() + "'" + ""))[n_DIVIDEND_LABEL_ID]["LabelName"]);
                                if (s_IncorporateDetails.Length > 0)
                                    e.Row.Cells[n_DIVIDEND_LABEL_ID].Text += " : " + s_IncorporateDetails;
                                s_IncorporateDetails.Clear();
                            }
                            else
                            {
                                e.Row.Cells[n_DIVIDEND_LABEL_ID].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_DIVIDEND_LABEL_ID].Text.Trim() + "'" + ""))[n_DIVIDEND_LABEL_ID]["LabelName"]);
                            }
                        }


                        if (!string.IsNullOrEmpty(e.Row.Cells[n_MP_TO_CAL_DIVIDEND_LABEL_ID].Text) && !e.Row.Cells[n_MP_TO_CAL_DIVIDEND_LABEL_ID].Text.Equals("&nbsp;"))
                        {
                            if (e.Row.Cells[n_MP_TO_CAL_DIVIDEND_LABEL_ID].Text.Trim().Equals("lblMPTCD02") && !string.IsNullOrEmpty(e.Row.Cells[n_SHORT_NAME].Text.Trim()) && !e.Row.Cells[n_SHORT_NAME].Text.Equals("&nbsp;"))
                                e.Row.Cells[n_MP_TO_CAL_DIVIDEND_LABEL_ID].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_MP_TO_CAL_DIVIDEND_LABEL_ID].Text.Trim() + "'" + ""))[n_DIVIDEND_LABEL_ID]["LabelName"]) + " : " + e.Row.Cells[n_SHORT_NAME].Text.Trim();
                            else
                                e.Row.Cells[n_MP_TO_CAL_DIVIDEND_LABEL_ID].Text = Convert.ToString((ac_ValuationParameter.dt_ValuParaSetupUI.Select("LabelID = " + "'" + e.Row.Cells[n_MP_TO_CAL_DIVIDEND_LABEL_ID].Text.Trim() + "'" + ""))[n_DIVIDEND_LABEL_ID]["LabelName"]);
                        }

                        e.Row.Cells[n_ViewHistoryData].Controls.Add((Control)new VPSCommonModel().AddHistoryHyperLink(e.Row.Cells[n_ADCID].Text, e.Row.Cells[n_APPLICABLE_FROM_DATE].Text, e.Row.Cells[n_TO_DATE].Text, "DC"));
                        e.Row.Cells[n_REMARK].Attributes.Add("style", "text-wrap:normal; word-break:break-all; word-wrap:break-word; max-width: 200px;");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to gridview
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="n_Inc_Index">n_Inc_Index</param>
        /// <param name="n_Inc_ADCID">n_Inc_ADCID</param>
        /// <param name="n_Inc_From_Date">n_Inc_From_Date</param>
        /// <param name="n_Inc_To_Date">n_Inc_To_Date</param>
        /// <param name="n_Inc_Dividend">n_Inc_Dividend</param>
        public void RowDataBindForGVIncorpDividend(GridViewRowEventArgs e, ref int n_Inc_Index, ref int n_Inc_ADCID, ref int n_Inc_From_Date, ref int n_Inc_To_Date, ref int n_Inc_Dividend)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ADCID":
                                    n_Inc_ADCID = n_Inc_Index;
                                    perColumn.Visible = false;
                                    break;
                                case "FROM DATE":
                                    n_Inc_From_Date = n_Inc_Index;
                                    break;
                                case "TO DATE":
                                    n_Inc_To_Date = n_Inc_Index;
                                    break;
                                case "DIVIDEND":
                                    n_Inc_Dividend = n_Inc_Index;
                                    break;
                            }
                            n_Inc_Index++;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_Inc_From_Date].HorizontalAlign = e.Row.Cells[n_Inc_To_Date].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Inc_Dividend].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_Inc_ADCID].Visible = false;
                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Inc_From_Date].Text) && !e.Row.Cells[n_Inc_From_Date].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_Inc_From_Date].Text = Convert.ToDateTime(e.Row.Cells[n_Inc_From_Date].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[n_Inc_To_Date].Text) && !e.Row.Cells[n_Inc_To_Date].Text.Equals("&nbsp;"))
                            e.Row.Cells[n_Inc_To_Date].Text = Convert.ToDateTime(e.Row.Cells[n_Inc_To_Date].Text).ToString("dd/MMM/yyyy");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="dividendUC">dividendUC page object</param>
        public void PageIndexChangingForGVDividend(int NewPageIndex, DividendUC dividendUC)
        {
            try
            {
                dividendUC.gvDividend.PageIndex = NewPageIndex;
                dividendUC.gvDividend.DataSource = ac_ValuationParameter.dt_Dividend;
                dividendUC.gvDividend.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// gridview page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="dividendUC">dividendUC page object</param>
        public void PageIndexChangingForGVEncorpDiv(int NewPageIndex, DividendUC dividendUC)
        {
            try
            {
                dividendUC.gvVPSIncorpDividend.PageIndex = NewPageIndex;
                dividendUC.gvVPSIncorpDividend.DataSource = ac_ValuationParameter.dt_IncorpDividendToSave;
                dividendUC.gvVPSIncorpDividend.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to check changes in Parameters.
        /// </summary>
        /// <param name="dividendUC"></param>
        public void ParamChange(DividendUC dividendUC)
        {
            CommonModel.IsParamChange("UPDATE", userSessionInfo);
        }

        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~DividendUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}