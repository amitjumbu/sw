﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation.UserControl_Model;
using EDFinancials.View.User.Valuation.UserControl;
using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class CompareGrantsUCModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public CompareGrantsUCModel()
        {
            if (ac_ValuationReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationReport);
                ac_ValuationReport = (CommonModel.AC_ValuationReport)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationReport];
            }
        }

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="ucCompareGrants">ucCompareGrants page object</param>
        internal void ReadL10N_UI(CompareGrantsUC ucCompareGrants)
        {
            try
            {
                ucCompareGrants.lblCompare.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblCompare'"))[0]["LabelName"]);
                ucCompareGrants.lblCompare.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblCompare'"))[0]["LabelToolTip"]);

                ucCompareGrants.lblSelectGrants.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblSelectGrants'"))[0]["LabelName"]);
                ucCompareGrants.lblSelectGrants.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblSelectGrants'"))[0]["LabelToolTip"]);

                ucCompareGrants.rdbFairValue.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'rdbFairValue'"))[0]["LabelName"]);
                ucCompareGrants.rdbFairValue.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'rdbFairValue'"))[0]["LabelToolTip"]);

                ucCompareGrants.rdbInrinsicValue.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'rdbInrinsicValue'"))[0]["LabelName"]);
                ucCompareGrants.rdbInrinsicValue.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'rdbInrinsicValue'"))[0]["LabelToolTip"]);

                ucCompareGrants.btnSaveContinue.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSaveContinue'"))[0]["LabelName"]);
                ucCompareGrants.btnSaveContinue.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSaveContinue'"))[0]["LabelToolTip"]);

                ucCompareGrants.btnViewValues.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnViewValues'"))[0]["LabelName"]);
                ucCompareGrants.btnViewValues.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnViewValues'"))[0]["LabelToolTip"]);

                ucCompareGrants.btnSaveComments.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnUpdateComments'"))[0]["LabelName"]);
                ucCompareGrants.btnSaveComments.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnUpdateComments'"))[0]["LabelToolTip"]);

                ucCompareGrants.lblComparePrameters.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblComparePrameters'"))[0]["LabelName"]);
                ucCompareGrants.lblComparePrameters.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblComparePrameters'"))[0]["LabelToolTip"]);

                ucCompareGrants.rdbValue.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'rdbValue'"))[0]["LabelName"]);
                ucCompareGrants.rdbValue.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'rdbValue'"))[0]["LabelToolTip"]);

                ucCompareGrants.rdbParameters.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'rdbParameters'"))[0]["LabelName"]);
                ucCompareGrants.rdbParameters.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'rdbParameters'"))[0]["LabelToolTip"]);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind locked record Grants
        /// </summary>
        /// <param name="ucCompareGrants">ucCompareGrants page object</param>
        public void BindGrantIDDropdown(CompareGrantsUC ucCompareGrants)
        {
            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                ac_ValuationReport.dt_all_Grants = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants;
            }

            if (ac_ValuationReport.dt_all_Grants != null && ac_ValuationReport.dt_all_Grants.Rows.Count > 0)
            {
                ucCompareGrants.ddlGrantIDList.DataSource = (from b in ac_ValuationReport.dt_all_Grants.AsEnumerable()
                                                             where b.Field<string>("Grant Registration ID") != null
                                                             select b.Field<string>("Grant Registration ID") + "(" + b.Field<string>("Grant Date") + ")").Distinct();
                ucCompareGrants.ddlGrantIDList.DataBind();
            }
            ucCompareGrants.ddlGrantIDList.Items.Insert(0, "--- Please Select ---");
        }

        /// <summary>
        /// Save and Continue to next step
        /// </summary>
        /// <param name="ucCompareGrants">ucCompareGrants page object</param>
        /// <param name="s_Action">Action based in condition</param>
        /// <param name="sender">sender</param>
        public void SaveContinue(CompareGrantsUC ucCompareGrants, string s_Action, object sender)
        {
            Button button = (Button)sender;
            try
            {
                string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
                string s_GrantID = ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Equals("--- Please Select ---") ? string.Empty : ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Split('(')[0];

                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                    {


                        valuationProperties.Operation = CommonConstantModel.s_SaveCompareComments;
                        valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.Action = s_Action.Equals("Create") ? "C" : "R";
                        valuationProperties.Step = "SAVE_STEP_NUMBER_OR_COMMENT";
                        valuationProperties.Group_Id = ac_ValuationReport.dt_all_Grants.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"].ToString();
                        valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        ac_ValuationReport.s_StepNumber = "0";

                        switch (button.ID)
                        {
                            case "btnSaveComments":
                                foreach (DataTable per_DataTable in ac_ValuationReport.ds_CalculationDetails.Tables)
                                {
                                    if (!ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Equals("--- Please Select ---") && ucCompareGrants.rdbValue.Checked)
                                    {
                                        valuationProperties.Selected_Grant_ID = per_DataTable.TableName;
                                        valuationProperties.Prameters_Selected = ucCompareGrants.rdbValue.Checked ? "Value" : ucCompareGrants.rdbParameters.Checked ? "Parameters" : string.Empty;
                                        valuationProperties.Compared_Grant_ID = ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Split('(')[0];
                                        valuationProperties.Is_Reviewer_User_Comment = userSessionInfo.ACC_UerTypeID.Equals(5) ? 2 : 1;
                                        valuationProperties.StockPriceComment = Convert.ToString(per_DataTable.Rows[0]["Comments"]);
                                        valuationProperties.ExpectedLifeComment = Convert.ToString(per_DataTable.Rows[1]["Comments"]);
                                        valuationProperties.VolatilityComment = Convert.ToString(per_DataTable.Rows[2]["Comments"]);
                                        valuationProperties.RFIR_Comment = Convert.ToString(per_DataTable.Rows[3]["Comments"]);
                                        valuationProperties.ExercisePriceComment = Convert.ToString(per_DataTable.Rows[4]["Comments"]);
                                        valuationProperties.DividendComment = Convert.ToString(per_DataTable.Rows[5]["Comments"]);
                                        valuationProperties.FVPerVestComment = Convert.ToString(per_DataTable.Rows[7]["Comments"]);
                                        valuationProperties.VestPercentComment = Convert.ToString(per_DataTable.Rows[9]["Comments"]);
                                        if (ac_ValuationReport.ds_CalculationDetails_IntrinsicValue != null && ac_ValuationReport.ds_CalculationDetails_IntrinsicValue.Tables.Count > 0)
                                        {
                                            valuationProperties.Market_Price = Convert.ToString(ac_ValuationReport.ds_CalculationDetails_IntrinsicValue.Tables[per_DataTable.TableName].Rows[0]["Comments"]);
                                            valuationProperties.Exercise_Price_Comments = Convert.ToString(ac_ValuationReport.ds_CalculationDetails_IntrinsicValue.Tables[per_DataTable.TableName].Rows[1]["Comments"]);
                                            valuationProperties.Intrinsic_Value_Comments = Convert.ToString(ac_ValuationReport.ds_CalculationDetails_IntrinsicValue.Tables[per_DataTable.TableName].Rows[2]["Comments"]);
                                        }
                                        valuationProperties.Step_Number = "1";
                                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                                    }
                                }
                                foreach (DataTable per_DataTable in ac_ValuationReport.ds_SelectedDataTables.Tables)
                                {
                                    if (!ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Equals("--- Please Select ---") && ucCompareGrants.rdbParameters.Checked)
                                    {
                                        valuationProperties.Selected_Grant_ID = per_DataTable.TableName;
                                        valuationProperties.Prameters_Selected = ucCompareGrants.rdbValue.Checked ? "Value" : ucCompareGrants.rdbParameters.Checked ? "Parameters" : string.Empty;
                                        valuationProperties.Compared_Grant_ID = ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Split('(')[0];
                                        valuationProperties.Is_Reviewer_User_Comment = userSessionInfo.ACC_UerTypeID.Equals(5) ? 2 : 1;
                                        valuationProperties.StockPriceComment = Convert.ToString(per_DataTable.Rows[0]["Comments"]);
                                        valuationProperties.ExpectedLifeComment = Convert.ToString(per_DataTable.Rows[1]["Comments"]);
                                        valuationProperties.VolatilityComment = Convert.ToString(per_DataTable.Rows[3]["Comments"]);
                                        valuationProperties.RFIR_Comment = Convert.ToString(per_DataTable.Rows[2]["Comments"]);
                                        valuationProperties.DividendComment = Convert.ToString(per_DataTable.Rows[4]["Comments"]);
                                        if (ac_ValuationReport.ds_SelectedDT_IntrinsicValue != null && ac_ValuationReport.ds_SelectedDT_IntrinsicValue.Tables.Count > 0)
                                        {
                                            valuationProperties.Market_Price = Convert.ToString(ac_ValuationReport.ds_SelectedDT_IntrinsicValue.Tables[per_DataTable.TableName].Rows[0]["Comments"]);
                                        }
                                        if (ac_ValuationReport.ds_CalculationDetails_IntrinsicValue != null && ac_ValuationReport.ds_CalculationDetails_IntrinsicValue.Tables.Count > 0)
                                        {
                                            valuationProperties.Market_Price = Convert.ToString(ac_ValuationReport.ds_CalculationDetails_IntrinsicValue.Tables[per_DataTable.TableName].Rows[0]["Comments"]);
                                        }
                                        valuationProperties.Step_Number = "1";
                                        valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                                    }
                                }

                                ucCompareGrants.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblCommentsUploaded", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10);
                                ucCompareGrants.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                                break;

                            case "btnSaveContinue":
                                ac_ValuationReport.dt_all_Grants = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants;
                                _gvUserControlModel.ac_SearchGrantDetails.s_StepNumber = "2";
                                SaveGrantLevelPrameters();
                                valuationProperties.Operation = CommonConstantModel.s_OperationCUD;
                                valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                                valuationProperties.Step_Number = "2";
                                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                                ucCompareGrants.ddlGrantIDList.SelectedIndex = -1;
                                break;
                        }


                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Read Valuation Parameters
        /// </summary>
        /// <param name="s_GrantID"></param>
        /// <returns></returns>
        public DataTable GetValuationParameters(string s_GrantID)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                valuationProperties.PageName = CommonConstantModel.s_ValuationParameters;
                valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                using (GetValuationParameters getValuationParameters = new GetValuationParameters())
                {
                    using (DataTable dt_ValuationParameter = getValuationParameters.CreateDataTable("CompareGrants"))
                    {
                        dt_ValuationParameter.TableName = "dtValuationParameter";

                        return getValuationParameters.CreateValuationParamDataTable(valuationServiceClient, dt_ValuationParameter, valuationCRUDProperties.ds_Result, s_GrantID);
                    }
                }
            }
        }

        /// <summary>
        /// Bind selected parameters to GridView
        /// </summary>
        /// <param name="ucCompareGrants">ucCompareGrants page object</param>
        /// <param name="s_Select">FairValue/IntrinsicValue</param>
        /// <param name="b_IsLinkButtonClick">FairValue/IntrinsicValue</param>
        public void BindSelectedGridValues(CompareGrantsUC ucCompareGrants, string s_Select, bool b_IsLinkButtonClick)
        {
            string s_SelectedGrantID = string.Empty;
            Table table = new Table();
            table.CellSpacing = 4;
            table.GridLines = GridLines.Both;
            ac_ValuationReport.s_CompareGrantID = string.Empty;
            table.HorizontalAlign = HorizontalAlign.Center;
            ucCompareGrants.btnSaveComments.Visible = false;

            #region Add header as "Selected Grants" and "Compare Grant"
            using (TableRow tr = new TableRow())
            {
                TableCell td = new TableCell();
                td.BackColor = System.Drawing.ColorTranslator.FromHtml("#F0F4F7");
                td.Text = "Selected Grants";
                td.Font.Bold = true;
                td.VerticalAlign = VerticalAlign.Middle;
                td.HorizontalAlign = HorizontalAlign.Center;
                td.Width = Unit.Percentage(50);
                td.Height = 25;
                tr.Cells.Add(td);
                table.Rows.Add(tr);


                td = new TableCell();
                if (!ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Equals("--- Please Select ---"))
                {
                    td.BackColor = System.Drawing.ColorTranslator.FromHtml("#F0F4F7");
                    td.Text = "Compare Grants";
                    td.VerticalAlign = VerticalAlign.Middle;
                    td.HorizontalAlign = HorizontalAlign.Center;
                    td.Font.Bold = true;
                }
                td.Height = 25;
                td.Width = Unit.Percentage(50);
                tr.Cells.Add(td);
                table.Rows.Add(tr);


            }
            #endregion

            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                valuationProperties.Operation = CommonConstantModel.s_SaveCompareComments;
                valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                valuationProperties.Action = "R";
                valuationProperties.Step = "SAVE_STEP_NUMBER_OR_COMMENT";

                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                ac_ValuationReport.dt_CommentsDetails = valuationCRUDProperties.dt_Result;
            }

            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                ac_ValuationReport.s_SelectedGrants = string.IsNullOrEmpty(ac_ValuationReport.s_SelectedGrants) ? _gvUserControlModel.ac_SearchGrantDetails.s_SelectedGrants : ac_ValuationReport.s_SelectedGrants;
            }

            foreach (var s_AGRMID in ac_ValuationReport.s_SelectedGrants.Split(','))
            {
                if (!string.IsNullOrEmpty(s_AGRMID))
                {
                    //This variable is used in SelectedGrantsUCModel.cs(Method Name: BindRows) page to retain state of selected check-box
                    using (TableRow tr = new TableRow())
                    {
                        tr.BorderWidth = Unit.Pixel(2);
                        tr.BorderStyle = BorderStyle.Solid;
                        tr.BorderColor = System.Drawing.ColorTranslator.FromHtml("#330000");

                        #region Selected Grants
                        using (GridView gvCalculations = new GridView())
                        {
                            using (TableCell td = new TableCell())
                            {
                                td.VerticalAlign = VerticalAlign.Top;
                                GridviewProperties(gvCalculations);
                                gvCalculations.RowDataBound += ucCompareGrants.gv_RowDataBound;
                                gvCalculations.DataBound += ucCompareGrants.gv_DataBound;
                                gvCalculations.EnableViewState = false;
                                using (DataTable dt_Parameters = GetValueOrParameters(ucCompareGrants, s_Select, s_AGRMID).Copy())
                                {
                                    if (ucCompareGrants.rdbValue.Checked && ucCompareGrants.rdbFairValue.Checked)
                                    {
                                        dt_Parameters.Rows.RemoveAt(10);
                                        dt_Parameters.Rows.RemoveAt(10);
                                        dt_Parameters.Rows.RemoveAt(10);
                                        dt_Parameters.Rows.RemoveAt(10);
                                        dt_Parameters.Rows.RemoveAt(10);
                                        dt_Parameters.Rows.RemoveAt(10);
                                    }

                                    DataColumnCollection columns = dt_Parameters.Columns;
                                    if (columns.Contains("Is_Manually_Updated"))
                                    {
                                        dt_Parameters.Columns.Remove("Is_Manually_Updated");
                                    }

                                    #region this is used to maintain parameters
                                    bool Is_Exist = false, Is_Exist_IV = false;

                                    foreach (DataTable item in ac_ValuationReport.ds_SelectedDataTables.Tables)
                                    {
                                        if (item.TableName.Equals(ac_ValuationReport.s_GrantRegID))
                                        {
                                            Is_Exist = true;
                                            break;
                                        }
                                    }
                                    foreach (DataTable item in ac_ValuationReport.ds_SelectedDT_IntrinsicValue.Tables)
                                    {
                                        if (item.TableName.Equals(ac_ValuationReport.s_GrantRegID))
                                        {
                                            Is_Exist_IV = true;
                                            break;
                                        }
                                    }
                                    s_SelectedGrantID = ac_ValuationReport.s_GrantRegID;
                                    if (!b_IsLinkButtonClick && !ucCompareGrants.rdbValue.Checked)
                                    {
                                        DataColumn dataColumn = new DataColumn("ParamID", typeof(string));
                                        dt_Parameters.Columns.Add(dataColumn);
                                        dt_Parameters.Columns.Add("Comments", typeof(string));
                                        dt_Parameters.TableName = s_SelectedGrantID;
                                        if (ucCompareGrants.rdbInrinsicValue.Checked)
                                        {
                                            if (!Is_Exist_IV)
                                            {
                                                ac_ValuationReport.ds_SelectedDT_IntrinsicValue.Tables.Add(dt_Parameters.Copy());
                                            }
                                        }
                                        else
                                        {
                                            if (!Is_Exist)
                                            {
                                                ac_ValuationReport.ds_SelectedDataTables.Tables.Add(dt_Parameters.Copy());
                                            }
                                        }
                                    }
                                    #endregion

                                    #region this is used to maintain calculations
                                    Is_Exist = Is_Exist_IV = false;
                                    foreach (DataTable item in ac_ValuationReport.ds_CalculationDetails.Tables)
                                    {
                                        if (item.TableName.Equals(ac_ValuationReport.s_GrantRegID))
                                        {
                                            Is_Exist = true;
                                            break;
                                        }
                                    }
                                    foreach (DataTable item in ac_ValuationReport.ds_CalculationDetails_IntrinsicValue.Tables)
                                    {
                                        if (item.TableName.Equals(ac_ValuationReport.s_GrantRegID))
                                        {
                                            Is_Exist_IV = true;
                                            break;
                                        }
                                    }
                                    if (ucCompareGrants.rdbValue.Checked)
                                    {
                                        dt_Parameters.Columns.Add("Comments", typeof(string));
                                        dt_Parameters.Columns.Add("Comments History", typeof(string));
                                        dt_Parameters.TableName = ac_ValuationReport.s_GrantRegID;
                                        if (ucCompareGrants.rdbInrinsicValue.Checked)
                                        {
                                            if (!Is_Exist_IV)
                                            {
                                                ac_ValuationReport.ds_CalculationDetails_IntrinsicValue.Tables.Add(dt_Parameters.Copy());
                                            }
                                        }
                                        else
                                        {
                                            if (!Is_Exist)
                                            {
                                                ac_ValuationReport.ds_CalculationDetails.Tables.Add(dt_Parameters.Copy());
                                            }
                                        }
                                    }
                                    #endregion

                                    gvCalculations.ID = "selected_" + ac_ValuationReport.s_GrantRegID;

                                    if (ucCompareGrants.rdbInrinsicValue.Checked)
                                    {
                                        if (dt_Parameters.Rows.Count > 3)
                                        {
                                            dt_Parameters.Rows.RemoveAt(dt_Parameters.Rows.Count - 1);
                                        }
                                        gvCalculations.DataSource = ucCompareGrants.rdbValue.Checked ? dt_Parameters : ac_ValuationReport.ds_SelectedDT_IntrinsicValue.Tables[ac_ValuationReport.s_GrantRegID];
                                    }
                                    else
                                    {
                                        gvCalculations.DataSource = ucCompareGrants.rdbValue.Checked ? dt_Parameters : ac_ValuationReport.ds_SelectedDataTables.Tables[ac_ValuationReport.s_GrantRegID];
                                    }

                                    gvCalculations.DataBind();
                                }
                                td.Width = Unit.Percentage(50);
                                td.Controls.Add(gvCalculations);
                                tr.Cells.Add(td);
                                table.Rows.Add(tr);
                                ucCompareGrants.CompareGD.Controls.Add(table);
                            }
                        }
                        #endregion

                        #region Add grants to Compare
                        if (!ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Equals("--- Please Select ---"))
                        {
                            ucCompareGrants.btnSaveComments.Visible = true;
                            using (GridView gvCalculationsComp = new GridView())
                            {
                                using (TableCell td = new TableCell())
                                {
                                    td.Width = Unit.Percentage(50);
                                    tr.Cells.Add(td);
                                    table.Rows.Add(tr);

                                    if (!(ac_ValuationReport.dt_all_Grants.Select("[AGRMID] = '" + s_AGRMID + "'")[0]["Grant Registration ID"].ToString()).Equals(ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Split('(')[0]))
                                    {
                                        using (Label lblSameGrants = new Label())
                                        {
                                            td.VerticalAlign = VerticalAlign.Top;
                                            gvCalculationsComp.ID = "comp|" + ac_ValuationReport.s_GrantRegID;
                                            GridviewProperties(gvCalculationsComp);
                                            gvCalculationsComp.RowDataBound += ucCompareGrants.gvLockedRecIVnFV_RowDataBound;
                                            gvCalculationsComp.DataBound += ucCompareGrants.gv_DataBound;
                                            gvCalculationsComp.EnableViewState = false;

                                            using (DataTable dt_Parameters = GetValueOrParameters(ucCompareGrants, s_Select, ac_ValuationReport.dt_all_Grants.Select("[Grant Registration ID] = '" + ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Split('(')[0] + "'")[0]["AGRMID"].ToString()).Copy())
                                            {
                                                if (ucCompareGrants.rdbValue.Checked && ucCompareGrants.rdbFairValue.Checked)
                                                {
                                                    dt_Parameters.Rows.RemoveAt(10);
                                                    dt_Parameters.Rows.RemoveAt(10);
                                                    dt_Parameters.Rows.RemoveAt(10);
                                                    dt_Parameters.Rows.RemoveAt(10);
                                                    dt_Parameters.Rows.RemoveAt(10);
                                                    dt_Parameters.Rows.RemoveAt(10);
                                                }

                                                DataColumnCollection columns = dt_Parameters.Columns;
                                                if (columns.Contains("Is_Manually_Updated"))
                                                {
                                                    dt_Parameters.Columns.Remove("Is_Manually_Updated");
                                                }

                                                dt_Parameters.Columns.RemoveAt(0);

                                                if (ucCompareGrants.rdbParameters.Checked)
                                                {
                                                    dt_Parameters.Columns.Remove("Update Grant Level Parameters");
                                                    dt_Parameters.Columns.Remove("Is Manual Uploaded");
                                                }
                                                else
                                                {
                                                    dt_Parameters.Columns.Add("Findings", typeof(string));
                                                }
                                                dt_Parameters.Columns.Add("Comments", typeof(string));
                                                dt_Parameters.Columns.Add("Comments History", typeof(string));
                                                if (ucCompareGrants.rdbValue.Checked && !ucCompareGrants.rdbInrinsicValue.Checked)
                                                {
                                                    CompareGrants(ac_ValuationReport.ds_CalculationDetails.Tables[s_SelectedGrantID], dt_Parameters);
                                                }
                                                gvCalculationsComp.DataSource = dt_Parameters;
                                                gvCalculationsComp.DataBind();

                                                td.Controls.Add(gvCalculationsComp);
                                                ucCompareGrants.CompareGD.Controls.Add(table);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        using (Label lblSameGrants = new Label())
                                        {
                                            lblSameGrants.Text = "Cannot compare same Grants";
                                            td.Controls.Add(lblSameGrants);
                                            ucCompareGrants.CompareGD.Controls.Add(table);
                                        }
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
            //ucCompareGrants.btnVRCompareGrants.Visible = true;
        }

        /// <summary>
        /// This method is used to get Values or Parameters
        /// </summary>
        /// <param name="ucCompareGrants">Page object</param>
        /// <param name="s_Select">Select type i.e. FairValue or IntrinsicValue</param>
        /// <param name="s_AGRMID">Grant reg. master ID</param>
        /// <returns>DataTable</returns>
        private DataTable GetValueOrParameters(CompareGrantsUC ucCompareGrants, string s_Select, string s_AGRMID)
        {
            try
            {
                using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                {
                    if (_gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants.Rows.Count > 0)
                    {
                        ac_ValuationReport.dt_all_Grants = _gvUserControlModel.ac_SearchGrantDetails.dt_all_Grants;
                    }
                }

                if (ac_ValuationReport.dt_all_Grants != null && ac_ValuationReport.dt_all_Grants.Rows.Count > 0)
                {
                    //used to display GrantID as Header 
                    ac_ValuationReport.s_GrantRegID = ac_ValuationReport.dt_all_Grants.Select("[AGRMID] = '" + s_AGRMID + "'")[0]["Grant Registration ID"].ToString();

                    using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                    {
                        using (GetValuationParameters getValuationParameters = new GetValuationParameters())
                        {
                            valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                            valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                            valuationProperties.GET_DATA_TYPE = "VESTWISE";
                            valuationProperties.Grant_ID = ac_ValuationReport.s_GrantRegID;
                            valuationProperties.SEN_IsListed = userSessionInfo.ACC_IsListed;
                            valuationProperties.SEN_IsMYESOPsClient = userSessionInfo.ACC_IsMYESOPsClient;
                            valuationProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                            valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            valuationProperties.SEN_CompanyTitle = userSessionInfo.ACC_CompanyTitle;

                            valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                            DataTable dataTable = valuationCRUDProperties.ds_Result.Tables[0];

                            using (DataTable outputTable = getValuationParameters.GetCalculationsIVnFV(ref dataTable, s_Select))
                            {

                                return ac_ValuationReport.dt_Selected = ucCompareGrants.rdbValue.Checked ? outputTable : GenerateDatatble(new DataTable(), GetValuationParameters(ac_ValuationReport.dt_all_Grants.Select("[AGRMID] = '" + s_AGRMID + "'")[0]["Grant Registration ID"].ToString()), s_Select, ac_ValuationReport.dt_all_Grants.Select("[AGRMID] = '" + s_AGRMID + "'")[0]["Grant Registration ID"].ToString());
                            }
                        }
                    }
                }
                return new DataTable();
            }
            catch
            {
                //do nothing
            }
            return new DataTable();
        }

        /// <summary>
        /// This method is used to add findings in DataTable
        /// </summary>
        /// <param name="dt_SelectedGrant">SelectedGrant DataTable</param>
        /// <param name="dt_ComparedGrant">ComparedGrant DataTable</param>
        internal void CompareGrants(DataTable dt_SelectedGrant, DataTable dt_ComparedGrant)
        {
            string s_Volatility_GreaterThan75 = string.Empty;

            string s_ExercisePrice = string.Empty;
            decimal n_Facevalue = string.IsNullOrEmpty(ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("[Grant Registration ID] = '" + dt_SelectedGrant.TableName + "'")[0]["Face Value"].ToString()) ? 0 : Convert.ToDecimal(ac_ValuationReport.dt_all_Grants.Select("[Grant Registration ID] = '" + dt_SelectedGrant.TableName + "'")[0]["Face Value"]);

            string s_ExpectedLifeLessThanVestingPerion = string.Empty;
            int n_VestingPeriod = 0;

            string s_ExpectedLifeGreaterThanExcercisePeriod = string.Empty;
            int n_ExcercisePeriod = 0;

            string s_VolatilityDifferentMoreThan20 = string.Empty;

            string s_RFIRDifferentMoreThan20 = string.Empty;
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                valuationProperties.PageName = CommonConstantModel.s_ValuationReport;
                valuationProperties.Operation = CommonConstantModel.s_OperationRead_Values;
                valuationProperties.Grant_ID = dt_SelectedGrant.TableName;
                valuationProperties.GET_DATA_TYPE = "VESTWISE";

                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                for (int i = 1; i < dt_SelectedGrant.Columns.Count - 2; i++)
                {
                    n_VestingPeriod = string.IsNullOrEmpty(valuationCRUDProperties.ds_Result.Tables[0].Select("[Vesting Date] = '" + dt_SelectedGrant.Columns[i].ColumnName.Split(':')[1].Trim() + "'")[0]["Vesting Period"].ToString()) ? 0 : Convert.ToInt32(valuationCRUDProperties.ds_Result.Tables[0].Select("[Vesting Date] = '" + dt_SelectedGrant.Columns[i].ColumnName.Split(':')[1].Trim() + "'")[0]["Vesting Period"]);
                    n_ExcercisePeriod = string.IsNullOrEmpty(valuationCRUDProperties.ds_Result.Tables[0].Select("[Vesting Date] = '" + dt_SelectedGrant.Columns[i].ColumnName.Split(':')[1].Trim() + "'")[0]["Exercise Period"].ToString()) ? 0 : Convert.ToInt32(valuationCRUDProperties.ds_Result.Tables[0].Select("[Vesting Date] = '" + dt_SelectedGrant.Columns[i].ColumnName.Split(':')[1].Trim() + "'")[0]["Exercise Period"]);

                    s_Volatility_GreaterThan75 = (!string.IsNullOrEmpty(dt_SelectedGrant.Rows[2].Field<string>(i)) ? Convert.ToDecimal(dt_SelectedGrant.Rows[2].Field<string>(i)) : 0) > 75 ? s_Volatility_GreaterThan75 + dt_SelectedGrant.Columns[i].ColumnName + ", " : s_Volatility_GreaterThan75;
                    s_ExercisePrice = (!string.IsNullOrEmpty(dt_SelectedGrant.Rows[4].Field<string>(i)) ? Convert.ToDecimal(dt_SelectedGrant.Rows[4].Field<string>(i)) : 0) <= n_Facevalue ? s_ExercisePrice + dt_SelectedGrant.Columns[i].ColumnName + ", " : s_ExercisePrice;
                    s_ExpectedLifeLessThanVestingPerion = (!string.IsNullOrEmpty(dt_SelectedGrant.Rows[1].Field<string>(i)) ? Convert.ToDecimal(dt_SelectedGrant.Rows[1].Field<string>(i)) : 0) <= n_VestingPeriod ? s_ExpectedLifeLessThanVestingPerion + dt_SelectedGrant.Columns[i].ColumnName + ", " : s_ExpectedLifeLessThanVestingPerion;
                    s_ExpectedLifeGreaterThanExcercisePeriod = (!string.IsNullOrEmpty(dt_SelectedGrant.Rows[1].Field<string>(i)) ? Convert.ToDecimal(dt_SelectedGrant.Rows[1].Field<string>(i)) : 0) >= n_ExcercisePeriod ? s_ExpectedLifeGreaterThanExcercisePeriod + dt_SelectedGrant.Columns[i].ColumnName + ", " : s_ExpectedLifeGreaterThanExcercisePeriod;

                    if (i >= dt_ComparedGrant.Columns.Count - 3)
                    {
                        int n_VolatilityOfEarliar = !string.IsNullOrEmpty(dt_ComparedGrant.Rows[2].Field<string>(dt_ComparedGrant.Columns.Count - 3)) ? Convert.ToInt32(dt_ComparedGrant.Rows[2].Field<string>(dt_ComparedGrant.Columns.Count - 3)) : 0;
                        s_VolatilityDifferentMoreThan20 = (!string.IsNullOrEmpty(dt_SelectedGrant.Rows[1].Field<string>(i)) ? Convert.ToDecimal(dt_SelectedGrant.Rows[2].Field<string>(i)) : 0) - n_VolatilityOfEarliar >= 20 ? s_ExpectedLifeGreaterThanExcercisePeriod + dt_SelectedGrant.Columns[i].ColumnName + ", " : s_ExpectedLifeGreaterThanExcercisePeriod;

                        decimal n_RFIROfEarliar = !string.IsNullOrEmpty(dt_ComparedGrant.Rows[3].Field<string>(dt_ComparedGrant.Columns.Count - 3)) ? Convert.ToDecimal(dt_ComparedGrant.Rows[3].Field<string>(dt_ComparedGrant.Columns.Count - 3)) : 0;
                        s_RFIRDifferentMoreThan20 = (!string.IsNullOrEmpty(dt_SelectedGrant.Rows[3].Field<string>(i)) ? Convert.ToDecimal(dt_SelectedGrant.Rows[3].Field<string>(i)) : 0) - n_VolatilityOfEarliar >= 20 ? s_ExpectedLifeGreaterThanExcercisePeriod + dt_SelectedGrant.Columns[i].ColumnName + ", " : s_ExpectedLifeGreaterThanExcercisePeriod;
                    }
                    else
                    {
                        decimal n_VolatilityOfEarliar = !string.IsNullOrEmpty(dt_ComparedGrant.Rows[2].Field<string>(i)) ? Convert.ToDecimal(dt_ComparedGrant.Rows[2].Field<string>(i)) : 0;
                        s_VolatilityDifferentMoreThan20 = (!string.IsNullOrEmpty(dt_SelectedGrant.Rows[2].Field<string>(i)) ? Convert.ToDecimal(dt_SelectedGrant.Rows[2].Field<string>(i)) : 0) - n_VolatilityOfEarliar >= 20 ? s_ExpectedLifeGreaterThanExcercisePeriod + dt_SelectedGrant.Columns[i].ColumnName + ", " : s_ExpectedLifeGreaterThanExcercisePeriod;

                        decimal n_RFIROfEarliar = !string.IsNullOrEmpty(dt_ComparedGrant.Rows[3].Field<string>(i)) ? Convert.ToDecimal(dt_ComparedGrant.Rows[3].Field<string>(i)) : 0;
                        s_RFIRDifferentMoreThan20 = (!string.IsNullOrEmpty(dt_SelectedGrant.Rows[3].Field<string>(i)) ? Convert.ToDecimal(dt_SelectedGrant.Rows[3].Field<string>(i)) : 0) - n_VolatilityOfEarliar >= 20 ? s_ExpectedLifeGreaterThanExcercisePeriod + dt_SelectedGrant.Columns[i].ColumnName + ", " : s_ExpectedLifeGreaterThanExcercisePeriod;
                    }
                }
                //Volatility findings
                dt_ComparedGrant.Rows[2]["Findings"] = string.IsNullOrEmpty(s_Volatility_GreaterThan75) ? string.Empty : Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgVolatility'"))[0]["LabelName"]) + s_Volatility_GreaterThan75.TrimEnd(' ', ',');
                dt_ComparedGrant.Rows[2]["Findings"] = string.IsNullOrEmpty(s_VolatilityDifferentMoreThan20) ? string.Empty : string.IsNullOrEmpty(s_Volatility_GreaterThan75) ? Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgVolatility2'"))[0]["LabelName"]) + s_VolatilityDifferentMoreThan20 : Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgVolatility'"))[0]["LabelName"]) +
                                                       s_Volatility_GreaterThan75.TrimEnd(' ', ',') + " and " + Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgVolatility2'"))[0]["LabelName"]) + s_VolatilityDifferentMoreThan20.TrimEnd(' ', ',');
                //Exercise Price findings
                dt_ComparedGrant.Rows[4]["Findings"] = string.IsNullOrEmpty(s_ExercisePrice) ? string.Empty : Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgExercisePrice'"))[0]["LabelName"]) + s_ExercisePrice.TrimEnd(' ', ',');
                //Expected Life findings
                dt_ComparedGrant.Rows[1]["Findings"] = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgExpectedLife'"))[0]["LabelName"]) + s_ExpectedLifeLessThanVestingPerion.TrimEnd(' ', ',');
                dt_ComparedGrant.Rows[1]["Findings"] = string.IsNullOrEmpty(s_ExpectedLifeLessThanVestingPerion) ? Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgExpectedLife2'"))[0]["LabelName"]) + s_ExpectedLifeGreaterThanExcercisePeriod.TrimEnd(' ', ',') : Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgExpectedLife'"))[0]["LabelName"]) +
                                                       s_ExpectedLifeLessThanVestingPerion.TrimEnd(' ', ',') + " and " + Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgExpectedLife2'"))[0]["LabelName"]) + s_ExpectedLifeGreaterThanExcercisePeriod.TrimEnd(' ', ',');
                //RFIR findings
                dt_ComparedGrant.Rows[3]["Findings"] = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgRFIRnDividend'"))[0]["LabelName"]) + s_RFIRDifferentMoreThan20.TrimEnd(' ', ',');
                //Dividend findings
                dt_ComparedGrant.Rows[5]["Findings"] = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'fndgRFIRnDividend'"))[0]["LabelName"]) + s_RFIRDifferentMoreThan20.TrimEnd(' ', ',');
            }
        }

        #region Create datatable for comparison

        /// <summary>
        /// This method is used to create datatable for comparison
        /// </summary>
        /// <param name="dt_Calculations">Actual datatable with calculation</param>
        /// <param name="dt_Parameters">Valuation parameters datatable</param>
        /// <param name="s_Select">Select "FairValue" or "IntrinsicValue"</param>
        /// <param name="s_GrantID">Grant ID</param>
        /// <returns>FinalData in DataTable</returns>
        public DataTable GenerateDatatble(DataTable dt_Calculations, DataTable dt_Parameters, string s_Select, string s_GrantID)
        {
            DataTable dt_FinalData = dt_Calculations;

            dt_FinalData.Columns.Add("", typeof(string));
            dt_FinalData.Columns.Add("Parameters at Company Level", typeof(string));
            dt_FinalData.Columns.Add("Grant Level", typeof(string));
            dt_FinalData.Columns.Add("Parameters at Grant Level", typeof(string));

            switch (s_Select)
            {
                case "FairValue":
                    dt_Parameters.Rows[0].Delete();
                    dt_FinalData = dt_Parameters;
                    dt_FinalData.Columns.Remove("Update Company Parameters");
                    break;

                case "IntrinsicValue":
                    dt_Parameters.Rows[1].Delete();
                    dt_Parameters.Rows[1].Delete();
                    dt_Parameters.Rows[1].Delete();
                    dt_Parameters.Rows[1].Delete();
                    dt_Parameters.Rows[1].Delete();
                    dt_FinalData = dt_Parameters;
                    dt_FinalData.Columns.Remove("Update Company Parameters");

                    break;
            }
            dt_FinalData.Columns["Parameters selected for grant"].ColumnName = "Variables";
            dt_FinalData.Columns["Company Level"].ColumnName = "Parameters at Company Level";
            dt_FinalData.Columns["Present Grant Parameters"].ColumnName = "Parameters at Grant Level";
            return dt_FinalData;
        }
        #endregion

        #region Common method to bind GridView CSS
        /// <summary>
        /// Common method to bind properties of gridview
        /// </summary>
        /// <param name="gvCalculations">GridView</param>
        private void GridviewProperties(GridView gvCalculations)
        {
            gvCalculations.CssClass = "Grid";
            gvCalculations.RowStyle.CssClass = "gridItems";
            gvCalculations.HeaderStyle.CssClass = "gridHeader";
            gvCalculations.SelectedRowStyle.CssClass = "gridItemsSelected";
            gvCalculations.CellPadding = 6;
            gvCalculations.CellSpacing = 0;
        }

        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ucCompareGrants"></param>
        /// <param name="sender"></param>
        /// <returns></returns>
        public string[] RedirectToGrantDetails(CompareGrantsUC ucCompareGrants, object sender)
        {
            ucCompareGrants.Session["CurrentTabIndex"] = "1";

            LinkButton linkbutton = (LinkButton)sender;

            return linkbutton.ID.Split('~');
        }

        #region Bind header and footer to GridView
        /// <summary>
        /// This method is used to bind footer 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="compareGrantsUCModel"></param>
        /// <param name="ucCompareGrants"></param>
        public void BindHeaderFooter(object sender, CompareGrantsUCModel compareGrantsUCModel, CompareGrantsUC ucCompareGrants)
        {
            using (gvUserControlModel _gvUserControlModel = new gvUserControlModel())
            {
                compareGrantsUCModel.ac_ValuationReport.n_VestCount = _gvUserControlModel.ac_SearchGrantDetails.n_VestCount;
                compareGrantsUCModel.ac_ValuationReport.s_FinalValue = _gvUserControlModel.ac_SearchGrantDetails.s_FinalValue;
                compareGrantsUCModel.ac_ValuationReport.s_FairValue = _gvUserControlModel.ac_SearchGrantDetails.s_FairValue;
                compareGrantsUCModel.ac_ValuationReport.n_RowCount = _gvUserControlModel.ac_SearchGrantDetails.n_RowCount;
            }

            using (GridView gridView = (GridView)sender)
            {
                if (gridView.Rows.Count > 0)
                {
                    using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal))
                    {
                        using (TableCell cell = new TableCell())
                        {
                            string GrantDate = ac_ValuationReport.dt_Selected.Columns.Cast<DataColumn>()
                                               .Select(x => x.ColumnName)
                                               .ToArray()[0];

                            cell.Text = "Grant Registration ID: " + compareGrantsUCModel.ac_ValuationReport.s_GrantRegID + "    |  " + GrantDate;
                            cell.ColumnSpan = compareGrantsUCModel.ac_ValuationReport.n_VestCount + 2;
                            cell.Font.Bold = true;
                            cell.ForeColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
                            cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#808080");
                            cell.HorizontalAlign = HorizontalAlign.Left;

                            row.Controls.Add(cell);
                            gridView.HeaderRow.Parent.Controls.AddAt(0, row);
                        }
                    }

                    if (ucCompareGrants.rdbValue.Checked)
                    {
                        using (GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Footer, DataControlRowState.Normal))
                        {
                            TableCell cell = new TableCell();
                            cell.Text = compareGrantsUCModel.ac_ValuationReport.s_FinalValue + ": " + compareGrantsUCModel.ac_ValuationReport.s_FairValue;
                            cell.ColumnSpan = 20;
                            cell.Font.Bold = true;
                            cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#D1D1D1");
                            cell.HorizontalAlign = HorizontalAlign.Center;
                            row.Controls.Add(cell);

                            gridView.HeaderRow.Parent.Controls.AddAt((compareGrantsUCModel.ac_ValuationReport.n_RowCount - 6) + 4, row);

                            cell.Dispose();
                        }
                    }
                }
            }
        }

        #endregion

        /// <summary>
        /// Compare records vest-wise
        /// </summary>
        /// <param name="ucCompareGrants">CompareGrants</param>
        /// <param name="e">GridViewRowEventArgs</param>
        /// <param name="s_Header">Header</param>
        /// <param name="n_index">index</param>
        /// <param name="n_Findings">Findings</param>
        /// <param name="n_Comments">Comments</param>
        /// <param name="sender">sender</param>
        public void BindGrid(CompareGrantsUC ucCompareGrants, GridViewRowEventArgs e, ref string s_Header, ref int n_index, ref int n_Findings, ref int n_Comments, object sender)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    e.Row.Height = Unit.Pixel(66);
                    s_Header = e.Row.Cells[0].Text;
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        switch (perColumn.Text.ToUpper())
                        {
                            case "FINDINGS":
                                n_Findings = n_index;
                                break;

                            case "COMMENTS":
                                n_Comments = n_index;
                                //perColumn.Visible = false;
                                break;
                        }
                        n_index = n_index + 1;
                    }
                    if (ucCompareGrants.rdbParameters.Checked)
                    {
                        e.Row.Cells[1].Visible = false;
                        e.Row.Cells[0].Text = "Applicable Parameters";
                    }
                    break;

                case DataControlRowType.DataRow:
                    GridView gv = (GridView)sender;
                    e.Row.Height = Unit.Pixel(30);
                    if (ucCompareGrants.rdbParameters.Checked)
                    {
                        e.Row.Height = Unit.Pixel(55);
                        e.Row.Cells[2].Controls.Add(AddTextBox(gv.ID, e.Row.RowIndex, ucCompareGrants));
                        CommentsDetails(ucCompareGrants, e, 3, gv.ID, e.Row.RowIndex);
                        e.Row.Cells[0].Width = 220;
                        e.Row.Cells[1].Width = 220;
                        e.Row.Cells[1].Visible = false;
                    }
                    else if (ucCompareGrants.rdbValue.Checked)
                    {
                        e.Row.Height = Unit.Pixel(45);
                        try
                        {
                            string s_roundingLimit = string.Empty;
                            using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                            {
                                for (int i = 0; i < e.Row.Cells.Count; i++)
                                {
                                    try
                                    {
                                        s_roundingLimit = e.Row.Cells[0].Text.Contains("Intrinsic Value") ? "1" : e.Row.Cells[0].Text.Contains("Fair Value") ? "2" : e.Row.Cells[0].Text.Contains("Market Price") ? "3" : e.Row.Cells[0].Text.Contains("Exercise Price") ? "4" : e.Row.Cells[0].Text.Contains("Expected Life ") ? "5" : e.Row.Cells[0].Text.Contains("Volatility") ? "6" : e.Row.Cells[0].Text.Contains("Riskfree Rate") ? "7" : e.Row.Cells[0].Text.Contains("Dividend yield") ? "8" : "11";

                                        e.Row.Cells[i].Text = e.Row.Cells[i].Text;

                                        if (Convert.ToDouble(e.Row.Cells[i].Text) > 999)
                                        {
                                            e.Row.Cells[i].Text = CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[i].Text, DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                            e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Right;
                                        }
                                        else
                                            e.Row.Cells[i].Text = CommonModel.GetRoundedValue(e.Row.Cells[i].Text, DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                        e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Right;
                                    }
                                    catch (Exception)
                                    {
                                        // Do nothing
                                    }
                                }
                            }
                        }
                        catch
                        {
                            throw;
                        }

                        for (int i = 0; i < e.Row.Cells.Count; i++)
                        {
                            e.Row.Cells[i].Width = i.Equals(e.Row.Cells.Count - 1) ? 130 : i.Equals(e.Row.Cells.Count - 2) ? 90 : 75;
                            if (i.Equals(e.Row.Cells.Count - 1) && (!string.IsNullOrEmpty(e.Row.Cells[0].Text) && !e.Row.Cells[0].Text.Equals("&nbsp;")))
                            {
                                e.Row.Cells[i - 1].Controls.Add(AddTextBox(gv.ID, e.Row.RowIndex, ucCompareGrants));
                                CommentsDetails(ucCompareGrants, e, i, gv.ID, e.Row.RowIndex);
                            }
                            if (i.Equals(e.Row.Cells.Count - 2))
                            {
                                if (!e.Row.Cells[0].Text.Equals("&nbsp;") && (!e.Row.RowIndex.Equals(7) && !e.Row.RowIndex.Equals(9)))
                                {
                                    e.Row.Cells[i - 1].Controls.Add(AddImage(e.Row.Cells[i - 1].Text));
                                    e.Row.Cells[i - 1].HorizontalAlign = HorizontalAlign.Center;
                                }
                            }

                        }

                    }

                    break;
            }
        }

        #region Add CommentsDetails
        /// <summary>
        /// This method is used to bind comments of user and reviewer inform of conversation
        /// </summary>
        /// <param name="ucCompareGrants">Page object</param>
        /// <param name="e">Grid View Row Event Arguments</param>
        /// <param name="i">Cell index</param>
        /// <param name="s_GrantID">GrantID</param>
        /// <param name="n_RowIndex">RowIndex</param>
        private void CommentsDetails(CompareGrantsUC ucCompareGrants, GridViewRowEventArgs e, int i, string s_GrantID, int n_RowIndex)
        {
            string s_ParametersSelected = ucCompareGrants.rdbValue.Checked ? "Value" : "Parameters";
            DataRow[] dr = ac_ValuationReport.dt_CommentsDetails.Select("GROUP_ID = '" + ac_ValuationReport.dt_all_Grants.Select("[Grant Registration ID] = '" + s_GrantID.Split('|')[1] + "'")[0]["Group Number"].ToString() +
                            "' AND COMPARED_GRANT_ID = '" + ucCompareGrants.ddlGrantIDList.SelectedItem.Text.Split('(')[0] +
                            "' AND GRANT_REG_ID = '" + s_GrantID.Split('|')[1] + "' AND PRAMETERS_SELECTED = '" + s_ParametersSelected + "'");

            using (DataTable dt = new DataTable())
            {
                if (dr.Count() > 0)
                {
                    dt.Columns.Add("User Type", typeof(string));
                    dt.Columns.Add("Comment", typeof(string));
                    dt.Columns.Add("Created On", typeof(string));

                    switch (n_RowIndex)
                    {
                        case 0:
                            if (ucCompareGrants.rdbInrinsicValue.Checked)
                            {
                                CreateCommentsDetails(dr, dt, "MARKET_PRICE");
                            }
                            else if (ucCompareGrants.rdbFairValue.Checked)
                            {
                                CreateCommentsDetails(dr, dt, "STOCK_PRICE_COMMENT");
                            }
                            break;

                        case 1:
                            if (ucCompareGrants.rdbInrinsicValue.Checked)
                            {
                                CreateCommentsDetails(dr, dt, "EXERCISE_PRICE");
                            }
                            else if (ucCompareGrants.rdbFairValue.Checked)
                            {
                                CreateCommentsDetails(dr, dt, "EXPECTED_LIFE_COMMENT");
                            }
                            break;

                        case 2:
                            if (ucCompareGrants.rdbInrinsicValue.Checked)
                            {
                                CreateCommentsDetails(dr, dt, "INTRINSIC_VALUE");
                            }
                            else if (ucCompareGrants.rdbFairValue.Checked)
                            {
                                CreateCommentsDetails(dr, dt, ucCompareGrants.rdbValue.Checked ? "VOLATILITY_COMMENT" : ucCompareGrants.rdbParameters.Checked ? "RFIR_COMMENT" : string.Empty);
                            }
                            break;

                        case 3:
                            CreateCommentsDetails(dr, dt, ucCompareGrants.rdbValue.Checked ? "RFIR_COMMENT" : ucCompareGrants.rdbParameters.Checked ? "VOLATILITY_COMMENT" : string.Empty);
                            break;

                        case 4:
                            CreateCommentsDetails(dr, dt, ucCompareGrants.rdbValue.Checked ? "EXERCISE_PRICE_COMMENT" : ucCompareGrants.rdbParameters.Checked ? "DIVIDEND_COMMENTS" : string.Empty);
                            break;

                        case 5:
                            if (ucCompareGrants.rdbValue.Checked)
                            {
                                CreateCommentsDetails(dr, dt, "DIVIDEND_COMMENTS");
                            }
                            break;

                        case 7:
                            if (ucCompareGrants.rdbValue.Checked)
                            {
                                CreateCommentsDetails(dr, dt, "FV_PER_VEST_COMMENT");
                            }
                            break;

                        case 9:
                            if (ucCompareGrants.rdbValue.Checked)
                            {
                                CreateCommentsDetails(dr, dt, "VEST_PERCENT_COMMENT");
                            }
                            break;
                    }

                    using (GridView gvCommentsDetails = new GridView())
                    {
                        if (dt.Rows.Count > 0)
                        {
                            GridviewProperties(gvCommentsDetails);
                            gvCommentsDetails.DataSource = dt;
                            gvCommentsDetails.DataBind();

                            System.Web.UI.HtmlControls.HtmlGenericControl div = new System.Web.UI.HtmlControls.HtmlGenericControl("div");
                            div.Attributes.Add("id", "divForRowNumber" + e.Row.RowIndex + s_GrantID);
                            div.Controls.Add(gvCommentsDetails);
                            div.Attributes.Add("style", "position:absolute;display:none;background-color: #4C0000; right: 2%; padding: 3px");

                            using (Image image = new Image())
                            {
                                image.ImageUrl = "~/View/App_Themes/images/View.png";
                                image.Attributes.Add("style", "cursor: pointer; cursor: hand;");
                                image.Attributes.Add("onmouseover", "document.getElementById('" + "divForRowNumber" + e.Row.RowIndex + s_GrantID + "').style.display = 'block'; ");
                                image.Attributes.Add("onmouseout", "document.getElementById('" + "divForRowNumber" + e.Row.RowIndex + s_GrantID + "').style.display = 'none'; ");
                                e.Row.Cells[i].Controls.Add(image);
                                e.Row.Cells[i].Controls.Add(div);
                                e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Center;
                                e.Row.Cells[i].Attributes.Add("style", "word-break:break-all;word-wrap:break-word");
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Create DataTable to bind GridView
        /// </summary>
        /// <param name="dr">DataRow array</param>
        /// <param name="dt_SelectTable">DataTable created to bind GridView</param>
        /// <param name="s_Comments">Comments to be inserted in GridView</param>
        /// <returns>DataTable</returns>
        private DataTable CreateCommentsDetails(DataRow[] dr, DataTable dt_SelectTable, string s_Comments)
        {
            foreach (DataRow perRow in dr)
            {
                DataRow dataRow = dt_SelectTable.NewRow();

                if (!string.IsNullOrEmpty(Convert.ToString(perRow["" + s_Comments + ""])))
                {
                    dataRow["User Type"] = perRow["IS_REVIEWER_USER_COMMENT"].Equals(1) ? "User" : "Reviewer";
                    dataRow["Comment"] = perRow["" + s_Comments + ""];
                    dataRow["Created On"] = perRow["CREATED_ON"];
                    dt_SelectTable.Rows.Add(dataRow);
                }

            }
            return dt_SelectTable;
        }
        #endregion

        /// <summary>
        /// Create textbox
        /// </summary>
        /// <param name="s_RowName">Name of the row</param>
        /// <param name="n_RowNumber">Row number</param>
        /// <param name="ucCompareGrants">Page object</param>
        /// <returns>TextBox</returns>
        private TextBox AddTextBox(string s_RowName, int n_RowNumber, CompareGrantsUC ucCompareGrants)
        {
            TextBox textBox = new TextBox();
            if (ucCompareGrants.rdbValue.Checked)
            {
                textBox.ID = ucCompareGrants.rdbInrinsicValue.Checked ? "IntrinsicValue_" + "Values_" + "txt_" + s_RowName + "|" + n_RowNumber : "Values_" + "txt_" + s_RowName + "|" + n_RowNumber;
            }
            else if (ucCompareGrants.rdbParameters.Checked)
            {
                textBox.ID = ucCompareGrants.rdbInrinsicValue.Checked ? "IntriValue_" + "Parameters_" + "txt_" + s_RowName + "|" + n_RowNumber : "Parameters_" + "txt_" + s_RowName + "|" + n_RowNumber;
            }

            textBox.TextMode = TextBoxMode.MultiLine;
            textBox.Width = 150;
            textBox.Height = 30;
            textBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
            textBox.CssClass = "cTextBox";
            return textBox;
        }

        /// <summary>
        /// Create Image
        /// </summary>
        /// <param name="s_Tooltip">Tooltip</param>
        /// <returns>Image</returns>
        private Image AddImage(string s_Tooltip)
        {
            using (Image image = new Image())
            {
                image.ImageUrl = "~/View/App_Themes/images/ViewHistory.png";
                image.ToolTip = s_Tooltip.Equals("&nbsp;") ? string.Empty : s_Tooltip;
                image.Attributes.Add("style", "cursor: pointer; cursor: hand;");
                return image;
            }
        }
        /// <summary>
        /// Bind valuation report parameters
        /// </summary>
        /// <param name="ucCompareGrants">page object</param>
        /// <param name="e">GridView Row Event Arguments</param>
        /// <param name="n_ValIndex">Index</param>
        /// <param name="n_ManuallyUploaded">Row index of ManuallyUploaded</param>
        /// <param name="n_GrantLevel"></param>
        /// <param name="n_CompanyLevel"></param>
        /// <param name="n_ParamID"></param>
        public void BindRowsValuationParam(CompareGrantsUC ucCompareGrants, GridViewRowEventArgs e, ref int n_ValIndex, ref int n_ManuallyUploaded, ref int n_GrantLevel, ref int n_CompanyLevel, ref int n_ParamID)
        {
            BulletedList bulletedList = new BulletedList();
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        e.Row.Height = Unit.Pixel(66);
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "IS MANUAL UPLOADED":
                                    n_ManuallyUploaded = n_ValIndex;
                                    perColumn.Visible = false;
                                    break;

                                case "PARAMETERS AT COMPANY LEVEL":
                                    n_CompanyLevel = n_ValIndex;
                                    break;

                                case "UPDATE GRANT LEVEL PARAMETERS":
                                    n_GrantLevel = n_ValIndex;
                                    break;

                                case "PARAMID":
                                    n_ParamID = n_ValIndex;
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_ValIndex = n_ValIndex + 1;
                        }
                        for (int i = 0; i < e.Row.Cells.Count; i++)
                        {
                            if ((i.Equals(e.Row.Cells.Count - 1) || i.Equals(e.Row.Cells.Count - 2)) && (e.Row.Cells[e.Row.Cells.Count - 2].Text.Equals("Comments") || e.Row.Cells[e.Row.Cells.Count - 1].Text.Equals("Comments History")))
                            {
                                e.Row.Cells[i].Visible = false;
                            }
                        }
                        if (ucCompareGrants.rdbParameters.Checked)
                        {
                            e.Row.Cells[6].Visible = false;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Height = Unit.Pixel(45);

                        if (ucCompareGrants.rdbParameters.Checked && e.Row.Cells.Count > 3)
                        {
                            e.Row.Height = Unit.Pixel(55);
                            if (e.Row.Cells.Count.Equals(7))
                            {
                                e.Row.Cells[0].Width = 155;
                                e.Row.Cells[1].Width = 230;
                                e.Row.Cells[2].Width = 230;
                                e.Row.Cells[5].Visible = false;
                                e.Row.Cells[6].Visible = false;
                                if (e.Row.RowIndex.Equals(2))
                                {
                                    e.Row.Cells[2].Controls.Add(BindRFIRCountryName(e.Row.Cells[0].Text.Split(' ')[0], e.Row.Cells[2].Text));
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(e.Row.Cells[4].Text) && !e.Row.Cells[4].Text.Equals("True") && ac_ValuationReport.b_IsEditEnabled)
                                    {
                                        e.Row.Cells[3].Controls.Add(CreateLinkButton(ucCompareGrants, "GrantLevel", e.Row.Cells[0].Text.Split(' ')[0]));
                                    }
                                }
                            }

                            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;

                            if ((e.Row.Cells[2].Text.Equals("&nbsp;") || string.IsNullOrEmpty(e.Row.Cells[2].Text)) && !e.Row.RowIndex.Equals(2))
                            {
                                e.Row.Cells[2].Text = "Same as company level";
                            }
                            else
                            {
                                if (e.Row.Cells[1].Text == e.Row.Cells[2].Text && !e.Row.RowIndex.Equals(2))
                                {
                                    e.Row.Cells[2].Text = "Same as company level";
                                }
                            }
                            if (!string.IsNullOrEmpty(e.Row.Cells[4].Text) && e.Row.Cells[4].Text.Equals("True"))
                            {
                                e.Row.Cells[2].Text = "Manually entered data";
                            }
                            e.Row.Cells[4].Visible = false;
                        }
                        else if (ucCompareGrants.rdbValue.Checked)
                        {
                            try
                            {
                                string s_roundingLimit = string.Empty;
                                using (DataTable DecimalLimitTable = CommonModel.GetRoundingLimit(adminProperties, userSessionInfo.ACC_CompanyName, adminCRUDProperties))
                                {
                                    for (int i = 0; i < e.Row.Cells.Count; i++)
                                    {
                                        try
                                        {
                                            s_roundingLimit = e.Row.Cells[0].Text.Contains("Intrinsic Value") ? "1" : e.Row.Cells[0].Text.Contains("Fair Value") ? "2" : e.Row.Cells[0].Text.Contains("Market Price") ? "3" : e.Row.Cells[0].Text.Contains("Exercise Price") ? "4" : e.Row.Cells[0].Text.Contains("Expected Life ") ? "5" : e.Row.Cells[0].Text.Contains("Volatility") ? "6" : e.Row.Cells[0].Text.Contains("Riskfree Rate") ? "7" : e.Row.Cells[0].Text.Contains("Dividend yield") ? "8" : "11";

                                            e.Row.Cells[i].Text = e.Row.Cells[i].Text;

                                            if (Convert.ToDouble(e.Row.Cells[i].Text) > 999)
                                            {

                                                e.Row.Cells[i].Text = CommonModel.ThousandFormating(CommonModel.GetRoundedValue(e.Row.Cells[i].Text, DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString()), DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                                e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Right;

                                            }
                                            else
                                                e.Row.Cells[i].Text = CommonModel.GetRoundedValue(e.Row.Cells[i].Text, DecimalLimitTable.Select("ADVSID = '" + s_roundingLimit + "'")[0]["ROUNDING_PLACE_VALUE"].ToString());
                                            e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Right;
                                        }
                                        catch (Exception)
                                        {
                                            // Do nothing
                                        }
                                    }
                                }
                            }
                            catch
                            {
                                throw;
                            }

                            for (int i = 0; i < e.Row.Cells.Count; i++)
                            {
                                e.Row.Cells[i].Width = i.Equals(0) ? 150 : 75;
                            }

                            for (int i = 0; i < e.Row.Cells.Count; i++)
                            {
                                if ((i.Equals(e.Row.Cells.Count - 1) || i.Equals(e.Row.Cells.Count - 2)) && (e.Row.Cells[e.Row.Cells.Count - 2].Text.Equals("&nbsp;") || e.Row.Cells[e.Row.Cells.Count - 1].Text.Equals("&nbsp;")))
                                {
                                    e.Row.Cells[i].Visible = false;
                                }
                            }
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to create link button
        /// </summary>
        /// <param name="ucCompareGrants">Page object</param>
        /// <param name="s_Parameters">parameter to select</param>
        /// <param name="s_ValueName"></param>
        /// <returns>LinkButton</returns>
        public LinkButton CreateLinkButton(CompareGrantsUC ucCompareGrants, string s_Parameters, string s_ValueName)
        {
            CompareGrantsUCModel compareGrantsUCModel = new CompareGrantsUCModel();
            string s_GrantDate = ac_ValuationReport.dt_all_Grants.Select("[Grant Registration ID] = '" + compareGrantsUCModel.ac_ValuationReport.s_GrantRegID + "'")[0]["Grant Date"].ToString();
            LinkButton linkButton = new LinkButton();
            linkButton.ToolTip = "Click here to edit";
            linkButton.Text = "Edit";
            linkButton.ID = s_ValueName + "~" + compareGrantsUCModel.ac_ValuationReport.s_GrantRegID + "~" + s_GrantDate;
            linkButton.ClientIDMode = System.Web.UI.ClientIDMode.Static;

            switch (s_Parameters)
            {
                case "GrantLevel":
                    linkButton.Attributes.Add("onclick", "return ShowSelectedSection(this)");
                    linkButton.Click += new EventHandler(ucCompareGrants.lbtnUPGrantLevelParam_Click);
                    break;
            }

            return linkButton;
        }

        /// <summary>
        /// This method is used bind RFIR country
        /// </summary>
        /// <returns>DropDown control</returns>
        private DropDownList BindRFIRCountryName(string s_ValueName, string s_CountryName)
        {
            using (DropDownList ddlRFIRCounrtyNames = new DropDownList())
            {
                ddlRFIRCounrtyNames.ID = "ddl_comp_" + s_ValueName + "|" + ac_ValuationReport.s_GrantRegID;
                ddlRFIRCounrtyNames.DataSource = ac_ValuationReport.dt_CountryNames;
                ddlRFIRCounrtyNames.DataTextField = "Country Name";
                ddlRFIRCounrtyNames.DataValueField = "ID";
                ddlRFIRCounrtyNames.DataBind();
                if (!string.IsNullOrEmpty(s_CountryName) && !s_CountryName.Equals("&nbsp;"))
                {
                    ddlRFIRCounrtyNames.SelectedIndex = ddlRFIRCounrtyNames.Items.IndexOf(ddlRFIRCounrtyNames.Items.FindByText(s_CountryName));
                }
                return ddlRFIRCounrtyNames;
            }
        }

        #region assign TextBox values in from dynamically created GridView to DataTable
        /// <summary>
        /// This method is used to assign TextBox values in from dynamically created GridView to DataTable
        /// </summary>
        /// <param name="nameValueCollection"></param>
        /// <param name="ucCompareGrants"></param>
        internal void AssignValuesFromTextbox(System.Collections.Specialized.NameValueCollection nameValueCollection, CompareGrantsUC ucCompareGrants)
        {
            if (ucCompareGrants.rdbValue.Checked || ucCompareGrants.rdbParameters.Checked)
            {
                foreach (var item in nameValueCollection.AllKeys)
                {
                    if (item != null && Convert.ToString(item).Contains("txt_comp"))
                    {
                        //e.g.: TextBox control name = ctl00$MainContent$CompareGrants$comp_pt3$ctl84$txt_comp_pt3_0
                        int s_RowNumber = Convert.ToInt32(Convert.ToString(item).Split('$').Last().Split('|').Last());
                        if (Convert.ToString(item).Contains("IntrinsicValue_Values"))
                        {
                            ac_ValuationReport.ds_CalculationDetails_IntrinsicValue.Tables[Convert.ToString(item).Split('$').Last().Split('|')[1]].Rows[s_RowNumber]["Comments"] = nameValueCollection[item];
                        }
                        else if (Convert.ToString(item).Contains("Values_"))
                        {
                            ac_ValuationReport.ds_CalculationDetails.Tables[Convert.ToString(item).Split('$').Last().Split('|')[1]].Rows[s_RowNumber]["Comments"] = nameValueCollection[item];
                        }
                        if (Convert.ToString(item).Contains("IntriValue_Parameters"))
                        {
                            ac_ValuationReport.ds_SelectedDT_IntrinsicValue.Tables[Convert.ToString(item).Split('$').Last().Split('|')[1]].Rows[s_RowNumber]["Comments"] = nameValueCollection[item];
                        }
                        else if (Convert.ToString(item).Contains("Parameters_"))
                        {
                            ac_ValuationReport.ds_SelectedDataTables.Tables[Convert.ToString(item).Split('$').Last().Split('|')[1]].Rows[s_RowNumber]["Comments"] = nameValueCollection[item];
                        }
                    }


                    #region Add RFIR country name to selected grants DataTables
                    if (item != null && Convert.ToString(item).Contains("ddl_comp"))
                    {
                        string s_CountryName = Convert.ToString(ac_ValuationReport.dt_CountryNames.Select("ID = " + nameValueCollection[item] + "")[0]["Country Name"]);

                        string s_GrantID = Convert.ToString(Convert.ToString(item).Split('$').Last().Split('|').Last());

                        ac_ValuationReport.ds_SelectedDataTables.Tables[s_GrantID].Rows[2]["ParamID"] = !Convert.ToString(ac_ValuationReport.ds_SelectedDataTables.Tables[s_GrantID].Rows[2]["Parameters at Company Level"]).Equals(s_CountryName) ?
                                                                                                        nameValueCollection[item] : string.Empty;


                    }
                    #endregion
                }
            }
        }
        #endregion

        #region Save grant level parameters
        /// <summary>
        /// This method is used to save Grant Level parameters
        /// </summary>
        internal void SaveGrantLevelPrameters()
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                valuationProperties.PageName = CommonConstantModel.s_ValuationParameters;
                valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);

                foreach (DataTable perDataTable in ac_ValuationReport.ds_SelectedDataTables.Tables)
                {
                    bool Is_GrantLevelPrams = false;

                    #region Market Price
                    foreach (string s_ArrayItem in Convert.ToString(perDataTable.Rows[0]["ParamID"]).Split(','))
                    {
                        if (string.IsNullOrEmpty(s_ArrayItem))
                        {
                            using (DataTable dt_CompanyLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table2"].Select("COMP_GRANT_REG_ID_FV = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table2"].Select("COMP_GRANT_REG_ID_FV = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                            {
                                using (DataTable dt_GrantLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table3"].Select("GRANT_GRANT_REG_ID_FV = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table3"].Select("GRANT_GRANT_REG_ID_FV = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                                {
                                    if (dt_GrantLevelParameters == null && dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                                    {
                                        valuationProperties.STOCK_EX_LABEL_ID_FV = Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_FV"]).Trim();
                                        valuationProperties.SEID_FV = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_FV"])) ? 0 : Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_FV"]).Trim().Equals("NSE") ? 1 : Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_FV"]).Trim().Equals("BSE") ? 2 : 0;
                                        valuationProperties.MARKET_PRICE_DT_LABEL_ID_FV = Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_FV"]).Trim();
                                    }
                                    else
                                    {
                                        valuationProperties.STOCK_EX_LABEL_ID_FV = Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_FV"]).Trim();
                                        valuationProperties.SEID_FV = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EXCHANGE_FV"])) ? 0 : Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EXCHANGE_FV"]).Trim().Equals("NSE") ? 1 : Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EXCHANGE_FV"]).Trim().Equals("BSE") ? 2 : 0;
                                        valuationProperties.MARKET_PRICE_DT_LABEL_ID_FV = Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MARKET_PRICE_LABEL_ID_FV"]).Trim();
                                    }
                                }
                            }
                            using (DataTable dt_CompanyLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table"].Select("COMP_GRANT_REG_ID_IV = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table"].Select("COMP_GRANT_REG_ID_IV = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                            {
                                using (DataTable dt_GrantLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table1"].Select("GRANT_GRANT_REG_ID_IV = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table1"].Select("GRANT_GRANT_REG_ID_IV = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                                {
                                    if (dt_GrantLevelParameters == null && dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                                    {
                                        valuationProperties.STOCK_EX_LABEL_ID_IV = Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_IV"]).Trim();
                                        valuationProperties.SEID_IV = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_IV"])) ? 0 : Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_IV"]).Trim().Equals("NSE") ? 1 : Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_IV"]).Trim().Equals("BSE") ? 2 : 0;
                                        valuationProperties.MARKET_PRICE_DT_LABEL_ID_IV = Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_IV"]).Trim();
                                    }
                                    else
                                    {
                                        valuationProperties.STOCK_EX_LABEL_ID_IV = Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EX_LABEL_ID_IV"]).Trim();
                                        valuationProperties.SEID_IV = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EXCHANGE_IV"])) ? 0 : Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EXCHANGE_IV"]).Trim().Equals("NSE") ? 1 : Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_STOCK_EXCHANGE_IV"]).Trim().Equals("BSE") ? 2 : 0;
                                        valuationProperties.MARKET_PRICE_DT_LABEL_ID_IV = Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MARKET_PRICE_LABEL_ID_IV"]).Trim();
                                    }
                                }
                            }
                        }
                        else
                        {
                            Is_GrantLevelPrams = true;
                            using (DataTable dt_CompanyLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table"].Select("COMP_GRANT_REG_ID_IV = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table"].Select("COMP_GRANT_REG_ID_IV = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                            {
                                valuationProperties.STOCK_EX_LABEL_ID_IV = Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EX_LABEL_ID_IV"]).Trim();
                                valuationProperties.SEID_IV = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_IV"])) ? 0 : Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_IV"]).Trim().Equals("NSE") ? 1 : Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_STOCK_EXCHANGE_IV"]).Trim().Equals("BSE") ? 2 : 0;
                                valuationProperties.MARKET_PRICE_DT_LABEL_ID_IV = Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MARKET_PRICE_LABEL_ID_IV"]).Trim();
                            }

                            switch (s_ArrayItem.Trim())
                            {
                                case "lblFVSE01":
                                case "lblFVSE02":
                                    valuationProperties.STOCK_EX_LABEL_ID_FV = s_ArrayItem;
                                    valuationProperties.SEID_FV = s_ArrayItem.Equals("lblFVSE01") ? Convert.ToInt32(Convert.ToString(perDataTable.Rows[0]["ParamID"]).Split(',')[1]) : 0;
                                    break;

                                case "lblFVDMP01":
                                case "lblFVDMP02":
                                    valuationProperties.MARKET_PRICE_DT_LABEL_ID_FV = s_ArrayItem.Trim();
                                    break;
                            }
                        }
                    }
                    #endregion

                    #region Expected Life
                    foreach (string s_ArrayItem in Convert.ToString(perDataTable.Rows[1]["ParamID"]).Split(','))
                    {
                        if (string.IsNullOrEmpty(s_ArrayItem))
                        {
                            using (DataTable dt_CompanyLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table4"].Select("COMP_GRANT_REG_ID = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table4"].Select("COMP_GRANT_REG_ID = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                            {
                                using (DataTable dt_GrantLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table5"].Select("GRANT_GRANT_REG_ID = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table5"].Select("GRANT_GRANT_REG_ID = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                                {
                                    if (dt_GrantLevelParameters == null && dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                                    {
                                        valuationProperties.CAL_METHOD_LABEL_ID_EL = dt_CompanyLevelParameters.Rows[0]["COMP_CAL_EXPECTED_LIFE"].ToString().Trim();
                                        valuationProperties.CONSIDER_PERIOD_IN_EL = dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_PERIOD_IN"].ToString().Trim();
                                        valuationProperties.CONSIDER_VALUE_EL = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"])) ? 0 : Convert.ToDecimal(dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"]);
                                    }
                                    else
                                    {
                                        valuationProperties.CAL_METHOD_LABEL_ID_EL = dt_GrantLevelParameters.Rows[0]["GRANT_CAL_EXPECTED_LIFE"].ToString().Trim();
                                        valuationProperties.CONSIDER_PERIOD_IN_EL = dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_PERIOD_IN"].ToString().Trim();
                                        valuationProperties.CONSIDER_VALUE_EL = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"])) ? 0 : Convert.ToDecimal(dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"]);
                                    }
                                }
                            }
                        }
                        else
                        {
                            Is_GrantLevelPrams = true;
                            switch (s_ArrayItem.Trim())
                            {
                                case "lblMCEL01":
                                case "lblMCEL02":
                                case "lblMCEL03":
                                    valuationProperties.CAL_METHOD_LABEL_ID_EL = s_ArrayItem.Trim();
                                    valuationProperties.CONSIDER_PERIOD_IN_EL = s_ArrayItem.Trim().Equals("lblMCEL02") || s_ArrayItem.Trim().Equals("lblMCEL03") ? Convert.ToString(perDataTable.Rows[1]["ParamID"]).Split(',')[1].Trim() : string.Empty;
                                    valuationProperties.CONSIDER_VALUE_EL = s_ArrayItem.Trim().Equals("lblMCEL02") || s_ArrayItem.Trim().Equals("lblMCEL03") ? Convert.ToDecimal(Convert.ToString(perDataTable.Rows[1]["ParamID"]).Split(',')[2].Trim()) : 0;
                                    break;
                            }
                        }

                    }
                    #endregion

                    #region Volatility
                    foreach (string s_ArrayItem in Convert.ToString(perDataTable.Rows[3]["ParamID"]).Split(','))
                    {
                        if (string.IsNullOrEmpty(s_ArrayItem))
                        {
                            using (DataTable dt_CompanyLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table6"].Select("COMP_GRANT_REG_ID = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table6"].Select("COMP_GRANT_REG_ID = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                            {
                                using (DataTable dt_GrantLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table7"].Select("GRANT_GRANT_REG_ID = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table7"].Select("GRANT_GRANT_REG_ID = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                                {
                                    if (dt_GrantLevelParameters == null && dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                                    {
                                        valuationProperties.VOLATILITY_OF_LABEL_ID_VC = Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_VOL_OF_LABEL_ID"]);
                                        valuationProperties.MP_CALC_VOLATILITY_LABEL_ID_VC = dt_CompanyLevelParameters.Rows[0]["COMP_MP_CALC_VOLATILITY"].ToString().Trim();
                                        valuationProperties.TRADING_DAYS_LABEL_ID_VC = dt_CompanyLevelParameters.Rows[0]["COMP_TRADING_DAYS_LABEL"].ToString().Trim();
                                        valuationProperties.TRADING_DAYS_VC = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_TRADING_DAYS"])) ? 0 : Convert.ToDecimal(dt_CompanyLevelParameters.Rows[0]["COMP_TRADING_DAYS"]);
                                        valuationProperties.PRD_CALC_VOLATILITY_LABEL_ID_VC = dt_CompanyLevelParameters.Rows[0]["COMP_PRD_CALC_VOL_LABEL"].ToString().Trim();
                                        valuationProperties.CONSIDER_PERIOD_IN_VC = dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_PERIOD_IN"].ToString().Trim();
                                        valuationProperties.CONSIDER_VALUE_VC = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"])) ? 0 : Convert.ToInt32(dt_CompanyLevelParameters.Rows[0]["COMP_CONSIDER_VALUE"]);
                                        valuationProperties.SEID_VC = string.IsNullOrEmpty(dt_CompanyLevelParameters.Rows[0]["SHORT_NAME"].ToString()) ? 1 : dt_CompanyLevelParameters.Rows[0]["SHORT_NAME"].ToString().Equals("NSE") ? 1 : 2;
                                    }
                                    else
                                    {
                                        valuationProperties.VOLATILITY_OF_LABEL_ID_VC = Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_VOL_OF_LABEL_ID"]);
                                        valuationProperties.MP_CALC_VOLATILITY_LABEL_ID_VC = dt_GrantLevelParameters.Rows[0]["GRANT_MP_CALC_VOLATILITY"].ToString().Trim();
                                        valuationProperties.TRADING_DAYS_LABEL_ID_VC = dt_GrantLevelParameters.Rows[0]["GRANT_TRADING_DAYS_LABEL"].ToString().Trim();
                                        valuationProperties.TRADING_DAYS_VC = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_TRADING_DAYS"])) ? 0 : Convert.ToDecimal(dt_GrantLevelParameters.Rows[0]["GRANT_TRADING_DAYS"]);
                                        valuationProperties.PRD_CALC_VOLATILITY_LABEL_ID_VC = dt_GrantLevelParameters.Rows[0]["GRANT_PRD_CALC_VOL_LABEL"].ToString().Trim();
                                        valuationProperties.CONSIDER_PERIOD_IN_VC = dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_PERIOD_IN"].ToString().Trim();
                                        valuationProperties.CONSIDER_VALUE_VC = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"])) ? 0 : Convert.ToInt32(dt_GrantLevelParameters.Rows[0]["GRANT_CONSIDER_VALUE"]);
                                        valuationProperties.SEID_VC = string.IsNullOrEmpty(dt_GrantLevelParameters.Rows[0]["SHORT_NAME"].ToString()) ? 1 : dt_GrantLevelParameters.Rows[0]["SHORT_NAME"].ToString().Equals("NSE") ? 1 : 2;
                                    }
                                }
                            }
                        }
                        else
                        {
                            Is_GrantLevelPrams = true;
                            switch (s_ArrayItem.Trim())
                            {
                                case "lblVOL01":
                                case "lblVOL02":
                                    valuationProperties.VOLATILITY_OF_LABEL_ID_VC = s_ArrayItem.Trim();
                                    valuationProperties.SEID_VC = s_ArrayItem.Trim().Equals("lblVOL01") ? Convert.ToInt32(Convert.ToString(perDataTable.Rows[3]["ParamID"]).Split(',')[1].Trim()) : 0;
                                    break;

                                case "lblMPTCV01":
                                    valuationProperties.MP_CALC_VOLATILITY_LABEL_ID_VC = s_ArrayItem.Trim();
                                    valuationProperties.TRADING_DAYS_LABEL_ID_VC = Convert.ToString(perDataTable.Rows[3]["ParamID"]).Split(',')[3].Trim();
                                    valuationProperties.TRADING_DAYS_VC = Convert.ToString(perDataTable.Rows[3]["ParamID"]).Split(',')[3].Trim().Equals("lblTDD03") ? Convert.ToDecimal(Convert.ToString(perDataTable.Rows[3]["ParamID"]).Split(',')[4]) : 0;
                                    break;

                                case "lblPTCV01":
                                case "lblPTCV02":
                                case "lblPTCV03":
                                    valuationProperties.PRD_CALC_VOLATILITY_LABEL_ID_VC = s_ArrayItem.Trim();
                                    valuationProperties.CONSIDER_PERIOD_IN_VC = s_ArrayItem.Trim().Equals("lblPTCV03") ? Convert.ToString(perDataTable.Rows[3]["ParamID"]).Split(',')[5].Trim() : string.Empty;
                                    valuationProperties.CONSIDER_VALUE_VC = s_ArrayItem.Trim().Equals("lblPTCV03") ? Convert.ToInt32(Convert.ToString(perDataTable.Rows[3]["ParamID"]).Split(',')[6].Trim()) : 0;
                                    break;
                            }
                        }
                    }
                    #endregion

                    #region Dividend
                    foreach (string s_ArrayItem in Convert.ToString(perDataTable.Rows[4]["ParamID"]).Split(','))
                    {
                        if (string.IsNullOrEmpty(s_ArrayItem))
                        {
                            using (DataTable dt_CompanyLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table8"].Select("COMP_GRANT_REG_ID = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table8"].Select("COMP_GRANT_REG_ID = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                            {
                                using (DataTable dt_GrantLevelParameters = valuationCRUDProperties.ds_Result.Tables["Table9"].Select("GRANT_GRANT_REG_ID = '" + perDataTable.TableName + "'").Count() > 0 ? valuationCRUDProperties.ds_Result.Tables["Table9"].Select("GRANT_GRANT_REG_ID = '" + perDataTable.TableName + "'").CopyToDataTable() : null)
                                {
                                    if (dt_GrantLevelParameters == null && dt_CompanyLevelParameters != null && dt_CompanyLevelParameters.Rows.Count > 0)
                                    {
                                        valuationProperties.DIVIDEND_LABEL_ID_DC = dt_CompanyLevelParameters.Rows[0]["COMP_DIVIDEND_LABEL_ID"].ToString().Trim();
                                        valuationProperties.NO_OF_YEARS_DC = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_NO_OF_YEARS"].ToString().Trim())) ? 0 : Convert.ToInt32(dt_CompanyLevelParameters.Rows[0]["COMP_NO_OF_YEARS"]);
                                        valuationProperties.SPECIAL_DIVIDEND_DC = string.IsNullOrEmpty(Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_SPECIAL_DIVIDEND"])) ? 0 : Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_SPECIAL_DIVIDEND"]).Equals("1") ? 1 : 0;
                                        valuationProperties.MP_TO_CAL_DIVIDEND_LABEL_ID_DC = Convert.ToString(dt_CompanyLevelParameters.Rows[0]["COMP_MP_TO_CAL_DIVIDEND"]);
                                    }
                                    else
                                    {
                                        valuationProperties.DIVIDEND_LABEL_ID_DC = dt_GrantLevelParameters.Rows[0]["GRANT_DIVIDEND_LABEL_ID"].ToString().Trim();
                                        valuationProperties.NO_OF_YEARS_DC = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_NO_OF_YEARS"].ToString().Trim())) ? 0 : Convert.ToInt32(dt_GrantLevelParameters.Rows[0]["GRANT_NO_OF_YEARS"]);
                                        valuationProperties.SPECIAL_DIVIDEND_DC = string.IsNullOrEmpty(Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_SPECIAL_DIVIDEND"])) ? 0 : Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_SPECIAL_DIVIDEND"]).Equals("1") ? 1 : 0;
                                        valuationProperties.MP_TO_CAL_DIVIDEND_LABEL_ID_DC = Convert.ToString(dt_GrantLevelParameters.Rows[0]["GRANT_MP_TO_CAL_DIVIDEND"]);
                                    }
                                }
                            }
                        }
                        else
                        {
                            Is_GrantLevelPrams = true;
                            switch (s_ArrayItem.Trim())
                            {
                                case "lblDIV01":
                                case "lblDIV02":
                                case "lblDIV03":
                                case "lblDIV04":
                                    valuationProperties.DIVIDEND_LABEL_ID_DC = s_ArrayItem.Trim();
                                    valuationProperties.NO_OF_YEARS_DC = s_ArrayItem.Trim().Equals("lblDIV03") ? Convert.ToInt32(Convert.ToString(perDataTable.Rows[4]["ParamID"]).Split(',')[1].Trim()) : 0;
                                    break;

                                case "SpecialDividend":
                                    valuationProperties.SPECIAL_DIVIDEND_DC = s_ArrayItem.Trim().Equals("lblDIV03") ? Convert.ToInt32(Convert.ToString(perDataTable.Rows[4]["ParamID"]).Split(',')[3].Trim()) : 0;
                                    break;

                                case "lblMPTCD01":
                                case "lblMPTCD02":
                                    valuationProperties.MP_TO_CAL_DIVIDEND_LABEL_ID_DC = s_ArrayItem.Trim();
                                    valuationProperties.SEID_DC = s_ArrayItem.Trim().Equals("lblMPTCD02") ? Convert.ToInt32(Convert.ToString(perDataTable.Rows[4]["ParamID"]).Split(',')[4].Trim()) : 0;
                                    break;
                            }
                        }

                    }
                    #endregion

                    #region RFIR
                    if (!string.IsNullOrEmpty(Convert.ToString(perDataTable.Rows[2]["ParamID"])))
                    {
                        Is_GrantLevelPrams = true;
                        valuationProperties.CMID = Convert.ToInt32(perDataTable.Rows[2]["ParamID"]);
                    }
                    else
                    {
                        valuationProperties.CMID = Convert.ToInt32(ac_ValuationReport.dt_CountryNames.Rows.Cast<System.Data.DataRow>().Take(1).First()["ID"]);
                    }
                    #endregion

                    if (Is_GrantLevelPrams)
                    {
                        valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        valuationProperties.AGRMID = ac_ValuationReport.dt_all_Grants.Select("[Grant Registration ID] = '" + perDataTable.TableName + "'")[0]["AGRMID"].ToString();

                        valuationProperties.PageName = "GRANTDETAILS";
                        valuationProperties.Operation = "CUD";
                        valuationProperties.PopulateControls = "GrantLevelSettings";


                        valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    }
                }

            }

        }
        #endregion

        #region Destructor
        /// <summary>
        /// Destructor for ValuationReportModel.
        /// </summary>
        ~CompareGrantsUCModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members

        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// Dispose method for ValuationReportModel
        /// </summary>
        /// <param name="disposing">dispose status</param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}