﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation.UserControl_Model;
using EDFinancials.View.User.Valuation.UserControl;
using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// 
    /// </summary>
    public class ReviewerFeedbackModelUC : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public ReviewerFeedbackModelUC()
        {
            if(ac_ValuationReport == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ValuationReport);
                ac_ValuationReport = (CommonModel.AC_ValuationReport)HttpContext.Current.Session[CommonConstantModel.s_AC_ValuationReport];
            }
        }

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="reviewerFeedback">reviewerFeedback page object</param>
        internal void ReadL10N_UI(ReviewerFeedback reviewerFeedback)
        {
            try
            {
                if((ac_ValuationReport.dt_Valuation_Report_UI_Text != null) && (ac_ValuationReport.dt_Valuation_Report_UI_Text.Rows.Count > 0))
                {
                    reviewerFeedback.lblReportStatus.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblReportStatus'"))[0]["LabelName"]);
                    reviewerFeedback.lblReportStatus.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblReportStatus'"))[0]["LabelToolTip"]);

                    reviewerFeedback.lblReviewerFeedback.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblReviewerComments'"))[0]["LabelName"]);
                    reviewerFeedback.lblReviewerFeedback.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'lblReviewerComments'"))[0]["LabelToolTip"]);

                    reviewerFeedback.btnSaveContinue.Text = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSaveContinue'"))[0]["LabelName"]);
                    reviewerFeedback.btnSaveContinue.ToolTip = Convert.ToString((ac_ValuationReport.dt_Valuation_Report_UI_Text.Select("LabelID = 'btnSaveContinue'"))[0]["LabelToolTip"]);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Dropdown for Country Status
        /// </summary>
        /// <param name="reviewerFeedback">Page object</param>
        internal void BindStatus(ReviewerFeedback reviewerFeedback)
        {
            using(DataTable dataTable = new DataTable())
            {
                dataTable.Columns.Add("STATUS_ID", typeof(string));
                dataTable.Columns.Add("STATUS", typeof(string));

                DataRow dataRow = null;
                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "1";
                dataRow["STATUS"] = "Approve";
                dataTable.Rows.Add(dataRow);

                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "2";
                dataRow["STATUS"] = "Disapprove";
                dataTable.Rows.Add(dataRow);

                reviewerFeedback.ddlStatus.DataSource = dataTable;
                reviewerFeedback.ddlStatus.DataTextField = "STATUS";
                reviewerFeedback.ddlStatus.DataValueField = "STATUS_ID";
                reviewerFeedback.ddlStatus.DataBind();

                reviewerFeedback.ddlStatus.Items.Insert(0, "--- Please Select ---");
            }
        }

        /// <summary>
        /// This method is used to save comments
        /// </summary>
        /// <param name="reviewerFeedback"></param>
        /// <param name="s_Action"></param>
        public void SaveContinue(ReviewerFeedback reviewerFeedback, string s_Action)
        {
            string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];
            bool b_GrantID = false;
            string temp_GrantRegId = string.Empty;

            foreach(var item in ac_ValuationReport.s_SelectedGrants.TrimStart(',').Split(','))
            {
                if(!string.IsNullOrEmpty(item))
                {
                    temp_GrantRegId = string.IsNullOrEmpty(temp_GrantRegId) ? "REG_ID = '" + ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Grant Registration ID"].ToString() + "'" : temp_GrantRegId + " OR REG_ID = '" + ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + item + "'")[0]["Grant Registration ID"].ToString() + "'";
                }
            }

            using(ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                b_GrantID = CheckParamApproval(b_GrantID, temp_GrantRegId, valuationServiceClient);

                if(!b_GrantID || !reviewerFeedback.ddlStatus.SelectedItem.Text.Equals("Approve"))
                {
                    valuationProperties.Operation = s_Action.Equals("Create") ? CommonConstantModel.s_OperationCUD : CommonConstantModel.s_OperationRead;
                    valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.Action = s_Action.Equals("Create") ? "C" : "V";
                    valuationProperties.AGRMID = string.Empty;
                    valuationProperties.Step = "SAVE_STEP_NUMBER_OR_COMMENT";
                    valuationProperties.Step_Number = reviewerFeedback.ddlStatus.SelectedItem.Text.Equals("Approve") ? "5" : "3";
                    valuationProperties.DownloadRepWorkUsrComment = reviewerFeedback.txtReviewerComments.Text;
                    // 2 : Reviewer Comments
                    valuationProperties.DownloadRepWorkIsUsrRev = 2;
                    valuationProperties.Is_Send_For_Review = null;
                    valuationProperties.Is_Reviewed = reviewerFeedback.ddlStatus.SelectedItem.Text.Equals("Approve");
                    valuationProperties.Group_Id = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"].ToString();
                    valuationProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
                    using(gvUserControlModel _gvUserControlModel = new gvUserControlModel())
                    {
                        _gvUserControlModel.ac_SearchGrantDetails.s_StepNumber = reviewerFeedback.ddlStatus.SelectedItem.Text.Equals("Approve") ? "5" : "3";
                    }

                    //Send mail
                    SendMail(reviewerFeedback.ddlStatus.SelectedItem.Text.Equals("Approve") ? "ApproveReport" : "DisapprovedReport");
                    reviewerFeedback.txtReviewerComments.Text = string.Empty;

                }
                else
                {
                    ScriptManager.RegisterStartupScript(reviewerFeedback, GetType(), "alertMessage", "alert('" + valuationServiceClient.GetValuation_L10N("lblDisApprovParam", CommonConstantModel.s_ValuationReport, CommonConstantModel.s_ValuationL10) + "')", true);
                }
            }
        }

        /// <summary>
        /// Approve details
        /// </summary>
        /// <param name="b_GrantID">GrantID</param>
        /// <param name="temp_GrantRegId">temp_GrantRegId</param>
        /// <param name="valuationServiceClient">valuationServiceClient</param>
        /// <returns>bool</returns>
        private bool CheckParamApproval(bool b_GrantID, string temp_GrantRegId, ValuationServiceClient valuationServiceClient)
        {
            valuationProperties.Operation = CommonConstantModel.s_OperationRead;
            valuationProperties.PageName = CommonConstantModel.s_ApproveStatus;
            valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
            valuationCRUDProperties = valuationServiceClient.CRUDValuationOperations(valuationProperties);
            foreach(string s_TempGrantID in temp_GrantRegId.Split(','))
            {
                foreach(DataTable dataTable in valuationCRUDProperties.ds_Result.Tables)
                {
                    foreach(DataRow perRow in dataTable.Select("IS_APPROVED = 0 AND " + s_TempGrantID + ""))
                    {
                        b_GrantID = true;
                    }
                }
            }
            return b_GrantID;
        }

        /// <summary>
        /// This method is used to trigger a mail to the reviewer/user
        /// </summary>
        /// <param name="s_TemplateName">Template name</param>
        public void SendMail(string s_TemplateName)
        {
            try
            {
                string s_GrantRegMasterID = ac_ValuationReport.s_SelectedGrants.Split(',').Length > 1 ? ac_ValuationReport.s_SelectedGrants.Split(',')[1] : ac_ValuationReport.s_SelectedGrants.Split(',')[0];

                using(ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using(GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.Operation = "GETUSERMAILSIDS";
                        valuationProperties.PageName = CommonConstantModel.s_CommentDetails;
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        valuationProperties.Group_Id = ac_ValuationReport.dt_temp_Unlocked_Valuation_Report.Select("AGRMID = '" + s_GrantRegMasterID + "'")[0]["Group Number"].ToString();

                        using(System.Data.DataTable dt_ReviewerDetails = valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result)
                        {
                            if(dt_ReviewerDetails != null && dt_ReviewerDetails.Rows.Count > 0)
                            {
                                string s_MailBody = MailBody(s_TemplateName);
                                emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                                emailProperties.b_IsBodyHtml = true;
                                emailProperties.s_MailBody = s_MailBody;
                                emailProperties.s_MailTo = string.Join(",", dt_ReviewerDetails.AsEnumerable().SelectMany(r => r.Field<string>("EMAIL_ID").Split(',')).ToArray());
                                emailProperties.s_MailCC = "";
                                emailProperties.s_MailBCC = "";
                                emailProperties.s_MailSubject = Regex.Match(s_MailBody.ToString(), @"<Title>\s*(.+?)\s*</Title>").Value.
                                                                Replace("\r", "").Replace("<Title>", "").Replace("</Title>", "").Replace("\n", "").Replace("\t", "");
                                genericServiceClient.SaveSendMail(emailProperties);
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to replace parameters from template
        /// </summary>
        /// <param name="s_TemplateName">Template name</param>
        private string MailBody(string s_TemplateName)
        {
            StringBuilder s_MailBody = new StringBuilder();
            s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\" + s_TemplateName + ".html"));
            s_MailBody.Replace("<<NAME OF COMPANY>>", userSessionInfo.ACC_CompanyName);
            s_MailBody.Replace("@ValCustSupportID", ConfigurationManager.AppSettings["ValCustSupport"]);
            s_MailBody.Replace("@Link", ConfigurationManager.AppSettings["SiteURL"]);
            return s_MailBody.ToString();
        }
        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ReviewerFeedbackModelUC()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}