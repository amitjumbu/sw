﻿using EDFinancials.Model.Generic;
using EDFinancials.View.User.Valuation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.User.Valuation
{
    /// <summary>
    /// Model file Page for peer company page.
    /// </summary>
    public class PeerCompanyModel : BaseModel, IDisposable
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public PeerCompanyModel()
        {
            if (ac_DividendSetUp == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_PeerCompanySetup);
                ac_PeerCompanySetup = (CommonModel.AC_PeerCompanySetup)HttpContext.Current.Session[CommonConstantModel.s_AC_PeerCompanySetup];
            }
        }

        /// <summary>
        /// 
        /// </summary>
        List<string> contentList = new List<string>();

        /// <summary>
        /// 
        /// </summary>
        List<string> columnList = new List<string>();

        /// <summary>
        /// This string has the Messege as well as list of companies whose stock code are invalid.
        /// </summary>
        public static string s_InvalidStockCodeList = string.Empty;

        /// <summary>
        /// Enables or disables control according to roles assigned to user.
        /// </summary>
        /// <param name="peerCompanySetUp">peercompany page</param>
        internal void CheckEmployeeRolePriviledges(PeerCompanySetUp peerCompanySetUp)
        {
            try
            {
                genericProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                genericProperties.PageName = CommonConstantModel.s_MnuPeerCompanySetup;
                genericProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (DataTable dt_RolePerviledges = CommonModel.GetEmployeeRolePriviledges(genericProperties))
                {
                    if (dt_RolePerviledges != null && dt_RolePerviledges.Rows.Count > 0)
                    {
                        foreach (DataRow rowPriviledge in dt_RolePerviledges.Rows)
                        {
                            switch (Convert.ToString(rowPriviledge["PRIVILEDGES"]))
                            {
                                case "VIEW":
                                    peerCompanySetUp.btnPeerAdd.Attributes.Add("disabled", "");
                                    peerCompanySetUp.btnNavigateToMarketPrice.Attributes.Add("disabled", "");
                                    peerCompanySetUp.btnPeerSave.Enabled = false;
                                    peerCompanySetUp.btnPeerDelete.Enabled = false;
                                    break;

                                case "ADD":
                                    peerCompanySetUp.btnPeerAdd.Attributes.Remove("disabled");
                                    peerCompanySetUp.btnNavigateToMarketPrice.Attributes.Remove("disabled");
                                    peerCompanySetUp.btnPeerSave.Enabled = true;
                                    break;

                                case "EDIT":
                                    peerCompanySetUp.btnPeerSave.Enabled = true;
                                    break;

                                case "DELETE":
                                    peerCompanySetUp.btnPeerDelete.Enabled = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to fetch messages from L10N xml via superadmin WCF service.
        /// </summary>
        /// <param name="MessegeId"></param>
        /// <returns>string as the message</returns>
        public string Val_L10N(string MessegeId)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    return valuationServiceClient.GetValuation_L10N(MessegeId, CommonConstantModel.s_PeerCompanySetup, CommonConstantModel.s_ValuationL10);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to load all label text from L10N_UI via wcf service
        /// </summary>
        /// <param name="peerCompanySetUp">The manage user page of aspx.cs side</param>
        public void BindPageUI(PeerCompanySetUp peerCompanySetUp)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    using (ac_PeerCompanySetup.dt_PeerCompanyUI = valuationServiceClient.GetValuation_L10N_UI(CommonConstantModel.s_PeerCompanySetup, CommonConstantModel.s_ValuationL10_UI))
                    {
                        peerCompanySetUp.lblPeerPagehead.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerPagehead'"))[0]["LabelName"]);
                        peerCompanySetUp.lblPeerSearchAccord.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerSearchAccord'"))[0]["LabelName"]);
                        peerCompanySetUp.lblPeerSearchAccord.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerSearchAccord'"))[0]["LabelToolTip"]);

                        peerCompanySetUp.lblMUAccordEditHead.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblMUAccordEditHead'"))[0]["LabelName"]);
                        peerCompanySetUp.lblMUAccordEditHead.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblMUAccordEditHead'"))[0]["LabelToolTip"]);

                        peerCompanySetUp.btnPeerAdd.Value = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerAdd'"))[0]["LabelName"]);
                        peerCompanySetUp.btnPeerAdd.Attributes.Add("title", Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerAdd'"))[0]["LabelToolTip"]));

                        peerCompanySetUp.btnNavigateToMarketPrice.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnNavigateToMarketPrice'"))[0]["LabelName"]);
                        peerCompanySetUp.btnNavigateToMarketPrice.Attributes.Add("title", Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnNavigateToMarketPrice'"))[0]["LabelToolTip"]));

                        peerCompanySetUp.btnPeerSave.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerSave'"))[0]["LabelName"]);
                        peerCompanySetUp.btnPeerSave.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerSave'"))[0]["LabelToolTip"]);

                        peerCompanySetUp.btnPeerViewHistory.Value = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerViewHistory'"))[0]["LabelName"]);
                        peerCompanySetUp.btnPeerViewHistory.Attributes.Add("title", Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerViewHistory'"))[0]["LabelToolTip"]));

                        peerCompanySetUp.btnPeerReset.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerReset'"))[0]["LabelName"]);
                        peerCompanySetUp.btnPeersCancel.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerCancel'"))[0]["LabelName"]);
                        peerCompanySetUp.btnPeersCancel.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerCancel'"))[0]["LabelToolTip"]);
                        peerCompanySetUp.btnHistoryBack.Value = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnHistoryBack'"))[0]["LabelName"]);
                        peerCompanySetUp.btnHistoryBack.Attributes.Add("title", Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnHistoryBack'"))[0]["LabelToolTip"]));

                        peerCompanySetUp.lblPeerAddFromDate.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerAddFromDate'"))[0]["LabelName"]);
                        peerCompanySetUp.lblPeerAddToDate.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerAddToDate'"))[0]["LabelName"]);

                        peerCompanySetUp.lblPeerNewFromDate.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerNewFromDate'"))[0]["LabelName"]);
                        peerCompanySetUp.lblPeerNewFromDate.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerNewFromDate'"))[0]["LabelToolTip"]);
                        peerCompanySetUp.ReqtxtPeerNewFromDate_gv.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerNewFromDate'"))[0]["ErrorText"]);

                        peerCompanySetUp.btnPeerDelete.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerDelete'"))[0]["LabelName"]);
                        peerCompanySetUp.btnPeerDelete.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerDelete'"))[0]["LabelToolTip"]);
                        ac_PeerCompanySetup.dt_TempGridviewTable.Rows.Clear();

                        peerCompanySetUp.btnBackToGD.Text = Convert.ToString(ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID = 'btnBackToGD'")[0]["LabelName"]);
                        peerCompanySetUp.btnBackToGD.ToolTip = Convert.ToString(ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID = 'btnBackToGD'")[0]["LabelToolTip"]);

                        peerCompanySetUp.btnPeerAddNew.Text = Convert.ToString(ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID = 'btnPeerAddNew'")[0]["LabelName"]);
                        peerCompanySetUp.btnPeerAddNew.ToolTip = Convert.ToString(ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID = 'btnPeerAddNew'")[0]["LabelToolTip"]);
                        peerCompanySetUp.lblPeerCompanyNote.Text = Convert.ToString(ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID = 'lblPeerCompanyNote'")[0]["LabelName"]);
                    }
                }
            }
            catch
            {

                throw;
            }

        }

        /// <summary>
        /// this method clears the flags and tables for the first visit.
        /// </summary>
        /// <param name="peerCompanySetUp">object of peerCompany Page</param>
        public void ResetAllParameters(PeerCompanySetUp peerCompanySetUp)
        {
            try
            {
                ac_PeerCompanySetup.totalWeightage = 0;
                ac_PeerCompanySetup.dt_TempGridviewTable.Dispose(); ;
                ac_PeerCompanySetup.dt_TempGridviewTable.Rows.Clear();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method loads and binds all dropdownlist on the page when called for. dropdowns are
        /// loaded one by one .
        /// </summary>
        /// <param name="Action">Operation to be performed</param>
        /// <returns></returns>
        public DataTable BindDropdowns(string Action)
        {
            DataTable dt_BindDropDown = new DataTable();
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.Action = Action;
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    valuationProperties.PageName = CommonConstantModel.s_PeerCompanySetup;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    dt_BindDropDown = valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result;
                }
            }
            catch
            {
                throw;
            }

            return dt_BindDropDown;
        }

        /// <summary>
        /// This method checks whether the particular Stock code is valid and falls under the given stock exchange.
        /// </summary>
        /// <param name="s_stockCode">Stock code</param>
        /// <param name="S_StockExName">Stock Exchange</param>
        /// <returns></returns>
        public bool ValidateStockExCode(string s_stockCode, string S_StockExName)
        {
            try
            {
                if ((S_StockExName.ToUpper()).Equals("NSE") || (S_StockExName.ToUpper()).Equals("BSE"))
				{
                    using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                    {
                        valuationProperties.StockExName = S_StockExName;
                        valuationProperties.StockCode = s_stockCode;
                        valuationProperties.Action = "VALIDATE_STOCK_EX_CODE";
                        valuationProperties.PageName = CommonConstantModel.s_PeerCompanySetup;
                        valuationProperties.Operation = CommonConstantModel.s_OperationCUD;

                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        return Convert.ToBoolean(valuationServiceClient.CRUDValuationOperations(valuationProperties).a_result);
                    }
				}
                else
				{
                    return true;
				}
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// This method hides / shows the accordian head depending upon the index of accordian passed to it.
        /// </summary>
        /// <param name="peerCompanySetUp">object of peer company</param>
        /// <param name="n_Accordian_index">accordian index number</param>
        public void Accordian_HideShow(PeerCompanySetUp peerCompanySetUp, int n_Accordian_index)
        {
            try
            {
                switch (n_Accordian_index)
                {
                    case 0:
                        peerCompanySetUp.h3SearchPanel.Style.Add("display", "block");
                        peerCompanySetUp.h3AddEdit.Style.Add("display", "none");
                        peerCompanySetUp.h3History.Style.Add("display", "none");
                        peerCompanySetUp.hdnAccordionIndex.Value = "0";
                        break;

                    case 1:
                        peerCompanySetUp.h3SearchPanel.Style.Add("display", "none");
                        peerCompanySetUp.h3AddEdit.Style.Add("display", "block");
                        peerCompanySetUp.h3History.Style.Add("display", "none");
                        peerCompanySetUp.hdnAccordionIndex.Value = "1";
                        break;

                    case 2:
                        peerCompanySetUp.h3SearchPanel.Style.Add("display", "none");
                        peerCompanySetUp.h3AddEdit.Style.Add("display", "none");
                        peerCompanySetUp.h3History.Style.Add("display", "block");
                        peerCompanySetUp.hdnAccordionIndex.Value = "2";
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Resets all the parameters in edit gridview and also the weightage count.
        /// </summary>
        /// <param name="peerCompanySetUp"></param>
        public void Reset_Gv1(PeerCompanySetUp peerCompanySetUp)
        {
            try
            {
                ac_PeerCompanySetup.totalWeightage = 0;

                LoadGridData(peerCompanySetUp, "LoadGridView");

                Calculate_Total_Weightage(peerCompanySetUp);

                peerCompanySetUp.txtPeerNew_ToDate.Text = string.Empty;
                peerCompanySetUp.txtPeerNewFromDate.Text = string.Empty;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Deletes the particular row from the edit gridview.
        /// </summary>
        /// <param name="peerCompanySetUp">object of peercompany page</param>
        public void DeleteRecordFrom_Gv1(PeerCompanySetUp peerCompanySetUp)
        {
            try
            {
                LoadDatafromEditGridView(peerCompanySetUp);

                Bind_Data_To_EditGridView(peerCompanySetUp);

                DataTable temporarayDataTable = ac_PeerCompanySetup.dt_NewPeerCompanies.Copy();
                temporarayDataTable.Clear();

                int i = 0;

                foreach (DataRow dr in ac_PeerCompanySetup.dt_NewPeerCompanies.Rows)
                {
                    if (!(((CheckBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("chk")).Checked))
                    {
                        var newDataRow = temporarayDataTable.NewRow();
                        newDataRow.ItemArray = dr.ItemArray;
                        temporarayDataTable.Rows.Add(newDataRow);
                    }
                    i = i + 1;
                }

                ac_PeerCompanySetup.dt_NewPeerCompanies = temporarayDataTable;
                peerCompanySetUp.Edit_Gridview.DataSource = ac_PeerCompanySetup.dt_NewPeerCompanies;
                peerCompanySetUp.Edit_Gridview.DataBind();

                peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText = Val_L10N("lblPEERMDeleted");
                peerCompanySetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                peerCompanySetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;

                if (ac_PeerCompanySetup.dt_NewPeerCompanies.Rows.Count > 0)
                {
                    peerCompanySetUp.divTotalWieghatge.Style.Add("display", "block");
                }
                else
                {
                    peerCompanySetUp.lblweightageCount.Text = "";
                    peerCompanySetUp.divTotalWieghatge.Style.Add("display", "none");
                }

                Calculate_Total_Weightage(peerCompanySetUp);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method binds the validator to edit gridview controls
        /// </summary>
        /// <param name="peerCompanySetUp">object of peercompany page</param>
        /// <param name="e">gridview row event</param>
        public void Bind_Validators_To_Grid(PeerCompanySetUp peerCompanySetUp, GridViewRowEventArgs e)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                try
                {

                    RequiredFieldValidator rqdtxtEditPeerName_gv = new RequiredFieldValidator();
                    rqdtxtEditPeerName_gv = (RequiredFieldValidator)e.Row.FindControl("rqdtxtEditPeerName_gv");
                    rqdtxtEditPeerName_gv.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerAddCompanyName'"))[0]["ErrorText"]);

                    RequiredFieldValidator rqd_ddEditStockExName_gv = new RequiredFieldValidator();
                    rqd_ddEditStockExName_gv = (RequiredFieldValidator)e.Row.FindControl("rqdddPeerEditStockEcName");
                    rqd_ddEditStockExName_gv.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerAddStockExName'"))[0]["ErrorText"]);

                    RequiredFieldValidator rqdtxtPeerEditStockExCode = new RequiredFieldValidator();
                    rqdtxtPeerEditStockExCode = (RequiredFieldValidator)e.Row.FindControl("rqdtxtPeerEditStockExCode");
                    rqdtxtPeerEditStockExCode.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerAddStockExCode'"))[0]["ErrorText"]);

                    RequiredFieldValidator rqdtxtPeerEditWeightage_gv = new RequiredFieldValidator();
                    rqdtxtPeerEditWeightage_gv = (RequiredFieldValidator)e.Row.FindControl("rqdtxtPeerEditWeightage_gv");
                    rqdtxtPeerEditWeightage_gv.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerWeightage'"))[0]["ErrorText"]);
                    rqdtxtPeerEditWeightage_gv.Display = ValidatorDisplay.Dynamic;

                    RangeValidator rngetxtPeerEditWeightage_gv = new RangeValidator();
                    rngetxtPeerEditWeightage_gv = (RangeValidator)e.Row.FindControl("RangePeerWeightage");
                    rngetxtPeerEditWeightage_gv.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerWeightage'"))[0]["ErrorText2"]);
                    rngetxtPeerEditWeightage_gv.Display = ValidatorDisplay.Dynamic;

                    RegularExpressionValidator reglrtxtPeerEditWeightage_gv = new RegularExpressionValidator();
                    reglrtxtPeerEditWeightage_gv = (RegularExpressionValidator)e.Row.FindControl("regtxtPeerEditWeightage_gv");
                    reglrtxtPeerEditWeightage_gv.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerWeightage2'"))[0]["ErrorText"]);
                    reglrtxtPeerEditWeightage_gv.Display = ValidatorDisplay.Dynamic;

                    RequiredFieldValidator rqdtxtPeerEditListDate_gv = new RequiredFieldValidator();
                    rqdtxtPeerEditListDate_gv = (RequiredFieldValidator)e.Row.FindControl("ReqtxtPeerEditListDate_gv");
                    rqdtxtPeerEditListDate_gv.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerAddListingDate'"))[0]["ErrorText"]);

                    RequiredFieldValidator rqdddEditPeerStatus_gv = new RequiredFieldValidator();
                    rqdddEditPeerStatus_gv = (RequiredFieldValidator)e.Row.FindControl("rqdddEditPeerStatus_gv");
                    rqdddEditPeerStatus_gv.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lblPeerStatus'"))[0]["ErrorText"]);

                    RequiredFieldValidator RqdPeerWeightage_submit = new RequiredFieldValidator();
                    RqdPeerWeightage_submit = (RequiredFieldValidator)e.Row.FindControl("RqdPeerWeightage_submit");
                    RqdPeerWeightage_submit.ToolTip = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lbltotalweightage'"))[0]["ErrorText"]);
                    reglrtxtPeerEditWeightage_gv.Display = ValidatorDisplay.Dynamic;
                }
                catch
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// This method calculates the total weightage given in each weightage textbox of the edit gridview row.
        /// </summary>
        /// <param name="peerCompanySetUp">object of peercompany page</param>
        public void Calculate_Total_Weightage(PeerCompanySetUp peerCompanySetUp)
        {
            using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
            {
                try
                {
                    double Weightage = 0;

                    for (int i = 0; i < peerCompanySetUp.Edit_Gridview.Rows.Count; i++)
                    {
                        try
                        {
                            if (!string.IsNullOrEmpty((((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditWeightage_gv")).Text)) && ((DropDownList)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("ddEditPeerStatus_gv")).SelectedValue == "1")
                                Weightage = Weightage + Convert.ToDouble(((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditWeightage_gv")).Text);
                        }
                        catch (Exception)
                        {
                            peerCompanySetUp.lblweightageCount.Text = valuationServiceClient.GetValuation_L10N("lblPEERInvalidWietage", CommonConstantModel.s_PeerCompanySetup, CommonConstantModel.s_ValuationL10);
                            peerCompanySetUp.lblweightageCount.ForeColor = System.Drawing.Color.Red;
                            return;
                        }
                        
                        peerCompanySetUp.lbltotalweightage.Text = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='lbltotalweightage'"))[0]["LabelName"]);
                        peerCompanySetUp.lblweightageCount.Text = Weightage.ToString();
                        
                        if (Weightage > 100)
                            peerCompanySetUp.lblweightageCount.ForeColor = System.Drawing.Color.Red;
                        else peerCompanySetUp.lblweightageCount.ForeColor =  System.Drawing.Color.Blue;

                        if (!(string.IsNullOrEmpty(peerCompanySetUp.lblweightageCount.Text)))
                        {
                            peerCompanySetUp.divTotalWieghatge.Style.Add("display", "block");
                        }
                        else
                        {
                            peerCompanySetUp.divTotalWieghatge.Style.Add("display", "none");
                        }
                    }

                }
                catch
                {
                    throw;
                }

                peerCompanySetUp.hdnValidateCount.Value = "1";
            }
        }

        /// <summary>
        /// This Method fetches data from the edit gridview, creates a final datatable and sends it to PerformCUD method for CUD operations.
        /// </summary>
        /// <param name="peerCompanySetUp">object of peercompany page</param>
        /// <param name="s_PeerOperations">peer operation</param>
        public void SavePeersToDatabase(PeerCompanySetUp peerCompanySetUp, string s_PeerOperations)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    ac_PeerCompanySetup.totalWeightage = 0;
                    ac_PeerCompanySetup.dt_TempGridviewTable.Clear();
                    peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText = string.Empty;
                    s_InvalidStockCodeList = string.Empty;

                    columnList.Add("CompanyName");
                    columnList.Add("SEID");
                    columnList.Add("Stock Code");
                    columnList.Add("Weightage");
                    columnList.Add("STATUSCODE");
                    columnList.Add("ListingDate");
                    columnList.Add("ActiveFromDate");
                    columnList.Add("ActiveToDate");
                    columnList.Add("PreviousToDate");
                    columnList.Add("IsFuture");
                    columnList.Add("GroupId");
                    columnList.Add("CREATEDBY");
                    columnList.Add("CREATED_ON");
                    columnList.Add("UPDATED_BY");
                    columnList.Add("UPDATED_ON");
                    if (!(peerCompanySetUp.Edit_Gridview.Rows.Count == 0))
                    {
                        for (int i = 0; i < peerCompanySetUp.Edit_Gridview.Rows.Count; i++)
                        {
                            string CompName = ((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtEditPeerName_gv")).Text;
                            string StockExName = ((DropDownList)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("ddPeerEditStockEcName")).SelectedValue;
                            string StockCode = ((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditStockExCode")).Text;
                            string Weightage = ((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditWeightage_gv")).Text;

                            if (!(string.IsNullOrEmpty(CompName) || string.IsNullOrEmpty(StockExName) || string.IsNullOrEmpty(StockCode) || string.IsNullOrEmpty(Weightage)))
                            {
                                contentList.Clear();
                                string if_reecordExists = null;
                                contentList.Add(((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtEditPeerName_gv")).Text);
                                contentList.Add(((DropDownList)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("ddPeerEditStockEcName")).SelectedValue);
                                contentList.Add(((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditStockExCode")).Text);
                                contentList.Add(((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditWeightage_gv")).Text);
                                contentList.Add(((DropDownList)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("ddEditPeerStatus_gv")).SelectedValue);
                                contentList.Add(((HtmlInputControl)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditListDate_gv")).Value);
                                contentList.Add(peerCompanySetUp.txtPeerNewFromDate.Text);
                                contentList.Add(peerCompanySetUp.txtPeerNew_ToDate.Text);
                                contentList.Add(Convert.ToString(Convert.ToDateTime(peerCompanySetUp.txtPeerNewFromDate.Text).AddDays(-1)));
                                contentList.Add(peerCompanySetUp.hdnIsFutureId.Value);
                                contentList.Add(peerCompanySetUp.hdnGroupId.Value);
                                contentList.Add(userSessionInfo.ACC_UserID.ToString());
                                contentList.Add(DateTime.Now.ToString());
                                contentList.Add(userSessionInfo.ACC_UserID.ToString());
                                contentList.Add(DateTime.Now.ToString());

                                try
                                {
                                    string s_stockCode = ((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditStockExCode")).Text;
                                    if_reecordExists = Convert.ToString((ac_PeerCompanySetup.dt_TempGridviewTable.Select("[Stock Code]='" + s_stockCode + "'"))[0]["SEID"]);
                                }
                                catch
                                {
                                    if_reecordExists = null;
                                }

                                if (string.IsNullOrEmpty(if_reecordExists))
                                {
                                    if ((ValidateStockExCode(((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditStockExCode")).Text, ((DropDownList)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("ddPeerEditStockEcName")).SelectedItem.ToString())))
                                    {
                                        if (((DropDownList)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("ddEditPeerStatus_gv")).SelectedValue == "1")
                                            ac_PeerCompanySetup.totalWeightage = ac_PeerCompanySetup.totalWeightage + Convert.ToDouble(Weightage);

                                        DataRow tableRow = ac_PeerCompanySetup.dt_TempGridviewTable.NewRow();

                                        for (int j = 0; j < contentList.Count; j++)
                                        {
                                            if (!ac_PeerCompanySetup.dt_TempGridviewTable.Columns.Contains(columnList[j]))
                                                ac_PeerCompanySetup.dt_TempGridviewTable.Columns.Add(columnList[j]);
                                            tableRow[columnList[j]] = contentList[j].ToString();
                                        }

                                        ac_PeerCompanySetup.dt_TempGridviewTable.Rows.Add(tableRow);
                                    }
                                    else
                                    {
                                       
                                        if (string.IsNullOrEmpty(s_InvalidStockCodeList))
                                        {
                                           
                                            peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblPEERInvalidStockExCode", CommonConstantModel.s_PeerCompanySetup, CommonConstantModel.s_ValuationL10) + " " + ((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditStockExCode")).Text;
                                            s_InvalidStockCodeList = peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText;
                                        }
                                        else
                                        {
                                            peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText = s_InvalidStockCodeList + ", " + ((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditStockExCode")).Text;
                                            s_InvalidStockCodeList = peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText;
                                        }
                                        peerCompanySetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                        peerCompanySetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                                        if (peerCompanySetUp.Edit_Gridview.Rows.Count-1 == i)
                                            return;
                                    }
                                }
                                else
                                {
                                    peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblPEERNameExists", CommonConstantModel.s_PeerCompanySetup, CommonConstantModel.s_ValuationL10) + " " + ((TextBox)peerCompanySetUp.Edit_Gridview.Rows[i].FindControl("txtPeerEditStockExCode")).Text; 
                                    peerCompanySetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                    peerCompanySetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                    return;
                                }
                            }

                        }
                    }
                    else
                    {
                        peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblPEERBlank", CommonConstantModel.s_PeerCompanySetup, CommonConstantModel.s_ValuationL10);
                        peerCompanySetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                        peerCompanySetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        return;
                    }
                    if (string.IsNullOrEmpty(s_InvalidStockCodeList))
                    {
                        if (!(ac_PeerCompanySetup.totalWeightage == 100))
                        {
                            peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblPEERWeightageInvalid", CommonConstantModel.s_PeerCompanySetup, CommonConstantModel.s_ValuationL10);
                            peerCompanySetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            peerCompanySetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            return;
                        }
                        else
                        {
                            PerformCUD(peerCompanySetUp, "CREATE_TYPE");
                        }
                    }
                }

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method Adds a new row in edit gridview when clicked on AddNew button.
        /// </summary>
        /// <param name="peerCompanySetUp">object of peercompany page</param>
        public void addNewRowToGrid(PeerCompanySetUp peerCompanySetUp)
        {
            try
            {
                LoadDatafromEditGridView(peerCompanySetUp);

                Bind_Data_To_EditGridView(peerCompanySetUp);

                DataRow tableRow = ac_PeerCompanySetup.dt_NewPeerCompanies.NewRow();
                ac_PeerCompanySetup.dt_NewPeerCompanies.Rows.Add(tableRow);

                peerCompanySetUp.Edit_Gridview.DataSource = ac_PeerCompanySetup.dt_NewPeerCompanies.Copy();
                peerCompanySetUp.Edit_Gridview.DataBind();

                peerCompanySetUp.h3AddEdit.Style.Add("display", "");
                peerCompanySetUp.hdnValidateCount.Value = "0";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method Binds the data to edit grid view that was already entered in it before clicking on "Add New" button.
        /// </summary>
        /// <param name="peerCompanySetUp">object of peercompany page</param>
        public void Bind_Data_To_EditGridView(PeerCompanySetUp peerCompanySetUp)
        {
            try
            {
                int RowCount_of_EditGridview = peerCompanySetUp.Edit_Gridview.Rows.Count;
                int ColCount_of_EditGridview = peerCompanySetUp.Edit_Gridview.Columns.Count;
                for (int j = 0; j < ac_PeerCompanySetup.editGridview_data.Length / 7; j++)
                {
                    ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[j][2] = string.IsNullOrEmpty(ac_PeerCompanySetup.editGridview_data[j, 0]) ? "" : ac_PeerCompanySetup.editGridview_data[j, 0];
                    ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[j][3] = string.IsNullOrEmpty(ac_PeerCompanySetup.editGridview_data[j, 1]) ? "" : ac_PeerCompanySetup.editGridview_data[j, 1];
                    ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[j][4] = string.IsNullOrEmpty(ac_PeerCompanySetup.editGridview_data[j, 2]) ? "" : ac_PeerCompanySetup.editGridview_data[j, 2];
                    ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[j][5] = string.IsNullOrEmpty(ac_PeerCompanySetup.editGridview_data[j, 3]) ? "" : ac_PeerCompanySetup.editGridview_data[j, 3];
                    ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[j][6] = string.IsNullOrEmpty(ac_PeerCompanySetup.editGridview_data[j, 4]) ? "" : ac_PeerCompanySetup.editGridview_data[j, 4];
                    ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[j][7] = string.IsNullOrEmpty(ac_PeerCompanySetup.editGridview_data[j, 5]) ? Convert.ToDecimal(null) : Convert.ToDecimal(ac_PeerCompanySetup.editGridview_data[j, 5]);
                    ac_PeerCompanySetup.dt_NewPeerCompanies.Rows[j][9] = string.IsNullOrEmpty(ac_PeerCompanySetup.editGridview_data[j, 6]) ? "" : ac_PeerCompanySetup.editGridview_data[j, 6];

                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// This method Loads the data from edit grid view that was already entered in it before clicking on "Add New" button into into a 2d array.
        /// </summary>
        /// <param name="peerCompanySetUp">object of peercompany page</param>
        public void LoadDatafromEditGridView(PeerCompanySetUp peerCompanySetUp)
        {
            try
            {
                int RowCount_of_EditGridview = peerCompanySetUp.Edit_Gridview.Rows.Count;
                int ColCount_of_EditGridview = peerCompanySetUp.Edit_Gridview.Columns.Count;
                string[,] DatafromGrid = new string[RowCount_of_EditGridview, ColCount_of_EditGridview];
                int Rowcounter = 0;

                for (int i = 0; i < RowCount_of_EditGridview; i++)
                {
                    DatafromGrid[Rowcounter, 0] = ((TextBox)peerCompanySetUp.Edit_Gridview.Rows[Rowcounter].FindControl("txtEditPeerName_gv")).Text;
                    DatafromGrid[Rowcounter, 1] = ((DropDownList)peerCompanySetUp.Edit_Gridview.Rows[Rowcounter].FindControl("ddPeerEditStockEcName")).SelectedItem.ToString();
                    DatafromGrid[Rowcounter, 2] = ((TextBox)peerCompanySetUp.Edit_Gridview.Rows[Rowcounter].FindControl("txtPeerEditStockExCode")).Text;
                    DatafromGrid[Rowcounter, 3] = ((HtmlInputControl)peerCompanySetUp.Edit_Gridview.Rows[Rowcounter].FindControl("txtPeerEditListDate_gv")).Value;
                    DatafromGrid[Rowcounter, 4] = ((DropDownList)peerCompanySetUp.Edit_Gridview.Rows[Rowcounter].FindControl("ddEditPeerStatus_gv")).SelectedItem.ToString();
                    DatafromGrid[Rowcounter, 5] = ((TextBox)peerCompanySetUp.Edit_Gridview.Rows[Rowcounter].FindControl("txtPeerEditWeightage_gv")).Text;
                    DatafromGrid[Rowcounter, 6] = ((DropDownList)peerCompanySetUp.Edit_Gridview.Rows[Rowcounter].FindControl("ddPeerEditStockEcName")).SelectedValue;
                    Rowcounter = Rowcounter + 1;
                }

                ac_PeerCompanySetup.editGridview_data = DatafromGrid;
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// This method is used to load content of IsActive dropdownlist
        /// </summary>
        /// <returns>void</returns>
        internal void PerformCUD(PeerCompanySetUp peerCompanySetUp, string s_Action)
        {
            if (ac_PeerCompanySetup.totalWeightage == 100.00)
                try
                {
                    using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                    {
                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                        valuationProperties.Action = s_Action;
                        ac_PeerCompanySetup.dt_TempGridviewTable.TableName = "DT";

                        valuationProperties.dt_PeerCompanyTable = ac_PeerCompanySetup.dt_TempGridviewTable;
                        valuationProperties.PageName = CommonConstantModel.s_PeerCompanySetup;
                        valuationProperties.Operation = CommonConstantModel.s_OperationCUD;

                        valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                        peerCompanySetUp.hdnAccordionIndex.Value = "0";
                        peerCompanySetUp.h3AddEdit.Style.Add("display", "none");



                        switch (valuationServiceClient.CRUDValuationOperations(valuationProperties).a_result)
                        {
                            case 0:
                                peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblError", CommonConstantModel.s_PeerCompanySetup, CommonConstantModel.s_ValuationL10);
                                peerCompanySetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                peerCompanySetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                peerCompanySetUp.hdnAccordionIndex.Value = "1";
                                peerCompanySetUp.h3AddEdit.Style.Add("display", "block");
                                break;

                            case 1:
                                peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblPEERAdded", CommonConstantModel.s_PeerCompanySetup, CommonConstantModel.s_ValuationL10);
                                peerCompanySetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                                ac_PeerCompanySetup.dt_TempGridviewTable.Clear();
                                ac_PeerCompanySetup.totalWeightage = 0;

                                LoadGridData(peerCompanySetUp, "LoadGridView");
                                break;

                            case 5:
                                peerCompanySetUp.ctrSuccessErrorMessage.s_MessageText = valuationServiceClient.GetValuation_L10N("lblPEERCanNotEditSettings", CommonConstantModel.s_PeerCompanySetup, CommonConstantModel.s_ValuationL10);
                                peerCompanySetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                peerCompanySetUp.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                                peerCompanySetUp.hdnAccordionIndex.Value = "1";
                                peerCompanySetUp.h3AddEdit.Style.Add("display", "block");
                                break;
                        }
                        peerCompanySetUp.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    }
                }
                catch
                {
                    throw;
                }
        }

        /// <summary>
        /// Loads gridview contents...
        /// </summary>
        /// <param name="peerCompanySetUp">peer Company SetUp</param>
        /// <param name="s_Action">Action to be performed</param>
        public void LoadGridData(PeerCompanySetUp peerCompanySetUp, string s_Action)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {
                    valuationProperties.Action = s_Action;
                    valuationProperties.PageName = CommonConstantModel.s_PeerCompanySetup;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;

                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    ac_PeerCompanySetup.dt_GridViewDataTable = valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result;
                    peerCompanySetUp.gv.DataSource = ac_PeerCompanySetup.dt_GridViewDataTable;
                    peerCompanySetUp.gv.DataBind();

                    ac_PeerCompanySetup.dt_NewPeerCompanies = ac_PeerCompanySetup.dt_GridViewDataTable.Copy();
                    peerCompanySetUp.Edit_Gridview.DataSource = ac_PeerCompanySetup.dt_NewPeerCompanies;
                    peerCompanySetUp.Edit_Gridview.DataBind();

                    if (ac_PeerCompanySetup.dt_GridViewDataTable.Rows.Count > 0)
                    {
                        peerCompanySetUp.hdnGroupId.Value = ac_PeerCompanySetup.dt_GridViewDataTable.Rows[0][10].ToString();

                        peerCompanySetUp.txtPeerCurrentFromDate.Text = peerCompanySetUp.lblCurrentPeerDate.Text = ac_PeerCompanySetup.dt_GridViewDataTable.Rows[0][8].ToString();
                        peerCompanySetUp.divTotalWieghatge.Style.Add("display", "");
                    }
                    else
                    {
                        peerCompanySetUp.divTotalWieghatge.Style.Add("display", "none");
                    }
                    Load_HistoryGridData(peerCompanySetUp, "Load_History");
                    peerCompanySetUp.btnNavigateToMarketPrice.Visible = peerCompanySetUp.btnPeerViewHistory.Visible = peerCompanySetUp.lblPeerAddFromDate.Visible = Convert.ToBoolean(peerCompanySetUp.gv.Rows.Count);

                    if (peerCompanySetUp.gv.Rows.Count > 0)
                    {
                        peerCompanySetUp.btnPeerAdd.Value = Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerAddEdit'"))[0]["LabelName"]);
                        peerCompanySetUp.btnPeerAdd.Attributes.Add("title", Convert.ToString((ac_PeerCompanySetup.dt_PeerCompanyUI.Select("LabelID='btnPeerAddEdit'"))[0]["LabelToolTip"]));
                    }
                    else
                    {
                        peerCompanySetUp.hdnAccordionIndex.Value = "0";
                        addNewRowToGrid(peerCompanySetUp);
                        peerCompanySetUp.h3AddEdit.Style.Add("display", "none");
                    }

                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Loads gridview contents...
        /// </summary>
        /// <param name="peerCompanySetUp">peer Company SetUp</param>
        /// <param name="s_Action">Action to be performed</param>
        public void Load_HistoryGridData(PeerCompanySetUp peerCompanySetUp, string s_Action)
        {
            try
            {
                using (ValuationServiceClient valuationServiceClient = new ValuationServiceClient())
                {

                    valuationProperties.Action = s_Action;
                    valuationProperties.PageName = CommonConstantModel.s_PeerCompanySetup;
                    valuationProperties.Operation = CommonConstantModel.s_OperationRead;
                    valuationProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    ac_PeerCompanySetup.dt_ViewHistory = valuationServiceClient.CRUDValuationOperations(valuationProperties).dt_Result;

                    peerCompanySetUp.gv_History.DataSource = Reconstruct_HistoryGridView(peerCompanySetUp);
                    peerCompanySetUp.gv_History.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

      /// <summary>
      /// 
      /// </summary>
      /// <param name="peerCompanySetUp"></param>
      /// <returns></returns>
        protected internal DataTable Reconstruct_HistoryGridView(PeerCompanySetUp peerCompanySetUp)
        {
             string Check_GroupId = string.Empty;
             DataTable dttemp = ac_PeerCompanySetup.dt_ViewHistory.Copy();
             dttemp.Clear();
            foreach (DataRow dr in ac_PeerCompanySetup.dt_ViewHistory.Rows)
            {
                if (peerCompanySetUp.hdnGroupId.Value != dr[1].ToString())
                {
                    if (Check_GroupId != dr[1].ToString())
                    {
                        if (dttemp.Rows.Count != 0)
                        {
                            DataRow blankrow = dttemp.NewRow();
                            dttemp.Rows.Add(blankrow);
                        }
                        Check_GroupId = dr[1].ToString();
                        DataRow Contentrow = dttemp.NewRow();
                        Contentrow.ItemArray = dr.ItemArray;
                        dttemp.Rows.Add(Contentrow);
                    }
                    else
                    {
                        DataRow Contentrow = dttemp.NewRow();
                        Contentrow.ItemArray = dr.ItemArray;
                        dttemp.Rows.Add(Contentrow);
                    }
                }
            }
            return dttemp;
        }

        /// <summary>
        /// This method hides unwanted column from history gridview and also does alignment operations
        /// </summary>
        /// <param name="e">gridview event object</param>
        /// <param name="n_index_History">index number</param>
        /// <param name="n_ID_History">Id</param>
        /// <param name="n_Createdby_History">Createdby index</param>
        /// <param name="n_StatusCode__History">statusCode index</param>
        /// <param name="n_Updated_By_History">UpdatedBy index</param>
        /// <param name="n_Updated_On_History">UpdatedOn index</param>
        /// <param name="n_GroupId_History">GroupId index</param>
        public void Bind_Gv_History(GridViewRowEventArgs e, ref int n_index_History, ref int n_ID_History, ref int n_Createdby_History, ref int n_StatusCode__History, ref int n_Updated_By_History, ref int n_Updated_On_History, ref int n_GroupId_History)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        try
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "APCSAID":
                                    n_StatusCode__History = n_index_History;
                                    perColumn.Visible = false;
                                    break;

                                case "GROUPID":
                                    n_GroupId_History = n_index_History;
                                    perColumn.Visible = false;
                                    break;

                                case "SEID":
                                    perColumn.Visible = false;
                                    n_ID_History = n_index_History;
                                    break;

                                case "CREATEDBY":
                                    n_Createdby_History = n_index_History;
                                    perColumn.Visible = false;
                                    break;

                                case "UPDATED_BY":
                                    perColumn.Visible = false;
                                    n_Updated_By_History = n_index_History;
                                    break;

                                case "UPDATED_ON":
                                    perColumn.Visible = false;
                                    n_Updated_On_History = n_index_History;
                                    break;

                            }
                            n_index_History = n_index_History + 1;
                        }
                        catch
                        {
                            throw;
                        }
                    }
                    break;

                case DataControlRowType.DataRow:
                    CheckBox chkBox = new CheckBox();
                    try
                    {
                        e.Row.Cells[n_GroupId_History].Visible = false;
                        e.Row.Cells[n_ID_History].Visible = false;
                        e.Row.Cells[n_StatusCode__History].Visible = false;
                        e.Row.Cells[n_Createdby_History].Visible = false;
                        e.Row.Cells[n_Updated_By_History].Visible = false;
                        e.Row.Cells[n_Updated_On_History].Visible = false;
                        e.Row.Cells[7].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                    }
                    catch
                    {
                        throw;
                    }
                    break;
            }
        }

        /// <summary>
        ///This method Binds Grid view row and coloumn
        /// </summary>
        /// <param name="e">Row Event</param>
        /// <param name="n_index">index number</param>
        /// <param name="n_ID">ID</param>
        /// <param name="n_FromDate">fromDate index</param>
        /// <param name="n_SEID">SEID index</param>
        /// <param name="n_Delete">Delete ID</param>
        /// <param name="n_GroupId">GroupId index</param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_FromDate, ref int n_SEID, ref int n_Delete, ref int n_GroupId)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                    {
                        try
                        {

                            switch (perColumn.Text.ToUpper())
                            {
                                case "APCSID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    n_Delete = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "FROMDATE":
                                    n_FromDate = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "SEID":
                                    n_SEID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "GROUPID":
                                    n_GroupId = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "WEIGHTS ASSIGNED":
                                    perColumn.Text = "Weights assigned (%)";
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        catch
                        {
                            throw;
                        }
                    }
                    break;

                case DataControlRowType.DataRow:
                    CheckBox chkBox = new CheckBox();
                    try
                    {
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[7].HorizontalAlign = HorizontalAlign.Right;
                        e.Row.Cells[n_FromDate].Visible = false;
                        e.Row.Cells[n_SEID].Visible = false;
                        e.Row.Cells[n_Delete].Visible = false;
                        e.Row.Cells[n_GroupId].Visible = false;
                    }
                    catch
                    {
                        throw;
                    }
                    break;
            }
        }

        /// <summary>
        /// this method generates a link button for toggling the peer company status.
        /// </summary>
        /// <param name="s_APCSID">peer company id</param>
        /// <param name="s_Company_Name">peer company name</param>
        /// <param name="s_SeId">Stock Ex Id</param>
        /// <param name="s_Stock_Ex_Code">Stock Code</param>
        /// <param name="weightage">weightage assigned</param>
        /// <param name="s_status">status as a text</param>
        /// <returns></returns>
        private LinkButton AddLinkButton(string s_APCSID, string s_Company_Name, string s_SeId, string s_Stock_Ex_Code, string weightage, string s_status)
        {
            LinkButton lnkbutton = new LinkButton();
            try
            {
                lnkbutton.Text = s_status;
                lnkbutton.Attributes.Add("onclick", "Searchpeers('" + s_APCSID + "', '" + s_Company_Name + "', '" + s_SeId + "', '" + s_Stock_Ex_Code + "','" + weightage + "')");
            }
            catch
            {
                throw;
            }
            return lnkbutton;
        }

        /// <summary>
        /// To change pages of gridview
        /// </summary>
        internal void gv_History_PageIndexChanging(object sender, GridViewPageEventArgs e, PeerCompanySetUp peerCompanySetUp, string s_PeerCompanyGroupID)
        {
            try
            {
                peerCompanySetUp.gv_History.PageIndex = e.NewPageIndex;
                peerCompanySetUp.gv_History.DataSource = Reconstruct_HistoryGridView(peerCompanySetUp);
                peerCompanySetUp.gv_History.DataBind();

            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// To change pages of gridview
        /// </summary>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_PeerCompanyGroupID)
        {
            try
            {
                string[] s_PeerCompanyGpID = s_PeerCompanyGroupID.TrimStart(',').Split(',');

                ac_PeerCompanySetup.dt_GridViewDataTable.Columns["Delete"].Expression = string.Empty;
                ac_PeerCompanySetup.dt_GridViewDataTable.AcceptChanges();

                foreach (string perID in s_PeerCompanyGpID)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_PeerCompanySetup.dt_GridViewDataTable.Select("APCSID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_PeerCompanySetup.dt_GridViewDataTable;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method adds image button in the action column of the grid .
        /// </summary>
        /// <param name="s_strToolTip">tooltip for img button</param>
        /// <param name="s_strUrl">image url </param>
        /// <param name="s_APCSID">Peer company id</param>
        /// <returns>returns image button</returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_APCSID)
        {
            try
            {
                using (ImageButton imgButton = new ImageButton())
                {
                    imgButton.ImageUrl = s_strUrl;
                    imgButton.ToolTip = s_strToolTip;
                    imgButton.Style.Add("cursor", "pointer");
                    if (!string.IsNullOrEmpty(s_APCSID))
                    {
                        imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_APCSID + "')");
                    }
                    return imgButton;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method loads the 'Grants applicable to' date, one day prior to the selected new 'grants applicable from' date. 
        /// </summary>
        /// <param name="peerCompanySetUp">peerCompanySetUp's object</param>
        public void txtPeerNewFromDate_TextChanged(PeerCompanySetUp peerCompanySetUp)
        {
            try
            {
                if (!((string.IsNullOrEmpty(peerCompanySetUp.txtPeerCurrentFromDate.Text) || peerCompanySetUp.txtPeerCurrentFromDate.Text == "dd/mmm/yyyy")))
                    if (!((string.IsNullOrEmpty(peerCompanySetUp.txtPeerNewFromDate.Text) || peerCompanySetUp.txtPeerNewFromDate.Text == "dd/mmm/yyyy")))
                    {
                        DateTime DTE = new DateTime();
                        DTE = Convert.ToDateTime(peerCompanySetUp.txtPeerNewFromDate.Text.ToString());
                        DTE = DTE.AddDays(-1);
                        peerCompanySetUp.txtPeerNew_ToDate.Text = DTE.ToString("dd/MMM/yyyy");
                        peerCompanySetUp.hdnAccordionIndex.Value = "1";
                    }
            }
            catch (Exception Ex)
            {
                CommonModel.SendExceptionMail(Convert.ToString("URL : " + System.Web.HttpContext.Current.Request.Url.AbsoluteUri + "\n" + "Error : " + Ex.Message + "\n" + CommonConstantModel.s_ExceptCompUserName.Replace("@", userSessionInfo.ACC_CompanyName).Replace("*", userSessionInfo.ACC_UserName) + "\n" + Ex.StackTrace));
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~PeerCompanyModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}