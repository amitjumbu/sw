﻿using System;

namespace EDFinancials.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class EDFinancialsException : Exception
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public EDFinancialsException()
        {
            // TODO: Complete member initialization
        }

        /// <summary>
        /// This method is used to write the Exception with message
        /// </summary>
        /// <param name="message">return the string parameter</param>
        public EDFinancialsException(string message) : base(message) { }

        /// <summary>
        /// This method is used to write the Exception with message and inner exception
        /// </summary>
        /// <param name="message">return the string parameter</param>
        /// <param name="inner">return inner exception</param>
        public EDFinancialsException(string message, Exception inner) : base(message, inner) { }
    }
}