﻿using EDFinancials.Model.Generic;
using EDFinancials.View.Admin;
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Linq;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.Admin
{
    /// <summary>
    /// This is  model class for Manage currencies page.
    /// </summary>
    public class ManageCurrenciesModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ManageCurrenciesModel"/> class.
        /// </summary>
        public ManageCurrenciesModel()
        {
            if (ac_ManageCurrency == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageCurrency);
                ac_ManageCurrency = (CommonModel.AC_ManageCurrency)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageCurrency];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty;

        #endregion

        /// <summary>
        /// This Method is used to bind UI labels to all controls from AP_L10_UI xml file at page-load
        /// </summary>
        /// <param name="manageCurrencies">manageCurrencies</param>
        internal void BindUI(ManageCurrencies manageCurrencies)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    using (DataTable dt_ADMCurrenciesUI = adminServiceClient.GetAdmin_L10N_UI(CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10_UI))
                    {
                        if ((dt_ADMCurrenciesUI != null) && (dt_ADMCurrenciesUI.Rows.Count > 0))
                        {
                            manageCurrencies.lblParamCurrencyName.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblParamCurrencyName'"))[0]["LabelName"]);
                            manageCurrencies.lblParamCMAlias.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblParamCMAlias'"))[0]["LabelName"]);
                            manageCurrencies.lblCRMIsDefault.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblCRMIsDefault'"))[0]["LabelName"]);
                            manageCurrencies.btnCRMApplyFilter.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMApplyFilter'"))[0]["LabelName"]);
                            manageCurrencies.btnCRMCreateNew.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMCreateNew'"))[0]["LabelName"]);
                            manageCurrencies.btnCRMDelete.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMDelete'"))[0]["LabelName"]);
                            manageCurrencies.lblCurrencyName.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblCurrencyName'"))[0]["LabelName"]);
                            manageCurrencies.lblCRMCurrencyAlias.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblCRMCurrencyAlias'"))[0]["LabelName"]);
                            manageCurrencies.btnCRMSave.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMSave'"))[0]["LabelName"]);
                            manageCurrencies.btnCRMCancel.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMCancel'"))[0]["LabelName"]);
                            manageCurrencies.lblHeader1.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblHeader1'"))[0]["LabelName"]);
                            manageCurrencies.lblHeader2.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblHeader2'"))[0]["LabelName"]);
                            manageCurrencies.lblTopHeader.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblTopHeader'"))[0]["LabelName"]);
                            manageCurrencies.btnClearFilter.Text = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnClearFilter'"))[0]["LabelName"]);
                            manageCurrencies.lblParamCurrencyName.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblParamCurrencyName'"))[0]["LabelToolTip"]);
                            manageCurrencies.lblParamCMAlias.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblParamCMAlias'"))[0]["LabelToolTip"]);
                            manageCurrencies.btnCRMApplyFilter.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMApplyFilter'"))[0]["LabelToolTip"]);
                            manageCurrencies.btnClearFilter.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnClearFilter'"))[0]["LabelToolTip"]);
                            manageCurrencies.btnCRMCreateNew.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMCreateNew'"))[0]["LabelToolTip"]);
                            manageCurrencies.btnCRMDelete.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMDelete'"))[0]["LabelToolTip"]);
                            manageCurrencies.lblCurrencyName.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblCurrencyName'"))[0]["LabelToolTip"]);
                            manageCurrencies.reqName.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblCurrencyName'"))[0]["ErrorText"]);
                            manageCurrencies.lblCRMCurrencyAlias.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblCRMCurrencyAlias'"))[0]["LabelToolTip"]);
                            manageCurrencies.lblCRMIsDefault.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblCRMIsDefault'"))[0]["LabelToolTip"]);
                            manageCurrencies.btnCRMSave.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMSave'"))[0]["LabelToolTip"]);
                            manageCurrencies.btnCRMCancel.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMCancel'"))[0]["LabelToolTip"]);
                            manageCurrencies.reqAlias.ToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'lblCRMCurrencyAlias'"))[0]["ErrorText"]);
                            s_BtnUpdateText = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMUpdate'"))[0]["LabelName"]);
                            s_BtnUpdateToolTip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMUpdate'"))[0]["LabelToolTip"]);
                            s_BtnSaveText = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMSave'"))[0]["LabelName"]);
                            s_BtnSaveTooltip = Convert.ToString((dt_ADMCurrenciesUI.Select("LabelID = 'btnCRMSave'"))[0]["LabelToolTip"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to bind currency names to dropdown
        /// </summary>
        /// <param name="manageCurrencies">manageCurrencies</param>
        internal void BindCurrencyName(ManageCurrencies manageCurrencies)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminProperties.CRMID = 0;
                    adminProperties.CRMAliasID = 0;

                    adminCRUDProperties.dt_Result = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminRead, adminProperties).dt_Result;
                    manageCurrencies.ddlCurrencyName.DataSource = adminCRUDProperties.dt_Result;
                    manageCurrencies.ddlCurrencyName.DataTextField = "Currency Name";
                    manageCurrencies.ddlCurrencyName.DataValueField = "ID";
                    manageCurrencies.ddlCurrencyName.DataBind();

                    manageCurrencies.ddlCurrencyName.Items.Insert(0, "--- Please Select ---");

                    manageCurrencies.btnCRMSave.Text = "Create";
                    manageCurrencies.hdnCurrencyMasterID.Value = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind alias names to dropdown
        /// </summary>
        /// <param name="manageCurrencies">manageCurrencies</param>
        internal void BindCurrencyAlias(ManageCurrencies manageCurrencies)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminProperties.CRMID = 0;
                    adminProperties.CRMAliasID = 0;

                    manageCurrencies.ddlCMAlias.DataSource = (DataTable)adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminRead, adminProperties).dt_Result;
                    manageCurrencies.ddlCMAlias.DataTextField = "Alias";
                    manageCurrencies.ddlCMAlias.DataValueField = "ID";
                    manageCurrencies.ddlCMAlias.DataBind();
                    manageCurrencies.ddlCMAlias.Items.Insert(0, "--- Please Select ---");

                    manageCurrencies.btnCRMSave.Text = "Create";
                    manageCurrencies.hdnCurrencyMasterID.Value = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used for bind the data in GridView 
        /// </summary>
        /// <param name="manageCurrencies">this is manageCurrencies page object</param>
        internal void BindCurrencyDetailsGrid(ManageCurrencies manageCurrencies)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminProperties.CRMID = manageCurrencies.ddlCurrencyName.SelectedValue == ("--- Please Select ---") ? 0 : Convert.ToInt32(manageCurrencies.ddlCurrencyName.SelectedValue);
                    adminProperties.CRMAliasID = manageCurrencies.ddlCMAlias.SelectedValue == ("--- Please Select ---") ? 0 : Convert.ToInt32(manageCurrencies.ddlCMAlias.SelectedValue);
                    manageCurrencies.btnClearFilter.Visible = manageCurrencies.ddlCurrencyName.SelectedValue == ("--- Please Select ---") && manageCurrencies.ddlCMAlias.SelectedValue == ("--- Please Select ---") ? false : true;

                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminRead, adminProperties);
                    ac_ManageCurrency.dt_Currencies = adminCRUDProperties.dt_Result;
                    manageCurrencies.gv.DataSource = ac_ManageCurrency.dt_Currencies;
                    manageCurrencies.gv.DataBind();

                    manageCurrencies.btnCRMDelete.Visible = manageCurrencies.gv.Rows.Count == 0 ? false : true;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to show or hide and set accordion index
        /// </summary>
        /// <param name="manageCurrencies">manageCurrencies</param>
        /// <param name="s_ButtonID">Button ID</param>
        internal void DisplayContents(ManageCurrencies manageCurrencies, string s_ButtonID)
        {
            try
            {
                switch (s_ButtonID)
                {
                    case "":
                        manageCurrencies.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                        manageCurrencies.btnClearFilter.Visible = false;
                        break;

                    case "btnApplyFilter":
                        manageCurrencies.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                        manageCurrencies.hdnAccordionIndex.Value = "0";
                        break;

                    case "btnDelete":
                        manageCurrencies.hdnDeletedRecords.Value = manageCurrencies.hdnDeletedID.Value + manageCurrencies.hdnDeletedRecords.Value;
                        manageCurrencies.hdnCRMCurrencyID.Value = manageCurrencies.hdnCurrencyMasterID.Value;

                        CUDCurrencyDetails(manageCurrencies);

                        manageCurrencies.hdnDeletedID.Value = "";
                        manageCurrencies.hdnAccordionIndex.Value = "0";
                        manageCurrencies.hdnDefaultCurrency.Value = string.Empty;
                        manageCurrencies.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                        break;

                    case "btnClearFilter":
                        manageCurrencies.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                        manageCurrencies.hdnAccordionIndex.Value = "0";
                        break;

                    case "lnkYes":
                        manageCurrencies.btnClearFilter.Visible = false;
                        manageCurrencies.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to Perform CUD Operations
        /// </summary>
        /// <param name="manageCurrencies">manageCurrencies page object</param>
        /// <returns></returns>
        internal int CUDCurrencyDetails(ManageCurrencies manageCurrencies)
        {
            try
            {
                int n_retValue = 0;

                adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.Action = !string.IsNullOrEmpty(manageCurrencies.hdnDeletedRecords.Value) ? "D" : manageCurrencies.hdnCRMCurrencyID.Value == "0" && (string.IsNullOrEmpty(manageCurrencies.hdnCurrencyMasterID.Value)) ? "C" : "U";
                    adminProperties.CurrencyName = manageCurrencies.txtCurrencyName.Text;
                    adminProperties.CurrencyNameAlias = manageCurrencies.txtCurrencyAlias.Text;
                    adminProperties.IsDefault = manageCurrencies.chkCRMIsDefault.Checked ? true : false;
                    adminProperties.IsDeleted = string.IsNullOrEmpty(manageCurrencies.hdnDeletedRecords.Value) ? false : true;
                    adminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    adminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    adminProperties.CRMID = adminProperties.Action == "U" ? Convert.ToInt32(manageCurrencies.hdnCurrencyMasterID.Value) : string.IsNullOrEmpty(manageCurrencies.hdnCRMCurrencyID.Value) ? 0 : Convert.ToInt32(manageCurrencies.hdnCRMCurrencyID.Value);
                    adminProperties.CRMID = adminProperties.Action == "C" ? 0 : adminProperties.CRMID;
                    adminProperties.DeleteIDs = string.IsNullOrEmpty(manageCurrencies.hdnDeletedRecords.Value) ? string.Empty : manageCurrencies.hdnDeletedRecords.Value.TrimStart(',');

                    manageCurrencies.txtCurrencyName.Text = "";
                    manageCurrencies.txtCurrencyAlias.Text = "";
                    manageCurrencies.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                    if (manageCurrencies.hdnDefaultCurrency.Value.ToUpper().Equals("YES") || manageCurrencies.SelectAllChecked.Value.Equals("true"))
                    {
                        string s_IsDefault = (from r in ac_ManageCurrency.dt_Currencies.AsEnumerable()
                                              where r.Field<string>("Default Currency") == "Yes"
                                              select r.Field<string>("Default Currency")).First<string>();
                        if (s_IsDefault.Equals("Yes"))
                        {
                            adminCRUDProperties.a_result = 6;
                        }
                    }
                    else if(!manageCurrencies.chkCRMIsDefault.Checked && adminProperties.Action.Equals("U"))
                    {
                        int s_IsDefault = (from r in ac_ManageCurrency.dt_Currencies.AsEnumerable()
                                           where r.Field<string>("Default Currency") == "Yes"
                                           select r.Field<int>("ID")).First<int>();
                        adminCRUDProperties.a_result = s_IsDefault.Equals(adminProperties.CRMID) ? 7 : adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminCUD, adminProperties).a_result;
                    }
                    else
                    {
                        adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminCUD, adminProperties);
                    }

                    manageCurrencies.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                    manageCurrencies.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    manageCurrencies.chkCRMIsDefault.Checked = adminProperties.IsDefault == true ? true : false;

                    switch (adminCRUDProperties.a_result)
                    {
                        case 0:
                            manageCurrencies.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMError", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            n_retValue = 0;
                            break;

                        case 1:
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMCreated", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            n_retValue = 0;
                            n_retValue = 1;
                            break;

                        case 2:
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMUpdated", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            manageCurrencies.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            n_retValue = 2;
                            break;

                        case 3:
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMDeleted", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            n_retValue = 3;
                            break;

                        case 4:
                            manageCurrencies.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMIsExist", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            n_retValue = 3;
                            break;

                        case 5:
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMActivate", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            manageCurrencies.ctrSuccessErrorMessage.s_RevOptionsDisplay = "block";
                            ac_ManageCurrency.s_CurrencyName = adminProperties.CurrencyName;
                            n_retValue = 3;
                            break;

                        case 6:
                            manageCurrencies.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMDefaultCurrency", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            manageCurrencies.hdnDeletedRecords.Value = string.Empty;
                            manageCurrencies.SelectAllChecked.Value = string.Empty;
                            n_retValue = 3;
                            break;

                        case 7:
                            manageCurrencies.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMchkIsdefault", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            manageCurrencies.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                            n_retValue = 2;
                            break;
                    }
                    return n_retValue;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to activate deleted currency
        /// </summary>
        /// <param name="manageCurrencies">manageCurrencies page object</param>
        internal void ReactivateCurrencyDetails(ManageCurrencies manageCurrencies)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.Action = "U";
                    adminProperties.CurrencyName = ac_ManageCurrency.s_CurrencyName;
                    adminProperties.IsDefault = manageCurrencies.chkCRMIsDefault.Checked ? true : false;
                    adminProperties.IsDeleted = false;
                    adminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    adminProperties.ModifiedBy = userSessionInfo.ACC_UserID; ;
                    adminProperties.CRMID = 0;
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    manageCurrencies.txtCurrencyName.Text = "";
                    manageCurrencies.txtCurrencyAlias.Text = "";
                    manageCurrencies.chkCRMIsDefault.Checked = false;
                    manageCurrencies.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminCUD, adminProperties);
                   
                    manageCurrencies.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                    manageCurrencies.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";

                    switch (adminCRUDProperties.a_result)
                    {
                        case 0:
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMError", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            break;

                        case 2:
                            manageCurrencies.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMUpdated", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            break;

                        case 3:
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMCurrencyAliasExist", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            break;

                        case 4:
                            manageCurrencies.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCRMIsExist", CommonConstantModel.s_AdManageCurrencies, CommonConstantModel.s_AdminL10);
                            break;

                    }
                    manageCurrencies.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to bind grid rows
        /// </summary>
        /// <param name="e">e</param>
        /// <param name="n_index">index</param>
        /// <param name="n_ID">ID</param>
        /// <param name="n_Delete">Delete</param>
        /// <param name="n_DefaultCurrency">Default Currency</param>
        /// <param name="n_Action">Action</param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_DefaultCurrency, ref int n_Action)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    n_Delete = n_index;
                                    e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                    break;

                                case "DEFAULT CURRENCY":
                                    n_DefaultCurrency = n_index;
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_Delete].HorizontalAlign = e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, "Edit"));
                        e.Row.Cells[n_Delete].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[n_DefaultCurrency].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to add image button to grid column
        /// </summary>
        /// <param name="s_strToolTip">Tooltip</param>
        /// <param name="s_strUrl">URL</param>
        /// <param name="s_CurrencyID">CurrencyID</param>
        /// <param name="s_CurrencyName">CurrencyName</param>
        /// <param name="s_Status">Status</param>
        /// <param name="s_IsDefault">IsDefault</param>
        /// <param name="s_Action">Action</param>
        /// <returns>ImageButton</returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_CurrencyID, string s_CurrencyName, string s_Status, string s_IsDefault, string s_Action)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");

                if (!string.IsNullOrEmpty(s_CurrencyName))
                {
                    imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_CurrencyName + "','" + s_Status + "','" + s_CurrencyID + "','" + s_IsDefault + "')");
                }

                return imgButton;
            }
        }

        /// <summary>
        /// This Method is used to add checkbox to grid row
        /// </summary>
        /// <param name="s_CurrencyID">CurrencyID</param>
        /// <param name="s_DefaultCurrency">this is default currency</param>
        /// <param name="IsDeleted">IsDeleted</param>
        /// <returns>CheckBox</returns>
        private CheckBox AddCheckBox(string s_CurrencyID, string s_DefaultCurrency, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_CurrencyID);
                checkBox.ID = "chk" + s_CurrencyID;
                checkBox.Checked = IsDeleted;
                checkBox.AutoPostBack = false;
                checkBox.Attributes.Add("name", "Types");
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                if (!string.IsNullOrEmpty(s_CurrencyID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_CurrencyID + "','" + s_DefaultCurrency + "',this)");
                }

                return checkBox;
            }

        }

        /// <summary>
        /// This Method is used to add checkboxes to all grid rows
        /// </summary>
        /// <returns>CheckBox</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chkDeleteAll";
                checkBox.Text = string.Empty;
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }

        /// <summary>
        /// The Page Index Change Event
        /// </summary>
        /// <param name="NewPageIndex">NewPageIndex</param>
        /// <param name="manageCurrencies">manageCurrencies</param>
        internal void PageIndexChanging(int NewPageIndex, ManageCurrencies manageCurrencies)
        {
            try
            {
                manageCurrencies.gv.PageIndex = NewPageIndex;
                manageCurrencies.gv.DataSource = ac_ManageCurrency.dt_Currencies;
                manageCurrencies.gv.DataBind();

                if (!string.IsNullOrEmpty(manageCurrencies.hdnDeletedRecords.Value))
                {
                    string[] s_hdnIDs = manageCurrencies.hdnDeletedRecords.Value.TrimStart(',').Split(',');
                    foreach (string s_PerID in s_hdnIDs)
                    {
                        foreach (DataRow perRow in ac_ManageCurrency.dt_Currencies.Select("ID ='" + s_PerID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
                manageCurrencies.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Finalizes an instance of the <see cref="ManageCurrenciesModel"/> class.
        /// </summary>
        ~ManageCurrenciesModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}