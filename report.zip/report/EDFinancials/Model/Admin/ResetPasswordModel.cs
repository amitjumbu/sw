﻿using EDFinancials.Model.Generic;
using EDFinancials.View.Admin;
using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Text;

namespace EDFinancials.Model.Admin
{
    /// <summary>
    /// The class file for reset password page
    /// </summary>
    public class ResetPasswordModel : BaseModel, IDisposable
    {

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="resetPasswordUI">Object of a page</param>
        internal void ReadL10N_UI(ResetPassword resetPasswordUI)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    using (DataTable dt_AdminL10N_UI = adminServiceClient.GetAdmin_L10N_UI(CommonConstantModel.s_AdResetPassword, CommonConstantModel.s_AdminL10_UI))
                    {
                        if ((dt_AdminL10N_UI != null) && (dt_AdminL10N_UI.Rows.Count > 0))
                        {
                            resetPasswordUI.lblParamLoginID.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblParamLoginID'"))[0]["LabelName"]);
                            resetPasswordUI.lblLoginID.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblLoginID'"))[0]["LabelName"]);
                            resetPasswordUI.btnGetUserDetails.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnGetUserDetails'"))[0]["LabelName"]);
                            resetPasswordUI.lblRPEmailID.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblRPEmailID'"))[0]["LabelName"]);
                            resetPasswordUI.lblRPLoginID.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblRPLoginID'"))[0]["LabelName"]);
                            resetPasswordUI.lblRPRole.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblRPRole'"))[0]["LabelName"]);
                            resetPasswordUI.lblRPStatus.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblRPStatus'"))[0]["LabelName"]);
                            resetPasswordUI.lblRPUserName.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblRPUserName'"))[0]["LabelName"]);
                            resetPasswordUI.lblRPUserType.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblRPUserType'"))[0]["LabelName"]);
                            resetPasswordUI.lblHeader1.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblHeader1'"))[0]["LabelName"]);
                            resetPasswordUI.lblHeader2.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblHeader2'"))[0]["LabelName"]);
                            resetPasswordUI.btnRPResetPassword.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnRPResetPassword'"))[0]["LabelName"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Country Master
        /// </summary>
        /// <param name="resetPasswordUI">UI object</param>
        internal void BindLoginIDs(View.Admin.ResetPassword resetPasswordUI)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.UMID = 0;
                    adminProperties.LoginId = "";
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdResetPassword, "Read", adminProperties);
                    resetPasswordUI.ddlParamLoginID.DataSource = adminCRUDProperties.dt_Result;
                    resetPasswordUI.ddlParamLoginID.DataTextField = "LOGIN_ID";
                    resetPasswordUI.ddlParamLoginID.DataValueField = "UMID";
                    resetPasswordUI.ddlParamLoginID.DataBind();

                    resetPasswordUI.ddlParamLoginID.Items.Insert(0, "--- Please Select ---");

                    resetPasswordUI.tblDetails.Visible = false;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind User Details
        /// </summary>
        /// <param name="resetPasswordUI">UI object</param>
        internal void BindLoginDetailData(View.Admin.ResetPassword resetPasswordUI)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    if (resetPasswordUI.ddlParamLoginID.SelectedIndex > 0 || !string.IsNullOrEmpty(resetPasswordUI.txtLoginID.Text))
                    {
                        adminProperties.UMID = (resetPasswordUI.ddlParamLoginID.SelectedIndex > 0) ? Convert.ToInt32(resetPasswordUI.ddlParamLoginID.SelectedValue) : 0;
                        adminProperties.LoginId = resetPasswordUI.txtLoginID.Text;
                        adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                        adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdResetPassword, "Read", adminProperties);

                        using (DataTable dt_LoginDetails = adminCRUDProperties.dt_Result)
                        {
                            if ((dt_LoginDetails != null) && (dt_LoginDetails.Rows.Count > 0))
                            {
                                resetPasswordUI.lblRPViewEmailID.Text = Convert.ToString(dt_LoginDetails.Select("UMID = '" + adminProperties.UMID + "' OR LOGIN_ID = '" + adminProperties.LoginId + "'")[0]["EMAIL_ID"]);
                                resetPasswordUI.lblRPViewLoginID.Text = Convert.ToString(dt_LoginDetails.Select("UMID = '" + adminProperties.UMID + "' OR LOGIN_ID = '" + adminProperties.LoginId + "'")[0]["LOGIN_ID"]);
                                resetPasswordUI.lblRPViewRole.Text = Convert.ToString(dt_LoginDetails.Select("UMID = '" + adminProperties.UMID + "' OR LOGIN_ID = '" + adminProperties.LoginId + "'")[0]["ROLE"]);
                                resetPasswordUI.lblRPViewStatus.Text = Convert.ToString(dt_LoginDetails.Select("UMID = '" + adminProperties.UMID + "' OR LOGIN_ID = '" + adminProperties.LoginId + "'")[0]["IS_ACTIVE"]);
                                resetPasswordUI.lblRPViewUserName.Text = Convert.ToString(dt_LoginDetails.Select("UMID = '" + adminProperties.UMID + "' OR LOGIN_ID = '" + adminProperties.LoginId + "'")[0]["USER_NAME"]);
                                resetPasswordUI.lblRPViewUserType.Text = Convert.ToString(dt_LoginDetails.Select("UMID = '" + adminProperties.UMID + "' OR LOGIN_ID = '" + adminProperties.LoginId + "'")[0]["USER_TYPE_ID"]);
                                resetPasswordUI.hdnUserID.Value = Convert.ToString(dt_LoginDetails.Select("UMID = '" + adminProperties.UMID + "' OR LOGIN_ID = '" + adminProperties.LoginId + "'")[0]["UMID"]);
                                resetPasswordUI.hdnOldPassword.Value = Convert.ToString(dt_LoginDetails.Select("UMID = '" + adminProperties.UMID + "' OR LOGIN_ID = '" + adminProperties.LoginId + "'")[0]["LOGIN_PASSWORD"]);
                                resetPasswordUI.tblDetails.Visible = true;
                                resetPasswordUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                            }
                            else
                            {
                                resetPasswordUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                resetPasswordUI.tblDetails.Visible = false;
                                resetPasswordUI.ctrSuccessErrorMessage.s_MessageText = new AdminServiceClient().GetAdmin_L10N("lblRPInvalid", CommonConstantModel.s_AdResetPassword, CommonConstantModel.s_AdminL10);
                            }
                        }
                    }
                    else
                    {
                        resetPasswordUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                        resetPasswordUI.tblDetails.Visible = false;
                        resetPasswordUI.ctrSuccessErrorMessage.s_MessageText = new AdminServiceClient().GetAdmin_L10N("lblRPSelectLoginID", CommonConstantModel.s_AdResetPassword, CommonConstantModel.s_AdminL10);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind User Details
        /// </summary>
        /// <param name="resetPasswordUI">UI object</param>
        internal void ResetPassword(View.Admin.ResetPassword resetPasswordUI)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    if (!string.IsNullOrEmpty(resetPasswordUI.ddlParamLoginID.SelectedValue))
                    {
                        adminProperties.UMID = Convert.ToInt32(resetPasswordUI.hdnUserID.Value);
                        adminProperties.Action = "P";
                        adminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        adminProperties.Old_Password = resetPasswordUI.hdnOldPassword.Value;
                        adminProperties.New_Password = CreatePassword(6);
                        adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdResetPassword, "CUD", adminProperties);

                        switch (adminCRUDProperties.a_result)
                        {
                            case 0:
                                resetPasswordUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblRPProblem", CommonConstantModel.s_AdResetPassword, CommonConstantModel.s_AdminL10) + " for LoginID : " + resetPasswordUI.lblRPViewLoginID.Text;
                                resetPasswordUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                break;

                            case 2:
                                resetPasswordUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblRPUpdated", CommonConstantModel.s_AdResetPassword, CommonConstantModel.s_AdminL10) + " for LoginID : " + resetPasswordUI.lblRPViewLoginID.Text;
                                resetPasswordUI.txtLoginID.Text = string.Empty;
                                resetPasswordUI.ddlParamLoginID.SelectedIndex = -1;

                                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                                {
                                    emailProperties.s_MailTo = resetPasswordUI.lblRPViewEmailID.Text;
                                    emailProperties.s_MailFrom = ConfigurationManager.AppSettings["MailFrom"];
                                    emailProperties.s_MailSubject = ConfigurationManager.AppSettings["MailSubjectRP"];
                                    emailProperties.s_MailBCC = ConfigurationManager.AppSettings["MailBCC"];
                                    emailProperties.s_MailCC = ConfigurationManager.AppSettings["MailCC"];
                                    emailProperties.s_MailBody = MailBody(adminProperties.New_Password, resetPasswordUI);
                                    emailProperties.b_IsBodyHtml = true;

                                    genericServiceClient.SaveSendMail(emailProperties);
                                }

                                resetPasswordUI.tblDetails.Visible = false;
                                resetPasswordUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                                break;

                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to generate random password
        /// </summary>
        /// <param name="length">Define length of password</param>
        /// <returns>Random generated password</returns>
        public string CreatePassword(int length)
        {
            try
            {
                const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
                StringBuilder stringBuilder = new StringBuilder();
                Random rnd = new Random();
                while (0 < length--)
                {
                    stringBuilder.Append(valid[rnd.Next(valid.Length)]);
                }
                return stringBuilder.ToString();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Append parameters in MailBody
        /// </summary>
        /// <param name="s_NewPassword">New generated password</param>
        /// <param name="resetPasswordUI">UI object</param>
        /// <returns>Mailbody in for of string</returns>
        public string MailBody(string s_NewPassword, View.Admin.ResetPassword resetPasswordUI)
        {
            try
            {
                StringBuilder s_MailBody = new StringBuilder();
                s_MailBody.Append(File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\ResetPasswordAdmin.html"));
                s_MailBody.Replace("&lt;User Contact name&gt;", resetPasswordUI.lblRPViewUserName.Text);
                s_MailBody.Replace("&lt;URL&gt;", ConfigurationManager.AppSettings["SiteURL"]);
                s_MailBody.Replace("&lt;LoginName&gt;", resetPasswordUI.lblRPViewLoginID.Text);
                s_MailBody.Replace("&lt;Password&gt;", s_NewPassword);
                s_MailBody.Replace("&lt;Company&gt;", userSessionInfo.ACC_CompanyName);
                s_MailBody.Replace("&lt;Valuation&gt;", ConfigurationManager.AppSettings["ValCustSupport"]);
                return s_MailBody.ToString();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~ResetPasswordModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}