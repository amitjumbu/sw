﻿using EDFinancials.Model.Generic;
using EDFinancials.View.Admin;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.Admin
{
    /// <summary>
    /// This is Model class manage Role page.
    /// </summary>
    public class ManageRolesModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ManageRolesModel"/> class.  
        /// </summary>
        public ManageRolesModel()
        {
            if (ac_ManageRoles == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageRoles);
                ac_ManageRoles = (CommonModel.AC_ManageRoles)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageRoles];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnCreateText = string.Empty, s_BtnCreateToolTip = string.Empty, s_BtnSubmitText = string.Empty, s_BtnSubmitTooltip = string.Empty;

        #endregion


        /// <summary>
        /// This Method is used to bind labels to controls from  xml file
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void BindUI(ManageRoles manageRoles)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    using (DataTable dt_ManageRolesUI = adminServiceClient.GetAdmin_L10N_UI(CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10_UI))
                    {
                        if ((dt_ManageRolesUI != null) && (dt_ManageRolesUI.Rows.Count > 0))
                        {
                            manageRoles.lblMRSPageName.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'lblMRSPageName'"))[0]["LabelName"]);
                            manageRoles.lblMRSPaneOneHeader.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'lblMRSPaneOneHeader'"))[0]["LabelName"]);
                            manageRoles.lblMRSPaneTwoHeader.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'lblMRSPaneTwoHeader'"))[0]["LabelName"]);
                            manageRoles.lblMRSRoleName.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'lblMRSRoleName'"))[0]["LabelName"]);
                            manageRoles.lblMRSStatus.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'lblMRSStatus'"))[0]["LabelName"]);
                            manageRoles.btnMRSApplyFilter.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSApplyFilter'"))[0]["LabelName"]);
                            manageRoles.btnMRSCreateNew.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSCreateNew'"))[0]["LabelName"]);
                            manageRoles.btnMRSClearFilter.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSClearFilter'"))[0]["LabelName"]);
                            manageRoles.btnMRSDelete.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSDelete'"))[0]["LabelName"]);
                            manageRoles.lblMRSCreateRoleName.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'lblMRSCreateRoleName'"))[0]["LabelName"]);
                            manageRoles.btnMRSSubmit.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSSubmit'"))[0]["LabelName"]);
                            manageRoles.btnMRSReset.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSReset'"))[0]["LabelName"]);
                            manageRoles.btnMRSCancel.Text = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSCancel'"))[0]["LabelName"]);
                            manageRoles.reqFldRoleName.ToolTip = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'reqFldRoleName'"))[0]["ErrorText"]);
                            manageRoles.btnMRSApplyFilter.ToolTip = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSApplyFilter'"))[0]["LabelToolTip"]);
                            manageRoles.btnMRSClearFilter.ToolTip = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSClearFilter'"))[0]["LabelToolTip"]);
                            manageRoles.btnMRSCreateNew.ToolTip = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSCreateNew'"))[0]["LabelToolTip"]);
                            manageRoles.btnMRSDelete.ToolTip = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSDelete'"))[0]["LabelToolTip"]);
                            manageRoles.btnMRSReset.ToolTip = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSReset'"))[0]["LabelToolTip"]);
                            manageRoles.btnMRSSubmit.ToolTip = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSSubmit'"))[0]["LabelToolTip"]);
                            manageRoles.btnMRSCancel.ToolTip = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSCancel'"))[0]["LabelToolTip"]);
                            s_BtnSubmitText = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSSubmit'"))[0]["LabelName"]);
                            s_BtnSubmitTooltip = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSSubmit'"))[0]["LabelToolTip"]);
                            s_BtnCreateText = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSCreate'"))[0]["LabelName"]);
                            s_BtnCreateToolTip = Convert.ToString((dt_ManageRolesUI.Select("LabelID = 'btnMRSCreate'"))[0]["LabelToolTip"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind role names to dropdown list
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void BindRoleName(ManageRoles manageRoles)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminProperties.PopulateControl = "FillDropDown";

                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminRead, adminProperties);
                    manageRoles.ddlMRSRoleName.DataSource = (DataTable)adminCRUDProperties.dt_Result;
                    manageRoles.ddlMRSRoleName.DataTextField = "ROLE_NAME";
                    manageRoles.ddlMRSRoleName.DataValueField = "RMID";
                    manageRoles.ddlMRSRoleName.DataBind();

                    manageRoles.ddlMRSRoleName.Items.Insert(0, "--- Please Select ---");
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind status to Status dropdown list
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void BindStatus(ManageRoles manageRoles)
        {
            using (AdminServiceClient adminServiceClient = new AdminServiceClient())
            {
                manageRoles.ddlMRSStatus.Items.Clear();
                manageRoles.ddlMRSStatus.Items.Insert(0, "--- Please Select ---");
                manageRoles.ddlMRSStatus.Items.Insert(1, "Activated");
                manageRoles.ddlMRSStatus.Items.Insert(2, "Deactivated");
            }
        }

        /// <summary>
        /// This method is used to bind role names to the grid
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void BindGrid(ManageRoles manageRoles)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminProperties.PopulateControl = "FillRoleNameGrid";
                    adminProperties.RMID = manageRoles.ddlMRSRoleName.SelectedItem.Text == ("--- Please Select ---") ? 0 : Convert.ToInt32(manageRoles.ddlMRSRoleName.SelectedItem.Value);
                    adminProperties.StatusID = manageRoles.ddlMRSStatus.SelectedItem.Text == ("--- Please Select ---") ? 0 : (manageRoles.ddlMRSStatus.SelectedItem.Text == ("Activated") ? 2 : 1);
                    manageRoles.btnMRSClearFilter.Visible = ((manageRoles.ddlMRSRoleName.SelectedValue == ("--- Please Select ---") && manageRoles.ddlMRSStatus.SelectedValue == ("--- Please Select ---"))) ? false : true;

                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminRead, adminProperties);
                    ac_ManageRoles.dt_ManageRoles = adminCRUDProperties.dt_Result;
                    ac_ManageRoles.dt_ManageRoles.AcceptChanges();
                    manageRoles.gv.DataSource = ac_ManageRoles.dt_ManageRoles;
                    manageRoles.gv.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind role privileges to the grid
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void BindGridRights(ManageRoles manageRoles)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    using (DataTable dt_Menu = BindEmptyPriviledges(manageRoles, adminServiceClient, "BLANK"))
                    {
                        using (DataTable dt_BindMenus = BindEmptyPriviledges(manageRoles, adminServiceClient, "NBLANK"))
                        {
                            using (DataTable dt_Priviledges = (DataTable)adminCRUDProperties.dt_Result)
                            {
                                foreach (DataRow perRow in dt_Priviledges.Rows)
                                {
                                    DataRow[] dataRowMenu = dt_Menu.Select("MMID = '" + perRow["MMID"] + "'");

                                    dataRowMenu[0]["View"] = perRow["View"];
                                    dataRowMenu[0]["Add"] = perRow["Add"];
                                    dataRowMenu[0]["Edit"] = perRow["Edit"];
                                    dataRowMenu[0]["Delete"] = perRow["Delete"];
                                    dataRowMenu[0]["Approve"] = perRow["Approve"];
                                    dataRowMenu[0]["Disapprove"] = perRow["Disapprove"];
                                    dataRowMenu[0]["Locked"] = perRow["Locked"];
                                    dataRowMenu[0]["Unlocked"] = perRow["Unlocked"];

                                    dt_Menu.AcceptChanges();
                                }
                            }

                            manageRoles.hdnRowCount.Value = Convert.ToString(dt_Menu.Rows.Count);
                            DataRow[] dr_ViewCount = dt_Menu.Select("View=" + Convert.ToString(1));
                            DataRow[] dr_AddCount = dt_Menu.Select("Add=" + Convert.ToString(1));
                            DataRow[] dr_EditCount = dt_Menu.Select("Edit=" + Convert.ToString(1));
                            DataRow[] dr_DeleteCount = dt_Menu.Select("Delete=" + Convert.ToString(1));
                            DataRow[] dr_ApproveCount = dt_Menu.Select("Approve=" + Convert.ToString(1));
                            DataRow[] dr_DisApproveCount = dt_Menu.Select("Disapprove=" + Convert.ToString(1));
                            DataRow[] dr_LockedCount = dt_Menu.Select("Locked=" + Convert.ToString(1));
                            DataRow[] dr_UnlockedCount = dt_Menu.Select("Unlocked=" + Convert.ToString(1));

                            if (dr_ViewCount.Length == Convert.ToInt32(manageRoles.hdnRowCount.Value))
                                manageRoles.hdnVCount.Value = "checked";

                            if (dr_AddCount.Length == Convert.ToInt32(manageRoles.hdnRowCount.Value))
                                manageRoles.hdnACount.Value = "checked";

                            if (dr_EditCount.Length == Convert.ToInt32(manageRoles.hdnRowCount.Value))
                                manageRoles.hdnECount.Value = "checked";

                            if (dr_DeleteCount.Length == Convert.ToInt32(manageRoles.hdnRowCount.Value))
                                manageRoles.hdnDCount.Value = "checked";

                            if (dr_ApproveCount.Length == Convert.ToInt32(manageRoles.hdnRowCount.Value))
                                manageRoles.hdnPCount.Value = "checked";

                            if (dr_DisApproveCount.Length == Convert.ToInt32(manageRoles.hdnRowCount.Value))
                                manageRoles.hdnICount.Value = "checked";

                            if (dr_LockedCount.Length == Convert.ToInt32(manageRoles.hdnRowCount.Value))
                                manageRoles.hdnLCount.Value = "checked";

                            if (dr_UnlockedCount.Length == Convert.ToInt32(manageRoles.hdnRowCount.Value))
                                manageRoles.hdnUCount.Value = "checked";

                            manageRoles.gvPriviledges.DataSource = dt_Menu;
                            manageRoles.gvPriviledges.DataBind();
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to Display or Hide and Set Accordion Index
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        /// <param name="s_ButtonID">Button ID</param>
        internal void DisplayControls(ManageRoles manageRoles, string s_ButtonID)
        {
            try
            {
                manageRoles.divrevOptions.Visible = false;
                manageRoles.divMessegebox.Style.Add("display", "none");

                switch (s_ButtonID)
                {
                    case "":
                        manageRoles.btnMRSDelete.Visible = manageRoles.gv.Rows.Count > 0 ? true : false;
                        manageRoles.hdnAccordionIndex.Value = "0";
                        break;

                    case "btnMRShdnCreateNew":
                        manageRoles.hdnSavedIDs.Value = "";
                        manageRoles.hdnAccordionIndex.Value = "1";
                        manageRoles.btnMRSDelete.Visible = manageRoles.gv.Rows.Count > 0 ? true : false;
                        manageRoles.h3AddEdit.Style.Add("display", "block");
                        break;

                    case "btnMRSDelete":
                        manageRoles.ddlMRSStatus.SelectedIndex = -1;
                        manageRoles.btnMRSDelete.Visible = manageRoles.gv.Rows.Count > 0 ? true : false;
                        manageRoles.hdnDeletedRecords.Value = string.Empty;
                        manageRoles.divMessegebox.Style.Add("display", "block");
                        manageRoles.h3AddEdit.Style.Add("display", "none");
                        break;

                    case "btnMRSApplyFilter":
                        manageRoles.hdnDeletedRecords.Value = string.Empty;
                        manageRoles.h3AddEdit.Style.Add("display", "none");
                        manageRoles.btnMRSDelete.Visible = manageRoles.gv.Rows.Count > 0 ? true : false;
                        manageRoles.hdnAccordionIndex.Value = "0";
                        break;

                    case "btnMRSClearFilter":
                        manageRoles.btnMRSDelete.Visible = manageRoles.gv.Rows.Count > 0 ? true : false;
                        break;

                    case "btnMRSChangeStatus":
                        manageRoles.hdnRMID.Value = "";
                        manageRoles.divMessegebox.Style.Add("display", "block");
                        manageRoles.h3AddEdit.Style.Add("display", "none");
                        break;

                    case "btnMRPriviledgeGrid":
                        manageRoles.ddlMRSStatus.SelectedIndex = -1;
                        manageRoles.hdnAccordionIndex.Value = "1";
                        manageRoles.btnMRSClearFilter.Visible = false;
                        manageRoles.h3AddEdit.Style.Add("display", "block");
                        break;

                    case "lnkBtnYes":
                        manageRoles.divMessegebox.Style.Add("display", "block");
                        manageRoles.btnMRSDelete.Visible = manageRoles.gv.Rows.Count > 0 ? true : false;
                        break;

                    case "lnkBtnNo":
                        manageRoles.btnMRSDelete.Visible = manageRoles.gv.Rows.Count > 0 ? true : false;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind empty grid view.
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        /// <param name="adminServiceClient">adminServiceClient</param>
        /// <param name="s_RMID">s_RMID</param>
        /// <returns></returns>
        private DataTable BindEmptyPriviledges(ManageRoles manageRoles, AdminServiceClient adminServiceClient, string s_RMID)
        {
            try
            {
                adminProperties.PopulateControl = s_RMID.Equals("BLANK") ? "ReadMenu" : "ReadPriviledges";

                adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                if (s_RMID.Equals("BLANK"))
                {
                    adminProperties.RMID = 0;
                }
                else if (s_RMID.Equals("NBLANK"))
                {
                    adminProperties.RMID = string.IsNullOrEmpty(manageRoles.hdnAction.Value) ? 0 : Convert.ToInt32(manageRoles.hdnRMID.Value);
                }
                else
                {
                    adminProperties.RMID = string.IsNullOrEmpty(manageRoles.hdnAction.Value) ? 0 : Convert.ToInt32(manageRoles.hdnRMID.Value);
                }

                adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminRead, adminProperties);

                DataTable dt_Menu = BindRolePriviledges();
                return dt_Menu;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind role privileges to the grid
        /// </summary>
        /// <returns>DataTable</returns>
        private DataTable BindRolePriviledges()
        {
            try
            {
                DataTable dt_Menu = (DataTable)adminCRUDProperties.dt_Result;
                DataTable dt_Privilegde = (DataTable)adminCRUDProperties.dt_Result;

                if (dt_Privilegde.Columns.Count.Equals(3))
                {
                    DataTable dt_TempRolePriviledges = new DataTable();
                    dt_TempRolePriviledges.Columns.Add("View", typeof(string));
                    dt_TempRolePriviledges.Columns.Add("Add", typeof(string));
                    dt_TempRolePriviledges.Columns.Add("Edit", typeof(string));
                    dt_TempRolePriviledges.Columns.Add("Delete", typeof(string));
                    dt_TempRolePriviledges.Columns.Add("Approve", typeof(string));
                    dt_TempRolePriviledges.Columns.Add("Disapprove", typeof(string));
                    dt_TempRolePriviledges.Columns.Add("Locked", typeof(string));
                    dt_TempRolePriviledges.Columns.Add("Unlocked", typeof(string));

                    dt_TempRolePriviledges.Columns["View"].DefaultValue = "0";
                    dt_TempRolePriviledges.Columns["Add"].DefaultValue = "0";
                    dt_TempRolePriviledges.Columns["Edit"].DefaultValue = "0";
                    dt_TempRolePriviledges.Columns["Delete"].DefaultValue = "0";
                    dt_TempRolePriviledges.Columns["Approve"].DefaultValue = "0";
                    dt_TempRolePriviledges.Columns["Disapprove"].DefaultValue = "0";
                    dt_TempRolePriviledges.Columns["Locked"].DefaultValue = "0";
                    dt_TempRolePriviledges.Columns["Unlocked"].DefaultValue = "0";

                    dt_Menu.Merge(dt_TempRolePriviledges);
                }

                return dt_Menu;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to perform CUD Operations
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        /// <returns>Result n_retValue</returns>
        internal int CUDManageRoles(ManageRoles manageRoles)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    if (string.IsNullOrEmpty(manageRoles.hdnRMID.Value) && !string.IsNullOrEmpty(manageRoles.hdnDeletedRecords.Value))
                    {
                        string[] s_IsDefaultRole = Convert.ToString(manageRoles.hdnDeletedRecords.Value).Split(',');

                        for(int n_ArrayCnt = 0 ; n_ArrayCnt < (s_IsDefaultRole.Length - 1) ; n_ArrayCnt++)
                        {
                            var v_RoleName = (from row in ac_ManageRoles.dt_ManageRoles.AsEnumerable()
                                             where row.Field<int>("RMID") == Convert.ToInt32(s_IsDefaultRole[n_ArrayCnt + 1])
                                             select row.Field<string>("Role Name")).SingleOrDefault();

                            if (Convert.ToString(v_RoleName) == "COMPLETE_ACCESS" || Convert.ToString(v_RoleName) == "PARTIAL_ACCESS")
                            {
                                adminProperties.Action = "";
                                adminCRUDProperties.a_result = 11;
                                break;
                            }
                            else
                                adminProperties.Action = "D";
                        }
                    }
                    else if (!string.IsNullOrEmpty(manageRoles.hdnStatus.Value) && string.IsNullOrEmpty(manageRoles.hdnViewRecords.Value))
                        adminProperties.Action = "S";
                    else
                        adminProperties.Action = string.IsNullOrEmpty(manageRoles.hdnRMID.Value) ? "C" : "U";

                    switch (adminProperties.Action)
                    {
                        case "D":
                            adminProperties.IsActive = manageRoles.hdnStatus.Value == "Activated" ? 2 : 1;
                            adminProperties.HiddenPriviledges = manageRoles.hdnAddRecords.Value;
                            adminProperties.IsDeleted = string.IsNullOrEmpty(manageRoles.hdnDeletedRecords.Value) ? false : true;
                            break;

                        case "S":
                            adminProperties.IsActive = manageRoles.hdnStatus.Value == "Activated" ? 1 : 2;
                            adminProperties.HiddenPriviledges = manageRoles.hdnAddRecords.Value;
                            adminProperties.IsDeleted = string.IsNullOrEmpty(manageRoles.hdnDeletedRecords.Value) ? false : true;
                            break;

                        case "C":
                            adminProperties.IsActive = manageRoles.hdnStatus.Value == "Activated" ? 2 : 1;
                            adminProperties.HiddenPriviledges = manageRoles.hdnAddRecords.Value.TrimStart(',');
                            adminProperties.IsDeleted = string.IsNullOrEmpty(manageRoles.hdnIsDeleted.Value) ? false : true;
                            adminProperties.IsFlag = manageRoles.hdnIsDeleted.Value;
                            break;

                        case "U":
                            adminProperties.IsActive = manageRoles.hdnStatus.Value == "Activated" ? 2 : 1;
                            adminProperties.HiddenPriviledges = manageRoles.hdnAddRecords.Value.TrimStart(',');
                            adminProperties.IsDeleted = string.IsNullOrEmpty(manageRoles.hdnDeletedRecords.Value) ? false : true;
                            break;
                    }

                    int n_retValue = 0;

                    if (adminProperties.Action != "")
                    {
                        adminProperties.RoleName = manageRoles.txtCreateRoleName.Text;
                        adminProperties.RMID = string.IsNullOrEmpty(manageRoles.hdnRMID.Value) ? 0 : Convert.ToInt32(manageRoles.hdnRMID.Value);

                        adminProperties.DeleteIDs = string.IsNullOrEmpty(manageRoles.hdnDeletedRecords.Value) ? string.Empty : manageRoles.hdnDeletedRecords.Value.TrimStart(',');

                        adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        adminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                        adminProperties.ModifiedBy = userSessionInfo.ACC_UserID;

                        manageRoles.divMessegebox.Style.Add("display", "none");

                        adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminCUD, adminProperties);
                    }

                    switch (adminCRUDProperties.a_result)
                    {
                        case 0:
                            manageRoles.lblMessage.ForeColor = Color.Red;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRError", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            n_retValue = 0;
                            break;

                        case 1:
                            manageRoles.lblMessage.ForeColor = Color.Blue;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRCreated", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            n_retValue = 0;
                            n_retValue = 1;
                            break;

                        case 2:
                            manageRoles.lblMessage.ForeColor = Color.Blue;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRUpdated", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            manageRoles.divrevOptions.Visible = false;
                            n_retValue = 2;
                            break;

                        case 3:
                            manageRoles.lblMessage.ForeColor = Color.Blue;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRDeleted", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            n_retValue = 3;
                            break;

                        case 4:
                            manageRoles.lblMessage.ForeColor = Color.Blue;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRIsExist", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            n_retValue = 3;
                            break;

                        case 5:
                            manageRoles.lblMessage.ForeColor = Color.Blue;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRStatusUpdated", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            n_retValue = 3;
                            break;

                        case 6:
                            manageRoles.lblMessage.ForeColor = Color.Blue;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRActivate", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            manageRoles.divrevOptions.Visible = true;
                            manageRoles.lnkBtnYes.Visible = true;
                            manageRoles.lnkBtnNo.Visible = true;
                            n_retValue = 3;
                            break;

                        case 7:
                            manageRoles.lblMessage.ForeColor = Color.Blue;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRUpdated", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            manageRoles.lnkBtnYes.Visible = false;
                            manageRoles.hdnIsDeleted.Value = string.Empty;
                            adminProperties.IsFlag = string.Empty;
                            n_retValue = 3;
                            break;

                        case 9:
                            manageRoles.lblMessage.ForeColor = Color.Red;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRCantDelete", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            manageRoles.lnkBtnYes.Visible = false;
                            manageRoles.hdnIsDeleted.Value = string.Empty;
                            n_retValue = 3;
                            break;

                        case 10:
                            manageRoles.lblMessage.ForeColor = Color.Red;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRCantDeactivate", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            manageRoles.lnkBtnYes.Visible = false;
                            manageRoles.hdnIsDeleted.Value = string.Empty;
                            n_retValue = 3;
                            break;

                        case 11:
                            manageRoles.lblMessage.ForeColor = Color.Red;
                            manageRoles.divMessegebox.Style.Add("display", "block");
                            manageRoles.lblMessage.Text = adminServiceClient.GetAdmin_L10N("lblMRCantDeleteDefault", CommonConstantModel.s_AdManageRoles, CommonConstantModel.s_AdminL10);
                            manageRoles.lnkBtnYes.Visible = false;
                            manageRoles.hdnIsDeleted.Value = string.Empty;
                            n_retValue = 3;
                            break;
                    }
                    return n_retValue;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used for create new button
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void CreateNew(ManageRoles manageRoles)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    DataTable dt_Menu = BindEmptyPriviledges(manageRoles, adminServiceClient, "BLANK");

                    manageRoles.gvPriviledges.DataSource = dt_Menu;
                    manageRoles.gvPriviledges.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to change status (activate or deactivate)
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void ChangeRoleStatus(ManageRoles manageRoles)
        {
            try
            {
                CUDManageRoles(manageRoles);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used for submit button
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void btnMRSSubmit_Click(ManageRoles manageRoles)
        {
            try
            {
                manageRoles.hdnAddRecords.Value = manageRoles.hdnAddRecords.Value + manageRoles.hdnSavedIDs.Value;
                manageRoles.hdnSavedIDs.Value = "";
                string s_hdnAddRecords = manageRoles.hdnAddRecords.Value;
                manageRoles.hdnAddRecords.Value = string.Empty;
                string[] s_myArray = s_hdnAddRecords.Split(',');
                s_myArray = s_myArray.Distinct().ToArray();
                foreach (string s_hdnArray in s_myArray)
                {
                    manageRoles.hdnAddRecords.Value = manageRoles.hdnAddRecords.Value + "," + s_hdnArray;
                }

                CUDManageRoles(manageRoles);

                BindRoleName(manageRoles);

                BindGrid(manageRoles);

                manageRoles.btnMRSDelete.Visible = manageRoles.gv.Rows.Count > 0 ? true : false;
                manageRoles.hdnAddRecords.Value = "";
                manageRoles.hdnAccordionIndex.Value = "0";
                manageRoles.h3AddEdit.Style.Add("display", "none");
                manageRoles.hdnRMID.Value = "";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is for reset button
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void btnMRSReset_Click(ManageRoles manageRoles)
        {
            try
            {
                manageRoles.hdnSavedIDs.Value = string.IsNullOrEmpty(manageRoles.hdnIsReset.Value) ? manageRoles.hdnSavedIDs.Value + manageRoles.hdnAddRecords.Value : string.Empty;

                ResetGrid(manageRoles);

                manageRoles.hdnAccordionIndex.Value = "1";
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used for reset the role privileges grid
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void ResetGrid(ManageRoles manageRoles)
        {
            try
            {
                BindGrid(manageRoles);

                BindRoleName(manageRoles);

                if (string.IsNullOrEmpty(manageRoles.hdnRMID.Value) || string.IsNullOrEmpty(manageRoles.hdnSavedIDs.Value))
                {
                    manageRoles.txtCreateRoleName.Text = manageRoles.hdnRMID.Value != "0" ? manageRoles.txtCreateRoleName.Text : string.Empty;
                    manageRoles.hdnRMID.Value = "0";
                }
                else
                {
                    manageRoles.hdnSavedIDs.Value = string.Empty;
                }

                BindGridRights(manageRoles);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Grid view Row Bound Method.
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        /// <param name="n_Delete">n_Delete</param>
        /// <param name="n_RMID">n_RMID</param>
        /// <param name="n_RoleName">n_RoleName</param>
        /// <param name="n_IsActive">n_IsActive</param>
        /// <param name="n_Action">n_Action</param>
        /// <param name="n_IsDeleted">n_IsDeleted</param>
        /// <param name="n_index">n_index</param>
        internal void RowDataBound(object sender, GridViewRowEventArgs e, ref int n_Delete, ref int n_RMID, ref int n_RoleName, ref int n_IsActive, ref int n_Action, ref int n_IsDeleted, ref int n_index)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SELECT ALL":
                                    n_Delete = n_index;
                                    e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                    break;

                                case "RMID":
                                    n_RMID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ROLE NAME":
                                    n_RoleName = n_index;
                                    break;

                                case "STATUS":
                                    n_IsActive = n_index;
                                    break;

                                case "IS_DELETED":
                                    n_IsDeleted = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "ACTIONS":
                                    n_Action = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_RMID].Visible = false;
                        e.Row.Cells[n_IsDeleted].Visible = false;
                        e.Row.Cells[n_Delete].HorizontalAlign = e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[n_Delete].Text, e.Row.Cells[n_RMID].Text, e.Row.Cells[n_RoleName].Text, e.Row.Cells[n_IsActive].Text, "Edit"));
                        e.Row.Cells[n_IsActive].Controls.Add(AddLinkButton(e.Row.Cells[n_RMID].Text, e.Row.Cells[n_RoleName].Text, e.Row.Cells[n_IsActive].Text));
                        e.Row.Cells[n_IsActive].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Delete].Controls.Add(AddCheckBox(e.Row.Cells[1].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        break;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used to add header checkbox in role names grid
        /// </summary>
        /// <returns>CheckBox</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chkDeleteAll";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }

        /// <summary>
        /// This method is used to add image button for edit in role names grid
        /// </summary>
        /// <param name="s_strToolTip">s_strToolTip</param>
        /// <param name="s_strUrl">s_strUrl</param>
        /// <param name="s_SelectAll">s_SelectAll</param>
        /// <param name="s_RMID">s_RMID</param>
        /// <param name="s_RoleName">s_RoleName</param>
        /// <param name="s_Status">s_Status</param>
        /// <param name="s_Action">s_Action</param>
        /// <returns>ImageButton</returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_SelectAll, string s_RMID, string s_RoleName, string s_Status, string s_Action)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");
                if (!string.IsNullOrEmpty(s_RoleName))
                {
                    imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_RMID + "','" + s_RoleName + "','" + s_Status + "','" + s_Action + "')");
                }
                return imgButton;
            }
        }

        /// <summary>
        /// This method is used to add activate or deactivate link buttons in grid view. 
        /// </summary>
        /// <param name="s_RMID">s_RMID</param>
        /// <param name="s_RoleName">s_RoleName</param>
        /// <param name="s_IsAcive">s_IsAcive</param>
        /// <returns>LinkButton</returns>
        private LinkButton AddLinkButton(string s_RMID, string s_RoleName, string s_IsAcive)
        {
            using (LinkButton lnkbtn = new LinkButton())
            {
                lnkbtn.Text = s_IsAcive;
                lnkbtn.Style.Add("cursor", "pointer");
                lnkbtn.ForeColor.Equals("Blue");
                lnkbtn.ToolTip = s_IsAcive.Equals("Deactivated") ? "Click here to Activate" : "Click here to Deactivate";
                lnkbtn.ClientIDMode = ClientIDMode.Static;
                lnkbtn.Attributes.Add("onclick", "javascript : return ChangeStatus('" + s_RMID + "','" + s_RoleName + "','" + s_IsAcive + "',this);");
                return lnkbtn;
            }
        }

        /// <summary>
        /// This method is used to add checkboxes in role names grid
        /// </summary>
        /// <param name="s_RMID">s_RMID</param>
        /// <param name="IsDeleted">IsDeleted</param>
        /// <returns>CheckBox</returns>
        private CheckBox AddCheckBox(string s_RMID, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_RMID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");
                if (!string.IsNullOrEmpty(s_RMID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_RMID + "',this)");
                }
                return checkBox;
            }
        }

        /// <summary>
        /// The grid view Privileges Row Bound
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        /// <param name="n_MMID">n_MMID</param>
        /// <param name="n_MenuName">n_MenuName</param>
        /// <param name="n_View">n_View</param>
        /// <param name="n_Add">n_Add</param>
        /// <param name="n_Edit">n_Edit</param>
        /// <param name="n_Delete">n_Delete</param>
        /// <param name="n_Approve">n_Approve</param>
        /// <param name="n_Disapprove">n_Disapprove</param>
        /// <param name="n_Locked">this is lock status</param>
        /// <param name="n_Unlocked">this is unlock status</param>
        /// <param name="n_indexRole">n_indexRole</param>
        /// <param name="hdnSavedIDs">hdnSavedIDs</param>
        /// <param name="manageRoles">manageRoles</param>
        internal void RolesRowDataBound(object sender, GridViewRowEventArgs e, ref int n_MMID, ref int n_MenuName, ref int n_View, ref int n_Add, ref int n_Edit, ref int n_Delete, ref int n_Approve, ref int n_Disapprove, ref int n_Locked, ref int n_Unlocked, ref int n_indexRole, ref HiddenField hdnSavedIDs, ManageRoles manageRoles)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "MMID":
                                    n_MMID = n_indexRole;
                                    perColumn.Visible = false;
                                    break;

                                case "SCREEN NAME":
                                    n_MenuName = n_indexRole;
                                    break;

                                case "VIEW":
                                    n_View = n_indexRole;
                                    e.Row.Cells[n_View].Controls.Add(AddAllChk("View / Upload", "chkViewAll", manageRoles));
                                    break;

                                case "ADD":
                                    n_Add = n_indexRole;
                                    e.Row.Cells[n_Add].Controls.Add(AddAllChk("Add", "chkAddAll", manageRoles));
                                    break;

                                case "EDIT":
                                    n_Edit = n_indexRole;
                                    e.Row.Cells[n_Edit].Controls.Add(AddAllChk("Edit", "chkEditAll", manageRoles));
                                    break;

                                case "DELETE":
                                    n_Delete = n_indexRole;
                                    e.Row.Cells[n_Delete].Controls.Add(AddAllChk("Delete", "chkDeleteAll", manageRoles));
                                    break;

                                case "APPROVE":
                                    n_Approve = n_indexRole;
                                    e.Row.Cells[n_Approve].Controls.Add(AddAllChk("Approve", "chkApproveAll", manageRoles));
                                    break;

                                case "DISAPPROVE":
                                    n_Disapprove = n_indexRole;
                                    e.Row.Cells[n_Disapprove].Controls.Add(AddAllChk("Disapprove", "chkDisapproveAll", manageRoles));
                                    break;

                                case "LOCKED":
                                    n_Locked = n_indexRole;
                                    e.Row.Cells[n_Locked].Controls.Add(AddAllChk("Locked", "chkLockedAll", manageRoles));
                                    break;

                                case "UNLOCKED":
                                    n_Unlocked = n_indexRole;
                                    e.Row.Cells[n_Unlocked].Controls.Add(AddAllChk("Unlocked", "chkUnlockedAll", manageRoles));
                                    break;
                            }
                            n_indexRole = n_indexRole + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_MMID].Visible = false;
                        e.Row.Cells[n_View].Controls.Add(AddChk(e.Row.Cells[n_MMID].Text, e.Row.Cells[n_View].Text, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, Convert.ToBoolean(Convert.ToInt32(e.Row.Cells[n_View].Text)), hdnSavedIDs));
                        e.Row.Cells[n_Add].Controls.Add(AddChk(e.Row.Cells[n_MMID].Text, string.Empty, e.Row.Cells[n_Add].Text, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, Convert.ToBoolean(Convert.ToInt32(e.Row.Cells[n_Add].Text)), hdnSavedIDs));
                        e.Row.Cells[n_Edit].Controls.Add(AddChk(e.Row.Cells[n_MMID].Text, string.Empty, string.Empty, e.Row.Cells[n_Edit].Text, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, Convert.ToBoolean(Convert.ToInt32(e.Row.Cells[n_Edit].Text)), hdnSavedIDs));
                        e.Row.Cells[n_Delete].Controls.Add(AddChk(e.Row.Cells[n_MMID].Text, string.Empty, string.Empty, string.Empty, e.Row.Cells[n_Delete].Text, string.Empty, string.Empty, string.Empty, string.Empty, Convert.ToBoolean(Convert.ToInt32(e.Row.Cells[n_Delete].Text)), hdnSavedIDs));
                        e.Row.Cells[n_Approve].Controls.Add(AddChk(e.Row.Cells[n_MMID].Text, string.Empty, string.Empty, string.Empty, string.Empty, e.Row.Cells[n_Approve].Text, string.Empty, string.Empty, string.Empty, Convert.ToBoolean(Convert.ToInt32(e.Row.Cells[n_Approve].Text)), hdnSavedIDs));
                        e.Row.Cells[n_Disapprove].Controls.Add(AddChk(e.Row.Cells[n_MMID].Text, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, e.Row.Cells[n_Disapprove].Text, string.Empty, string.Empty, Convert.ToBoolean(Convert.ToInt32(e.Row.Cells[n_Disapprove].Text)), hdnSavedIDs));
                        e.Row.Cells[n_Locked].Controls.Add(AddChk(e.Row.Cells[n_MMID].Text, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, e.Row.Cells[n_Locked].Text, string.Empty, Convert.ToBoolean(Convert.ToInt32(e.Row.Cells[n_Locked].Text)), hdnSavedIDs));
                        e.Row.Cells[n_Unlocked].Controls.Add(AddChk(e.Row.Cells[n_MMID].Text, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, e.Row.Cells[n_Unlocked].Text, Convert.ToBoolean(Convert.ToInt32(e.Row.Cells[n_Unlocked].Text)), hdnSavedIDs));
                        e.Row.Cells[n_View].HorizontalAlign = e.Row.Cells[n_Add].HorizontalAlign = e.Row.Cells[n_Edit].HorizontalAlign = e.Row.Cells[n_Delete].HorizontalAlign = e.Row.Cells[n_Approve].HorizontalAlign = e.Row.Cells[n_Disapprove].HorizontalAlign = e.Row.Cells[n_Locked].HorizontalAlign = e.Row.Cells[n_Unlocked].HorizontalAlign = HorizontalAlign.Center;
                        break;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method used to add header checkbox to grid.
        /// </summary>
        /// <param name="s_Type">s_Type</param>
        /// <param name="s_AttrValue">s_AttrValue</param>
        /// <param name="manageRoles">manageRoles</param>
        /// <returns>CheckBox</returns>
        private CheckBox AddAllChk(string s_Type, string s_AttrValue, ManageRoles manageRoles)
        {
            try
            {
                string s_VarIndex = (s_Type.Equals("View / Upload") ? "0" :
                    s_Type.Equals("Add") ? "1" :
                    s_Type.Equals("Edit") ? "2" :
                    s_Type.Equals("Delete") ? "3" :
                    s_Type.Equals("Approve") ? "4" :
                    s_Type.Equals("Disapprove") ? "5" :
                    s_Type.Equals("Locked") ? "6" :
                    "7");
                CheckBox chkAll = new CheckBox();
                chkAll.ID = s_AttrValue;
                chkAll.Text = s_Type;
                switch (s_AttrValue)
                {
                    case "chkViewAll":
                        chkAll.Checked = manageRoles.hdnVCount.Value == "checked" ? true : false;
                        break;
                    case "chkAddAll":
                        chkAll.Checked = manageRoles.hdnACount.Value == "checked" ? true : false;
                        break;
                    case "chkEditAll":
                        chkAll.Checked = manageRoles.hdnECount.Value == "checked" ? true : false;
                        break;
                    case "chkDeleteAll":
                        chkAll.Checked = manageRoles.hdnDCount.Value == "checked" ? true : false;
                        break;
                    case "chkApproveAll":
                        chkAll.Checked = manageRoles.hdnPCount.Value == "checked" ? true : false;
                        break;
                    case "chkDisapproveAll":
                        chkAll.Checked = manageRoles.hdnICount.Value == "checked" ? true : false;
                        break;
                    case "chkLockedAll":
                        chkAll.Checked = manageRoles.hdnLCount.Value == "checked" ? true : false;
                        break;
                    case "chkUnlockedAll":
                        chkAll.Checked = manageRoles.hdnUCount.Value == "checked" ? true : false;
                        break;
                }
                chkAll.AutoPostBack = false;
                chkAll.InputAttributes.Add("Value", s_AttrValue);
                chkAll.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                chkAll.Attributes.Add("Onclick", "javascript : return SelectViewAllCheckBoxes('" + s_VarIndex + "' ,this);");
                return chkAll;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add checkboxes to each row of grid view.
        /// </summary>
        /// <param name="s_MMID">s_MMID</param>
        /// <param name="s_View">s_View</param>
        /// <param name="s_Add">s_Add</param>
        /// <param name="s_Edit">s_Edit</param>
        /// <param name="s_Delete">s_Delete</param>
        /// <param name="s_Approve">s_Approve</param>
        /// <param name="s_Disapprove">s_Disapprove</param>
        /// <param name="s_Locked">this is Lock flag</param>
        /// <param name="s_Unlocked">this is UnLock flag</param>
        /// <param name="b_IsChecked">b_IsChecked</param>
        /// <param name="hdnSavedIDs">hdnSavedIDs</param>
        /// <returns>CheckBox</returns>
        private CheckBox AddChk(string s_MMID, string s_View, string s_Add, string s_Edit, string s_Delete, string s_Approve, string s_Disapprove, string s_Locked, string s_Unlocked, bool b_IsChecked, HiddenField hdnSavedIDs)
        {
            try
            {
                string s_chkIPType =
                    (!string.IsNullOrEmpty(s_View) ? "V" :
                    !string.IsNullOrEmpty(s_Add) ? "A" :
                    !string.IsNullOrEmpty(s_Edit) ? "E" :
                    !string.IsNullOrEmpty(s_Delete) ? "D" :
                    !string.IsNullOrEmpty(s_Approve) ? "P" :
                    !string.IsNullOrEmpty(s_Disapprove) ? "I" :
                    !string.IsNullOrEmpty(s_Locked) ? "L" :
                    "U");

                using (CheckBox chkBox = new CheckBox())
                {
                    chkBox.Checked = b_IsChecked;
                    string s_Records = s_chkIPType + "_" + s_MMID;
                    chkBox.InputAttributes.Add("Value", s_Records);
                    chkBox.ID = s_chkIPType;
                    chkBox.AutoPostBack = false;
                    chkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;

                    if (b_IsChecked)
                        hdnSavedIDs.Value += "," + s_Records;

                    if (!string.IsNullOrEmpty(s_MMID))
                    {
                        chkBox.Attributes.Add("onclick", "return UpdateCreateRights('" + s_Records + "','" + s_View + "','" + s_Add + "','" + s_Edit + "','" + s_Delete + "','" + s_Approve + "','" + s_Disapprove + "','" + s_Locked + "','" + s_Unlocked + "',this)");
                    }
                    return chkBox;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This is GridView RolePrivileges PreRender Event
        /// </summary>
        /// <param name="manageRoles">manageRoles</param>
        internal void gvPriviledges_PreRender(ManageRoles manageRoles)
        {
            try
            {
                MergeRows(manageRoles.gvPriviledges);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to Merge The Rows In GridView.
        /// </summary>
        /// <param name="gvRolePriviledges">GridView gvRolePriviledges</param>
        public static void MergeRows(GridView gvRolePriviledges)
        {
            for (int rowIndex = gvRolePriviledges.Rows.Count - 2; rowIndex >= 0; rowIndex--)
            {
                GridViewRow row = gvRolePriviledges.Rows[rowIndex];
                GridViewRow previousRow = gvRolePriviledges.Rows[rowIndex + 1];

                for (int i = 0; i < row.Cells.Count; i++)
                {
                    if (!row.Cells[i].Text.Equals("0") && !row.Cells[i].Text.Equals("1"))
                    {
                        if (row.Cells[i].Text == previousRow.Cells[i].Text)
                        {
                            row.Cells[i].RowSpan = previousRow.Cells[i].RowSpan < 2 ? 2 :
                                                   previousRow.Cells[i].RowSpan + 1;
                            previousRow.Cells[i].Visible = false;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// This is Page index change event
        /// </summary>
        /// <param name="NewPageIndex">NewPageIndex</param>
        /// <param name="manageRoles">manageRoles</param>
        internal void PageIndexChanging(int NewPageIndex, ManageRoles manageRoles)
        {
            try
            {
                manageRoles.gv.PageIndex = NewPageIndex;
                manageRoles.gv.DataSource = ac_ManageRoles.dt_ManageRoles;
                manageRoles.gv.DataBind();

                if (!string.IsNullOrEmpty(manageRoles.hdnDeletedRecords.Value))
                {
                    string[] s_StockExgIDs = manageRoles.hdnDeletedRecords.Value.TrimStart(',').Split(',');
                    foreach (string s_PerID in s_StockExgIDs)
                    {
                        foreach (DataRow perRow in ac_ManageRoles.dt_ManageRoles.Select("RMID='" + s_PerID + "'"))
                        {
                            perRow["Select All"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Finalizes an instance of the <see cref="ManageRolesModel"/> class.
        /// </summary>
        ~ManageRolesModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}