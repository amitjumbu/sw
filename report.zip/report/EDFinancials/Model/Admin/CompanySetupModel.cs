﻿using EDFinancials.Model.Generic;
using EDFinancials.Model.User.Valuation;
using EDFinancials.View.Admin;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.Admin
{
    /// <summary>
    /// Model page class of CompanySetup page
    /// </summary>
    public class CompanySetupModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        ///  Initializes a new instance of the <see cref="CompanySetupModel"/> class.
        /// </summary>
        public CompanySetupModel()
        {
            if (ac_CompanySetup == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_CompanySetup);
                ac_CompanySetup = (CommonModel.AC_CompanySetup)HttpContext.Current.Session[CommonConstantModel.s_AC_CompanySetup];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty,
            s_DefaultCurrUpdateMsg = string.Empty, s_AssociateStockExgesMsg = string.Empty, s_AssociateStockMsg = string.Empty, s_DateErrorMsg = string.Empty;

        #endregion

        /// <summary>
        /// This method is used to populate all the controls 
        /// </summary>
        /// <param name="companySetup">CompanySetup page object</param>
        public void PopulateAllControls(CompanySetup companySetup)
        {
            try
            {
                BindUI(companySetup);
                BindControls(companySetup);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to bind all the labels from L10N_UI.xml
        /// </summary>
        /// <param name="companySetup">CompanySetup page object</param>
        private void BindUI(CompanySetup companySetup)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    using (DataTable dt_ManageSEMUI = adminServiceClient.GetAdmin_L10N_UI(CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10_UI))
                    {
                        companySetup.lblCSCompanyName.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSCompanyName'"))[0]["LabelName"]);
                        companySetup.lblCSCompanyName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSCompanyName'"))[0]["LabelToolTip"]);
                        companySetup.lblCSCompanyType.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSCompanyType'"))[0]["LabelName"]);
                        companySetup.lblCSCompanyType.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSCompanyType'"))[0]["LabelToolTip"]);
                        companySetup.lblCSListingStatus.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSListingStatus'"))[0]["LabelName"]);
                        companySetup.lblCSListingStatus.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSListingStatus'"))[0]["LabelToolTip"]);
                        companySetup.btnViewListingStatus.Value = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnViewListingStatus'"))[0]["LabelName"]);
                        companySetup.btnViewListingStatus.Attributes.Add("title", Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnViewListingStatus'"))[0]["LabelToolTip"]));
                        companySetup.btnSESave.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSESave'"))[0]["LabelName"]);
                        companySetup.btnSESave.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSESave'"))[0]["LabelToolTip"]);
                        companySetup.btnSECancel.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSECancel'"))[0]["LabelName"]);
                        companySetup.btnSECancel.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSECancel'"))[0]["LabelToolTip"]);
                        companySetup.btnCSDeleteAll.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSDeleteAll'"))[0]["LabelName"]);
                        companySetup.btnCSDeleteAll.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSDeleteAll'"))[0]["LabelToolTip"]);
                        companySetup.btnCSAdd.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSAdd'"))[0]["LabelName"]);
                        companySetup.btnCSAdd.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSAdd'"))[0]["LabelToolTip"]);
                        companySetup.btnCSSubmit.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSSubmit'"))[0]["LabelName"]);
                        companySetup.btnCSSubmit.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSSubmit'"))[0]["LabelToolTip"]);
                        companySetup.btnReset.Value = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSReset'"))[0]["LabelName"]);
                        companySetup.btnReset.Attributes.Add("title", Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSReset'"))[0]["LabelToolTip"]));
                        companySetup.lblStockExchangeName.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSStockExchangeName'"))[0]["LabelName"]);
                        companySetup.lblStockExchangeName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSStockExchangeName'"))[0]["LabelToolTip"]);
                        companySetup.rfvStockExchangeName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSStockExchangeName'"))[0]["ErrorText"]);
                        companySetup.lblShortName.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSShortName'"))[0]["LabelName"]);
                        companySetup.lblShortName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSShortName'"))[0]["LabelToolTip"]);
                        companySetup.rfvShortName.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSShortName'"))[0]["ErrorText"]);
                        companySetup.lblCIAllFromDateLS.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCIAllFromDateLS'"))[0]["LabelName"]);
                        companySetup.lblCIAllFromDateLS.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCIAllFromDateLS'"))[0]["LabelToolTip"]);
                        companySetup.lblCSPageHeader.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSPageHeader'"))[0]["LabelName"]);
                        companySetup.lblCSCompanySetupPanel.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSPageHeader'"))[0]["LabelName"]);
                        companySetup.lblCSStatusHistory.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSStatusHistory'"))[0]["LabelName"]);
                        companySetup.lblStockExchangeCode.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSStockExchangeCode'"))[0]["LabelName"]);
                        companySetup.lblStockExchangeCode.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSStockExchangeCode'"))[0]["LabelToolTip"]);
                        companySetup.rfvStockExchangeCode.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSStockExchangeCode'"))[0]["ErrorText"]);
                        companySetup.gv.EmptyDataText = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSNoRecordsFound'"))[0]["LabelName"]);
                        companySetup.rfvCIApplFromDateLS.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCIAllFromDateLS'"))[0]["ErrorText"]);
                        companySetup.txtCSCompanyNameRFV.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSCompanyName'"))[0]["ErrorText"]);
                        companySetup.lblCSStockExchangeDetails.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSStockExchangeDetails'"))[0]["LabelName"]);
                        companySetup.lblCSStockExchangeDetails.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSStockExchangeDetails'"))[0]["LabelToolTip"]);
                        companySetup.rfvCurrency.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'rfvCurrency'"))[0]["LabelName"]);
                        companySetup.lblCurrency.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCurrency'"))[0]["LabelName"]);
                        companySetup.lblCurrency.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCurrency'"))[0]["LabelToolTip"]);
                        companySetup.lblCIAddress.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSAddress'"))[0]["LabelName"]);
                        companySetup.lblCIAddress.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSAddress'"))[0]["LabelToolTip"]);
                        companySetup.lblCIContactPerson.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSContactPerson'"))[0]["LabelName"]);
                        companySetup.lblCIContactPerson.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSContactPerson'"))[0]["LabelToolTip"]);
                        companySetup.lblCIDesignation.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSDesignation'"))[0]["LabelName"]);
                        companySetup.lblCIDesignation.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSDesignation'"))[0]["LabelToolTip"]);
                        companySetup.lblCIPhoneNo.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSPhoneNo'"))[0]["LabelName"]);
                        companySetup.lblCIPhoneNo.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSPhoneNo'"))[0]["LabelToolTip"]);
                        companySetup.lblCIEmailID.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSEmailID'"))[0]["LabelName"]);
                        companySetup.lblCIEmailID.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSEmailID'"))[0]["LabelToolTip"]);
                        companySetup.lblCIAuditor.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSAuditor'"))[0]["LabelName"]);
                        companySetup.lblCIAuditor.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSAuditor'"))[0]["LabelToolTip"]);
                        companySetup.lblCIAuditorInternal.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSAuditorInternal'"))[0]["LabelName"]);
                        companySetup.lblCIAuditorInternal.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSAuditorInternal'"))[0]["LabelToolTip"]);
                        companySetup.lblCIAuditorExternal.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSAuditorExternal'"))[0]["LabelName"]);
                        companySetup.lblCIAuditorExternal.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSAuditorExternal'"))[0]["LabelToolTip"]);
                        companySetup.lblCICurrency.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSCurrency'"))[0]["LabelName"]);
                        companySetup.lblCICurrency.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSCurrency'"))[0]["LabelToolTip"]);
                        companySetup.btnCISetDefaultCurrency.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSSetDefaultCurrency'"))[0]["LabelName"]);
                        companySetup.btnCISetDefaultCurrency.ToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSSetDefaultCurrency'"))[0]["LabelToolTip"]);
                        companySetup.lblCSAddEditPanel.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSAddEditPanel'"))[0]["LabelName"]);
                        companySetup.lblCSCompanyNameHistory.Text = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'lblCSCompanyNameHistory'"))[0]["LabelName"]);
                        s_BtnUpdateText = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEUpdate'"))[0]["LabelName"]);
                        s_BtnUpdateToolTip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSEUpdate'"))[0]["LabelToolTip"]);
                        s_BtnSaveText = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSESave'"))[0]["LabelName"]);
                        s_BtnSaveTooltip = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnSESave'"))[0]["LabelToolTip"]);
                        ac_CompanySetup.s_BtnUpdateText = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSUpdate'"))[0]["LabelName"]);
                        ac_CompanySetup.s_BtnCancelText = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSCancel'"))[0]["LabelName"]);
                        ac_CompanySetup.s_BtnEditText = Convert.ToString((dt_ManageSEMUI.Select("LabelID = 'btnCSEdit'"))[0]["LabelName"]);
                        s_DefaultCurrUpdateMsg = adminServiceClient.GetAdmin_L10N("lblCSDefaultCurrUpdateMsg", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                        s_AssociateStockExgesMsg = adminServiceClient.GetAdmin_L10N("lblCSAssociateStockExgesMsg", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                        s_AssociateStockMsg = adminServiceClient.GetAdmin_L10N("lblCSAssociateStockMsg", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                        s_DateErrorMsg = adminServiceClient.GetAdmin_L10N("lblCSDateErrorMessage", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind listing status history to grid view
        /// </summary>
        /// <param name="companySetup">CompanySetup page object</param>
        /// <param name="n_RetValue">return value</param>
        public void ReBindGridView(CompanySetup companySetup, int n_RetValue)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminRead, adminProperties);
                    ac_CompanySetup.ds_CompanyDetails = (DataSet)adminCRUDProperties.ds_Result;

                    /* bind history grid */
                    ac_CompanySetup.dt_ListingHistory = ac_CompanySetup.ds_CompanyDetails.Tables[3];
                    if (ac_CompanySetup.dt_ListingHistory.Rows.Count > 0)
                    {
                        companySetup.gvListingHistory.DataSource = ac_CompanySetup.dt_ListingHistory;
                        companySetup.gvListingHistory.DataBind();
                    }

                    /* bind associated parameters */
                    ac_CompanySetup.dt_AssociatedParameters = ac_CompanySetup.ds_CompanyDetails.Tables[4];
                    if (ac_CompanySetup.dt_AssociatedParameters.Rows.Count > 0)
                    {
                        companySetup.gvAssociatedParams.DataSource = ac_CompanySetup.dt_AssociatedParameters;
                        companySetup.gvAssociatedParams.DataBind();
                    }

                    /* bind Stock exchanges */
                    ac_CompanySetup.dt_StockExchangeDetails = ac_CompanySetup.ds_CompanyDetails.Tables[5];
                    companySetup.gv.DataSource = ac_CompanySetup.dt_StockExchangeDetails;
                    companySetup.gv.DataBind();
                    companySetup.btnCSDeleteAll.Visible = ac_CompanySetup.dt_StockExchangeDetails.Rows.Count > 0;
                    companySetup.hdnAssociatedSECount.Value = (ac_CompanySetup.dt_StockExchangeDetails.Rows.Count > 0) ? Convert.ToString(ac_CompanySetup.dt_StockExchangeDetails.Select("Status = 1").Length) : "0";

                    /* bind Company Name History Data */
                    ac_CompanySetup.dt_CompanyNameHistoryData = ac_CompanySetup.ds_CompanyDetails.Tables[6];
                    companySetup.gvCompanyNameHistory.DataSource = ac_CompanySetup.dt_CompanyNameHistoryData;
                    companySetup.gvCompanyNameHistory.DataBind();

                    if (!n_RetValue.Equals(8))
                        companySetup.hdnCSStockExchangeID.Value = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to bind company associated parameters to grid view
        /// </summary>
        /// <param name="companySetup">CompanySetup page object</param>
        public void BindControls(CompanySetup companySetup)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    int n_DefaultCurrency = 0;

                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminRead, adminProperties);
                    ac_CompanySetup.ds_CompanyDetails = (DataSet)adminCRUDProperties.ds_Result;

                    /* bind Company type dropdown */
                    ac_CompanySetup.dt_CompanyType = ac_CompanySetup.ds_CompanyDetails.Tables[0];
                    companySetup.ddlCSCompanyType.DataSource = ac_CompanySetup.dt_CompanyType;
                    companySetup.ddlCSCompanyType.DataTextField = "COMPANY_TYPE";
                    companySetup.ddlCSCompanyType.DataValueField = "CTID";
                    companySetup.ddlCSCompanyType.DataBind();
                    BindToolTip(companySetup.ddlCSCompanyType);

                    /* bind Currency dropdown */
                    ac_CompanySetup.dt_Currencies = ac_CompanySetup.ds_CompanyDetails.Tables[1];
                    companySetup.ddlCurrency.DataSource = ac_CompanySetup.dt_Currencies;
                    companySetup.ddlCurrency.DataTextField = "Currency Name";
                    companySetup.ddlCurrency.DataValueField = "ID";
                    companySetup.ddlCurrency.DataBind();
                    companySetup.ddlCurrency.Items.Insert(0, new ListItem("--- Please Select ---", "0"));
                    BindToolTip(companySetup.ddlCurrency);

                    IEnumerable<int> query = from CountryList in ac_CompanySetup.dt_Currencies.AsEnumerable()
                                             where CountryList.Field<string>("Default Currency") == "Yes"
                                             select CountryList.Field<int>("ID");
                    foreach (int currID in query)
                    {
                        n_DefaultCurrency = currID;
                    }
                    companySetup.ddlCICurrency.DataSource = ac_CompanySetup.dt_Currencies;
                    companySetup.ddlCICurrency.DataTextField = "Currency Name";
                    companySetup.ddlCICurrency.DataValueField = "ID";
                    companySetup.ddlCICurrency.DataBind();
                    BindToolTip(companySetup.ddlCICurrency);
                    if (n_DefaultCurrency > 0)
                    {
                        companySetup.ddlCICurrency.Items.FindByValue(Convert.ToString(n_DefaultCurrency)).Selected = true;
                        companySetup.hdnUpdatedDefaultCurrID.Value = Convert.ToString(n_DefaultCurrency);
                    }

                    /* bind all input controls */
                    ac_CompanySetup.dt_CompanyDetails = ac_CompanySetup.ds_CompanyDetails.Tables[2];
                    if (ac_CompanySetup.dt_CompanyDetails.Rows.Count > 0)
                    {
                        companySetup.txtCSCompanyName.Text = Convert.ToString(ac_CompanySetup.dt_CompanyDetails.Rows[0]["COMPANY_NAME"]);
                        companySetup.ddlCSCompanyType.SelectedValue = Convert.ToBoolean(ac_CompanySetup.dt_CompanyDetails.Rows[0]["IS_MYESOPS_CLIENT"]) ? "1" : "0";

                        if (Convert.ToBoolean(ac_CompanySetup.dt_CompanyDetails.Rows[0]["Status"]))
                        {
                            companySetup.rbtLstCSListingStatus.Items.FindByValue("1").Selected = true;
                            companySetup.rbtLstCSListingStatus.Items.FindByValue("0").Selected = false;
                            companySetup.trListedSection.Style.Add("display", "");
                            companySetup.hdnIsListed.Value = "true";
                        }
                        else
                        {
                            companySetup.rbtLstCSListingStatus.Items.FindByValue("0").Selected = true;
                            companySetup.rbtLstCSListingStatus.Items.FindByValue("1").Selected = false;
                            companySetup.trListedSection.Style.Add("display", "none");
                            companySetup.hdnIsListed.Value = "false";
                        }
                        companySetup.hdnCSDateOfListing.Value = Convert.ToDateTime(ac_CompanySetup.dt_CompanyDetails.Rows[0]["Listing Date"]).ToString("dd/MMM/yyyy");
                        companySetup.txtCIAddress.Text = Convert.ToString(ac_CompanySetup.dt_CompanyDetails.Rows[0]["ADDRESS"]);
                        companySetup.txtCIContactPerson.Text = Convert.ToString(ac_CompanySetup.dt_CompanyDetails.Rows[0]["CONTACT_PERSON"]);
                        companySetup.txtCIAuditorInternal.Text = Convert.ToString(ac_CompanySetup.dt_CompanyDetails.Rows[0]["INTERNAL_AUDITOR"]);
                        companySetup.txtCIAuditorExternal.Text = Convert.ToString(ac_CompanySetup.dt_CompanyDetails.Rows[0]["EXTERNAL_AUDITOR"]);
                        companySetup.txtCIDesignation.Text = Convert.ToString(ac_CompanySetup.dt_CompanyDetails.Rows[0]["DESIGNATION"]);
                        companySetup.txtCIEmailID.Text = Convert.ToString(ac_CompanySetup.dt_CompanyDetails.Rows[0]["EMAIL_ID"]);
                        companySetup.txtCIPhoneNo.Text = Convert.ToString(ac_CompanySetup.dt_CompanyDetails.Rows[0]["PHONE_NO"]);
                    }

                    /* bind history grid */
                    ac_CompanySetup.dt_ListingHistory = ac_CompanySetup.ds_CompanyDetails.Tables[3];
                    if (ac_CompanySetup.dt_ListingHistory.Rows.Count > 0)
                    {
                        companySetup.gvListingHistory.DataSource = ac_CompanySetup.dt_ListingHistory;
                        companySetup.gvListingHistory.DataBind();
                    }

                    /* bind associated parameters */
                    ac_CompanySetup.dt_AssociatedParameters = ac_CompanySetup.ds_CompanyDetails.Tables[4];
                    if (ac_CompanySetup.dt_AssociatedParameters.Rows.Count > 0)
                    {
                        companySetup.gvAssociatedParams.DataSource = ac_CompanySetup.dt_AssociatedParameters;
                        companySetup.gvAssociatedParams.DataBind();
                    }

                    /* bind Stock exchanges */
                    ac_CompanySetup.dt_StockExchangeDetails = ac_CompanySetup.ds_CompanyDetails.Tables[5];
                    companySetup.gv.DataSource = ac_CompanySetup.dt_StockExchangeDetails;
                    companySetup.gv.DataBind();
                    companySetup.btnCSDeleteAll.Visible = ac_CompanySetup.dt_StockExchangeDetails.Rows.Count > 0;
                    companySetup.hdnAssociatedSECount.Value = (ac_CompanySetup.dt_StockExchangeDetails.Rows.Count > 0) ? Convert.ToString(ac_CompanySetup.dt_StockExchangeDetails.Select("Status = 1").Length) : "0";

                    /* bind Company Name History Data */
                    ac_CompanySetup.dt_CompanyNameHistoryData = ac_CompanySetup.ds_CompanyDetails.Tables[6];
                    companySetup.gvCompanyNameHistory.DataSource = ac_CompanySetup.dt_CompanyNameHistoryData;
                    companySetup.gvCompanyNameHistory.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        /// <param name="n_index">index</param>
        /// <param name="n_ID">SEID row Index</param>
        /// <param name="n_Action">action row index</param>
        /// <param name="n_Delete">delete checkbox row index</param>
        public void RowDataBindForGV(GridViewRowEventArgs e, ref int n_index, ref  int n_ID, ref int n_Action, ref int n_Delete)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "SEID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "SELECT ALL":
                                    n_Delete = n_index;
                                    e.Row.Cells[n_Delete].Controls.Add(AddSelectAllCheckBox());
                                    break;

                                case "STATUS":
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    break;

                                case "CRMID":
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_ID].Visible = e.Row.Cells[6].Visible = false;
                        e.Row.Cells[n_Action].HorizontalAlign = e.Row.Cells[n_Delete].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Action].Controls.Add((Control)AddImageLink(ac_CompanySetup.s_BtnEditText, "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, (string.IsNullOrEmpty(e.Row.Cells[6].Text) || e.Row.Cells[6].Text.Equals("&nbsp;")) ? "0" : e.Row.Cells[6].Text, e.Row.Cells[8].Text));
                        e.Row.Cells[8].Controls.Add((Control)AddHyperLink(e.Row.Cells[8].Text, e.Row.RowIndex));
                        e.Row.Cells[8].Controls.Add((Control)AddDateTextBox(e.Row.RowIndex, "txtAssociateDate_"));
                        e.Row.Cells[8].Controls.Add((Control)AddRFV(e.Row.RowIndex, "rfvAssociateDate_"));
                        e.Row.Cells[8].Controls.Add((Control)AddUpdateButton(e.Row.Cells[0].Text, e.Row.Cells[8].Text, ac_CompanySetup.s_BtnUpdateText, e.Row.RowIndex));
                        e.Row.Cells[8].Controls.Add((Control)AddCancelButton(e.Row.Cells[0].Text, e.Row.Cells[8].Text, ac_CompanySetup.s_BtnCancelText, e.Row.RowIndex));
                        e.Row.Cells[n_Delete].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[n_Delete].Text.Equals("1")));

                        if ((string.IsNullOrEmpty(e.Row.Cells[4].Text.Trim()) || e.Row.Cells[4].Text.Trim().Equals("&nbsp;")) && e.Row.Cells[8].Text.Equals("0"))
                        {
                            e.Row.Cells[4].Controls.Add((Control)AddDateTextBox(e.Row.RowIndex, "txtEditCode_"));
                            e.Row.Cells[4].Controls.Add((Control)AddRFV(e.Row.RowIndex, "rfvEditCode_"));
                        }
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void gvAssociatedParams_RowDataBound(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ACMAID":
                                    perColumn.Visible = false;
                                    break;
                                case "IS_ACTIVE":
                                    perColumn.Visible = false;
                                    break;
                            }
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[0].Visible = e.Row.Cells[5].Visible = false;
                        e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[4].Controls.Add((Control)AddStatusHyperLink(e.Row.Cells[0].Text, e.Row.Cells[5].Text));
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void gvListingHistory_RowDataBound(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.DataRow:
                        e.Row.Cells[1].HorizontalAlign = e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Center;
                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");

                        if (!string.IsNullOrEmpty(e.Row.Cells[2].Text) && !e.Row.Cells[2].Text.Equals("&nbsp;"))
                            e.Row.Cells[2].Text = Convert.ToDateTime(e.Row.Cells[2].Text).ToString("dd/MMM/yyyy");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GridView row data bound event to bind data to grid view
        /// </summary>
        /// <param name="e">Grid View Page Event Args parameter</param>
        public void gvCompanyNameHistory_RowDataBound(GridViewRowEventArgs e)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.DataRow:
                        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                        if (!string.IsNullOrEmpty(e.Row.Cells[1].Text) && !e.Row.Cells[1].Text.Equals("&nbsp;"))
                            e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd/MMM/yyyy");
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add image link to grid view rows
        /// </summary>
        /// <param name="s_BtnEditText">this is image button text </param>
        /// <param name="s_Url">image URL</param>
        /// <param name="s_StockExhchangeID">Stock Exchange ID</param>
        /// <param name="s_StockExhchangeName">Stock Exchange Name</param>
        /// <param name="s_ShortName">Short Name</param>
        /// <param name="s_Code">Stock Exchange Code</param>
        /// <param name="s_CRMID">Currency Master ID</param>
        /// <param name="s_IsAssociated">Stock exchange associated check</param>
        /// <returns>returns image button</returns>
        private ImageButton AddImageLink(string s_BtnEditText, string s_Url, string s_StockExhchangeID, string s_StockExhchangeName, string s_ShortName, string s_Code, string s_CRMID, string s_IsAssociated)
        {
            using (ImageButton img = new ImageButton())
            {
                img.ImageUrl = s_Url;
                img.ToolTip = s_BtnEditText;
                img.Style.Add("cursor", "pointer");
                img.Style.Add("text-align", "center");
                img.TabIndex = 7;
                s_Code = (string.IsNullOrEmpty(s_Code) || s_Code.Equals("&nbsp;")) ? string.Empty : s_Code;
                s_IsAssociated = (string.IsNullOrEmpty(s_IsAssociated) || s_IsAssociated.Equals("0")) ? "0" : "1";
                img.Attributes.Add("onclick", "return ShowEditSection('" + s_StockExhchangeName + "','" + s_ShortName + "','" + s_Code + "','" + s_StockExhchangeID + "','" + ac_CompanySetup.s_BtnUpdateText + "','" + s_CRMID + "','" + s_IsAssociated + "')");
                return img;
            }
        }

        /// <summary>
        /// This method is used to add image link to grid view rows
        /// </summary>
        /// <param name="s_IsAssociated">associated</param>
        /// <param name="n_RowIndex">grid view row index</param>
        /// <returns>returns control Hyper Link</returns>
        private HyperLink AddHyperLink(string s_IsAssociated, int n_RowIndex)
        {
            bool b_IsAssociated = (string.IsNullOrEmpty(s_IsAssociated) || s_IsAssociated.Equals("0")) ? false : true;
            using (HyperLink hyperLink = new HyperLink())
            {
                hyperLink.Text = b_IsAssociated ? "Associated" : "Disassociated";
                hyperLink.ToolTip = b_IsAssociated ? "Click here to Disassociate" : "Click here to Associate";
                hyperLink.ID = "imgAssociate_" + n_RowIndex;
                hyperLink.ClientIDMode = ClientIDMode.Static;
                hyperLink.CssClass = "cHyperLinksp";
                hyperLink.TabIndex = 8;
                hyperLink.Attributes.Add("onclick", "return ShowDatePanel('" + n_RowIndex + "',this)");
                return hyperLink;
            }
        }

        /// <summary>
        /// This method is used to add image link to grid view rows
        /// </summary>
        /// <param name="s_ACMAID">Module association ID</param>
        /// <param name="s_IsActive">active modules</param>
        /// <returns>Returns control HyperLink</returns>
        private HyperLink AddStatusHyperLink(string s_ACMAID, string s_IsActive)
        {
            bool b_IsActive = (string.IsNullOrEmpty(s_IsActive) || s_IsActive.Equals("1")) ? false : true;
            using (HyperLink hyperLink = new HyperLink())
            {
                hyperLink.Text = b_IsActive ? "Activated" : "Deactivated";
                hyperLink.ToolTip = b_IsActive ? "Click here to deactivate" : "Click here to activate";
                hyperLink.ID = "hypActive";
                hyperLink.ClientIDMode = ClientIDMode.Static;
                hyperLink.CssClass = "cHyperLinksp";
                hyperLink.TabIndex = 8;
                hyperLink.Attributes.Add("onclick", "return AssociateModule('" + s_ACMAID + "','" + s_IsActive + "')");
                return hyperLink;
            }
        }

        /// <summary>
        /// This method is used to add image link to grid view rows
        /// </summary>
        /// <param name="n_RowIndex">grid view row index</param>
        /// <param name="txtID">Control Id</param>
        /// <returns>Returns TextBox control</returns>
        private TextBox AddDateTextBox(int n_RowIndex, string txtID)
        {
            try
            {
                using (TextBox textBox = new TextBox())
                {
                    textBox.Style.Add("margin-left", "2px");
                    textBox.Style.Add("width", "87px");
                    textBox.ID = txtID + n_RowIndex;

                    if (txtID.Equals("txtAssociateDate_"))
                    {
                        textBox.Attributes.Add("class", "cTextBoxDatepick datepickerDateAssociated txtAssociateDate");
                        textBox.ToolTip = "Please enter Date";
                    }
                    else
                    {
                        textBox.Attributes.Add("class", "cTextBox txtEditCode");
                        textBox.ToolTip = "Please enter Stock Exchange Code";
                    }

                    textBox.ClientIDMode = ClientIDMode.Static;
                    textBox.Style.Add("display", "none");
                    textBox.ValidationGroup = "AssociateDate_" + n_RowIndex;
                    return textBox;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add image link to grid-view rows
        /// </summary>
        /// <param name="n_RowIndex">grid view row index</param>
        /// <param name="txtID">Control Id</param>
        /// <returns>Returns TextBox control</returns>
        private RequiredFieldValidator AddRFV(int n_RowIndex, string txtID)
        {
            try
            {
                using (RequiredFieldValidator rfv = new RequiredFieldValidator())
                {
                    rfv.ID = txtID + n_RowIndex;
                    rfv.Attributes.Add("Class", "EDValidator");
                    rfv.Style.Add("display", "none");
                    rfv.Display = ValidatorDisplay.Dynamic;
                    rfv.Enabled = true;

                    if (txtID.Equals("rfvAssociateDate_"))
                    {
                        rfv.Attributes.Add("class", "EDValidator rfvAssociateDate");
                        rfv.ControlToValidate = "txtAssociateDate_" + n_RowIndex;
                        rfv.ToolTip = "Please enter Date";
                    }
                    else
                    {
                        rfv.Attributes.Add("class", "EDValidator rfvEditCode");
                        rfv.ControlToValidate = "txtEditCode_" + n_RowIndex;
                        rfv.ToolTip = "Please enter Stock Exchange Code";
                    }

                    rfv.SetFocusOnError = true;
                    rfv.ValidationGroup = "AssociateDate_" + n_RowIndex;
                    return rfv;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to add asp button control
        /// </summary>
        /// <param name="s_StockExhchangeID">Stock exchange ID</param>
        /// <param name="s_IsAssociated">Association</param>
        /// <param name="s_BtnType">button type Save/Update</param>
        /// <param name="n_RowIndex">grid view row index</param>
        /// <returns>Returns asp button control</returns>
        private Button AddUpdateButton(string s_StockExhchangeID, string s_IsAssociated, string s_BtnType, int n_RowIndex)
        {
            using (Button button = new Button())
            {
                button.Text = s_BtnType;
                button.ToolTip = s_BtnType;
                button.CssClass = "";
                button.ID = "btnUpdate_" + n_RowIndex;
                button.ClientIDMode = ClientIDMode.Static;
                button.Style.Add("display", "none");
                button.TabIndex = 10;
                button.Attributes.Add("class", "cButtonsp btnUpdate");
                button.ValidationGroup = "AssociateDate_" + n_RowIndex;
                button.Attributes.Add("onclick", "return UpdateStatus('" + s_StockExhchangeID + "','" + s_IsAssociated + "','" + n_RowIndex + "',this)");
                return button;
            }
        }

        /// <summary>
        /// This method is used to add asp button control
        /// </summary>
        /// <param name="s_StockExhchangeID">Stock exchange ID</param>
        /// <param name="s_IsAssociated">Association</param>
        /// <param name="s_BtnType">button type Save/Update</param>
        /// <param name="n_RowIndex">grid view row index</param>
        /// <returns>Returns asp button control</returns>
        private Button AddCancelButton(string s_StockExhchangeID, string s_IsAssociated, string s_BtnType, int n_RowIndex)
        {
            using (Button button = new Button())
            {
                button.Text = s_BtnType;
                button.ToolTip = s_BtnType;
                button.Style.Add("cursor", "pointer");
                button.Attributes.Add("class", "cButtonsp btnCancel");
                button.ID = "btnCancel_" + n_RowIndex;
                button.ClientIDMode = ClientIDMode.Static;
                button.Style.Add("display", "none");
                button.TabIndex = 10;
                button.Attributes.Add("onclick", "return CancelStatus('" + s_StockExhchangeID + "','" + s_IsAssociated + "','" + n_RowIndex + "',this)");
                return button;
            }
        }

        /// <summary>
        /// This method is used to add delete checkbox to grid view rows
        /// </summary>
        /// <param name="s_SEID">Stock Exchange ID</param>
        /// <param name="b_IsDeleted">Boolean value for Deleted</param>
        /// <returns>returns CheckBox control</returns>
        private CheckBox AddCheckBox(string s_SEID, bool b_IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_SEID);
                checkBox.ID = "chk";
                checkBox.ClientIDMode = ClientIDMode.Static;
                checkBox.Checked = b_IsDeleted;
                checkBox.TabIndex = 7;
                checkBox.Style.Add("cursor", "pointer");
                checkBox.Style.Add("text-align", "center");
                checkBox.Attributes.Add("name", "Types");

                if (!string.IsNullOrEmpty(s_SEID))
                {
                    checkBox.Attributes.Add("onclick", "DeleteSelectedRecords('" + s_SEID + "',this)");
                }

                return checkBox;
            }
        }

        /// <summary>
        /// This method is used to add delete all checkbox to grid view header
        /// </summary>
        /// <returns>Returns CHeckBox control</returns>
        private CheckBox AddSelectAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chk";
                checkBox.Attributes.Add("name", "Types");
                checkBox.Text = string.Empty;
                checkBox.TabIndex = 6;
                checkBox.Style.Add("cursor", "pointer");
                checkBox.Attributes.Add("onclick", "SelectAllCheckBoxes(this)");
                return checkBox;
            }
        }

        /// <summary>
        /// Used to bind tool-tips to drop-down items
        /// </summary>
        /// <param name="list">ListControl object</param>
        private void BindToolTip(ListControl list)
        {
            try
            {
                foreach (ListItem item in list.Items)
                {
                    item.Attributes.Add("title", item.Text);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This Method is used to save/update data
        /// </summary>
        /// <param name="companySetup">CompanySetup page object</param>
        /// <param name="s_Action">This is Action to be performed</param>
        public int SaveStockExchangeDetails(CompanySetup companySetup, string s_Action)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
                    {
                        using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                        {
                            int n_RetValue = 0;
                            superAdminProperties = new SuperAdminProperties();
                            if (s_Action.Equals("D"))
                            {
                                if (Convert.ToInt32(companySetup.hdnAssociatedSECount.Value) > 0)
                                {
                                    int n_DeleteCount = 0;
                                    string s_IDs = companySetup.hdnCSSEIDs_Deleted.Value;
                                    string[] o_IDs = s_IDs.Split(',');

                                    foreach (DataRow perRow in ac_CompanySetup.dt_StockExchangeDetails.Select("Status='" + 1 + "'"))
                                    {
                                        foreach (string s_ID in o_IDs)
                                        {
                                            if (Convert.ToInt32(s_ID).Equals(perRow["SEID"]))
                                                n_DeleteCount += 1;
                                        }
                                    }

                                    if (n_DeleteCount.Equals(Convert.ToInt32(companySetup.hdnAssociatedSECount.Value)))
                                    {
                                        companySetup.hdnCSIsAssociated.Value = string.Empty;
                                        companySetup.hdnCSDateAssociated.Value = string.Empty;
                                        companySetup.hdnCSStockExchangeID.Value = string.Empty;
                                        companySetup.hdnCSSEIDs_Deleted.Value = string.Empty;
                                        companySetup.hdnCSEditCode.Value = string.Empty;
                                        n_RetValue = 7;
                                        goto switchCase;
                                    }
                                }
                                superAdminProperties.SEMultipleIDs = companySetup.hdnCSSEIDs_Deleted.Value;
                            }
                            else superAdminProperties.SEMultipleIDs = companySetup.hdnCSStockExchangeID.Value;

                            if (s_Action.Equals("C"))
                                superAdminProperties.CreatedBy = userSessionInfo.ACC_UserID;

                            if (s_Action.Equals("A"))
                            {
                                s_Action = "U";

                                bool b_IsAssociated = (string.IsNullOrEmpty(companySetup.hdnCSIsAssociated.Value) || companySetup.hdnCSIsAssociated.Value.Equals("0")) ? false : true;
                                superAdminProperties.IS_ASSOCIATED = !b_IsAssociated;

                                if (!string.IsNullOrEmpty(companySetup.hdnCSEditCode.Value))
                                    superAdminProperties.CODE = companySetup.hdnCSEditCode.Value;

                                if (b_IsAssociated && Convert.ToInt32(companySetup.hdnAssociatedSECount.Value).Equals(1))
                                {
                                    companySetup.hdnCSIsAssociated.Value = string.Empty;
                                    companySetup.hdnCSDateAssociated.Value = string.Empty;
                                    companySetup.hdnCSStockExchangeID.Value = string.Empty;
                                    companySetup.hdnCSSEIDs_Deleted.Value = string.Empty;
                                    companySetup.hdnCSEditCode.Value = string.Empty;
                                    n_RetValue = 6;
                                    goto switchCase;
                                }
                            }
                            else
                            {
                                bool isAssociated = (string.IsNullOrEmpty(companySetup.hdnCSIsAssociated.Value) || companySetup.hdnCSIsAssociated.Value.Equals("0")) ? false : true;
                                superAdminProperties.IS_ASSOCIATED = isAssociated;
                                superAdminProperties.StockExchangeName = string.IsNullOrEmpty(companySetup.txtStockExchangeName.Text) ? string.Empty : companySetup.txtStockExchangeName.Text;
                                superAdminProperties.ShortName = string.IsNullOrEmpty(companySetup.txtShortName.Text) ? string.Empty : companySetup.txtShortName.Text;
                                superAdminProperties.CODE = string.IsNullOrEmpty(companySetup.txtStockExchangeCode.Text) ? string.Empty : companySetup.txtStockExchangeCode.Text;
                                superAdminProperties.CRMID = Convert.ToInt32(companySetup.ddlCurrency.SelectedItem.Value);

                                if (!s_Action.Equals("D"))
                                {
                                    using (PeerCompanyModel peerCompanyModel = new PeerCompanyModel())
                                    {
                                        bool b_IsValidCode = peerCompanyModel.ValidateStockExCode(superAdminProperties.CODE.Trim(), superAdminProperties.ShortName.Trim());
                                        if (!b_IsValidCode)
                                        {
                                            n_RetValue = 8;
                                            goto switchCase;
                                        }
                                    }
                                }
                            }
                            superAdminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                            superAdminProperties.Action = s_Action;
                            superAdminProperties.PageName = CommonConstantModel.s_ManageStockExchange;
                            superAdminProperties.Operation = CommonConstantModel.s_OperationCUD;
                            superAdminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                            superAdminProperties.ASSOCIATED_DATE = companySetup.hdnCSDateAssociated.Value;

                            superAdminCRUDProperties = superAdminServiceClient.CRUDSuperAdminOperations(superAdminProperties);
                            n_RetValue = superAdminCRUDProperties.a_result;

                        switchCase:

                            switch (n_RetValue)
                            {
                                case 1:
                                    companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSSaveMessage", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                    companySetup.hdnAccordionIndex.Value = "0";
                                    companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    companySetup.h3AddEdit.Style.Add("display", "none");
                                    companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                    break;
                                case 2:
                                    companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSUpdateMessage", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                    companySetup.hdnAccordionIndex.Value = "0";
                                    companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    companySetup.h3AddEdit.Style.Add("display", "none");
                                    companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                    break;
                                case 3:
                                    companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSDeleteMessage", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                    companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    companySetup.h3AddEdit.Style.Add("display", "none");
                                    companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                    break;
                                case 4:
                                    companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSRecordAlreadyExists", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                    companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    companySetup.h3AddEdit.Style.Add("display", "block");
                                    companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                    break;
                                case 5:
                                    companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSExistWithDeletedStatus", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                    companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                    companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "block";
                                    companySetup.h3AddEdit.Style.Add("display", "block");
                                    break;
                                case 6:
                                    companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSAssociateSEBeforeDisassociate", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                    companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    companySetup.h3AddEdit.Style.Add("display", "none");
                                    companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                    break;
                                case 7:
                                    companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSAssociateSEBeforeDelete", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                    companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    companySetup.h3AddEdit.Style.Add("display", "none");
                                    companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                    break;
                                case 8:
                                    companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSInvalidStockExCode", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                    companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                    companySetup.h3AddEdit.Style.Add("display", "block");
                                    companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                    companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                    break;

                                default:
                                    break;
                            }

                            if (!n_RetValue.Equals(8))
                            {
                                companySetup.hdnCSStockExchangeID.Value = string.Empty;
                                companySetup.hdnCSIsAssociated.Value = string.Empty;
                                companySetup.hdnCSDateAssociated.Value = string.Empty;
                                companySetup.hdnCSSEIDs_Deleted.Value = string.Empty;
                                companySetup.hdnCSEditCode.Value = string.Empty;
                            }

                            if (companySetup.rbtLstCSListingStatus.Items.FindByValue("1").Selected)
                                companySetup.trListedSection.Style.Add("display", "");
                            else
                                companySetup.trListedSection.Style.Add("display", "none");

                            return n_RetValue;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to update company details
        /// </summary>
        /// <param name="companySetup">CompanySetup page object</param>
        ///  <param name="n_Action">Action to be performed </param>
        public void UpdateCompanySetupDetails(CompanySetup companySetup, int n_Action)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    if (n_Action == 1)
                    {
                        adminProperties.COMPANY_NAME = companySetup.txtCSCompanyName.Text;
                        adminProperties.IS_LISTED = Convert.ToBoolean(Convert.ToInt32(companySetup.rbtLstCSListingStatus.SelectedItem.Value));
                    }
                    else if (n_Action == 2)
                    {
                        adminProperties.IsActive = (Convert.ToInt32(companySetup.hdnIsActive.Value) == 1) ? 2 : 1;
                        adminProperties.ACMAID = Convert.ToInt32(companySetup.hdnACMAID.Value);
                    }

                    adminProperties.CREATED_BY = userSessionInfo.ACC_UserID;
                    adminProperties.UPDATED_BY = userSessionInfo.ACC_UserID;
                    adminProperties.ACTION = n_Action;
                    adminProperties.CS_ADDRESS = companySetup.txtCIAddress.Text.Trim();
                    adminProperties.CS_CONTACT_PERSON = companySetup.txtCIContactPerson.Text.Trim();
                    adminProperties.CS_INTERNAL_AUDITOR = companySetup.txtCIAuditorInternal.Text.Trim();
                    adminProperties.CS_EXTERNAL_AUDITOR = companySetup.txtCIAuditorExternal.Text.Trim();
                    adminProperties.CS_DEFAULT_CURRENCY = Convert.ToInt32(companySetup.ddlCICurrency.SelectedItem.Value);
                    adminProperties.CS_DESIGNATION = companySetup.txtCIDesignation.Text.Trim();
                    adminProperties.CS_EMAIL_ID = companySetup.txtCIEmailID.Text.Trim();
                    adminProperties.CS_PHONE_NO = companySetup.txtCIPhoneNo.Text;

                    if (!string.IsNullOrEmpty(companySetup.txtCIApplFromDateLS.Text) && !companySetup.txtCIApplFromDateLS.Text.Trim().Equals("dd/mmm/yyyy"))
                        adminProperties.FROM_DATE = companySetup.txtCIApplFromDateLS.Text;

                    using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                    {

                        adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                        adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminCUD, adminProperties);

                        switch (Convert.ToInt32(Convert.ToString(adminCRUDProperties.dt_Result.Rows[0]["RESULT"]).Split('|')[0]))
                        {
                            case 2:
                                companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSUpdateMessage", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                if (companySetup.rbtLstCSListingStatus.SelectedItem.Value.Equals("1"))
                                    companySetup.hdnIsListed.Value = "true";
                                else
                                    companySetup.hdnIsListed.Value = "false";
                                if (!string.IsNullOrEmpty(companySetup.txtCIApplFromDateLS.Text) && !companySetup.txtCIApplFromDateLS.Text.Trim().Equals("dd/mmm/yyyy"))
                                    companySetup.hdnCSDateOfListing.Value = companySetup.txtCIApplFromDateLS.Text;
                                companySetup.txtCIApplFromDateLS.Text = string.Empty;
                                break;
                            case 3:
                                companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSDateErrorMessage", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                if (companySetup.rbtLstCSListingStatus.Items.FindByValue("1").Selected)
                                    companySetup.trListedSection.Style.Add("display", "");
                                else
                                    companySetup.trListedSection.Style.Add("display", "none");

                                break;
                            case 4:
                                companySetup.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCSTodaysDateErrorMessage", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                                companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                if (companySetup.rbtLstCSListingStatus.Items.FindByValue("1").Selected)
                                    companySetup.trListedSection.Style.Add("display", "");
                                else
                                    companySetup.trListedSection.Style.Add("display", "none");

                                break;
                            case 5:
                                string s_MessageText = string.Empty;
                                if (!string.IsNullOrEmpty(Convert.ToString(adminCRUDProperties.dt_Result.Rows[0]["RESULT"]).Split('|')[1].Trim()))
                                {
                                    s_MessageText = adminServiceClient.GetAdmin_L10N("lblCISaveMsgDefaultSettingsError", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10)
                                    + Convert.ToString(adminCRUDProperties.dt_Result.Rows[0]["RESULT"]).Split('|')[1].Trim();
                                }
                                else s_MessageText = adminServiceClient.GetAdmin_L10N("lblCISaveMsgDefaultSettings", CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminL10);
                                companySetup.ctrSuccessErrorMessage.s_MessageText = s_MessageText.Replace("~", "</br>");
                                companySetup.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                                companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
                                companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
                                if (companySetup.rbtLstCSListingStatus.SelectedItem.Value.Equals("1"))
                                    companySetup.hdnIsListed.Value = "true";
                                else
                                    companySetup.hdnIsListed.Value = "false";
                                if (!string.IsNullOrEmpty(companySetup.txtCIApplFromDateLS.Text) && !companySetup.txtCIApplFromDateLS.Text.Trim().Equals("dd/mmm/yyyy"))
                                    companySetup.hdnCSDateOfListing.Value = companySetup.txtCIApplFromDateLS.Text;
                                companySetup.txtCIApplFromDateLS.Text = string.Empty;
                                break;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to update company details
        /// </summary>
        /// <param name="s_CRMID">Currency Master ID</param>
        /// <returns>returns result</returns>
        public int UpdateDefaultCurr(object s_CRMID)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties = new AdminProperties();
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    adminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    adminProperties.CS_DEFAULT_CURRENCY = Convert.ToInt32(s_CRMID);
                    adminProperties.ACTION = 3;

                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdCompanySetup, CommonConstantModel.s_AdminCUD, adminProperties);
                    return Convert.ToInt32(Convert.ToString(adminCRUDProperties.dt_Result.Rows[0]["RESULT"]).Split('|')[0]);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// grid-view page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="companySetup">CompanySetup page object</param>
        internal void PageIndexChanging(int NewPageIndex, CompanySetup companySetup)
        {
            try
            {
                companySetup.gv.PageIndex = NewPageIndex;
                companySetup.gv.DataSource = ac_CompanySetup.dt_StockExchangeDetails;
                companySetup.gv.DataBind();

                if (!string.IsNullOrEmpty(companySetup.hdnCSStockExchangeID.Value))
                {
                    string[] s_StockExgIDs = companySetup.hdnCSStockExchangeID.Value.TrimStart(',').Split(',');
                    foreach (string s_PerID in s_StockExgIDs)
                    {
                        foreach (DataRow perRow in ac_CompanySetup.dt_StockExchangeDetails.Select("SEID='" + s_PerID + "'"))
                        {
                            perRow["Select All"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// grid-view page index change event
        /// </summary>
        /// <param name="NewPageIndex">Grid view page index</param>
        /// <param name="companySetup">CompanySetup page object</param>
        internal void gvAssociatedParams_PageIndexChanging(int NewPageIndex, CompanySetup companySetup)
        {
            try
            {
                companySetup.gvAssociatedParams.PageIndex = NewPageIndex;
                companySetup.gvAssociatedParams.DataSource = ac_CompanySetup.dt_AssociatedParameters;
                companySetup.gvAssociatedParams.DataBind();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to clear success/error message
        /// </summary>
        /// <param name="companySetup">>CompanySetup page object</param>
        public void ClearMessage(CompanySetup companySetup)
        {
            companySetup.ctrSuccessErrorMessage.s_MsgBoxDisplay = "";
            companySetup.ctrSuccessErrorMessage.s_RevOptionsDisplay = "none";
        }

        /// <summary>
        /// This method is used to hide Add/Edit Section
        /// </summary>
        /// <param name="companySetup">this is companySetup page object</param>
        public void HideAddEditSection(CompanySetup companySetup)
        {
            companySetup.h3AddEdit.Style.Add("display", "none");
        }

        #region Destructors
        /// <summary>
        /// Finalizes an instance of the <see cref="CompanySetupModel"/> class.
        /// </summary>
        ~CompanySetupModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>        
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}