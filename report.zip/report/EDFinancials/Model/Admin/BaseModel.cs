﻿using EDFinancials.Model.Generic;

namespace EDFinancials.Model.Admin
{
    /// <summary>
    /// Model class for Base page
    /// </summary>
    public class BaseModel : EDFinancials.Model.SuperAdmin.BaseModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BaseModel"/> class.
        /// </summary>
        public BaseModel()
        {
            if ((AdminProperties)System.Web.HttpContext.Current.Session["adminProperties"] == null)
            {
                adminProperties = new AdminProperties();
                System.Web.HttpContext.Current.Session["adminProperties"] = adminProperties;
            }
            else
            {
                adminProperties = (AdminProperties)System.Web.HttpContext.Current.Session["adminProperties"];
            }

            if ((AdminCRUDProperties)System.Web.HttpContext.Current.Session["adminCRUDProperties"] == null)
            {
                adminCRUDProperties = new AdminCRUDProperties();
                System.Web.HttpContext.Current.Session["adminCRUDProperties"] = adminCRUDProperties;
            }
            else
            {
                adminCRUDProperties = (AdminCRUDProperties)System.Web.HttpContext.Current.Session["adminCRUDProperties"];
            }
        }

        /// <summary>
        /// PRIVATE DECLARATION FOR ADMIN PROPERTY
        /// </summary>
        private AdminProperties _adminProperties;

        /// <summary>
        /// PUBLIC DECLARATION FOR ADMIN PROPERTY
        /// </summary>
        public AdminProperties adminProperties
        {
            get { return _adminProperties; }
            set { _adminProperties = value; }
        }

        /// <summary>
        /// PRIVATE DECLARATION FOR ADMIN CURD PROPERTY
        /// </summary>
        private AdminCRUDProperties _adminCRUDProperties;

        /// <summary>
        /// PUBLIC DECLARATION FOR ADMIN CURD PROPERTY
        /// </summary>
        public AdminCRUDProperties adminCRUDProperties
        {
            get { return _adminCRUDProperties; }
            set { _adminCRUDProperties = value; }
        }

        /// <summary>
        /// OBJECT OF COMPNAY SETUP ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_CompanySetup ac_CompanySetup;

        /// <summary>
        /// OBJECT OF MANAGE ROLE ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ManageRoles ac_ManageRoles;

        /// <summary>
        /// OBJECT OF MANAGE USERS ABSTRACT CLASS
        /// </summary>
        public CommonModel.AC_ManageUser ac_ManageUser;     
    }
}