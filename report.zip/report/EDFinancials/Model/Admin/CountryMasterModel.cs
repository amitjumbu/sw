﻿using EDFinancials.Model.Generic;
using EDFinancials.View.Admin;
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Linq;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.Admin
{
    /// <summary>
    /// Model class for CountryMaster page
    /// </summary>
    public class CountryMasterModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="CountryMasterModel"/> class.
        /// </summary>
        public CountryMasterModel()
        {
            if (ac_ManageCountry == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageCountry);
                ac_ManageCountry = (CommonModel.AC_ManageCountry)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageCountry];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty;

        #endregion

        /// <summary>
        /// Read label/button names
        /// </summary>
        /// <param name="countryMasterUI">View.Admin.ManageCountries</param>
        internal void ReadL10N_UI(ManageCountries countryMasterUI)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    using (DataTable dt_AdminL10N_UI = adminServiceClient.GetAdmin_L10N_UI(CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10_UI))
                    {
                        if ((dt_AdminL10N_UI != null) && (dt_AdminL10N_UI.Rows.Count > 0))
                        {
                            countryMasterUI.lblParamCountryName.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblParamCountryName'"))[0]["LabelName"]);
                            countryMasterUI.lblCMStatus.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblCMStatus'"))[0]["LabelName"]);
                            countryMasterUI.lblIsDefault.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblIsDefault'"))[0]["LabelName"]);
                            countryMasterUI.btnCMApplyFilter.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnCMApplyFilter'"))[0]["LabelName"]);
                            countryMasterUI.btnCMCreateNew.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnCMCreateNew'"))[0]["LabelName"]);
                            countryMasterUI.btnCMDelete.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnCMDelete'"))[0]["LabelName"]);
                            countryMasterUI.lblCountryName.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblCountryName'"))[0]["LabelName"]);
                            countryMasterUI.lblCMIsActive.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblCMIsActive'"))[0]["LabelName"]);
                            countryMasterUI.btnCMSave.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnCMSave'"))[0]["LabelName"]);
                            countryMasterUI.btnCMCancel.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnCMCancel'"))[0]["LabelName"]);
                            countryMasterUI.lblAdCMHeader1.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblAdCMHeader1'"))[0]["LabelName"]);
                            countryMasterUI.lblAdCMHeader2.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblAdCMHeader2'"))[0]["LabelName"]);
                            countryMasterUI.lblAdCMHeader3.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblAdCMHeader3'"))[0]["LabelName"]);
                            countryMasterUI.btnCMClearFilter.Text = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnCMClearFilter'"))[0]["LabelName"]);
                            countryMasterUI.reqName.ToolTip = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'lblCountryName'"))[0]["ErrorText"]);
                            s_BtnUpdateText = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnCMUpdate'"))[0]["LabelName"]);
                            s_BtnUpdateToolTip = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnCMUpdate'"))[0]["LabelToolTip"]);
                            s_BtnSaveText = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnCMSave'"))[0]["LabelName"]);
                            s_BtnSaveTooltip = Convert.ToString((dt_AdminL10N_UI.Select("LabelID = 'btnCMSave'"))[0]["LabelToolTip"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// Method is used for bind the data in GridView 
        /// </summary>
        /// <param name="countryMasterUI">this is countryMasterUI page object</param>
        internal void BindCountryDetailsGrid(ManageCountries countryMasterUI)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.CMID = countryMasterUI.ddlParamCountryName.SelectedValue == ("--- Please Select ---") || countryMasterUI.ddlParamCountryName.SelectedValue == ("") ? 0 : Convert.ToInt32(countryMasterUI.ddlParamCountryName.SelectedValue);
                    adminProperties.IsActive = countryMasterUI.ddlCMStatus.SelectedValue == ("--- Please Select ---") || countryMasterUI.ddlCMStatus.SelectedValue == ("") ? 0 : Convert.ToInt32(countryMasterUI.ddlCMStatus.SelectedValue);
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCountries, "Read", adminProperties);
                    ac_ManageCountry.dt_Countries = adminCRUDProperties.dt_Result;
                    countryMasterUI.gv.DataSource = adminCRUDProperties.dt_Result;
                    countryMasterUI.gv.DataBind();

                    if (!(countryMasterUI.ddlParamCountryName.SelectedValue == ("--- Please Select ---") || countryMasterUI.ddlParamCountryName.SelectedValue == ("")))
                    {
                        countryMasterUI.btnCMClearFilter.Visible = true;
                    }
                    if (!(countryMasterUI.ddlCMStatus.SelectedValue == ("--- Please Select ---") || countryMasterUI.ddlCMStatus.SelectedValue == ("")))
                    {
                        countryMasterUI.btnCMClearFilter.Visible = true;
                    }

                    if (ac_ManageCountry.dt_Countries.Rows.Count <= 0)
                    {
                        countryMasterUI.btnCMDelete.Visible = false;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used for bind the data in GridView 
        /// </summary>
        /// <param name="countryMasterUI">this is countryMasterUI page object </param>
        internal void ClearFilters(ManageCountries countryMasterUI)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.CMID = 0;
                    adminProperties.IsActive = 0;
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCountries, "Read", adminProperties);
                    ac_ManageCountry.dt_Countries = adminCRUDProperties.dt_Result;
                    countryMasterUI.gv.DataSource = adminCRUDProperties.dt_Result;
                    countryMasterUI.gv.DataBind();

                    countryMasterUI.btnCMClearFilter.Visible = false;
                    countryMasterUI.btnCMDelete.Visible = adminCRUDProperties.dt_Result.Rows.Count > 0;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Country Master
        /// </summary>
        /// <param name="countryMasterUI">View.Admin.ManageCountries</param>
        internal void BindCountryName(ManageCountries countryMasterUI)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.CMID = 0;
                    adminProperties.IsActive = 0;
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCountries, "Read", adminProperties);
                    countryMasterUI.ddlParamCountryName.DataSource = adminCRUDProperties.dt_Result;
                    countryMasterUI.ddlParamCountryName.DataTextField = "Country Name";
                    countryMasterUI.ddlParamCountryName.DataValueField = "ID";
                    countryMasterUI.ddlParamCountryName.DataBind();
                    countryMasterUI.ddlParamCountryName.Items.Insert(0, "--- Please Select ---");

                    countryMasterUI.hdnCountryMasterID.Value = string.Empty;
                    countryMasterUI.hdnDeletedRecords.Value = string.Empty;
                    countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Dropdown for Country Status
        /// </summary>
        /// <param name="countryMasterUI">View.Admin.ManageCountries</param>
        internal void BindCountryStatus(ManageCountries countryMasterUI)
        {
            try
            {
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("STATUS_ID", typeof(string));
                dataTable.Columns.Add("STATUS", typeof(string));

                DataRow dataRow = null;
                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "1";
                dataRow["STATUS"] = "Activated";
                dataTable.Rows.Add(dataRow);

                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "2";
                dataRow["STATUS"] = "Deactivated";
                dataTable.Rows.Add(dataRow);

                countryMasterUI.ddlCMStatus.DataSource = dataTable;
                countryMasterUI.ddlCMStatus.DataTextField = "STATUS";
                countryMasterUI.ddlCMStatus.DataValueField = "STATUS_ID";
                countryMasterUI.ddlCMStatus.DataBind();

                countryMasterUI.ddlCMStatus.Items.Insert(0, "--- Please Select ---");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Bind Dropdown for Country Status
        /// </summary>
        /// <param name="countryMasterUI">View.Admin.ManageCountries</param>
        internal void BindStatus(ManageCountries countryMasterUI)
        {
            try
            {
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("STATUS_ID", typeof(string));
                dataTable.Columns.Add("STATUS", typeof(string));

                DataRow dataRow = null;
                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "1";
                dataRow["STATUS"] = "Activated";
                dataTable.Rows.Add(dataRow);

                dataRow = dataTable.NewRow();
                dataRow["STATUS_ID"] = "2";
                dataRow["STATUS"] = "Deactivated";
                dataTable.Rows.Add(dataRow);

                countryMasterUI.ddlStatus.DataSource = dataTable;
                countryMasterUI.ddlStatus.DataTextField = "STATUS";
                countryMasterUI.ddlStatus.DataValueField = "STATUS_ID";
                countryMasterUI.ddlStatus.DataBind();

                countryMasterUI.ddlStatus.Items.Insert(0, "--- Please Select ---");
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// CUD[Create/Update/Delete] operation on Forfeiture Group
        /// </summary>
        /// <param name="countryMasterUI">View.Admin.ManageCountries</param>
        internal void CUDCountryDetails(ManageCountries countryMasterUI)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    if (string.IsNullOrEmpty(countryMasterUI.hdnCountryMasterID.Value) && !string.IsNullOrEmpty(countryMasterUI.hdnDeletedRecords.Value))
                        adminProperties.Action = "D";
                    else
                        adminProperties.Action = string.IsNullOrEmpty(countryMasterUI.hdnCountryMasterID.Value) ? "C" : "U";

                    adminProperties.CountryName = countryMasterUI.txtCountryName.Text;
                    adminProperties.IsActive = Convert.ToInt32(countryMasterUI.ddlStatus.SelectedValue);
                    adminProperties.IsDefault = countryMasterUI.chkIsDefault.Checked ? true : false;
                    adminProperties.IsDeleted = string.IsNullOrEmpty(countryMasterUI.hdnDeletedRecords.Value) ? false : true;
                    adminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    adminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    adminProperties.CMID = string.IsNullOrEmpty(countryMasterUI.hdnCountryMasterID.Value) ? 0 : Convert.ToInt32(countryMasterUI.hdnCountryMasterID.Value);
                    adminProperties.CMDeleteID = string.IsNullOrEmpty(countryMasterUI.hdnDeletedRecords.Value) ? string.Empty : countryMasterUI.hdnDeletedRecords.Value.TrimStart(',');
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    countryMasterUI.txtCountryName.Text = "";
                    countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                    if (countryMasterUI.hdnDefCountry.Value == "Yes" || countryMasterUI.SelectAllChecked.Value.Equals("true"))
                    {
                        string s_IsDefault = (from r in ac_ManageCountry.dt_Countries.AsEnumerable()
                                              where r.Field<string>("Default Country") == "Yes"
                                              select r.Field<string>("Default Country")).First<string>();
                        if (s_IsDefault.Equals("Yes"))
                        {
                            adminCRUDProperties.a_result = 6;
                        }
                    }
                    else if(!countryMasterUI.chkIsDefault.Checked && adminProperties.Action.Equals("U"))
                    {
                        int s_IsDefault = (from r in ac_ManageCountry.dt_Countries.AsEnumerable()
                                              where r.Field<string>("Default Country") == "Yes"
                                              select r.Field<int>("ID")).First<int>();
                        adminCRUDProperties.a_result = s_IsDefault.Equals(adminProperties.CMID) ? 9 : adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCountries, "CUD", adminProperties).a_result;
                    }
                    else
                    {
                        adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCountries, "CUD", adminProperties);
                    }
                   
                    countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                    countryMasterUI.chkIsDefault.Checked = false;

                    switch (Convert.ToInt16(adminCRUDProperties.a_result))
                    {
                        case 0:
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMError", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 1:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMCreated", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 2:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMUpdated", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 3:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMDeleted", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 4:
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMIsExist", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 5:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMReactive", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            countryMasterUI.ctrSuccessErrorMessage.s_RevOptionsDisplay = "block";
                            ac_ManageCountry.s_CountryName = adminProperties.CountryName;
                            break;

                        case 6:
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMDefaultCurrency", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            countryMasterUI.hdnDefCountry.Value = string.Empty;
                            countryMasterUI.hdnDeletedRecords.Value = string.Empty;
                            countryMasterUI.SelectAllChecked.Value = string.Empty;
                            break;

                        case 7:
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMAssociatedRFIR", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            countryMasterUI.hdnDefCountry.Value = string.Empty;
                            countryMasterUI.hdnDeletedRecords.Value = string.Empty;
                            countryMasterUI.SelectAllChecked.Value = string.Empty;
                            break;

                        case 8:
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMCountryAssociatedRFIR", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            countryMasterUI.hdnDefCountry.Value = string.Empty;
                            countryMasterUI.hdnDeletedRecords.Value = string.Empty;
                            countryMasterUI.SelectAllChecked.Value = string.Empty;
                            break;

                        case 9:
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgForeColor = Color.Red;
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMchkIsDefault", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            countryMasterUI.hdnDefCountry.Value = string.Empty;
                            countryMasterUI.hdnDeletedRecords.Value = string.Empty;
                            countryMasterUI.SelectAllChecked.Value = string.Empty;
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// CUD[Create/Update/Delete] operation on Forfeiture Group
        /// </summary>
        /// <param name="countryMasterUI">UI object</param>
        /// <returns></returns>
        internal void ReactiveCountryDetails(ManageCountries countryMasterUI)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.Action = "U";

                    adminProperties.CountryName = ac_ManageCountry.s_CountryName;
                    adminProperties.IsDeleted = false;
                    adminProperties.CreatedBy = userSessionInfo.ACC_UserID;
                    adminProperties.ModifiedBy = userSessionInfo.ACC_UserID;
                    adminProperties.CMID = 0;
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    countryMasterUI.txtCountryName.Text = "";
                    countryMasterUI.chkIsDefault.Checked = false;
                    countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_AdManageCountries, "CUD", adminProperties);

                    switch (Convert.ToInt16(adminCRUDProperties.a_result))
                    {
                        case 0:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMError", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;

                        case 2:
                            countryMasterUI.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCMUpdated", CommonConstantModel.s_AdManageCountries, CommonConstantModel.s_AdminL10);
                            countryMasterUI.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                            break;
                    }
                    countryMasterUI.ctrSuccessErrorMessage.divrevOptions.Visible = false;
                }
            }
            catch
            {
                throw;
            }
        }

        #region Bind/Hide rows into GridView gv
        /// <summary>
        /// Bind GridView Rows
        /// </summary>
        /// <param name="e">e</param>
        /// <param name="n_index">index</param>
        /// <param name="n_ID">ID</param>
        /// <param name="n_Delete">Delete</param>
        /// <param name="n_Action">Action</param>
        /// <param name="n_DefCountry">Default Country</param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action, ref int n_DefCountry)
        {
            try
            {
                switch (e.Row.RowType)
                {
                    case DataControlRowType.Header:
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {
                            switch (perColumn.Text.ToUpper())
                            {
                                case "ID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    n_Delete = n_index;
                                    e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                    break;

                                case "DEFAULT COUNTRY":
                                    n_DefCountry = n_index;
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                        break;

                    case DataControlRowType.DataRow:
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, "Edit"));
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[1].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[n_DefCountry].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                        break;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Create Image button
        /// </summary>
        /// <param name="s_strToolTip">ToolTip</param>
        /// <param name="s_strUrl">URL</param>
        /// <param name="s_CountryID">CountryID</param>
        /// <param name="s_CountryName">CountryName</param>
        /// <param name="s_Status">Status</param>
        /// <param name="s_IsDefault">string to check if is Default</param>
        /// <param name="s_Action">Action</param>
        /// <returns>ImageButton control</returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_CountryID, string s_CountryName, string s_Status, string s_IsDefault, string s_Action)
        {
            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");

                if (!string.IsNullOrEmpty(s_CountryName))
                {
                    imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_CountryName + "','" + s_Status + "','" + s_CountryID + "','" + s_IsDefault + "')");
                }

                return imgButton;
            }
        }

        /// <summary>
        /// Bind CheckBox for delete multiple records
        /// </summary>
        /// <param name="s_CountryID">CountryID</param>
        /// <param name="s_DefCountry">Default Country</param>
        /// <param name="IsDeleted">Is Deleted</param>
        /// <returns>CheckBox control</returns>
        private CheckBox AddCheckBox(string s_CountryID, string s_DefCountry, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_CountryID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");

                if (!string.IsNullOrEmpty(s_CountryID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_CountryID + "','" + s_DefCountry + "',this)");
                }

                return checkBox;
            }
        }
        /// <summary>
        /// Add Delete all checkbox
        /// </summary>
        /// <returns>CheckBox control</returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chk";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Text = string.Empty;
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }
        #endregion

        /// <summary>
        /// Bind next page data
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">GridViewPageEventArgs</param>
        /// <param name="gv">GridView</param>
        /// <param name="s_CountryID">CountryID</param>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_CountryID)
        {
            try
            {
                string[] s_CountryGpID = s_CountryID.TrimStart(',').Split(',');

                ac_ManageCountry.dt_Countries.Columns["Delete"].Expression = string.Empty;
                ac_ManageCountry.dt_Countries.AcceptChanges();

                foreach (string perID in s_CountryGpID)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_ManageCountry.dt_Countries.Select("ID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }
                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_ManageCountry.dt_Countries;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Finalizes an instance of the <see cref="CountryMasterModel"/> class.
        /// </summary>
        ~CountryMasterModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}