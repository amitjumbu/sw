﻿using EDFinancials.Model.Generic;
using System;
using System.Data;

namespace EDFinancials.Model.Admin
{
    /// <summary>
    /// Model for Admin's ChangePassword Page.
    /// </summary>
    public class ChangePasswordModel : BaseModel, IDisposable
    {
        /// <summary>
        /// This Method is used to fetch messages from L10N xml via super admin WCF service.
        /// </summary>
        /// <param name="MessegeId"></param>
        /// <returns>string as the message</returns>
        public string AD_L10N(string MessegeId)
        {
            using (AdminServiceClient adminServiceClient = new AdminServiceClient())
            {
                try
                {
                    return adminServiceClient.GetAdmin_L10N(MessegeId, CommonConstantModel.s_ChangePassword, CommonConstantModel.s_AdminL10);
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// This method is used to load all label text from L10N_UI via WCF service
        /// </summary>
        /// <param name="changePassword">Entire page is sent to module using 'this' keyword</param>
        public void BindPageUI(EDFinancials.View.Admin.ChangePassword changePassword)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    using (DataTable dt_ChangPWEUI = adminServiceClient.GetAdmin_L10N_UI(CommonConstantModel.s_ChangePassword, CommonConstantModel.s_AdminL10_UI))
                    {
                        if ((dt_ChangPWEUI != null) && (dt_ChangPWEUI.Rows.Count > 0))
                        {
                            changePassword.lblCPHeader.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPHeader'"))[0]["LabelName"]);
                            changePassword.lblCPoldPassword.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPoldPassword'"))[0]["LabelName"]);
                            changePassword.lblCPoldPassword.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPoldPassword'"))[0]["LabelToolTip"]);
                            changePassword.RqdOldpswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPoldPassword'"))[0]["LabelToolTip"]);

                            changePassword.lblCPnewPassword.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPnewPassword'"))[0]["LabelName"]);
                            changePassword.lblCPnewPassword.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPnewPassword'"))[0]["LabelToolTip"]);
                            changePassword.rqdnewpswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPnewPassword'"))[0]["LabelToolTip"]);

                            changePassword.lblCPconfirmPassword.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["LabelName"]);
                            changePassword.lblCPconfirmPassword.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["LabelToolTip"]);
                            changePassword.rqdcnfmpswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["ErrorText2"]);
                            changePassword.cmpConfmpswd.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='lblCPconfirmPassword'"))[0]["ErrorText"]);

                            changePassword.btnCPSubmit.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='btnCPSubmit'"))[0]["LabelName"]);
                            changePassword.btnCPSubmit.ToolTip = Convert.ToString((dt_ChangPWEUI.Select("LabelID='btnCPSubmit'"))[0]["LabelToolTip"]);
                            changePassword.btnCPCancel.Value = Convert.ToString((dt_ChangPWEUI.Select("LabelID='btnCPCancel'"))[0]["LabelName"]);
                            changePassword.lblPasswordpattern.Text = Convert.ToString((dt_ChangPWEUI.Select("LabelID='PasswordPatternHelp'"))[0]["LabelName"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to perform CUD operations
        /// </summary>
        /// <param name="changePassword">Entire page is sent to module using 'this' keyword</param>
        internal void PerformCUD(EDFinancials.View.Admin.ChangePassword changePassword)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        adminProperties.Id = userSessionInfo.ACC_UserID;
                    }

                    adminProperties.LoginPassword = changePassword.txtCPoldPassword.Text;
                    adminProperties.NewPassword = changePassword.txtCPnewPassword.Text;
                    adminProperties.Action = "P";

                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;


                    switch (adminServiceClient.CRUDAdminOperations("ChangePassword", "CUD", adminProperties).a_result)
                    {
                        case 0:
                            changePassword.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCPError", CommonConstantModel.s_ChangePassword, CommonConstantModel.s_AdminL10);
                            changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;

                        case 4:
                            changePassword.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCPNoMatch", CommonConstantModel.s_ChangePassword, CommonConstantModel.s_AdminL10);
                            changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;


                        case 2:
                            changePassword.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblCPUpdated", CommonConstantModel.s_ChangePassword, CommonConstantModel.s_AdminL10);
                            changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            break;

                    }
                    changePassword.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    changePassword.txtCPoldPassword.Text = string.Empty;
                    changePassword.txtCPnewPassword.Text = string.Empty;
                    changePassword.txtCPconfirmPassword.Text = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method validates the new password string according to the predefined password standard.
        /// </summary>
        /// <param name="changePassword">object of change password page</param>
        /// <returns>returns boolean</returns>
        internal bool ValidatePasswordPattern(EDFinancials.View.Admin.ChangePassword changePassword)
        {
            bool b_flag = true;
            try
            {
                string[] s_IsInValidPassword = new string[2];
                s_IsInValidPassword = CommonModel.ValidatePasswordPattern(changePassword.txtCPconfirmPassword.Text);
                if (!(string.IsNullOrEmpty(s_IsInValidPassword[0])))
                {
                    using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                    {
                        changePassword.ctrSuccessErrorMessage.s_MessageText = genericServiceClient.Get_L10N(s_IsInValidPassword[0], "Message", "COMMON_L10N.xml");
                        changePassword.ctrSuccessErrorMessage.s_MessageText = changePassword.ctrSuccessErrorMessage.s_MessageText + s_IsInValidPassword[1].ToString() + genericServiceClient.Get_L10N(s_IsInValidPassword[2], "Message", "COMMON_L10N.xml");
                    }
                    changePassword.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                    changePassword.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    b_flag = false;
                }
            }
            catch
            {
                throw;
            }

            return b_flag;
        }

        #region Destructors
        /// <summary>
        ///  Finalizes an instance of the <see cref="ChangePasswordModel"/> class.
        /// </summary>
        ~ChangePasswordModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}