﻿using EDFinancials.Model.Generic;
using EDFinancials.View.Admin;
using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Web;
using System.Web.UI.WebControls;

namespace EDFinancials.Model.Admin
{
    /// <summary>
    /// Model for ManageUsers Page.
    /// </summary>
    public class ManageUsersModel : BaseModel, IDisposable
    {
        #region Default constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ManageUsersModel"/> class.
        /// </summary>
        public ManageUsersModel()
        {
            if (ac_ManageUser == null)
            {
                CommonModel.Instance(CommonConstantModel.s_AC_ManageUser);
                ac_ManageUser = (CommonModel.AC_ManageUser)HttpContext.Current.Session[CommonConstantModel.s_AC_ManageUser];
            }
        }

        #endregion

        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty, s_BtnUpdateToolTip = string.Empty, s_BtnSaveText = string.Empty, s_BtnSaveTooltip = string.Empty;

        #endregion

        /// <summary>
        /// This Method is used to fetch messages from L10N xml via super admin WCF service.
        /// </summary>
        /// <param name="MessegeId"></param>
        /// <returns>string as the message</returns>
        public string AD_L10N(string MessegeId)
        {
            using (AdminServiceClient adminServiceClient = new AdminServiceClient())
            {
                try
                {
                    return adminServiceClient.GetAdmin_L10N(MessegeId, CommonConstantModel.s_ManageUsers, CommonConstantModel.s_AdminL10);
                }
                catch
                {
                    throw;
                }
            }

        }

        /// <summary>
        /// This method is used to load all label text from L10N_UI via WCF service
        /// </summary>
        /// <param name="manageUsers">The manage user page of aspx.cs side</param>
        public void BindPageUI(Manage_Users manageUsers)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    using (DataTable dt_ManagerUsersUI = adminServiceClient.GetAdmin_L10N_UI(CommonConstantModel.s_ManageUsers, CommonConstantModel.s_AdminL10_UI))
                    {

                        manageUsers.lblMUPagehead.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUPagehead'"))[0]["LabelName"]);
                        manageUsers.lblMUAccordMngeHead.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUAccordMngeHead'"))[0]["LabelName"]);
                        manageUsers.lblMUAccordEditHead.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUAccordEditHead'"))[0]["LabelName"]);
                        manageUsers.lblMUUserName.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUUserName'"))[0]["LabelName"]);
                        manageUsers.lblMUUserName.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUUserName'"))[0]["LabelToolTip"]);

                        manageUsers.lblMULoginId.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMULoginId'"))[0]["LabelName"]);
                        manageUsers.lblMULoginId.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMULoginId'"))[0]["LabelToolTip"]);

                        manageUsers.lblMUStatus.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUStatus'"))[0]["LabelName"]);
                        manageUsers.lblMUStatus.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUStatus'"))[0]["LabelToolTip"]);

                        manageUsers.lblMUUNameEdit.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUUNameEdit'"))[0]["LabelName"]);
                        manageUsers.lblMUUNameEdit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUUNameEdit'"))[0]["LabelToolTip"]);
                        manageUsers.RqdFieldTxtEditMName.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUUNameEdit'"))[0]["ErrorText"]);

                        manageUsers.lblMULoginIDEdit.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMULoginIDEdit'"))[0]["LabelName"]);
                        manageUsers.lblMULoginIDEdit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMULoginIDEdit'"))[0]["LabelToolTip"]);
                        manageUsers.RqdFieldLoginEdit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMULoginIDEdit'"))[0]["ErrorText"]);
                        manageUsers.RegExpLoginId.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMULoginIDEdit'"))[0]["ErrorText2"]);

                        manageUsers.lblMUEmailIdEdit.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUEmailIdEdit'"))[0]["LabelName"]);
                        manageUsers.lblMUEmailIdEdit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUEmailIdEdit'"))[0]["LabelToolTip"]);
                        manageUsers.RqdFieldEmailEdit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUEmailIdEdit'"))[0]["ErrorText"]);
                        manageUsers.RegExpEmail.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUEmailIdEdit'"))[0]["ErrorText2"]);

                        manageUsers.lblMUAssignRole.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUAssignRole'"))[0]["LabelName"]);
                        manageUsers.lblMUAssignRole.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUAssignRole'"))[0]["LabelToolTip"]);
                        manageUsers.RoleValidFilter.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUAssignRole'"))[0]["ErrorText"]);

                        manageUsers.lblMUUserType.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUUserType'"))[0]["LabelName"]);
                        manageUsers.lblMUUserType.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUUserType'"))[0]["LabelToolTip"]);
                        manageUsers.RgeValidUtype.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUUserType'"))[0]["ErrorText"]);

                        manageUsers.lblMUEmpVAcc.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUEmpVAcc'"))[0]["LabelName"]);
                        manageUsers.lblMUEmpVAcc.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUEmpVAcc'"))[0]["LabelToolTip"]);

                        manageUsers.lblMUStatusEdit.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUStatusEdit'"))[0]["LabelName"]);
                        manageUsers.lblMUStatusEdit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUStatusEdit'"))[0]["LabelToolTip"]);
                        manageUsers.RgeValidFilterEdit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='lblMUStatusEdit'"))[0]["ErrorText"]);

                        manageUsers.BtnMUGridfilter.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='BtnMUGridfilter'"))[0]["LabelName"]);
                        manageUsers.BtnMUGridfilter.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='BtnMUGridfilter'"))[0]["LabelToolTip"]);
                        manageUsers.btnMUClearFilter.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='btnMUClearFilter'"))[0]["LabelName"]);
                        manageUsers.btnMUClearFilter.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='btnMUClearFilter'"))[0]["LabelToolTip"]);
                        manageUsers.btnMUCreateNew.Value = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='btnMUCreateNew'"))[0]["LabelName"]);
                        manageUsers.btnMUSubmit.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='btnMUSubmit'"))[0]["LabelName"]);
                        manageUsers.btnMUSubmit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='btnMUSubmit'"))[0]["LabelToolTip"]);
                        manageUsers.btnMUCancel.Value = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='btnMUCancel'"))[0]["LabelName"]);
                        manageUsers.btnMUDelete.Text = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='btnMUDelete'"))[0]["LabelName"]);
                        manageUsers.btnMUDelete.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='btnMUDelete'"))[0]["LabelToolTip"]);

                        manageUsers.RegExpLoginId.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='ToolTipLoginIdInvalid'"))[0]["LabelName"]);
                        manageUsers.RegExpEmail.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='ToolTipEmailInvalid'"))[0]["LabelName"]);
                        manageUsers.RqdFieldTxtEditMName.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='ToolTipRqdFieldTxtEditMName'"))[0]["LabelName"]);
                        manageUsers.RqdFieldLoginEdit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='ToolTipRqdFieldLoginEdit'"))[0]["LabelName"]);
                        manageUsers.RqdFieldEmailEdit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='ToolTipRqdFieldEmailEdit'"))[0]["LabelName"]);
                        manageUsers.RgeValidFilterEdit.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='ToolTipRgeValidFilterEdit'"))[0]["LabelName"]);
                        manageUsers.RgeValidUtype.ToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID='ToolTipRgeValidUtype'"))[0]["LabelName"]);

                        s_BtnUpdateText = Convert.ToString((dt_ManagerUsersUI.Select("LabelID = 'btnMUUpdate'"))[0]["LabelName"]);
                        s_BtnUpdateToolTip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID = 'btnMUUpdate'"))[0]["LabelToolTip"]);
                        s_BtnSaveText = Convert.ToString((dt_ManagerUsersUI.Select("LabelID = 'btnMUSubmit'"))[0]["LabelName"]);
                        s_BtnSaveTooltip = Convert.ToString((dt_ManagerUsersUI.Select("LabelID = 'btnMUSubmit'"))[0]["LabelToolTip"]);
                    }
                }
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// This method is used to load content of IsActive dropdown list
        /// </summary>
        /// <returns>int</returns>
        internal void PerformCUD(Manage_Users manageUsers, string MmId, string s_Action)
        {
            using (AdminServiceClient adminServiceClient = new AdminServiceClient())
            {
                if (s_Action == "C")
                {
                    adminProperties.LoginPassword = CommonModel.GenerateRandomPassword();
                }
                adminProperties.LoginId = manageUsers.txtMuLoginIdEdit.Text;

                adminProperties.Id = MmId.Contains(",") ? 0 : Convert.ToInt32(MmId);
                adminProperties.Ids = MmId;
                adminProperties.Name = CommonModel.ReplaceApostrophe(manageUsers.txtUserNameEdit.Text);
                adminProperties.Email = manageUsers.txtMuEmailId.Text;
                adminProperties.Role = Convert.ToInt32(manageUsers.ddMuRoleEdit.SelectedValue);
                adminProperties.UType = Convert.ToInt32(manageUsers.ddMuUserType.SelectedValue);
                adminProperties.Emp_wise_Acc = Convert.ToInt32(manageUsers.chkMuEmpWiseAcc.Checked);
                adminProperties.isActive = Convert.ToInt32(manageUsers.ddMUIsActiveEdit.SelectedValue);
                adminProperties.Action = s_Action;

                adminProperties.CreatedBy = userSessionInfo.ACC_UerTypeID;
                adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                manageUsers.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                try
                {
                    switch (adminServiceClient.CRUDAdminOperations("ManageUsers", "CUD", adminProperties).a_result)
                    {
                        case 0:
                            manageUsers.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblMUError", CommonConstantModel.s_ManageUsers, CommonConstantModel.s_AdminL10);
                            manageUsers.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            break;

                        case 1:
                            manageUsers.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblMUAdded", CommonConstantModel.s_ManageUsers, CommonConstantModel.s_AdminL10);
                            manageUsers.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            SendMailConfirmation(manageUsers, adminProperties.LoginPassword);
                            manageUsers.hdnAccordionIndex.Value = "0";
                            break;

                        case 2:
                            manageUsers.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblMUUpdated", CommonConstantModel.s_ManageUsers, CommonConstantModel.s_AdminL10);
                            manageUsers.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            manageUsers.hdnAccordionIndex.Value = "0";
                            break;

                        case 3:
                            manageUsers.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblMURowDeleted", CommonConstantModel.s_ManageUsers, CommonConstantModel.s_AdminL10);
                            manageUsers.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Blue;
                            manageUsers.hdnAccordionIndex.Value = "0";
                            break;

                        case 4:
                            manageUsers.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblMUUserExist", CommonConstantModel.s_ManageUsers, CommonConstantModel.s_AdminL10);
                            manageUsers.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            manageUsers.hdnAccordionIndex.Value = "1";
                            break;

                        case 5:
                            manageUsers.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblMUReverseDeletedUser", CommonConstantModel.s_ManageUsers, CommonConstantModel.s_AdminL10);
                            manageUsers.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            manageUsers.ctrSuccessErrorMessage.s_RevOptionsDisplay = "block";
                            ac_ManageUser.reversingUName = adminProperties.LoginId;
                            ac_ManageUser.reversingEmail = adminProperties.Email;
                            ac_ManageUser.reversingUStatus = adminProperties.isActive;
                            ac_ManageUser.reversingURole = adminProperties.Role;
                            ac_ManageUser.reversingUType = Convert.ToInt16(adminProperties.UType);
                            ac_ManageUser.reversingEmpwiseAcc = adminProperties.Emp_wise_Acc;
                            manageUsers.hdnAccordionIndex.Value = "1";
                            break;

                        case 7:
                            manageUsers.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblMUEmailExist", CommonConstantModel.s_ManageUsers, CommonConstantModel.s_AdminL10);
                            manageUsers.ctrSuccessErrorMessage.s_MsgForeColor = System.Drawing.Color.Red;
                            manageUsers.hdnAccordionIndex.Value = "1";
                            break;
                    }
                    manageUsers.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
                    if (manageUsers.hdnAccordionIndex.Value == "0")
                    {
                        manageUsers.txtUserNameEdit.Text = "";
                        manageUsers.txtMuLoginIdEdit.Text = "";
                        manageUsers.txtMuEmailId.Text = "";
                        manageUsers.ddMUIsActiveEdit.SelectedIndex = 0;
                    }
                }
                catch
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// Method is used to send an email confirmation to the created user with login details
        /// </summary>
        /// <param name="manageUsers"></param>
        /// <param name="s_LoginPassword"></param>
        private void SendMailConfirmation(Manage_Users manageUsers, string s_LoginPassword)
        {
            try
            {
                using (GenericServiceClient genericServiceClient = new GenericServiceClient())
                {
                    var s_MailBody = File.ReadAllText(ConfigurationManager.AppSettings["BinariesPath"] + @"\Mails\UserLoginDetailsMailAlert.html");
                    emailProperties.s_MailBody = s_MailBody.Replace("@UserName", manageUsers.txtUserNameEdit.Text).Replace("@URL", ConfigurationManager.AppSettings["SiteURL"]).Replace("@LoginName", manageUsers.txtMuLoginIdEdit.Text).Replace("@Password", s_LoginPassword).Replace("@CompanyName", userSessionInfo.ACC_CompanyName).Replace("@ValCustSupportID", ConfigurationManager.AppSettings["ValCustSupport"]);
                    emailProperties.s_MailFrom = Convert.ToString(ConfigurationManager.AppSettings["MailFrom"]);
                    emailProperties.b_IsBodyHtml = true;
                    emailProperties.s_MailTo = manageUsers.txtMuEmailId.Text;
                    emailProperties.s_MailCC = "";
                    emailProperties.s_MailBCC = "";
                    emailProperties.s_MailSubject = "EDFinancials - Login Details";

                    genericServiceClient.SaveSendMail(emailProperties);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method is used to load grid view data 
        /// </summary>
        /// <returns>DataTable</returns>
        public void LoadGridData(Manage_Users manageUsers, string Action)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.Name = manageUsers.ddMUUserName.SelectedItem != null ? manageUsers.ddMUUserName.SelectedItem.ToString() : "";
                    adminProperties.isActive = Convert.ToInt32(manageUsers.ddMUIsActive.SelectedValue);
                    adminProperties.Action = Action;

                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    ac_ManageUser.dt_ManageUsers = adminServiceClient.CRUDAdminOperations("ManageUsers", "Read", adminProperties).dt_Result;
                    manageUsers.gv.DataSource = ac_ManageUser.dt_ManageUsers;
                    manageUsers.gv.DataBind();

                    manageUsers.btnMUClearFilter.Visible = false;
                    manageUsers.btnMUDelete.Visible = manageUsers.gv.Rows.Count > 0 ? true : false;
                }
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// Filters Grid view data according to the parameters selected
        /// </summary>
        /// <param name="manageUsers">manageUsers Page object</param>
        public void FilterGridData(Manage_Users manageUsers)
        {
            using (SuperAdminServiceClient superAdminServiceClient = new SuperAdminServiceClient())
            {
                try
                {
                    string s_UserName = manageUsers.ddMUUserName.SelectedIndex > 0 ? "[User Name] = '" + Convert.ToString(manageUsers.ddMUUserName.SelectedItem) + "'" : string.Empty;
                    string s_Status = manageUsers.ddMUIsActive.SelectedIndex > 0 ? "[Status] = '" + Convert.ToString(manageUsers.ddMUIsActive.SelectedItem.ToString()) + "'" : string.Empty;

                    if ((!(string.IsNullOrEmpty(s_UserName))) || (!(string.IsNullOrEmpty(s_Status))))
                    {
                        manageUsers.btnMUClearFilter.Visible = true;
                        manageUsers.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";
                    }

                    ac_ManageUser.dt_TempManageUsers = ac_ManageUser.dt_ManageUsers;

                    try
                    {
                        if (!(string.IsNullOrEmpty(s_UserName)))
                            ac_ManageUser.dt_TempManageUsers = ac_ManageUser.dt_TempManageUsers.Select("" + s_UserName + "").CopyToDataTable();

                        if (!(string.IsNullOrEmpty(s_Status)))
                            ac_ManageUser.dt_TempManageUsers = ac_ManageUser.dt_TempManageUsers.Select("" + s_Status + "").CopyToDataTable();

                        if (string.IsNullOrEmpty(s_Status) && string.IsNullOrEmpty(s_UserName))
                        {
                            ac_ManageUser.dt_TempManageUsers = ac_ManageUser.dt_TempManageUsers;
                            manageUsers.btnMUClearFilter.Visible = false;
                        }
                    }
                    catch
                    {
                        ac_ManageUser.dt_TempManageUsers = new DataTable();
                    }

                    manageUsers.gv.DataSource = ac_ManageUser.dt_TempManageUsers;
                    manageUsers.gv.DataBind();
                    manageUsers.btnMUDelete.Visible = manageUsers.gv.Rows.Count > 0 ? true : false;
                }
                catch
                {
                    throw;
                }

                manageUsers.btnMUDelete.Visible = manageUsers.gv.Rows.Count > 0 ? true : false;
            }
        }

        /// <summary>
        /// This method loads and binds Username dropdown list
        /// </summary>
        /// <param name="manageUsers"></param>
        public void LoadUNameDropdown(Manage_Users manageUsers)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.Action = "N";
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    manageUsers.ddMUUserName.DataSource = adminServiceClient.CRUDAdminOperations("ManageUsers", "Read", adminProperties).dt_Result;
                    manageUsers.ddMUUserName.DataTextField = "USER_NAME";
                    manageUsers.ddMUUserName.DataValueField = "UMID";
                    manageUsers.ddMUUserName.DataBind();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method fetches the status of employee wise access checkbox on the basis of My ESOP/Non My ESOP company
        /// </summary>
        /// <param name="manageUsers">Manage User page</param>
        public void LoadEmpwisestatus(Manage_Users manageUsers)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.Action = "ES";
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminProperties.Name = adminProperties.SEN_CompanyName;
                    manageUsers.chkMuEmpWiseAcc.Enabled = Convert.ToBoolean(adminServiceClient.CRUDAdminOperations("ManageUsers", "Read", adminProperties).dt_Result.Rows[0][0]);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method fetches respective LoginId and user status for particular user selected in ddMU User name dropdown. 
        /// </summary>
        /// <param name="manageUsers">Manage User page</param>
        /// <param name="Action">Action to be performed.</param>
        public void LoadUserDetails(Manage_Users manageUsers, string Action)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.Action = Action;
                    adminProperties.Name = manageUsers.ddMUUserName.SelectedItem.ToString();

                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    using (DataTable dt_dataTable = adminServiceClient.CRUDAdminOperations("ManageUsers", "Read", adminProperties).dt_Result)
                    {
                        manageUsers.txtMuLoginId.Text = dt_dataTable.Rows[0]["LOGIN_ID"].ToString();
                        manageUsers.ddMUIsActive.SelectedValue = Convert.ToInt16(dt_dataTable.Rows[0]["IS_ACTIVE"]).ToString();
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// load IsActive selection dropdown list
        /// </summary>
        /// <returns>DropDownList</returns>
        public DropDownList Load_ddIsactive(DropDownList dropDownList, string Action)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.Action = Action;
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;

                    dropDownList.DataSource = adminServiceClient.CRUDAdminOperations("ManageUsers", "Read", adminProperties).dt_Result;
                    dropDownList.DataTextField = "DATA";
                    dropDownList.DataValueField = "VALUE";
                    dropDownList.DataBind();

                    return dropDownList;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Add Delete all checkbox
        /// </summary>
        /// <returns></returns>
        private CheckBox AddDeleteAllCheckBox()
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.ID = "chkDeleteAll";
                checkBox.InputAttributes.Add("Value", "0");
                checkBox.Text = string.Empty;
                checkBox.Checked = false;
                checkBox.AutoPostBack = false;
                checkBox.ClientIDMode = System.Web.UI.ClientIDMode.Static;
                checkBox.Attributes.Add("Onclick", "javascript : return SelectAllCheckBoxes(this);");
                return checkBox;
            }
        }

        /// <summary>
        ///This method Binds Grid view row and column
        /// </summary>
        /// <param name="e">Row Event</param>
        /// <param name="n_index">index number</param>
        /// <param name="n_ID">ID</param>
        /// <param name="n_Delete">Delete ID</param>
        /// <param name="n_Action">Action to be Performed</param>
        public void BindRows(GridViewRowEventArgs e, ref int n_index, ref int n_ID, ref int n_Delete, ref int n_Action)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:
                    try
                    {
                        foreach (DataControlFieldHeaderCell perColumn in e.Row.Cells)
                        {

                            switch (perColumn.Text.ToUpper())
                            {
                                case "UMID":
                                    n_ID = n_index;
                                    perColumn.Visible = false;
                                    break;

                                case "DELETE":
                                    n_Delete = n_index;
                                    e.Row.Cells[n_Delete].Controls.Add(AddDeleteAllCheckBox());
                                    break;

                                case "ACTION":
                                    n_Action = n_index;
                                    break;

                                case "ROLEID":
                                    perColumn.Visible = false;
                                    break;

                                case "USERTYPEID":
                                    perColumn.Visible = false;
                                    break;
                            }
                            n_index = n_index + 1;
                        }
                    }
                    catch
                    {
                        throw;
                    }
                    break;

                case DataControlRowType.DataRow:
                    try
                    {
                        e.Row.Cells[n_ID].Visible = false;
                        e.Row.Cells[n_Action].Controls.Add(AddImageLink("Edit", "~/View/App_Themes/images/Edit.png", e.Row.Cells[0].Text, e.Row.Cells[2].Text, e.Row.Cells[3].Text, e.Row.Cells[4].Text, e.Row.Cells[5].Text, e.Row.Cells[7].Text, e.Row.Cells[9].Text, e.Row.Cells[10].Text, "Edit"));
                        e.Row.Cells[1].Controls.Add(AddCheckBox(e.Row.Cells[0].Text, e.Row.Cells[n_Delete].Text.Equals("1")));
                        e.Row.Cells[n_Delete].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[n_Action].HorizontalAlign = HorizontalAlign.Center;
                        e.Row.Cells[9].Visible = false;
                        e.Row.Cells[7].Visible = false;
                    }
                    catch
                    {
                        throw;
                    }
                    break;

            }
        }

        /// <summary>
        /// This method is used to add image link control on page.
        /// </summary>
        /// <param name="s_strToolTip">ToolTip for Image Button</param>
        /// <param name="s_strUrl">Image Url</param>
        /// <param name="s_MUID">MUID</param>
        /// <param name="s_Name">UserName</param>
        /// <param name="s_LoginId">Login ID</param>
        /// <param name="s_EmailId">Email Id</param>
        /// <param name="s_Status">Status</param>
        /// <param name="n_RmId">Role Id</param>
        /// <param name="s_UTypeId">User type Id</param>
        /// <param name="s_EmpWiseAccess">Employee wise Acess</param>
        /// <param name="Action">Action to be performed</param>
        /// <returns></returns>
        private ImageButton AddImageLink(string s_strToolTip, string s_strUrl, string s_MUID, string s_Name, string s_LoginId, string s_EmailId, string s_Status, string n_RmId, string s_UTypeId, string s_EmpWiseAccess, string Action)
        {
            int n_status = s_Status == "Activated" ? 2 : 1;

            using (ImageButton imgButton = new ImageButton())
            {
                imgButton.ImageUrl = s_strUrl;
                imgButton.ToolTip = s_strToolTip;
                imgButton.Style.Add("cursor", "pointer");

                if (!string.IsNullOrEmpty(s_MUID))
                {
                    using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                    {
                        imgButton.Attributes.Add("onclick", "return ShowEditSection('" + s_Name + "','" + s_LoginId + "','" + s_EmailId + "','" + n_status + "','" + n_RmId + "','" + s_UTypeId + "', '" + s_EmpWiseAccess + "','" + s_MUID + "','" + 1 + "')");
                    }
                }

                return imgButton;
            }
        }

        /// <summary>
        /// to add checkboxes
        /// </summary>
        /// <returns></returns>
        private CheckBox AddCheckBox(string s_ManageModuleGroupID, bool IsDeleted)
        {
            using (CheckBox checkBox = new CheckBox())
            {
                checkBox.InputAttributes.Add("Value", s_ManageModuleGroupID);
                checkBox.ID = "chk";
                checkBox.Checked = IsDeleted;
                checkBox.Attributes.Add("name", "Types");

                if (!string.IsNullOrEmpty(s_ManageModuleGroupID))
                {
                    checkBox.Attributes.Add("onclick", "return DeleteSelectedRecords('" + s_ManageModuleGroupID + "',this)");
                }

                return checkBox;
            }
        }

        /// <summary>
        /// To change pages of grid view
        /// </summary>
        /// <returns></returns>
        internal void PageIndexChanging(object sender, GridViewPageEventArgs e, GridView gv, string s_ManageUsersGroupID)
        {
            try
            {
                string[] s_AssociateModuleGpID = s_ManageUsersGroupID.TrimStart(',').Split(',');

                ac_ManageUser.dt_ManageUsers.Columns["Delete"].Expression = string.Empty;
                ac_ManageUser.dt_ManageUsers.AcceptChanges();

                foreach (string perID in s_AssociateModuleGpID)
                {
                    if (!perID.Equals(string.Empty))
                    {
                        foreach (DataRow perRow in ac_ManageUser.dt_ManageUsers.Select("UMID='" + perID + "'"))
                        {
                            perRow["Delete"] = 1;
                            perRow.AcceptChanges();
                        }
                    }
                }

                gv.PageIndex = e.NewPageIndex;
                gv.DataSource = ac_ManageUser.dt_ManageUsers;
                gv.DataBind();
            }
            catch
            {
                throw;
            }
        }

        #region Destructors
        /// <summary>
        /// Finalizes an instance of the <see cref="ManageUsersModel"/> class.
        /// </summary>
        ~ManageUsersModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}