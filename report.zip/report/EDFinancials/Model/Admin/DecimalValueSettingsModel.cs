﻿using EDFinancials.Model.Generic;
using EDFinancials.View.Admin;
using System;
using System.Data;
using System.Drawing;

namespace EDFinancials.Model.Admin
{
    /// <summary>
    /// Model class for DecimalValueSettings page
    /// </summary>
    public class DecimalValueSettingsModel : BaseModel, IDisposable
    {
        #region Static Variables

        /// <summary>
        /// Public Static Variables
        /// </summary>
        public static string s_BtnUpdateText = string.Empty;

        #endregion

        /// <summary>
        /// Method is used to bind UI 
        /// </summary>
        /// <param name="decimalValueSettings">Page object as parameter</param>
        internal void BindPageUI(DecimalValueSettings decimalValueSettings)
        {
            try
            {
                decimalValueSettings.ctrSuccessErrorMessage.s_MsgBoxDisplay = "none";

                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    using (DataTable dt_DecimalValSetUI = adminServiceClient.GetAdmin_L10N_UI(CommonConstantModel.s_DecimalValueSettings, CommonConstantModel.s_AdminL10_UI))
                    {
                        if ((dt_DecimalValSetUI != null) && (dt_DecimalValSetUI.Rows.Count > 0))
                        {
                            decimalValueSettings.lblDecimalPageSetHeader.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblDecimalPageSetHeader'"))[0]["LabelName"]);
                            decimalValueSettings.lblDecimalPageSetSearch.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblDecimalPageSetSearch'"))[0]["LabelName"]);
                            decimalValueSettings.lblRoundIntrinsicValue.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblRoundIntrinsicValue'"))[0]["LabelName"]);
                            decimalValueSettings.lblRoundFairValue.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblRoundFairValue'"))[0]["LabelName"]);
                            decimalValueSettings.lblRoundMarketPrice.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblRoundMarketPrice'"))[0]["LabelName"]);
                            decimalValueSettings.lblRoundExercisePrice.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblRoundExercisePrice'"))[0]["LabelName"]);
                            decimalValueSettings.lblRoundExpectedLife.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblRoundExpectedLife'"))[0]["LabelName"]);
                            decimalValueSettings.lblRoundVolatility.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblRoundVolatility'"))[0]["LabelName"]);
                            decimalValueSettings.lblRoundRiskFreeInterestRate.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblRoundRiskFreeInterestRate'"))[0]["LabelName"]);
                            decimalValueSettings.lblRoundDividendYield.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblRoundDividendYield'"))[0]["LabelName"]);
                            decimalValueSettings.lblRoundValuationCost.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblRoundValuationCost'"))[0]["LabelName"]);
                            decimalValueSettings.lblRoundCompensationCost.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'lblRoundCompensationCost'"))[0]["LabelName"]);

                            decimalValueSettings.valReqIntrinsicValue.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valReqIntrinsicValue'"))[0]["ErrorText"]);
                            decimalValueSettings.valReqFairValue.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valReqFairValue'"))[0]["ErrorText"]);
                            decimalValueSettings.valReqMarketPrice.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valReqMarketPrice'"))[0]["ErrorText"]);
                            decimalValueSettings.valReqExercisePrice.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valReqExercisePrice'"))[0]["ErrorText"]);
                            decimalValueSettings.valReqExpectedLife.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valReqExpectedLife'"))[0]["ErrorText"]);
                            decimalValueSettings.valReqVolatility.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valReqVolatility'"))[0]["ErrorText"]);
                            decimalValueSettings.valReqRiskFreeInterestRate.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valReqRiskFreeInterestRate'"))[0]["ErrorText"]);
                            decimalValueSettings.valReqDividendYield.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valReqDividendYield'"))[0]["ErrorText"]);
                            decimalValueSettings.valReqValuationCost.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valReqValuationCost'"))[0]["ErrorText"]);
                            decimalValueSettings.valreqCompensationCost.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valreqCompensationCost'"))[0]["ErrorText"]);

                            decimalValueSettings.valRegIntrinsicValue.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valRegIntrinsicValue'"))[0]["ErrorText"]);
                            decimalValueSettings.valRegFairValue.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valRegFairValue'"))[0]["ErrorText"]);
                            decimalValueSettings.valRegMarketPrice.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valRegMarketPrice'"))[0]["ErrorText"]);
                            decimalValueSettings.valRegExercisePrice.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valRegExercisePrice'"))[0]["ErrorText"]);
                            decimalValueSettings.valRegExpectedLife.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valRegExpectedLife'"))[0]["ErrorText"]);
                            decimalValueSettings.valRegVolatility.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valRegVolatility'"))[0]["ErrorText"]);
                            decimalValueSettings.valRegRiskFreeInterestRate.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valRegRiskFreeInterestRate'"))[0]["ErrorText"]);
                            decimalValueSettings.valRegDividendYield.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valRegDividendYield'"))[0]["ErrorText"]);
                            decimalValueSettings.valregValuationCost.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valregValuationCost'"))[0]["ErrorText"]);
                            decimalValueSettings.valregCompensationCost.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'valregCompensationCost'"))[0]["ErrorText"]);

                            decimalValueSettings.btnUpdate.Text = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'btnUpdate'"))[0]["LabelName"]);
                            decimalValueSettings.btnUpdate.ToolTip = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'btnUpdate'"))[0]["LabelToolTip"]);
                            s_BtnUpdateText = Convert.ToString((dt_DecimalValSetUI.Select("LabelID = 'btnUpdate'"))[0]["LabelName"]);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method is used to bind default rounding parameter value to drop down list
        /// </summary>
        /// <param name="decimalValueSettings">Page object as parameter</param>
        internal void BindDefaultRoundingParm(DecimalValueSettings decimalValueSettings)
        {
            try
            {

                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminProperties.PopulateControl = "BindDefaultRoundingParm";
                    adminProperties.Action = "BindDefaultRounding";
                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_DecimalValueSettings, CommonConstantModel.s_AdminRead, adminProperties);

                    if (adminCRUDProperties.dt_Result != null && adminCRUDProperties.dt_Result.Rows.Count > 0)
                    {
                        decimalValueSettings.ddlIntrinsicValuePram.DataSource = adminCRUDProperties.dt_Result;
                        decimalValueSettings.ddlIntrinsicValuePram.DataValueField = "Alias";
                        decimalValueSettings.ddlIntrinsicValuePram.DataTextField = "ParmText";
                        decimalValueSettings.ddlIntrinsicValuePram.DataBind();

                        decimalValueSettings.ddlFairValueParm.DataSource = adminCRUDProperties.dt_Result;
                        decimalValueSettings.ddlFairValueParm.DataValueField = "Alias";
                        decimalValueSettings.ddlFairValueParm.DataTextField = "ParmText";
                        decimalValueSettings.ddlFairValueParm.DataBind();

                        decimalValueSettings.ddlMarketPricePram.DataSource = adminCRUDProperties.dt_Result;
                        decimalValueSettings.ddlMarketPricePram.DataValueField = "Alias";
                        decimalValueSettings.ddlMarketPricePram.DataTextField = "ParmText";
                        decimalValueSettings.ddlMarketPricePram.DataBind();

                        decimalValueSettings.ddlExercisePricePram.DataSource = adminCRUDProperties.dt_Result;
                        decimalValueSettings.ddlExercisePricePram.DataValueField = "Alias";
                        decimalValueSettings.ddlExercisePricePram.DataTextField = "ParmText";
                        decimalValueSettings.ddlExercisePricePram.DataBind();

                        decimalValueSettings.ddlExpectedLifePram.DataSource = adminCRUDProperties.dt_Result;
                        decimalValueSettings.ddlExpectedLifePram.DataValueField = "Alias";
                        decimalValueSettings.ddlExpectedLifePram.DataTextField = "ParmText";
                        decimalValueSettings.ddlExpectedLifePram.DataBind();

                        decimalValueSettings.ddlVolatilityPram.DataSource = adminCRUDProperties.dt_Result;
                        decimalValueSettings.ddlVolatilityPram.DataValueField = "Alias";
                        decimalValueSettings.ddlVolatilityPram.DataTextField = "ParmText";
                        decimalValueSettings.ddlVolatilityPram.DataBind();

                        decimalValueSettings.ddlRiskFreeInterestRatePram.DataSource = adminCRUDProperties.dt_Result;
                        decimalValueSettings.ddlRiskFreeInterestRatePram.DataValueField = "Alias";
                        decimalValueSettings.ddlRiskFreeInterestRatePram.DataTextField = "ParmText";
                        decimalValueSettings.ddlRiskFreeInterestRatePram.DataBind();

                        decimalValueSettings.ddlDividendYieldPram.DataSource = adminCRUDProperties.dt_Result;
                        decimalValueSettings.ddlDividendYieldPram.DataValueField = "Alias";
                        decimalValueSettings.ddlDividendYieldPram.DataTextField = "ParmText";
                        decimalValueSettings.ddlDividendYieldPram.DataBind();

                        decimalValueSettings.ddlValuationCostPram.DataSource = adminCRUDProperties.dt_Result;
                        decimalValueSettings.ddlValuationCostPram.DataValueField = "Alias";
                        decimalValueSettings.ddlValuationCostPram.DataTextField = "ParmText";
                        decimalValueSettings.ddlValuationCostPram.DataBind();

                        decimalValueSettings.ddlCompensationCostPram.DataSource = adminCRUDProperties.dt_Result;
                        decimalValueSettings.ddlCompensationCostPram.DataValueField = "Alias";
                        decimalValueSettings.ddlCompensationCostPram.DataTextField = "ParmText";
                        decimalValueSettings.ddlCompensationCostPram.DataBind();
                    }
                }
            }
            catch
            {

                throw;
            }
        }

        /// <summary>
        /// Method is used to bind default rounding value and rounding parameter to control
        /// </summary>
        /// <param name="decimalValueSettings">Page object as parameter</param>
        internal void BindDefaultValueControls(DecimalValueSettings decimalValueSettings)
        {
            try
            {
                using (AdminServiceClient adminServiceClient = new AdminServiceClient())
                {
                    adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                    adminProperties.PopulateControl = "BindDefaultDataToPage";
                    adminProperties.Action = "BindDefaultData";
                    adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_DecimalValueSettings, CommonConstantModel.s_AdminRead, adminProperties);

                    if (adminCRUDProperties.dt_Result != null && adminCRUDProperties.dt_Result.Rows.Count > 0)
                    {
                        decimalValueSettings.txtRoundIntrinsicValue.Text = Convert.ToString(adminCRUDProperties.dt_Result.Rows[0]["ROUNDING_PLACE_VALUE"]);
                        decimalValueSettings.txtRoundFairValue.Text = Convert.ToString(adminCRUDProperties.dt_Result.Rows[1]["ROUNDING_PLACE_VALUE"]);
                        decimalValueSettings.txtRoundMarketPrice.Text = Convert.ToString(adminCRUDProperties.dt_Result.Rows[2]["ROUNDING_PLACE_VALUE"]);
                        decimalValueSettings.txtRoundExercisePrice.Text = Convert.ToString(adminCRUDProperties.dt_Result.Rows[3]["ROUNDING_PLACE_VALUE"]);
                        decimalValueSettings.txtRoundExpectedLife.Text = Convert.ToString(adminCRUDProperties.dt_Result.Rows[4]["ROUNDING_PLACE_VALUE"]);
                        decimalValueSettings.txtRoundVolatility.Text = Convert.ToString(adminCRUDProperties.dt_Result.Rows[5]["ROUNDING_PLACE_VALUE"]);
                        decimalValueSettings.txtRoundRiskFreeInterestRate.Text = Convert.ToString(adminCRUDProperties.dt_Result.Rows[6]["ROUNDING_PLACE_VALUE"]);
                        decimalValueSettings.txtRoundDividendYield.Text = Convert.ToString(adminCRUDProperties.dt_Result.Rows[7]["ROUNDING_PLACE_VALUE"]);
                        decimalValueSettings.txtRoundValuationCost.Text = Convert.ToString(adminCRUDProperties.dt_Result.Rows[8]["ROUNDING_PLACE_VALUE"]);
                        decimalValueSettings.txtCompensationCost.Text = Convert.ToString(adminCRUDProperties.dt_Result.Rows[9]["ROUNDING_PLACE_VALUE"]);

                        decimalValueSettings.ddlIntrinsicValuePram.SelectedValue = Convert.ToString(adminCRUDProperties.dt_Result.Rows[0]["ROUNDING_PLACE_PARM"]);
                        decimalValueSettings.ddlFairValueParm.SelectedValue = Convert.ToString(adminCRUDProperties.dt_Result.Rows[1]["ROUNDING_PLACE_PARM"]);
                        decimalValueSettings.ddlMarketPricePram.SelectedValue = Convert.ToString(adminCRUDProperties.dt_Result.Rows[2]["ROUNDING_PLACE_PARM"]);
                        decimalValueSettings.ddlExercisePricePram.SelectedValue = Convert.ToString(adminCRUDProperties.dt_Result.Rows[3]["ROUNDING_PLACE_PARM"]);
                        decimalValueSettings.ddlExpectedLifePram.SelectedValue = Convert.ToString(adminCRUDProperties.dt_Result.Rows[4]["ROUNDING_PLACE_PARM"]);
                        decimalValueSettings.ddlVolatilityPram.SelectedValue = Convert.ToString(adminCRUDProperties.dt_Result.Rows[5]["ROUNDING_PLACE_PARM"]);
                        decimalValueSettings.ddlRiskFreeInterestRatePram.SelectedValue = Convert.ToString(adminCRUDProperties.dt_Result.Rows[6]["ROUNDING_PLACE_PARM"]);
                        decimalValueSettings.ddlDividendYieldPram.SelectedValue = Convert.ToString(adminCRUDProperties.dt_Result.Rows[7]["ROUNDING_PLACE_PARM"]);
                        decimalValueSettings.ddlValuationCostPram.SelectedValue = Convert.ToString(adminCRUDProperties.dt_Result.Rows[8]["ROUNDING_PLACE_PARM"]);
                        decimalValueSettings.ddlCompensationCostPram.SelectedValue = Convert.ToString(adminCRUDProperties.dt_Result.Rows[9]["ROUNDING_PLACE_PARM"]);
                    }
                }
            }
            catch
            {

                throw;
            }
        }

        /// <summary>
        /// This method  is used to update the settings
        /// </summary>
        /// <param name="decimalValueSettings">Page object as parameter</param>
        internal void UpdateDecimalValueSttings(DecimalValueSettings decimalValueSettings)
        {
            using (AdminServiceClient adminServiceClient = new AdminServiceClient())
            {
                adminProperties.SEN_CompanyName = userSessionInfo.ACC_CompanyName;
                adminProperties.SEN_UserID = userSessionInfo.ACC_UserID;
                adminProperties.IV_ROUND_VALUE = Convert.ToInt32(decimalValueSettings.txtRoundIntrinsicValue.Text);
                adminProperties.IV_ROUND_PARM = Convert.ToString(decimalValueSettings.ddlIntrinsicValuePram.SelectedItem.Value);
                adminProperties.FV_ROUND_VALUE = Convert.ToInt32(decimalValueSettings.txtRoundFairValue.Text);
                adminProperties.FV_ROUND_PARM = Convert.ToString(decimalValueSettings.ddlFairValueParm.SelectedItem.Value);
                adminProperties.MP_ROUND_VALUE = Convert.ToInt32(decimalValueSettings.txtRoundMarketPrice.Text);
                adminProperties.MP_ROUND_PARM = Convert.ToString(decimalValueSettings.ddlMarketPricePram.SelectedItem.Value);
                adminProperties.EP_ROUND_VALUE = Convert.ToInt32(decimalValueSettings.txtRoundExercisePrice.Text);
                adminProperties.EP_ROUND_PARM = Convert.ToString(decimalValueSettings.ddlExercisePricePram.SelectedItem.Value);
                adminProperties.EL_ROUND_VALUE = Convert.ToInt32(decimalValueSettings.txtRoundExpectedLife.Text);
                adminProperties.EL_ROUND_PARM = Convert.ToString(decimalValueSettings.ddlExpectedLifePram.SelectedItem.Value);
                adminProperties.VL_ROUND_VALUE = Convert.ToInt32(decimalValueSettings.txtRoundVolatility.Text);
                adminProperties.VL_ROUND_PARM = Convert.ToString(decimalValueSettings.ddlVolatilityPram.SelectedItem.Value);
                adminProperties.IFIR_ROUND_VALUE = Convert.ToInt32(decimalValueSettings.txtRoundRiskFreeInterestRate.Text);
                adminProperties.IFIR_ROUND_PARM = Convert.ToString(decimalValueSettings.ddlRiskFreeInterestRatePram.SelectedItem.Value);
                adminProperties.DY_ROUND_VALUE = Convert.ToInt32(decimalValueSettings.txtRoundDividendYield.Text);
                adminProperties.DY_ROUND_PARM = Convert.ToString(decimalValueSettings.ddlDividendYieldPram.SelectedItem.Value);
                adminProperties.VC_ROUND_VALUE = Convert.ToInt32(decimalValueSettings.txtRoundValuationCost.Text);
                adminProperties.VC_ROUND_PARM = Convert.ToString(decimalValueSettings.ddlValuationCostPram.SelectedItem.Value);
                adminProperties.CC_ROUND_VALUE = Convert.ToInt32(decimalValueSettings.txtCompensationCost.Text);
                adminProperties.CC_ROUND_PARM = Convert.ToString(decimalValueSettings.ddlCompensationCostPram.SelectedItem.Value);

                adminCRUDProperties = adminServiceClient.CRUDAdminOperations(CommonConstantModel.s_DecimalValueSettings, CommonConstantModel.s_AdminCUD, adminProperties);

                if (adminCRUDProperties.a_result == 1)
                {
                    decimalValueSettings.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                    decimalValueSettings.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblDVScUpdated", CommonConstantModel.s_DecimalValueSettings, CommonConstantModel.s_AdminL10);

                    BindDefaultValueControls(decimalValueSettings);
                }
                else
                {
                    decimalValueSettings.ctrSuccessErrorMessage.s_MsgForeColor = Color.Blue;
                    decimalValueSettings.ctrSuccessErrorMessage.s_MessageText = adminServiceClient.GetAdmin_L10N("lblDVScError", CommonConstantModel.s_DecimalValueSettings, CommonConstantModel.s_AdminL10);
                }

                decimalValueSettings.ctrSuccessErrorMessage.s_MsgBoxDisplay = "block";
            }
        }

        #region Destructors
        /// <summary>
        /// Finalizes an instance of the <see cref="DecimalValueSettingsModel"/> class.
        /// </summary>
        ~DecimalValueSettingsModel()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}