﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Abp.Data;
using Abp.EntityFrameworkCore;
using ESPD.EntityFrameworkCore;
using ESPD.EntityFrameworkCore.Repositories;
using Microsoft.EntityFrameworkCore;

namespace ESPD.Employee
{
    public class EmployeeRepository : ESPDRepositoryBase<Employee, int>, IEmployeeRepository
    {
        private readonly IActiveTransactionProvider _transactionProvider;

        public EmployeeRepository(IDbContextProvider<ESPDDbContext> dbContextProvider, IActiveTransactionProvider transactionProvider)
            : base(dbContextProvider)
        {
            _transactionProvider = transactionProvider;
        }
        public async Task<List<string>> GetAllEmployees()
        {
            EnsureConnectionOpen();
            //List<Employee> lstemployee = new List<Employee>();
            using (var command = CreateCommand("spGetAllEmployees", CommandType.StoredProcedure))
            {
                using (var dataReader = await command.ExecuteReaderAsync())
                {
                    var result = new List<string>();
                    //var e = await _employeeRepository.GetAllListAsync();
                    while (dataReader.Read())
                    {
                        result.Add(Convert.ToInt32(dataReader["EmployeeID"]).ToString());
                        result.Add(dataReader["Name"].ToString());
                        result.Add(dataReader["Gender"].ToString());
                        result.Add(dataReader["Department"].ToString());
                        result.Add(dataReader["City"].ToString());
                    }

                    return result;
                }
            }
        }


        private DbCommand CreateCommand(string commandText, CommandType commandType, params SqlParameter[] parameters)
        {
            var command = Context.Database.GetDbConnection().CreateCommand();

            command.CommandText = commandText;
            command.CommandType = commandType;
            command.Transaction = GetActiveTransaction();

            foreach (var parameter in parameters)
            {
                command.Parameters.Add(parameter);
            }

            return command;
        }

        private void EnsureConnectionOpen()
        {
            var connection = Context.Database.GetDbConnection();

            if (connection.State != ConnectionState.Open)
            {
                connection.Open();
            }
        }

        private DbTransaction GetActiveTransaction()
        {
            return (DbTransaction)_transactionProvider.GetActiveTransaction(new ActiveTransactionProviderArgs
            {
                {"ContextType", typeof(ESPDDbContext) },
                {"MultiTenancySide", MultiTenancySide }
            });
        }
    }
}
