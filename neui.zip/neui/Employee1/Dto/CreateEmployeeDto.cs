﻿namespace ESPD.Employee.Dto
{
    public class CreateEmployeeDto
    {
        public string Name { get; set; }

        public string Gender { get; set; }

        public string Department { get; set; }

        public string City { get; set; }
    }
}
