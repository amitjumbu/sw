﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using ESPD.Employee.Dto;

namespace ESPD.Employee
{
    public class EmployeeAppService : AsyncCrudAppService<Employee, EmployeeDto, int, PagedResultRequestDto, CreateEmployeeDto, EmployeeDto>, IEmployeeAppService
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeAppService(IRepository<Employee> repository, IEmployeeRepository employeeRepository) : base(repository)
        {
            _employeeRepository = employeeRepository;
        }
        public async Task<ListResultDto<Employee>> GetAllEmployees()
        {
            var e = await _employeeRepository.GetAllListAsync();
            return new ListResultDto<Employee>(ObjectMapper.Map<List<Employee>>(e));
        }
    }
}
