﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using ESPD.Employee.Dto;
using System.Threading.Tasks;

namespace ESPD.Employee
{
    public interface IEmployeeAppService : IAsyncCrudAppService<EmployeeDto, int, PagedResultRequestDto, CreateEmployeeDto, EmployeeDto>
    {

        Task<ListResultDto<Employee>> GetAllEmployees();
    }
}
