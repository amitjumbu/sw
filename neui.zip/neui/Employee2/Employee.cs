﻿using Abp.Domain.Entities;
using Abp.Domain.Entities.Auditing;
using System;
using System.ComponentModel.DataAnnotations;

namespace ESPD.Employee
{
    public class Employee : Entity
    {
        public const int MaxNameLength = 32;

        [Required]
        [MaxLength(MaxNameLength)]
        public string Name { get; set; }        

        public string Gender { get; set; }

        public string Department { get; set; }

        public string City { get; set; }
        public Employee()
        {

        }
        public Employee(string name)
        {
            Name = name;
        }
    }
}
