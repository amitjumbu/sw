﻿using Abp.Domain.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ESPD.Employee
{
    public interface IEmployeeRepository: IRepository<Employee,int>
    {
        Task<List<string>> GetAllEmployees();
    }
}
