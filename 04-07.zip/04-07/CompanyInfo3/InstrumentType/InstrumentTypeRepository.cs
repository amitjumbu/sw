﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Abp.Data;
using Abp.EntityFrameworkCore;
using MyReEsop.EntityFrameworkCore;
using MyReEsop.EntityFrameworkCore.Repositories;
using Microsoft.EntityFrameworkCore;
using MyReEsop.CompanyInfo.InstrumentType.Dtos;
using Abp.Application.Services.Dto;
using System.Threading;

namespace MyReEsop.CompanyInfo.InstrumentType
{
    public class InstrumentTypeRepository : MyReEsopRepositoryBase<InstrumentType,int>, IInstrumentTypeRepository
    {
        private readonly IActiveTransactionProvider _transactionProvider;

        public InstrumentTypeRepository(IDbContextProvider<MyReEsopDbContext> dbContextProvider, IActiveTransactionProvider transactionProvider)
            : base(dbContextProvider)
        {
            _transactionProvider = transactionProvider;
        }

        public async Task<List<InstrumentType>> GetAllIntrumentType()
        {
            EnsureConnectionOpen();
            //List<Employee> lstemployee = new List<Employee>();
            using (var command = CreateCommand("GetIntrumentType", CommandType.StoredProcedure))
            {
                using (var dataReader = await command.ExecuteReaderAsync())
                {
                    var result = new List<InstrumentType>();
                    //var e = await _employeeRepository.GetAllListAsync();
                    while (dataReader.Read())
                    {
                        InstrumentType obj =new InstrumentType();
                        obj.Id = Convert.ToInt32(dataReader["MIT_ID"]);
                        obj.INSTRUMENTNAME = dataReader["INSTRUMENT_NAME"].ToString();
                        obj.INSDISPLAYNAME= dataReader["INS_DISPLAY_NAME"].ToString();
                        obj.MSEid = dataReader["MSE_ID"].ToString();
                        obj.CurrencySymbol = dataReader["CurrencySymbol"].ToString();
                        obj.CurrencyAlias = dataReader["CurrencyAlias"].ToString();
                        obj.SEMVALRPT = dataReader["SEM_VAL_RPT_ID"].ToString();
                        obj.ISENABLED= Convert.ToBoolean(dataReader["IS_ENABLED"]);
                        obj.SESYMBOL = dataReader["STOCK_EXCHANGE_SYMBOL"].ToString();
                        obj.CIMid = dataReader["CIM_ID"].ToString();
                        obj.Curencyid = dataReader["CurrencyID"].ToString();
                        obj.STOCKECCHANGESYMBOL = dataReader["STOCK_EXCHANGE_SYMBOL_VAL_RPT"].ToString();
                        //result.Add(dataReader["INSTRUMENT_NAME"].ToString());
                        //result.Add(dataReader["MSE_ID"].ToString());
                        //result.Add(dataReader["CurrencySymbol"].ToString());
                        //result.Add(dataReader["CurrencyAlias"].ToString());
                        //result.Add(dataReader["SEM_VAL_RPT_ID"].ToString());
                        //result.Add(Convert.ToBoolean(dataReader["IS_ENABLED"]).ToString());
                        //result.Add(Convert.ToInt32(dataReader["MIT_ID"]).ToString());
                        result.Add(obj);
                    }

                    return result;
                }
            }
        }

        public async Task UpdateIntrumentType(UpdateIntrumentTypeDto input)
        {
            await Context.Database.ExecuteSqlCommandAsync(
                "EXEC updatesptemp1MIT @MIT_ID,@CIM_ID,@MSE_ID,@INS_DISPLAY_NAME,@CurrencyID,@SEM_VAL_RPT_ID,@IS_ENABLED,UPDATED_BY,@type",                
                new SqlParameter("MIT_ID", input.Id),
                new SqlParameter("CIM_ID", input.CIMid),
                new SqlParameter("MSE_ID", input.MSEid),
                new SqlParameter("INS_DISPLAY_NAME", input.INSDISPLAYNAME),
                new SqlParameter("CurrencyID", input.Curencyid),
                new SqlParameter("SEM_VAL_RPT_ID", input.SEMVALRPTID),
                new SqlParameter("IS_ENABLED", input.ISENABLED),
                new SqlParameter("type", "")

            );
        }

        
        private DbCommand CreateCommand(string commandText, CommandType commandType, params SqlParameter[] parameters)
        {
            var command = Context.Database.GetDbConnection().CreateCommand();

            command.CommandText = commandText;
            command.CommandType = commandType;
            command.Transaction = GetActiveTransaction();

            foreach (var parameter in parameters)
            {
                command.Parameters.Add(parameter);
            }

            return command;
        }

        private void EnsureConnectionOpen()
        {
            var connection = Context.Database.GetDbConnection();

            if (connection.State != ConnectionState.Open)
            {
                connection.Open();
            }
        }

        private DbTransaction GetActiveTransaction()
        {
            return (DbTransaction)_transactionProvider.GetActiveTransaction(new ActiveTransactionProviderArgs
            {
                {"ContextType", typeof(MyReEsopDbContext) },
                {"MultiTenancySide", MultiTenancySide }
            });
        }
    }
}
