﻿using Abp.Domain.Repositories;
using MyReEsop.CompanyInfo.InstrumentType.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyReEsop.CompanyInfo.InstrumentType
{
    public interface IInstrumentTypeRepository : IRepository<InstrumentType,int>
    {
        Task<List<InstrumentType>> GetAllIntrumentType();

        Task UpdateIntrumentType(UpdateIntrumentTypeDto input);
    }
}
