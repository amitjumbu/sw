﻿using Abp.Application.Services.Dto;

namespace MyReEsop.CompanyInfo.InstrumentType.Dtos
{
    public class CreateIntrumentTypeDto: EntityDto
    {
        public string INSTRUMENTNAME { get; set; }

        public string MSEid { get; set; }

        public string CurrencySymbol { get; set; }

        public string CurrencyAlias { get; set; }

        public string SEMVALRPT { get; set; }

        public bool ISENABLED { get; set; }

        public string SESYMBOL { get; set; }

        public string CIMid { get; set; }

        public string Curencyid { get; set; }

        public string STOCKECCHANGESYMBOL { get; set; }
    }
}
