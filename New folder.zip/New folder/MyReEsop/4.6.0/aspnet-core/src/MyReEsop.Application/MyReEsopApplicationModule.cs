﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using MyReEsop.Authorization;

namespace MyReEsop
{
    [DependsOn(
        typeof(MyReEsopCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class MyReEsopApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<MyReEsopAuthorizationProvider>();
        }

        public override void Initialize()
        {
            var thisAssembly = typeof(MyReEsopApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddProfiles(thisAssembly)
            );
        }
    }
}
