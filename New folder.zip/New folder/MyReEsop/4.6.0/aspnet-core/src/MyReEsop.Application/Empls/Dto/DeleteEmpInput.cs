﻿namespace MyReEsop.Empls.Dto
{
    public class DeleteEmpInput
    {
        public int Id { get; set; }
    }
}
