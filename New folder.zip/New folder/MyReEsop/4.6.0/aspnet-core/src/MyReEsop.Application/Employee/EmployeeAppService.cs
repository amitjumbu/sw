﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Authorization;
using Abp.Domain.Repositories;
using MyReEsop.Authorization;
using MyReEsop.Employee.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MyReEsop.Employee
{
    [AbpAuthorize]
    public class EmployeeAppService : AsyncCrudAppService<Employee, EmployeeListDto>, IEmployeeAppService
    {
        
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeAppService(IRepository<Employee> repository, IEmployeeRepository employeeRepository) : base(repository)
        {
            _employeeRepository = employeeRepository;
        }

        public async Task<ListResultDto<Employee>> GetAllEmployees()
        {
            var e = await _employeeRepository.GetAllListAsync();
            return new ListResultDto<Employee>(ObjectMapper.Map<List<Employee>>(e));
        }
    }
}
