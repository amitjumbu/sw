﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using System.Threading.Tasks;

namespace MyReEsop.Employee
{
    public interface IEmployeeAppService : IApplicationService
    {
        Task<ListResultDto<Employee>> GetAllEmployees();
    }
}
