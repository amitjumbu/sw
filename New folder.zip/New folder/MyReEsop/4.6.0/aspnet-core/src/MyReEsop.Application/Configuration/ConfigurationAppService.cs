﻿using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Runtime.Session;
using MyReEsop.Configuration.Dto;

namespace MyReEsop.Configuration
{
    [AbpAuthorize]
    public class ConfigurationAppService : MyReEsopAppServiceBase, IConfigurationAppService
    {
        public async Task ChangeUiTheme(ChangeUiThemeInput input)
        {
            await SettingManager.ChangeSettingForUserAsync(AbpSession.ToUserIdentifier(), AppSettingNames.UiTheme, input.Theme);
        }
    }
}
