﻿using Abp.Authorization;
using Abp.Domain.Repositories;
using MyReEsop.MultiTenancy;

namespace MyReEsop.CompanyProfile
{
    [AbpAuthorize]
    public class CompanyProfileAppService : MyReEsopAppServiceBase, ICompanyProfileAppService
    {
        //public CompanyProfileAppService(IRepository<Tenant, int> repository


        //    ) : base(repository)
        //{

        //}
    }
}
