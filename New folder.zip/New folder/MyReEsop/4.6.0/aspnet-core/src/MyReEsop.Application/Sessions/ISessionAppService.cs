﻿using System.Threading.Tasks;
using Abp.Application.Services;
using MyReEsop.Sessions.Dto;

namespace MyReEsop.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
