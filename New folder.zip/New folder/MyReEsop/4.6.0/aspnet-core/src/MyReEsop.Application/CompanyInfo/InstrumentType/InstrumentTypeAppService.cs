﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using MyReEsop.CompanyInfo.InstrumentType.Dto;

namespace MyReEsop.CompanyInfo.InstrumentType
{
    public class InstrumentTypeAppService : MyReEsopAppServiceBase, IInstrumentTypeAppService
    {
        private readonly IInstrumentTypeRepository _InstrumentTypeRepository;

        public InstrumentTypeAppService(IInstrumentTypeRepository InstrumentTypeRepository)
        {
            _InstrumentTypeRepository = InstrumentTypeRepository;
        }
        //public async Task<ListResultDto<InstrumentTypeDto>> GetAllInstrumentType()
        //{
        //    var e = await _InstrumentTypeRepository.GetAllIntrumentType(); 
        //    return new ListResultDto<InstrumentTypeDto>(e);
        //}

        public async Task<ListResultDto<InstrumentTypeDto>> GetAllInstrumentType()
        {

            var e = await _InstrumentTypeRepository.GetAllIntrumentType();
            
            return new ListResultDto<InstrumentTypeDto>(ObjectMapper.Map<List<InstrumentTypeDto>>(e));
        }
    }
}
