﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;

namespace MyReEsop.CompanyInfo.InstrumentType.Dto
{

    [AutoMapFrom(typeof(InstrumentType))]
    public class InstrumentTypeListDto
    {

        public int MITID { get; set; }

        public string INSTRUMENTNAME { get; set; }

        public string MSEID { get; set; }

        public string CurrencySymbol { get; set; }

        public string CurrencyAlias { get; set; }

        public string SEMVALRPTID { get; set; }

        public bool ISENABLED { get; set; }
    }
}
