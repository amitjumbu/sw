﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using MyReEsop.CompanyInfo.InstrumentType.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyReEsop.CompanyInfo.InstrumentType
{
    public interface IInstrumentTypeAppService : IApplicationService
    {
        Task<ListResultDto<InstrumentTypeDto>> GetAllInstrumentType();
        //Task<ListResultDto<InstrumentTypeDto>> GetAllInstrumentType();
    }
}
