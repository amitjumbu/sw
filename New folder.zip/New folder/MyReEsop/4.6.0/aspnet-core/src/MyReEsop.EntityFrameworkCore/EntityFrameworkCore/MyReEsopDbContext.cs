﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using MyReEsop.Authorization.Roles;
using MyReEsop.Authorization.Users;
using MyReEsop.MultiTenancy;
using MyReEsop.Models;

namespace MyReEsop.EntityFrameworkCore
{
    public class MyReEsopDbContext : AbpZeroDbContext<Tenant, Role, User, MyReEsopDbContext>
    {
        /* Define a DbSet for each entity of the application */
        public DbSet<Models.Employee> Employees { get; set; }
        public DbSet<Models.Employee> Employee1 { get; set; }
        public MyReEsopDbContext(DbContextOptions<MyReEsopDbContext> options)
            : base(options)
        {
        }
    }
}
