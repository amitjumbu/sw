﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using MyReEsop.Configuration;
using MyReEsop.Web;


namespace MyReEsop.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class MyReEsopDbContextFactory : IDesignTimeDbContextFactory<MyReEsopDbContext>
    {
        public MyReEsopDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<MyReEsopDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            MyReEsopDbContextConfigurer.Configure(builder, configuration.GetConnectionString(MyReEsopConsts.ConnectionStringName));

            return new MyReEsopDbContext(builder.Options);
        }
    }
}
