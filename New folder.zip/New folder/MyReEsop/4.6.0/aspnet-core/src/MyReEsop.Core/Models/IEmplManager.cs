﻿using Abp.Domain.Repositories;
using Abp.Domain.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyReEsop.Models
{
    public interface IEmplManager : IDomainService
    {
        IEnumerable<Employee> GetAllList();
        Employee GetEmpByID(int id);
        Task<Employee> Create(Employee entity);
        void Update(Employee entity);
        void Delete(int id);
    }
}
