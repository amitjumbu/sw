﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using Abp.Domain.Services;
using Abp.UI;

namespace MyReEsop.Models
{
    public class EmplManager : DomainService,IEmplManager
    {
        private readonly IRepository<Employee> _repositoryEmp;
        public EmplManager(IRepository<Employee> repositoryEmp)
        {
            _repositoryEmp = repositoryEmp;
        }

        public async Task<Employee> Create(Employee entity)
        {
            var emp = _repositoryEmp.FirstOrDefault(x => x.Id == entity.Id);
            if (emp != null)
            {
                throw new UserFriendlyException("Allready Exist");
            }
            else
            {
                return await _repositoryEmp.InsertAsync(entity);
            }
        }

        public void Delete(int id)
        {
            var emp = _repositoryEmp.FirstOrDefault(x => x.Id == id);
            if (emp == null)
            {
                throw new UserFriendlyException("no data found");
            }
            else
            {
                _repositoryEmp.Delete(emp);
            }
        }

        public IEnumerable<Employee> GetAllList()
        {
            return _repositoryEmp.GetAll();
        }

        public Employee GetEmpByID(int id)
        {
            return _repositoryEmp.Get(id);
        }

        public void Update(Employee entity)
        {
            _repositoryEmp.Update(entity);
        }
    }
}
