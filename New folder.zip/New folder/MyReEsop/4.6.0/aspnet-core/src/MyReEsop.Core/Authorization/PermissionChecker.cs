﻿using Abp.Authorization;
using MyReEsop.Authorization.Roles;
using MyReEsop.Authorization.Users;

namespace MyReEsop.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
