﻿using Abp.Authorization.Users;
using MyReEsop.Authorization.Users;

namespace MyReEsop.Authorization.Employee
{
    public class Employee : AbpUser<User>
    {
        public Employee()
        {

        }
    }
}
