import { Component, Injector, AfterViewInit } from '@angular/core';
import { AppComponentBase } from '@shared/app-component-base';
import { appModuleAnimation } from '@shared/animations/routerTransition';

@Component({
  selector: 'app-company-profile',
  templateUrl: './company-profile.component.html',
   styleUrls: ['./company-profile.component.css']
})
export class CompanyProfileComponent extends AppComponentBase {

    constructor(
        injector: Injector
    ) {
        super(injector);
    }

}
