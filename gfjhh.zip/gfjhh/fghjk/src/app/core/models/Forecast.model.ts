import { PaginationModel } from "./Pagination.Model";

export class Forecast extends PaginationModel {
  Id: number;
  ForecastTypeId: number;
  Code: string;
  Name: string;
  Description: string;
  StartDate: Date;
  EndDate: Date;
  SalesManagerIds: any;
  IsActive: string;
  HistoricalForecastId: string;
  CalendarTypeId: number;
  NoOfDaysInAperiod: string;
  IsDeleted: boolean;
  ClientId: number;
  SourceSystemId: number;
  UpdatedBy: string;
  UpdateDateTimeServer: Date;
  UpdateDateTimeBrowser: Date;
  CreatedBy: string;
  CreateDateTimeBrowser: Date;
  CreateDateTimeServer: Date;
}



