"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Resource = void 0;
var Resource = /** @class */ (function () {
    function Resource() {
    }
    return Resource;
}());
exports.Resource = Resource;
//# sourceMappingURL=resource .js.map