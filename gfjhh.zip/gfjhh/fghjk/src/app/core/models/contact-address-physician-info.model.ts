
export class ContactAddressPhysicianInfo {
  Id: number;
  Mode: string;
  DataMode: string;
  constructor() {
    
  }
}

