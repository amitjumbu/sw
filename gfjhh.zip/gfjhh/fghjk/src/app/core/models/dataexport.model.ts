import { PaginationModel } from "./Pagination.Model";

export class DataExportViewModel extends PaginationModel {
  selectRow: string;
  id: number;
  Datesubmit: string;
  User: string;
  Status: string; 


}


