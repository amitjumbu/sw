"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Geoloction = /** @class */ (function () {
    function Geoloction() {
    }
    return Geoloction;
}());
exports.Geoloction = Geoloction;
var AddressLocation = /** @class */ (function () {
    function AddressLocation() {
    }
    return AddressLocation;
}());
exports.AddressLocation = AddressLocation;
//# sourceMappingURL=geolocation.js.map