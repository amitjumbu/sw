"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserActivityLog = /** @class */ (function () {
    function UserActivityLog() {
    }
    return UserActivityLog;
}());
exports.UserActivityLog = UserActivityLog;
var ActionOnPage;
(function (ActionOnPage) {
    ActionOnPage["View"] = "View Report";
    ActionOnPage["Save"] = "Save Information";
    ActionOnPage["Edit"] = "Modify Information";
    ActionOnPage["Delete"] = "Delete Information";
})(ActionOnPage = exports.ActionOnPage || (exports.ActionOnPage = {}));
//# sourceMappingURL=useractivity.js.map