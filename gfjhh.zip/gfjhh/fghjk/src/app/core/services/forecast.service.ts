import { Injectable } from '@angular/core';

import { JsonApiService } from './json-api.service';
import { environment } from '@env/environment';
import { User, PreferenceTypeService } from '..';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BaseService } from './base.service';
import { map } from 'rxjs/operators';

const routes = {
    users: '/users'
};

@Injectable({
  providedIn: 'root'
})
export class ForecastService extends BaseService{

  constructor(private http: HttpClient,
    preferenceService: PreferenceTypeService) {
    super(preferenceService);
  }

  

    addForecast(forecast: any) {
      return this.http.post<any>(`${this.BASE_SERVICE_URL}/forecast`,forecast)
        .pipe(map(response => {
          return response;
        }));
    }
}
