import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-filter',
  templateUrl: './claim-filter.component.html',
  styleUrls: ['./claim-filter.component.css']
})
export class ClaimFilterComponent implements OnInit {
  panelOpenState = false;
  public dateFormat: String = "MM-dd-yyyy";
  constructor() { }

  ngOnInit(): void {
  }
}
