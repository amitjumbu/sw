import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tosca-forgot-password',
  templateUrl: './tosca-forgot-password.component.html',
  styleUrls: ['./tosca-forgot-password.component.css']
})
export class ToscaForgotPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
