import { NgModule } from '@angular/core';

import { SharedModule } from '@app/shared';

@NgModule({
  declarations: [],
  imports: [
    SharedModule
  ]
})
export class BillingManagementModule { }
