
export interface List {
  id: string;
  name: string;
}

export const LISTS: List[] = [
  { name: 'Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1 Option 1', id: 'A' },
  { name: 'Option 2', id: 'B' },
  { name: 'Option 3', id: 'C' },
  { name: 'Option 4', id: 'D' },
  { name: 'Option 5', id: 'E' },
  { name: 'Option 6', id: 'F' },
  { name: 'Option 7', id: 'G' },
  { name: 'Option 8', id: 'H' },
  { name: 'Option 9', id: 'I' },
  { name: 'Option 10', id: 'J' }
];
