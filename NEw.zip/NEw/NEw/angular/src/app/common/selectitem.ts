export interface SelectItem {
    label?: string;
    value: any;
    styleClass?: string;
    icon?: string;
    title?: string;
    disabled?: boolean;
}
export interface SelectItems {
    label?: string;
    value: any;
    
}
