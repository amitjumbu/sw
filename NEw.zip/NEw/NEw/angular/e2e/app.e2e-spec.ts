import { MyReEsopTemplatePage } from './app.po';

describe('MyReEsop App', function() {
  let page: MyReEsopTemplatePage;

  beforeEach(() => {
    page = new MyReEsopTemplatePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
