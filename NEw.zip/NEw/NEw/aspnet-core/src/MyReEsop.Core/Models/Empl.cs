﻿using Abp.Domain.Entities.Auditing;
using System.ComponentModel.DataAnnotations;

namespace MyReEsop.Models
{
    public class Employee : FullAuditedEntity
    {
        [Required]
        [Display(Name = "Name")]
        [StringLength(64, ErrorMessage = "Maximum Length is 64")]
        public string Name { get; set; }
        public string Gender { get; set; }
        public string Department { get; set; }
        public string City { get; set; }
    }
}
