﻿using Abp.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.Employee
{
    public class Employee : Entity
    {
        
        public string Name { get; set; }

        public string Gender { get; set; }

        public string Department { get; set; }

        public string City { get; set; }
    }
}
