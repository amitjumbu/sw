﻿using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using MyReEsop.Authorization.Users;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyReEsop.Employee
{
    public interface IEmployeeRepository : IRepository<User, long>
    {
        Task<List<string>> GetAllEmployees();
    }
}
