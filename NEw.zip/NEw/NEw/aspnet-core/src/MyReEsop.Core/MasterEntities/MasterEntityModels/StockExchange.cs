﻿using Abp.Domain.Entities;
using Abp.Domain.Entities.Auditing;

namespace MyReEsop.MasterEntities.MasterEntityModels
{
    public class StockExchange:Entity
    {
        public new string Id { get; set; }
        public string MSE_ID { get; set; }
        public string STOCK_EXCHANGE_NAME { get; set; }
        public string STOCK_EXCHANGE_SYMBOL { get; set; }
        public string STOCK_EXCHANGE_URL { get; set; }
        public bool IS_ACTIVE { get; set; }
        public int CurrencyID { get; set; }
        //public StockExchange(string Id)
        //{
        //    Id = MSE_ID;
        //}

    }
}
