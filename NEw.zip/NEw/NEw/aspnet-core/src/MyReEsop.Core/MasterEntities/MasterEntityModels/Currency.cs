﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.MasterEntities.MasterEntityModels
{
    class Currency
    {
    }
}
