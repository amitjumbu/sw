﻿using System.Collections.Generic;
using Abp.Domain.Repositories;
using Abp.Domain.Services;
using MyReEsop.MasterEntities.MasterEntityModels;

namespace MyReEsop.MasterEntities
{
    public class MasterEntityManager : DomainService, IMasterEntityManager
    {
        private readonly IRepository<StockExchange> _repositorySE;
        public MasterEntityManager(IRepository<StockExchange> repositorySE)
        {
            _repositorySE = repositorySE;
        }
        public IEnumerable<StockExchange> GetAllStockExchange()
        {
            return _repositorySE.GetAll();
        }
    }
}
