﻿using Abp.Domain.Services;
using MyReEsop.MasterEntities.MasterEntityModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.MasterEntities
{
   public interface IMasterEntityManager : IDomainService
    {
        IEnumerable<StockExchange> GetAllStockExchange();
    }
}
