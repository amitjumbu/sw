﻿using Abp.Application.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyReEsop.CompanyProfile
{
   public interface ICompanyProfileAppService: IApplicationService
    {
    }
}
