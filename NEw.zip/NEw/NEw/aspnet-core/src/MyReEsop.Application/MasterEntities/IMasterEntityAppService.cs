﻿using Abp.Application.Services;
using MyReEsop.MasterEntities.Dto;
using System.Collections.Generic;

namespace MyReEsop.MasterEntities
{
    public interface IMasterEntityAppService : IApplicationService
    {
        IEnumerable<GetStockExchaneOutput> ListAll();
    }
}
