﻿using Abp.AutoMapper;
using MyReEsop.MasterEntities.MasterEntityModels;

namespace MyReEsop.MasterEntities.Dto
{
    [AutoMapFrom(typeof(StockExchange))]
    public class GetStockExchaneOutput
    {
        //public string MSE_ID { get; set; }
        public int Id { get; set; }
        public string STOCK_EXCHANGE_NAME { get; set; }
        public string STOCK_EXCHANGE_SYMBOL { get; set; }
        public string STOCK_EXCHANGE_URL { get; set; }
        public bool IS_ACTIVE { get; set; }
        public int CurrencyID { get; set; }
    }
}
