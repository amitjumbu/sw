﻿using AutoMapper;
using MyReEsop.MasterEntities.Dto;
using MyReEsop.MasterEntities.MasterEntityModels;
using System.Collections.Generic;
using System.Linq;

namespace MyReEsop.MasterEntities
{
    public class MasterEntityAppService : MyReEsopAppServiceBase, IMasterEntityAppService
    {
        private readonly IMasterEntityManager _MasterEntityManager;
        public MasterEntityAppService(IMasterEntityManager MasterEntityManager)
        {
            _MasterEntityManager = MasterEntityManager;
        }
        public IEnumerable<GetStockExchaneOutput> ListAll()
        {
            var getAll = _MasterEntityManager.GetAllStockExchange().ToList();
            List<GetStockExchaneOutput> output = Mapper.Map<List<StockExchange>, List<GetStockExchaneOutput>>(getAll);
            return output;

        }
    }
}
