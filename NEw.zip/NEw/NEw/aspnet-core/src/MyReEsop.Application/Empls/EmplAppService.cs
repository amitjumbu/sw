﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Abp.Application.Services;
using AutoMapper;
using MyReEsop.Empls.Dto;
using MyReEsop.Models;

namespace MyReEsop.Empls
{
    public class EmplAppService : MyReEsopAppServiceBase, IEmplAppService
    {
        private readonly IEmplManager _EmpManager;
        public EmplAppService(IEmplManager EmpManager)
        {
            _EmpManager = EmpManager;
        }

        //public async Task Create(CreateEmpInput input)
        //{
        //    Models.Employee output = Mapper.Map<CreateEmpInput, Models.Employee>(input);
        //    await _EmpManager.Create(output);
        //}

        //public void Delete(DeleteEmpInput input)
        //{
        //    _EmpManager.Delete(input.Id);
        //}

        //public GetEmpOutput GetEmpById(GetEmpInput input)
        //{
        //    var getEmp = _EmpManager.GetEmpByID(input.Id);
        //    GetEmpOutput output = Mapper.Map<Models.Employee, GetEmpOutput>(getEmp);
        //    return output;
        //}

        public IEnumerable<GetEmpOutput> ListAll()
        {
            var getAll = _EmpManager.GetAllList().ToList();
            List<GetEmpOutput> output = Mapper.Map<List<Models.Employee>, List<GetEmpOutput>>(getAll);
            return output;
        }

        //public void Update(UpdateEmpInput input)
        //{
        //    Models.Employee output = Mapper.Map<UpdateEmpInput, Models.Employee>(input);

        //    _EmpManager.Update(output);
        //}
    }
}
