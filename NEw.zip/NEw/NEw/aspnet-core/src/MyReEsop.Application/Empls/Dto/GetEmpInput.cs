﻿namespace MyReEsop.Empls.Dto
{
    public class GetEmpInput
    {
        public int Id { get; set; }
    }
}
