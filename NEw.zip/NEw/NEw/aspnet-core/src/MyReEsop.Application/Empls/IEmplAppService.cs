﻿using Abp.Application.Services;
using MyReEsop.Empls.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyReEsop.Empls
{
    public interface IEmplAppService : IApplicationService
    {
        IEnumerable<GetEmpOutput> ListAll();
        //Task Create(CreateEmpInput input);
        //void Update(UpdateEmpInput input);
        //void Delete(DeleteEmpInput input);

        //GetEmpOutput GetEmpById(GetEmpInput input);
    }
}
