﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;

namespace MyReEsop.Employee.Dto
{
    [AutoMapFrom(typeof(Employee))]
    public class EmployeeListDto : EntityDto
    {
        public string Name { get; set; }

        public string Gender { get; set; }

        public string Department { get; set; }

        public string City { get; set; }
    }
}
