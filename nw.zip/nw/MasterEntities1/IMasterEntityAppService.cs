﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using MyReEsop.MasterEntities.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyReEsop.MasterEntities
{
    public interface IMasterEntityAppService : IApplicationService
    {
        Task<ListResultDto<GetStockExchaneOutput>> ListAll();
        Task<ListResultDto<GetCurrencyOutput>> ListAllCurrencyAsync();
    }
}
