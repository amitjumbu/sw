﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using MyReEsop.MasterEntities.MasterEntityModels;

namespace MyReEsop.MasterEntities.Dto
{
    [AutoMapFrom(typeof(Currency))]
    public class GetCurrencyOutput:EntityDto
    {
        public string CurrencyName { get; set; }
        public string CurrencySymbol { get; set; }
        public string CurrencyAlias { get; set; }
    }
}
