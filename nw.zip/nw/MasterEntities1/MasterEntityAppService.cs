﻿using Abp.Application.Services.Dto;
using AutoMapper;
using MyReEsop.MasterEntities.Dto;
using MyReEsop.MasterEntities.MasterEntityModels;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyReEsop.MasterEntities
{
    public class MasterEntityAppService : MyReEsopAppServiceBase, IMasterEntityAppService
    {
        private readonly IMasterEntityManager _MasterEntityManager;
        public MasterEntityAppService(IMasterEntityManager MasterEntityManager)
        {
            _MasterEntityManager = MasterEntityManager;
        }
        
        public async Task<ListResultDto<GetStockExchaneOutput>> ListAll()
        {

            var e = await _MasterEntityManager.GetAllStockExchange();

            return new ListResultDto<GetStockExchaneOutput>(ObjectMapper.Map<List<GetStockExchaneOutput>>(e));
        }

        public async Task<ListResultDto<GetCurrencyOutput>> ListAllCurrencyAsync()
        {
            var e = await _MasterEntityManager.GetAllCurrency();

            return new ListResultDto<GetCurrencyOutput>(ObjectMapper.Map<List<GetCurrencyOutput>>(e));
        }
        //public async Task<ListResultDto<GetStockExchaneOutput>> IMasterEntityAppService.ListAll()
        //{
        //    throw new System.NotImplementedException();
        //}
    }
}
