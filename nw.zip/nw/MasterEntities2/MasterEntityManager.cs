﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Entities;
using Abp.Domain.Repositories;
using Abp.Domain.Services;
using MyReEsop.MasterEntities.MasterEntityModels;

namespace MyReEsop.MasterEntities
{
    public class MasterEntityManager : DomainService, IMasterEntityManager
    {
        private readonly IRepository<StockExchange, long> _repositorySE;
        private readonly IRepository<Currency, int> _repositoryCurrency;
        public MasterEntityManager(IRepository<StockExchange, long> repositorySE, IRepository<Currency, int> repositoryCurrency)
        {
            _repositorySE = repositorySE;
            _repositoryCurrency = repositoryCurrency;
        }

        public Task<List<Currency>> GetAllCurrency()
        {
            return _repositoryCurrency.GetAllListAsync();
        }

        public Task<List<StockExchange>> GetAllStockExchange()
        {

            return _repositorySE.GetAllListAsync();

        }

        //public Task<List<StockExchange>> IMasterEntityManager.GetAllStockExchange()
        //{
        //    return _repositorySE.GetAll();
        //}
    }
}
