﻿using Abp.Domain.Entities;
using Abp.Domain.Entities.Auditing;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyReEsop.MasterEntities.MasterEntityModels
{
    [Table("MST_STOCK_EXCHANGE")]
    public class StockExchange:Entity<long>
    {
        [Column("MSE_ID")]
        
        public override long Id { get; set; }        
        public string STOCK_EXCHANGE_NAME { get; set; }
        public string STOCK_EXCHANGE_SYMBOL { get; set; }
        public string STOCK_EXCHANGE_URL { get; set; }
        public byte IS_ACTIVE { get; set; }
        public int CurrencyID { get; set; }
        

        public StockExchange()
        {
           //Id=;
        }

        
    }
}
