﻿using Abp.Domain.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyReEsop.MasterEntities.MasterEntityModels
{
    public class Currency:Entity
    {
        [Column("CurrencyID")]

        public override int Id { get; set; }
        public string CurrencyName { get; set; }
        public string CurrencySymbol { get; set; }
        public string CurrencyAlias { get; set; }
        
    }
}
