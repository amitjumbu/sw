﻿using Abp.Domain.Services;
using MyReEsop.MasterEntities.MasterEntityModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MyReEsop.MasterEntities
{
   public interface IMasterEntityManager : IDomainService
    {
        Task<List<StockExchange>> GetAllStockExchange();
        Task<List<Currency>> GetAllCurrency();
    }
}
